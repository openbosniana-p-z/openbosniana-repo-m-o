import colors from "../colors.js";

export default colors("1b9e77d95f027570b3e7298a66a61ee6ab02a6761d666666");
