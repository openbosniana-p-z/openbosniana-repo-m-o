export default function (number: number, index: number): [string, string];
