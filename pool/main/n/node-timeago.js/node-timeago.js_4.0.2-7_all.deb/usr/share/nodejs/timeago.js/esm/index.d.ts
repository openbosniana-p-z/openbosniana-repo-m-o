/**
 * Created by hustcc on 18/5/20.
 * Contract: i@hust.cc
 */
import { register } from './register';
export { format } from './format';
export { render, cancel } from './realtime';
export { register };
export * from './interface';
