// Type definitions for unc-path-regex 0.1
// Project: https://github.com/regexhq/unc-path-regex
// Definitions by: BendingBender <https://github.com/BendingBender>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

export = uncPathRegex;

declare function uncPathRegex(): RegExp;
