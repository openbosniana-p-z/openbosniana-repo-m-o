// Type definitions for sorted-object 2.0
// Project: https://github.com/domenic/sorted-object#readme
// Definitions by: Richie Bendall <https://github.com/Richienb>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

declare function sortedObject(input: object): object;

export = sortedObject;
