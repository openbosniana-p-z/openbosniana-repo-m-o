import { ui } from '../..';

export = ui.BottomBar;
