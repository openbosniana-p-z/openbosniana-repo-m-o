import { ui } from '../..';

export = ui.Prompt;
