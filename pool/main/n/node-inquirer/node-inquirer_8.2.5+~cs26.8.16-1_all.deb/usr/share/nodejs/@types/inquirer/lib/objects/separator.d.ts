import { Separator } from "../..";

export = Separator;
