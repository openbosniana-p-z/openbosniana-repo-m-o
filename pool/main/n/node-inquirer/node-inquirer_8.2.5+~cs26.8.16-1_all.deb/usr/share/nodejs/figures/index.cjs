"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.replaceSymbols = exports.mainSymbols = exports.fallbackSymbols = exports["default"] = void 0;
var _nodeProcess = _interopRequireDefault(require("node:process"));
var _escapeStringRegexp = _interopRequireDefault(require("escape-string-regexp"));
var _isUnicodeSupported = _interopRequireDefault(require("is-unicode-supported"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
var platform = _nodeProcess["default"].platform;
var common = {
  square: '█',
  squareDarkShade: '▓',
  squareMediumShade: '▒',
  squareLightShade: '░',
  squareTop: '▀',
  squareBottom: '▄',
  squareLeft: '▌',
  squareRight: '▐',
  squareCenter: '■',
  bullet: '●',
  dot: '․',
  ellipsis: '…',
  pointerSmall: '›',
  triangleUp: '▲',
  triangleUpSmall: '▴',
  triangleDown: '▼',
  triangleDownSmall: '▾',
  triangleLeftSmall: '◂',
  triangleRightSmall: '▸',
  home: '⌂',
  heart: '♥',
  musicNote: '♪',
  musicNoteBeamed: '♫',
  arrowUp: '↑',
  arrowDown: '↓',
  arrowLeft: '←',
  arrowRight: '→',
  arrowLeftRight: '↔',
  arrowUpDown: '↕',
  almostEqual: '≈',
  notEqual: '≠',
  lessOrEqual: '≤',
  greaterOrEqual: '≥',
  identical: '≡',
  infinity: '∞',
  subscriptZero: '₀',
  subscriptOne: '₁',
  subscriptTwo: '₂',
  subscriptThree: '₃',
  subscriptFour: '₄',
  subscriptFive: '₅',
  subscriptSix: '₆',
  subscriptSeven: '₇',
  subscriptEight: '₈',
  subscriptNine: '₉',
  oneHalf: '½',
  oneThird: '⅓',
  oneQuarter: '¼',
  oneFifth: '⅕',
  oneSixth: '⅙',
  oneEighth: '⅛',
  twoThirds: '⅔',
  twoFifths: '⅖',
  threeQuarters: '¾',
  threeFifths: '⅗',
  threeEighths: '⅜',
  fourFifths: '⅘',
  fiveSixths: '⅚',
  fiveEighths: '⅝',
  sevenEighths: '⅞',
  line: '─',
  lineBold: '━',
  lineDouble: '═',
  lineDashed0: '┄',
  lineDashed1: '┅',
  lineDashed2: '┈',
  lineDashed3: '┉',
  lineDashed4: '╌',
  lineDashed5: '╍',
  lineDashed6: '╴',
  lineDashed7: '╶',
  lineDashed8: '╸',
  lineDashed9: '╺',
  lineDashed10: '╼',
  lineDashed11: '╾',
  lineDashed12: '−',
  lineDashed13: '–',
  lineDashed14: '‐',
  lineDashed15: '⁃',
  lineVertical: '│',
  lineVerticalBold: '┃',
  lineVerticalDouble: '║',
  lineVerticalDashed0: '┆',
  lineVerticalDashed1: '┇',
  lineVerticalDashed2: '┊',
  lineVerticalDashed3: '┋',
  lineVerticalDashed4: '╎',
  lineVerticalDashed5: '╏',
  lineVerticalDashed6: '╵',
  lineVerticalDashed7: '╷',
  lineVerticalDashed8: '╹',
  lineVerticalDashed9: '╻',
  lineVerticalDashed10: '╽',
  lineVerticalDashed11: '╿',
  lineDownLeft: '┐',
  lineDownLeftArc: '╮',
  lineDownBoldLeftBold: '┓',
  lineDownBoldLeft: '┒',
  lineDownLeftBold: '┑',
  lineDownDoubleLeftDouble: '╗',
  lineDownDoubleLeft: '╖',
  lineDownLeftDouble: '╕',
  lineDownRight: '┌',
  lineDownRightArc: '╭',
  lineDownBoldRightBold: '┏',
  lineDownBoldRight: '┎',
  lineDownRightBold: '┍',
  lineDownDoubleRightDouble: '╔',
  lineDownDoubleRight: '╓',
  lineDownRightDouble: '╒',
  lineUpLeft: '┘',
  lineUpLeftArc: '╯',
  lineUpBoldLeftBold: '┛',
  lineUpBoldLeft: '┚',
  lineUpLeftBold: '┙',
  lineUpDoubleLeftDouble: '╝',
  lineUpDoubleLeft: '╜',
  lineUpLeftDouble: '╛',
  lineUpRight: '└',
  lineUpRightArc: '╰',
  lineUpBoldRightBold: '┗',
  lineUpBoldRight: '┖',
  lineUpRightBold: '┕',
  lineUpDoubleRightDouble: '╚',
  lineUpDoubleRight: '╙',
  lineUpRightDouble: '╘',
  lineUpDownLeft: '┤',
  lineUpBoldDownBoldLeftBold: '┫',
  lineUpBoldDownBoldLeft: '┨',
  lineUpDownLeftBold: '┥',
  lineUpBoldDownLeftBold: '┩',
  lineUpDownBoldLeftBold: '┪',
  lineUpDownBoldLeft: '┧',
  lineUpBoldDownLeft: '┦',
  lineUpDoubleDownDoubleLeftDouble: '╣',
  lineUpDoubleDownDoubleLeft: '╢',
  lineUpDownLeftDouble: '╡',
  lineUpDownRight: '├',
  lineUpBoldDownBoldRightBold: '┣',
  lineUpBoldDownBoldRight: '┠',
  lineUpDownRightBold: '┝',
  lineUpBoldDownRightBold: '┡',
  lineUpDownBoldRightBold: '┢',
  lineUpDownBoldRight: '┟',
  lineUpBoldDownRight: '┞',
  lineUpDoubleDownDoubleRightDouble: '╠',
  lineUpDoubleDownDoubleRight: '╟',
  lineUpDownRightDouble: '╞',
  lineDownLeftRight: '┬',
  lineDownBoldLeftBoldRightBold: '┳',
  lineDownLeftBoldRightBold: '┯',
  lineDownBoldLeftRight: '┰',
  lineDownBoldLeftBoldRight: '┱',
  lineDownBoldLeftRightBold: '┲',
  lineDownLeftRightBold: '┮',
  lineDownLeftBoldRight: '┭',
  lineDownDoubleLeftDoubleRightDouble: '╦',
  lineDownDoubleLeftRight: '╥',
  lineDownLeftDoubleRightDouble: '╤',
  lineUpLeftRight: '┴',
  lineUpBoldLeftBoldRightBold: '┻',
  lineUpLeftBoldRightBold: '┷',
  lineUpBoldLeftRight: '┸',
  lineUpBoldLeftBoldRight: '┹',
  lineUpBoldLeftRightBold: '┺',
  lineUpLeftRightBold: '┶',
  lineUpLeftBoldRight: '┵',
  lineUpDoubleLeftDoubleRightDouble: '╩',
  lineUpDoubleLeftRight: '╨',
  lineUpLeftDoubleRightDouble: '╧',
  lineUpDownLeftRight: '┼',
  lineUpBoldDownBoldLeftBoldRightBold: '╋',
  lineUpDownBoldLeftBoldRightBold: '╈',
  lineUpBoldDownLeftBoldRightBold: '╇',
  lineUpBoldDownBoldLeftRightBold: '╊',
  lineUpBoldDownBoldLeftBoldRight: '╉',
  lineUpBoldDownLeftRight: '╀',
  lineUpDownBoldLeftRight: '╁',
  lineUpDownLeftBoldRight: '┽',
  lineUpDownLeftRightBold: '┾',
  lineUpBoldDownBoldLeftRight: '╂',
  lineUpDownLeftBoldRightBold: '┿',
  lineUpBoldDownLeftBoldRight: '╃',
  lineUpBoldDownLeftRightBold: '╄',
  lineUpDownBoldLeftBoldRight: '╅',
  lineUpDownBoldLeftRightBold: '╆',
  lineUpDoubleDownDoubleLeftDoubleRightDouble: '╬',
  lineUpDoubleDownDoubleLeftRight: '╫',
  lineUpDownLeftDoubleRightDouble: '╪',
  lineCross: '╳',
  lineBackslash: '╲',
  lineSlash: '╱'
};
var mainSymbols = _objectSpread(_objectSpread(_objectSpread({}, common), platform === 'linux' ? {
  circleQuestionMark: '?⃝',
  questionMarkPrefix: '?⃝'
} : {
  circleQuestionMark: '?',
  questionMarkPrefix: '?'
}), {}, {
  tick: '✔',
  info: 'ℹ',
  warning: '⚠',
  cross: '✖',
  squareSmall: '◻',
  squareSmallFilled: '◼',
  circle: '◯',
  circleFilled: '◉',
  circleDotted: '◌',
  circleDouble: '◎',
  circleCircle: 'ⓞ',
  circleCross: 'ⓧ',
  circlePipe: 'Ⓘ',
  radioOn: '◉',
  radioOff: '◯',
  checkboxOn: '☒',
  checkboxOff: '☐',
  checkboxCircleOn: 'ⓧ',
  checkboxCircleOff: 'Ⓘ',
  pointer: '❯',
  triangleUpOutline: '△',
  triangleLeft: '◀',
  triangleRight: '▶',
  lozenge: '◆',
  lozengeOutline: '◇',
  hamburger: '☰',
  smiley: '㋡',
  mustache: '෴',
  star: '★',
  play: '▶',
  nodejs: '⬢',
  oneSeventh: '⅐',
  oneNinth: '⅑',
  oneTenth: '⅒'
});
exports.mainSymbols = mainSymbols;
var fallbackSymbols = _objectSpread(_objectSpread({}, common), {}, {
  tick: '√',
  info: 'i',
  warning: '‼',
  cross: '×',
  squareSmall: '□',
  squareSmallFilled: '■',
  circle: '( )',
  circleFilled: '(*)',
  circleDotted: '( )',
  circleDouble: '( )',
  circleCircle: '(○)',
  circleCross: '(×)',
  circlePipe: '(│)',
  circleQuestionMark: '(?)',
  radioOn: '(*)',
  radioOff: '( )',
  checkboxOn: '[×]',
  checkboxOff: '[ ]',
  checkboxCircleOn: '(×)',
  checkboxCircleOff: '( )',
  questionMarkPrefix: '？',
  pointer: '>',
  triangleUpOutline: '∆',
  triangleLeft: '◄',
  triangleRight: '►',
  lozenge: '♦',
  lozengeOutline: '◊',
  hamburger: '≡',
  smiley: '☺',
  mustache: '┌─┐',
  star: '✶',
  play: '►',
  nodejs: '♦',
  oneSeventh: '1/7',
  oneNinth: '1/9',
  oneTenth: '1/10'
});
exports.fallbackSymbols = fallbackSymbols;
var shouldUseMain = (0, _isUnicodeSupported["default"])();
var figures = shouldUseMain ? mainSymbols : fallbackSymbols;
var _default = figures;
exports["default"] = _default;
var isFallbackSymbol = function isFallbackSymbol(key, mainSymbol) {
  return fallbackSymbols[key] !== mainSymbol;
};
var getFigureRegExp = function getFigureRegExp(key, mainSymbol) {
  return [new RegExp((0, _escapeStringRegexp["default"])(mainSymbol), 'g'), fallbackSymbols[key]];
};
var replacements = [];
var getReplacements = function getReplacements() {
  if (replacements.length > 0) {
    return replacements;
  }
  replacements = Object.entries(mainSymbols).filter(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 2),
      key = _ref2[0],
      mainSymbol = _ref2[1];
    return isFallbackSymbol(key, mainSymbol);
  }).map(function (_ref3) {
    var _ref4 = _slicedToArray(_ref3, 2),
      key = _ref4[0],
      mainSymbol = _ref4[1];
    return getFigureRegExp(key, mainSymbol);
  });
  return replacements;
};

// On terminals which do not support Unicode symbols, substitute them to other symbols
var replaceSymbols = function replaceSymbols(string) {
  if (shouldUseMain) {
    return string;
  }
  var _iterator = _createForOfIteratorHelper(getReplacements()),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var _step$value = _slicedToArray(_step.value, 2),
        figureRegExp = _step$value[0],
        fallbackSymbol = _step$value[1];
      string = string.replace(figureRegExp, fallbackSymbol);
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  return string;
};
exports.replaceSymbols = replaceSymbols;
