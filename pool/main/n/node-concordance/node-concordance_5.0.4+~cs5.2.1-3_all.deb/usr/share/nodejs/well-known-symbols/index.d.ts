declare const WellKnownSymbols: {
  getLabel (value: symbol): string | undefined,
  isWellKnown (value: symbol): boolean,
}

export = WellKnownSymbols;
