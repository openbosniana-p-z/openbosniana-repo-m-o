module.exports = { gute: 'nacht' };
