exports.index = 1;
exports.show  = 2;
