exports.world = true;
exports.universe = 42;
