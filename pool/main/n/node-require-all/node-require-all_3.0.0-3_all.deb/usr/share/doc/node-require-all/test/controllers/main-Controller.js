exports.index = 1;
exports.show  = 2;
exports.add   = 3;
exports.edit  = 4;
