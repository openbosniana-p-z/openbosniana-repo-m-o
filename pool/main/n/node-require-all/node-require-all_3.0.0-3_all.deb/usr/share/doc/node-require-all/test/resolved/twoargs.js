module.exports = function (arg1, arg2) {
	return arg2;
}
