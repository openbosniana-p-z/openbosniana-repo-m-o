# Nadoka: IRC Client server program.

Written by SASADA Koichi <ko1 at atdot.net>

[![Gem Version](https://badge.fury.io/rb/nadoka.svg)](http://badge.fury.io/rb/nadoka)
[![Build Status](https://img.shields.io/travis/nadoka/nadoka.svg)](https://travis-ci.org/nadoka/nadoka)
[![Code Climate](https://img.shields.io/codeclimate/github/nadoka/nadoka.svg)](https://codeclimate.com/github/nadoka/nadoka)

## What's this?

Nadoka is IRC Client Server program.
It's same concept as [madoka](http://www.madoka.org/).

You can do with this software:

- connect to IRC usually
- easy to make a bot with ruby


## more about

See Web pages:

- https://github.com/nadoka/nadoka
- http://www.atdot.net/nadoka/
