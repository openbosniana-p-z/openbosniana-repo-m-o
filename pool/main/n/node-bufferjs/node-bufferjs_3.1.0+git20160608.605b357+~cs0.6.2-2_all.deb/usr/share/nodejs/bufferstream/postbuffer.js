
module.exports = require('./lib/post-buffer')
