
module.exports = require('./lib/buffer-stream')
