# README.md

    resolve package root and package.json paths , work on node 17 too

## install

```bash
yarn add @yarn-tool/resolve-package
yarn-tool add @yarn-tool/resolve-package
yt add @yarn-tool/resolve-package
```

```typescript
import { resolvePackageJsonLocation } from '@yarn-tool/resolve-package'

console.dir(resolvePackageJsonLocation('tslib'));
```
