export function keyName(event: Event): string;

export const base: {[keyCode: number]: string};

export const shift: {[keyCode: number]: string};
