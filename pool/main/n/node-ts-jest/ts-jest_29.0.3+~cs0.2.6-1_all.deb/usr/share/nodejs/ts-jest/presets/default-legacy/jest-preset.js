module.exports = require('..').defaultsLegacy
