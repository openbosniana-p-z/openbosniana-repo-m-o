module.exports = require('..').jsWithBabelESMLegacy
