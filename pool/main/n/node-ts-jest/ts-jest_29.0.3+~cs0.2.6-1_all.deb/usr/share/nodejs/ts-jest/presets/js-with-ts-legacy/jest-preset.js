module.exports = require('..').jsWithTsLegacy
