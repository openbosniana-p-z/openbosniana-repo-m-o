module.exports = require('./dist/legacy')
