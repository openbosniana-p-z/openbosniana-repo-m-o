module.exports = require('..').defaultsESMLegacy
