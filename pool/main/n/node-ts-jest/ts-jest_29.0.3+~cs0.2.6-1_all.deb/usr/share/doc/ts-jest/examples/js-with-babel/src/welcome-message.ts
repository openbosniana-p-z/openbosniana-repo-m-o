export const getWelcomeMessage = (): string => 'Welcome to ts-jest!!!'
