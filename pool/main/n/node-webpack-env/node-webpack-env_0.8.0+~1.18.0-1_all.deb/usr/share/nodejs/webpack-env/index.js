module.exports = require(__dirname + '/lib/webpack_env')();
