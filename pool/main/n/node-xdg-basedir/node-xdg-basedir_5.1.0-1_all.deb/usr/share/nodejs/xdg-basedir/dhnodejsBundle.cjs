Object.defineProperty(exports, '__esModule', { value: true });

const os = require('os');
const path = require('path');

const homeDirectory = os.homedir();
const {env} = process;

const xdgData = env.XDG_DATA_HOME ||
	(homeDirectory ? path.join(homeDirectory, '.local', 'share') : undefined);

const xdgConfig = env.XDG_CONFIG_HOME ||
	(homeDirectory ? path.join(homeDirectory, '.config') : undefined);

const xdgState = env.XDG_STATE_HOME ||
	(homeDirectory ? path.join(homeDirectory, '.local', 'state') : undefined);

const xdgCache = env.XDG_CACHE_HOME || (homeDirectory ? path.join(homeDirectory, '.cache') : undefined);

const xdgRuntime = env.XDG_RUNTIME_DIR || undefined;

const xdgDataDirectories = (env.XDG_DATA_DIRS || '/usr/local/share/:/usr/share/').split(':');

if (xdgData) {
	xdgDataDirectories.unshift(xdgData);
}

const xdgConfigDirectories = (env.XDG_CONFIG_DIRS || '/etc/xdg').split(':');

if (xdgConfig) {
	xdgConfigDirectories.unshift(xdgConfig);
}

exports.xdgCache = xdgCache;
exports.xdgConfig = xdgConfig;
exports.xdgConfigDirectories = xdgConfigDirectories;
exports.xdgData = xdgData;
exports.xdgDataDirectories = xdgDataDirectories;
exports.xdgRuntime = xdgRuntime;
exports.xdgState = xdgState;
