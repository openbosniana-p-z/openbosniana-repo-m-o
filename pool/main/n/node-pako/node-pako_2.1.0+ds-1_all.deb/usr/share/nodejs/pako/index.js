// Top level file is just a mixin of submodules & constants
'use strict';

const { Deflate, deflate, deflateRaw, gzip } = require('./lib/deflate');

const { Inflate, inflate, inflateRaw, ungzip } = require('./lib/inflate');

const Zstream = require('./lib/zlib/zstream');
const zlib_deflate = require('./lib/zlib/deflate');
const zlib_inflate = require('./lib/zlib/inflate');

const constants = require('./lib/zlib/constants');

module.exports.Deflate = Deflate;
module.exports.deflate = deflate;
module.exports.deflateRaw = deflateRaw;
module.exports.gzip = gzip;
module.exports.Inflate = Inflate;
module.exports.inflate = inflate;
module.exports.inflateRaw = inflateRaw;
module.exports.ungzip = ungzip;
module.exports.constants = constants;
module.exports.Zstream = Zstream;
module.exports.zlib_deflate = zlib_deflate;
module.exports.zlib_inflate = zlib_inflate;
