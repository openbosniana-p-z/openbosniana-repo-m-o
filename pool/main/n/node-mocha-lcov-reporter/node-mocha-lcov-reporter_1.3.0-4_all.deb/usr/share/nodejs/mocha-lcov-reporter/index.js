/**
 * Export lib/
 *
 */

module.exports = require('./lib');
