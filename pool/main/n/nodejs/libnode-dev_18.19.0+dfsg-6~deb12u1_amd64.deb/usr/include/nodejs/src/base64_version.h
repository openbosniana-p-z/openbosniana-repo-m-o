// This is an auto generated file, please do not edit.
// Refer to tools/dep_updaters/update-base64.sh
#ifndef SRC_BASE64_VERSION_H_
#define SRC_BASE64_VERSION_H_
#define BASE64_VERSION "0.5.0"
#endif  // SRC_BASE64_VERSION_H_
