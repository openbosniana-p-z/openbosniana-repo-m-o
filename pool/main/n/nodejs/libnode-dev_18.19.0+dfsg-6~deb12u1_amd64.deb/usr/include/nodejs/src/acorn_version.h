// This is an auto generated file, please do not edit.
// Refer to tools/update-acorn.sh
#ifndef SRC_ACORN_VERSION_H_
#define SRC_ACORN_VERSION_H_
#define ACORN_VERSION "8.8.1"
#endif  // SRC_ACORN_VERSION_H_
