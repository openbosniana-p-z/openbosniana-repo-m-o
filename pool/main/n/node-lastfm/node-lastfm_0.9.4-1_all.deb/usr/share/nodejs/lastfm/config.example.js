module.exports = {
    api_key: '',
    secret: ''
};
