'use strict';
var parse = require('parse-base64vlq-mappings');

var mappings = parse('AAAA;AACA;AACA;AACA;AACA');
console.log(mappings);
