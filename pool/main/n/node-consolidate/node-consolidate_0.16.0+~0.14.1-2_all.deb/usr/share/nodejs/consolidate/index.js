module.exports = require('./lib/consolidate');
