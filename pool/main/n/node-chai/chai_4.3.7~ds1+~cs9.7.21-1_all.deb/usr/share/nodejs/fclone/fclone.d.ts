declare module 'fclone' {
  export default function fclone<T>(obj: T): T;
}
