module.exports = require('@mapbox/node-pre-gyp');
