'use strict';
const FirstChunkStream = require('first-chunk-stream');
const stripBomBuffer = require('strip-bom-buf');

module.exports = () =>
	new FirstChunkStream({chunkSize: 3}, async (chunk, encoding) => {
		return stripBomBuffer(chunk);
	});
