node-mersenne
=============

Great random number generation for nodejs!

Change log:

  * 0.0.4 -- clarify license (BSD)

  * 0.0.3 -- fix variable scoping to avoid globals

  * 0.0.1 -- initial release

