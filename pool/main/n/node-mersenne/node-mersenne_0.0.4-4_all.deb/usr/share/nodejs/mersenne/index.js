module.exports = require('./lib/mersenne.js');
