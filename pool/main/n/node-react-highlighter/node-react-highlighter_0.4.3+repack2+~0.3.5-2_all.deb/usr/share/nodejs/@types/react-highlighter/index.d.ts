// Type definitions for react-highlighter 0.3
// Project: https://github.com/helior/react-highlighter
// Definitions by: DefinitelyTyped <https://github.com/DefinitelyTyped>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped
// TypeScript Version: 2.8

/// <reference types="react" />

declare var Highlight: any;
export = Highlight;
