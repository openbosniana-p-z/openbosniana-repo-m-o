module.exports = require("strip-final-newline");
