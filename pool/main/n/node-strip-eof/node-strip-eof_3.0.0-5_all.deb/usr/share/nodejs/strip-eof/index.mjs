import * as strip-eof from 'strip-final-newline';
export default *;
