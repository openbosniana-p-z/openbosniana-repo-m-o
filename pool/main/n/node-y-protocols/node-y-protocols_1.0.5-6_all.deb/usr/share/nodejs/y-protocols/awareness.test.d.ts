export function testAwareness(tc: t.TestCase): void;
import * as t from "lib0/testing";
//# sourceMappingURL=awareness.test.d.ts.map