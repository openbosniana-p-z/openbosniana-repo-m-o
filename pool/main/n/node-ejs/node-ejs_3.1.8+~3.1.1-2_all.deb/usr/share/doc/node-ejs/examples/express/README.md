```
npm install
npm start
open http://localhost:3000
```
