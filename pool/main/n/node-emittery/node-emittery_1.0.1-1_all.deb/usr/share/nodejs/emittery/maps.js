export const anyMap = new WeakMap();
export const eventsMap = new WeakMap();
export const producersMap = new WeakMap();
