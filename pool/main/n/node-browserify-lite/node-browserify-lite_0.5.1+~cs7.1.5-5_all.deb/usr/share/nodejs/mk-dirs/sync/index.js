'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var fs = require('fs');
var path = require('path');

function throws(code, msg, path) {
	let err = new Error(code + ': ' + msg);
	err.code=code; err.path=path;
	throw err;
}

function mkdir(str, opts={}) {
	if (process.platform === 'win32' && /[<>:"|?*]/.test(str.replace(path.parse(str).root, ''))) {
		throws('EINVAL', 'invalid characters', str);
	}

	let cwd = path.resolve(opts.cwd || '.');
	let seg, mode = opts.mode || 0o777 & (~process.umask());
	let arr = path.resolve(cwd, path.normalize(str)).replace(cwd, '').split(/\/|\\/);

	for (seg of arr) {
		cwd = path.join(cwd, seg);
		if (fs.existsSync(cwd)) {
			if (!fs.statSync(cwd).isDirectory()) {
				throws('ENOTDIR', 'not a directory', cwd);
			}
		} else {
			fs.mkdirSync(cwd, mode);
		}
	}

	return cwd;
}

exports.mkdir = mkdir;
