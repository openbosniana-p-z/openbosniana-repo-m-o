export function rewrite(source: string, require?: string): string;
