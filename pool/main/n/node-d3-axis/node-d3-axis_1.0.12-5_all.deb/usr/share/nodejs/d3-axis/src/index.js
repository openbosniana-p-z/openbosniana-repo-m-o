export {
  axisTop,
  axisRight,
  axisBottom,
  axisLeft
} from "./axis";
