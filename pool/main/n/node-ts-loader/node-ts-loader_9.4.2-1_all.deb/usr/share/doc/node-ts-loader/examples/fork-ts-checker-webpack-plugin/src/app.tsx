import * as React from 'react';
import { Layout } from './components/layout';

export const App: React.FC = () => (
  <div className="ui container">
    <Layout />
  </div>
);
