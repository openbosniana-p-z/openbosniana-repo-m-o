import { CreateZoo } from '@myscope/zoo';
import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(
  <CreateZoo />,
  document.getElementById('react-content')
);