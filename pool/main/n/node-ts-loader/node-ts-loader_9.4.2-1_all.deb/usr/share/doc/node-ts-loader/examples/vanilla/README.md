# vanilla ts-loader

```shell
yarn install

# Run in watch mode
yarn watch

# Run in production mode
yarn build 
```

To see your output simply open up the `index.html` file in your browser of choice.
