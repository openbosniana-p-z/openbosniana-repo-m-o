import render = require('./render');

render();