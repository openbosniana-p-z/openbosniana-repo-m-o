import { Animal } from './animal';

import { createDog, Dog } from './dog';
export { Animal, createDog, Dog };
