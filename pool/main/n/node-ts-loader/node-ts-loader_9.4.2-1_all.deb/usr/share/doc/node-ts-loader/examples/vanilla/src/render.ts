function render() {
    document.getElementById('wrapper').innerHTML = "<h1> Hello World!</h1>";
}

export = render;