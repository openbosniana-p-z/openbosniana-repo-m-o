import * as React from 'react';

export const Layout: React.FC = () => <h1>Heya, heya, heya!!</h1>;
