import { concat } from '../index';
export default concat;
