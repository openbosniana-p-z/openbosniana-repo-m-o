import { clamp } from '../index';
export default clamp;
