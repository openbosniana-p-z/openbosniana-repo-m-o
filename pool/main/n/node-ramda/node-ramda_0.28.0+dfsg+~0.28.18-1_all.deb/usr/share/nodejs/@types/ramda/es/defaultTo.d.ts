import { defaultTo } from '../index';
export default defaultTo;
