import { findLast } from '../index';
export default findLast;
