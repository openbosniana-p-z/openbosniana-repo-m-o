import { range } from '../index';
export default range;
