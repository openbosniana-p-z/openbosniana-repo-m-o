import { match } from '../index';
export default match;
