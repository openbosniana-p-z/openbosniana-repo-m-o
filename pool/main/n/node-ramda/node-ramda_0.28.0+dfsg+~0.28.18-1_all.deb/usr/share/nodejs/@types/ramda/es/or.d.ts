import { or } from '../index';
export default or;
