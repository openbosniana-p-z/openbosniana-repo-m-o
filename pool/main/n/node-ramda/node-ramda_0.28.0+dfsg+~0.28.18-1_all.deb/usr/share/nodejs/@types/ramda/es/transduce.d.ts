import { transduce } from '../index';
export default transduce;
