import { cond } from '../index';
export default cond;
