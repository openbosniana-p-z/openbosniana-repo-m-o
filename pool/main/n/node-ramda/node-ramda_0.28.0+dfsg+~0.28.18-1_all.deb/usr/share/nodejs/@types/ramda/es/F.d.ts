import { F } from '../index';
export default F;
