import { reduceBy } from '../index';
export default reduceBy;
