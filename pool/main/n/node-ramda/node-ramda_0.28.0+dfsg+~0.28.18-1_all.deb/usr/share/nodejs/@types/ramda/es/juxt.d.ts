import { juxt } from '../index';
export default juxt;
