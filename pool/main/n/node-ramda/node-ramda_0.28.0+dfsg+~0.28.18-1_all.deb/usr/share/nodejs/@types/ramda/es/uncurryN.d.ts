import { uncurryN } from '../index';
export default uncurryN;
