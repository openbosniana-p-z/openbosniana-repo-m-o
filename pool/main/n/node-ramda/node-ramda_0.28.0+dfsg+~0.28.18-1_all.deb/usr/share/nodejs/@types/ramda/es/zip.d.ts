import { zip } from '../index';
export default zip;
