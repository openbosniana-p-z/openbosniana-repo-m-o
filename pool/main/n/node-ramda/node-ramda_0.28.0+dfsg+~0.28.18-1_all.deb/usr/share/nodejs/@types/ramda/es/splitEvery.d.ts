import { splitEvery } from '../index';
export default splitEvery;
