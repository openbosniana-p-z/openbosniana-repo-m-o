import { merge } from '../index';
export default merge;
