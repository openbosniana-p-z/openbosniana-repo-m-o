import { modulo } from '../index';
export default modulo;
