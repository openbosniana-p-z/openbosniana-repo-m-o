import { mathMod } from '../index';
export default mathMod;
