import { sort } from '../index';
export default sort;
