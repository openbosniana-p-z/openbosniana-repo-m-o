import { pluck } from '../index';
export default pluck;
