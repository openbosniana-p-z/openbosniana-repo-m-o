import { pipe } from '../index';
export default pipe;
