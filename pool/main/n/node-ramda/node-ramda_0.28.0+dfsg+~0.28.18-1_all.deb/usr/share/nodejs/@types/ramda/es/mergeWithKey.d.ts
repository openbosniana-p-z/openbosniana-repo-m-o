import { mergeWithKey } from '../index';
export default mergeWithKey;
