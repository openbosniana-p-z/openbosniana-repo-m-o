import { identity } from '../index';
export default identity;
