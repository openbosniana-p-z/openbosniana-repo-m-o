import { nAry } from '../index';
export default nAry;
