import { toPairsIn } from '../index';
export default toPairsIn;
