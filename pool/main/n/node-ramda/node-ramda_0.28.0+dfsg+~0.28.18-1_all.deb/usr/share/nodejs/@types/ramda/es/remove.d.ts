import { remove } from '../index';
export default remove;
