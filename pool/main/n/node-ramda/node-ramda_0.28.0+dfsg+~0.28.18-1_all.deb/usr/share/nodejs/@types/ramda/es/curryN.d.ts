import { curryN } from '../index';
export default curryN;
