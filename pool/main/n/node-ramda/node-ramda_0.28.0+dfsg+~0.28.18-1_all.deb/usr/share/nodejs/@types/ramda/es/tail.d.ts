import { tail } from '../index';
export default tail;
