import { props } from '../index';
export default props;
