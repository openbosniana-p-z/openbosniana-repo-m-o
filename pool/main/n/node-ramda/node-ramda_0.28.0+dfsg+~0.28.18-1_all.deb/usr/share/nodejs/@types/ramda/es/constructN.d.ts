import { constructN } from '../index';
export default constructN;
