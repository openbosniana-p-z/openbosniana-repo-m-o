import { max } from '../index';
export default max;
