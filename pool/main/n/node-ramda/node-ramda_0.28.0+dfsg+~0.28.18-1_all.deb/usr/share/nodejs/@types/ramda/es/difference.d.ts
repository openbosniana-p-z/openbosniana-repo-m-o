import { difference } from '../index';
export default difference;
