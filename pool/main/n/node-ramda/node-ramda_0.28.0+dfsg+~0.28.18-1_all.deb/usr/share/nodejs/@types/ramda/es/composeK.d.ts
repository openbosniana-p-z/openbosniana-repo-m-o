import { composeK } from '../index';
export default composeK;
