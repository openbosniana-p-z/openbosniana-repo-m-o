import { where } from '../index';
export default where;
