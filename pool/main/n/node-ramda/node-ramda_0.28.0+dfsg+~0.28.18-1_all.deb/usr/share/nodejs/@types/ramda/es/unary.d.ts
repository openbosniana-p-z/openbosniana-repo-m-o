import { unary } from '../index';
export default unary;
