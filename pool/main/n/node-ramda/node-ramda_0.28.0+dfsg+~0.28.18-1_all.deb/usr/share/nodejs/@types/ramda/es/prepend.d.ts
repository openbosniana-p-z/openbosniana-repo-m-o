import { prepend } from '../index';
export default prepend;
