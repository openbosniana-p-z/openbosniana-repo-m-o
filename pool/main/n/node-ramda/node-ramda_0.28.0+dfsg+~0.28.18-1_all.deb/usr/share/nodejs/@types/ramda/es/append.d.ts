import { append } from '../index';
export default append;
