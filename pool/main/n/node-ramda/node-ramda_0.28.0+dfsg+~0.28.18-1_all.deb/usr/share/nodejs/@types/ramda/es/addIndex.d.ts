import { addIndex } from '../index';
export default addIndex;
