import { mergeDeepRight } from '../index';
export default mergeDeepRight;
