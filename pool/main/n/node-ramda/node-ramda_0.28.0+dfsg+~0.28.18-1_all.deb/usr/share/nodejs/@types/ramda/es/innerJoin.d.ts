import { innerJoin } from '../index';
export default innerJoin;
