import { identical } from '../index';
export default identical;
