import { last } from '../index';
export default last;
