import { isEmpty } from '../index';
export default isEmpty;
