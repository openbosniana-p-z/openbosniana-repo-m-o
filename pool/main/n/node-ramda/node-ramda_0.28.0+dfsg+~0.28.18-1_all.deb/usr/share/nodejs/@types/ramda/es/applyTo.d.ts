import { applyTo } from '../index';
export default applyTo;
