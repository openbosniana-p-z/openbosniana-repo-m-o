import { isNil } from '../index';
export default isNil;
