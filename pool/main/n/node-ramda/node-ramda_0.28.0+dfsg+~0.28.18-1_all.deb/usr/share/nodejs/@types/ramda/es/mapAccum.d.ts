import { mapAccum } from '../index';
export default mapAccum;
