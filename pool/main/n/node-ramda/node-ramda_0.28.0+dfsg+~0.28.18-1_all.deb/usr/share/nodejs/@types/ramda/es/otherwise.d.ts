import { otherwise } from '../index';
export default otherwise;
