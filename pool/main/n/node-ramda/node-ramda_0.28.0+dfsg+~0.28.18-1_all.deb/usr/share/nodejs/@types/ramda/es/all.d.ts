import { all } from '../index';
export default all;
