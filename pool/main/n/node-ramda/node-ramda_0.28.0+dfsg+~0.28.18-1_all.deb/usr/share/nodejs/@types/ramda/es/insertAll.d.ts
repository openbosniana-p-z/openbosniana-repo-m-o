import { insertAll } from '../index';
export default insertAll;
