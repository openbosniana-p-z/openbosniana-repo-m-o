import { reduce } from '../index';
export default reduce;
