import { join } from '../index';
export default join;
