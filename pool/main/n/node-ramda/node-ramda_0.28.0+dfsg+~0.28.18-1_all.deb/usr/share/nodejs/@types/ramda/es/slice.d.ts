import { slice } from '../index';
export default slice;
