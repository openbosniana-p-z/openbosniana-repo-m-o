import { mapAccumRight } from '../index';
export default mapAccumRight;
