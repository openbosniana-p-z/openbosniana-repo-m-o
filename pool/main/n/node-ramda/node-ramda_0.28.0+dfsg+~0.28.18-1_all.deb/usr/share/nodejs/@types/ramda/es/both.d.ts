import { both } from '../index';
export default both;
