import { dropLast } from '../index';
export default dropLast;
