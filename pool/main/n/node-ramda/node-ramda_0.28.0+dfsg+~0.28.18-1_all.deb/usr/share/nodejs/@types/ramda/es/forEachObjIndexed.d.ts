import { forEachObjIndexed } from '../index';
export default forEachObjIndexed;
