import { nth } from '../index';
export default nth;
