import { eqBy } from '../index';
export default eqBy;
