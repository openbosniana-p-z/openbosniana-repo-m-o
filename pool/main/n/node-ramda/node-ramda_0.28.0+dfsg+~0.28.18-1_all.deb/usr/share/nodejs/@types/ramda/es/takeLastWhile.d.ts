import { takeLastWhile } from '../index';
export default takeLastWhile;
