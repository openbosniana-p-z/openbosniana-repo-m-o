import { lastIndexOf } from '../index';
export default lastIndexOf;
