import { dissocPath } from '../index';
export default dissocPath;
