import { propIs } from '../index';
export default propIs;
