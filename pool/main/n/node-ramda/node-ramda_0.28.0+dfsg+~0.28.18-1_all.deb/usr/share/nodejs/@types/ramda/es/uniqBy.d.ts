import { uniqBy } from '../index';
export default uniqBy;
