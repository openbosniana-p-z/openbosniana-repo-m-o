import { pair } from '../index';
export default pair;
