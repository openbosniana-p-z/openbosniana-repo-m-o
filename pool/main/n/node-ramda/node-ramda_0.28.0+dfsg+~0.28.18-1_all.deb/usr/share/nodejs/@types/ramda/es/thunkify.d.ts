import { thunkify } from '../index';
export default thunkify;
