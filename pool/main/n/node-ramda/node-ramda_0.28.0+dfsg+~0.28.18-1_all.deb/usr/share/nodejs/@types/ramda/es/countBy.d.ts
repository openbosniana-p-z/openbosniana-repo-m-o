import { countBy } from '../index';
export default countBy;
