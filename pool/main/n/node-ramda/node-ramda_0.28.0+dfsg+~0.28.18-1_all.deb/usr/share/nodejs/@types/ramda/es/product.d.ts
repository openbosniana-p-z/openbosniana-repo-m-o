import { product } from '../index';
export default product;
