import { any } from '../index';
export default any;
