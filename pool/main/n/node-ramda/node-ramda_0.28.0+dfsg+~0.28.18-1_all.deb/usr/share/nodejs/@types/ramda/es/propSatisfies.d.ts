import { propSatisfies } from '../index';
export default propSatisfies;
