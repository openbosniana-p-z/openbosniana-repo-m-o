import { eqProps } from '../index';
export default eqProps;
