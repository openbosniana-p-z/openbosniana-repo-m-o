import { propEq } from '../index';
export default propEq;
