import { transpose } from '../index';
export default transpose;
