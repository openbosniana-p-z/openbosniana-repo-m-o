import { init } from '../index';
export default init;
