import { and } from '../index';
export default and;
