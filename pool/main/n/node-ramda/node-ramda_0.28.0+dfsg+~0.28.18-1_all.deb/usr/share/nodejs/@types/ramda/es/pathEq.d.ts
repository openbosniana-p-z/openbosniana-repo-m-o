import { pathEq } from '../index';
export default pathEq;
