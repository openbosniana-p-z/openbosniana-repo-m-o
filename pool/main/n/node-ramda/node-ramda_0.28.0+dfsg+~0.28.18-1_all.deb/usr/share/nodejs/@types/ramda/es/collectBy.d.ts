import { collectBy } from '../index';
export default collectBy;
