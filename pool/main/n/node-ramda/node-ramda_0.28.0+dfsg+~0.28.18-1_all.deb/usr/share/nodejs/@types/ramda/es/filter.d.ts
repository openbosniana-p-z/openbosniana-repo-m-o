import { filter } from '../index';
export default filter;
