import { length } from '../index';
export default length;
