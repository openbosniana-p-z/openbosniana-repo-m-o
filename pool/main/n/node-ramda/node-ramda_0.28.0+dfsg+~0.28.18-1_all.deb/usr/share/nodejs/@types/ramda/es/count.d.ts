import { count } from '../index';
export default count;
