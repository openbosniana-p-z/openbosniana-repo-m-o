import { trim } from '../index';
export default trim;
