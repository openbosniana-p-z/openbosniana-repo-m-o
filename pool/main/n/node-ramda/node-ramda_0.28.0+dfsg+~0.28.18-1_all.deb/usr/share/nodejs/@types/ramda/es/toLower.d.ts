import { toLower } from '../index';
export default toLower;
