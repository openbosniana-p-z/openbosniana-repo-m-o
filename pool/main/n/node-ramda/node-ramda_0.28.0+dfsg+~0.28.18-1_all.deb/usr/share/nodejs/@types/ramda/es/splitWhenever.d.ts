import { splitWhenever } from '../index';
export default splitWhenever;
