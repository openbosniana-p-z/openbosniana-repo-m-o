import { is } from '../index';
export default is;
