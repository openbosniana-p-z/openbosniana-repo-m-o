import { bind } from '../index';
export default bind;
