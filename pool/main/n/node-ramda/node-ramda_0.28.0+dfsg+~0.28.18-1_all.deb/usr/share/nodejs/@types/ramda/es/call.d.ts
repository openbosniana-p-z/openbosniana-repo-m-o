import { call } from '../index';
export default call;
