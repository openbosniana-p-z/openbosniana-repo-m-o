import { hasPath } from '../index';
export default hasPath;
