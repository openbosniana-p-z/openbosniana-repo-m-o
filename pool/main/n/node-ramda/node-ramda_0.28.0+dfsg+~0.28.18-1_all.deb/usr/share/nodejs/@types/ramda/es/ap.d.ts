import { ap } from '../index';
export default ap;
