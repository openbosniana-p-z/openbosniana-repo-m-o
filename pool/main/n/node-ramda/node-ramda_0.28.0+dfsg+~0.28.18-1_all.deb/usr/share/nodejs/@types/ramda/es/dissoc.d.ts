import { dissoc } from '../index';
export default dissoc;
