import { reduceRight } from '../index';
export default reduceRight;
