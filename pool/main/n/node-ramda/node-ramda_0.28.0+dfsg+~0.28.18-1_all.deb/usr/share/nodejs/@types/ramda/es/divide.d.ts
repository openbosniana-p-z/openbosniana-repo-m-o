import { divide } from '../index';
export default divide;
