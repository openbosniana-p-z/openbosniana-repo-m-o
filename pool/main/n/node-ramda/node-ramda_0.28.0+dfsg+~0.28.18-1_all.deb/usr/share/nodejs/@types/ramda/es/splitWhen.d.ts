import { splitWhen } from '../index';
export default splitWhen;
