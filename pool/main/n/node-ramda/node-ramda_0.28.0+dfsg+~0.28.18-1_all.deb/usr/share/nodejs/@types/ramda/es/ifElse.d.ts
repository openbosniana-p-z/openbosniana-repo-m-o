import { ifElse } from '../index';
export default ifElse;
