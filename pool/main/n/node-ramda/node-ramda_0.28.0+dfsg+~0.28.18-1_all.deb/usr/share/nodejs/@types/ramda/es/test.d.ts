import { test } from '../index';
export default test;
