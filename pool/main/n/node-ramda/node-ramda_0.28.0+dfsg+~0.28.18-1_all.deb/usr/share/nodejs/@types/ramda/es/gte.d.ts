import { gte } from '../index';
export default gte;
