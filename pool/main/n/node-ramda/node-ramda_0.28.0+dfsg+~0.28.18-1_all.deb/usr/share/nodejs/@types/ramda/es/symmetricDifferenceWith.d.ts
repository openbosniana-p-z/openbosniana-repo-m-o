import { symmetricDifferenceWith } from '../index';
export default symmetricDifferenceWith;
