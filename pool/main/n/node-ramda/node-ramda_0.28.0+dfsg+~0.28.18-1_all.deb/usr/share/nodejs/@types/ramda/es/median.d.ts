import { median } from '../index';
export default median;
