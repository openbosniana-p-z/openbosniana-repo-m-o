import { modify } from '../index';
export default modify;
