import { pathSatisfies } from '../index';
export default pathSatisfies;
