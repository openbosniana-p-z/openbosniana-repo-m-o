import { lensIndex } from '../index';
export default lensIndex;
