import { into } from '../index';
export default into;
