import { multiply } from '../index';
export default multiply;
