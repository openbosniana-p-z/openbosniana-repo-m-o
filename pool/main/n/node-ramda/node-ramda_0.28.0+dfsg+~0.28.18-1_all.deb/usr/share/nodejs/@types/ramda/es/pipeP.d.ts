import { pipeP } from '../index';
export default pipeP;
