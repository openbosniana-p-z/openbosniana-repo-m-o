import { partialObject } from '../index';
export default partialObject;
