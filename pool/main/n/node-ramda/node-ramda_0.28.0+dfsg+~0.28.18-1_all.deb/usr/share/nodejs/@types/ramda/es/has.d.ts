import { has } from '../index';
export default has;
