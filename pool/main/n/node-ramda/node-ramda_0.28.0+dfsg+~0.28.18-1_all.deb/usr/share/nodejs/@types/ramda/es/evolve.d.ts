import { evolve } from '../index';
export default evolve;
