import { dropRepeats } from '../index';
export default dropRepeats;
