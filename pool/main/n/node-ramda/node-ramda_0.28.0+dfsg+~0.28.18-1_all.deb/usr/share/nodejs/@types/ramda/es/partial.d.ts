import { partial } from '../index';
export default partial;
