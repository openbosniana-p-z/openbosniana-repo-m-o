import { takeWhile } from '../index';
export default takeWhile;
