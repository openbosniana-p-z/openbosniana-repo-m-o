import { composeP } from '../index';
export default composeP;
