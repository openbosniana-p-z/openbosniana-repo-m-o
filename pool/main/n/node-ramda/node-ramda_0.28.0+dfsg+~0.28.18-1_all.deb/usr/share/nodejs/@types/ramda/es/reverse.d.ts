import { reverse } from '../index';
export default reverse;
