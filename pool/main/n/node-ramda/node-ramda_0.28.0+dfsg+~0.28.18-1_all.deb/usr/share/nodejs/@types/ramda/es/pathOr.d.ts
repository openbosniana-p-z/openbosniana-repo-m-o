import { pathOr } from '../index';
export default pathOr;
