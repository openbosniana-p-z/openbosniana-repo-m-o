import { empty } from '../index';
export default empty;
