import { when } from '../index';
export default when;
