import { indexBy } from '../index';
export default indexBy;
