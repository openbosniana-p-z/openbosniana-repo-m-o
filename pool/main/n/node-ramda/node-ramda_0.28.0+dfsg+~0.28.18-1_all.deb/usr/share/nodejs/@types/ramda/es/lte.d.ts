import { lte } from '../index';
export default lte;
