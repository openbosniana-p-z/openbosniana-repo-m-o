import { type } from '../index';
export default type;
