import { andThen } from '../index';
export default andThen;
