import { without } from '../index';
export default without;
