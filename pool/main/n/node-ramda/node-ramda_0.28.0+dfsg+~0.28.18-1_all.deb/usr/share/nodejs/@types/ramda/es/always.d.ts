import { always } from '../index';
export default always;
