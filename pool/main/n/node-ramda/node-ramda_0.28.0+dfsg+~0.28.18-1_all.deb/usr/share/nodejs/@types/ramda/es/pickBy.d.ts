import { pickBy } from '../index';
export default pickBy;
