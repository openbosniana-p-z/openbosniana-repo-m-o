import { zipWith } from '../index';
export default zipWith;
