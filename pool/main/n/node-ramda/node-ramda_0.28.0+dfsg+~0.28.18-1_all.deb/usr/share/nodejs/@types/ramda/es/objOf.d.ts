import { objOf } from '../index';
export default objOf;
