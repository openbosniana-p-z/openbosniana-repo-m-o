import { partialRight } from '../index';
export default partialRight;
