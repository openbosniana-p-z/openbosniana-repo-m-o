import { hasIn } from '../index';
export default hasIn;
