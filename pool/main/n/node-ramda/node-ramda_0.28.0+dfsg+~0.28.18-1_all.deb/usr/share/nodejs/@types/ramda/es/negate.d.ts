import { negate } from '../index';
export default negate;
