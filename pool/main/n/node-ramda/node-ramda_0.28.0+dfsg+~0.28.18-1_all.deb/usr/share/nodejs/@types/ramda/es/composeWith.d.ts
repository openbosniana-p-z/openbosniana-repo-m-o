import { composeWith } from '../index';
export default composeWith;
