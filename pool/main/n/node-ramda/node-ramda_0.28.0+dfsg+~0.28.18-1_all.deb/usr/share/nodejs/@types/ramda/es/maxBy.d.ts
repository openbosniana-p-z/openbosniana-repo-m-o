import { maxBy } from '../index';
export default maxBy;
