import { splitAt } from '../index';
export default splitAt;
