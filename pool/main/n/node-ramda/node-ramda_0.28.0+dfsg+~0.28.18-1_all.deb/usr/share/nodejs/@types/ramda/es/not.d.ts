import { not } from '../index';
export default not;
