import { anyPass } from '../index';
export default anyPass;
