import { once } from '../index';
export default once;
