import { mergeLeft } from '../index';
export default mergeLeft;
