import { lens } from '../index';
export default lens;
