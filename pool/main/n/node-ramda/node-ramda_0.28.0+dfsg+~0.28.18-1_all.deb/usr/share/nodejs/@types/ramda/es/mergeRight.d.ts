import { mergeRight } from '../index';
export default mergeRight;
