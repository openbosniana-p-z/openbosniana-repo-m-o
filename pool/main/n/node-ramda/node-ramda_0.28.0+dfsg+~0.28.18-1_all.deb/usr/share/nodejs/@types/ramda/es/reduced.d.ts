import { reduced } from '../index';
export default reduced;
