import { lensPath } from '../index';
export default lensPath;
