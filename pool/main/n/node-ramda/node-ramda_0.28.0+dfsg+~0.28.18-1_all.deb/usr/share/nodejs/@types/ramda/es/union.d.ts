import { union } from '../index';
export default union;
