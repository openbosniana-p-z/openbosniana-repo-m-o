import { path } from '../index';
export default path;
