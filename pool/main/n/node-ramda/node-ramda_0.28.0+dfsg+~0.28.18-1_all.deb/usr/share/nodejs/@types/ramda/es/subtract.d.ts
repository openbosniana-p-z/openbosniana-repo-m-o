import { subtract } from '../index';
export default subtract;
