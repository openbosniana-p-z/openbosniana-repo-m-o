import { move } from '../index';
export default move;
