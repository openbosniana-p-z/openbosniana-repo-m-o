import { tryCatch } from '../index';
export default tryCatch;
