import { min } from '../index';
export default min;
