import { zipObj } from '../index';
export default zipObj;
