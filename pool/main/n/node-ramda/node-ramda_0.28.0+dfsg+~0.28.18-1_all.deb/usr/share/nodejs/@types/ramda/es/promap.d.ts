import { promap } from '../index';
export default promap;
