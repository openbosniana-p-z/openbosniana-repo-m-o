import { mergeAll } from '../index';
export default mergeAll;
