import { partition } from '../index';
export default partition;
