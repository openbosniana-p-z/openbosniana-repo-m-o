import { tap } from '../index';
export default tap;
