import { dropRepeatsWith } from '../index';
export default dropRepeatsWith;
