import { applySpec } from '../index';
export default applySpec;
