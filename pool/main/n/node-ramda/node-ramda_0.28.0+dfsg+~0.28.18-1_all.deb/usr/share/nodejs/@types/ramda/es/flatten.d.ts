import { flatten } from '../index';
export default flatten;
