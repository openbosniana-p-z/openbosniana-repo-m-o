import { construct } from '../index';
export default construct;
