import { toPairs } from '../index';
export default toPairs;
