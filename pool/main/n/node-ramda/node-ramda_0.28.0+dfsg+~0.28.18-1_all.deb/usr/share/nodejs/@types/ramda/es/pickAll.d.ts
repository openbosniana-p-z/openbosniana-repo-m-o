import { pickAll } from '../index';
export default pickAll;
