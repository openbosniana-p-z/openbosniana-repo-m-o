import { chain } from '../index';
export default chain;
