import { reduceWhile } from '../index';
export default reduceWhile;
