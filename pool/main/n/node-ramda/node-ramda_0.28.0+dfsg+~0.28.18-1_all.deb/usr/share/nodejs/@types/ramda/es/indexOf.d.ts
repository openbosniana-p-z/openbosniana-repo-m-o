import { indexOf } from '../index';
export default indexOf;
