import { minBy } from '../index';
export default minBy;
