import { flip } from '../index';
export default flip;
