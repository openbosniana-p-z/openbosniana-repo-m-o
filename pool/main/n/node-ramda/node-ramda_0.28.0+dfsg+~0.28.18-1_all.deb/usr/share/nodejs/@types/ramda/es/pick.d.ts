import { pick } from '../index';
export default pick;
