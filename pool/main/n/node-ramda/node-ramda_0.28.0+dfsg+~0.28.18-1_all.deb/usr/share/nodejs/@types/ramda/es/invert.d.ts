import { invert } from '../index';
export default invert;
