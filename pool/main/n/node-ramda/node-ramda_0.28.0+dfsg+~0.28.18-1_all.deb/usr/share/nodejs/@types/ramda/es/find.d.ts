import { find } from '../index';
export default find;
