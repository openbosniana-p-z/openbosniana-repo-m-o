import { on } from '../index';
export default on;
