import { pipeK } from '../index';
export default pipeK;
