import { adjust } from '../index';
export default adjust;
