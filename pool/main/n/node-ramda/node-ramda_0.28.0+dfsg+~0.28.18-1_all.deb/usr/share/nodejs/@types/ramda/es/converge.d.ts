import { converge } from '../index';
export default converge;
