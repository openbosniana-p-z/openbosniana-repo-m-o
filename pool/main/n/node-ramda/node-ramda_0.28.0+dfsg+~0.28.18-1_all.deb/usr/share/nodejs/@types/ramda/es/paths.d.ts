import { paths } from '../index';
export default paths;
