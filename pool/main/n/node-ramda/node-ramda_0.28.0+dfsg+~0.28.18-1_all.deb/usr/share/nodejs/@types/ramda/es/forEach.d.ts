import { forEach } from '../index';
export default forEach;
