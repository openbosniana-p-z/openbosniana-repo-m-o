import { scan } from '../index';
export default scan;
