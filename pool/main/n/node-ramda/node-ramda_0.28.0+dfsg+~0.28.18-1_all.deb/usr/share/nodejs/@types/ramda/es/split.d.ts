import { split } from '../index';
export default split;
