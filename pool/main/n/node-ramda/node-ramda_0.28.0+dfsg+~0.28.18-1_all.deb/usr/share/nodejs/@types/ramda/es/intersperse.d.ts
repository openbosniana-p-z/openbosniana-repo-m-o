import { intersperse } from '../index';
export default intersperse;
