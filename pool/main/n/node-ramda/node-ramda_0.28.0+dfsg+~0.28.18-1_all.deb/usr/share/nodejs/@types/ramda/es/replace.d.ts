import { replace } from '../index';
export default replace;
