import { insert } from '../index';
export default insert;
