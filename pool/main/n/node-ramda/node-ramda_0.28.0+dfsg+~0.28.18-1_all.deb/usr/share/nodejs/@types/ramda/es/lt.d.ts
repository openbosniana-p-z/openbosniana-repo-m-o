import { lt } from '../index';
export default lt;
