import { toString } from '../index';
export default toString;
