import { assocPath } from '../index';
export default assocPath;
