import { assoc } from '../index';
export default assoc;
