import { startsWith } from '../index';
export default startsWith;
