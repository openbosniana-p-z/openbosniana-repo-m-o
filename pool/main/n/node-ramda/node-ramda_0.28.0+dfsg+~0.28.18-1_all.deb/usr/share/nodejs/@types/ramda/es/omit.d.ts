import { omit } from '../index';
export default omit;
