import { dropLastWhile } from '../index';
export default dropLastWhile;
