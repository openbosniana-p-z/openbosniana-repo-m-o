import { mapObjIndexed } from '../index';
export default mapObjIndexed;
