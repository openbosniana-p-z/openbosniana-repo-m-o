import { lift } from '../index';
export default lift;
