import { curry } from '../index';
export default curry;
