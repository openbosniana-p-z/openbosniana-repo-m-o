import { prop } from '../index';
export default prop;
