import { inc } from '../index';
export default inc;
