import { pipeWith } from '../index';
export default pipeWith;
