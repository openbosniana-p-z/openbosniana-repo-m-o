import { dec } from '../index';
export default dec;
