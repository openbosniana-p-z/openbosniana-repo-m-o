import { binary } from '../index';
export default binary;
