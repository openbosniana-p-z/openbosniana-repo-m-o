import { includes } from '../index';
export default includes;
