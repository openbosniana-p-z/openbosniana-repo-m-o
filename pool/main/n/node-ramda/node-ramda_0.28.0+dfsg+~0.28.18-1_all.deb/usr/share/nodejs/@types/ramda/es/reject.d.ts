import { reject } from '../index';
export default reject;
