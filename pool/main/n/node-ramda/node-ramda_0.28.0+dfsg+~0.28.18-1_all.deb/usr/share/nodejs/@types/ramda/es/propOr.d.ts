import { propOr } from '../index';
export default propOr;
