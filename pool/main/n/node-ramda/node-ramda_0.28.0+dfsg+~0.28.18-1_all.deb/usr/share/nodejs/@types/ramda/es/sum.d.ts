import { sum } from '../index';
export default sum;
