import { nthArg } from '../index';
export default nthArg;
