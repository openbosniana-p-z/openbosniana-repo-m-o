import { none } from '../index';
export default none;
