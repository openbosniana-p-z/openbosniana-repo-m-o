import { o } from '../index';
export default o;
