import { findIndex } from '../index';
export default findIndex;
