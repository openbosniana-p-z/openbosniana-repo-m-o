import { set } from '../index';
export default set;
