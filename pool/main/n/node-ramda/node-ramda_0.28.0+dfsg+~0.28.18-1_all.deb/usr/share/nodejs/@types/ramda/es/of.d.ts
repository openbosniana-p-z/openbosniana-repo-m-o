import { of } from '../index';
export default of;
