import { apply } from '../index';
export default apply;
