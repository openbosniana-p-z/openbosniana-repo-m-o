import { update } from '../index';
export default update;
