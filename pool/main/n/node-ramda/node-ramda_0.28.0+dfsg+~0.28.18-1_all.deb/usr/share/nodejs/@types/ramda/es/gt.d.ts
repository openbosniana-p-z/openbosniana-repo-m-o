import { gt } from '../index';
export default gt;
