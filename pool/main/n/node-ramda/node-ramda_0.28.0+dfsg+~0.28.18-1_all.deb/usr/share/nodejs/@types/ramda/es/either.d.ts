import { either } from '../index';
export default either;
