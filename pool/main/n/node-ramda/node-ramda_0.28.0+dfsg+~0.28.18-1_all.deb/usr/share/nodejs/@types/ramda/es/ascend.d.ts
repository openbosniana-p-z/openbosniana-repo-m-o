import { ascend } from '../index';
export default ascend;
