import { fromPairs } from '../index';
export default fromPairs;
