import { take } from '../index';
export default take;
