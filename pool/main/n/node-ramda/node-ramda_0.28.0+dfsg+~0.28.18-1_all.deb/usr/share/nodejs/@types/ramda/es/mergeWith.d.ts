import { mergeWith } from '../index';
export default mergeWith;
