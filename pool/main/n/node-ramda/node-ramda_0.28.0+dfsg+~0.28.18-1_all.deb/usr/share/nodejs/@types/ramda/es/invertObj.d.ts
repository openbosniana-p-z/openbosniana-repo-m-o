import { invertObj } from '../index';
export default invertObj;
