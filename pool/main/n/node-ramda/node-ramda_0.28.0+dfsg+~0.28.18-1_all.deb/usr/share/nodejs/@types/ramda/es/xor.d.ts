import { xor } from '../index';
export default xor;
