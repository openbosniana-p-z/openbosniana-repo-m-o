import { add } from '../index';
export default add;
