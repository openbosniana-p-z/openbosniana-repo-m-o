import { valuesIn } from '../index';
export default valuesIn;
