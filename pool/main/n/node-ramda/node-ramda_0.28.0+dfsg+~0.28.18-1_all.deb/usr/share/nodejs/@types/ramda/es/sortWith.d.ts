import { sortWith } from '../index';
export default sortWith;
