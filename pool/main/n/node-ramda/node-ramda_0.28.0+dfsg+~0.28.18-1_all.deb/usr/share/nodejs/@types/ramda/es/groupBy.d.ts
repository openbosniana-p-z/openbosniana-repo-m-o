import { groupBy } from '../index';
export default groupBy;
