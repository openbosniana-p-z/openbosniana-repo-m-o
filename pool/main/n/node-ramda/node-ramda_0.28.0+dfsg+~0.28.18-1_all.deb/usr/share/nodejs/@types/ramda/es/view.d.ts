import { view } from '../index';
export default view;
