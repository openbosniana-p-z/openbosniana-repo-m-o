import { T } from '../index';
export default T;
