import { mean } from '../index';
export default mean;
