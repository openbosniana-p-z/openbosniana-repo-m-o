import { aperture } from '../index';
export default aperture;
