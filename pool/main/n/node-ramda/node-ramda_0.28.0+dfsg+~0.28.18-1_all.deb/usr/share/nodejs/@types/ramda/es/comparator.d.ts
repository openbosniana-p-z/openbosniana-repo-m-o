import { comparator } from '../index';
export default comparator;
