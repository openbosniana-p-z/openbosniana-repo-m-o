import { endsWith } from '../index';
export default endsWith;
