import { compose } from '../index';
export default compose;
