import { mergeDeepLeft } from '../index';
export default mergeDeepLeft;
