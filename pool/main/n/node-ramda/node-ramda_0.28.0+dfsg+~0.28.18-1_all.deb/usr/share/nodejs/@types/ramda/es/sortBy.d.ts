import { sortBy } from '../index';
export default sortBy;
