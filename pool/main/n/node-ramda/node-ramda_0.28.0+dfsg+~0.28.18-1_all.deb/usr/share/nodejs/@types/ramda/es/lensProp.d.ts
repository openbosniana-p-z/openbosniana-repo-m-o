import { lensProp } from '../index';
export default lensProp;
