import { uniq } from '../index';
export default uniq;
