import { whereEq } from '../index';
export default whereEq;
