import { takeLast } from '../index';
export default takeLast;
