import { clone } from '../index';
export default clone;
