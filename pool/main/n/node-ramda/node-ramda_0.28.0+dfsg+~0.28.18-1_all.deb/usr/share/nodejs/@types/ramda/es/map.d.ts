import { map } from '../index';
export default map;
