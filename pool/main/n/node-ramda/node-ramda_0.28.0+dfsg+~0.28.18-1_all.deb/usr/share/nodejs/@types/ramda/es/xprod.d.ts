import { xprod } from '../index';
export default xprod;
