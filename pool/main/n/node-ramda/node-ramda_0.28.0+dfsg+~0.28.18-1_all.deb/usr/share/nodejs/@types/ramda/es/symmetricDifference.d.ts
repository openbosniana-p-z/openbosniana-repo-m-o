import { symmetricDifference } from '../index';
export default symmetricDifference;
