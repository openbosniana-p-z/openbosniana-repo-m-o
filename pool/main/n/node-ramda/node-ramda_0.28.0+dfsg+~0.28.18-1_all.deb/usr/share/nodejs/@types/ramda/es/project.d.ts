import { project } from '../index';
export default project;
