import { findLastIndex } from '../index';
export default findLastIndex;
