import { equals } from '../index';
export default equals;
