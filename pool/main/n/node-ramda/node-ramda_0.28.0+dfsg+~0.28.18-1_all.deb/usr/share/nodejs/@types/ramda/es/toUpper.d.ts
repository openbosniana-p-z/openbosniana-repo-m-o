import { toUpper } from '../index';
export default toUpper;
