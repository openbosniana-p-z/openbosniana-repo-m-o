import { descend } from '../index';
export default descend;
