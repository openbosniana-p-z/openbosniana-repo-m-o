import { intersection } from '../index';
export default intersection;
