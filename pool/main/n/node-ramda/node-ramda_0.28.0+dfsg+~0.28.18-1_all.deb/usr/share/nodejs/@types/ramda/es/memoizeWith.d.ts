import { memoizeWith } from '../index';
export default memoizeWith;
