import { allPass } from '../index';
export default allPass;
