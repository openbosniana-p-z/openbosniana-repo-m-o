import { head } from '../index';
export default head;
