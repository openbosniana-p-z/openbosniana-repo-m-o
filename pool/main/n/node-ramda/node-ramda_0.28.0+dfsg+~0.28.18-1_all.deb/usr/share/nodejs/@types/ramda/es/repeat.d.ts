import { repeat } from '../index';
export default repeat;
