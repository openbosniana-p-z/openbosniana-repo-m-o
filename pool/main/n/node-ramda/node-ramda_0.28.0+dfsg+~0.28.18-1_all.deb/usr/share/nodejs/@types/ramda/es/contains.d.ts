import { contains } from '../index';
export default contains;
