import { times } from '../index';
export default times;
