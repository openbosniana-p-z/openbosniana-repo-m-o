import { drop } from '../index';
export default drop;
