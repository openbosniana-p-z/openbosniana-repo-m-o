'use strict';

var bufferEqual = require('buffer-equal');

console.dir(bufferEqual(
	Buffer.from([253, 254, 255]),
	Buffer.from([253, 254, 255])
));
console.dir(bufferEqual(
	Buffer.from('abc'),
	Buffer.from('abcd')
));
console.dir(bufferEqual(
	Buffer.from('abc'),
	'abc'
));
