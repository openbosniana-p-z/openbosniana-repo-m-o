README.txt .................... this file
async ......................... demo aysnchronous HTTP get-url requests
client ........................ demo for TCP networking client
env.cgi ....................... httpd server CGI file to show environment
finger ........................ demo for using TCP finger port
form.cgi ...................... demo for HTML form CGI
form.html ..................... used by form.cgi
httpd-conf.lsp ................ configuration file for newLISP httpd mode
newLISP-Excel-Import.xls ...... demo how to import newLISP in MS Excel
observer ...................... demo for forking processes
opengl-demo-ffi.lsp ........... OpenGL demo for extended FFI
opengl-demo.lsp ............... OpenGL demo for simple FFI
prodcons.lsp .................. demo for producer/consumer messageing
query ......................... demo for spawning parallel processes
scan .......................... TCP port scanner
server ........................ demo TCP server, run before TCP client
sniff ......................... TCP port sniffer
tcltk.lsp ..................... Tcl/Tk graphics demo
udp-client.lsp ................ demo for UDP client
udp-server.lsp ................ demo for UDP server
upload.cgi .................... CGI for uploading a file (works on Apache and newLISP httpd)
upload.html ................... used for upload.cgi
win32demo.lsp ................. demo for importing Win32 SDK GUI functions
xmlrpc.cgi .................... demo for xmlrpc CGI

