// Type definitions for hash-sum 1.0
// Project: https://github.com/bevacqua/hash-sum
// Definitions by: Daniel Rosenwasser <https://github.com/DanielRosenwasser>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

export = hash_sum;

declare function hash_sum(value: any): string;
