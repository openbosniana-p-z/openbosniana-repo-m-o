// +build !windows

package main

const homeEnv = "HOME"
