"use strict";

module.exports = require("../lib/private/decimal-adjust")("floor");
