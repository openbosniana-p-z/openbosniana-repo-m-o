"use strict";

module.exports = require("./is-implemented")() ? globalThis : require("./implementation");
