/** List of binary file extensions */
const list = [
	'dds',
	'eot',
	'gif',
	'ico',
	'jar',
	'jpeg',
	'jpg',
	'pdf',
	'png',
	'swf',
	'tga',
	'ttf',
	'zip',
]
export default list
