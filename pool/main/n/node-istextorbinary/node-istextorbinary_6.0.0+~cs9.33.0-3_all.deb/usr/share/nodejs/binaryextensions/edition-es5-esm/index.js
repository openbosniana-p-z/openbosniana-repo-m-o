/** List of binary file extensions */
var list = [
    'dds',
    'eot',
    'gif',
    'ico',
    'jar',
    'jpeg',
    'jpg',
    'pdf',
    'png',
    'swf',
    'tga',
    'ttf',
    'zip',
];
export default list;
