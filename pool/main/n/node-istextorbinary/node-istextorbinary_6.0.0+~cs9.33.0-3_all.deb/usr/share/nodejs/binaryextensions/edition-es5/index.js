"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/** List of binary file extensions */
var list = [
    'dds',
    'eot',
    'gif',
    'ico',
    'jar',
    'jpeg',
    'jpg',
    'pdf',
    'png',
    'swf',
    'tga',
    'ttf',
    'zip',
];
exports.default = list;
