// Type definitions for is-dotfile 2.0
// Project: https://github.com/jonschlinkert/is-dotfile
// Definitions by: BendingBender <https://github.com/BendingBender>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

export = isDotfile;

declare function isDotfile(path: string): boolean;
