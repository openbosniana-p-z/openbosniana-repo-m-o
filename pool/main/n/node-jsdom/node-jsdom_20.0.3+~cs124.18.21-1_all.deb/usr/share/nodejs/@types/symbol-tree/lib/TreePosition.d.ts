// same as DOM DOCUMENT_POSITION_
export const DISCONNECTED: 1;
export const PRECEDING: 2;
export const FOLLOWING: 4;
export const CONTAINS: 8;
export const CONTAINED_BY: 16;
