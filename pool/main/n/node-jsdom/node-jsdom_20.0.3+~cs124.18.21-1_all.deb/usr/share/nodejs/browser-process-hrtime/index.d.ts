declare module "browser-process-hrtime" {
  function hrtime(time?: [number, number]): [number, number];
  export = hrtime;
}
