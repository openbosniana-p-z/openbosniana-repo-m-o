// Type definitions for symbol-tree 3.2
// Project: https://github.com/jsdom/js-symbol-tree#symbol-tree
// Definitions by: ExE Boss <https://github.com/ExE-Boss>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

import SymbolTree = require('./lib/SymbolTree');
export = SymbolTree;
