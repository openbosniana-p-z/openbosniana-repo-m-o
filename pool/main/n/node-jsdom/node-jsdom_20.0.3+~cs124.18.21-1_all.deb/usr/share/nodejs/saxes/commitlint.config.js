"use strict";

module.exports = {
  extends: ["@commitlint/config-angular"],
};
