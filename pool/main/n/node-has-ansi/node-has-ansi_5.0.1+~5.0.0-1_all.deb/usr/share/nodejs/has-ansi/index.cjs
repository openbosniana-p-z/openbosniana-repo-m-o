const e=require("ansi-regex")({onlyFirst:!0});module.exports=function(r){return e.test(r)};
