var resolve = require('browser-resolve');
resolve('fs', null, function(err, path) {
    console.log(path);
});
