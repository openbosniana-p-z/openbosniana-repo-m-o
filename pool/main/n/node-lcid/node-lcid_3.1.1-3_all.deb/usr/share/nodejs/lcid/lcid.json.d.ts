declare const lcidCodes: {readonly [localeId: string]: string};

export = lcidCodes;
