export declare function parseXML(svg: Document | string | SVGElement): SVGElement;
