import { VectorArray } from '../../core/vector';
export default function smoothBezier(points: VectorArray[], smooth?: number, isLoop?: boolean, constraint?: VectorArray[]): any[][];
