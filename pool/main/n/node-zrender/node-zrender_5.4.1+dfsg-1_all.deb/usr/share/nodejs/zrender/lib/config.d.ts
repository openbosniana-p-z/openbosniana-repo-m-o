export declare const debugMode = 0;
export declare const devicePixelRatio: number;
export declare const DARK_MODE_THRESHOLD = 0.4;
export declare const DARK_LABEL_COLOR = "#333";
export declare const LIGHT_LABEL_COLOR = "#ccc";
export declare const LIGHTER_LABEL_COLOR = "#eee";
