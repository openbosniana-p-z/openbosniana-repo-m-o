import {registerPainter} from '../zrender';
import Painter from './Painter';

registerPainter('canvas', Painter);