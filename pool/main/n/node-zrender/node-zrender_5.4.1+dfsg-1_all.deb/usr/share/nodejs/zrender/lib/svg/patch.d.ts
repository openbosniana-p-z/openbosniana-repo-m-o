import { SVGVNode } from './core';
export declare function updateAttrs(oldVnode: SVGVNode, vnode: SVGVNode): void;
export default function patch(oldVnode: SVGVNode, vnode: SVGVNode): SVGVNode;
