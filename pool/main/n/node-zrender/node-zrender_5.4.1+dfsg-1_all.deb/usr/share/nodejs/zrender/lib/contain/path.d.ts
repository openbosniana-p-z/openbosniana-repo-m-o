import PathProxy from '../core/PathProxy';
export declare function contain(pathProxy: PathProxy, x: number, y: number): boolean;
export declare function containStroke(pathProxy: PathProxy, lineWidth: number, x: number, y: number): boolean;
