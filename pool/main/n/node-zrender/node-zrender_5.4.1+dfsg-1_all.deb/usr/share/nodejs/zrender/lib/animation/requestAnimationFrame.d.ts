declare type RequestAnimationFrameType = typeof window.requestAnimationFrame;
declare let requestAnimationFrame: RequestAnimationFrameType;
export default requestAnimationFrame;
