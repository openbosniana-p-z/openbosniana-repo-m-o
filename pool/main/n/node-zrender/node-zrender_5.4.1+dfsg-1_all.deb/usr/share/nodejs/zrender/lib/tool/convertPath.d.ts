import PathProxy from '../core/PathProxy';
export declare function pathToBezierCurves(path: PathProxy): number[][];
export declare function pathToPolygons(path: PathProxy, scale?: number): number[][];
