export declare function buildTransformer(src: number[], dest: number[]): (out: number[], srcPointX: number, srcPointY: number) => void;
