export declare function createCubicEasingFunc(cubicEasingStr: string): (p: number) => number;
