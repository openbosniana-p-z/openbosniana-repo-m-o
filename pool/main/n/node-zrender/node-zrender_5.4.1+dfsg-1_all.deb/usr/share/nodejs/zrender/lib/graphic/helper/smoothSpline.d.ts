import { VectorArray } from '../../core/vector';
export default function smoothSpline(points: VectorArray[], isLoop?: boolean): VectorArray[];
