import {registerPainter} from '../zrender';
import Painter from './Painter';

registerPainter('svg-legacy', Painter);