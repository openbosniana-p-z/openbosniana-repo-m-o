export declare function normalizeRadian(angle: number): number;
