import Path from '../graphic/Path';
export declare function clone(path: Path, count: number): Path<import("../graphic/Path").PathProps>[];
export declare function split(path: Path, count: number): Path<import("../graphic/Path").PathProps>[];
