import PathProxy from '../core/PathProxy';
import { MatrixArray } from '../core/matrix';
export default function transformPath(path: PathProxy, m: MatrixArray): void;
