// Bit masks to check which parts of element needs to be updated.
export const REDRAW_BIT = 1;
export const STYLE_CHANGED_BIT = 2;
export const SHAPE_CHANGED_BIT = 4;
