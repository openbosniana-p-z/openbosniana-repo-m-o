import { VectorArray } from '../core/vector';
export declare function contain(points: VectorArray[], x: number, y: number): boolean;
