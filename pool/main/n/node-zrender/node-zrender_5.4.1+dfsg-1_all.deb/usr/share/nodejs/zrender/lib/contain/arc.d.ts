export declare function containStroke(cx: number, cy: number, r: number, startAngle: number, endAngle: number, anticlockwise: boolean, lineWidth: number, x: number, y: number): boolean;
