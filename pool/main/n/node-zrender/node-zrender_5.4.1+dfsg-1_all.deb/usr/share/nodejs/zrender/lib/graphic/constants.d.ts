export declare const REDRAW_BIT = 1;
export declare const STYLE_CHANGED_BIT = 2;
export declare const SHAPE_CHANGED_BIT = 4;
