var Applause = require('./src/applause');

// Expose
module.exports = Applause;
