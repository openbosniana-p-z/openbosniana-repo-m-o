export * from "./dist/index.d";
import { makeOptionalRequire } from "./dist/index.d";

// @ts-ignore
export = makeOptionalRequire;
