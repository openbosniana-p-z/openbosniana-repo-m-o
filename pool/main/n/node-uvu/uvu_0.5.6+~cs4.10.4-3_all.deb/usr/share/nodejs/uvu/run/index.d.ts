import type { Suite } from 'uvu/parse';
export function run(suites: Suite[], options?: { bail: boolean }): Promise<void>;
