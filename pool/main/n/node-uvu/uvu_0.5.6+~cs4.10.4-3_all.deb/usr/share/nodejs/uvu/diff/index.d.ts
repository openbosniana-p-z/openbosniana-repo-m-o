export function chars(input: any, expects: any): string;
export function lines(input: any, expects: any, linenum?: number): string;
export function direct(input: any, expects: any, lenA?: number, lenB?: number): string;
export function compare(input: any, expects: any): string;
export function arrays(input: any, expects: any): string;
