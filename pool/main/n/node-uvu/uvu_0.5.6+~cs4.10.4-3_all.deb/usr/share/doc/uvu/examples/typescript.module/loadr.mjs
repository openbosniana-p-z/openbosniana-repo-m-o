// NOTE: used for "test:alt" script only
// @see https://github.com/lukeed/loadr
export const loaders = ['tsm'];
