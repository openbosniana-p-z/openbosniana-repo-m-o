export const sum = (a, b) => a + b;
export const div = (a, b) => a / b;
export const mod = (a, b) => a % b;
