export function sum(a: number, b: number): number {
	return a + b;
}

export function div(a: number, b: number): number {
	return a / b;
}

export function mod(a: number, b: number): number {
	return a % b;
}
