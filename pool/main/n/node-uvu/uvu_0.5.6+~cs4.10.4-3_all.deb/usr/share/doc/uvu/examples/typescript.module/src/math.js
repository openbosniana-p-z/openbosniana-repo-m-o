/**
 * @param {number} a
 * @param {number} b
 */
export const sum = (a, b) => a + b;

/**
 * @param {number} a
 * @param {number} b
 */
export const div = (a, b) => a / b;

/**
 * @param {number} a
 * @param {number} b
 */
export const mod = (a, b) => a % b;
