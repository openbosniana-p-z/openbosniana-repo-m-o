import * as math from './math.js';
import * as utils from './utils.js';

window.__MATH__ = math;
window.__UTILS__ = utils;
