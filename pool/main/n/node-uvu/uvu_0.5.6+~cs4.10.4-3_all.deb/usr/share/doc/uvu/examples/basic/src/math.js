exports.sum = (a, b) => a + b;
exports.div = (a, b) => a / b;
exports.mod = (a, b) => a % b;
