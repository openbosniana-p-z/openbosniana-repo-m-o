declare function isMergeableObject(value: any): boolean;

export default isMergeableObject;
