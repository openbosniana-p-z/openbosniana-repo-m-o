# regenerator-preset

Babel preset for easy use of [regenerator-transform](https://github.com/facebook/regenerator/tree/master/packages/regenerator-transform).
