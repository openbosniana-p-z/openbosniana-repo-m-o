
var B = require('./b');
var App = require('./c');

// console.log(App.metadata)
var app = new App();
