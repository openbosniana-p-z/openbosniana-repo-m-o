import { Observable } from './src/Observable.js';

export default Observable;
export { Observable };
export * from './src/extras.js';
