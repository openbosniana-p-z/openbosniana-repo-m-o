module.exports = require('./lib/Observable.js').Observable;
