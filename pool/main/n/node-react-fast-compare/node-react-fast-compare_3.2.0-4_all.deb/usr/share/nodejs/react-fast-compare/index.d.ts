declare function isEqual<A = any, B = any>(a: A, b: B): boolean;
export = isEqual;
