var subarg = require('node-subarg');
var argv = subarg(process.argv.slice(2));
console.log(argv);
