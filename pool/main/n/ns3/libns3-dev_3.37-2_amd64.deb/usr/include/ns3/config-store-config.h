#ifndef NS3_CONFIG_STORE_CONFIG_H
#define NS3_CONFIG_STORE_CONFIG_H

/* #undef PYTHONDIR */
/* #undef PYTHONARCHDIR */
/* #undef HAVE_PYEMBED */
/* #undef HAVE_PYEXT */
/* #undef HAVE_PYTHON_H */

#endif // NS3_CONFIG_STORE_CONFIG_H
