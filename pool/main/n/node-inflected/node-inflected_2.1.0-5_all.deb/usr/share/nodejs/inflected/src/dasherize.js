export default function dasherize(underscoredWord) {
  return underscoredWord.replace(/_/g, "-");
}
