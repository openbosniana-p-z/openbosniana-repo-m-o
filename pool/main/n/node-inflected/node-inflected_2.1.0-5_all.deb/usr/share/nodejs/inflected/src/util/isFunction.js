const toString = Object.prototype.toString;

export default function isFunc(obj) {
  return toString.call(obj) === "[object Function]";
}
