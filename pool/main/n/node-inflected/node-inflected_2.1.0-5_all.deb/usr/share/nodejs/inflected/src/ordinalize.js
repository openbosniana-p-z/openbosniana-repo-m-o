import ordinal from "./ordinal";

export default function ordinalize(number) {
  return `${number}${ordinal(number)}`;
}
