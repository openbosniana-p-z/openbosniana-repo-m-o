Contributed levels:

Maps  Filename             Difficulty Contributors
----- -------------------- ---------- ------------------------------------
  20  WOLF.COOP            medium     Jalal A. Elhusseini
  20  DRAGON.COOP          hard       Jalal A. Elhusseini
  20  RAVENS CURSE.COOP    medium     Raven
  20  ONE4ALL.COOP         hard       Nenad Jovanovic (two players cooperate or fail)
  20  EIKE.COOP            hard       Eike Klattenhoff
  20  EIKE.DUEL            -          Eike Klattenhoff
  20  LABYRINTHE.COOP      medium     Lemberniot
   2  LABYRINTHE.DUEL      -          Lemberniot
  20  ALIS.COOP            hard       Redkin Egor
  20  ALISPLUS.COOP        medium     Redkin Egor
  15  SPIRITWORLD.COOP     medium     Tim Schaefer
  15  DEADLYSPIRIT.DUEL    -          Tim Schaefer
   7  INSANIAC.COOP        extra hard Daniel Whigham (this one is a real challenge)
   8  ALLSFAIR.DUEL        -          Daniel Whigham
   4  BEAMTEAM.DUEL        -          M.Diener & B.Stryi (aka BeaM-Team)
   3  DULIO.DUEL           -          Dario Dulic

  10  LA_GINECAL.COOP      medium     Sean Austin
  13  KILLER.DUEL          -          Thomas Buch
  13  KILLER.COOP          medium     Thomas Buch
  20  BUCHI.DUEL           -          Thomas Buch
  20  BUCHI.COOP           easy       Thomas Buch
  11  BEAS.DUEL            -          Tischler Lukas
   9  STEPHANE.DUEL        -          St�phane Galtier & Karoline

Original levels:

Maps  Filename             Difficulty
----- -------------------- ----------
  20  ORIGINAL.COOP        hard
  20  GAUNTLET.COOP        hard
  20  DUNGEON.COOP         hard
  10  EASY.COOP            easy
  20  ORIGINAL.DUEL        -
   5  HUNT.DUEL            -           Collection of levels similar to
                                       "ghost hunt" level of original.duel set
                                       great fun for 4 players

Total: 18 levelsets, 262 levels.
