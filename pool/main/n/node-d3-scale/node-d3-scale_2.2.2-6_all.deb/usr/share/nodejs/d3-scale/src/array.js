var array = Array.prototype;

export var map = array.map;
export var slice = array.slice;
