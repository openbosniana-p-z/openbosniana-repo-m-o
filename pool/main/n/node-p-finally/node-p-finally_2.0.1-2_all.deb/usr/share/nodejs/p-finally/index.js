'use strict';

module.exports = async (
	promise,
	onFinally = (() => {})
) => {
	let value;
	try {
		value = await promise;
	} catch (error) {
		await onFinally();
		throw error;
	}

	await onFinally();
	return value;
};
