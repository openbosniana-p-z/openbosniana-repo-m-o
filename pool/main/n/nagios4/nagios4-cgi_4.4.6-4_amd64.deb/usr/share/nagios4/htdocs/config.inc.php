<?php
//


$cfg['cgi_config_file']='/etc/nagios4/cgi.cfg';  // location of the CGI config file

$cfg['cgi_base_url']='/cgi-bin/nagios4';


// FILE LOCATION DEFAULTS
$cfg['main_config_file']='/etc/nagios4/nagios.cfg';  // default location of the main Nagios config file
$cfg['status_file']='/var/lib/nagios4/status.dat'; // default location of Nagios status file
$cfg['state_retention_file']='/var/lib/nagios4/retention.dat'; // default location of Nagios retention file



// utilities
require_once(dirname(__FILE__).'/includes/utils.inc.php');

?>
