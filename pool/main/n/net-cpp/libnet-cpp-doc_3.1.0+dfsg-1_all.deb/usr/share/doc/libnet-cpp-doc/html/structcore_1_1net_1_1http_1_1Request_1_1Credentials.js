var structcore_1_1net_1_1http_1_1Request_1_1Credentials =
[
    [ "password", "structcore_1_1net_1_1http_1_1Request_1_1Credentials.html#a58ae06caee358a50c4ef630f6e7aa197", null ],
    [ "username", "structcore_1_1net_1_1http_1_1Request_1_1Credentials.html#a5c9769f2adbebc4b5f7c87a7e1af4b0c", null ]
];