var classcore_1_1net_1_1Error =
[
    [ "Error", "classcore_1_1net_1_1Error.html#a7bb0264a41d27994daeef372579433c2", null ],
    [ "~Error", "classcore_1_1net_1_1Error.html#a50b07d3e8360adadc65b3731b331d642", null ]
];