var namespacecore =
[
    [ "net", "namespacecore_1_1net.html", "namespacecore_1_1net" ],
    [ "Location", "structcore_1_1Location.html", "structcore_1_1Location" ],
    [ "from_here", "namespacecore.html#a2048a6f036feaab92de323d6a05c1f77", null ]
];