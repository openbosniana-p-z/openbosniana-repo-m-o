var structcore_1_1net_1_1Uri =
[
    [ "Host", "structcore_1_1net_1_1Uri.html#ad9652182672898c9dc62754f514034b4", null ],
    [ "Path", "structcore_1_1net_1_1Uri.html#a9a14aec84d5de0598d10e81eb0f96e1d", null ],
    [ "QueryParameters", "structcore_1_1net_1_1Uri.html#a7063159d93e4cc4ec81d1d03ba8591b2", null ],
    [ "host", "structcore_1_1net_1_1Uri.html#a065204bb9d832bb3ab91f2cb9cbc5b86", null ],
    [ "path", "structcore_1_1net_1_1Uri.html#aacedb77ff2a589f61600b407a98cb9d2", null ],
    [ "query_parameters", "structcore_1_1net_1_1Uri.html#a1aaf6c2d12573e17b63009b16e7839a7", null ]
];