var uri_8h =
[
    [ "core::net::Uri", "structcore_1_1net_1_1Uri.html", "structcore_1_1net_1_1Uri" ],
    [ "make_uri", "uri_8h.html#a7657bc69238652b5b094c081ef66844a", null ]
];