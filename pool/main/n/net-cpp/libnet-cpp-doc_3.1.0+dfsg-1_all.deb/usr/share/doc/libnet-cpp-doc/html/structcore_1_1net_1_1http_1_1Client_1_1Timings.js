var structcore_1_1net_1_1http_1_1Client_1_1Timings =
[
    [ "Statistics", "structcore_1_1net_1_1http_1_1Client_1_1Timings_1_1Statistics.html", "structcore_1_1net_1_1http_1_1Client_1_1Timings_1_1Statistics" ],
    [ "Seconds", "structcore_1_1net_1_1http_1_1Client_1_1Timings.html#ab794169c39fdec2de688b95d7aced71f", null ],
    [ "app_connect", "structcore_1_1net_1_1http_1_1Client_1_1Timings.html#ad7fcfc944812d24bc1d4b118f217272b", null ],
    [ "connect", "structcore_1_1net_1_1http_1_1Client_1_1Timings.html#aee3be3cde77f34cbd0dea251dc8abb6d", null ],
    [ "name_look_up", "structcore_1_1net_1_1http_1_1Client_1_1Timings.html#a73e6485e12cb518d33207a00ea3ca34c", null ],
    [ "pre_transfer", "structcore_1_1net_1_1http_1_1Client_1_1Timings.html#a010b5f81bf66bb8a048b88b8509a309b", null ],
    [ "start_transfer", "structcore_1_1net_1_1http_1_1Client_1_1Timings.html#a59555302569ee836e30eea33fc85f7db", null ],
    [ "total", "structcore_1_1net_1_1http_1_1Client_1_1Timings.html#ad21bc9bdf6dfa9b9cf57b9eeb4e5b3eb", null ]
];