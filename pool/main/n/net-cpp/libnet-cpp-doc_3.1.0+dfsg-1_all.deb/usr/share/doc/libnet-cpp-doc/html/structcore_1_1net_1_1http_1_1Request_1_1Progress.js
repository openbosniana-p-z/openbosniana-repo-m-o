var structcore_1_1net_1_1http_1_1Request_1_1Progress =
[
    [ "Next", "structcore_1_1net_1_1http_1_1Request_1_1Progress.html#aaed152af58179a2c20185199933ea903", [
      [ "continue_operation", "structcore_1_1net_1_1http_1_1Request_1_1Progress.html#aaed152af58179a2c20185199933ea903a2e57c690ead6dd3554e3f4a5c0b1e249", null ],
      [ "abort_operation", "structcore_1_1net_1_1http_1_1Request_1_1Progress.html#aaed152af58179a2c20185199933ea903a5773b76a3416cb76ea4b69b87eeeec6d", null ]
    ] ],
    [ "current", "structcore_1_1net_1_1http_1_1Request_1_1Progress.html#a103441177d82d2cef628e3a04cdad4d0", null ],
    [ "download", "structcore_1_1net_1_1http_1_1Request_1_1Progress.html#a1dc419684f85c85ea0f80ba691e0e9d2", null ],
    [ "total", "structcore_1_1net_1_1http_1_1Request_1_1Progress.html#a7c0b1d3b2d9a70dfe2eca3400d8c7b44", null ],
    [ "upload", "structcore_1_1net_1_1http_1_1Request_1_1Progress.html#a213367e33a81d96d650b72cd5b8e42a4", null ]
];