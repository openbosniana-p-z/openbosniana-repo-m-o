var structcore_1_1net_1_1http_1_1Client_1_1Timings_1_1Statistics =
[
    [ "max", "structcore_1_1net_1_1http_1_1Client_1_1Timings_1_1Statistics.html#a1d79387b04f06231748c707e58100651", null ],
    [ "mean", "structcore_1_1net_1_1http_1_1Client_1_1Timings_1_1Statistics.html#a7f685bdf6fd2024705cafc2263cb0e39", null ],
    [ "min", "structcore_1_1net_1_1http_1_1Client_1_1Timings_1_1Statistics.html#aa9c2cbf9ae1c3d6a873f43eb923f8f15", null ],
    [ "variance", "structcore_1_1net_1_1http_1_1Client_1_1Timings_1_1Statistics.html#aeaad355a7b133a7428808d3362b1ebdd", null ]
];