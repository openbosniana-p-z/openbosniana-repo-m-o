var structcore_1_1net_1_1http_1_1Request_1_1Configuration =
[
    [ "authentication_handler", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#aad8ba6b79c51bf224d7441946b8b519d", null ],
    [ "for_http", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#a561db69a2d3e9c07536a786d801fae82", null ],
    [ "for_proxy", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#a573d1450a5bbf1576573f35781ad76b4", null ],
    [ "header", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#a350bae12554841df9ddb3768f8874068", null ],
    [ "on_error", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#a7edf589266095704b1b46678d9768587", null ],
    [ "on_progress", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#a0c65f30229e3a43563c789f67517ff80", null ],
    [ "on_response", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#a9483a26288e1fad42a7e3faa22e6a0aa", null ],
    [ "ssl", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#a93bc5c267577bb7a4a92fe5ee9c9ec85", null ],
    [ "uri", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#ade992e874d27f48ccd007820ea62ffa9", null ],
    [ "verify_host", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#a268c999e7d8708c1433044db2587b64d", null ],
    [ "verify_peer", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html#a757ef12a0f6e4cd7a13f59e684cd0070", null ]
];