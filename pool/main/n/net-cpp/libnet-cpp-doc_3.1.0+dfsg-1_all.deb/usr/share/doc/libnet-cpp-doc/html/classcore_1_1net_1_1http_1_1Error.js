var classcore_1_1net_1_1http_1_1Error =
[
    [ "Error", "classcore_1_1net_1_1http_1_1Error.html#a9957eb66d4e3d168b5c4f37c00423b12", null ],
    [ "~Error", "classcore_1_1net_1_1http_1_1Error.html#a971b31e0793ed919b61417fbd0bc4c87", null ]
];