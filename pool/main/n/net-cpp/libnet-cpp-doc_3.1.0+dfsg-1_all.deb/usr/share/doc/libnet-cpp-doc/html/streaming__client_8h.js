var streaming__client_8h =
[
    [ "core::net::http::StreamingClient", "classcore_1_1net_1_1http_1_1StreamingClient.html", "classcore_1_1net_1_1http_1_1StreamingClient" ],
    [ "make_streaming_client", "streaming__client_8h.html#a3a1fd6b68d65c992babb818a3629f30c", null ]
];