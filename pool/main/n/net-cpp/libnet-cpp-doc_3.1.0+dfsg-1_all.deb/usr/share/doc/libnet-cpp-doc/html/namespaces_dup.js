var namespaces_dup =
[
    [ "core", "namespacecore.html", "namespacecore" ]
];