var namespacecore_1_1net =
[
    [ "http", "namespacecore_1_1net_1_1http.html", "namespacecore_1_1net_1_1http" ],
    [ "Error", "classcore_1_1net_1_1Error.html", "classcore_1_1net_1_1Error" ],
    [ "Uri", "structcore_1_1net_1_1Uri.html", "structcore_1_1net_1_1Uri" ],
    [ "make_uri", "namespacecore_1_1net.html#a7657bc69238652b5b094c081ef66844a", null ]
];