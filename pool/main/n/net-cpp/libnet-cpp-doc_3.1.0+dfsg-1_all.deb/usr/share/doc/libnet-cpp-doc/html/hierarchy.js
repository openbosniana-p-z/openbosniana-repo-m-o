var hierarchy =
[
    [ "core::net::http::Client", "classcore_1_1net_1_1http_1_1Client.html", [
      [ "core::net::http::StreamingClient", "classcore_1_1net_1_1http_1_1StreamingClient.html", null ]
    ] ],
    [ "core::net::http::Request::Configuration", "structcore_1_1net_1_1http_1_1Request_1_1Configuration.html", null ],
    [ "core::net::http::ContentType", "structcore_1_1net_1_1http_1_1ContentType.html", null ],
    [ "core::net::http::Request::Credentials", "structcore_1_1net_1_1http_1_1Request_1_1Credentials.html", null ],
    [ "core::net::http::Client::Errors", "structcore_1_1net_1_1http_1_1Client_1_1Errors.html", null ],
    [ "core::net::http::Request::Errors", "structcore_1_1net_1_1http_1_1Request_1_1Errors.html", null ],
    [ "std::exception", null, [
      [ "std::runtime_error", null, [
        [ "core::net::Error", "classcore_1_1net_1_1Error.html", [
          [ "core::net::http::Error", "classcore_1_1net_1_1http_1_1Error.html", [
            [ "core::net::http::Client::Errors::HttpMethodNotSupported", "structcore_1_1net_1_1http_1_1Client_1_1Errors_1_1HttpMethodNotSupported.html", null ],
            [ "core::net::http::Request::Errors::AlreadyActive", "structcore_1_1net_1_1http_1_1Request_1_1Errors_1_1AlreadyActive.html", null ]
          ] ]
        ] ]
      ] ]
    ] ],
    [ "core::net::http::Request::Handler", "classcore_1_1net_1_1http_1_1Request_1_1Handler.html", null ],
    [ "core::net::http::Header", "classcore_1_1net_1_1http_1_1Header.html", null ],
    [ "core::Location", "structcore_1_1Location.html", null ],
    [ "core::net::http::Request::Progress", "structcore_1_1net_1_1http_1_1Request_1_1Progress.html", null ],
    [ "core::net::http::Request", "classcore_1_1net_1_1http_1_1Request.html", [
      [ "core::net::http::StreamingRequest", "classcore_1_1net_1_1http_1_1StreamingRequest.html", null ]
    ] ],
    [ "core::net::http::Response", "structcore_1_1net_1_1http_1_1Response.html", null ],
    [ "core::net::http::Client::Timings::Statistics", "structcore_1_1net_1_1http_1_1Client_1_1Timings_1_1Statistics.html", null ],
    [ "core::net::http::Client::Timings", "structcore_1_1net_1_1http_1_1Client_1_1Timings.html", null ],
    [ "core::net::Uri", "structcore_1_1net_1_1Uri.html", null ]
];