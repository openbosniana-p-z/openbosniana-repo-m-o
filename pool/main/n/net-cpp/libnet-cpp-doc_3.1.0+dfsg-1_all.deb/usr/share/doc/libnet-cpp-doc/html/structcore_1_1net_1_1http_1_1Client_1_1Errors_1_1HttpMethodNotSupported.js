var structcore_1_1net_1_1http_1_1Client_1_1Errors_1_1HttpMethodNotSupported =
[
    [ "HttpMethodNotSupported", "structcore_1_1net_1_1http_1_1Client_1_1Errors_1_1HttpMethodNotSupported.html#a515ad304b1129a66c061f942b0b5a4a8", null ],
    [ "method", "structcore_1_1net_1_1http_1_1Client_1_1Errors_1_1HttpMethodNotSupported.html#ac46aa1356ab6e626755d9bb6b6977a96", null ]
];