var structcore_1_1net_1_1http_1_1Request_1_1Errors =
[
    [ "AlreadyActive", "structcore_1_1net_1_1http_1_1Request_1_1Errors_1_1AlreadyActive.html", "structcore_1_1net_1_1http_1_1Request_1_1Errors_1_1AlreadyActive" ],
    [ "Errors", "structcore_1_1net_1_1http_1_1Request_1_1Errors.html#aee4cdbab55b37cc888cb6614c7b3d078", null ]
];