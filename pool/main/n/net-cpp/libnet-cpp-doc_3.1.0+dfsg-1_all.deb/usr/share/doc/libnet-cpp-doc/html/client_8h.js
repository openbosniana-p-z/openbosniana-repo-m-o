var client_8h =
[
    [ "core::net::http::Client", "classcore_1_1net_1_1http_1_1Client.html", "classcore_1_1net_1_1http_1_1Client" ],
    [ "core::net::http::Client::Errors", "structcore_1_1net_1_1http_1_1Client_1_1Errors.html", "structcore_1_1net_1_1http_1_1Client_1_1Errors" ],
    [ "core::net::http::Client::Errors::HttpMethodNotSupported", "structcore_1_1net_1_1http_1_1Client_1_1Errors_1_1HttpMethodNotSupported.html", "structcore_1_1net_1_1http_1_1Client_1_1Errors_1_1HttpMethodNotSupported" ],
    [ "core::net::http::Client::Timings", "structcore_1_1net_1_1http_1_1Client_1_1Timings.html", "structcore_1_1net_1_1http_1_1Client_1_1Timings" ],
    [ "core::net::http::Client::Timings::Statistics", "structcore_1_1net_1_1http_1_1Client_1_1Timings_1_1Statistics.html", "structcore_1_1net_1_1http_1_1Client_1_1Timings_1_1Statistics" ],
    [ "make_client", "client_8h.html#ab9090bc577f594d4c9373687c3b5d417", null ]
];