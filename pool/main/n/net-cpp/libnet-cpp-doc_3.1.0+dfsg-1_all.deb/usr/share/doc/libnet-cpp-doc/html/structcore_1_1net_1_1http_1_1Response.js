var structcore_1_1net_1_1http_1_1Response =
[
    [ "Body", "structcore_1_1net_1_1http_1_1Response.html#aba37b39833bd66419271ac6812eee79c", null ],
    [ "body", "structcore_1_1net_1_1http_1_1Response.html#ac8866f0aa746a1be63f3346ae17ea831", null ],
    [ "header", "structcore_1_1net_1_1http_1_1Response.html#ab3229fb1d7f27762a332de5c954ae4ac", null ],
    [ "status", "structcore_1_1net_1_1http_1_1Response.html#ac9ad53e60cbc159086e166473508d8e1", null ]
];