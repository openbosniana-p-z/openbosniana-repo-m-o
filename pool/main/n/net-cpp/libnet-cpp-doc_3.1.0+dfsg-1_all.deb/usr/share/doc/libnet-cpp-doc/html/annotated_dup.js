var annotated_dup =
[
    [ "core", "namespacecore.html", [
      [ "net", "namespacecore_1_1net.html", [
        [ "http", "namespacecore_1_1net_1_1http.html", [
          [ "Client", "classcore_1_1net_1_1http_1_1Client.html", "classcore_1_1net_1_1http_1_1Client" ],
          [ "ContentType", "structcore_1_1net_1_1http_1_1ContentType.html", "structcore_1_1net_1_1http_1_1ContentType" ],
          [ "Error", "classcore_1_1net_1_1http_1_1Error.html", "classcore_1_1net_1_1http_1_1Error" ],
          [ "Header", "classcore_1_1net_1_1http_1_1Header.html", "classcore_1_1net_1_1http_1_1Header" ],
          [ "Request", "classcore_1_1net_1_1http_1_1Request.html", "classcore_1_1net_1_1http_1_1Request" ],
          [ "Response", "structcore_1_1net_1_1http_1_1Response.html", "structcore_1_1net_1_1http_1_1Response" ],
          [ "StreamingClient", "classcore_1_1net_1_1http_1_1StreamingClient.html", "classcore_1_1net_1_1http_1_1StreamingClient" ],
          [ "StreamingRequest", "classcore_1_1net_1_1http_1_1StreamingRequest.html", "classcore_1_1net_1_1http_1_1StreamingRequest" ]
        ] ],
        [ "Error", "classcore_1_1net_1_1Error.html", "classcore_1_1net_1_1Error" ],
        [ "Uri", "structcore_1_1net_1_1Uri.html", "structcore_1_1net_1_1Uri" ]
      ] ],
      [ "Location", "structcore_1_1Location.html", "structcore_1_1Location" ]
    ] ]
];