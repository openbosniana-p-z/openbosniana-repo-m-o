var structcore_1_1net_1_1http_1_1Client_1_1Errors =
[
    [ "HttpMethodNotSupported", "structcore_1_1net_1_1http_1_1Client_1_1Errors_1_1HttpMethodNotSupported.html", "structcore_1_1net_1_1http_1_1Client_1_1Errors_1_1HttpMethodNotSupported" ],
    [ "Errors", "structcore_1_1net_1_1http_1_1Client_1_1Errors.html#a5c6b701d7cc1c2f6ac88404465fecf1c", null ]
];