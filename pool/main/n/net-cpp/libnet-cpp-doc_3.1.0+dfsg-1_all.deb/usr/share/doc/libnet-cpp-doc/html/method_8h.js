var method_8h =
[
    [ "Method", "method_8h.html#ab97b6acf537769e4d31c291f27c6af1a", [
      [ "get", "method_8h.html#ab97b6acf537769e4d31c291f27c6af1aab5eda0a74558a342cf659187f06f746f", null ],
      [ "head", "method_8h.html#ab97b6acf537769e4d31c291f27c6af1aa96e89a298e0a9f469b9ae458d6afae9f", null ],
      [ "post", "method_8h.html#ab97b6acf537769e4d31c291f27c6af1aa42b90196b487c54069097a68fe98ab6f", null ],
      [ "put", "method_8h.html#ab97b6acf537769e4d31c291f27c6af1aa8e13ffc9fd9d6a6761231a764bdf106b", null ],
      [ "del", "method_8h.html#ab97b6acf537769e4d31c291f27c6af1aad2bcc286168bf8e040885c5cb7b6df13", null ]
    ] ]
];