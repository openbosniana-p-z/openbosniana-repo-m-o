var JSONDocument =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./lib/Formats.js":
/*!************************!*\
  !*** ./lib/Formats.js ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * JSON Schema Formats
 *
 * TODO
 * Is there a good way to express these over multiple lines with comments
 * for easier debugging and auditing?
 */

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var DATETIME_REGEXP = /^\d\d\d\d-[0-1]\d-[0-3]\d[t\s][0-2]\d:[0-5]\d:[0-5]\d(?:\.\d+)?(?:z|[+-]\d\d:\d\d)$/i;
var URI_REGEXP = /^(?:[a-z][a-z0-9+-.]*)?(?:\:|\/)\/?[^\s]*$/i;
var EMAIL_REGEXP = /^[a-z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i;
var IPV4_REGEXP = /^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/;
var IPV6_REGEXP = /^\s*(?:(?:(?:[0-9a-f]{1,4}:){7}(?:[0-9a-f]{1,4}|:))|(?:(?:[0-9a-f]{1,4}:){6}(?::[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(?:(?:[0-9a-f]{1,4}:){5}(?:(?:(?::[0-9a-f]{1,4}){1,2})|:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(?:(?:[0-9a-f]{1,4}:){4}(?:(?:(?::[0-9a-f]{1,4}){1,3})|(?:(?::[0-9a-f]{1,4})?:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?:(?:[0-9a-f]{1,4}:){3}(?:(?:(?::[0-9a-f]{1,4}){1,4})|(?:(?::[0-9a-f]{1,4}){0,2}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?:(?:[0-9a-f]{1,4}:){2}(?:(?:(?::[0-9a-f]{1,4}){1,5})|(?:(?::[0-9a-f]{1,4}){0,3}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?:(?:[0-9a-f]{1,4}:){1}(?:(?:(?::[0-9a-f]{1,4}){1,6})|(?:(?::[0-9a-f]{1,4}){0,4}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(?::(?:(?:(?::[0-9a-f]{1,4}){1,7})|(?:(?::[0-9a-f]{1,4}){0,5}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(?:%.+)?\s*$/i;
var HOSTNAME_REGEXP = /^[a-z](?:(?:[-0-9a-z]{0,61})?[0-9a-z])?(\.[a-z](?:(?:[-0-9a-z]{0,61})?[0-9a-z])?)*$/i;
/**
 * Formats
 */

var Formats = /*#__PURE__*/function () {
  function Formats() {
    _classCallCheck(this, Formats);
  }

  _createClass(Formats, [{
    key: "register",
    value:
    /**
     * Register
     *
     * @description
     * Register a new mapping from named format to RegExp instance
     *
     * TODO
     * We can do some extra validation of the RegExp to
     * ensure it's the acceptable subset of RegExps allowed
     * by JSON Schema.
     *
     * @param {string} name
     * @param {RegExp} pattern
     * @returns {RegExp}
     */
    function register(name, pattern) {
      // verify name is a string
      if (typeof name !== 'string') {
        throw new Error('Format name must be a string');
      } // cast a string to RegExp


      if (typeof pattern === 'string') {
        pattern = new RegExp(pattern);
      }

      return this[name] = pattern;
    }
    /**
     * Resolve
     *
     * @description
     * Given a format name, return the corresponding registered validation. In the
     * event a format is not registered, throw an error.
     *
     * @param {string} name
     * @returns {RegExp}
     */

  }, {
    key: "resolve",
    value: function resolve(name) {
      var format = this[name];

      if (!format) {
        throw new Error('Unknown JSON Schema format.');
      }

      return format;
    }
    /**
     * Test
     *
     * @description
     * Test that a value conforms to a format.
     *
     * @param {string} name
     * @param {string} value
     * @returns {Boolean}
     */

  }, {
    key: "test",
    value: function test(name, value) {
      var format = this.resolve(name);
      return format.test(value);
    }
  }], [{
    key: "initialize",
    value:
    /**
     * Initialize
     *
     * @description
     * Create a new Formats instance and register default formats
     *
     * @returns {Formats}
     */
    function initialize() {
      var formats = new Formats();
      formats.register('date-time', DATETIME_REGEXP);
      formats.register('uri', URI_REGEXP);
      formats.register('email', EMAIL_REGEXP);
      formats.register('ipv4', IPV4_REGEXP);
      formats.register('ipv6', IPV6_REGEXP);
      formats.register('hostname', HOSTNAME_REGEXP);
      return formats;
    }
  }]);

  return Formats;
}();
/**
 * Export
 */


module.exports = Formats.initialize();

/***/ }),

/***/ "./lib/Initializer.js":
/*!****************************!*\
  !*** ./lib/Initializer.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Initializer
 */

function _typeof(obj) { "@babel/helpers - typeof"; return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; })(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var Initializer = /*#__PURE__*/function () {
  /**
   * constructor
   */
  function Initializer(schema, options) {
    _classCallCheck(this, Initializer);

    Object.assign(this, options || {});
    this.root = this.root || this;
    this.root.depth = this.root.depth || 1;

    if (this.level > this.root.depth) {
      this.root.depth = this.level;
    }

    this.level = this.level || 0;
    this.schema = schema;
  }
  /**
   * compile (static)
   */


  _createClass(Initializer, [{
    key: "compile",
    value:
    /**
     * compile
     */
    function compile() {
      var root = this.root,
          depth = this.depth,
          level = this.level;
      var declarations = "";
      var body = ""; // traverse the schema and generate code

      body += this["default"]();
      body += this.properties(); //body += this.additionalProperties()

      body += this.items(); //body += this.additionalItems()
      // value

      body += this.member();
      body += this.item(); // after traversing the schema
      // generate the variable declarations

      if (root === this) {
        for (var i = 1; i <= this.root.depth; i++) {
          declarations += this.declaration(i);
        }

        return "\n        options = options || {}\n\n        if (options.filter === false) {\n          Object.assign(target, JSON.parse(JSON.stringify(source)))\n        }\n\n        ".concat(declarations, "\n        ").concat(body, "\n      ");
      }

      return body;
    }
    /**
     * declaration
     */

  }, {
    key: "declaration",
    value: function declaration(level) {
      return "\n      var target".concat(level, "\n      var source").concat(level, "\n      var count").concat(level, "\n    ");
    }
    /**
     * default
     */

  }, {
    key: "default",
    value: function _default() {
      var schema = this.schema,
          level = this.level,
          key = this.key,
          index = this.index;
      var value = schema["default"]; // rename default to value because it's a keyword and syntax highlighter breaks

      var block = "";

      if (schema.hasOwnProperty('default')) {
        if (key) {
          block += "\n          target".concat(level, "['").concat(key, "'] = ").concat(JSON.stringify(value), "\n        ");
        }

        if (index) {
          block += "\n          target".concat(level, "[").concat(index, "] = ").concat(JSON.stringify(value), "\n        ");
        }

        if (level > 1) {
          block += "\n          count".concat(level, "++\n        ");
        }

        block = "\n        if (options.defaults !== false) {\n          ".concat(block, "\n        }\n      ");
      }

      return block;
    }
    /**
     * member
     */

  }, {
    key: "member",
    value: function member() {
      var schema = this.schema,
          root = this.root,
          level = this.level,
          key = this.key;
      var properties = schema.properties,
          additionalProperties = schema.additionalProperties,
          items = schema.items,
          additionalItems = schema.additionalItems;
      var block = ""; // `key` tells us to treat this subschema as an object member vs an array item
      // and the absence of the other values here indicates we are dealing with a
      // primitive value

      if (key && !properties && !additionalProperties && !items && !additionalItems) {
        // first generate the assignment statement
        block += "\n        target".concat(level, "['").concat(key, "'] = source").concat(level, "['").concat(key, "']\n      "); // for nested container objects, add the counter incrementing statement

        if (level > 1) {
          block += "\n          count".concat(level, "++\n        ");
        } // wrap the foregoing in a check for presence on the source


        block = "\n        if (source".concat(level, ".hasOwnProperty('").concat(key, "')) {\n          ").concat(block, "\n        }\n      ");
      }

      return block;
    }
    /**
     * item
     */

  }, {
    key: "item",
    value: function item() {
      var schema = this.schema,
          root = this.root,
          level = this.level,
          index = this.index;
      var properties = schema.properties,
          additionalProperties = schema.additionalProperties,
          items = schema.items,
          additionalItems = schema.additionalItems;
      var block = "";

      if (index && !properties && !additionalProperties && !items && !additionalItems) {
        block += "\n        target".concat(level, "[").concat(index, "] = source").concat(level, "[").concat(index, "]\n      ");

        if (level > 1) {
          block += "\n          count".concat(level, "++\n        ");
        }

        block = "\n        if (".concat(index, " < len) {\n          ").concat(block, "\n        }\n      ");
      }

      return block;
    }
    /**
     * properties
     */

  }, {
    key: "properties",
    value: function properties() {
      var schema = this.schema,
          root = this.root,
          level = this.level,
          key = this.key,
          index = this.index;
      var properties = schema.properties;
      var block = "";

      if (properties) {
        Object.keys(properties).forEach(function (key) {
          var subschema = properties[key];
          var initializer = new Initializer(subschema, {
            key: key,
            root: root,
            level: level + 1
          });
          block += initializer.compile();
        }); // root-level properties boilerplate

        if (root === this) {
          block = "\n          if (typeof source === 'object' && source !== null && !Array.isArray(source)) {\n            if (typeof target !== 'object') {\n              throw new Error('?')\n            }\n\n            source1 = source\n            target1 = target\n            count1 = 0\n\n            ".concat(block, "\n          }\n        "); // nested properties boilerplate
        } else {
          if (index) {
            block = "\n            if (".concat(index, " < source").concat(level, ".length || typeof source").concat(level, "[").concat(index, "] === 'object') {\n\n              source").concat(level + 1, " = source").concat(level, "[").concat(index, "] || {}\n              count").concat(level + 1, " = 0\n\n              if (").concat(index, " < target").concat(level, ".length || typeof target").concat(level, "[").concat(index, "] !== 'object') {\n                target").concat(level + 1, " = {}\n                if (").concat(index, " < source").concat(level, ".length) {\n                  count").concat(level + 1, "++\n                }\n              } else {\n                target").concat(level + 1, " = target").concat(level, "[").concat(index, "]\n              }\n\n              ").concat(block, "\n\n              if (count").concat(level + 1, " > 0) {\n                target").concat(level, "[").concat(index, "] = target").concat(level + 1, "\n                count").concat(level, "++\n              }\n\n            } else {\n              target").concat(level, "[").concat(index, "] = source").concat(level, "[").concat(index, "]\n              count").concat(level, "++\n            }\n          ");
          }

          if (key) {
            block = "\n            if ((typeof source".concat(level, "['").concat(key, "'] === 'object'\n                  && source").concat(level, "['").concat(key, "'] !== null\n                  && !Array.isArray(source").concat(level, "['").concat(key, "']))\n                || !source").concat(level, ".hasOwnProperty('").concat(key, "')) {\n\n              source").concat(level + 1, " = source").concat(level, "['").concat(key, "'] || {}\n              count").concat(level + 1, " = 0\n\n              if (!target").concat(level, ".hasOwnProperty('").concat(key, "')\n                  || typeof target").concat(level, "['").concat(key, "'] !== 'object'\n                  || target").concat(level, "['").concat(key, "'] === null\n                  || Array.isArray(target").concat(level, "['").concat(key, "'])) {\n                target").concat(level + 1, " = {}\n                if (source").concat(level, ".hasOwnProperty('").concat(key, "')) {\n                  count").concat(level + 1, "++\n                }\n              } else {\n                target").concat(level + 1, " = target").concat(level, "['").concat(key, "']\n                count").concat(level + 1, "++\n              }\n\n              ").concat(block, "\n\n              if (count").concat(level + 1, " > 0) {\n                target").concat(level, "['").concat(key, "'] = target").concat(level + 1, "\n                count").concat(level, "++\n              }\n\n            } else {\n              target").concat(level, "['").concat(key, "'] = source").concat(level, "['").concat(key, "']\n              count").concat(level, "++\n            }\n          ");
          }
        }
      }

      return block;
    }
    /**
     *
     */

  }, {
    key: "additionalProperties",
    value: function additionalProperties() {}
    /**
     * items
     */

  }, {
    key: "items",
    value: function items() {
      var schema = this.schema,
          root = this.root,
          level = this.level,
          key = this.key,
          index = this.index;
      var items = schema.items;
      var block = "";

      if (items) {
        if (Array.isArray(items)) {// TODO
          //
          //
          //
          //
          //
          // ...
        } else if (_typeof(items) === 'object' && items !== null) {
          var _index = "i".concat(level + 1);

          var initializer = new Initializer(items, {
            index: _index,
            root: root,
            level: level + 1
          });
          block += "\n          var sLen = source".concat(level + 1, ".length || 0\n          var tLen = target").concat(level + 1, ".length || 0\n          var len = 0\n\n          if (sLen > len) { len = sLen }\n          // THIS IS WRONG, CAUSED SIMPLE ARRAY INIT TO FAIL (OVERWRITE\n          // EXISTING TARGET VALUES WITH UNDEFINED WHEN SOURCE IS SHORTER THAN\n          // TARGET). LEAVING HERE UNTIL WE FINISH TESTING AND SEE WHY IT MIGHT\n          // HAVE BEEN HERE IN THE FIRST PLACE.\n          //\n          // if (tLen > len) { len = tLen }\n\n          for (var ").concat(_index, " = 0; ").concat(_index, " < len; ").concat(_index, "++) {\n            ").concat(initializer.compile(), "\n          }\n        ");
        } // root-level properties boilerplate


        if (root === this) {
          block = "\n          if (Array.isArray(source)) {\n            if (!Array.isArray(target)) {\n              throw new Error('?')\n            }\n\n            source1 = source\n            target1 = target\n\n            ".concat(block, "\n          }\n        "); // nested properties boilerplate
        } else {
          block = "\n          if (Array.isArray(source".concat(level, "['").concat(key, "']) || !source").concat(level, ".hasOwnProperty('").concat(key, "')) {\n\n            source").concat(level + 1, " = source").concat(level, "['").concat(key, "'] || []\n            count").concat(level + 1, " = 0\n\n            if (!target").concat(level, ".hasOwnProperty('").concat(key, "') || !Array.isArray(target").concat(level, "['").concat(key, "'])) {\n              target").concat(level + 1, " = []\n                if (source").concat(level, ".hasOwnProperty('").concat(key, "')) {\n                  count").concat(level + 1, "++\n                }\n\n            } else {\n              target").concat(level + 1, " = target").concat(level, "['").concat(key, "']\n              count").concat(level + 1, "++\n            }\n\n            ").concat(block, "\n\n            if (count").concat(level + 1, " > 0) {\n              target").concat(level, "['").concat(key, "'] = target").concat(level + 1, "\n              count").concat(level, "++\n            }\n\n          } else {\n            target").concat(level, "['").concat(key, "'] = source").concat(level, "['").concat(key, "']\n            count").concat(level, "++\n          }\n        ");
        }
      }

      return block;
    }
    /**
     *
     */

  }, {
    key: "additionalItems",
    value: function additionalItems() {}
  }], [{
    key: "compile",
    value: function compile(schema) {
      var initializer = new Initializer(schema);
      var block = initializer.compile(); //console.log(beautify(block))

      try {
        return new Function('target', 'source', 'options', block);
      } catch (e) {
        console.log(e, e.stack);
      }
    }
  }]);

  return Initializer;
}();

module.exports = Initializer;

/***/ }),

/***/ "./lib/JSONDocument.js":
/*!*****************************!*\
  !*** ./lib/JSONDocument.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Module dependencies
 * @ignore
 */

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var JSONPatch = __webpack_require__(/*! ./JSONPatch */ "./lib/JSONPatch.js");
/**
 * JSONDocument
 *
 * @class
 * JSONDocument is a high level interface that binds together all other features of
 * this package and provides the principle method of data modeling.
 */


var JSONDocument = /*#__PURE__*/function () {
  /**
   * Constructor
   *
   * @param {Object} data
   * @param {Object} options
   */
  function JSONDocument() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    _classCallCheck(this, JSONDocument);

    this.initialize(data, options);
  }
  /**
   * Initialize
   *
   * @param {Object} data
   * @param {Object} options
   */


  _createClass(JSONDocument, [{
    key: "initialize",
    value: function initialize() {
      var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var schema = this.constructor.schema;
      schema.initialize(this, data, options);
    }
    /**
     * Validate
     *
     * @param {JSONSchema} alternate - OPTIONAL alternate schema
     * @returns {Object}
     */

  }, {
    key: "validate",
    value: function validate(alternate) {
      var schema = this.constructor.schema;
      return (alternate || schema).validate(this);
    }
    /**
     * Patch
     *
     * @param {Array} ops
     */

  }, {
    key: "patch",
    value: function patch(ops) {
      var patch = new JSONPatch(ops);
      patch.apply(this);
    }
    /**
     * Select
     */

  }, {
    key: "select",
    value: function select() {}
    /**
     * Project
     *
     * @description
     * Given a mapping, return an object projected from the current instance.
     *
     * @example
     * let schema = new JSONSchema({
     *   properties: {
     *     foo: { type: 'Array' }
     *   }
     * })
     *
     * let mapping = new JSONMapping({
     *   '/foo/0': '/bar/baz'
     * })
     *
     * class FooTracker extends JSONDocument {
     *   static get schema () { return schema }
     * }
     *
     * let instance = new FooTracker({ foo: ['qux'] })
     * instance.project(mapping)
     * // => { bar: { baz: 'qux' } }
     *
     * @param {JSONMapping} mapping
     * @return {Object}
     */

  }, {
    key: "project",
    value: function project(mapping) {
      return mapping.project(this);
    }
    /**
     * Serialize
     *
     * @param {Object} object
     * @returns {string}
     */

  }], [{
    key: "schema",
    get:
    /**
     * Schema
     */
    function get() {
      throw new Error('Schema must be defined by classes extending JSONDocument');
    }
  }, {
    key: "serialize",
    value: function serialize(object) {
      return JSON.stringify(object);
    }
    /**
     * Deserialize
     *
     * @param {string} data
     * @return {*}
     */

  }, {
    key: "deserialize",
    value: function deserialize(data) {
      try {
        return JSON.parse(data);
      } catch (e) {
        throw new Error('Failed to parse JSON');
      }
    }
  }]);

  return JSONDocument;
}();
/**
 * Export
 */


module.exports = JSONDocument;

/***/ }),

/***/ "./lib/JSONMapping.js":
/*!****************************!*\
  !*** ./lib/JSONMapping.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Module dependencies
 * @ignore
 */

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var JSONPointer = __webpack_require__(/*! ./JSONPointer */ "./lib/JSONPointer.js");
/**
 * JSONPointer mode
 */


var RECOVER = 1;
/**
 * JSONMapping
 *
 * @class
 * Defines a means to declaratively translate between object
 * representations using JSON Pointer syntax.
 */

var JSONMapping = /*#__PURE__*/function () {
  /**
   * Constructor
   *
   * @description Translate pointers from JSON Strings into Pointer objects
   * @param {Object} mapping
   */
  function JSONMapping(mapping) {
    var _this = this;

    _classCallCheck(this, JSONMapping);

    Object.defineProperty(this, 'mapping', {
      enumerable: false,
      value: new Map()
    });
    Object.keys(mapping).forEach(function (key) {
      var value = mapping[key];

      _this.mapping.set(new JSONPointer(key, RECOVER), new JSONPointer(value, RECOVER));
    });
  }
  /**
   * Map
   *
   * @description Assign values from source to target by reading the mapping
   * from right to left.
   * @param {Object} target
   * @param {Object} source
   */


  _createClass(JSONMapping, [{
    key: "map",
    value: function map(target, source) {
      this.mapping.forEach(function (right, left) {
        left.add(target, right.get(source));
      });
    }
    /**
     * Project
     *
     * @description Assign values from source to target by reading the mapping
     * from left to right.
     * @param {Object} source
     * @param {Object} target
     */

  }, {
    key: "project",
    value: function project(source, target) {
      this.mapping.forEach(function (right, left) {
        right.add(target, left.get(source));
      });
    }
  }]);

  return JSONMapping;
}();
/**
 * Exports
 */


module.exports = JSONMapping;

/***/ }),

/***/ "./lib/JSONPatch.js":
/*!**************************!*\
  !*** ./lib/JSONPatch.js ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Module dependencies
 * @ignore
 */

function _typeof(obj) { "@babel/helpers - typeof"; return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; })(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var JSONPointer = __webpack_require__(/*! ./JSONPointer */ "./lib/JSONPointer.js");
/**
 * Modes
 */


var THROW = 0;
var RECOVER = 1;
var SILENT = 2;
/**
 * Operations list
 */

var OPERATIONS = ['add', 'remove', 'replace', 'move', 'copy', 'test'];
/**
 * Patch
 *
 * @class
 * Implements RFC 6902: JavaScript Object Notation (JSON) Patch
 * https://tools.ietf.org/html/rfc6902
 */

var JSONPatch = /*#__PURE__*/function () {
  /**
   * Constructor
   *
   * @param {Array} ops
   */
  function JSONPatch(ops) {
    _classCallCheck(this, JSONPatch);

    this.ops = ops || [];
  }
  /**
   * Apply
   *
   * @todo handle errors/roll back
   * @todo protect properties that are private in the schema
   * @todo map JSON Pointers real property names
   *
   * @param {Object} target
   */


  _createClass(JSONPatch, [{
    key: "apply",
    value: function apply(target) {
      var _this = this;

      this.ops.forEach(function (operation) {
        var op = operation.op;

        if (!op) {
          throw new Error('Missing "op" in JSON Patch operation');
        }

        if (OPERATIONS.indexOf(op) === -1) {
          throw new Error('Invalid "op" in JSON Patch operation');
        }

        if (!operation.path) {
          throw new Error('Missing "path" in JSON Patch operation');
        }

        _this[op](operation, target);
      });
    }
    /**
     * Add
     *
     * @param {Object} op
     * @param {Object} target
     */

  }, {
    key: "add",
    value: function add(op, target) {
      if (op.value === undefined) {
        throw new Error('Missing "value" in JSON Patch add operation');
      }

      var pointer = new JSONPointer(op.path, SILENT);
      pointer.add(target, op.value);
    }
    /**
     * Remove
     *
     * @param {Object} op
     * @param {Object} target
     */

  }, {
    key: "remove",
    value: function remove(op, target) {
      var pointer = new JSONPointer(op.path);
      pointer.remove(target);
    }
    /**
     * Replace
     *
     * @param {Object} op
     * @param {Object} target
     */

  }, {
    key: "replace",
    value: function replace(op, target) {
      if (op.value === undefined) {
        throw new Error('Missing "value" in JSON Patch replace operation');
      }

      var pointer = new JSONPointer(op.path);
      pointer.replace(target, op.value);
    }
    /**
     * Move
     *
     * @param {Object} op
     * @param {Object} target
     */

  }, {
    key: "move",
    value: function move(op, target) {
      if (op.from === undefined) {
        throw new Error('Missing "from" in JSON Patch move operation');
      }

      if (op.path.match(new RegExp("^".concat(op.from)))) {
        throw new Error('Invalid "from" in JSON Patch move operation');
      }

      var pointer = new JSONPointer(op.path);
      var from = new JSONPointer(op.from);
      var value = from.get(target);
      from.remove(target);
      pointer.add(target, value);
    }
    /**
     * Copy
     *
     * @param {Object} op
     * @param {Object} target
     */

  }, {
    key: "copy",
    value: function copy(op, target) {
      if (op.from === undefined) {
        throw new Error('Missing "from" in JSON Patch copy operation');
      }

      var pointer = new JSONPointer(op.path);
      var from = new JSONPointer(op.from);
      var value = from.get(target);
      pointer.add(target, value);
    }
    /**
     * Test
     *
     * @param {Object} op
     * @param {Object} target
     */

  }, {
    key: "test",
    value: function test(op, target) {
      if (op.value === undefined) {
        throw new Error('Missing "value" in JSON Patch test operation');
      }

      var pointer = new JSONPointer(op.path);
      var value = pointer.get(target);

      switch (_typeof(op.value)) {
        //case 'string':
        //case 'number':
        //case 'boolean':
        //  if (value !== op.value) {
        //    throw new Error('Mismatching JSON Patch test value')
        //  }
        default:
          if (value !== op.value) {
            throw new Error('Mismatching JSON Patch test value');
          }

      }
    }
  }]);

  return JSONPatch;
}();
/**
 * Exports
 */


module.exports = JSONPatch;

/***/ }),

/***/ "./lib/JSONPointer.js":
/*!****************************!*\
  !*** ./lib/JSONPointer.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Mode enumeration
 */

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var THROW = 0;
var RECOVER = 1;
var SILENT = 2;
/**
 * JSONPointer
 *
 * @class
 * Implements RFC 6901: JavaScript Object Notation (JSON) Pointer
 * https://tools.ietf.org/html/rfc6901
 */

var JSONPointer = /*#__PURE__*/function () {
  /**
   * Constructor
   */
  function JSONPointer(expr, mode) {
    _classCallCheck(this, JSONPointer);

    this.expr = expr;
    this.mode = mode || THROW;
    this.tokens = expr && expr.charAt(0) === '#' ? this.parseURIFragmentIdentifier(expr) : this.parseJSONString(expr);
  }
  /**
   * Escape
   */


  _createClass(JSONPointer, [{
    key: "escape",
    value: function escape(expr) {
      return expr.replace(/~/g, '~0').replace(/\//g, '~1');
    }
    /**
     * Unescape
     */

  }, {
    key: "unescape",
    value: function unescape(expr) {
      return expr.replace(/~1/g, '/').replace(/~0/g, '~');
    }
    /**
     * Parse
     */

  }, {
    key: "parseJSONString",
    value:
    /**
     * Parse JSON String
     *
     * @description Parse an expression into a list of tokens
     * @param {string} expr
     * @returns {Array}
     */
    function parseJSONString(expr) {
      if (typeof expr !== 'string') {
        throw new Error('JSON Pointer must be a string');
      }

      if (expr === '') {
        return [];
      }

      if (expr.charAt(0) !== '/') {
        throw new Error('Invalid JSON Pointer');
      }

      if (expr === '/') {
        return [''];
      }

      return expr.substr(1).split('/').map(this.unescape);
    }
    /**
     * To JSON String
     *
     * @description Render a JSON string representation of a pointer
     * @returns {string}
     */

  }, {
    key: "toJSONString",
    value: function toJSONString() {
      return "/".concat(this.tokens.map(this.escape).join('/'));
    }
    /**
     * Parse URI Fragment Identifer
     */

  }, {
    key: "parseURIFragmentIdentifier",
    value: function parseURIFragmentIdentifier(expr) {
      if (typeof expr !== 'string') {
        throw new Error('JSON Pointer must be a string');
      }

      if (expr.charAt(0) !== '#') {
        throw new Error('Invalid JSON Pointer URI Fragment Identifier');
      }

      return this.parseJSONString(decodeURIComponent(expr.substr(1)));
    }
    /**
     * To URI Fragment Identifier
     *
     * @description Render a URI Fragment Identifier representation of a pointer
     * @returns {string}
     */

  }, {
    key: "toURIFragmentIdentifier",
    value: function toURIFragmentIdentifier() {
      var _this = this;

      var value = this.tokens.map(function (token) {
        return encodeURIComponent(_this.escape(token));
      }).join('/');
      return "#/".concat(value);
    }
    /**
     * Get
     *
     * @description Get a value from the source object referenced by the pointer
     * @param {Object} source
     * @returns {*}
     */

  }, {
    key: "get",
    value: function get(source) {
      var current = source;
      var tokens = this.tokens;

      for (var i = 0; i < tokens.length; i++) {
        if (!current || current[tokens[i]] === undefined) {
          if (this.mode !== THROW) {
            return undefined;
          } else {
            throw new Error('Invalid JSON Pointer reference');
          }
        }

        current = current[tokens[i]];
      }

      return current;
    }
    /**
     * Add
     *
     * @description Set a value on a target object referenced by the pointer. Put
     * will insert an array element. To change an existing array elemnent, use
     * `pointer.set()`
     * @param {Object} target
     * @param {*} value
     */

  }, {
    key: "add",
    value: function add(target, value) {
      var tokens = this.tokens;
      var current = target; // iterate through the tokens

      for (var i = 0; i < tokens.length; i++) {
        var token = tokens[i]; // set the property on the target location

        if (i === tokens.length - 1) {
          if (token === '-') {
            current.push(value);
          } else if (Array.isArray(current)) {
            current.splice(token, 0, value);
          } else if (value !== undefined) {
            current[token] = value;
          } // handle missing target location based on "mode"

        } else if (!current[token]) {
          switch (this.mode) {
            case THROW:
              throw new Error('Invalid JSON Pointer reference');

            case RECOVER:
              current = current[token] = parseInt(token) ? [] : {};
              break;

            case SILENT:
              return;

            default:
              throw new Error('Invalid pointer mode');
          } // reference the next object in the path

        } else {
          current = current[token];
        }
      }
    }
    /**
     * Replace
     *
     * @description Set a value on a target object referenced by the pointer. Set will
     * overwrite an existing array element at the target location.
     * @param {Object} target
     * @param {*} value
     */

  }, {
    key: "replace",
    value: function replace(target, value) {
      var tokens = this.tokens;
      var current = target;

      for (var i = 0; i < tokens.length; i++) {
        var token = tokens[i];

        if (i === tokens.length - 1) {
          current[token] = value;
        } else if (!current[token]) {
          current = current[token] = parseInt(token) ? [] : {};
        } else {
          current = current[token];
        }
      }
    }
    /**
     * Del
     *
     * - if this is an array it should splice the value out
     */

  }, {
    key: "remove",
    value: function remove(target) {
      var tokens = this.tokens;
      var current = target;

      for (var i = 0; i < tokens.length; i++) {
        var token = tokens[i];

        if (current === undefined || current[token] === undefined) {
          return undefined;
        } else if (Array.isArray(current)) {
          current.splice(token, 1);
          return undefined;
        } else if (i === tokens.length - 1) {
          delete current[token];
        }

        current = current[token];
      } // delete from the target

    }
  }], [{
    key: "parse",
    value: function parse(expr) {
      return new JSONPointer(expr);
    }
  }]);

  return JSONPointer;
}();
/**
 * Exports
 */


module.exports = JSONPointer;

/***/ }),

/***/ "./lib/JSONSchema.js":
/*!***************************!*\
  !*** ./lib/JSONSchema.js ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Module dependencies
 * @ignore
 */

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _typeof(obj) { "@babel/helpers - typeof"; return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; })(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var Initializer = __webpack_require__(/*! ./Initializer */ "./lib/Initializer.js");

var Validator = __webpack_require__(/*! ./Validator */ "./lib/Validator.js");
/**
 * JSONSchema
 *
 * @class
 * Compiles JSON Schema documents to an object with object initialization
 * and validation methods.
 */


var JSONSchema = /*#__PURE__*/function () {
  /**
   * Constructor
   *
   * @param {Object} schema
   */
  function JSONSchema(schema) {
    _classCallCheck(this, JSONSchema);

    // TODO: optionally parse JSON string?
    Object.assign(this, schema); // add schema-derived initialize and validate methods

    Object.defineProperties(this, {
      initialize: {
        enumerable: false,
        writeable: false,
        value: Initializer.compile(schema)
      },
      validate: {
        enumerable: false,
        writeable: false,
        value: Validator.compile(schema)
      }
    });
  }
  /**
   * Extend
   *
   * @description
   * ...
   * Dear future,
   *
   * This function was meticulously plagiarized from some curious amalgam of
   * stackoverflow posts whilst dozing off at my keyboard, too deprived of REM-
   * sleep to recurse unassisted. If it sucks, you have only yourself to blame.
   *
   * Goodnight.
   *
   * @param {Object} schema
   * @returns {JSONSchema}
   */


  _createClass(JSONSchema, [{
    key: "extend",
    value: function extend(schema) {
      function isObject(data) {
        return data && _typeof(data) === 'object' && data !== null && !Array.isArray(data);
      }

      function extender(target, source) {
        var result = Object.assign({}, target);

        if (isObject(target) && isObject(source)) {
          Object.keys(source).forEach(function (key) {
            if (isObject(source[key])) {
              if (!(key in target)) {
                Object.assign(result, _defineProperty({}, key, source[key]));
              } else {
                result[key] = extender(target[key], source[key]);
              }
            } else {
              Object.assign(result, _defineProperty({}, key, source[key]));
            }
          });
        }

        return result;
      }

      var descriptor = extender(this, schema);
      return new JSONSchema(descriptor);
    }
  }]);

  return JSONSchema;
}();
/**
 * Export
 */


module.exports = JSONSchema;

/***/ }),

/***/ "./lib/Validator.js":
/*!**************************!*\
  !*** ./lib/Validator.js ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Module dependencies
 * @ignore
 */

function _typeof(obj) { "@babel/helpers - typeof"; return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; })(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

var formats = __webpack_require__(/*! ./Formats */ "./lib/Formats.js");
/**
 * For variable iterator counter
 *
 * @type {number}
 */


var indexCount = 0;
/**
 * Validator
 *
 * Compile an object describing a JSON Schema into a validation function.
 */

var Validator = /*#__PURE__*/function () {
  /**
   * Constructor
   *
   * @param {Object} schema - object representation of a schema
   * @param {string} options - compilation options
   */
  function Validator(schema) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    _classCallCheck(this, Validator);

    // assign schema to this
    this.schema = schema; // assign all options to this

    Object.assign(this, options); // ensure address is defined

    if (!this.address) {
      this.address = '';
    } // ensure require is boolean


    if (this.require !== true) {
      this.require = false;
    }
  }
  /**
   * Compile
   *
   * @description
   * The instance compile method is "dumb". It only sequences invocation of
   * more specific compilation methods. It generates code to
   *
   *  - read a value from input
   *  - validate type(s) of input
   *  - validate constraints described by various schema keywords
   *
   * Conditional logic related to code generation is pushed downsteam to
   * type-specific methods.
   */


  _createClass(Validator, [{
    key: "compile",
    value: function compile() {
      var block = "";

      if (this.require) {
        block += this.required();
      } // type validation


      block += this.type(); // type specific validation generators
      // null and boolean are covered by this.type()
      // integer should be covered by number and this.type()

      block += this.array();
      block += this.number();
      block += this.object();
      block += this.string(); // non-type-specific validation generators

      block += this["enum"]();
      block += this.anyOf();
      block += this.allOf();
      block += this.not();
      block += this.oneOf();
      return block;
    }
    /**
     * push
     */

  }, {
    key: "push",
    value: function push() {
      return "\n      stack.push(value)\n      container = value\n      top++\n    ";
    }
    /**
     * pop
     */

  }, {
    key: "pop",
    value: function pop() {
      return "\n      if (stack.length > 1) {\n        top--\n        stack.pop()\n      }\n\n      value = container = stack[top]\n    ";
    }
    /**
     * type
     *
     * @description
     * > An instance matches successfully if its primitive type is one of the
     * > types defined by keyword. Recall: "number" includes "integer".
     * > JSON Schema Validation Section 5.5.2
     *
     * @returns {string}
     */

  }, {
    key: "type",
    value: function type() {
      var type = this.schema.type,
          address = this.address;
      var block = "";

      if (type) {
        var types = Array.isArray(type) ? type : [type];
        var conditions = types.map(function (type) {
          // TODO: can we make a mapping object for this to clean it up?
          if (type === 'array') return "!Array.isArray(value)";
          if (type === 'boolean') return "typeof value !== 'boolean'";
          if (type === 'integer') return "!Number.isInteger(value)";
          if (type === 'null') return "value !== null";
          if (type === 'number') return "typeof value !== 'number'";
          if (type === 'object') return "(typeof value !== 'object' || Array.isArray(value) || value === null)";
          if (type === 'string') return "typeof value !== 'string'";
        }).join(' && ');
        block += "\n      // ".concat(address, " type checking\n      if (value !== undefined && ").concat(conditions, ") {\n        valid = false\n        errors.push({\n          keyword: 'type',\n          message: 'invalid type'\n        })\n      }\n      ");
      }

      return block;
    }
    /**
     * Type-specific validations
     *
     * Type checking is optional in JSON Schema, and a schema can allow
     * multiple types. Generated code needs to apply type-specific validations
     * only to appropriate values, and ignore everything else. Type validation
     * itself is handled separately from other validation keywords.
     *
     * The methods `array`, `number`, `object`, `string` generate type-specific
     * validation code blocks, wrapped in a conditional such that they will
     * only be applied to values of that type.
     *
     * For example, the `number` method, given the schema
     *
     *     { minimum: 3 }
     *
     * will generate
     *
     *     if (typeof value === 'number') {
     *       if (value < 3) {
     *         valid = false
     *         errors.push({ message: '...' })
     *       }
     *     }
     *
     * Integer values are also numbers, and are validated the same as numbers
     * other than the type validation itself. Therefore no `integer` method is
     * needed.
     */

    /**
     * array
     *
     * @description
     * Invoke methods for array-specific keywords and wrap resulting code in
     * type-checking conditional so that any resulting validations are only
     * applied to array values.
     *
     * @returns {string}
     */

  }, {
    key: "array",
    value: function array() {
      var keywords = ['additionalItems', 'items', 'minItems', 'maxItems', 'uniqueItems'];
      var validations = this.validations(keywords);
      var block = "";

      if (validations.length > 0) {
        block += "\n      /**\n       * Array validations\n       */\n      if (Array.isArray(value)) {\n      ".concat(validations, "\n      }\n      ");
      }

      return block;
    }
    /**
     * number
     *
     * @description
     * Invoke methods for number-specific keywords and wrap resulting code in
     * type-checking conditional so that any resulting validations are only
     * applied to number values.
     *
     * @returns {string}
     */

  }, {
    key: "number",
    value: function number() {
      var keywords = ['minimum', 'maximum', 'multipleOf'];
      var validations = this.validations(keywords);
      var block = "";

      if (validations.length > 0) {
        block += "\n      /**\n       * Number validations\n       */\n      if (typeof value === 'number') {\n      ".concat(validations, "\n      }\n      ");
      }

      return block;
    }
    /**
     * object
     *
     * @description
     * Invoke methods for object-specific keywords and wrap resulting code in
     * type-checking conditional so that any resulting validations are only
     * applied to object values.
     *
     * @returns {string}
     */

  }, {
    key: "object",
    value: function object() {
      var keywords = ['maxProperties', 'minProperties', 'additionalProperties', 'properties', 'patternProperties', 'dependencies', 'schemaDependencies', 'propertyDependencies'];
      var validations = this.validations(keywords);
      var block = "";

      if (validations.length > 0) {
        block += "\n      /**\n       * Object validations\n       */\n      if (typeof value === 'object' && value !== null && !Array.isArray(value)) {\n      ".concat(validations, "\n      }\n      ");
      }

      return block;
    }
    /**
     * string
     *
     * @description
     * Invoke methods for string-specific keywords and wrap resulting code in
     * type-checking conditional so that any resulting validations are only
     * applied to string values.
     *
     * @returns {string}
     */

  }, {
    key: "string",
    value: function string() {
      var keywords = ['maxLength', 'minLength', 'pattern', 'format'];
      var validations = this.validations(keywords);
      var block = "";

      if (validations.length > 0) {
        block += "\n      /**\n       * String validations\n       */\n      if (typeof value === 'string') {\n      ".concat(validations, "\n      }\n      ");
      }

      return block;
    }
    /**
     * validations
     *
     * @description
     * Iterate over an array of keywords and invoke code generator methods
     * for each. Concatenate the results together and return. Used by "type"
     * methods such as this.array() and this.string()
     *
     * @param {Array} keywords
     * @returns {string}
     */

  }, {
    key: "validations",
    value: function validations(keywords) {
      var _this = this;

      var schema = this.schema;
      var block = "";
      var constraints = Object.keys(schema).filter(function (key) {
        return keywords.indexOf(key) !== -1;
      });
      constraints.forEach(function (keyword) {
        block += _this[keyword]();
      });
      return block;
    }
    /**
     * enum
     *
     * @description
     * > An instance validates successfully against this keyword if its value
     * > is equal to one of the elements in this keyword's array value.
     * > JSON Schema Validation Section 5.5.1
     *
     * @returns {string}
     */

  }, {
    key: "enum",
    value: function _enum() {
      var enumerated = this.schema["enum"],
          address = this.address;
      var conditions = ['value !== undefined'];
      var block = "";

      if (enumerated) {
        enumerated.forEach(function (value) {
          switch (_typeof(value)) {
            case 'boolean':
              conditions.push("value !== ".concat(value));
              break;

            case 'number':
              conditions.push("value !== ".concat(value));
              break;

            case 'string':
              conditions.push("value !== \"".concat(value, "\""));
              break;

            case 'object':
              if (value === null) {
                conditions.push("value !== null");
              } else {
                conditions.push("'".concat(JSON.stringify(value), "' !== JSON.stringify(value)"));
              }

              break;

            default:
              throw new Error('Things are not well in the land of enum');
          }
        });
        block += "\n      /**\n       * Validate \"".concat(address, "\" enum\n       */\n      if (").concat(conditions.join(' && '), ") {\n        valid = false\n        errors.push({\n          keyword: 'enum',\n          message: JSON.stringify(value) + ' is not an enumerated value'\n        })\n      }\n      ");
      }

      return block;
    }
    /**
     * anyOf
     *
     * @description
     * > An instance validates successfully against this keyword if it
     * > validates successfully against at least one schema defined by this
     * > keyword's value.
     * > JSON Schema Validation Section 5.5.4
     *
     * @returns {string}
     */

  }, {
    key: "anyOf",
    value: function anyOf() {
      var anyOf = this.schema.anyOf,
          address = this.address;
      var block = "";

      if (Array.isArray(anyOf)) {
        block += "\n        initialValidity = valid\n        initialErrorCount = errors.length\n        anyValid = false\n      ";
        anyOf.forEach(function (subschema) {
          var validator = new Validator(subschema, {
            address: address
          });
          block += "\n        accumulatedErrorCount = errors.length\n        ".concat(validator.compile(), "\n        if (accumulatedErrorCount === errors.length) {\n          anyValid = true\n        }\n        ");
        });
        block += "\n          if (anyValid === true) {\n            valid = initialValidity\n            errors = errors.slice(0, initialErrorCount)\n          }\n      ";
      }

      return block;
    }
    /**
     * allOf
     *
     * @description
     * > An instance validates successfully against this keyword if it
     * > validates successfully against all schemas defined by this keyword's
     * > value.
     * > JSON Schema Validation Section 5.5.3
     *
     * @returns {string}
     */

  }, {
    key: "allOf",
    value: function allOf() {
      var allOf = this.schema.allOf,
          address = this.address;
      var block = "";

      if (Array.isArray(allOf)) {
        allOf.forEach(function (subschema) {
          var validator = new Validator(subschema, {
            address: address
          });
          block += "\n        ".concat(validator.compile(), "\n        ");
        });
      }

      return block;
    }
    /**
     * oneOf
     *
     * @description
     * > An instance validates successfully against this keyword if it
     * > validates successfully against exactly one schema defined by this
     * > keyword's value.
     * > JSON Schema Validation Section 5.5.5
     *
     * @returns {string}
     */

  }, {
    key: "oneOf",
    value: function oneOf() {
      var oneOf = this.schema.oneOf,
          address = this.address;
      var block = "";

      if (Array.isArray(oneOf)) {
        block += "\n        /**\n         * Validate ".concat(address, " oneOf\n         */\n        initialValidity = valid\n        initialErrorCount = errors.length\n        countOfValid = 0\n      ");
        oneOf.forEach(function (subschema) {
          var validator = new Validator(subschema, {
            address: address
          });
          block += "\n        accumulatedErrorCount = errors.length\n        ".concat(validator.compile(), "\n        if (accumulatedErrorCount === errors.length) {\n          countOfValid += 1\n        }\n        ");
        });
        block += "\n          if (countOfValid === 1) {\n            valid = initialValidity\n            errors = errors.slice(0, initialErrorCount)\n          } else {\n            valid = false\n            errors.push({\n              keyword: 'oneOf',\n              message: 'what is a reasonable error message for this case?'\n            })\n          }\n      ";
      }

      return block;
    }
    /**
     * not
     *
     * @description
     * > An instance is valid against this keyword if it fails to validate
     * > successfully against the schema defined by this keyword.
     * > JSON Schema Validation Section 5.5.6
     *
     * @returns {string}
     */

  }, {
    key: "not",
    value: function not() {
      var not = this.schema.not,
          address = this.address;
      var block = "";

      if (_typeof(not) === 'object' && not !== null && !Array.isArray(not)) {
        var subschema = not;
        var validator = new Validator(subschema, {
          address: address
        });
        block += "\n        /**\n         * NOT\n         */\n        if (value !== undefined) {\n          initialValidity = valid\n          initialErrorCount = errors.length\n          notValid = true\n\n          accumulatedErrorCount = errors.length\n\n          ".concat(validator.compile(), "\n\n          if (accumulatedErrorCount === errors.length) {\n            notValid = false\n          }\n\n          if (notValid === true) {\n            valid = initialValidity\n            errors = errors.slice(0, initialErrorCount)\n          } else {\n            valid = false\n            errors = errors.slice(0, initialErrorCount)\n            errors.push({\n              keyword: 'not',\n              message: 'hmm...'\n            })\n          }\n        }\n      ");
      }

      return block;
    }
    /**
     * properties
     *
     * @description
     * Iterate over the `properties` schema property if it is an object. For each
     * key, initialize a new Validator for the subschema represented by the property
     * value and invoke compile. Append the result of compiling each subschema to
     * the block of code being generated.
     *
     * @returns {string}
     */

  }, {
    key: "properties",
    value: function properties() {
      var schema = this.schema,
          address = this.address;
      var properties = schema.properties,
          required = schema.required;
      var block = this.push(); // ensure the value of "required" schema property is an array

      required = Array.isArray(required) ? required : [];

      if (_typeof(properties) === 'object') {
        Object.keys(properties).forEach(function (key) {
          var subschema = properties[key];
          var isRequired = required.indexOf(key) !== -1; // TODO
          // how should we be calculating these things? should be json pointer?
          // needs a separate function

          var pointer = [address, key].filter(function (segment) {
            return !!segment;
          }).join('.');
          var validation = new Validator(subschema, {
            address: pointer,
            require: isRequired
          }); // read the value

          block += "\n        value = container['".concat(key, "']\n        ");
          block += validation.compile();
        });
      }

      block += this.pop();
      return block;
    }
    /**
     * Other Properties
     *
     * @description
     * This method is not for a keyword. It wraps validations for
     * patternProperties and additionalProperties in a single iteration over
     * an object-type value's properties.
     *
     * It should only be invoked once for a given subschema.
     *
     * @returns {string}
     */

  }, {
    key: "otherProperties",
    value: function otherProperties() {
      return "\n      /**\n       * Validate Other Properties\n       */\n      ".concat(this.push(), "\n\n      for (let key in container) {\n        value = container[key]\n        matched = false\n\n        ").concat(this.patternValidations(), "\n        ").concat(this.additionalValidations(), "\n      }\n\n      ").concat(this.pop(), "\n    ");
    }
    /**
     * Pattern Validations
     *
     * @description
     * Generate validation code from a subschema for properties matching a
     * regular expression.
     *
     * @returns {string}
     */

  }, {
    key: "patternValidations",
    value: function patternValidations() {
      var patternProperties = this.schema.patternProperties;
      var block = "";

      if (_typeof(patternProperties) === 'object') {
        Object.keys(patternProperties).forEach(function (pattern) {
          var subschema = patternProperties[pattern];
          var validator = new Validator(subschema);
          block += "\n          if (key.match('".concat(pattern, "')) {\n            matched = true\n            ").concat(validator.compile(), "\n          }\n        ");
        });
      }

      return block;
    }
    /**
     * Additional Validations
     *
     * @description
     * Generate validation code, either from a subschema for properties not
     * defined in the schema, or to disallow properties not defined in the
     * schema.
     *
     * @returns {string}
     */

  }, {
    key: "additionalValidations",
    value: function additionalValidations() {
      var _this$schema = this.schema,
          properties = _this$schema.properties,
          additionalProperties = _this$schema.additionalProperties,
          address = this.address;
      var validations = "";
      var block = ""; // catch additional unmatched properties

      var conditions = ['matched !== true']; // ignore defined properties

      Object.keys(properties || {}).forEach(function (key) {
        conditions.push("key !== '".concat(key, "'"));
      }); // validate additional properties

      if (_typeof(additionalProperties) === 'object') {
        var subschema = additionalProperties;
        var validator = new Validator(subschema, {
          address: "".concat(address, "[APKey]")
        });
        block += "\n        // validate additional properties\n        if (".concat(conditions.join(' && '), ") {\n          ").concat(validator.compile(), "\n        }\n      ");
      } // error for additional properties


      if (additionalProperties === false) {
        block += "\n        // validate non-presence of additional properties\n        if (".concat(conditions.join(' && '), ") {\n          valid = false\n          errors.push({\n            keyword: 'additionalProperties',\n            message: key + ' is not a defined property'\n          })\n        }\n      ");
      }

      return block;
    }
    /**
     * patternProperties
     *
     * @description
     * Generate validation code for properties matching a pattern
     * defined by the property name (key), which must be a string
     * representing a valid regular expression.
     *
     * @returns {string}
     */

  }, {
    key: "patternProperties",
    value: function patternProperties() {
      var block = "";

      if (!this.otherPropertiesCalled) {
        this.otherPropertiesCalled = true;
        block += this.otherProperties();
      }

      return block;
    }
    /**
     * additionalProperties
     *
     * @description
     * Generate validation code for additional properties not defined
     * in the schema, or disallow additional properties if the value of
     * `additionalProperties` in the schema is `false`.
     *
     * @returns {string}
     */

  }, {
    key: "additionalProperties",
    value: function additionalProperties() {
      var block = "";

      if (!this.otherPropertiesCalled) {
        this.otherPropertiesCalled = true;
        block += this.otherProperties();
      }

      return block;
    }
    /**
     * minProperties
     *
     * @description
     * > An object instance is valid against "minProperties" if its number of
     * > properties is greater than, or equal to, the value of this keyword.
     * > JSON Schema Validation Section 5.4.2
     *
     * @returns {string}
     */

  }, {
    key: "minProperties",
    value: function minProperties() {
      var minProperties = this.schema.minProperties,
          address = this.address;
      return "\n        // ".concat(address, " min properties\n        if (Object.keys(value).length < ").concat(minProperties, ") {\n          valid = false\n          errors.push({\n            keyword: 'minProperties',\n            message: 'too few properties'\n          })\n        }\n    ");
    }
    /**
     * maxProperties
     *
     * @description
     * > An object instance is valid against "maxProperties" if its number of
     * > properties is less than, or equal to, the value of this keyword.
     * > JSON Schema Validation Section 5.4.1
     *
     * @returns {string}
     */

  }, {
    key: "maxProperties",
    value: function maxProperties() {
      var maxProperties = this.schema.maxProperties,
          address = this.address;
      return "\n        // ".concat(address, " max properties\n        if (Object.keys(value).length > ").concat(maxProperties, ") {\n          valid = false\n          errors.push({\n            keyword: 'maxProperties',\n            message: 'too many properties'\n          })\n        }\n    ");
    }
    /**
     * Dependencies
     *
     * @description
     * > For all (name, schema) pair of schema dependencies, if the instance has
     * > a property by this name, then it must also validate successfully against
     * > the schema.
     * >
     * > Note that this is the instance itself which must validate successfully,
     * > not the value associated with the property name.
     * >
     * > For each (name, propertyset) pair of property dependencies, if the
     * > instance has a property by this name, then it must also have properties
     * > with the same names as propertyset.
     * > JSON Schema Validation Section 5.4.5.2
     *
     * @returns {string}
     */

  }, {
    key: "dependencies",
    value: function dependencies() {
      var dependencies = this.schema.dependencies,
          address = this.address;
      var block = this.push();

      if (_typeof(dependencies) === 'object') {
        Object.keys(dependencies).forEach(function (key) {
          var dependency = dependencies[key];
          var conditions = [];

          if (Array.isArray(dependency)) {
            dependency.forEach(function (item) {
              conditions.push("container['".concat(item, "'] === undefined"));
            });
            block += "\n            if (container['".concat(key, "'] !== undefined && (").concat(conditions.join(' || '), ")) {\n              valid = false\n              errors.push({\n                keyword: 'dependencies',\n                message: 'unmet dependencies'\n              })\n            }\n          ");
          } else if (_typeof(dependency) === 'object') {
            var subschema = dependency;
            var validator = new Validator(subschema, {
              address: address
            });
            block += "\n            if (container['".concat(key, "'] !== undefined) {\n              ").concat(validator.compile(), "\n            }\n          ");
          }
        });
      }

      block += this.pop();
      return block;
    }
    /**
     * Required
     *
     * @description
     * > An object instance is valid against this keyword if its property set
     * > contains all elements in this keyword's array value.
     * > JSON Schema Validation Section 5.4.3
     *
     * @returns {string}
     */

  }, {
    key: "required",
    value: function required() {
      var properties = this.schema.properties,
          address = this.address;
      var block = "";
      block += "\n      // validate ".concat(address, " presence\n      if (value === undefined) {\n        valid = false\n        errors.push({\n          keyword: 'required',\n          message: 'is required'\n        })\n      }\n    ");
      return block;
    }
    /**
     * additionalItems
     *
     * @description
     * > Successful validation of an array instance with regards to these two
     * > keywords is determined as follows: if "items" is not present, or its
     * > value is an object, validation of the instance always succeeds,
     * > regardless of the value of "additionalItems"; if the value of
     * > "additionalItems" is boolean value true or an object, validation of
     * > the instance always succeeds; if the value of "additionalItems" is
     * > boolean value false and the value of "items" is an array, the
     * > instance is valid if its size is less than, or equal to, the size
     * > of "items".
     * > JSON Schema Validation Section 5.3.1
     *
     * @returns {string}
     */

  }, {
    key: "additionalItems",
    value: function additionalItems() {
      var _this$schema2 = this.schema,
          items = _this$schema2.items,
          additionalItems = _this$schema2.additionalItems,
          address = this.address;
      var block = "";

      if (additionalItems === false && Array.isArray(items)) {
        block += "\n        // don't allow additional items\n        if (value.length > ".concat(items.length, ") {\n          valid = false\n          errors.push({\n            keyword: 'additionalItems',\n            message: 'additional items not allowed'\n          })\n        }\n      ");
      }

      if (_typeof(additionalItems) === 'object' && additionalItems !== null && Array.isArray(items)) {
        var subschema = additionalItems;
        var validator = new Validator(subschema);
        var counter = Validator.counter;
        block += "\n        // additional items\n        ".concat(this.push(), "\n\n        for (var i").concat(counter, " = ").concat(items.length, "; i").concat(counter, " <= container.length; i").concat(counter, "++) {\n          value = container[i").concat(counter, "]\n          ").concat(validator.compile(), "\n        }\n\n        ").concat(this.pop(), "\n      ");
      }

      return block;
    }
    /**
     * Items
     *
     * @description
     * > Successful validation of an array instance with regards to these two
     * > keywords is determined as follows: if "items" is not present, or its
     * > value is an object, validation of the instance always succeeds,
     * > regardless of the value of "additionalItems"; if the value of
     * > "additionalItems" is boolean value true or an object, validation of
     * > the instance always succeeds; if the value of "additionalItems" is
     * > boolean value false and the value of "items" is an array, the
     * > instance is valid if its size is less than, or equal to, the size
     * > of "items".
     * > JSON Schema Validation Section 5.3.1
     *
     * Code to generate
     *
     *     // this outer conditional is generated by this.array()
     *     if (Array.isArray(value) {
     *       let parent = value
     *       for (let i = 0; i < parent.length; i++) {
     *         value = parent[i]
     *         // other validation code depending on value here
     *       }
     *       value = parent
     *     }
     *
     *
     * @returns {string}
     */

  }, {
    key: "items",
    value: function items() {
      var items = this.schema.items,
          address = this.address;
      var block = ""; // if items is an array

      if (Array.isArray(items)) {
        block += this.push();
        items.forEach(function (item, index) {
          var subschema = item;
          var validator = new Validator(subschema, {
            address: "".concat(address, "[").concat(index, "]")
          });
          block += "\n          // item #".concat(index, "\n          value = container[").concat(index, "]\n          ").concat(validator.compile(), "\n        ");
        });
        block += this.pop(); // if items is an object
      } else if (_typeof(items) === 'object' && items !== null) {
        var subschema = items;
        var validator = new Validator(subschema);
        var counter = Validator.counter;
        block += "\n        // items\n        ".concat(this.push(), "\n\n        for (var i").concat(counter, " = 0; i").concat(counter, " < container.length; i").concat(counter, "++) {\n          // read array element\n          value = container[i").concat(counter, "]\n          ").concat(validator.compile(), "\n        }\n\n        ").concat(this.pop(), "\n      ");
      }

      return block;
    }
    /**
     * minItems
     *
     * @description
     * > An array instance is valid against "minItems" if its size is greater
     * > than, or equal to, the value of this keyword.
     * > JSON Schema Validation Section 5.3.3
     *
     * @returns {string}
     */

  }, {
    key: "minItems",
    value: function minItems() {
      var minItems = this.schema.minItems,
          address = this.address;
      return "\n        // ".concat(address, " min items\n        if (value.length < ").concat(minItems, ") {\n          valid = false\n          errors.push({\n            keyword: 'minItems',\n            message: 'too few properties'\n          })\n        }\n    ");
    }
    /**
     * maxItems
     *
     * @description
     * > An array instance is valid against "maxItems" if its size is less
     * > than, or equal to, the value of this keyword.
     * > JSON Schema Validation Section 5.3.2
     *
     * @returns {string}
     */

  }, {
    key: "maxItems",
    value: function maxItems() {
      var maxItems = this.schema.maxItems,
          address = this.address;
      return "\n        // ".concat(address, " max items\n        if (value.length > ").concat(maxItems, ") {\n          valid = false\n          errors.push({\n            keyword: 'maxItems',\n            message: 'too many properties'\n          })\n        }\n    ");
    }
    /**
     * uniqueItems
     *
     * @description
     * > If this keyword has boolean value false, the instance validates
     * > successfully. If it has boolean value true, the instance validates
     * > successfully if all of its elements are unique.
     * > JSON Schema Validation Section 5.3.4
     *
     * TODO
     * optimize
     *
     * @returns {string}
     */

  }, {
    key: "uniqueItems",
    value: function uniqueItems() {
      var uniqueItems = this.schema.uniqueItems,
          address = this.address;
      var block = "";

      if (uniqueItems === true) {
        block += "\n        // validate ".concat(address, " unique items\n        let values = value.map(v => JSON.stringify(v)) // TODO: optimize\n        let set = new Set(values)\n        if (values.length !== set.size) {\n          valid = false\n          errors.push({\n            keyword: 'uniqueItems',\n            message: 'items must be unique'\n          })\n        }\n      ");
      }

      return block;
    }
    /**
     * minLength
     *
     * @description
     * > A string instance is valid against this keyword if its length is
     * > greater than, or equal to, the value of this keyword. The length of
     * > a string instance is defined as the number of its characters as
     * > defined by RFC 4627 [RFC4627].
     * > JSON Schema Validation Section 5.2.2
     *
     * @returns {string}
     */

  }, {
    key: "minLength",
    value: function minLength() {
      var minLength = this.schema.minLength,
          address = this.address;
      return "\n        // ".concat(address, " validate minLength\n        if (Array.from(value).length < ").concat(minLength, ") {\n          valid = false\n          errors.push({\n            keyword: 'minLength',\n            message: 'too short'\n          })\n        }\n    ");
    }
    /**
     * maxLength
     *
     * @description
     * > A string instance is valid against this keyword if its length is less
     * > than, or equal to, the value of this keyword. The length of a string
     * > instance is defined as the number of its characters as defined by
     * > RFC 4627 [RFC4627].
     * > JSON Schema Validation Section 5.2.1
     *
     * @returns {string}
     */

  }, {
    key: "maxLength",
    value: function maxLength() {
      var maxLength = this.schema.maxLength,
          address = this.address;
      return "\n        // ".concat(address, " validate maxLength\n        if (Array.from(value).length > ").concat(maxLength, ") {\n          valid = false\n          errors.push({\n            keyword: 'maxLength',\n            message: 'too long'\n          })\n        }\n    ");
    }
    /**
     * Pattern
     *
     * @description
     * > A string instance is considered valid if the regular expression
     * > matches the instance successfully.
     * > JSON Schema Validation Section 5.2.3
     *
     * @returns {string}
     */

  }, {
    key: "pattern",
    value: function pattern() {
      var pattern = this.schema.pattern,
          address = this.address;

      if (pattern) {
        return "\n          // ".concat(address, " validate pattern\n          if (!value.match(new RegExp('").concat(pattern, "'))) {\n            valid = false\n            errors.push({\n              keyword: 'pattern',\n              message: 'does not match the required pattern'\n            })\n          }\n      ");
      }
    }
    /**
     * Format
     *
     * @description
     * > Structural validation alone may be insufficient to validate that
     * > an instance meets all the requirements of an application. The
     * > "format" keyword is defined to allow interoperable semantic
     * > validation for a fixed subset of values which are accurately
     * > described by authoritative resources, be they RFCs or other
     * > external specifications.
     * > JSON Schema Validation Section 7.1
     *
     * @returns {string}
     */

  }, {
    key: "format",
    value: function format() {
      var format = this.schema.format,
          address = this.address;
      var matcher = formats.resolve(format);

      if (matcher) {
        return "\n      // ".concat(address, " validate format\n      if (!value.match(").concat(matcher, ")) {\n        valid = false\n        errors.push({\n          keyword: 'format',\n          message: 'is not \"").concat(format, "\" format'\n        })\n      }\n      ");
      }
    }
    /**
     * Minimum
     *
     * @description
     * > Successful validation depends on the presence and value of
     * > "exclusiveMinimum": if "exclusiveMinimum" is not present, or has
     * > boolean value false, then the instance is valid if it is greater
     * > than, or equal to, the value of "minimum"; if "exclusiveMinimum" is
     * > present and has boolean value true, the instance is valid if it is
     * > strictly greater than the value of "minimum".
     * > JSON Schema Validation Section 5.1.3
     *
     * @returns {string}
     */

  }, {
    key: "minimum",
    value: function minimum() {
      var _this$schema3 = this.schema,
          minimum = _this$schema3.minimum,
          exclusiveMinimum = _this$schema3.exclusiveMinimum,
          address = this.address;
      var operator = exclusiveMinimum === true ? '<=' : '<';
      return "\n        // ".concat(address, " validate minimum\n        if (value ").concat(operator, " ").concat(minimum, ") {\n          valid = false\n          errors.push({\n            keyword: 'minimum',\n            message: 'too small'\n          })\n        }\n    ");
    }
    /**
     * Maximum
     *
     * @description
     * > Successful validation depends on the presence and value of
     * > "exclusiveMaximum": if "exclusiveMaximum" is not present, or has
     * > boolean value false, then the instance is valid if it is lower than,
     * > or equal to, the value of "maximum"; if "exclusiveMaximum" has
     * > boolean value true, the instance is valid if it is strictly lower
     * > than the value of "maximum".
     * > JSON Schema Validation Section 5.1.2
     *
     * @returns {string}
     */

  }, {
    key: "maximum",
    value: function maximum() {
      var _this$schema4 = this.schema,
          maximum = _this$schema4.maximum,
          exclusiveMaximum = _this$schema4.exclusiveMaximum,
          address = this.address;
      var operator = exclusiveMaximum === true ? '>=' : '>';
      return "\n        // ".concat(address, " validate maximum\n        if (value ").concat(operator, " ").concat(maximum, ") {\n          valid = false\n          errors.push({\n            keyword: 'maximum',\n            message: 'too large'\n          })\n        }\n    ");
    }
    /**
     * multipleOf
     *
     * @description
     * > A numeric instance is valid against "multipleOf" if the result of
     * > the division of the instance by this keyword's value is an integer.
     * > JSON Schema Validation Section 5.1.1
     *
     * @returns {string}
     */

  }, {
    key: "multipleOf",
    value: function multipleOf() {
      var multipleOf = this.schema.multipleOf;
      var block = "";

      if (typeof multipleOf === 'number') {
        var length = multipleOf.toString().length;
        var decimals = length - multipleOf.toFixed(0).length - 1;
        var pow = decimals > 0 ? Math.pow(10, decimals) : 1;
        var condition;

        if (decimals > 0) {
          condition = "(value * ".concat(pow, ") % ").concat(multipleOf * pow, " !== 0");
        } else {
          condition = "value % ".concat(multipleOf, " !== 0");
        }

        block += "\n        if (".concat(condition, ") {\n          valid = false\n          errors.push({\n            keyword: 'multipleOf',\n            message: 'must be a multiple of ").concat(multipleOf, "'\n          })\n        }\n      ");
      }

      return block;
    }
  }], [{
    key: "compile",
    value:
    /**
     * Compile (static)
     *
     * @description
     * Compile an object describing a JSON Schema into a validation function.
     *
     * @param {Object} schema
     * @returns {Function}
     */
    function compile(schema) {
      var validator = new Validator(schema);
      var body = "\n      // \"cursor\"\n      let value = data\n      let container\n      let stack = []\n      let top = -1\n\n      // error state\n      let valid = true\n      let errors = []\n\n      // complex schema state\n      let initialValidity\n      let anyValid\n      let notValid\n      let countOfValid\n      let initialErrorCount\n      let accumulatedErrorCount\n\n      // validation code\n      ".concat(validator.compile(), "\n\n      // validation result\n      return {\n        valid,\n        errors\n      }\n    ");
      return new Function('data', body);
    }
    /**
     * Return current iterator index counter and increase value
     *
     * @returns {number}
     */

  }, {
    key: "counter",
    get: function get() {
      return indexCount++;
    }
  }]);

  return Validator;
}();
/**
 * Export
 */


module.exports = Validator;

/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  Formats: __webpack_require__(/*! ./Formats */ "./lib/Formats.js"),
  Initializer: __webpack_require__(/*! ./Initializer */ "./lib/Initializer.js"),
  JSONDocument: __webpack_require__(/*! ./JSONDocument */ "./lib/JSONDocument.js"),
  JSONMapping: __webpack_require__(/*! ./JSONMapping */ "./lib/JSONMapping.js"),
  JSONPatch: __webpack_require__(/*! ./JSONPatch */ "./lib/JSONPatch.js"),
  JSONPointer: __webpack_require__(/*! ./JSONPointer */ "./lib/JSONPointer.js"),
  JSONSchema: __webpack_require__(/*! ./JSONSchema */ "./lib/JSONSchema.js"),
  Validator: __webpack_require__(/*! ./Validator */ "./lib/Validator.js")
};

/***/ }),

/***/ 0:
/*!****************************!*\
  !*** multi ./lib/index.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./lib/index.js */"./lib/index.js");


/***/ })

/******/ });
//# sourceMappingURL=json-document.js.map