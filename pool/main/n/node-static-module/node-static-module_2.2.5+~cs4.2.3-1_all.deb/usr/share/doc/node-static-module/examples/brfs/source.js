var fs = require('fs');
var src = fs.readFileSync(__dirname + '/x.txt');
console.log(src);
