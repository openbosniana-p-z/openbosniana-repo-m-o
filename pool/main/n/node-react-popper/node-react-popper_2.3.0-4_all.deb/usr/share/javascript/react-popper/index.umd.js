(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('react'), require('react-dom'), require('@popperjs/core'), require('react-fast-compare'), require('warning')) :
  typeof define === 'function' && define.amd ? define(['exports', 'react', 'react-dom', '@popperjs/core', 'react-fast-compare', 'warning'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global.ReactPopper = {}, global.React, global.ReactDOM, global.Popper, global.isEqual, global.warning));
})(this, (function (exports, React, ReactDOM, core, isEqual, warning) { 'use strict';

  function _interopNamespaceDefault(e) {
    var n = Object.create(null);
    if (e) {
      Object.keys(e).forEach(function (k) {
        if (k !== 'default') {
          var d = Object.getOwnPropertyDescriptor(e, k);
          Object.defineProperty(n, k, d.get ? d : {
            enumerable: true,
            get: function () { return e[k]; }
          });
        }
      });
    }
    n.default = e;
    return Object.freeze(n);
  }

  var React__namespace = /*#__PURE__*/_interopNamespaceDefault(React);
  var ReactDOM__namespace = /*#__PURE__*/_interopNamespaceDefault(ReactDOM);

  var ManagerReferenceNodeContext = /*#__PURE__*/React__namespace.createContext();
  var ManagerReferenceNodeSetterContext = /*#__PURE__*/React__namespace.createContext();
  function Manager(_ref) {
    var children = _ref.children;
    var _React$useState = React__namespace.useState(null),
      referenceNode = _React$useState[0],
      setReferenceNode = _React$useState[1];
    var hasUnmounted = React__namespace.useRef(false);
    React__namespace.useEffect(function () {
      return function () {
        hasUnmounted.current = true;
      };
    }, []);
    var handleSetReferenceNode = React__namespace.useCallback(function (node) {
      if (!hasUnmounted.current) {
        setReferenceNode(node);
      }
    }, []);
    return /*#__PURE__*/React__namespace.createElement(ManagerReferenceNodeContext.Provider, {
      value: referenceNode
    }, /*#__PURE__*/React__namespace.createElement(ManagerReferenceNodeSetterContext.Provider, {
      value: handleSetReferenceNode
    }, children));
  }

  /**
   * Takes an argument and if it's an array, returns the first item in the array,
   * otherwise returns the argument. Used for Preact compatibility.
   */
  var unwrapArray = function unwrapArray(arg) {
    return Array.isArray(arg) ? arg[0] : arg;
  };

  /**
   * Takes a maybe-undefined function and arbitrary args and invokes the function
   * only if it is defined.
   */
  var safeInvoke = function safeInvoke(fn) {
    if (typeof fn === 'function') {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      return fn.apply(void 0, args);
    }
  };

  /**
   * Sets a ref using either a ref callback or a ref object
   */
  var setRef = function setRef(ref, node) {
    // if its a function call it
    if (typeof ref === 'function') {
      return safeInvoke(ref, node);
    }
    // otherwise we should treat it as a ref object
    else if (ref != null) {
      ref.current = node;
    }
  };

  /**
   * Simple ponyfill for Object.fromEntries
   */
  var fromEntries = function fromEntries(entries) {
    return entries.reduce(function (acc, _ref) {
      var key = _ref[0],
        value = _ref[1];
      acc[key] = value;
      return acc;
    }, {});
  };

  /**
   * Small wrapper around `useLayoutEffect` to get rid of the warning on SSR envs
   */
  var useIsomorphicLayoutEffect = typeof window !== 'undefined' && window.document && window.document.createElement ? React__namespace.useLayoutEffect : React__namespace.useEffect;

  var EMPTY_MODIFIERS$1 = [];
  var usePopper = function usePopper(referenceElement, popperElement, options) {
    if (options === void 0) {
      options = {};
    }
    var prevOptions = React__namespace.useRef(null);
    var optionsWithDefaults = {
      onFirstUpdate: options.onFirstUpdate,
      placement: options.placement || 'bottom',
      strategy: options.strategy || 'absolute',
      modifiers: options.modifiers || EMPTY_MODIFIERS$1
    };
    var _React$useState = React__namespace.useState({
        styles: {
          popper: {
            position: optionsWithDefaults.strategy,
            left: '0',
            top: '0'
          },
          arrow: {
            position: 'absolute'
          }
        },
        attributes: {}
      }),
      state = _React$useState[0],
      setState = _React$useState[1];
    var updateStateModifier = React__namespace.useMemo(function () {
      return {
        name: 'updateState',
        enabled: true,
        phase: 'write',
        fn: function fn(_ref) {
          var state = _ref.state;
          var elements = Object.keys(state.elements);
          ReactDOM__namespace.flushSync(function () {
            setState({
              styles: fromEntries(elements.map(function (element) {
                return [element, state.styles[element] || {}];
              })),
              attributes: fromEntries(elements.map(function (element) {
                return [element, state.attributes[element]];
              }))
            });
          });
        },
        requires: ['computeStyles']
      };
    }, []);
    var popperOptions = React__namespace.useMemo(function () {
      var newOptions = {
        onFirstUpdate: optionsWithDefaults.onFirstUpdate,
        placement: optionsWithDefaults.placement,
        strategy: optionsWithDefaults.strategy,
        modifiers: [].concat(optionsWithDefaults.modifiers, [updateStateModifier, {
          name: 'applyStyles',
          enabled: false
        }])
      };
      if (isEqual(prevOptions.current, newOptions)) {
        return prevOptions.current || newOptions;
      } else {
        prevOptions.current = newOptions;
        return newOptions;
      }
    }, [optionsWithDefaults.onFirstUpdate, optionsWithDefaults.placement, optionsWithDefaults.strategy, optionsWithDefaults.modifiers, updateStateModifier]);
    var popperInstanceRef = React__namespace.useRef();
    useIsomorphicLayoutEffect(function () {
      if (popperInstanceRef.current) {
        popperInstanceRef.current.setOptions(popperOptions);
      }
    }, [popperOptions]);
    useIsomorphicLayoutEffect(function () {
      if (referenceElement == null || popperElement == null) {
        return;
      }
      var createPopper = options.createPopper || core.createPopper;
      var popperInstance = createPopper(referenceElement, popperElement, popperOptions);
      popperInstanceRef.current = popperInstance;
      return function () {
        popperInstance.destroy();
        popperInstanceRef.current = null;
      };
    }, [referenceElement, popperElement, options.createPopper]);
    return {
      state: popperInstanceRef.current ? popperInstanceRef.current.state : null,
      styles: state.styles,
      attributes: state.attributes,
      update: popperInstanceRef.current ? popperInstanceRef.current.update : null,
      forceUpdate: popperInstanceRef.current ? popperInstanceRef.current.forceUpdate : null
    };
  };

  var NOOP = function NOOP() {
    return void 0;
  };
  var NOOP_PROMISE = function NOOP_PROMISE() {
    return Promise.resolve(null);
  };
  var EMPTY_MODIFIERS = [];
  function Popper(_ref) {
    var _ref$placement = _ref.placement,
      placement = _ref$placement === void 0 ? 'bottom' : _ref$placement,
      _ref$strategy = _ref.strategy,
      strategy = _ref$strategy === void 0 ? 'absolute' : _ref$strategy,
      _ref$modifiers = _ref.modifiers,
      modifiers = _ref$modifiers === void 0 ? EMPTY_MODIFIERS : _ref$modifiers,
      referenceElement = _ref.referenceElement,
      onFirstUpdate = _ref.onFirstUpdate,
      innerRef = _ref.innerRef,
      children = _ref.children;
    var referenceNode = React__namespace.useContext(ManagerReferenceNodeContext);
    var _React$useState = React__namespace.useState(null),
      popperElement = _React$useState[0],
      setPopperElement = _React$useState[1];
    var _React$useState2 = React__namespace.useState(null),
      arrowElement = _React$useState2[0],
      setArrowElement = _React$useState2[1];
    React__namespace.useEffect(function () {
      setRef(innerRef, popperElement);
    }, [innerRef, popperElement]);
    var options = React__namespace.useMemo(function () {
      return {
        placement: placement,
        strategy: strategy,
        onFirstUpdate: onFirstUpdate,
        modifiers: [].concat(modifiers, [{
          name: 'arrow',
          enabled: arrowElement != null,
          options: {
            element: arrowElement
          }
        }])
      };
    }, [placement, strategy, onFirstUpdate, modifiers, arrowElement]);
    var _usePopper = usePopper(referenceElement || referenceNode, popperElement, options),
      state = _usePopper.state,
      styles = _usePopper.styles,
      forceUpdate = _usePopper.forceUpdate,
      update = _usePopper.update;
    var childrenProps = React__namespace.useMemo(function () {
      return {
        ref: setPopperElement,
        style: styles.popper,
        placement: state ? state.placement : placement,
        hasPopperEscaped: state && state.modifiersData.hide ? state.modifiersData.hide.hasPopperEscaped : null,
        isReferenceHidden: state && state.modifiersData.hide ? state.modifiersData.hide.isReferenceHidden : null,
        arrowProps: {
          style: styles.arrow,
          ref: setArrowElement
        },
        forceUpdate: forceUpdate || NOOP,
        update: update || NOOP_PROMISE
      };
    }, [setPopperElement, setArrowElement, placement, state, styles, update, forceUpdate]);
    return unwrapArray(children)(childrenProps);
  }

  function Reference(_ref) {
    var children = _ref.children,
      innerRef = _ref.innerRef;
    var setReferenceNode = React__namespace.useContext(ManagerReferenceNodeSetterContext);
    var refHandler = React__namespace.useCallback(function (node) {
      setRef(innerRef, node);
      safeInvoke(setReferenceNode, node);
    }, [innerRef, setReferenceNode]);

    // ran on unmount
    // eslint-disable-next-line react-hooks/exhaustive-deps
    React__namespace.useEffect(function () {
      return function () {
        return setRef(innerRef, null);
      };
    }, []);
    React__namespace.useEffect(function () {
      warning(Boolean(setReferenceNode), '`Reference` should not be used outside of a `Manager` component.');
    }, [setReferenceNode]);
    return unwrapArray(children)({
      ref: refHandler
    });
  }

  exports.Manager = Manager;
  exports.Popper = Popper;
  exports.Reference = Reference;
  exports.usePopper = usePopper;

}));
