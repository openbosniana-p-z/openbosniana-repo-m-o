export {default as path} from "./path.js";
