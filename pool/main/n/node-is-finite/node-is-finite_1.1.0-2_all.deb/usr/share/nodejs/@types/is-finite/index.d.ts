// Type definitions for is-finite 1.0
// Project: https://github.com/sindresorhus/is-finite#readme
// Definitions by: Mohamed Hegazy <https://github.com/mhegazy>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

export = is_finite;
declare function is_finite(p0: any): boolean;
