import PersistentFile = require("./PersistentFile");

declare const VolatileFile: typeof PersistentFile;

export = VolatileFile;
