declare function parseDate(isoDate: string): Date | number | null
declare function parseDate(isoDate: null | undefined): null
export default parseDate
