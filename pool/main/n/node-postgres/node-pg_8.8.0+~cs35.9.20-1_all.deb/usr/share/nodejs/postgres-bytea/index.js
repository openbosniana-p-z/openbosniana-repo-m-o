'use strict'

exports = module.exports = require('./decode')

exports.Encoder = require('./encoder')
exports.Decoder = require('./decoder')
