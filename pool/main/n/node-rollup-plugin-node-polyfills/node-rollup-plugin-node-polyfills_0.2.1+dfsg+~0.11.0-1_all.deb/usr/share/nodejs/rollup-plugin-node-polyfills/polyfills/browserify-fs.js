import require$$0 from 'buffer';
import require$$0$1 from 'events';
import require$$1$1 from 'util';
import require$$1 from 'readable-stream';
import require$$8 from 'assert';
import require$$3$1 from 'stream';
import require$$6$1 from 'string_decoder/';
import require$$4 from 'once';
import require$$0$2 from 'path';

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

function getAugmentedNamespace(n) {
  var f = n.default;
	if (typeof f == "function") {
		var a = function () {
			return f.apply(this, arguments);
		};
		a.prototype = f.prototype;
  } else a = {};
  Object.defineProperty(a, '__esModule', {value: true});
	Object.keys(n).forEach(function (k) {
		var d = Object.getOwnPropertyDescriptor(n, k);
		Object.defineProperty(a, k, d.get ? d : {
			enumerable: true,
			get: function () {
				return n[k];
			}
		});
	});
	return a;
}

var abstractLeveldown$1 = {};

var immutable = extend$3;

var hasOwnProperty$2 = Object.prototype.hasOwnProperty;

function extend$3() {
    var target = {};

    for (var i = 0; i < arguments.length; i++) {
        var source = arguments[i];

        for (var key in source) {
            if (hasOwnProperty$2.call(source, key)) {
                target[key] = source[key];
            }
        }
    }

    return target
}

var mutable = extend$2;

var hasOwnProperty$1 = Object.prototype.hasOwnProperty;

function extend$2(target) {
    for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];

        for (var key in source) {
            if (hasOwnProperty$1.call(source, key)) {
                target[key] = source[key];
            }
        }
    }

    return target
}

// For (old) browser support
var xtend$2 = immutable;
var assign = mutable;

var levelSupports = function supports () {
  var manifest = xtend$2.apply(null, arguments);

  return assign(manifest, {
    // Features of abstract-leveldown
    bufferKeys: manifest.bufferKeys || false,
    snapshots: manifest.snapshots || false,
    permanence: manifest.permanence || false,
    seek: manifest.seek || false,
    clear: manifest.clear || false,

    // Features of abstract-leveldown that levelup doesn't have
    status: manifest.status || false,

    // Features of disk-based implementations
    createIfMissing: manifest.createIfMissing || false,
    errorIfExists: manifest.errorIfExists || false,

    // Features of level(up) that abstract-leveldown doesn't have yet
    deferredOpen: manifest.deferredOpen || false,
    openCallback: manifest.openCallback || false,
    promises: manifest.promises || false,
    streams: manifest.streams || false,
    encodings: manifest.encodings || false,

    // Methods that are not part of abstract-leveldown or levelup
    additionalMethods: xtend$2(manifest.additionalMethods)
  })
};

var nextTickBrowser = {exports: {}};

var _nodeResolve_empty = {};

var _nodeResolve_empty$1 = /*#__PURE__*/Object.freeze({
	__proto__: null,
	'default': _nodeResolve_empty
});

var require$$6 = /*@__PURE__*/getAugmentedNamespace(_nodeResolve_empty$1);

var queueMicrotask = {};

queueMicrotask.test = function () {
  return typeof commonjsGlobal.queueMicrotask === 'function';
};

queueMicrotask.install = function (func) {
  return function () {
    commonjsGlobal.queueMicrotask(func);
  };
};

var mutation = {};

//based off rsvp https://github.com/tildeio/rsvp.js
//license https://github.com/tildeio/rsvp.js/blob/master/LICENSE
//https://github.com/tildeio/rsvp.js/blob/master/lib/rsvp/asap.js

var Mutation = commonjsGlobal.MutationObserver || commonjsGlobal.WebKitMutationObserver;

mutation.test = function () {
  return Mutation;
};

mutation.install = function (handle) {
  var called = 0;
  var observer = new Mutation(handle);
  var element = commonjsGlobal.document.createTextNode('');
  observer.observe(element, {
    characterData: true
  });
  return function () {
    element.data = (called = ++called % 2);
  };
};

var messageChannel = {};

messageChannel.test = function () {
  if (commonjsGlobal.setImmediate) {
    // we can only get here in IE10
    // which doesn't handel postMessage well
    return false;
  }
  return typeof commonjsGlobal.MessageChannel !== 'undefined';
};

messageChannel.install = function (func) {
  var channel = new commonjsGlobal.MessageChannel();
  channel.port1.onmessage = func;
  return function () {
    channel.port2.postMessage(0);
  };
};

var stateChange = {};

stateChange.test = function () {
  return 'document' in commonjsGlobal && 'onreadystatechange' in commonjsGlobal.document.createElement('script');
};

stateChange.install = function (handle) {
  return function () {

    // Create a <script> element; its readystatechange event will be fired asynchronously once it is inserted
    // into the document. Do so, thus queuing up the task. Remember to clean up once it's been called.
    var scriptEl = commonjsGlobal.document.createElement('script');
    scriptEl.onreadystatechange = function () {
      handle();

      scriptEl.onreadystatechange = null;
      scriptEl.parentNode.removeChild(scriptEl);
      scriptEl = null;
    };
    commonjsGlobal.document.documentElement.appendChild(scriptEl);

    return handle;
  };
};

var timeout = {};

timeout.test = function () {
  return true;
};

timeout.install = function (t) {
  return function () {
    setTimeout(t, 0);
  };
};

var types = [
  require$$6,
  queueMicrotask,
  mutation,
  messageChannel,
  stateChange,
  timeout
];
var draining;
var currentQueue;
var queueIndex = -1;
var queue = [];
var scheduled = false;
function cleanUpNextTick() {
  if (!draining || !currentQueue) {
    return;
  }
  draining = false;
  if (currentQueue.length) {
    queue = currentQueue.concat(queue);
  } else {
    queueIndex = -1;
  }
  if (queue.length) {
    nextTick$4();
  }
}

//named nextTick for less confusing stack traces
function nextTick$4() {
  if (draining) {
    return;
  }
  scheduled = false;
  draining = true;
  var len = queue.length;
  var timeout = setTimeout(cleanUpNextTick);
  while (len) {
    currentQueue = queue;
    queue = [];
    while (currentQueue && ++queueIndex < len) {
      currentQueue[queueIndex].run();
    }
    queueIndex = -1;
    len = queue.length;
  }
  currentQueue = null;
  queueIndex = -1;
  draining = false;
  clearTimeout(timeout);
}
var scheduleDrain;
var i = -1;
var len = types.length;
while (++i < len) {
  if (types[i] && types[i].test && types[i].test()) {
    scheduleDrain = types[i].install(nextTick$4);
    break;
  }
}
// v8 likes predictible objects
function Item(fun, array) {
  this.fun = fun;
  this.array = array;
}
Item.prototype.run = function () {
  var fun = this.fun;
  var array = this.array;
  switch (array.length) {
  case 0:
    return fun();
  case 1:
    return fun(array[0]);
  case 2:
    return fun(array[0], array[1]);
  case 3:
    return fun(array[0], array[1], array[2]);
  default:
    return fun.apply(null, array);
  }

};
var lib = immediate;
function immediate(task) {
  var args = new Array(arguments.length - 1);
  if (arguments.length > 1) {
    for (var i = 1; i < arguments.length; i++) {
      args[i - 1] = arguments[i];
    }
  }
  queue.push(new Item(task, args));
  if (!scheduled && !draining) {
    scheduled = true;
    scheduleDrain();
  }
}

(function (module) {
	module.exports = lib;
} (nextTickBrowser));

var nextTick$3 = nextTickBrowser.exports;

function AbstractIterator$3 (db) {
  if (typeof db !== 'object' || db === null) {
    throw new TypeError('First argument must be an abstract-leveldown compliant store')
  }

  this.db = db;
  this._ended = false;
  this._nexting = false;
}

AbstractIterator$3.prototype.next = function (callback) {
  var self = this;

  if (typeof callback !== 'function') {
    throw new Error('next() requires a callback argument')
  }

  if (self._ended) {
    nextTick$3(callback, new Error('cannot call next() after end()'));
    return self
  }

  if (self._nexting) {
    nextTick$3(callback, new Error('cannot call next() before previous next() has completed'));
    return self
  }

  self._nexting = true;
  self._next(function () {
    self._nexting = false;
    callback.apply(null, arguments);
  });

  return self
};

AbstractIterator$3.prototype._next = function (callback) {
  nextTick$3(callback);
};

AbstractIterator$3.prototype.seek = function (target) {
  if (this._ended) {
    throw new Error('cannot call seek() after end()')
  }
  if (this._nexting) {
    throw new Error('cannot call seek() before next() has completed')
  }

  target = this.db._serializeKey(target);
  this._seek(target);
};

AbstractIterator$3.prototype._seek = function (target) {};

AbstractIterator$3.prototype.end = function (callback) {
  if (typeof callback !== 'function') {
    throw new Error('end() requires a callback argument')
  }

  if (this._ended) {
    return nextTick$3(callback, new Error('end() already called on iterator'))
  }

  this._ended = true;
  this._end(callback);
};

AbstractIterator$3.prototype._end = function (callback) {
  nextTick$3(callback);
};

// Expose browser-compatible nextTick for dependents
AbstractIterator$3.prototype._nextTick = nextTick$3;

var abstractIterator = AbstractIterator$3;

var nextTick$2 = nextTickBrowser.exports;

function AbstractChainedBatch$1 (db) {
  if (typeof db !== 'object' || db === null) {
    throw new TypeError('First argument must be an abstract-leveldown compliant store')
  }

  this.db = db;
  this._operations = [];
  this._written = false;
}

AbstractChainedBatch$1.prototype._checkWritten = function () {
  if (this._written) {
    throw new Error('write() already called on this batch')
  }
};

AbstractChainedBatch$1.prototype.put = function (key, value) {
  this._checkWritten();

  var err = this.db._checkKey(key) || this.db._checkValue(value);
  if (err) throw err

  key = this.db._serializeKey(key);
  value = this.db._serializeValue(value);

  this._put(key, value);

  return this
};

AbstractChainedBatch$1.prototype._put = function (key, value) {
  this._operations.push({ type: 'put', key: key, value: value });
};

AbstractChainedBatch$1.prototype.del = function (key) {
  this._checkWritten();

  var err = this.db._checkKey(key);
  if (err) throw err

  key = this.db._serializeKey(key);
  this._del(key);

  return this
};

AbstractChainedBatch$1.prototype._del = function (key) {
  this._operations.push({ type: 'del', key: key });
};

AbstractChainedBatch$1.prototype.clear = function () {
  this._checkWritten();
  this._clear();

  return this
};

AbstractChainedBatch$1.prototype._clear = function () {
  this._operations = [];
};

AbstractChainedBatch$1.prototype.write = function (options, callback) {
  this._checkWritten();

  if (typeof options === 'function') { callback = options; }
  if (typeof callback !== 'function') {
    throw new Error('write() requires a callback argument')
  }
  if (typeof options !== 'object' || options === null) {
    options = {};
  }

  this._written = true;
  this._write(options, callback);
};

AbstractChainedBatch$1.prototype._write = function (options, callback) {
  this.db._batch(this._operations, options, callback);
};

// Expose browser-compatible nextTick for dependents
AbstractChainedBatch$1.prototype._nextTick = nextTick$2;

var abstractChainedBatch = AbstractChainedBatch$1;

var xtend$1 = immutable;
var supports$1 = levelSupports;
var Buffer$4 = require$$0.Buffer;
var AbstractIterator$2 = abstractIterator;
var AbstractChainedBatch = abstractChainedBatch;
var nextTick$1 = nextTickBrowser.exports;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var rangeOptions = 'start end gt gte lt lte'.split(' ');

function AbstractLevelDOWN$2 (manifest) {
  this.status = 'new';

  // TODO (next major): make this mandatory
  this.supports = supports$1(manifest, {
    status: true
  });
}

AbstractLevelDOWN$2.prototype.open = function (options, callback) {
  var self = this;
  var oldStatus = this.status;

  if (typeof options === 'function') callback = options;

  if (typeof callback !== 'function') {
    throw new Error('open() requires a callback argument')
  }

  if (typeof options !== 'object' || options === null) options = {};

  options.createIfMissing = options.createIfMissing !== false;
  options.errorIfExists = !!options.errorIfExists;

  this.status = 'opening';
  this._open(options, function (err) {
    if (err) {
      self.status = oldStatus;
      return callback(err)
    }
    self.status = 'open';
    callback();
  });
};

AbstractLevelDOWN$2.prototype._open = function (options, callback) {
  nextTick$1(callback);
};

AbstractLevelDOWN$2.prototype.close = function (callback) {
  var self = this;
  var oldStatus = this.status;

  if (typeof callback !== 'function') {
    throw new Error('close() requires a callback argument')
  }

  this.status = 'closing';
  this._close(function (err) {
    if (err) {
      self.status = oldStatus;
      return callback(err)
    }
    self.status = 'closed';
    callback();
  });
};

AbstractLevelDOWN$2.prototype._close = function (callback) {
  nextTick$1(callback);
};

AbstractLevelDOWN$2.prototype.get = function (key, options, callback) {
  if (typeof options === 'function') callback = options;

  if (typeof callback !== 'function') {
    throw new Error('get() requires a callback argument')
  }

  var err = this._checkKey(key);
  if (err) return nextTick$1(callback, err)

  key = this._serializeKey(key);

  if (typeof options !== 'object' || options === null) options = {};

  options.asBuffer = options.asBuffer !== false;

  this._get(key, options, callback);
};

AbstractLevelDOWN$2.prototype._get = function (key, options, callback) {
  nextTick$1(function () { callback(new Error('NotFound')); });
};

AbstractLevelDOWN$2.prototype.put = function (key, value, options, callback) {
  if (typeof options === 'function') callback = options;

  if (typeof callback !== 'function') {
    throw new Error('put() requires a callback argument')
  }

  var err = this._checkKey(key) || this._checkValue(value);
  if (err) return nextTick$1(callback, err)

  key = this._serializeKey(key);
  value = this._serializeValue(value);

  if (typeof options !== 'object' || options === null) options = {};

  this._put(key, value, options, callback);
};

AbstractLevelDOWN$2.prototype._put = function (key, value, options, callback) {
  nextTick$1(callback);
};

AbstractLevelDOWN$2.prototype.del = function (key, options, callback) {
  if (typeof options === 'function') callback = options;

  if (typeof callback !== 'function') {
    throw new Error('del() requires a callback argument')
  }

  var err = this._checkKey(key);
  if (err) return nextTick$1(callback, err)

  key = this._serializeKey(key);

  if (typeof options !== 'object' || options === null) options = {};

  this._del(key, options, callback);
};

AbstractLevelDOWN$2.prototype._del = function (key, options, callback) {
  nextTick$1(callback);
};

AbstractLevelDOWN$2.prototype.batch = function (array, options, callback) {
  if (!arguments.length) return this._chainedBatch()

  if (typeof options === 'function') callback = options;

  if (typeof array === 'function') callback = array;

  if (typeof callback !== 'function') {
    throw new Error('batch(array) requires a callback argument')
  }

  if (!Array.isArray(array)) {
    return nextTick$1(callback, new Error('batch(array) requires an array argument'))
  }

  if (array.length === 0) {
    return nextTick$1(callback)
  }

  if (typeof options !== 'object' || options === null) options = {};

  var serialized = new Array(array.length);

  for (var i = 0; i < array.length; i++) {
    if (typeof array[i] !== 'object' || array[i] === null) {
      return nextTick$1(callback, new Error('batch(array) element must be an object and not `null`'))
    }

    var e = xtend$1(array[i]);

    if (e.type !== 'put' && e.type !== 'del') {
      return nextTick$1(callback, new Error("`type` must be 'put' or 'del'"))
    }

    var err = this._checkKey(e.key);
    if (err) return nextTick$1(callback, err)

    e.key = this._serializeKey(e.key);

    if (e.type === 'put') {
      var valueErr = this._checkValue(e.value);
      if (valueErr) return nextTick$1(callback, valueErr)

      e.value = this._serializeValue(e.value);
    }

    serialized[i] = e;
  }

  this._batch(serialized, options, callback);
};

AbstractLevelDOWN$2.prototype._batch = function (array, options, callback) {
  nextTick$1(callback);
};

AbstractLevelDOWN$2.prototype.clear = function (options, callback) {
  if (typeof options === 'function') {
    callback = options;
  } else if (typeof callback !== 'function') {
    throw new Error('clear() requires a callback argument')
  }

  options = cleanRangeOptions(this, options);
  options.reverse = !!options.reverse;
  options.limit = 'limit' in options ? options.limit : -1;

  this._clear(options, callback);
};

AbstractLevelDOWN$2.prototype._clear = function (options, callback) {
  // Avoid setupIteratorOptions, would serialize range options a second time.
  options.keys = true;
  options.values = false;
  options.keyAsBuffer = true;
  options.valueAsBuffer = true;

  var iterator = this._iterator(options);
  var emptyOptions = {};
  var self = this;

  var next = function (err) {
    if (err) {
      return iterator.end(function () {
        callback(err);
      })
    }

    iterator.next(function (err, key) {
      if (err) return next(err)
      if (key === undefined) return iterator.end(callback)

      // This could be optimized by using a batch, but the default _clear
      // is not meant to be fast. Implementations have more room to optimize
      // if they override _clear. Note: using _del bypasses key serialization.
      self._del(key, emptyOptions, next);
    });
  };

  next();
};

AbstractLevelDOWN$2.prototype._setupIteratorOptions = function (options) {
  options = cleanRangeOptions(this, options);

  options.reverse = !!options.reverse;
  options.keys = options.keys !== false;
  options.values = options.values !== false;
  options.limit = 'limit' in options ? options.limit : -1;
  options.keyAsBuffer = options.keyAsBuffer !== false;
  options.valueAsBuffer = options.valueAsBuffer !== false;

  return options
};

function cleanRangeOptions (db, options) {
  var result = {};

  for (var k in options) {
    if (!hasOwnProperty.call(options, k)) continue

    var opt = options[k];

    if (isRangeOption(k)) {
      // Note that we don't reject nullish and empty options here. While
      // those types are invalid as keys, they are valid as range options.
      opt = db._serializeKey(opt);
    }

    result[k] = opt;
  }

  return result
}

function isRangeOption (k) {
  return rangeOptions.indexOf(k) !== -1
}

AbstractLevelDOWN$2.prototype.iterator = function (options) {
  if (typeof options !== 'object' || options === null) options = {};
  options = this._setupIteratorOptions(options);
  return this._iterator(options)
};

AbstractLevelDOWN$2.prototype._iterator = function (options) {
  return new AbstractIterator$2(this)
};

AbstractLevelDOWN$2.prototype._chainedBatch = function () {
  return new AbstractChainedBatch(this)
};

AbstractLevelDOWN$2.prototype._serializeKey = function (key) {
  return key
};

AbstractLevelDOWN$2.prototype._serializeValue = function (value) {
  return value
};

AbstractLevelDOWN$2.prototype._checkKey = function (key) {
  if (key === null || key === undefined) {
    return new Error('key cannot be `null` or `undefined`')
  } else if (Buffer$4.isBuffer(key) && key.length === 0) {
    return new Error('key cannot be an empty Buffer')
  } else if (key === '') {
    return new Error('key cannot be an empty String')
  } else if (Array.isArray(key) && key.length === 0) {
    return new Error('key cannot be an empty Array')
  }
};

AbstractLevelDOWN$2.prototype._checkValue = function (value) {
  if (value === null || value === undefined) {
    return new Error('value cannot be `null` or `undefined`')
  }
};

// Expose browser-compatible nextTick for dependents
AbstractLevelDOWN$2.prototype._nextTick = nextTick$1;

var abstractLeveldown = AbstractLevelDOWN$2;

abstractLeveldown$1.AbstractLevelDOWN = abstractLeveldown;
abstractLeveldown$1.AbstractIterator = abstractIterator;
abstractLeveldown$1.AbstractChainedBatch = abstractChainedBatch;

var inherits_browser = {exports: {}};

if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  inherits_browser.exports = function inherits(ctor, superCtor) {
    if (superCtor) {
      ctor.super_ = superCtor;
      ctor.prototype = Object.create(superCtor.prototype, {
        constructor: {
          value: ctor,
          enumerable: false,
          writable: true,
          configurable: true
        }
      });
    }
  };
} else {
  // old school shim for old browsers
  inherits_browser.exports = function inherits(ctor, superCtor) {
    if (superCtor) {
      ctor.super_ = superCtor;
      var TempCtor = function () {};
      TempCtor.prototype = superCtor.prototype;
      ctor.prototype = new TempCtor();
      ctor.prototype.constructor = ctor;
    }
  };
}

var ltgt$3 = {};

(function (exports) {
	exports.compare = function (a, b) {

	  if(Buffer.isBuffer(a)) {
	    var l = Math.min(a.length, b.length);
	    for(var i = 0; i < l; i++) {
	      var cmp = a[i] - b[i];
	      if(cmp) return cmp
	    }
	    return a.length - b.length
	  }

	  return a < b ? -1 : a > b ? 1 : 0
	};

	// to be compatible with the current abstract-leveldown tests
	// nullish or empty strings.
	// I could use !!val but I want to permit numbers and booleans,
	// if possible.

	function isDef (val) {
	  return val !== undefined && val !== ''
	}

	function has (range, name) {
	  return Object.hasOwnProperty.call(range, name)
	}

	function hasKey(range, name) {
	  return Object.hasOwnProperty.call(range, name) && name
	}

	var lowerBoundKey = exports.lowerBoundKey = function (range) {
	    return (
	       hasKey(range, 'gt')
	    || hasKey(range, 'gte')
	    || hasKey(range, 'min')
	    || (range.reverse ? hasKey(range, 'end') : hasKey(range, 'start'))
	    || undefined
	    )
	};

	var lowerBound = exports.lowerBound = function (range, def) {
	  var k = lowerBoundKey(range);
	  return k ? range[k] : def
	};

	var lowerBoundInclusive = exports.lowerBoundInclusive = function (range) {
	  return has(range, 'gt') ? false : true
	};

	var upperBoundInclusive = exports.upperBoundInclusive =
	  function (range) {
	    return (has(range, 'lt') /*&& !range.maxEx*/) ? false : true
	  };

	var lowerBoundExclusive = exports.lowerBoundExclusive =
	  function (range) {
	    return !lowerBoundInclusive(range)
	  };

	var upperBoundExclusive = exports.upperBoundExclusive =
	  function (range) {
	    return !upperBoundInclusive(range)
	  };

	var upperBoundKey = exports.upperBoundKey = function (range) {
	    return (
	       hasKey(range, 'lt')
	    || hasKey(range, 'lte')
	    || hasKey(range, 'max')
	    || (range.reverse ? hasKey(range, 'start') : hasKey(range, 'end'))
	    || undefined
	    )
	};

	var upperBound = exports.upperBound = function (range, def) {
	  var k = upperBoundKey(range);
	  return k ? range[k] : def
	};

	exports.start = function (range, def) {
	  return range.reverse ? upperBound(range, def) : lowerBound(range, def)
	};
	exports.end = function (range, def) {
	  return range.reverse ? lowerBound(range, def) : upperBound(range, def)
	};
	exports.startInclusive = function (range) {
	  return (
	    range.reverse
	  ? upperBoundInclusive(range)
	  : lowerBoundInclusive(range)
	  )
	};
	exports.endInclusive = function (range) {
	  return (
	    range.reverse
	  ? lowerBoundInclusive(range)
	  : upperBoundInclusive(range)
	  )
	};

	function id (e) { return e }

	exports.toLtgt = function (range, _range, map, lower, upper) {
	  _range = _range || {};
	  map = map || id;
	  var defaults = arguments.length > 3;
	  var lb = exports.lowerBoundKey(range);
	  var ub = exports.upperBoundKey(range);
	  if(lb) {
	    if(lb === 'gt') _range.gt = map(range.gt, false);
	    else            _range.gte = map(range[lb], false);
	  }
	  else if(defaults)
	    _range.gte = map(lower, false);

	  if(ub) {
	    if(ub === 'lt') _range.lt = map(range.lt, true);
	    else            _range.lte = map(range[ub], true);
	  }
	  else if(defaults)
	    _range.lte = map(upper, true);

	  if(range.reverse != null)
	    _range.reverse = !!range.reverse;

	  //if range was used mutably
	  //(in level-sublevel it's part of an options object
	  //that has more properties on it.)
	  if(has(_range, 'max'))   delete _range.max;
	  if(has(_range, 'min'))   delete _range.min;
	  if(has(_range, 'start')) delete _range.start;
	  if(has(_range, 'end'))   delete _range.end;

	  return _range
	};

	exports.contains = function (range, key, compare) {
	  compare = compare || exports.compare;

	  var lb = lowerBound(range);
	  if(isDef(lb)) {
	    var cmp = compare(key, lb);
	    if(cmp < 0 || (cmp === 0 && lowerBoundExclusive(range)))
	      return false
	  }

	  var ub = upperBound(range);
	  if(isDef(ub)) {
	    var cmp = compare(key, ub);
	    if(cmp > 0 || (cmp === 0) && upperBoundExclusive(range))
	      return false
	  }

	  return true
	};

	exports.filter = function (range, compare) {
	  return function (key) {
	    return exports.contains(range, key, compare)
	  }
	};
} (ltgt$3));

/* global IDBKeyRange */

var ltgt$2 = ltgt$3;
var NONE = {};

var keyRange = function createKeyRange (options) {
  var lower = ltgt$2.lowerBound(options, NONE);
  var upper = ltgt$2.upperBound(options, NONE);
  var lowerOpen = ltgt$2.lowerBoundExclusive(options, NONE);
  var upperOpen = ltgt$2.upperBoundExclusive(options, NONE);

  if (lower !== NONE && upper !== NONE) {
    return IDBKeyRange.bound(lower, upper, lowerOpen, upperOpen)
  } else if (lower !== NONE) {
    return IDBKeyRange.lowerBound(lower, lowerOpen)
  } else if (upper !== NONE) {
    return IDBKeyRange.upperBound(upper, upperOpen)
  } else {
    return null
  }
};

var Buffer$3 = require$$0.Buffer;
var ta2str = (function () {
  if (commonjsGlobal.TextDecoder) {
    var decoder = new TextDecoder('utf-8');
    return decoder.decode.bind(decoder)
  } else {
    return function ta2str (ta) {
      return ta2buf(ta).toString()
    }
  }
})();

var ab2str = (function () {
  if (commonjsGlobal.TextDecoder) {
    var decoder = new TextDecoder('utf-8');
    return decoder.decode.bind(decoder)
  } else {
    return function ab2str (ab) {
      return Buffer$3.from(ab).toString()
    }
  }
})();

function ta2buf (ta) {
  var buf = Buffer$3.from(ta.buffer);

  if (ta.byteLength === ta.buffer.byteLength) {
    return buf
  } else {
    return buf.slice(ta.byteOffset, ta.byteOffset + ta.byteLength)
  }
}

var deserialize$2 = function (data, asBuffer) {
  if (data instanceof Uint8Array) {
    return asBuffer ? ta2buf(data) : ta2str(data)
  } else if (data instanceof ArrayBuffer) {
    return asBuffer ? Buffer$3.from(data) : ab2str(data)
  } else {
    return asBuffer ? Buffer$3.from(String(data)) : String(data)
  }
};

var inherits$7 = inherits_browser.exports;
var AbstractIterator$1 = abstractLeveldown$1.AbstractIterator;
var createKeyRange$1 = keyRange;
var deserialize$1 = deserialize$2;
var noop$4 = function () {};

var iterator = Iterator$1;

function Iterator$1 (db, location, options) {
  AbstractIterator$1.call(this, db);

  this._limit = options.limit;
  this._count = 0;
  this._callback = null;
  this._cache = [];
  this._completed = false;
  this._aborted = false;
  this._error = null;
  this._transaction = null;

  this._keys = options.keys;
  this._values = options.values;
  this._keyAsBuffer = options.keyAsBuffer;
  this._valueAsBuffer = options.valueAsBuffer;

  if (this._limit === 0) {
    this._completed = true;
    return
  }

  try {
    var keyRange = createKeyRange$1(options);
  } catch (e) {
    // The lower key is greater than the upper key.
    // IndexedDB throws an error, but we'll just return 0 results.
    this._completed = true;
    return
  }

  this.createIterator(location, keyRange, options.reverse);
}

inherits$7(Iterator$1, AbstractIterator$1);

Iterator$1.prototype.createIterator = function (location, keyRange, reverse) {
  var self = this;
  var transaction = this.db.db.transaction([location], 'readonly');
  var store = transaction.objectStore(location);
  var req = store.openCursor(keyRange, reverse ? 'prev' : 'next');

  req.onsuccess = function (ev) {
    var cursor = ev.target.result;
    if (cursor) self.onItem(cursor);
  };

  this._transaction = transaction;

  // If an error occurs (on the request), the transaction will abort.
  transaction.onabort = function () {
    self.onAbort(self._transaction.error || new Error('aborted by user'));
  };

  transaction.oncomplete = function () {
    self.onComplete();
  };
};

Iterator$1.prototype.onItem = function (cursor) {
  this._cache.push(cursor.key, cursor.value);

  if (this._limit <= 0 || ++this._count < this._limit) {
    cursor.continue();
  }

  this.maybeNext();
};

Iterator$1.prototype.onAbort = function (err) {
  this._aborted = true;
  this._error = err;
  this.maybeNext();
};

Iterator$1.prototype.onComplete = function () {
  this._completed = true;
  this.maybeNext();
};

Iterator$1.prototype.maybeNext = function () {
  if (this._callback) {
    this._next(this._callback);
    this._callback = null;
  }
};

Iterator$1.prototype._next = function (callback) {
  if (this._aborted) {
    // The error should be picked up by either next() or end().
    var err = this._error;
    this._error = null;
    this._nextTick(callback, err);
  } else if (this._cache.length > 0) {
    var key = this._cache.shift();
    var value = this._cache.shift();

    if (this._keys && key !== undefined) {
      key = this._deserializeKey(key, this._keyAsBuffer);
    } else {
      key = undefined;
    }

    if (this._values && value !== undefined) {
      value = this._deserializeValue(value, this._valueAsBuffer);
    } else {
      value = undefined;
    }

    this._nextTick(callback, null, key, value);
  } else if (this._completed) {
    this._nextTick(callback);
  } else {
    this._callback = callback;
  }
};

// Exposed for the v4 to v5 upgrade utility
Iterator$1.prototype._deserializeKey = deserialize$1;
Iterator$1.prototype._deserializeValue = deserialize$1;

Iterator$1.prototype._end = function (callback) {
  if (this._aborted || this._completed) {
    return this._nextTick(callback, this._error)
  }

  // Don't advance the cursor anymore, and the transaction will complete
  // on its own in the next tick. This approach is much cleaner than calling
  // transaction.abort() with its unpredictable event order.
  this.onItem = noop$4;
  this.onAbort = callback;
  this.onComplete = callback;
};

var Buffer$2 = require$$0.Buffer;
// Returns either a Uint8Array or Buffer (doesn't matter to
// IndexedDB, because Buffer is a subclass of Uint8Array)
var str2bin = (function () {
  if (commonjsGlobal.TextEncoder) {
    var encoder = new TextEncoder('utf-8');
    return encoder.encode.bind(encoder)
  } else {
    return Buffer$2.from
  }
})();

var serialize$1 = function (data, asBuffer) {
  if (asBuffer) {
    return Buffer$2.isBuffer(data) ? data : str2bin(String(data))
  } else {
    return String(data)
  }
};

var support$1 = {};

(function (exports) {

	var Buffer = require$$0.Buffer;

	exports.test = function (key) {
	  return function test (impl) {
	    try {
	      impl.cmp(key, 0);
	      return true
	    } catch (err) {
	      return false
	    }
	  }
	};

	// Detect binary key support (IndexedDB Second Edition)
	exports.bufferKeys = exports.test(Buffer.alloc(0));
} (support$1));

var clear$1 = function clear (db, location, keyRange, options, callback) {
  if (options.limit === 0) return db._nextTick(callback)

  var transaction = db.db.transaction([location], 'readwrite');
  var store = transaction.objectStore(location);
  var count = 0;

  transaction.oncomplete = function () {
    callback();
  };

  transaction.onabort = function () {
    callback(transaction.error || new Error('aborted by user'));
  };

  // A key cursor is faster (skips reading values) but not supported by IE
  var method = store.openKeyCursor ? 'openKeyCursor' : 'openCursor';
  var direction = options.reverse ? 'prev' : 'next';

  store[method](keyRange, direction).onsuccess = function (ev) {
    var cursor = ev.target.result;

    if (cursor) {
      // Wait for a request to complete before continuing, saving CPU.
      store.delete(cursor.key).onsuccess = function () {
        if (options.limit <= 0 || ++count < options.limit) {
          cursor.continue();
        }
      };
    }
  };
};

/* global indexedDB */

var levelJs = Level;

var AbstractLevelDOWN$1 = abstractLeveldown$1.AbstractLevelDOWN;
var inherits$6 = inherits_browser.exports;
var Iterator = iterator;
var serialize = serialize$1;
var deserialize = deserialize$2;
var support = support$1;
var clear = clear$1;
var createKeyRange = keyRange;

var DEFAULT_PREFIX = 'level-js-';

function Level (location, opts) {
  if (!(this instanceof Level)) return new Level(location, opts)

  AbstractLevelDOWN$1.call(this, {
    bufferKeys: support.bufferKeys(indexedDB),
    snapshots: true,
    permanence: true,
    clear: true
  });

  opts = opts || {};

  if (typeof location !== 'string') {
    throw new Error('constructor requires a location string argument')
  }

  this.location = location;
  this.prefix = opts.prefix == null ? DEFAULT_PREFIX : opts.prefix;
  this.version = parseInt(opts.version || 1, 10);
}

inherits$6(Level, AbstractLevelDOWN$1);

Level.prototype.type = 'level-js';

Level.prototype._open = function (options, callback) {
  var req = indexedDB.open(this.prefix + this.location, this.version);
  var self = this;

  req.onerror = function () {
    callback(req.error || new Error('unknown error'));
  };

  req.onsuccess = function () {
    self.db = req.result;
    callback();
  };

  req.onupgradeneeded = function (ev) {
    var db = ev.target.result;

    if (!db.objectStoreNames.contains(self.location)) {
      db.createObjectStore(self.location);
    }
  };
};

Level.prototype.store = function (mode) {
  var transaction = this.db.transaction([this.location], mode);
  return transaction.objectStore(this.location)
};

Level.prototype.await = function (request, callback) {
  var transaction = request.transaction;

  // Take advantage of the fact that a non-canceled request error aborts
  // the transaction. I.e. no need to listen for "request.onerror".
  transaction.onabort = function () {
    callback(transaction.error || new Error('aborted by user'));
  };

  transaction.oncomplete = function () {
    callback(null, request.result);
  };
};

Level.prototype._get = function (key, options, callback) {
  var store = this.store('readonly');

  try {
    var req = store.get(key);
  } catch (err) {
    return this._nextTick(callback, err)
  }

  this.await(req, function (err, value) {
    if (err) return callback(err)

    if (value === undefined) {
      // 'NotFound' error, consistent with LevelDOWN API
      return callback(new Error('NotFound'))
    }

    callback(null, deserialize(value, options.asBuffer));
  });
};

Level.prototype._del = function (key, options, callback) {
  var store = this.store('readwrite');

  try {
    var req = store.delete(key);
  } catch (err) {
    return this._nextTick(callback, err)
  }

  this.await(req, callback);
};

Level.prototype._put = function (key, value, options, callback) {
  var store = this.store('readwrite');

  try {
    // Will throw a DataError or DataCloneError if the environment
    // does not support serializing the key or value respectively.
    var req = store.put(value, key);
  } catch (err) {
    return this._nextTick(callback, err)
  }

  this.await(req, callback);
};

Level.prototype._serializeKey = function (key) {
  return serialize(key, this.supports.bufferKeys)
};

Level.prototype._serializeValue = function (value) {
  return serialize(value, true)
};

Level.prototype._iterator = function (options) {
  return new Iterator(this, this.location, options)
};

Level.prototype._batch = function (operations, options, callback) {
  if (operations.length === 0) return this._nextTick(callback)

  var store = this.store('readwrite');
  var transaction = store.transaction;
  var index = 0;
  var error;

  transaction.onabort = function () {
    callback(error || transaction.error || new Error('aborted by user'));
  };

  transaction.oncomplete = function () {
    callback();
  };

  // Wait for a request to complete before making the next, saving CPU.
  function loop () {
    var op = operations[index++];
    var key = op.key;

    try {
      var req = op.type === 'del' ? store.delete(key) : store.put(op.value, key);
    } catch (err) {
      error = err;
      transaction.abort();
      return
    }

    if (index < operations.length) {
      req.onsuccess = loop;
    }
  }

  loop();
};

Level.prototype._clear = function (options, callback) {
  try {
    var keyRange = createKeyRange(options);
  } catch (e) {
    // The lower key is greater than the upper key.
    // IndexedDB throws an error, but we'll just do nothing.
    return this._nextTick(callback)
  }

  if (options.limit >= 0) {
    // IDBObjectStore#delete(range) doesn't have such an option.
    // Fall back to cursor-based implementation.
    return clear(this, this.location, keyRange, options, callback)
  }

  try {
    var store = this.store('readwrite');
    var req = keyRange ? store.delete(keyRange) : store.clear();
  } catch (err) {
    return this._nextTick(callback, err)
  }

  this.await(req, callback);
};

Level.prototype._close = function (callback) {
  this.db.close();
  this._nextTick(callback);
};

// NOTE: remove in a next major release
Level.prototype.upgrade = function (callback) {
  if (this.status !== 'open') {
    return this._nextTick(callback, new Error('cannot upgrade() before open()'))
  }

  var it = this.iterator();
  var batchOptions = {};
  var self = this;

  it._deserializeKey = it._deserializeValue = identity;
  next();

  function next (err) {
    if (err) return finish(err)
    it.next(each);
  }

  function each (err, key, value) {
    if (err || key === undefined) {
      return finish(err)
    }

    var newKey = self._serializeKey(deserialize(key, true));
    var newValue = self._serializeValue(deserialize(value, true));

    // To bypass serialization on the old key, use _batch() instead of batch().
    // NOTE: if we disable snapshotting (#86) this could lead to a loop of
    // inserting and then iterating those same entries, because the new keys
    // possibly sort after the old keys.
    self._batch([
      { type: 'del', key: key },
      { type: 'put', key: newKey, value: newValue }
    ], batchOptions, next);
  }

  function finish (err) {
    it.end(function (err2) {
      callback(err || err2);
    });
  }

  function identity (data) {
    return data
  }
};

Level.destroy = function (location, prefix, callback) {
  if (typeof prefix === 'function') {
    callback = prefix;
    prefix = DEFAULT_PREFIX;
  }
  var request = indexedDB.deleteDatabase(prefix + location);
  request.onsuccess = function () {
    callback();
  };
  request.onerror = function (err) {
    callback(err);
  };
};

var deferredLeveldown = {exports: {}};

var AbstractIterator = abstractLeveldown$1.AbstractIterator;
var inherits$5 = inherits_browser.exports;

function DeferredIterator$1 (db, options) {
  AbstractIterator.call(this, db);

  this._options = options;
  this._iterator = null;
  this._operations = [];
}

inherits$5(DeferredIterator$1, AbstractIterator);

DeferredIterator$1.prototype.setDb = function (db) {
  var it = this._iterator = db.iterator(this._options);
  this._operations.forEach(function (op) {
    it[op.method].apply(it, op.args);
  });
};

DeferredIterator$1.prototype._operation = function (method, args) {
  if (this._iterator) return this._iterator[method].apply(this._iterator, args)
  this._operations.push({ method: method, args: args });
};

'next end'.split(' ').forEach(function (m) {
  DeferredIterator$1.prototype['_' + m] = function () {
    this._operation(m, arguments);
  };
});

// Must defer seek() rather than _seek() because it requires db._serializeKey to be available
DeferredIterator$1.prototype.seek = function () {
  this._operation('seek', arguments);
};

var deferredIterator = DeferredIterator$1;

var AbstractLevelDOWN = abstractLeveldown$1.AbstractLevelDOWN;
var inherits$4 = inherits_browser.exports;
var DeferredIterator = deferredIterator;
var deferrables = 'put get del batch clear'.split(' ');
var optionalDeferrables = 'approximateSize compactRange'.split(' ');

function DeferredLevelDOWN$1 (db) {
  AbstractLevelDOWN.call(this, db.supports || {});

  // TODO (future major): remove this fallback; db must have manifest that
  // declares approximateSize and compactRange in additionalMethods.
  optionalDeferrables.forEach(function (m) {
    if (typeof db[m] === 'function' && !this.supports.additionalMethods[m]) {
      this.supports.additionalMethods[m] = true;
    }
  }, this);

  this._db = db;
  this._operations = [];
  closed(this);
}

inherits$4(DeferredLevelDOWN$1, AbstractLevelDOWN);

DeferredLevelDOWN$1.prototype.type = 'deferred-leveldown';

DeferredLevelDOWN$1.prototype._open = function (options, callback) {
  var self = this;

  this._db.open(options, function (err) {
    if (err) return callback(err)

    self._operations.forEach(function (op) {
      if (op.iterator) {
        op.iterator.setDb(self._db);
      } else {
        self._db[op.method].apply(self._db, op.args);
      }
    });
    self._operations = [];

    open(self);
    callback();
  });
};

DeferredLevelDOWN$1.prototype._close = function (callback) {
  var self = this;

  this._db.close(function (err) {
    if (err) return callback(err)
    closed(self);
    callback();
  });
};

function open (self) {
  deferrables.concat('iterator').forEach(function (m) {
    self['_' + m] = function () {
      return this._db[m].apply(this._db, arguments)
    };
  });
  Object.keys(self.supports.additionalMethods).forEach(function (m) {
    self[m] = function () {
      return this._db[m].apply(this._db, arguments)
    };
  });
}

function closed (self) {
  deferrables.forEach(function (m) {
    self['_' + m] = function () {
      this._operations.push({ method: m, args: arguments });
    };
  });
  Object.keys(self.supports.additionalMethods).forEach(function (m) {
    self[m] = function () {
      this._operations.push({ method: m, args: arguments });
    };
  });
  self._iterator = function (options) {
    var it = new DeferredIterator(self, options);
    this._operations.push({ iterator: it });
    return it
  };
}

DeferredLevelDOWN$1.prototype._serializeKey = function (key) {
  return key
};

DeferredLevelDOWN$1.prototype._serializeValue = function (value) {
  return value
};

deferredLeveldown.exports = DeferredLevelDOWN$1;
deferredLeveldown.exports.DeferredIterator = DeferredIterator;

var inherits$3 = inherits_browser.exports;
var Readable$3 = require$$1.Readable;
var extend$1 = immutable;

var levelIteratorStream = ReadStream$2;
inherits$3(ReadStream$2, Readable$3);

function ReadStream$2 (iterator, options) {
  if (!(this instanceof ReadStream$2)) return new ReadStream$2(iterator, options)
  options = options || {};
  Readable$3.call(this, extend$1(options, {
    objectMode: true
  }));
  this._iterator = iterator;
  this._options = options;
  this.on('end', this.destroy.bind(this, null, null));
}

ReadStream$2.prototype._read = function () {
  var self = this;
  var options = this._options;
  if (this.destroyed) return

  this._iterator.next(function (err, key, value) {
    if (self.destroyed) return
    if (err) return self.destroy(err)

    if (key === undefined && value === undefined) {
      self.push(null);
    } else if (options.keys !== false && options.values === false) {
      self.push(key);
    } else if (options.keys === false && options.values !== false) {
      self.push(value);
    } else {
      self.push({ key: key, value: value });
    }
  });
};

ReadStream$2.prototype._destroy = function (err, callback) {
  this._iterator.end(function (err2) {
    callback(err || err2);
  });
};

var errno$3 = {exports: {}};

var prr$1 = {exports: {}};

/*!
  * prr
  * (c) 2013 Rod Vagg <rod@vagg.org>
  * https://github.com/rvagg/prr
  * License: MIT
  */

(function (module) {
	(function (name, context, definition) {
	  if (module.exports)
	    module.exports = definition();
	  else
	    context[name] = definition();
	})('prr', commonjsGlobal, function() {

	  var setProperty = typeof Object.defineProperty == 'function'
	      ? function (obj, key, options) {
	          Object.defineProperty(obj, key, options);
	          return obj
	        }
	      : function (obj, key, options) { // < es5
	          obj[key] = options.value;
	          return obj
	        }

	    , makeOptions = function (value, options) {
	        var oo = typeof options == 'object'
	          , os = !oo && typeof options == 'string'
	          , op = function (p) {
	              return oo
	                ? !!options[p]
	                : os
	                  ? options.indexOf(p[0]) > -1
	                  : false
	            };

	        return {
	            enumerable   : op('enumerable')
	          , configurable : op('configurable')
	          , writable     : op('writable')
	          , value        : value
	        }
	      }

	    , prr = function (obj, key, value, options) {
	        var k;

	        options = makeOptions(value, options);

	        if (typeof key == 'object') {
	          for (k in key) {
	            if (Object.hasOwnProperty.call(key, k)) {
	              options.value = key[k];
	              setProperty(obj, k, options);
	            }
	          }
	          return obj
	        }

	        return setProperty(obj, key, options)
	      };

	  return prr
	});
} (prr$1));

var prr = prr$1.exports;

function init (type, message, cause) {
  if (!!message && typeof message != 'string') {
    message = message.message || message.name;
  }
  prr(this, {
      type    : type
    , name    : type
      // can be passed just a 'cause'
    , cause   : typeof message != 'string' ? message : cause
    , message : message
  }, 'ewr');
}

// generic prototype, not intended to be actually used - helpful for `instanceof`
function CustomError (message, cause) {
  Error.call(this);
  if (Error.captureStackTrace)
    Error.captureStackTrace(this, this.constructor);
  init.call(this, 'CustomError', message, cause);
}

CustomError.prototype = new Error();

function createError$2 (errno, type, proto) {
  var err = function (message, cause) {
    init.call(this, type, message, cause);
    //TODO: the specificity here is stupid, errno should be available everywhere
    if (type == 'FilesystemError') {
      this.code    = this.cause.code;
      this.path    = this.cause.path;
      this.errno   = this.cause.errno;
      this.message =
        (errno.errno[this.cause.errno]
          ? errno.errno[this.cause.errno].description
          : this.cause.message)
        + (this.cause.path ? ' [' + this.cause.path + ']' : '');
    }
    Error.call(this);
    if (Error.captureStackTrace)
      Error.captureStackTrace(this, err);
  };
  err.prototype = !!proto ? new proto() : new CustomError();
  return err
}

var custom = function (errno) {
  var ce = function (type, proto) {
    return createError$2(errno, type, proto)
  };
  return {
      CustomError     : CustomError
    , FilesystemError : ce('FilesystemError')
    , createError     : ce
  }
};

(function (module) {
	var all = module.exports.all = [
	  {
	    errno: -2,
	    code: 'ENOENT',
	    description: 'no such file or directory'
	  },
	  {
	    errno: -1,
	    code: 'UNKNOWN',
	    description: 'unknown error'
	  },
	  {
	    errno: 0,
	    code: 'OK',
	    description: 'success'
	  },
	  {
	    errno: 1,
	    code: 'EOF',
	    description: 'end of file'
	  },
	  {
	    errno: 2,
	    code: 'EADDRINFO',
	    description: 'getaddrinfo error'
	  },
	  {
	    errno: 3,
	    code: 'EACCES',
	    description: 'permission denied'
	  },
	  {
	    errno: 4,
	    code: 'EAGAIN',
	    description: 'resource temporarily unavailable'
	  },
	  {
	    errno: 5,
	    code: 'EADDRINUSE',
	    description: 'address already in use'
	  },
	  {
	    errno: 6,
	    code: 'EADDRNOTAVAIL',
	    description: 'address not available'
	  },
	  {
	    errno: 7,
	    code: 'EAFNOSUPPORT',
	    description: 'address family not supported'
	  },
	  {
	    errno: 8,
	    code: 'EALREADY',
	    description: 'connection already in progress'
	  },
	  {
	    errno: 9,
	    code: 'EBADF',
	    description: 'bad file descriptor'
	  },
	  {
	    errno: 10,
	    code: 'EBUSY',
	    description: 'resource busy or locked'
	  },
	  {
	    errno: 11,
	    code: 'ECONNABORTED',
	    description: 'software caused connection abort'
	  },
	  {
	    errno: 12,
	    code: 'ECONNREFUSED',
	    description: 'connection refused'
	  },
	  {
	    errno: 13,
	    code: 'ECONNRESET',
	    description: 'connection reset by peer'
	  },
	  {
	    errno: 14,
	    code: 'EDESTADDRREQ',
	    description: 'destination address required'
	  },
	  {
	    errno: 15,
	    code: 'EFAULT',
	    description: 'bad address in system call argument'
	  },
	  {
	    errno: 16,
	    code: 'EHOSTUNREACH',
	    description: 'host is unreachable'
	  },
	  {
	    errno: 17,
	    code: 'EINTR',
	    description: 'interrupted system call'
	  },
	  {
	    errno: 18,
	    code: 'EINVAL',
	    description: 'invalid argument'
	  },
	  {
	    errno: 19,
	    code: 'EISCONN',
	    description: 'socket is already connected'
	  },
	  {
	    errno: 20,
	    code: 'EMFILE',
	    description: 'too many open files'
	  },
	  {
	    errno: 21,
	    code: 'EMSGSIZE',
	    description: 'message too long'
	  },
	  {
	    errno: 22,
	    code: 'ENETDOWN',
	    description: 'network is down'
	  },
	  {
	    errno: 23,
	    code: 'ENETUNREACH',
	    description: 'network is unreachable'
	  },
	  {
	    errno: 24,
	    code: 'ENFILE',
	    description: 'file table overflow'
	  },
	  {
	    errno: 25,
	    code: 'ENOBUFS',
	    description: 'no buffer space available'
	  },
	  {
	    errno: 26,
	    code: 'ENOMEM',
	    description: 'not enough memory'
	  },
	  {
	    errno: 27,
	    code: 'ENOTDIR',
	    description: 'not a directory'
	  },
	  {
	    errno: 28,
	    code: 'EISDIR',
	    description: 'illegal operation on a directory'
	  },
	  {
	    errno: 29,
	    code: 'ENONET',
	    description: 'machine is not on the network'
	  },
	  {
	    errno: 31,
	    code: 'ENOTCONN',
	    description: 'socket is not connected'
	  },
	  {
	    errno: 32,
	    code: 'ENOTSOCK',
	    description: 'socket operation on non-socket'
	  },
	  {
	    errno: 33,
	    code: 'ENOTSUP',
	    description: 'operation not supported on socket'
	  },
	  {
	    errno: 34,
	    code: 'ENOENT',
	    description: 'no such file or directory'
	  },
	  {
	    errno: 35,
	    code: 'ENOSYS',
	    description: 'function not implemented'
	  },
	  {
	    errno: 36,
	    code: 'EPIPE',
	    description: 'broken pipe'
	  },
	  {
	    errno: 37,
	    code: 'EPROTO',
	    description: 'protocol error'
	  },
	  {
	    errno: 38,
	    code: 'EPROTONOSUPPORT',
	    description: 'protocol not supported'
	  },
	  {
	    errno: 39,
	    code: 'EPROTOTYPE',
	    description: 'protocol wrong type for socket'
	  },
	  {
	    errno: 40,
	    code: 'ETIMEDOUT',
	    description: 'connection timed out'
	  },
	  {
	    errno: 41,
	    code: 'ECHARSET',
	    description: 'invalid Unicode character'
	  },
	  {
	    errno: 42,
	    code: 'EAIFAMNOSUPPORT',
	    description: 'address family for hostname not supported'
	  },
	  {
	    errno: 44,
	    code: 'EAISERVICE',
	    description: 'servname not supported for ai_socktype'
	  },
	  {
	    errno: 45,
	    code: 'EAISOCKTYPE',
	    description: 'ai_socktype not supported'
	  },
	  {
	    errno: 46,
	    code: 'ESHUTDOWN',
	    description: 'cannot send after transport endpoint shutdown'
	  },
	  {
	    errno: 47,
	    code: 'EEXIST',
	    description: 'file already exists'
	  },
	  {
	    errno: 48,
	    code: 'ESRCH',
	    description: 'no such process'
	  },
	  {
	    errno: 49,
	    code: 'ENAMETOOLONG',
	    description: 'name too long'
	  },
	  {
	    errno: 50,
	    code: 'EPERM',
	    description: 'operation not permitted'
	  },
	  {
	    errno: 51,
	    code: 'ELOOP',
	    description: 'too many symbolic links encountered'
	  },
	  {
	    errno: 52,
	    code: 'EXDEV',
	    description: 'cross-device link not permitted'
	  },
	  {
	    errno: 53,
	    code: 'ENOTEMPTY',
	    description: 'directory not empty'
	  },
	  {
	    errno: 54,
	    code: 'ENOSPC',
	    description: 'no space left on device'
	  },
	  {
	    errno: 55,
	    code: 'EIO',
	    description: 'i/o error'
	  },
	  {
	    errno: 56,
	    code: 'EROFS',
	    description: 'read-only file system'
	  },
	  {
	    errno: 57,
	    code: 'ENODEV',
	    description: 'no such device'
	  },
	  {
	    errno: 58,
	    code: 'ESPIPE',
	    description: 'invalid seek'
	  },
	  {
	    errno: 59,
	    code: 'ECANCELED',
	    description: 'operation canceled'
	  }
	];

	module.exports.errno = {};
	module.exports.code = {};

	all.forEach(function (error) {
	  module.exports.errno[error.errno] = error;
	  module.exports.code[error.code] = error;
	});

	module.exports.custom = custom(module.exports);
	module.exports.create = module.exports.custom.createError;
} (errno$3));

var createError$1 = errno$3.exports.create;
var LevelUPError$1 = createError$1('LevelUPError');
var NotFoundError$2 = createError$1('NotFoundError', LevelUPError$1);

NotFoundError$2.prototype.notFound = true;
NotFoundError$2.prototype.status = 404;

var errors$3 = {
  LevelUPError: LevelUPError$1,
  InitializationError: createError$1('InitializationError', LevelUPError$1),
  OpenError: createError$1('OpenError', LevelUPError$1),
  ReadError: createError$1('ReadError', LevelUPError$1),
  WriteError: createError$1('WriteError', LevelUPError$1),
  NotFoundError: NotFoundError$2,
  EncodingError: createError$1('EncodingError', LevelUPError$1)
};

function promisify$2 () {
  var callback;
  var promise = new Promise(function (resolve, reject) {
    callback = function callback (err, value) {
      if (err) reject(err);
      else resolve(value);
    };
  });
  callback.promise = promise;
  return callback
}

var promisify_1 = promisify$2;

var common = {};

common.getCallback = function (options, callback) {
  return typeof options === 'function' ? options : callback
};

common.getOptions = function (options) {
  return typeof options === 'object' && options !== null ? options : {}
};

var WriteError$1 = errors$3.WriteError;
var promisify$1 = promisify_1;
var getCallback$1 = common.getCallback;
var getOptions$1 = common.getOptions;

function Batch$1 (levelup) {
  // TODO (next major): remove this._levelup alias
  this.db = this._levelup = levelup;
  this.batch = levelup.db.batch();
  this.ops = [];
  this.length = 0;
}

Batch$1.prototype.put = function (key, value) {
  try {
    this.batch.put(key, value);
  } catch (e) {
    throw new WriteError$1(e)
  }

  this.ops.push({ type: 'put', key: key, value: value });
  this.length++;

  return this
};

Batch$1.prototype.del = function (key) {
  try {
    this.batch.del(key);
  } catch (err) {
    throw new WriteError$1(err)
  }

  this.ops.push({ type: 'del', key: key });
  this.length++;

  return this
};

Batch$1.prototype.clear = function () {
  try {
    this.batch.clear();
  } catch (err) {
    throw new WriteError$1(err)
  }

  this.ops = [];
  this.length = 0;

  return this
};

Batch$1.prototype.write = function (options, callback) {
  var levelup = this._levelup;
  var ops = this.ops;
  var promise;

  callback = getCallback$1(options, callback);

  if (!callback) {
    callback = promisify$1();
    promise = callback.promise;
  }

  options = getOptions$1(options);

  try {
    this.batch.write(options, function (err) {
      if (err) { return callback(new WriteError$1(err)) }
      levelup.emit('batch', ops);
      callback();
    });
  } catch (err) {
    throw new WriteError$1(err)
  }

  return promise
};

var batch = Batch$1;

var EventEmitter$1 = require$$0$1.EventEmitter;
var inherits$2 = require$$1$1.inherits;
var extend = immutable;
var DeferredLevelDOWN = deferredLeveldown.exports;
var IteratorStream = levelIteratorStream;
var Batch = batch;
var errors$2 = errors$3;
var supports = levelSupports;
var assert = require$$8;
var promisify = promisify_1;
var getCallback = common.getCallback;
var getOptions = common.getOptions;

var WriteError = errors$2.WriteError;
var ReadError = errors$2.ReadError;
var NotFoundError$1 = errors$2.NotFoundError;
var OpenError = errors$2.OpenError;
var InitializationError = errors$2.InitializationError;

// Possible AbstractLevelDOWN#status values:
//  - 'new'     - newly created, not opened or closed
//  - 'opening' - waiting for the database to be opened, post open()
//  - 'open'    - successfully opened the database, available for use
//  - 'closing' - waiting for the database to be closed, post close()
//  - 'closed'  - database has been successfully closed, should not be
//                 used except for another open() operation

function LevelUP (db, options, callback) {
  if (!(this instanceof LevelUP)) {
    return new LevelUP(db, options, callback)
  }

  var error;
  var self = this;

  EventEmitter$1.call(this);
  this.setMaxListeners(Infinity);

  if (typeof options === 'function') {
    callback = options;
    options = {};
  }

  options = options || {};

  if (!db || typeof db !== 'object') {
    error = new InitializationError('First argument must be an abstract-leveldown compliant store');
    if (typeof callback === 'function') {
      return process.nextTick(callback, error)
    }
    throw error
  }

  assert.strictEqual(typeof db.status, 'string', '.status required, old abstract-leveldown');

  this.options = getOptions(options);
  this._db = db;
  this.db = new DeferredLevelDOWN(db);
  this.open(callback || function (err) {
    if (err) self.emit('error', err);
  });

  // Create manifest based on deferred-leveldown's
  this.supports = supports(this.db.supports, {
    status: false,
    deferredOpen: true,
    openCallback: true,
    promises: true,
    streams: true
  });

  // Experimental: enrich levelup interface
  Object.keys(this.supports.additionalMethods).forEach(function (method) {
    if (this[method] != null) return

    // Don't do this.db[method].bind() because this.db is dynamic.
    this[method] = function () {
      return this.db[method].apply(this.db, arguments)
    };
  }, this);
}

LevelUP.prototype.emit = EventEmitter$1.prototype.emit;
LevelUP.prototype.once = EventEmitter$1.prototype.once;
inherits$2(LevelUP, EventEmitter$1);

LevelUP.prototype.open = function (opts, callback) {
  var self = this;
  var promise;

  if (typeof opts === 'function') {
    callback = opts;
    opts = null;
  }

  if (!callback) {
    callback = promisify();
    promise = callback.promise;
  }

  if (!opts) {
    opts = this.options;
  }

  if (this.isOpen()) {
    process.nextTick(callback, null, self);
    return promise
  }

  if (this._isOpening()) {
    this.once('open', function () { callback(null, self); });
    return promise
  }

  this.emit('opening');

  this.db.open(opts, function (err) {
    if (err) {
      return callback(new OpenError(err))
    }
    self.db = self._db;
    callback(null, self);
    self.emit('open');
    self.emit('ready');
  });

  return promise
};

LevelUP.prototype.close = function (callback) {
  var self = this;
  var promise;

  if (!callback) {
    callback = promisify();
    promise = callback.promise;
  }

  if (this.isOpen()) {
    this.db.close(function () {
      self.emit('closed');
      callback.apply(null, arguments);
    });
    this.emit('closing');
    this.db = new DeferredLevelDOWN(this._db);
  } else if (this.isClosed()) {
    process.nextTick(callback);
  } else if (this.db.status === 'closing') {
    this.once('closed', callback);
  } else if (this._isOpening()) {
    this.once('open', function () {
      self.close(callback);
    });
  }

  return promise
};

LevelUP.prototype.isOpen = function () {
  return this.db.status === 'open'
};

LevelUP.prototype._isOpening = function () {
  return this.db.status === 'opening'
};

LevelUP.prototype.isClosed = function () {
  return (/^clos|new/).test(this.db.status)
};

LevelUP.prototype.get = function (key, options, callback) {
  var promise;

  callback = getCallback(options, callback);

  if (!callback) {
    callback = promisify();
    promise = callback.promise;
  }

  if (maybeError(this, callback)) { return promise }

  options = getOptions(options);

  this.db.get(key, options, function (err, value) {
    if (err) {
      if ((/notfound/i).test(err) || err.notFound) {
        err = new NotFoundError$1('Key not found in database [' + key + ']', err);
      } else {
        err = new ReadError(err);
      }
      return callback(err)
    }
    callback(null, value);
  });

  return promise
};

LevelUP.prototype.put = function (key, value, options, callback) {
  var self = this;
  var promise;

  callback = getCallback(options, callback);

  if (!callback) {
    callback = promisify();
    promise = callback.promise;
  }

  if (maybeError(this, callback)) { return promise }

  options = getOptions(options);

  this.db.put(key, value, options, function (err) {
    if (err) {
      return callback(new WriteError(err))
    }
    self.emit('put', key, value);
    callback();
  });

  return promise
};

LevelUP.prototype.del = function (key, options, callback) {
  var self = this;
  var promise;

  callback = getCallback(options, callback);

  if (!callback) {
    callback = promisify();
    promise = callback.promise;
  }

  if (maybeError(this, callback)) { return promise }

  options = getOptions(options);

  this.db.del(key, options, function (err) {
    if (err) {
      return callback(new WriteError(err))
    }
    self.emit('del', key);
    callback();
  });

  return promise
};

LevelUP.prototype.batch = function (arr, options, callback) {
  if (!arguments.length) {
    return new Batch(this)
  }

  var self = this;
  var promise;

  if (typeof arr === 'function') callback = arr;
  else callback = getCallback(options, callback);

  if (!callback) {
    callback = promisify();
    promise = callback.promise;
  }

  if (maybeError(this, callback)) { return promise }

  options = getOptions(options);

  this.db.batch(arr, options, function (err) {
    if (err) {
      return callback(new WriteError(err))
    }
    self.emit('batch', arr);
    callback();
  });

  return promise
};

LevelUP.prototype.iterator = function (options) {
  return this.db.iterator(options)
};

LevelUP.prototype.clear = function (options, callback) {
  var self = this;
  var promise;

  callback = getCallback(options, callback);
  options = getOptions(options);

  if (!callback) {
    callback = promisify();
    promise = callback.promise;
  }

  if (maybeError(this, callback)) {
    return promise
  }

  this.db.clear(options, function (err) {
    if (err) {
      return callback(new WriteError(err))
    }
    self.emit('clear', options);
    callback();
  });

  return promise
};

LevelUP.prototype.readStream =
LevelUP.prototype.createReadStream = function (options) {
  options = extend({ keys: true, values: true }, options);
  if (typeof options.limit !== 'number') { options.limit = -1; }
  return new IteratorStream(this.db.iterator(options), options)
};

LevelUP.prototype.keyStream =
LevelUP.prototype.createKeyStream = function (options) {
  return this.createReadStream(extend(options, { keys: true, values: false }))
};

LevelUP.prototype.valueStream =
LevelUP.prototype.createValueStream = function (options) {
  return this.createReadStream(extend(options, { keys: false, values: true }))
};

LevelUP.prototype.toString = function () {
  return 'LevelUP'
};

LevelUP.prototype.type = 'levelup';

function maybeError (db, callback) {
  if (!db._isOpening() && !db.isOpen()) {
    process.nextTick(callback, new ReadError('Database is not open'));
    return true
  }
}

LevelUP.errors = errors$2;
var levelup$1 = LevelUP.default = LevelUP;

var fwdStream = {};

var writable = {exports: {}};

var util$4 = {};

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

// NOTE: These type checking functions intentionally don't use `instanceof`
// because it is fragile and can be easily faked with `Object.create()`.

function isArray$1(arg) {
  if (Array.isArray) {
    return Array.isArray(arg);
  }
  return objectToString(arg) === '[object Array]';
}
util$4.isArray = isArray$1;

function isBoolean(arg) {
  return typeof arg === 'boolean';
}
util$4.isBoolean = isBoolean;

function isNull(arg) {
  return arg === null;
}
util$4.isNull = isNull;

function isNullOrUndefined(arg) {
  return arg == null;
}
util$4.isNullOrUndefined = isNullOrUndefined;

function isNumber(arg) {
  return typeof arg === 'number';
}
util$4.isNumber = isNumber;

function isString$1(arg) {
  return typeof arg === 'string';
}
util$4.isString = isString$1;

function isSymbol(arg) {
  return typeof arg === 'symbol';
}
util$4.isSymbol = isSymbol;

function isUndefined(arg) {
  return arg === void 0;
}
util$4.isUndefined = isUndefined;

function isRegExp(re) {
  return objectToString(re) === '[object RegExp]';
}
util$4.isRegExp = isRegExp;

function isObject$1(arg) {
  return typeof arg === 'object' && arg !== null;
}
util$4.isObject = isObject$1;

function isDate(d) {
  return objectToString(d) === '[object Date]';
}
util$4.isDate = isDate;

function isError(e) {
  return (objectToString(e) === '[object Error]' || e instanceof Error);
}
util$4.isError = isError;

function isFunction$2(arg) {
  return typeof arg === 'function';
}
util$4.isFunction = isFunction$2;

function isPrimitive(arg) {
  return arg === null ||
         typeof arg === 'boolean' ||
         typeof arg === 'number' ||
         typeof arg === 'string' ||
         typeof arg === 'symbol' ||  // ES6 symbol
         typeof arg === 'undefined';
}
util$4.isPrimitive = isPrimitive;

util$4.isBuffer = require$$0.Buffer.isBuffer;

function objectToString(o) {
  return Object.prototype.toString.call(o);
}

var toString = {}.toString;

var isarray = Array.isArray || function (arr) {
  return toString.call(arr) == '[object Array]';
};

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

var _stream_readable$1 = Readable$2;

/*<replacement>*/
var isArray = isarray;
/*</replacement>*/


/*<replacement>*/
var Buffer$1 = require$$0.Buffer;
/*</replacement>*/

Readable$2.ReadableState = ReadableState;

var EE = require$$0$1.EventEmitter;

/*<replacement>*/
if (!EE.listenerCount) EE.listenerCount = function(emitter, type) {
  return emitter.listeners(type).length;
};
/*</replacement>*/

var Stream = require$$3$1;

/*<replacement>*/
var util$3 = util$4;
util$3.inherits = inherits_browser.exports;
/*</replacement>*/

var StringDecoder;

util$3.inherits(Readable$2, Stream);

function ReadableState(options, stream) {
  options = options || {};

  // the point at which it stops calling _read() to fill the buffer
  // Note: 0 is a valid value, means "don't call _read preemptively ever"
  var hwm = options.highWaterMark;
  this.highWaterMark = (hwm || hwm === 0) ? hwm : 16 * 1024;

  // cast to ints.
  this.highWaterMark = ~~this.highWaterMark;

  this.buffer = [];
  this.length = 0;
  this.pipes = null;
  this.pipesCount = 0;
  this.flowing = false;
  this.ended = false;
  this.endEmitted = false;
  this.reading = false;

  // In streams that never have any data, and do push(null) right away,
  // the consumer can miss the 'end' event if they do some I/O before
  // consuming the stream.  So, we don't emit('end') until some reading
  // happens.
  this.calledRead = false;

  // a flag to be able to tell if the onwrite cb is called immediately,
  // or on a later tick.  We set this to true at first, becuase any
  // actions that shouldn't happen until "later" should generally also
  // not happen before the first write call.
  this.sync = true;

  // whenever we return null, then we set a flag to say
  // that we're awaiting a 'readable' event emission.
  this.needReadable = false;
  this.emittedReadable = false;
  this.readableListening = false;


  // object stream flag. Used to make read(n) ignore n and to
  // make all the buffer merging and length checks go away
  this.objectMode = !!options.objectMode;

  // Crypto is kind of old and crusty.  Historically, its default string
  // encoding is 'binary' so we have to make this configurable.
  // Everything else in the universe uses 'utf8', though.
  this.defaultEncoding = options.defaultEncoding || 'utf8';

  // when piping, we only care about 'readable' events that happen
  // after read()ing all the bytes and not getting any pushback.
  this.ranOut = false;

  // the number of writers that are awaiting a drain event in .pipe()s
  this.awaitDrain = 0;

  // if true, a maybeReadMore has been scheduled
  this.readingMore = false;

  this.decoder = null;
  this.encoding = null;
  if (options.encoding) {
    if (!StringDecoder)
      StringDecoder = require$$6$1.StringDecoder;
    this.decoder = new StringDecoder(options.encoding);
    this.encoding = options.encoding;
  }
}

function Readable$2(options) {
  if (!(this instanceof Readable$2))
    return new Readable$2(options);

  this._readableState = new ReadableState(options);

  // legacy
  this.readable = true;

  Stream.call(this);
}

// Manually shove something into the read() buffer.
// This returns true if the highWaterMark has not been hit yet,
// similar to how Writable.write() returns true if you should
// write() some more.
Readable$2.prototype.push = function(chunk, encoding) {
  var state = this._readableState;

  if (typeof chunk === 'string' && !state.objectMode) {
    encoding = encoding || state.defaultEncoding;
    if (encoding !== state.encoding) {
      chunk = new Buffer$1(chunk, encoding);
      encoding = '';
    }
  }

  return readableAddChunk(this, state, chunk, encoding, false);
};

// Unshift should *always* be something directly out of read()
Readable$2.prototype.unshift = function(chunk) {
  var state = this._readableState;
  return readableAddChunk(this, state, chunk, '', true);
};

function readableAddChunk(stream, state, chunk, encoding, addToFront) {
  var er = chunkInvalid(state, chunk);
  if (er) {
    stream.emit('error', er);
  } else if (chunk === null || chunk === undefined) {
    state.reading = false;
    if (!state.ended)
      onEofChunk(stream, state);
  } else if (state.objectMode || chunk && chunk.length > 0) {
    if (state.ended && !addToFront) {
      var e = new Error('stream.push() after EOF');
      stream.emit('error', e);
    } else if (state.endEmitted && addToFront) {
      var e = new Error('stream.unshift() after end event');
      stream.emit('error', e);
    } else {
      if (state.decoder && !addToFront && !encoding)
        chunk = state.decoder.write(chunk);

      // update the buffer info.
      state.length += state.objectMode ? 1 : chunk.length;
      if (addToFront) {
        state.buffer.unshift(chunk);
      } else {
        state.reading = false;
        state.buffer.push(chunk);
      }

      if (state.needReadable)
        emitReadable(stream);

      maybeReadMore(stream, state);
    }
  } else if (!addToFront) {
    state.reading = false;
  }

  return needMoreData(state);
}



// if it's past the high water mark, we can push in some more.
// Also, if we have no data yet, we can stand some
// more bytes.  This is to work around cases where hwm=0,
// such as the repl.  Also, if the push() triggered a
// readable event, and the user called read(largeNumber) such that
// needReadable was set, then we ought to push more, so that another
// 'readable' event will be triggered.
function needMoreData(state) {
  return !state.ended &&
         (state.needReadable ||
          state.length < state.highWaterMark ||
          state.length === 0);
}

// backwards compatibility.
Readable$2.prototype.setEncoding = function(enc) {
  if (!StringDecoder)
    StringDecoder = require$$6$1.StringDecoder;
  this._readableState.decoder = new StringDecoder(enc);
  this._readableState.encoding = enc;
};

// Don't raise the hwm > 128MB
var MAX_HWM = 0x800000;
function roundUpToNextPowerOf2(n) {
  if (n >= MAX_HWM) {
    n = MAX_HWM;
  } else {
    // Get the next highest power of 2
    n--;
    for (var p = 1; p < 32; p <<= 1) n |= n >> p;
    n++;
  }
  return n;
}

function howMuchToRead(n, state) {
  if (state.length === 0 && state.ended)
    return 0;

  if (state.objectMode)
    return n === 0 ? 0 : 1;

  if (isNaN(n) || n === null) {
    // only flow one buffer at a time
    if (state.flowing && state.buffer.length)
      return state.buffer[0].length;
    else
      return state.length;
  }

  if (n <= 0)
    return 0;

  // If we're asking for more than the target buffer level,
  // then raise the water mark.  Bump up to the next highest
  // power of 2, to prevent increasing it excessively in tiny
  // amounts.
  if (n > state.highWaterMark)
    state.highWaterMark = roundUpToNextPowerOf2(n);

  // don't have that much.  return null, unless we've ended.
  if (n > state.length) {
    if (!state.ended) {
      state.needReadable = true;
      return 0;
    } else
      return state.length;
  }

  return n;
}

// you can override either this method, or the async _read(n) below.
Readable$2.prototype.read = function(n) {
  var state = this._readableState;
  state.calledRead = true;
  var nOrig = n;

  if (typeof n !== 'number' || n > 0)
    state.emittedReadable = false;

  // if we're doing read(0) to trigger a readable event, but we
  // already have a bunch of data in the buffer, then just trigger
  // the 'readable' event and move on.
  if (n === 0 &&
      state.needReadable &&
      (state.length >= state.highWaterMark || state.ended)) {
    emitReadable(this);
    return null;
  }

  n = howMuchToRead(n, state);

  // if we've ended, and we're now clear, then finish it up.
  if (n === 0 && state.ended) {
    if (state.length === 0)
      endReadable(this);
    return null;
  }

  // All the actual chunk generation logic needs to be
  // *below* the call to _read.  The reason is that in certain
  // synthetic stream cases, such as passthrough streams, _read
  // may be a completely synchronous operation which may change
  // the state of the read buffer, providing enough data when
  // before there was *not* enough.
  //
  // So, the steps are:
  // 1. Figure out what the state of things will be after we do
  // a read from the buffer.
  //
  // 2. If that resulting state will trigger a _read, then call _read.
  // Note that this may be asynchronous, or synchronous.  Yes, it is
  // deeply ugly to write APIs this way, but that still doesn't mean
  // that the Readable class should behave improperly, as streams are
  // designed to be sync/async agnostic.
  // Take note if the _read call is sync or async (ie, if the read call
  // has returned yet), so that we know whether or not it's safe to emit
  // 'readable' etc.
  //
  // 3. Actually pull the requested chunks out of the buffer and return.

  // if we need a readable event, then we need to do some reading.
  var doRead = state.needReadable;

  // if we currently have less than the highWaterMark, then also read some
  if (state.length - n <= state.highWaterMark)
    doRead = true;

  // however, if we've ended, then there's no point, and if we're already
  // reading, then it's unnecessary.
  if (state.ended || state.reading)
    doRead = false;

  if (doRead) {
    state.reading = true;
    state.sync = true;
    // if the length is currently zero, then we *need* a readable event.
    if (state.length === 0)
      state.needReadable = true;
    // call internal read method
    this._read(state.highWaterMark);
    state.sync = false;
  }

  // If _read called its callback synchronously, then `reading`
  // will be false, and we need to re-evaluate how much data we
  // can return to the user.
  if (doRead && !state.reading)
    n = howMuchToRead(nOrig, state);

  var ret;
  if (n > 0)
    ret = fromList(n, state);
  else
    ret = null;

  if (ret === null) {
    state.needReadable = true;
    n = 0;
  }

  state.length -= n;

  // If we have nothing in the buffer, then we want to know
  // as soon as we *do* get something into the buffer.
  if (state.length === 0 && !state.ended)
    state.needReadable = true;

  // If we happened to read() exactly the remaining amount in the
  // buffer, and the EOF has been seen at this point, then make sure
  // that we emit 'end' on the very next tick.
  if (state.ended && !state.endEmitted && state.length === 0)
    endReadable(this);

  return ret;
};

function chunkInvalid(state, chunk) {
  var er = null;
  if (!Buffer$1.isBuffer(chunk) &&
      'string' !== typeof chunk &&
      chunk !== null &&
      chunk !== undefined &&
      !state.objectMode &&
      !er) {
    er = new TypeError('Invalid non-string/buffer chunk');
  }
  return er;
}


function onEofChunk(stream, state) {
  if (state.decoder && !state.ended) {
    var chunk = state.decoder.end();
    if (chunk && chunk.length) {
      state.buffer.push(chunk);
      state.length += state.objectMode ? 1 : chunk.length;
    }
  }
  state.ended = true;

  // if we've ended and we have some data left, then emit
  // 'readable' now to make sure it gets picked up.
  if (state.length > 0)
    emitReadable(stream);
  else
    endReadable(stream);
}

// Don't emit readable right away in sync mode, because this can trigger
// another read() call => stack overflow.  This way, it might trigger
// a nextTick recursion warning, but that's not so bad.
function emitReadable(stream) {
  var state = stream._readableState;
  state.needReadable = false;
  if (state.emittedReadable)
    return;

  state.emittedReadable = true;
  if (state.sync)
    process.nextTick(function() {
      emitReadable_(stream);
    });
  else
    emitReadable_(stream);
}

function emitReadable_(stream) {
  stream.emit('readable');
}


// at this point, the user has presumably seen the 'readable' event,
// and called read() to consume some data.  that may have triggered
// in turn another _read(n) call, in which case reading = true if
// it's in progress.
// However, if we're not ended, or reading, and the length < hwm,
// then go ahead and try to read some more preemptively.
function maybeReadMore(stream, state) {
  if (!state.readingMore) {
    state.readingMore = true;
    process.nextTick(function() {
      maybeReadMore_(stream, state);
    });
  }
}

function maybeReadMore_(stream, state) {
  var len = state.length;
  while (!state.reading && !state.flowing && !state.ended &&
         state.length < state.highWaterMark) {
    stream.read(0);
    if (len === state.length)
      // didn't get any data, stop spinning.
      break;
    else
      len = state.length;
  }
  state.readingMore = false;
}

// abstract method.  to be overridden in specific implementation classes.
// call cb(er, data) where data is <= n in length.
// for virtual (non-string, non-buffer) streams, "length" is somewhat
// arbitrary, and perhaps not very meaningful.
Readable$2.prototype._read = function(n) {
  this.emit('error', new Error('not implemented'));
};

Readable$2.prototype.pipe = function(dest, pipeOpts) {
  var src = this;
  var state = this._readableState;

  switch (state.pipesCount) {
    case 0:
      state.pipes = dest;
      break;
    case 1:
      state.pipes = [state.pipes, dest];
      break;
    default:
      state.pipes.push(dest);
      break;
  }
  state.pipesCount += 1;

  var doEnd = (!pipeOpts || pipeOpts.end !== false) &&
              dest !== process.stdout &&
              dest !== process.stderr;

  var endFn = doEnd ? onend : cleanup;
  if (state.endEmitted)
    process.nextTick(endFn);
  else
    src.once('end', endFn);

  dest.on('unpipe', onunpipe);
  function onunpipe(readable) {
    if (readable !== src) return;
    cleanup();
  }

  function onend() {
    dest.end();
  }

  // when the dest drains, it reduces the awaitDrain counter
  // on the source.  This would be more elegant with a .once()
  // handler in flow(), but adding and removing repeatedly is
  // too slow.
  var ondrain = pipeOnDrain(src);
  dest.on('drain', ondrain);

  function cleanup() {
    // cleanup event handlers once the pipe is broken
    dest.removeListener('close', onclose);
    dest.removeListener('finish', onfinish);
    dest.removeListener('drain', ondrain);
    dest.removeListener('error', onerror);
    dest.removeListener('unpipe', onunpipe);
    src.removeListener('end', onend);
    src.removeListener('end', cleanup);

    // if the reader is waiting for a drain event from this
    // specific writer, then it would cause it to never start
    // flowing again.
    // So, if this is awaiting a drain, then we just call it now.
    // If we don't know, then assume that we are waiting for one.
    if (!dest._writableState || dest._writableState.needDrain)
      ondrain();
  }

  // if the dest has an error, then stop piping into it.
  // however, don't suppress the throwing behavior for this.
  function onerror(er) {
    unpipe();
    dest.removeListener('error', onerror);
    if (EE.listenerCount(dest, 'error') === 0)
      dest.emit('error', er);
  }
  // This is a brutally ugly hack to make sure that our error handler
  // is attached before any userland ones.  NEVER DO THIS.
  if (!dest._events || !dest._events.error)
    dest.on('error', onerror);
  else if (isArray(dest._events.error))
    dest._events.error.unshift(onerror);
  else
    dest._events.error = [onerror, dest._events.error];



  // Both close and finish should trigger unpipe, but only once.
  function onclose() {
    dest.removeListener('finish', onfinish);
    unpipe();
  }
  dest.once('close', onclose);
  function onfinish() {
    dest.removeListener('close', onclose);
    unpipe();
  }
  dest.once('finish', onfinish);

  function unpipe() {
    src.unpipe(dest);
  }

  // tell the dest that it's being piped to
  dest.emit('pipe', src);

  // start the flow if it hasn't been started already.
  if (!state.flowing) {
    // the handler that waits for readable events after all
    // the data gets sucked out in flow.
    // This would be easier to follow with a .once() handler
    // in flow(), but that is too slow.
    this.on('readable', pipeOnReadable);

    state.flowing = true;
    process.nextTick(function() {
      flow(src);
    });
  }

  return dest;
};

function pipeOnDrain(src) {
  return function() {
    var state = src._readableState;
    state.awaitDrain--;
    if (state.awaitDrain === 0)
      flow(src);
  };
}

function flow(src) {
  var state = src._readableState;
  var chunk;
  state.awaitDrain = 0;

  function write(dest, i, list) {
    var written = dest.write(chunk);
    if (false === written) {
      state.awaitDrain++;
    }
  }

  while (state.pipesCount && null !== (chunk = src.read())) {

    if (state.pipesCount === 1)
      write(state.pipes);
    else
      forEach(state.pipes, write);

    src.emit('data', chunk);

    // if anyone needs a drain, then we have to wait for that.
    if (state.awaitDrain > 0)
      return;
  }

  // if every destination was unpiped, either before entering this
  // function, or in the while loop, then stop flowing.
  //
  // NB: This is a pretty rare edge case.
  if (state.pipesCount === 0) {
    state.flowing = false;

    // if there were data event listeners added, then switch to old mode.
    if (EE.listenerCount(src, 'data') > 0)
      emitDataEvents(src);
    return;
  }

  // at this point, no one needed a drain, so we just ran out of data
  // on the next readable event, start it over again.
  state.ranOut = true;
}

function pipeOnReadable() {
  if (this._readableState.ranOut) {
    this._readableState.ranOut = false;
    flow(this);
  }
}


Readable$2.prototype.unpipe = function(dest) {
  var state = this._readableState;

  // if we're not piping anywhere, then do nothing.
  if (state.pipesCount === 0)
    return this;

  // just one destination.  most common case.
  if (state.pipesCount === 1) {
    // passed in one, but it's not the right one.
    if (dest && dest !== state.pipes)
      return this;

    if (!dest)
      dest = state.pipes;

    // got a match.
    state.pipes = null;
    state.pipesCount = 0;
    this.removeListener('readable', pipeOnReadable);
    state.flowing = false;
    if (dest)
      dest.emit('unpipe', this);
    return this;
  }

  // slow case. multiple pipe destinations.

  if (!dest) {
    // remove all.
    var dests = state.pipes;
    var len = state.pipesCount;
    state.pipes = null;
    state.pipesCount = 0;
    this.removeListener('readable', pipeOnReadable);
    state.flowing = false;

    for (var i = 0; i < len; i++)
      dests[i].emit('unpipe', this);
    return this;
  }

  // try to find the right one.
  var i = indexOf(state.pipes, dest);
  if (i === -1)
    return this;

  state.pipes.splice(i, 1);
  state.pipesCount -= 1;
  if (state.pipesCount === 1)
    state.pipes = state.pipes[0];

  dest.emit('unpipe', this);

  return this;
};

// set up data events if they are asked for
// Ensure readable listeners eventually get something
Readable$2.prototype.on = function(ev, fn) {
  var res = Stream.prototype.on.call(this, ev, fn);

  if (ev === 'data' && !this._readableState.flowing)
    emitDataEvents(this);

  if (ev === 'readable' && this.readable) {
    var state = this._readableState;
    if (!state.readableListening) {
      state.readableListening = true;
      state.emittedReadable = false;
      state.needReadable = true;
      if (!state.reading) {
        this.read(0);
      } else if (state.length) {
        emitReadable(this);
      }
    }
  }

  return res;
};
Readable$2.prototype.addListener = Readable$2.prototype.on;

// pause() and resume() are remnants of the legacy readable stream API
// If the user uses them, then switch into old mode.
Readable$2.prototype.resume = function() {
  emitDataEvents(this);
  this.read(0);
  this.emit('resume');
};

Readable$2.prototype.pause = function() {
  emitDataEvents(this, true);
  this.emit('pause');
};

function emitDataEvents(stream, startPaused) {
  var state = stream._readableState;

  if (state.flowing) {
    // https://github.com/isaacs/readable-stream/issues/16
    throw new Error('Cannot switch to old mode now.');
  }

  var paused = startPaused || false;
  var readable = false;

  // convert to an old-style stream.
  stream.readable = true;
  stream.pipe = Stream.prototype.pipe;
  stream.on = stream.addListener = Stream.prototype.on;

  stream.on('readable', function() {
    readable = true;

    var c;
    while (!paused && (null !== (c = stream.read())))
      stream.emit('data', c);

    if (c === null) {
      readable = false;
      stream._readableState.needReadable = true;
    }
  });

  stream.pause = function() {
    paused = true;
    this.emit('pause');
  };

  stream.resume = function() {
    paused = false;
    if (readable)
      process.nextTick(function() {
        stream.emit('readable');
      });
    else
      this.read(0);
    this.emit('resume');
  };

  // now make it start, just in case it hadn't already.
  stream.emit('readable');
}

// wrap an old-style stream as the async data source.
// This is *not* part of the readable stream interface.
// It is an ugly unfortunate mess of history.
Readable$2.prototype.wrap = function(stream) {
  var state = this._readableState;
  var paused = false;

  var self = this;
  stream.on('end', function() {
    if (state.decoder && !state.ended) {
      var chunk = state.decoder.end();
      if (chunk && chunk.length)
        self.push(chunk);
    }

    self.push(null);
  });

  stream.on('data', function(chunk) {
    if (state.decoder)
      chunk = state.decoder.write(chunk);
    if (!chunk || !state.objectMode && !chunk.length)
      return;

    var ret = self.push(chunk);
    if (!ret) {
      paused = true;
      stream.pause();
    }
  });

  // proxy all the other methods.
  // important when wrapping filters and duplexes.
  for (var i in stream) {
    if (typeof stream[i] === 'function' &&
        typeof this[i] === 'undefined') {
      this[i] = function(method) { return function() {
        return stream[method].apply(stream, arguments);
      }}(i);
    }
  }

  // proxy certain important events.
  var events = ['error', 'close', 'destroy', 'pause', 'resume'];
  forEach(events, function(ev) {
    stream.on(ev, self.emit.bind(self, ev));
  });

  // when we try to consume some more bytes, simply unpause the
  // underlying stream.
  self._read = function(n) {
    if (paused) {
      paused = false;
      stream.resume();
    }
  };

  return self;
};



// exposed for testing purposes only.
Readable$2._fromList = fromList;

// Pluck off n bytes from an array of buffers.
// Length is the combined lengths of all the buffers in the list.
function fromList(n, state) {
  var list = state.buffer;
  var length = state.length;
  var stringMode = !!state.decoder;
  var objectMode = !!state.objectMode;
  var ret;

  // nothing in the list, definitely empty.
  if (list.length === 0)
    return null;

  if (length === 0)
    ret = null;
  else if (objectMode)
    ret = list.shift();
  else if (!n || n >= length) {
    // read it all, truncate the array.
    if (stringMode)
      ret = list.join('');
    else
      ret = Buffer$1.concat(list, length);
    list.length = 0;
  } else {
    // read just some of it.
    if (n < list[0].length) {
      // just take a part of the first list item.
      // slice is the same for buffers and strings.
      var buf = list[0];
      ret = buf.slice(0, n);
      list[0] = buf.slice(n);
    } else if (n === list[0].length) {
      // first list is a perfect match
      ret = list.shift();
    } else {
      // complex case.
      // we have enough to cover it, but it spans past the first buffer.
      if (stringMode)
        ret = '';
      else
        ret = new Buffer$1(n);

      var c = 0;
      for (var i = 0, l = list.length; i < l && c < n; i++) {
        var buf = list[0];
        var cpy = Math.min(n - c, buf.length);

        if (stringMode)
          ret += buf.slice(0, cpy);
        else
          buf.copy(ret, c, 0, cpy);

        if (cpy < buf.length)
          list[0] = buf.slice(cpy);
        else
          list.shift();

        c += cpy;
      }
    }
  }

  return ret;
}

function endReadable(stream) {
  var state = stream._readableState;

  // If we get here before consuming all the bytes, then that is a
  // bug in node.  Should never happen.
  if (state.length > 0)
    throw new Error('endReadable called on non-empty stream');

  if (!state.endEmitted && state.calledRead) {
    state.ended = true;
    process.nextTick(function() {
      // Check that we didn't get one last unshift.
      if (!state.endEmitted && state.length === 0) {
        state.endEmitted = true;
        stream.readable = false;
        stream.emit('end');
      }
    });
  }
}

function forEach (xs, f) {
  for (var i = 0, l = xs.length; i < l; i++) {
    f(xs[i], i);
  }
}

function indexOf (xs, x) {
  for (var i = 0, l = xs.length; i < l; i++) {
    if (xs[i] === x) return i;
  }
  return -1;
}

var _stream_duplex$1;
var hasRequired_stream_duplex$1;

function require_stream_duplex$1 () {
	if (hasRequired_stream_duplex$1) return _stream_duplex$1;
	hasRequired_stream_duplex$1 = 1;
	// Copyright Joyent, Inc. and other Node contributors.
	//
	// Permission is hereby granted, free of charge, to any person obtaining a
	// copy of this software and associated documentation files (the
	// "Software"), to deal in the Software without restriction, including
	// without limitation the rights to use, copy, modify, merge, publish,
	// distribute, sublicense, and/or sell copies of the Software, and to permit
	// persons to whom the Software is furnished to do so, subject to the
	// following conditions:
	//
	// The above copyright notice and this permission notice shall be included
	// in all copies or substantial portions of the Software.
	//
	// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
	// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
	// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
	// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
	// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
	// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
	// USE OR OTHER DEALINGS IN THE SOFTWARE.

	// a duplex stream is just a stream that is both readable and writable.
	// Since JS doesn't have multiple prototypal inheritance, this class
	// prototypally inherits from Readable, and then parasitically from
	// Writable.

	_stream_duplex$1 = Duplex;

	/*<replacement>*/
	var objectKeys = Object.keys || function (obj) {
	  var keys = [];
	  for (var key in obj) keys.push(key);
	  return keys;
	};
	/*</replacement>*/


	/*<replacement>*/
	var util = util$4;
	util.inherits = inherits_browser.exports;
	/*</replacement>*/

	var Readable = _stream_readable$1;
	var Writable = require_stream_writable$1();

	util.inherits(Duplex, Readable);

	forEach(objectKeys(Writable.prototype), function(method) {
	  if (!Duplex.prototype[method])
	    Duplex.prototype[method] = Writable.prototype[method];
	});

	function Duplex(options) {
	  if (!(this instanceof Duplex))
	    return new Duplex(options);

	  Readable.call(this, options);
	  Writable.call(this, options);

	  if (options && options.readable === false)
	    this.readable = false;

	  if (options && options.writable === false)
	    this.writable = false;

	  this.allowHalfOpen = true;
	  if (options && options.allowHalfOpen === false)
	    this.allowHalfOpen = false;

	  this.once('end', onend);
	}

	// the no-half-open enforcer
	function onend() {
	  // if we allow half-open state, or if the writable side ended,
	  // then we're ok.
	  if (this.allowHalfOpen || this._writableState.ended)
	    return;

	  // no more data can be written.
	  // But allow more writes to happen in this tick.
	  process.nextTick(this.end.bind(this));
	}

	function forEach (xs, f) {
	  for (var i = 0, l = xs.length; i < l; i++) {
	    f(xs[i], i);
	  }
	}
	return _stream_duplex$1;
}

var _stream_writable$1;
var hasRequired_stream_writable$1;

function require_stream_writable$1 () {
	if (hasRequired_stream_writable$1) return _stream_writable$1;
	hasRequired_stream_writable$1 = 1;
	// Copyright Joyent, Inc. and other Node contributors.
	//
	// Permission is hereby granted, free of charge, to any person obtaining a
	// copy of this software and associated documentation files (the
	// "Software"), to deal in the Software without restriction, including
	// without limitation the rights to use, copy, modify, merge, publish,
	// distribute, sublicense, and/or sell copies of the Software, and to permit
	// persons to whom the Software is furnished to do so, subject to the
	// following conditions:
	//
	// The above copyright notice and this permission notice shall be included
	// in all copies or substantial portions of the Software.
	//
	// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
	// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
	// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
	// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
	// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
	// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
	// USE OR OTHER DEALINGS IN THE SOFTWARE.

	// A bit simpler than readable streams.
	// Implement an async ._write(chunk, cb), and it'll handle all
	// the drain event emission and buffering.

	_stream_writable$1 = Writable;

	/*<replacement>*/
	var Buffer = require$$0.Buffer;
	/*</replacement>*/

	Writable.WritableState = WritableState;


	/*<replacement>*/
	var util = util$4;
	util.inherits = inherits_browser.exports;
	/*</replacement>*/


	var Stream = require$$3$1;

	util.inherits(Writable, Stream);

	function WriteReq(chunk, encoding, cb) {
	  this.chunk = chunk;
	  this.encoding = encoding;
	  this.callback = cb;
	}

	function WritableState(options, stream) {
	  options = options || {};

	  // the point at which write() starts returning false
	  // Note: 0 is a valid value, means that we always return false if
	  // the entire buffer is not flushed immediately on write()
	  var hwm = options.highWaterMark;
	  this.highWaterMark = (hwm || hwm === 0) ? hwm : 16 * 1024;

	  // object stream flag to indicate whether or not this stream
	  // contains buffers or objects.
	  this.objectMode = !!options.objectMode;

	  // cast to ints.
	  this.highWaterMark = ~~this.highWaterMark;

	  this.needDrain = false;
	  // at the start of calling end()
	  this.ending = false;
	  // when end() has been called, and returned
	  this.ended = false;
	  // when 'finish' is emitted
	  this.finished = false;

	  // should we decode strings into buffers before passing to _write?
	  // this is here so that some node-core streams can optimize string
	  // handling at a lower level.
	  var noDecode = options.decodeStrings === false;
	  this.decodeStrings = !noDecode;

	  // Crypto is kind of old and crusty.  Historically, its default string
	  // encoding is 'binary' so we have to make this configurable.
	  // Everything else in the universe uses 'utf8', though.
	  this.defaultEncoding = options.defaultEncoding || 'utf8';

	  // not an actual buffer we keep track of, but a measurement
	  // of how much we're waiting to get pushed to some underlying
	  // socket or file.
	  this.length = 0;

	  // a flag to see when we're in the middle of a write.
	  this.writing = false;

	  // a flag to be able to tell if the onwrite cb is called immediately,
	  // or on a later tick.  We set this to true at first, becuase any
	  // actions that shouldn't happen until "later" should generally also
	  // not happen before the first write call.
	  this.sync = true;

	  // a flag to know if we're processing previously buffered items, which
	  // may call the _write() callback in the same tick, so that we don't
	  // end up in an overlapped onwrite situation.
	  this.bufferProcessing = false;

	  // the callback that's passed to _write(chunk,cb)
	  this.onwrite = function(er) {
	    onwrite(stream, er);
	  };

	  // the callback that the user supplies to write(chunk,encoding,cb)
	  this.writecb = null;

	  // the amount that is being written when _write is called.
	  this.writelen = 0;

	  this.buffer = [];

	  // True if the error was already emitted and should not be thrown again
	  this.errorEmitted = false;
	}

	function Writable(options) {
	  var Duplex = require_stream_duplex$1();

	  // Writable ctor is applied to Duplexes, though they're not
	  // instanceof Writable, they're instanceof Readable.
	  if (!(this instanceof Writable) && !(this instanceof Duplex))
	    return new Writable(options);

	  this._writableState = new WritableState(options, this);

	  // legacy.
	  this.writable = true;

	  Stream.call(this);
	}

	// Otherwise people can pipe Writable streams, which is just wrong.
	Writable.prototype.pipe = function() {
	  this.emit('error', new Error('Cannot pipe. Not readable.'));
	};


	function writeAfterEnd(stream, state, cb) {
	  var er = new Error('write after end');
	  // TODO: defer error events consistently everywhere, not just the cb
	  stream.emit('error', er);
	  process.nextTick(function() {
	    cb(er);
	  });
	}

	// If we get something that is not a buffer, string, null, or undefined,
	// and we're not in objectMode, then that's an error.
	// Otherwise stream chunks are all considered to be of length=1, and the
	// watermarks determine how many objects to keep in the buffer, rather than
	// how many bytes or characters.
	function validChunk(stream, state, chunk, cb) {
	  var valid = true;
	  if (!Buffer.isBuffer(chunk) &&
	      'string' !== typeof chunk &&
	      chunk !== null &&
	      chunk !== undefined &&
	      !state.objectMode) {
	    var er = new TypeError('Invalid non-string/buffer chunk');
	    stream.emit('error', er);
	    process.nextTick(function() {
	      cb(er);
	    });
	    valid = false;
	  }
	  return valid;
	}

	Writable.prototype.write = function(chunk, encoding, cb) {
	  var state = this._writableState;
	  var ret = false;

	  if (typeof encoding === 'function') {
	    cb = encoding;
	    encoding = null;
	  }

	  if (Buffer.isBuffer(chunk))
	    encoding = 'buffer';
	  else if (!encoding)
	    encoding = state.defaultEncoding;

	  if (typeof cb !== 'function')
	    cb = function() {};

	  if (state.ended)
	    writeAfterEnd(this, state, cb);
	  else if (validChunk(this, state, chunk, cb))
	    ret = writeOrBuffer(this, state, chunk, encoding, cb);

	  return ret;
	};

	function decodeChunk(state, chunk, encoding) {
	  if (!state.objectMode &&
	      state.decodeStrings !== false &&
	      typeof chunk === 'string') {
	    chunk = new Buffer(chunk, encoding);
	  }
	  return chunk;
	}

	// if we're already writing something, then just put this
	// in the queue, and wait our turn.  Otherwise, call _write
	// If we return false, then we need a drain event, so set that flag.
	function writeOrBuffer(stream, state, chunk, encoding, cb) {
	  chunk = decodeChunk(state, chunk, encoding);
	  if (Buffer.isBuffer(chunk))
	    encoding = 'buffer';
	  var len = state.objectMode ? 1 : chunk.length;

	  state.length += len;

	  var ret = state.length < state.highWaterMark;
	  // we must ensure that previous needDrain will not be reset to false.
	  if (!ret)
	    state.needDrain = true;

	  if (state.writing)
	    state.buffer.push(new WriteReq(chunk, encoding, cb));
	  else
	    doWrite(stream, state, len, chunk, encoding, cb);

	  return ret;
	}

	function doWrite(stream, state, len, chunk, encoding, cb) {
	  state.writelen = len;
	  state.writecb = cb;
	  state.writing = true;
	  state.sync = true;
	  stream._write(chunk, encoding, state.onwrite);
	  state.sync = false;
	}

	function onwriteError(stream, state, sync, er, cb) {
	  if (sync)
	    process.nextTick(function() {
	      cb(er);
	    });
	  else
	    cb(er);

	  stream._writableState.errorEmitted = true;
	  stream.emit('error', er);
	}

	function onwriteStateUpdate(state) {
	  state.writing = false;
	  state.writecb = null;
	  state.length -= state.writelen;
	  state.writelen = 0;
	}

	function onwrite(stream, er) {
	  var state = stream._writableState;
	  var sync = state.sync;
	  var cb = state.writecb;

	  onwriteStateUpdate(state);

	  if (er)
	    onwriteError(stream, state, sync, er, cb);
	  else {
	    // Check if we're actually ready to finish, but don't emit yet
	    var finished = needFinish(stream, state);

	    if (!finished && !state.bufferProcessing && state.buffer.length)
	      clearBuffer(stream, state);

	    if (sync) {
	      process.nextTick(function() {
	        afterWrite(stream, state, finished, cb);
	      });
	    } else {
	      afterWrite(stream, state, finished, cb);
	    }
	  }
	}

	function afterWrite(stream, state, finished, cb) {
	  if (!finished)
	    onwriteDrain(stream, state);
	  cb();
	  if (finished)
	    finishMaybe(stream, state);
	}

	// Must force callback to be called on nextTick, so that we don't
	// emit 'drain' before the write() consumer gets the 'false' return
	// value, and has a chance to attach a 'drain' listener.
	function onwriteDrain(stream, state) {
	  if (state.length === 0 && state.needDrain) {
	    state.needDrain = false;
	    stream.emit('drain');
	  }
	}


	// if there's something in the buffer waiting, then process it
	function clearBuffer(stream, state) {
	  state.bufferProcessing = true;

	  for (var c = 0; c < state.buffer.length; c++) {
	    var entry = state.buffer[c];
	    var chunk = entry.chunk;
	    var encoding = entry.encoding;
	    var cb = entry.callback;
	    var len = state.objectMode ? 1 : chunk.length;

	    doWrite(stream, state, len, chunk, encoding, cb);

	    // if we didn't call the onwrite immediately, then
	    // it means that we need to wait until it does.
	    // also, that means that the chunk and cb are currently
	    // being processed, so move the buffer counter past them.
	    if (state.writing) {
	      c++;
	      break;
	    }
	  }

	  state.bufferProcessing = false;
	  if (c < state.buffer.length)
	    state.buffer = state.buffer.slice(c);
	  else
	    state.buffer.length = 0;
	}

	Writable.prototype._write = function(chunk, encoding, cb) {
	  cb(new Error('not implemented'));
	};

	Writable.prototype.end = function(chunk, encoding, cb) {
	  var state = this._writableState;

	  if (typeof chunk === 'function') {
	    cb = chunk;
	    chunk = null;
	    encoding = null;
	  } else if (typeof encoding === 'function') {
	    cb = encoding;
	    encoding = null;
	  }

	  if (typeof chunk !== 'undefined' && chunk !== null)
	    this.write(chunk, encoding);

	  // ignore unnecessary end() calls.
	  if (!state.ending && !state.finished)
	    endWritable(this, state, cb);
	};


	function needFinish(stream, state) {
	  return (state.ending &&
	          state.length === 0 &&
	          !state.finished &&
	          !state.writing);
	}

	function finishMaybe(stream, state) {
	  var need = needFinish(stream, state);
	  if (need) {
	    state.finished = true;
	    stream.emit('finish');
	  }
	  return need;
	}

	function endWritable(stream, state, cb) {
	  state.ending = true;
	  finishMaybe(stream, state);
	  if (cb) {
	    if (state.finished)
	      process.nextTick(cb);
	    else
	      stream.once('finish', cb);
	  }
	  state.ended = true;
	}
	return _stream_writable$1;
}

(function (module) {
	module.exports = require_stream_writable$1();
} (writable));

var readable = {exports: {}};

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


// a transform stream is a readable/writable stream where you do
// something with the data.  Sometimes it's called a "filter",
// but that's not a great name for it, since that implies a thing where
// some bits pass through, and others are simply ignored.  (That would
// be a valid example of a transform, of course.)
//
// While the output is causally related to the input, it's not a
// necessarily symmetric or synchronous transformation.  For example,
// a zlib stream might take multiple plain-text writes(), and then
// emit a single compressed chunk some time in the future.
//
// Here's how this works:
//
// The Transform stream has all the aspects of the readable and writable
// stream classes.  When you write(chunk), that calls _write(chunk,cb)
// internally, and returns false if there's a lot of pending writes
// buffered up.  When you call read(), that calls _read(n) until
// there's enough pending readable data buffered up.
//
// In a transform stream, the written data is placed in a buffer.  When
// _read(n) is called, it transforms the queued up data, calling the
// buffered _write cb's as it consumes chunks.  If consuming a single
// written chunk would result in multiple output chunks, then the first
// outputted bit calls the readcb, and subsequent chunks just go into
// the read buffer, and will cause it to emit 'readable' if necessary.
//
// This way, back-pressure is actually determined by the reading side,
// since _read has to be called to start processing a new chunk.  However,
// a pathological inflate type of transform can cause excessive buffering
// here.  For example, imagine a stream where every byte of input is
// interpreted as an integer from 0-255, and then results in that many
// bytes of output.  Writing the 4 bytes {ff,ff,ff,ff} would result in
// 1kb of data being output.  In this case, you could write a very small
// amount of input, and end up with a very large amount of output.  In
// such a pathological inflating mechanism, there'd be no way to tell
// the system to stop doing the transform.  A single 4MB write could
// cause the system to run out of memory.
//
// However, even in such a pathological case, only a single written chunk
// would be consumed, and then the rest would wait (un-transformed) until
// the results of the previous transformed chunk were consumed.

var _stream_transform$1 = Transform$3;

var Duplex$1 = require_stream_duplex$1();

/*<replacement>*/
var util$2 = util$4;
util$2.inherits = inherits_browser.exports;
/*</replacement>*/

util$2.inherits(Transform$3, Duplex$1);


function TransformState(options, stream) {
  this.afterTransform = function(er, data) {
    return afterTransform$1(stream, er, data);
  };

  this.needTransform = false;
  this.transforming = false;
  this.writecb = null;
  this.writechunk = null;
}

function afterTransform$1(stream, er, data) {
  var ts = stream._transformState;
  ts.transforming = false;

  var cb = ts.writecb;

  if (!cb)
    return stream.emit('error', new Error('no writecb in Transform class'));

  ts.writechunk = null;
  ts.writecb = null;

  if (data !== null && data !== undefined)
    stream.push(data);

  if (cb)
    cb(er);

  var rs = stream._readableState;
  rs.reading = false;
  if (rs.needReadable || rs.length < rs.highWaterMark) {
    stream._read(rs.highWaterMark);
  }
}


function Transform$3(options) {
  if (!(this instanceof Transform$3))
    return new Transform$3(options);

  Duplex$1.call(this, options);

  this._transformState = new TransformState(options, this);

  // when the writable side finishes, then flush out anything remaining.
  var stream = this;

  // start out asking for a readable event once data is transformed.
  this._readableState.needReadable = true;

  // we have implemented the _read method, and done the other things
  // that Readable wants before the first _read call, so unset the
  // sync guard flag.
  this._readableState.sync = false;

  this.once('finish', function() {
    if ('function' === typeof this._flush)
      this._flush(function(er) {
        done$1(stream, er);
      });
    else
      done$1(stream);
  });
}

Transform$3.prototype.push = function(chunk, encoding) {
  this._transformState.needTransform = false;
  return Duplex$1.prototype.push.call(this, chunk, encoding);
};

// This is the part where you do stuff!
// override this function in implementation classes.
// 'chunk' is an input chunk.
//
// Call `push(newChunk)` to pass along transformed output
// to the readable side.  You may call 'push' zero or more times.
//
// Call `cb(err)` when you are done with this chunk.  If you pass
// an error, then that'll put the hurt on the whole operation.  If you
// never call cb(), then you'll never get another chunk.
Transform$3.prototype._transform = function(chunk, encoding, cb) {
  throw new Error('not implemented');
};

Transform$3.prototype._write = function(chunk, encoding, cb) {
  var ts = this._transformState;
  ts.writecb = cb;
  ts.writechunk = chunk;
  ts.writeencoding = encoding;
  if (!ts.transforming) {
    var rs = this._readableState;
    if (ts.needTransform ||
        rs.needReadable ||
        rs.length < rs.highWaterMark)
      this._read(rs.highWaterMark);
  }
};

// Doesn't matter what the args are here.
// _transform does all the work.
// That we got here means that the readable side wants more data.
Transform$3.prototype._read = function(n) {
  var ts = this._transformState;

  if (ts.writechunk !== null && ts.writecb && !ts.transforming) {
    ts.transforming = true;
    this._transform(ts.writechunk, ts.writeencoding, ts.afterTransform);
  } else {
    // mark that we need a transform, so that any data that comes in
    // will get processed, now that we've asked for it.
    ts.needTransform = true;
  }
};


function done$1(stream, er) {
  if (er)
    return stream.emit('error', er);

  // if there's nothing in the write buffer, then that means
  // that nothing more will ever be provided
  var ws = stream._writableState;
  stream._readableState;
  var ts = stream._transformState;

  if (ws.length)
    throw new Error('calling transform done when ws.length != 0');

  if (ts.transforming)
    throw new Error('calling transform done when still transforming');

  return stream.push(null);
}

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

// a passthrough stream.
// basically just the most minimal sort of Transform stream.
// Every written chunk gets output as-is.

var _stream_passthrough$1 = PassThrough$1;

var Transform$2 = _stream_transform$1;

/*<replacement>*/
var util$1 = util$4;
util$1.inherits = inherits_browser.exports;
/*</replacement>*/

util$1.inherits(PassThrough$1, Transform$2);

function PassThrough$1(options) {
  if (!(this instanceof PassThrough$1))
    return new PassThrough$1(options);

  Transform$2.call(this, options);
}

PassThrough$1.prototype._transform = function(chunk, encoding, cb) {
  cb(null, chunk);
};

(function (module, exports) {
	exports = module.exports = _stream_readable$1;
	exports.Readable = exports;
	exports.Writable = require_stream_writable$1();
	exports.Duplex = require_stream_duplex$1();
	exports.Transform = _stream_transform$1;
	exports.PassThrough = _stream_passthrough$1;
} (readable, readable.exports));

var duplex = {exports: {}};

(function (module) {
	module.exports = require_stream_duplex$1();
} (duplex));

(function (exports) {
	var Writable = writable.exports;
	var Readable = readable.exports;
	var Duplex = duplex.exports;

	var DUMMY = new Buffer(0);
	var noop = function() {};

	var toFunction = function(fn) {
		if (typeof fn === 'function') return fn;
		return function(cb) {
			cb(null, fn);
		};
	};

	var onreadable = function(rs, init) {
		var reading = false;
		var destroyed = false;

		rs._read = function() {
			reading = true;
		};

		rs.destroy = function() {
			destroyed = true;
		};

		init(function(err, source) {
			if (err) return rs.emit('error', err);

			var fwd = function() {
				var data;
				while ((data = source.read()) !== null) {
					reading = false;
					rs.push(data);
				}
			};

			source.on('readable', function() {
				if (reading) fwd();
			});

			source.on('end', function() {
				fwd();
				rs.push(null);
			});

			source.on('error', function(err) {
				rs.emit('error', err);
			});

			source.on('close', function() {
				fwd();
				process.nextTick(function() {
					rs.emit('close');
				});
			});

			rs._read = function() {
				reading = true;
				fwd();
			};

			rs.destroy = function() {
				if (destroyed) return;
				destroyed = true;
				if (source.destroy) source.destroy();
			};

			if (destroyed) {
				destroyed = false;
				rs.destroy();
				return;
			}

			if (reading) fwd();
		});

		return rs;
	};

	var onwritable = function(ws, init) {
		var ready = noop;
		var destroyed = false;

		ws._write = function(data, enc, cb) {
			ready = cb;
		};

		ws.destroy = function() {
			destroyed = true;
		};

		ws.write(DUMMY);

		init(function(err, source) {
			if (err) return ws.emit('error', err);

			source.on('close', function() {
				ws.emit('close');
			});

			source.on('error', function(err) {
				ws.emit('error', err);
			});

			ws._write = function(data, enc, cb) {
				if (data === DUMMY) return cb();
				source.write(data, enc, cb);
			};

			var emit = ws.emit;

			source.on('finish', function() {
				emit.call(ws, 'finish');
			});

			ws.destroy = function() {
				if (destroyed) return;
				destroyed = true;
				if (source.destroy) source.destroy();
			};

			ws.emit = function(name) {
				if (name !== 'finish') return emit.apply(ws, arguments);
				source.end();
			};

			if (destroyed) {
				destroyed = false;
				ws.destroy();
				return;
			}

			ready();
		});

		return ws;
	};

	exports.readable = function(opts, init) {
		if (arguments.length === 1) return exports.readable(null, opts);
		if (!opts) opts = {};
		return onreadable(new Readable(opts), toFunction(init));
	};

	exports.writable = function(opts, init) {
		if (arguments.length === 1) return exports.writable(null, opts);
		if (!opts) opts = {};
		return onwritable(new Writable(opts), toFunction(init));
	};

	exports.duplex = function(opts, initWritable, initReadable) {
		if (arguments.length === 2) return exports.duplex(null, opts, initWritable);
		if (!opts) opts = {};
		var dupl = new Duplex(opts);
		onwritable(dupl, toFunction(initWritable));
		onreadable(dupl, toFunction(initReadable));
		return dupl;
	};
} (fwdStream));

var range = {exports: {}};

(function (module, exports) {
	var ltgt = ltgt$3;

	//compare two array items
	function isArrayLike (a) {
	  return Array.isArray(a) || Buffer.isBuffer(a)
	}

	function isPrimitive (a) {
	  return 'string' === typeof a || 'number' === typeof a
	}

	function has(o, k) {
	  return Object.hasOwnProperty.call(o, k)
	}

	function compare (a, b) {
	  if(isArrayLike(a) && isArrayLike(b)) {
	    var l = Math.min(a.length, b.length);
	    for(var i = 0; i < l; i++) {
	      var c = compare(a[i], b[i]);
	      if(c) return c
	    }
	    return a.length - b.length
	  }
	  if(isPrimitive(a) && isPrimitive(b))
	    return a < b ? -1 : a > b ? 1 : 0

	  throw new Error('items not comparable:'
	    + JSON.stringify(a) + ' ' + JSON.stringify(b))
	}

	//this assumes that the prefix is of the form:
	// [Array, string]

	function prefix (a, b) {
	  if(a.length > b.length) return false
	  var l = a.length - 1;
	  var lastA = a[l];
	  var lastB = b[l];

	  if(typeof lastA !== typeof lastB)
	    return false

	  if('string' == typeof lastA
	    && 0 != lastB.indexOf(lastA))
	      return false
	  
	  //handle cas where there is no key prefix
	  //(a hook on an entire sublevel)
	  if(a.length == 1 && isArrayLike(lastA)) l ++;
	  
	  while(l--) {
	    if(compare(a[l], b[l])) return false
	  }
	  return true
	}

	exports = module.exports = function (range, key, _compare) {
	  _compare = _compare || compare;
	  //handle prefix specially,
	  //check that everything up to the last item is equal
	  //then check the last item starts with
	  if(isArrayLike(range)) return prefix(range, key)

	  return ltgt.contains(range, key, _compare)
	};

	function addPrefix(prefix, range) {
	  var o = ltgt.toLtgt(range, null, function (key) {
	    return [prefix, key]
	  });

	  //if there where no ranges, then then just use a prefix.
	  if(!has(o, 'gte') && !has(o, 'lte')) return [prefix]

	  return o
	}

	exports.compare = compare;
	exports.prefix = prefix;
	exports.addPrefix = addPrefix;
} (range, range.exports));

var inRange = range.exports;

var hooks$1 = function (compare) {
  var hooks = [];

  return {
    add: function (range, hook) {
      var m = {range: range, hook: hook};
      hooks.push(m);
      //call this to remove
      return function () {
        var i = hooks.indexOf(m);
        if(~i) return hooks.splice(i, 1)
      }

    },

    //remove all listeners within a range.
    //this will be used to close a sublevel.
    removeAll: function (range) {
      throw new Error('not implemented')
    },

    trigger: function (key, args) {
      for(var i = 0; i < hooks.length; i++) {
        var test = hooks[i];
        if(inRange(test.range, key, compare))
          test.hook.apply(this, args);
      }
    }
  }
};

var hooks = hooks$1;
var ltgt$1 = ltgt$3;

function isFunction$1 (f) {
  return 'function' === typeof f
}

function getPrefix (db) {
  if(db == null) return db
  if(isFunction$1(db.prefix)) return db.prefix()
  return db
}

function clone (_obj) {
  var obj = {};
  for(var k in _obj)
    obj[k] = _obj[k];
  return obj
}

var nut$1 = function (db, precodec, codec, compare) {
  var prehooks = hooks(compare);
  var posthooks = hooks(compare);
  var waiting = [], ready = false;

  function encodePrefix(prefix, key, opts1, opts2) {
    return precodec.encode([ prefix, codec.encodeKey(key, opts1, opts2 ) ])
  }

  function addEncodings(op, prefix) {
    if(prefix && prefix.options) {
      op.keyEncoding =
        op.keyEncoding || prefix.options.keyEncoding;
      op.valueEncoding =
        op.valueEncoding || prefix.options.valueEncoding;
    }
    return op
  }

  function start () {
    ready = true;
    while(waiting.length)
      waiting.shift()();
  }

  if(isFunction$1(db.isOpen)) {
    if(db.isOpen())
      ready = true;
    else
      db.open(start);
  } else {
    db.open(start);
  }

  return {
    location: db.location,
    apply: function (ops, opts, cb) {
      //apply prehooks here.
      for(var i = 0; i < ops.length; i++) {
        var op = ops[i];

        function add(op) {
          if(op === false) return delete ops[i]
          ops.push(op);
        }

        addEncodings(op, op.prefix);
        op.prefix = getPrefix(op.prefix);
        prehooks.trigger([op.prefix, op.key], [op, add, ops]);
      }

      opts = opts || {};

      if('object' !== typeof opts) throw new Error('opts must be object, was:'+ opts) 

      if('function' === typeof opts) cb = opts, opts = {};

      if(ops.length)
        (db.db || db).batch(
          ops.map(function (op) {
            return {
              key: encodePrefix(op.prefix, op.key, opts, op),
              value:
                  op.type !== 'del'
                ? codec.encodeValue(
                    op.value,
                    opts,
                    op
                  )
                : undefined,
              type:
                op.type || (op.value === undefined ? 'del' : 'put')
            }
          }),
          opts,
          function (err) {
              if(err) return cb(err)
            ops.forEach(function (op) {
              posthooks.trigger([op.prefix, op.key], [op]);
            });
            cb();
          }
        );
      else
        cb();
    },
    get: function (key, prefix, opts, cb) {
      opts.asBuffer = codec.isValueAsBuffer(opts);
      return (db.db || db).get(
        encodePrefix(prefix, key, opts),
        opts,
        function (err, value) {
          if(err) cb(err);
          else    cb(null, codec.decodeValue(value, opts));
        }
      )
    },
    pre: prehooks.add,
    post: posthooks.add,
    createDecoder: function (opts) {
      if(opts.keys !== false && opts.values !== false)
        return function (key, value) {
          return {
            key: codec.decodeKey(precodec.decode(key)[1], opts),
            value: codec.decodeValue(value, opts)
          }
        }
      if(opts.values !== false)
        return function (_, value) {
          return codec.decodeValue(value, opts)
        }
      if(opts.keys !== false)
        return function (key) {
          return codec.decodeKey(precodec.decode(key)[1], opts)
        }
      return function () {}
    },
    isOpen: function isOpen() {
      if (db.db && isFunction$1(db.db.isOpen))
        return db.db.isOpen()

      return db.isOpen()
    },
    isClosed: function isClosed() {
      if (db.db && isFunction$1(db.db.isClosed))
        return db.db.isClosed()

      return db.isClosed()
    },
    close: function close (cb) {
      return db.close(cb)
    },
    iterator: function (_opts, cb) {
      var opts = clone(_opts || {});
      var prefix = _opts.prefix || [];

      function encodeKey(key) {
        return encodePrefix(prefix, key, opts, {})
      }

      ltgt$1.toLtgt(_opts, opts, encodeKey, precodec.lowerBound, precodec.upperBound);

      // if these legacy values are in the options, remove them

      opts.prefix = null;

      //************************************************
      //hard coded defaults, for now...
      //TODO: pull defaults and encoding out of levelup.
      opts.keyAsBuffer = opts.valueAsBuffer = false;
      //************************************************


      //this is vital, otherwise limit: undefined will
      //create an empty stream.
      if ('number' !== typeof opts.limit)
        opts.limit = -1;

      opts.keyAsBuffer = precodec.buffer;
      opts.valueAsBuffer = codec.isValueAsBuffer(opts);

      function wrapIterator (iterator) {
        return {
          next: function (cb) {
            return iterator.next(cb)
          },
          end: function (cb) {
            iterator.end(cb);
          }
        }
      }

      if(ready)
        return wrapIterator((db.db || db).iterator(opts))
      else
        waiting.push(function () {
          cb(null, wrapIterator((db.db || db).iterator(opts)));
        });

    }
  }

};

var shell$1 = {exports: {}};

/* Copyright (c) 2012-2014 LevelUP contributors
 * See list at <https://github.com/rvagg/node-levelup#contributing>
 * MIT License
 * <https://github.com/rvagg/node-levelup/blob/master/LICENSE.md>
 */

var createError   = errno$3.exports.create
  , LevelUPError  = createError('LevelUPError')
  , NotFoundError = createError('NotFoundError', LevelUPError);

NotFoundError.prototype.notFound = true;
NotFoundError.prototype.status   = 404;

var errors$1 = {
    LevelUPError        : LevelUPError
  , InitializationError : createError('InitializationError', LevelUPError)
  , OpenError           : createError('OpenError', LevelUPError)
  , ReadError           : createError('ReadError', LevelUPError)
  , WriteError          : createError('WriteError', LevelUPError)
  , NotFoundError       : NotFoundError
  , EncodingError       : createError('EncodingError', LevelUPError)
};

var name = "level-sublevel";
var description = "partition levelup databases";
var version$1 = "6.6.5";
var homepage = "https://github.com/dominictarr/level-sublevel";
var repository = {
	type: "git",
	url: "git://github.com/dominictarr/level-sublevel.git"
};
var dependencies = {
	bytewise: "~1.1.0",
	levelup: "~0.19.0",
	ltgt: "~2.1.1",
	"pull-defer": "^0.2.2",
	"pull-level": "^2.0.3",
	"pull-stream": "^3.6.8",
	typewiselite: "~1.0.0",
	xtend: "~4.0.0"
};
var devDependencies = {
	level: "^3.0.1",
	"level-test": "^3.0.0",
	"monotonic-timestamp": "0.0.8",
	"pull-level": "~1.1.1",
	rimraf: "~2.1.4",
	shasum: "0.0.2",
	"stream-to-pull-stream": "~1.2.0",
	tape: "~2.14.0",
	through: "~2.3.4"
};
var scripts = {
	test: "set -e; for t in test/*.js; do node $t; done"
};
var author = "Dominic Tarr <dominic.tarr@gmail.com> (http://dominictarr.com)";
var license = "MIT";
var stability = "unstable";
var testling = {
	files: "test/*.js",
	browsers: [
		"ie/8..latest",
		"firefox/17..latest",
		"firefox/nightly",
		"chrome/22..latest",
		"chrome/canary",
		"opera/12..latest",
		"opera/next",
		"safari/5.1..latest",
		"ipad/6.0..latest",
		"iphone/6.0..latest",
		"android-browser/4.2..latest"
	]
};
var require$$3 = {
	name: name,
	description: description,
	version: version$1,
	homepage: homepage,
	repository: repository,
	dependencies: dependencies,
	devDependencies: devDependencies,
	scripts: scripts,
	author: author,
	license: license,
	stability: stability,
	testling: testling
};

var EventEmitter = require$$0$1.EventEmitter;
var addpre = range.exports.addPrefix;

var errors = errors$1;

function isFunction (f) {
  return 'function' === typeof f
}

function isString (s) {
  return 'string' === typeof s
}

function isObject (o) {
  return o && 'object' === typeof o
}

var version = require$$3.version;

var sublevel$2 = shell$1.exports = function (nut, prefix, createStream, options) {
  var emitter = new EventEmitter();
  emitter.sublevels = {};
  emitter.options = options;

  emitter.version = version;

  emitter.methods = {};
  prefix = prefix || [];

  function errback (err) { if (err) emitter.emit('error', err); }

  createStream = createStream || function (e) { return e };

  function mergeOpts(opts) {
    var o = {};
    if(options)
      for(var k in options)
        if(options[k] != undefined)o[k] = options[k];
    if(opts)
      for(var k in opts)
        if(opts[k] != undefined) o[k] = opts[k];
    return o
  }

  emitter.put = function (key, value, opts, cb) {
    if('function' === typeof opts) cb = opts, opts = {};
    if(!cb) cb = errback;

    nut.apply([{
      key: key, value: value,
      prefix: prefix.slice(), type: 'put'
    }], mergeOpts(opts), function (err) {
      if(!err) { emitter.emit('put', key, value); cb(null); }
      if(err) return cb(err)
    });
  };

  emitter.prefix = function () {
    return prefix.slice()
  };

  emitter.del = function (key, opts, cb) {
    if('function' === typeof opts) cb = opts, opts = {};
    if(!cb) cb = errback;

    nut.apply([{
      key: key,
      prefix: prefix.slice(), type: 'del'
    }], mergeOpts(opts), function (err) {
      if(!err) { emitter.emit('del', key); cb(null); }
      if(err) return cb(err)
    });
  };

  emitter.batch = function (ops, opts, cb) {
    if('function' === typeof opts)
      cb = opts, opts = {};
    if(!cb) cb = errback;

    ops = ops.map(function (op) {
      return {
        key:           op.key,
        value:         op.value,
        prefix:        op.prefix || prefix,
        keyEncoding:   op.keyEncoding,    // *
        valueEncoding: op.valueEncoding,  // * (TODO: encodings on sublevel)
        type:          op.type
      }
    });

    nut.apply(ops, mergeOpts(opts), function (err) {
      if(!err) { emitter.emit('batch', ops); cb(null); }
      if(err) return cb(err)
    });
  };

  emitter.get = function (key, opts, cb) {
    if('function' === typeof opts)
      cb = opts, opts = {};
    nut.get(key, prefix, mergeOpts(opts), function (err, value) {
      if(err) cb(new errors.NotFoundError('Key not found in database', err));
      else cb(null, value);
    });
  };

  emitter.clone = function(opts) {
    return sublevel$2(nut, prefix, createStream, mergeOpts(opts))
  };

  emitter.sublevel = function (name, opts) {
    return emitter.sublevels[name] =
      emitter.sublevels[name] || sublevel$2(nut, prefix.concat(name), createStream, mergeOpts(opts))
  };

  emitter.pre = function (key, hook) {
    if(isFunction(key)) return nut.pre([prefix], key)
    if(isString(key)) return nut.pre([prefix, key], hook)
    if(isObject(key)) return nut.pre(addpre(prefix, key), hook)

    throw new Error('not implemented yet')
  };

  emitter.post = function (key, hook) {
    if(isFunction(key)) return nut.post([prefix], key)
    if(isString(key))   return nut.post([prefix, key], hook)
    if(isObject(key))   return nut.post(addpre(prefix, key), hook)

    //TODO: handle ranges, needed for level-live-stream, etc.
    throw new Error('not implemented yet')
  };

  emitter.readStream =
  emitter.createReadStream = function (opts) {
    opts = mergeOpts(opts);
    opts.prefix = prefix;
    var stream;
    var it = nut.iterator(opts, function (err, it) {
      stream.setIterator(it);
    });

    stream = createStream(opts, nut.createDecoder(opts));
    if(it) stream.setIterator(it);

    return stream
  };

  emitter.valueStream =
  emitter.createValueStream = function (opts) {
    opts = opts || {};
    opts.values = true;
    opts.keys = false;
    return emitter.createReadStream(opts)
  };

  emitter.keyStream =
  emitter.createKeyStream = function (opts) {
    opts = opts || {};
    opts.values = false;
    opts.keys = true;
    return emitter.createReadStream(opts)
  };

  emitter.close = function (cb) {
    //TODO: deregister all hooks
    cb = cb || function () {};
    if (!prefix.length) nut.close(cb);
    else process.nextTick(cb);
  };

  emitter.isOpen = nut.isOpen;
  emitter.isClosed = nut.isClosed;

  emitter.location = nut.location;

  return emitter
};

var codec$2 = {};

//define the key ordering for level-sublevelq

//var join = '\x01', separate = '\x00'
var join = '#', separate = '!';

codec$2.encode = function (e) {
  return separate + e[0].join(join) + separate + e[1]
};

codec$2.decode = function (s) {
  var i = s.indexOf(separate, 1);
  return [s.substring(1, i).split(join).filter(Boolean), s.substring(++i)]
};

codec$2.buffer = false;

codec$2.lowerBound = '\x00';
codec$2.upperBound = '\uffff';

/* Copyright (c) 2012-2014 LevelUP contributors
 * See list at <https://github.com/rvagg/node-levelup#contributing>
 * MIT License
 * <https://github.com/rvagg/node-levelup/blob/master/LICENSE.md>
 */

var encodingNames = [
        'hex'
      , 'utf8'
      , 'utf-8'
      , 'ascii'
      , 'binary'
      , 'base64'
      , 'ucs2'
      , 'ucs-2'
      , 'utf16le'
      , 'utf-16le'
    ];

var encodings$2 = (function () {
  function isBinary (data) {
    return data === undefined || data === null || Buffer.isBuffer(data)
  }

  var encodings = {};

  encodings.utf8 = encodings['utf-8'] = {
      encode : function (data) {
        return isBinary(data) ? data : String(data)
      }
    , decode : function (data) { return data }
    , buffer : false
    , type   : 'utf8'
  };

  encodings.json = {
      encode : JSON.stringify
    , decode : JSON.parse
    , buffer : false
    , type   : 'json'
  };

  encodings.binary = {
      encode : function (data) {
        return isBinary(data) ? data : new Buffer(data)
      }
    , decode : function (data) {
        return data
      }
    , buffer : true
    , type   : 'binary'
  };

  encodingNames.forEach(function (type) {
    if (encodings[type])
      return

    encodings[type] = {
        encode : function (data) {
          return isBinary(data) ? data : new Buffer(data, type)
        }
      , decode : function (buffer) {
          return buffer.toString(type)
        }
      , buffer : true
      , type   : type // useful for debugging purposes
    };
  });

  return encodings
})();

/* Copyright (c) 2012-2014 LevelUP contributors
 * See list at <https://github.com/rvagg/node-levelup#contributing>
 * MIT License
 * <https://github.com/rvagg/node-levelup/blob/master/LICENSE.md>
 */

var encodings$1 = encodings$2;

function getKeyEncoder (options, op) {
  var type = ((op && op.keyEncoding) || options.keyEncoding) || 'utf8';
  return encodings$1[type] || type
}

function getValueEncoder (options, op) {
  var type = (((op && (op.valueEncoding || op.encoding))
      || options.valueEncoding || options.encoding)) || 'utf8';
  return encodings$1[type] || type
}

/*
  Encode a key.
  This method takes two options, because the leveldb instance
  has options, and this operation (a put, del, or batch)
  also has options that may override the leveldb's options.
*/

function encodeKey (key, options, op) {
  return getKeyEncoder(options, op).encode(key)
}

/*
  Encode a value.
  Takes 2 options, for the same reason as encodeKey
*/

function encodeValue (value, options, op) {
  return getValueEncoder(options, op).encode(value)
}

/*
  Decode an encoded key
*/

function decodeKey (key, options) {
  return getKeyEncoder(options).decode(key)
}

/*
  Decode an encoded value
*/

function decodeValue (value, options) {
  return getValueEncoder(options).decode(value)
}

/*
  check whether this value should be requested as a buffer
  (if false, then it will be a string)
  this allows an optimization in leveldown where leveldown
  retrives a string directly, and thus avoids a memory copy.
*/

function isValueAsBuffer (options, op) {
  return getValueEncoder(options, op).buffer
}

/*
  check whether a given key should be requested as a buffer.
*/

function isKeyAsBuffer (options, op) {
  return getKeyEncoder(options, op).buffer
}


var codec$1 = {
    encodeKey       : encodeKey
  , encodeValue     : encodeValue
  , isValueAsBuffer : isValueAsBuffer
  , isKeyAsBuffer   : isKeyAsBuffer
  , decodeValue     : decodeValue
  , decodeKey       : decodeKey
};

/* Copyright (c) 2012-2014 LevelUP contributors
 * See list at <https://github.com/rvagg/node-levelup#contributing>
 * MIT License
 * <https://github.com/rvagg/node-levelup/blob/master/LICENSE.md>
 */

var encodings     = encodings$2
  ; ((function () {
      var eo = {};
      for(var e in encodings)
        eo[e] = {valueEncoding: encodings[e]};
      return eo
    })());

/* Copyright (c) 2012-2014 LevelUP contributors
 * See list at <https://github.com/rvagg/node-levelup#contributing>
 * MIT License <https://github.com/rvagg/node-levelup/blob/master/LICENSE.md>
 */

// NOTE: we are fixed to readable-stream@1.0.x for now
// for pure Streams2 across Node versions
var Readable$1      = require$$1.Readable
  , inherits$1      = require$$1$1.inherits
  , EncodingError = errors$1.EncodingError
  ;



function ReadStream$1 (options, makeData) {
  if (!(this instanceof ReadStream$1))
    return new ReadStream$1(options, makeData)

  Readable$1.call(this, { objectMode: true, highWaterMark: options.highWaterMark });

  // purely to keep `db` around until we're done so it's not GCed if the user doesn't keep a ref

  this._waiting = false;
  this._options = options;
  this._makeData = makeData;
}

inherits$1(ReadStream$1, Readable$1);

ReadStream$1.prototype.setIterator = function (it) {
  this._iterator = it;
  if(this._destroyed) return it.end(function () {})
  if(this._waiting) {
    this._waiting = false;
    return this._read()
  }
  return this
};

ReadStream$1.prototype._read = function read () {
  var self = this;
  if (self._destroyed)
    return
  if(!self._iterator)
    return this._waiting = true

  self._iterator.next(function(err, key, value) {
    if (err || (key === undefined && value === undefined)) {
      if (!err && !self._destroyed)
        self.push(null);
      return self._cleanup(err)
    }


    try {
      value = self._makeData(key, value);
    } catch (e) {
      return self._cleanup(new EncodingError(e))
    }
    if (!self._destroyed)
      self.push(value);
  });
};

ReadStream$1.prototype._cleanup = function (err) {
  if (this._destroyed)
    return

  this._destroyed = true;

  var self = this;
  if (err)
    self.emit('error', err);

  if (self._iterator) {
    self._iterator.end(function () {
      self._iterator = null;
      self.emit('close');
    });
  } else {
    self.emit('close');
  }
};

ReadStream$1.prototype.destroy = function () {
  this._cleanup();
};

ReadStream$1.prototype.toString = function () {
  return 'LevelUP.ReadStream'
};


var readStream = ReadStream$1;

var nut   = nut$1;
var shell = shell$1.exports; //the shell surrounds the nut
var precodec = codec$2;
var codec = codec$1;
var merge = immutable;

var ReadStream = readStream;

var sublevel$1 = function (db, opts) {
  opts = merge(db.options, opts);
  return shell ( nut ( db, precodec, codec ), [], ReadStream, opts)
};

var levelSublevel = function (db, opts) {
  if (typeof db.sublevel === 'function' && typeof db.clone === 'function') return db.clone(opts)
  return sublevel$1(db, opts)
};

var levelPeek = {};

var pullLevel = {};

var pull$2 = function pull (a) {
  var length = arguments.length;
  if (typeof a === 'function' && a.length === 1) {
    var args = new Array(length);
    for(var i = 0; i < length; i++)
      args[i] = arguments[i];
    return function (read) {
      if (args == null) {
        throw new TypeError("partial sink should only be called once!")
      }

      // Grab the reference after the check, because it's always an array now
      // (engines like that kind of consistency).
      var ref = args;
      args = null;

      // Prioritize common case of small number of pulls.
      switch (length) {
      case 1: return pull(read, ref[0])
      case 2: return pull(read, ref[0], ref[1])
      case 3: return pull(read, ref[0], ref[1], ref[2])
      case 4: return pull(read, ref[0], ref[1], ref[2], ref[3])
      default:
        ref.unshift(read);
        return pull.apply(null, ref)
      }
    }
  }

  var read = a;

  if (read && typeof read.source === 'function') {
    read = read.source;
  }

  for (var i = 1; i < length; i++) {
    var s = arguments[i];
    if (typeof s === 'function') {
      read = s(read);
    } else if (s && typeof s === 'object') {
      s.sink(read);
      read = s.source;
    }
  }

  return read
};

function abortAll(ary, abort, cb) {
  var n = ary.length;
  if(!n) return cb(abort)
  ary.forEach(function (f) {
    if(f) f(abort, next);
    else next();
  });

  function next() {
    if(--n) return
    cb(abort);
  }
  if(!n) next();
}

var pullCat = function (streams) {
  return function (abort, cb) {
(function next () {
      if(abort)
        abortAll(streams, abort, cb);
      else if(!streams.length)
        cb(true);
      else if(!streams[0])
        streams.shift(), next();
      else
        streams[0](null, function (err, data) {
          if(err) {
            streams.shift(); //drop the first, has already ended.
            if(err === true) next();
            else             abortAll(streams, err, cb);
          }
          else
            cb(null, data);
        });
    })();
  }
};

var abortCb$2 = function abortCb(cb, abort, onAbort) {
  cb(abort);
  onAbort && onAbort(abort === true ? null: abort);
  return
};

var abortCb$1 = abortCb$2;

var once$6 = function once (value, onAbort) {
  return function (abort, cb) {
    if(abort)
      return abortCb$1(cb, abort, onAbort)
    if(value != null) {
      var _value = value; value = null;
      cb(null, _value);
    } else
      cb(true);
  }
};

var Cat = pullCat;
var Once = once$6;

var pullLive = function (createSource, createLive) {

  return function (opts) {
      opts = opts || {};
      var isOld = opts.old !== false;
      var isLive = opts.live === true || opts.old === false;

      if(!isLive && !isOld)
        throw new Error('ls with neither old or new is empty')

      if(isLive && isOld)
        return Cat([
          createSource(opts),
          opts.sync === false ? null : Once({sync: true}),
          createLive(opts)
        ])
      else if(!isLive)
        return createSource(opts)
      else
        return createLive(opts)
  }
};

var streamToPullStream = {exports: {}};

var looper$1 = function (fn) {
  var active = false, called = 0;
  return function () {
    called = true;
    if(!active) {
      active = true;
      while(called) {
        called = false;
        fn();
      }
      active = false;
    }
  }
};

(function (module, exports) {

	function destroy (stream) {
	  if(!stream.destroy)
	    console.error(
	      'warning, stream-to-pull-stream: \n'
	    + 'the wrapped node-stream does not implement `destroy`, \n'
	    + 'this may cause resource leaks.'
	    );
	  else stream.destroy();

	}

	function write(read, stream, cb) {
	  var ended, closed = false, did;
	  function done () {
	    if(did) return
	    did = true;
	    cb && cb(ended === true ? null : ended);
	  }

	  function onClose () {
	    if(closed) return
	    closed = true;
	    cleanup();
	    if(!ended) read(ended = true, done);
	    else       done();
	  }
	  function onError (err) {
	    cleanup();
	    if(!ended) read(ended = err, done);
	  }
	  function cleanup() {
	    stream.on('finish', onClose);
	    stream.removeListener('close', onClose);
	    stream.removeListener('error', onError);
	  }
	  stream.on('close', onClose);
	  stream.on('finish', onClose);
	  stream.on('error', onError);
	  process.nextTick(function () {
	  });
	}

	function read2(stream) {
	  var ended = false, waiting = false;
	  var _cb;

	  function read () {
	    var data = stream.read();
	    if(data !== null && _cb) {
	      var cb = _cb; _cb = null;
	      cb(null, data);
	    }
	  }

	  stream.on('readable', function () {
	    waiting = true;
	    _cb && read();
	  })
	  .on('end', function () {
	    ended = true;
	    _cb && _cb(ended);
	  })
	  .on('error', function (err) {
	    ended = err;
	    _cb && _cb(ended);
	  });

	  return function (end, cb) {
	    _cb = cb;
	    if(ended)
	      cb(ended);
	    else if(waiting)
	      read();
	  }
	}

	function read1(stream) {
	  var buffer = [], cbs = [], ended, paused = false;
	  function drain() {
	    while((buffer.length || ended) && cbs.length)
	      cbs.shift()(buffer.length ? null : ended, buffer.shift());
	    if(!buffer.length && (paused)) {
	      paused = false;
	      stream.resume();
	    }
	  }

	  stream.on('data', function (data) {
	    buffer.push(data);
	    drain();
	    if(buffer.length && stream.pause) {
	      paused = true;
	      stream.pause();
	    }
	  });
	  stream.on('end', function () {
	    ended = true;
	    drain();
	  });
	  stream.on('close', function () {
	    ended = true;
	    drain();
	  });
	  stream.on('error', function (err) {
	    ended = err;
	    drain();
	  });
	  return function (abort, cb) {
	    if(!cb) throw new Error('*must* provide cb')
	    if(abort) {
	      function onAbort () {
	        while(cbs.length) cbs.shift()(abort);
	        cb(abort);
	      }
	      //if the stream happens to have already ended, then we don't need to abort.
	      if(ended) return onAbort()
	      stream.once('close', onAbort);
	      destroy(stream);
	    }
	    else {
	      cbs.push(cb);
	      drain();
	    }
	  }
	}

	var read = read1;

	var sink = function (stream, cb) {
	  return function (read) {
	    return write(read, stream, cb)
	  }
	};

	var source = function (stream) {
	  return read1(stream)
	};

	exports = module.exports = function (stream, cb) {
	  return (
	    (stream.writable && stream.write)
	    ? stream.readable
	      ? function(_read) {
	          write(_read, stream, cb);
	          return read1(stream)
	        }
	      : sink(stream, cb)
	    : source(stream)
	  )
	};

	exports.sink = sink;
	exports.source = source;
	exports.read = read;
	exports.read1 = read1;
	exports.read2 = read2;
	exports.duplex = function (stream, cb) {
	  return {
	    source: source(stream),
	    sink: sink(stream, cb)
	  }
	};
	exports.transform = function (stream) {
	  return function (read) {
	    var _source = source(stream);
	    sink(stream)(read); return _source
	  }
	};
} (streamToPullStream, streamToPullStream.exports));

var toPull   = streamToPullStream.exports;

var old$1 = function read(db, opts) {
  return toPull.read1(db.createReadStream(opts))
};

var pullPushable_1 = pullPushable;

function pullPushable (separated, onClose) {
  if (typeof separated === 'function') {
    onClose = separated;
    separated = false;
  }

  // create a buffer for data
  // that have been pushed
  // but not yet pulled.
  var buffer = [];

  // a pushable is a source stream
  // (abort, cb) => cb(end, data)
  //
  // when pushable is pulled,
  // keep references to abort and cb
  // so we can call back after
  // .end(end) or .push(data)
  var abort, cb;
  function read (_abort, _cb) {
    if (_abort) {
      abort = _abort;
      // if there is already a cb waiting, abort it.
      if (cb) callback(abort);
    }
    cb = _cb;
    drain();
  }

  var ended;
  function end (end) {
    ended = ended || end || true;
    // attempt to drain
    drain();
  }

  function push (data) {
    if (ended) return
    // if sink already waiting,
    // we can call back directly.
    if (cb) {
      callback(abort, data);
      return
    }
    // otherwise buffer data
    buffer.push(data);
  }

  // Return functions separated from source { push, end, source }
  if (separated) {
    return { push: push, end: end, source: read, buffer: buffer }
  }

  // Return normal
  read.push = push;
  read.end = end;
  read.buffer = buffer;
  return read

  // `drain` calls back to (if any) waiting
  // sink with abort, end, or next data.
  function drain () {
    if (!cb) return

    if (abort) callback(abort);
    else if (!buffer.length && ended) callback(ended);
    else if (buffer.length) callback(null, buffer.shift());
  }

  // `callback` calls back to waiting sink,
  // and removes references to sink cb.
  function callback (err, val) {
    var _cb = cb;
    // if error and pushable passed onClose, call it
    // the first time this stream ends or errors.
    if (err && onClose) {
      var c = onClose;
      onClose = null;
      c(err === true ? null : err);
    }
    cb = null;
    _cb(err, val);
  }
}

var ltgt = ltgt$3;

var levelPost = function post (db, opts, each) {
  if(!each)
    each = opts, opts = {};

  if('function' === typeof db.post)
    return db.post(opts, each)

  var encode = (opts && opts.keyEncoding && opts.keyEncoding.encode)
    || (db.options && db.options.keyEncoding && db.options.keyEncoding.encode)
    || function (x) { return x };

  var _opts = ltgt.toLtgt(opts, {}, encode);

  function cmp (key) {
    return ltgt.contains(_opts, encode(key))
  }

  function onPut (key, val) {
    if(cmp(key))
      each({type: 'put', key: key, value: val});
  }

  function onDel (key, val) {
    if(cmp(key))
      each({type: 'del', key: key, value: val});
  }

  function onBatch (ary) {
    ary.forEach(function (op) {
      if(cmp(op.key))
        each(op);
    });
  }

  db.on('put', onPut);
  db.on('del', onDel);
  db.on('batch', onBatch);

  return function () {
    db.removeListener('put', onPut);
    db.removeListener('del', onDel);
    db.removeListener('batch', onBatch);
  }
};

var pushable = pullPushable_1;
var post     = levelPost;

var live$1 = function (db, opts) {
  opts = opts || {};

  var l = pushable(function (err) {
    if(opts.onAbort) opts.onAbort(err);
    cleanup();
  });

  var cleanup = post(db, opts, function (ch) {
    if(opts.keys === false)
      l.push(ch.value);
    else if(opts.values === false)
      l.push(ch.key);
    else
      l.push(ch);
  });

  return l

};

var Live = pullLive;

var old = old$1;
var live = live$1;

var read = function (db, opts) {
  if(opts && opts.tail) {
    console.error('pull-level: .tail option is depreciated. use .live instead');
    opts.live = opts.tail;
  }
  return Live(function (opts) {
    return old(db, opts)
  }, function (opts) {
    return live(db, opts)
  })(opts)
};

var prop$5 = function prop (key) {
  return key && (
    'string' == typeof key
    ? function (data) { return data[key] }
    : 'object' === typeof key && 'function' === typeof key.exec //regexp
    ? function (data) { var v = key.exec(data); return v && v[0] }
    : key
  )
};

function id$4 (e) { return e }
var prop$4 = prop$5;

var map = function map (mapper) {
  if(!mapper) return id$4
  mapper = prop$4(mapper);
  return function (read) {
    return function (abort, cb) {
      read(abort, function (end, data) {
        try {
        data = !end ? mapper(data) : null;
        } catch (err) {
          return read(err, function () {
            return cb(err)
          })
        }
        cb(end, data);
      });
    }
  }
};

function id$3 (e) { return e }
var prop$3 = prop$5;

var asyncMap = function asyncMap (map) {
  if(!map) return id$3
  map = prop$3(map);
  var busy = false, abortCb, aborted;
  return function (read) {
    return function next (abort, cb) {
      if(aborted) return cb(aborted)
      if(abort) {
        aborted = abort;
        if(!busy) read(abort, function (err) {
          //incase the source has already ended normally,
          //we should pass our own error.
          cb(abort);
        });
        else read(abort, function (err) {
          //if we are still busy, wait for the mapper to complete.
          if(busy) abortCb = cb;
          else cb(abort);
        });
      }
      else
        read(null, function (end, data) {
          if(end) cb(end);
          else if(aborted) cb(aborted);
          else {
            busy = true;
            map(data, function (err, data) {
              busy = false;
              if(aborted) {
                cb(aborted);
                abortCb && abortCb(aborted);
              }
              else if(err) next (err, cb);
              else cb(null, data);
            });
          }
        });
    }
  }
};

var drain$4 = function drain (op, done) {
  var read, abort;

  function sink (_read) {
    read = _read;
    if(abort) return sink.abort()
    //this function is much simpler to write if you
    //just use recursion, but by using a while loop
    //we do not blow the stack if the stream happens to be sync.
    ;(function next() {
        var loop = true, cbed = false;
        while(loop) {
          cbed = false;
          read(null, function (end, data) {
            cbed = true;
            if(end = end || abort) {
              loop = false;
              if(done) done(end === true ? null : end);
              else if(end && end !== true)
                throw end
            }
            else if(op && false === op(data) || abort) {
              loop = false;
              read(abort || true, done || function () {});
            }
            else if(!loop){
              next();
            }
          });
          if(!cbed) {
            loop = false;
            return
          }
        }
      })();
  }

  sink.abort = function (err, cb) {
    if('function' == typeof err)
      cb = err, err = true;
    abort = err || true;
    if(read) return read(abort, cb || function () {})
  };

  return sink
};

var pullWindow = {exports: {}};

var looper = looper$1;

var window$1 = pullWindow.exports = function (init, start) {
return function (read) {
  start = start || function (start, data) {
    return {start: start, data: data}
  };
  var windows = [], output = [], ended = null;

  return function (abort, cb) {
    if(output.length)
      return cb(null, output.shift())
    if(ended)
      return cb(ended)
    read(abort, looper(function (end, data) {
      var next = this;
      var update, once = false;
      if(end)
        ended = end;

      function _update (end, _data) {
        if(once) return
        once = true;
        delete windows[windows.indexOf(update)];
        output.push(start(data, _data));
      }

      if(!ended)
        update = init(data, _update);

      if(update)
        windows.push(update);
      else
        //don't allow data unless a window started here!
        once = true;

      windows.forEach(function (update, i) {
        update(end, data);
      });

      if(output.length)
        return cb(null, output.shift())
      else if(ended)
        return cb(ended)
      else
        read(null, next);

  }));
  }
}};

window$1.recent = function (size, time) {
  var current = null;
  return window$1(function (data, cb) {
    if(current) return
    current = [];
    var timer;
      
    function done () {
      var _current = current;
      current = null;
      clearTimeout(timer);
      cb(null, _current);
    }

    if(time)
      timer = setTimeout(done, time);

    return function (end, data) {
      if(end) return done()
      current.push(data);
      if(size != null && current.length >= size)
        done();
    }
  }, function (_, data) {
    return data
  })
};

window$1.sliding = function (reduce, width) {
  width = width || 10;
  return window$1(function (data, cb) {
    var acc;
    var i = 0;
    return function (end, data) {
      if(end) return
      acc = reduce(acc, data);
      if(width <= ++ i)
        cb(null, acc);
    }
  })
};

var pull$1     = pull$2;
var Map      = map;
var AsyncMap = asyncMap;
var Drain    = drain$4;
var Window   = pullWindow.exports;

var write = function (db, opts, done) {
  if('function' === typeof opts)
    done = opts, opts = null;
  opts = opts || {};
  return pull$1(
    Map(function (e) {
      if(e.type) return e
      return {
        key   : e.key, 
        value : e.value,
        type  : e.value == null ? 'del' : 'put'
      }
    }),
    Window.recent(opts.windowSize, opts.windowTime),
    AsyncMap(function (batch, cb) {
      db.batch(batch, cb);
    }),
    Drain(null, done)
  )
};

pullLevel.old = old$1;
pullLevel.live = live$1;


pullLevel.read =
pullLevel.readStream =
pullLevel.createReadStream = read;

pullLevel.write =
pullLevel.writeStream =
pullLevel.createWriteStream = write;

var pullStream = {exports: {}};

var abortCb = abortCb$2;

var values$2 = function values (array, onAbort) {
  if(!array)
    return function (abort, cb) {
      if(abort) return abortCb(cb, abort, onAbort)
      return cb(true)
    }
  if(!Array.isArray(array))
    array = Object.keys(array).map(function (k) {
      return array[k]
    });
  var i = 0;
  return function (abort, cb) {
    if(abort)
      return abortCb(cb, abort, onAbort)
    if(i >= array.length)
      cb(true);
    else
      cb(null, array[i++]);
  }
};

var values$1 = values$2;
var keys = function (object) {
  return values$1(Object.keys(object))
};

var count = function count (max) {
  var i = 0; max = max || Infinity;
  return function (end, cb) {
    if(end) return cb && cb(end)
    if(i > max)
      return cb(true)
    cb(null, i++);
  }
};

var infinite = function infinite (generate) {
  generate = generate || Math.random;
  return function (end, cb) {
    if(end) return cb && cb(end)
    return cb(null, generate())
  }
};

//a stream that ends immediately.
var empty = function empty () {
  return function (abort, cb) {
    cb(true);
  }
};

//a stream that errors immediately.
var error = function error (err) {
  return function (abort, cb) {
    cb(err);
  }
};

var sources = {
  keys: keys,
  once: once$6,
  values: values$2,
  count: count,
  infinite: infinite,
  empty: empty,
  error: error
};

var drain$3 = drain$4;

var onEnd = function onEnd (done) {
  return drain$3(null, done)
};

var drain$2 = drain$4;

var log = function log (done) {
  return drain$2(function (data) {
    console.log(data);
  }, done)
};

function id$2 (e) { return e }
var prop$2 = prop$5;
var drain$1 = drain$4;

var find = function find (test, cb) {
  var ended = false;
  if(!cb)
    cb = test, test = id$2;
  else
    test = prop$2(test) || id$2;

  return drain$1(function (data) {
    if(test(data)) {
      ended = true;
      cb(null, data);
    return false
    }
  }, function (err) {
    if(ended) return //already called back
    cb(err === true ? null : err, null);
  })
};

var drain = drain$4;

var reduce$2 = function reduce (reducer, acc, cb ) {
  if(!cb) cb = acc, acc = null;
  var sink = drain(function (data) {
    acc = reducer(acc, data);
  }, function (err) {
    cb(err, acc);
  });
  if (arguments.length === 2)
    return function (source) {
      source(null, function (end, data) {
        //if ended immediately, and no initial...
        if(end) return cb(end === true ? null : end)
        acc = data; sink(source);
      });
    }
  else
    return sink
};

var reduce$1 = reduce$2;

var collect = function collect (cb) {
  return reduce$1(function (arr, item) {
    arr.push(item);
    return arr
  }, [], cb)
};

var reduce = reduce$2;

var concat$1 = function concat (cb) {
  return reduce(function (a, b) {
    return a + b
  }, '', cb)
};

var sinks = {
  drain: drain$4,
  onEnd: onEnd,
  log: log,
  find: find,
  reduce: reduce$2,
  collect: collect,
  concat: concat$1
};

var prop$1 = prop$5;

function id$1 (e) { return e }

var tester$2 = function tester (test) {
  return (
    'object' === typeof test && 'function' === typeof test.test //regexp
    ? function (data) { return test.test(data) }
    : prop$1 (test) || id$1
  )
};

var tester$1 = tester$2;

var filter$2 = function filter (test) {
  //regexp
  test = tester$1(test);
  return function (read) {
    return function next (end, cb) {
      var sync, loop = true;
      while(loop) {
        loop = false;
        sync = true;
        read(end, function (end, data) {
          if(!end && !test(data))
            return sync ? loop = true : next(end, cb)
          cb(end, data);
        });
        sync = false;
      }
    }
  }
};

var tester = tester$2;
var filter$1 = filter$2;

var filterNot = function filterNot (test) {
  test = tester(test);
  return filter$1(function (data) { return !test(data) })
};

//a pass through stream that doesn't change the value.
var through = function through (op, onEnd) {
  var a = false;

  function once (abort) {
    if(a || !onEnd) return
    a = true;
    onEnd(abort === true ? null : abort);
  }

  return function (read) {
    return function (end, cb) {
      if(end) once(end);
      return read(end, function (end, data) {
        if(!end) op && op(data);
        else once(end);
        cb(end, data);
      })
    }
  }
};

//read a number of items and then stop.
var take = function take (test, opts) {
  opts = opts || {};
  var last = opts.last || false; // whether the first item for which !test(item) should still pass
  var ended = false;
  if('number' === typeof test) {
    last = true;
    var n = test; test = function () {
      return --n
    };
  }

  return function (read) {

    function terminate (cb) {
      read(true, function (err) {
        last = false; cb(err || true);
      });
    }

    return function (end, cb) {
      if(ended && !end) last ? terminate(cb) : cb(ended);
      else if(ended = end) read(ended, cb);
      else
        read(null, function (end, data) {
          if(ended = ended || end) {
            //last ? terminate(cb) :
            cb(ended);
          }
          else if(!test(data)) {
            ended = true;
            last ? cb(null, data) : terminate(cb);
          }
          else
            cb(null, data);
        });
    }
  }
};

function id (e) { return e }
var prop = prop$5;
var filter = filter$2;

//drop items you have already seen.
var unique$1 = function unique (field, invert) {
  field = prop(field) || id;
  var seen = {};
  return filter(function (data) {
    var key = field(data);
    if(seen[key]) return !!invert //false, by default
    else seen[key] = true;
    return !invert //true by default
  })
};

var unique = unique$1;

//passes an item through when you see it for the second time.
var nonUnique = function nonUnique (field) {
  return unique(field, true)
};

var values = values$2;
var once$5 = once$6;

//convert a stream of arrays or streams into just a stream.
var flatten = function flatten () {
  return function (read) {
    var _read;
    return function (abort, cb) {
      if (abort) { //abort the current stream, and then stream of streams.
        _read ? _read(abort, function(err) {
          read(err || abort, cb);
        }) : read(abort, cb);
      }
      else if(_read) nextChunk();
      else nextStream();

      function nextChunk () {
        _read(null, function (err, data) {
          if (err === true) nextStream();
          else if (err) {
            read(true, function(abortErr) {
              // TODO: what do we do with the abortErr?
              cb(err);
            });
          }
          else cb(null, data);
        });
      }
      function nextStream () {
        _read = null;
        read(null, function (end, stream) {
          if(end)
            return cb(end)
          if(Array.isArray(stream) || stream && 'object' === typeof stream)
            stream = values(stream);
          else if('function' != typeof stream)
            stream = once$5(stream);
          _read = stream;
          nextChunk();
        });
      }
    }
  }
};

var throughs = {
  map: map,
  asyncMap: asyncMap,
  filter: filter$2,
  filterNot: filterNot,
  through: through,
  take: take,
  unique: unique$1,
  nonUnique: nonUnique,
  flatten: flatten
};

(function (module, exports) {

	var sources$1  = sources;
	var sinks$1    = sinks;
	var throughs$1 = throughs;

	exports = module.exports = pull$2;

	exports.pull = exports;

	for(var k in sources$1)
	  exports[k] = sources$1[k];

	for(var k in throughs$1)
	  exports[k] = throughs$1[k];

	for(var k in sinks$1)
	  exports[k] = sinks$1[k];
} (pullStream, pullStream.exports));

var pl = pullLevel;
var pull = pullStream.exports;

function first (cb) {
  var data;
  return pull.drain(function (_data) {
    data = _data;
    return false
  }, function (err) {
    cb(err === true ? null : err, data && data.key, data && data.value);
  })
}

levelPeek.first = function (db, opts, cb) {
  opts = opts || {};
  opts.limit = 1;
  pull(pl.read(db, opts), first(cb));
};

levelPeek.last = function (db, opts, cb) {
  opts = opts || {};
  opts.reverse = true;
  opts.limit = 1;
  pull(pl.read(db, opts), first(cb));

};

var Writable$1 = writable.exports;
var Readable = readable.exports;
var peek$1 = levelPeek;
var util = require$$1$1;
var once$4 = require$$4;

var EMPTY = new Buffer(0);
var ENCODER = {
	encode: function(data) {
		return typeof data === 'string' ? data = new Buffer(data) : data;
	},
	decode: function(data) {
		return Buffer.isBuffer(data) ? data : new Buffer(data);
	},
	buffer: true,
	type: 'raw'
};

var noop$3 = function() {};

var pad = function(n) {
	n = n.toString(16);
	return '00000000'.slice(0, -n.length)+n;
};

var expand = function(buf, len) {
	var tmp = new Buffer(len);
	buf.copy(tmp);
	return tmp;
};

var levelBlobs = function(db, opts) {
	if (!opts) opts = {};

	var blobs = {};

	var blockSize = opts.blockSize || 65536;
	var maxBatch = opts.batch || 100;
	var blank = new Buffer(blockSize);

	db.put('\x00', 'ignore', noop$3); // memdown#12 workaround

	var reservations = {};
	var mutateBlock = function(key, offset, block, append, cb) {
		var release = function() {
			if (!--reservations[key].locks) delete reservations[key];
		};

		var onreservation = function(r) {
			r.locks++;

			if (!r.block && !offset) {
				r.block = block;
				cb(null, r.block, release);
				return;
			}

			if (!r.block) r.block = new Buffer(blockSize);
			if (r.block.length < offset + block.length) r.block = expand(r.block, offset + block.length);

			block.copy(r.block, offset);

			if (!append && offset + block.length < r.block.length) r.block = r.block.slice(0, offset+block.length);
			cb(null, r.block, release);
		};

		if (reservations[key]) return onreservation(reservations[key]);

		db.get(key, {valueEncoding:ENCODER}, function(err, block) {
			if (err && !err.notFound) return cb(err);
			if (!reservations[key]) reservations[key] = {locks:0, block:block};
			onreservation(reservations[key]);
		});
	};

	var WriteStream = function(name, opts) {
		if (!(this instanceof WriteStream)) return new WriteStream(name, opts);
		if (!opts) opts = {};

		this.name = name;
		this.blocks = [];
		this.batch = [];
		this.bytesWritten = 0;
		this.truncate = !opts.append;
		this.append = opts.append;

		this._shouldInitAppend = this.append && opts.start === undefined;
		this._destroyed = false;
		this._init(opts.start || 0);

		Writable$1.call(this);
	};

	util.inherits(WriteStream, Writable$1);

	WriteStream.prototype._init = function(start) {
		this.blockIndex = (start / blockSize) | 0;
		this.blockOffset = start - this.blockIndex * blockSize;
		this.blockLength = this.blockOffset;
	};

	WriteStream.prototype._flush = function(cb) {
		if (!this.batch.length) return cb();

		var key = this.batch[this.batch.length-1].key;
		var batch = this.batch;
		this.batch = [];

		if (!this.truncate) return db.batch(batch, cb);
		this.truncate = false;
		this._truncate(batch, key, cb);
	};

	WriteStream.prototype._truncate = function(batch, key, cb) {
		cb = once$4(cb);

		var dels = [];
		var keys = db.createKeyStream({
			start: key,
			end: this.name+'\xff\xff'
		});

		keys.on('error', cb);

		keys.on('data', function(key) {
			dels.push({type:'del', key:key});
		});

		keys.on('end', function() {
			dels.push.apply(dels, batch);
			db.batch(dels, cb);
		});
	};

	WriteStream.prototype._writeBlock = function(cb) {
		var block = this.blocks.length === 1 ? this.blocks[0] : Buffer.concat(this.blocks, this.blockLength - this.blockOffset);
		var index = this.blockIndex;
		var offset = this.blockOffset;
		var self = this;

		this.blockOffset = 0;
		this.blockLength = 0;
		this.blockIndex++;
		this.blocks = [];

		var key = this.name+'\xff'+pad(index);

		var append = function(block, force, cb) {
			if (block.length) {
				self.batch.push({
					type: 'put',
					key: key,
					value: block,
					valueEncoding: ENCODER
				});
			}

			if (!force && self.batch.length < maxBatch) return cb();
			return self._flush(cb);
		};

		if (!offset && block.length === blockSize) return append(block, false, cb);
		if (!offset && !this.append) return append(block, false, cb);

		// partial write
		mutateBlock(key, offset, block, this.append, function(err, block, release) {
			if (err) return cb(err);
			append(block, true, function(err) {
				release();
				cb(err);
			});
		});
	};

	WriteStream.prototype._initAppend = function(data, enc, cb) {
		var self = this;
		this._shouldInitAppend = false;
		blobs.size(this.name, function(err, size) {
			if (err) return cb(err);
			self._init(size);
			self._write(data, enc, cb);
		});
	};

	WriteStream.prototype._write = function(data, enc, cb) {
		if (!data.length || this._destroyed) return cb();
		if (this._shouldInitAppend) return this._initAppend(data, enc, cb);

		var self = this;
		var overflow;
		var free = blockSize - this.blockLength;

		var done = function(err) {
			if (err) return cb(err);
			if (overflow) return self._write(overflow, enc, cb);
			cb();
		};

		if (data.length > free) {
			overflow = data.slice(free);
			data = data.slice(0, free);
		}

		this.bytesWritten += data.length;
		this.blockLength += data.length;
		this.blocks.push(data);

		if (data.length < free) return done();
		this._writeBlock(done);
	};

	WriteStream.prototype.destroy = function() {
		if (this._destroyed) return;
		this._destroyed = true;
		process.nextTick(this.emit.bind(this, 'close'));
	};

	WriteStream.prototype.end = function(data) {
		var self = this;
		var args = arguments;

		if (data && typeof data !== 'function') {
			this.write(data);
			data = EMPTY;
		}

		this.write(EMPTY, function() {
			self._writeBlock(function(err) {
				if (err) return self.emit('error', err);
				self._flush(function(err) {
					if (err) return self.emit('error', err);
					Writable$1.prototype.end.apply(self, args);
				});
			});
		});
	};

	var ReadStream = function(name, opts) {
		if (!opts) opts = {};

		var self = this;

		var start = opts.start || 0;
		var blockIndex = (start / blockSize) | 0;
		var blockOffset = start - blockIndex * blockSize;
		var key = name+'\xff'+pad(blockIndex);

		this.name = name;
		this._missing = (typeof opts.end === 'number' ? opts.end : Infinity) - start + 1;
		this._paused = false;
		this._destroyed = false;

		this._reader = db.createReadStream({
			start: key,
			end: name+'\xff\xff',
			valueEncoding: ENCODER
		});

		var onblock = function(val) {
			key = name+'\xff'+pad(++blockIndex);

			if (!self._missing) return false;

			if (blockOffset) {
				val = val.slice(blockOffset);
				blockOffset = 0;
				if (!val.length) return true;
			}

			if (val.length > self._missing) val = val.slice(0, self._missing);

			self._missing -= val.length;
			self._pause(!self.push(val));

			return !!self._missing;
		};

		this._reader.on('data', function(data) {
			while (data.key > key) {
				if (!onblock(blank)) return;
			}

			onblock(data.value);
		});

		this._reader.on('error', function(err) {
			self.emit('error', err);
		});

		this._reader.on('end', function() {
			self.push(null);
		});

		Readable.call(this);
	};

	util.inherits(ReadStream, Readable);

	ReadStream.prototype.destroy = function() {
		if (this._destroyed) return;
		this._destroyed = true;
		this._reader.destroy();
		process.nextTick(this.emit.bind(this, 'close'));
	};

	ReadStream.prototype._pause = function(paused) {
		if (this._paused === paused) return;
		this._paused = paused;
		if (this._paused) this._reader.pause();
		else this._reader.resume();
	};

	ReadStream.prototype._read = function() {
		this._pause(false);
	};

	blobs.remove = function(name, cb) {
		cb = once$4(cb || noop$3);

		var batch = [];
		var keys = db.createKeyStream({
			start: name+'\xff',
			end: name+'\xff\xff'
		});

		keys.on('error', cb);

		keys.on('data', function(key) {
			batch.push({type:'del', key:key});
		});

		keys.on('end', function() {
			db.batch(batch, cb);
		});
	};

	blobs.size = function(name, cb) {
		peek$1.last(db, {
			start: name+'\xff',
			end: name+'\xff\xff',
			valueEncoding:ENCODER
		}, function(err, latest, val) {
			if (err && err.message === 'range not found') return cb(null, 0);
			if (err) return cb(err);
			if (latest.slice(0, name.length+1) !== name+'\xff') return cb(null, 0);

			cb(null, parseInt(latest.toString().slice(name.length+1), 16) * blockSize + val.length);
		});
	};

	blobs.write = function(name, data, opts, cb) {
		if (typeof opts === 'function') return blobs.write(name, data, null, opts);
		if (!opts) opts = {};
		if (!cb) cb = noop$3;

		var ws = blobs.createWriteStream(name, opts);

		ws.on('error', cb);
		ws.on('finish', function() {
			cb();
		});

		ws.write(data);
		ws.end();
	};

	blobs.read = function(name, opts, cb) {
		if (typeof opts === 'function') return blobs.read(name, null, opts);
		if (!opts) opts = {};

		var rs = blobs.createReadStream(name, opts);
		var list = [];

		rs.on('error', cb);
		rs.on('data', function(data) {
			list.push(data);
		});
		rs.on('end', function() {
			cb(null, list.length === 1 ? list[0] : Buffer.concat(list));
		});
	};

	blobs.createReadStream = function(name, opts) {
		return new ReadStream(name, opts);
	};

	blobs.createWriteStream = function(name, opts) {
		return new WriteStream(name, opts);
	};

	return blobs;
};

var octal$2 = function (num, base) {
  return parseInt(num.toString(), base || 8)
};

var errno$2 = {};

(function (exports) {
	var errno = errno$3.exports;

	Object.keys(errno.code).forEach(function(code) {
		var e = errno.code[code];

		exports[code] = function(path) {
			var err = new Error(code+', '+e.description+(path ? ' \''+path+'\'' : ''));
			err.errno = e.errno;
			err.code = code;
			err.path = path;
			return err;
		};
	});
} (errno$2));

var readableBrowser = {exports: {}};

var streamBrowser = require$$0$1.EventEmitter;

var buffer_list;
var hasRequiredBuffer_list;

function requireBuffer_list () {
	if (hasRequiredBuffer_list) return buffer_list;
	hasRequiredBuffer_list = 1;

	function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

	function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

	function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

	function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

	var _require = require$$0,
	    Buffer = _require.Buffer;

	var _require2 = require$$1$1,
	    inspect = _require2.inspect;

	var custom = inspect && inspect.custom || 'inspect';

	function copyBuffer(src, target, offset) {
	  Buffer.prototype.copy.call(src, target, offset);
	}

	buffer_list =
	/*#__PURE__*/
	function () {
	  function BufferList() {
	    _classCallCheck(this, BufferList);

	    this.head = null;
	    this.tail = null;
	    this.length = 0;
	  }

	  _createClass(BufferList, [{
	    key: "push",
	    value: function push(v) {
	      var entry = {
	        data: v,
	        next: null
	      };
	      if (this.length > 0) this.tail.next = entry;else this.head = entry;
	      this.tail = entry;
	      ++this.length;
	    }
	  }, {
	    key: "unshift",
	    value: function unshift(v) {
	      var entry = {
	        data: v,
	        next: this.head
	      };
	      if (this.length === 0) this.tail = entry;
	      this.head = entry;
	      ++this.length;
	    }
	  }, {
	    key: "shift",
	    value: function shift() {
	      if (this.length === 0) return;
	      var ret = this.head.data;
	      if (this.length === 1) this.head = this.tail = null;else this.head = this.head.next;
	      --this.length;
	      return ret;
	    }
	  }, {
	    key: "clear",
	    value: function clear() {
	      this.head = this.tail = null;
	      this.length = 0;
	    }
	  }, {
	    key: "join",
	    value: function join(s) {
	      if (this.length === 0) return '';
	      var p = this.head;
	      var ret = '' + p.data;

	      while (p = p.next) {
	        ret += s + p.data;
	      }

	      return ret;
	    }
	  }, {
	    key: "concat",
	    value: function concat(n) {
	      if (this.length === 0) return Buffer.alloc(0);
	      var ret = Buffer.allocUnsafe(n >>> 0);
	      var p = this.head;
	      var i = 0;

	      while (p) {
	        copyBuffer(p.data, ret, i);
	        i += p.data.length;
	        p = p.next;
	      }

	      return ret;
	    } // Consumes a specified amount of bytes or characters from the buffered data.

	  }, {
	    key: "consume",
	    value: function consume(n, hasStrings) {
	      var ret;

	      if (n < this.head.data.length) {
	        // `slice` is the same for buffers and strings.
	        ret = this.head.data.slice(0, n);
	        this.head.data = this.head.data.slice(n);
	      } else if (n === this.head.data.length) {
	        // First chunk is a perfect match.
	        ret = this.shift();
	      } else {
	        // Result spans more than one buffer.
	        ret = hasStrings ? this._getString(n) : this._getBuffer(n);
	      }

	      return ret;
	    }
	  }, {
	    key: "first",
	    value: function first() {
	      return this.head.data;
	    } // Consumes a specified amount of characters from the buffered data.

	  }, {
	    key: "_getString",
	    value: function _getString(n) {
	      var p = this.head;
	      var c = 1;
	      var ret = p.data;
	      n -= ret.length;

	      while (p = p.next) {
	        var str = p.data;
	        var nb = n > str.length ? str.length : n;
	        if (nb === str.length) ret += str;else ret += str.slice(0, n);
	        n -= nb;

	        if (n === 0) {
	          if (nb === str.length) {
	            ++c;
	            if (p.next) this.head = p.next;else this.head = this.tail = null;
	          } else {
	            this.head = p;
	            p.data = str.slice(nb);
	          }

	          break;
	        }

	        ++c;
	      }

	      this.length -= c;
	      return ret;
	    } // Consumes a specified amount of bytes from the buffered data.

	  }, {
	    key: "_getBuffer",
	    value: function _getBuffer(n) {
	      var ret = Buffer.allocUnsafe(n);
	      var p = this.head;
	      var c = 1;
	      p.data.copy(ret);
	      n -= p.data.length;

	      while (p = p.next) {
	        var buf = p.data;
	        var nb = n > buf.length ? buf.length : n;
	        buf.copy(ret, ret.length - n, 0, nb);
	        n -= nb;

	        if (n === 0) {
	          if (nb === buf.length) {
	            ++c;
	            if (p.next) this.head = p.next;else this.head = this.tail = null;
	          } else {
	            this.head = p;
	            p.data = buf.slice(nb);
	          }

	          break;
	        }

	        ++c;
	      }

	      this.length -= c;
	      return ret;
	    } // Make sure the linked list only shows the minimal necessary information.

	  }, {
	    key: custom,
	    value: function value(_, options) {
	      return inspect(this, _objectSpread({}, options, {
	        // Only inspect one level.
	        depth: 0,
	        // It should not recurse.
	        customInspect: false
	      }));
	    }
	  }]);

	  return BufferList;
	}();
	return buffer_list;
}

function destroy(err, cb) {
  var _this = this;

  var readableDestroyed = this._readableState && this._readableState.destroyed;
  var writableDestroyed = this._writableState && this._writableState.destroyed;

  if (readableDestroyed || writableDestroyed) {
    if (cb) {
      cb(err);
    } else if (err) {
      if (!this._writableState) {
        process.nextTick(emitErrorNT, this, err);
      } else if (!this._writableState.errorEmitted) {
        this._writableState.errorEmitted = true;
        process.nextTick(emitErrorNT, this, err);
      }
    }

    return this;
  } // we set destroyed to true before firing error callbacks in order
  // to make it re-entrance safe in case destroy() is called within callbacks


  if (this._readableState) {
    this._readableState.destroyed = true;
  } // if this is a duplex stream mark the writable part as destroyed as well


  if (this._writableState) {
    this._writableState.destroyed = true;
  }

  this._destroy(err || null, function (err) {
    if (!cb && err) {
      if (!_this._writableState) {
        process.nextTick(emitErrorAndCloseNT, _this, err);
      } else if (!_this._writableState.errorEmitted) {
        _this._writableState.errorEmitted = true;
        process.nextTick(emitErrorAndCloseNT, _this, err);
      } else {
        process.nextTick(emitCloseNT, _this);
      }
    } else if (cb) {
      process.nextTick(emitCloseNT, _this);
      cb(err);
    } else {
      process.nextTick(emitCloseNT, _this);
    }
  });

  return this;
}

function emitErrorAndCloseNT(self, err) {
  emitErrorNT(self, err);
  emitCloseNT(self);
}

function emitCloseNT(self) {
  if (self._writableState && !self._writableState.emitClose) return;
  if (self._readableState && !self._readableState.emitClose) return;
  self.emit('close');
}

function undestroy() {
  if (this._readableState) {
    this._readableState.destroyed = false;
    this._readableState.reading = false;
    this._readableState.ended = false;
    this._readableState.endEmitted = false;
  }

  if (this._writableState) {
    this._writableState.destroyed = false;
    this._writableState.ended = false;
    this._writableState.ending = false;
    this._writableState.finalCalled = false;
    this._writableState.prefinished = false;
    this._writableState.finished = false;
    this._writableState.errorEmitted = false;
  }
}

function emitErrorNT(self, err) {
  self.emit('error', err);
}

function errorOrDestroy(stream, err) {
  // We have tests that rely on errors being emitted
  // in the same tick, so changing this is semver major.
  // For now when you opt-in to autoDestroy we allow
  // the error to be emitted nextTick. In a future
  // semver major update we should change the default to this.
  var rState = stream._readableState;
  var wState = stream._writableState;
  if (rState && rState.autoDestroy || wState && wState.autoDestroy) stream.destroy(err);else stream.emit('error', err);
}

var destroy_1 = {
  destroy: destroy,
  undestroy: undestroy,
  errorOrDestroy: errorOrDestroy
};

var errorsBrowser = {};

function _inheritsLoose(subClass, superClass) { subClass.prototype = Object.create(superClass.prototype); subClass.prototype.constructor = subClass; Object.setPrototypeOf(subClass, superClass); }

var codes = {};

function createErrorType(code, message, Base) {
  if (!Base) {
    Base = Error;
  }

  function getMessage(arg1, arg2, arg3) {
    if (typeof message === 'string') {
      return message;
    } else {
      return message(arg1, arg2, arg3);
    }
  }

  var NodeError =
  /*#__PURE__*/
  function (_Base) {
    _inheritsLoose(NodeError, _Base);

    function NodeError(arg1, arg2, arg3) {
      return _Base.call(this, getMessage(arg1, arg2, arg3)) || this;
    }

    return NodeError;
  }(Base);

  NodeError.prototype.name = Base.name;
  NodeError.prototype.code = code;
  codes[code] = NodeError;
} // https://github.com/nodejs/node/blob/v10.8.0/lib/internal/errors.js


function oneOf(expected, thing) {
  if (Array.isArray(expected)) {
    var len = expected.length;
    expected = expected.map(function (i) {
      return String(i);
    });

    if (len > 2) {
      return "one of ".concat(thing, " ").concat(expected.slice(0, len - 1).join(', '), ", or ") + expected[len - 1];
    } else if (len === 2) {
      return "one of ".concat(thing, " ").concat(expected[0], " or ").concat(expected[1]);
    } else {
      return "of ".concat(thing, " ").concat(expected[0]);
    }
  } else {
    return "of ".concat(thing, " ").concat(String(expected));
  }
} // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/startsWith


function startsWith(str, search, pos) {
  return str.substr(!pos || pos < 0 ? 0 : +pos, search.length) === search;
} // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/endsWith


function endsWith(str, search, this_len) {
  if (this_len === undefined || this_len > str.length) {
    this_len = str.length;
  }

  return str.substring(this_len - search.length, this_len) === search;
} // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/includes


function includes(str, search, start) {
  if (typeof start !== 'number') {
    start = 0;
  }

  if (start + search.length > str.length) {
    return false;
  } else {
    return str.indexOf(search, start) !== -1;
  }
}

createErrorType('ERR_INVALID_OPT_VALUE', function (name, value) {
  return 'The value "' + value + '" is invalid for option "' + name + '"';
}, TypeError);
createErrorType('ERR_INVALID_ARG_TYPE', function (name, expected, actual) {
  // determiner: 'must be' or 'must not be'
  var determiner;

  if (typeof expected === 'string' && startsWith(expected, 'not ')) {
    determiner = 'must not be';
    expected = expected.replace(/^not /, '');
  } else {
    determiner = 'must be';
  }

  var msg;

  if (endsWith(name, ' argument')) {
    // For cases like 'first argument'
    msg = "The ".concat(name, " ").concat(determiner, " ").concat(oneOf(expected, 'type'));
  } else {
    var type = includes(name, '.') ? 'property' : 'argument';
    msg = "The \"".concat(name, "\" ").concat(type, " ").concat(determiner, " ").concat(oneOf(expected, 'type'));
  }

  msg += ". Received type ".concat(typeof actual);
  return msg;
}, TypeError);
createErrorType('ERR_STREAM_PUSH_AFTER_EOF', 'stream.push() after EOF');
createErrorType('ERR_METHOD_NOT_IMPLEMENTED', function (name) {
  return 'The ' + name + ' method is not implemented';
});
createErrorType('ERR_STREAM_PREMATURE_CLOSE', 'Premature close');
createErrorType('ERR_STREAM_DESTROYED', function (name) {
  return 'Cannot call ' + name + ' after a stream was destroyed';
});
createErrorType('ERR_MULTIPLE_CALLBACK', 'Callback called multiple times');
createErrorType('ERR_STREAM_CANNOT_PIPE', 'Cannot pipe, not readable');
createErrorType('ERR_STREAM_WRITE_AFTER_END', 'write after end');
createErrorType('ERR_STREAM_NULL_VALUES', 'May not write null values to stream', TypeError);
createErrorType('ERR_UNKNOWN_ENCODING', function (arg) {
  return 'Unknown encoding: ' + arg;
}, TypeError);
createErrorType('ERR_STREAM_UNSHIFT_AFTER_END_EVENT', 'stream.unshift() after end event');
errorsBrowser.codes = codes;

var ERR_INVALID_OPT_VALUE = errorsBrowser.codes.ERR_INVALID_OPT_VALUE;

function highWaterMarkFrom(options, isDuplex, duplexKey) {
  return options.highWaterMark != null ? options.highWaterMark : isDuplex ? options[duplexKey] : null;
}

function getHighWaterMark(state, options, duplexKey, isDuplex) {
  var hwm = highWaterMarkFrom(options, isDuplex, duplexKey);

  if (hwm != null) {
    if (!(isFinite(hwm) && Math.floor(hwm) === hwm) || hwm < 0) {
      var name = isDuplex ? duplexKey : 'highWaterMark';
      throw new ERR_INVALID_OPT_VALUE(name, hwm);
    }

    return Math.floor(hwm);
  } // Default value


  return state.objectMode ? 16 : 16 * 1024;
}

var state = {
  getHighWaterMark: getHighWaterMark
};

/**
 * Module exports.
 */

var browser = deprecate;

/**
 * Mark that a method should not be used.
 * Returns a modified function which warns once by default.
 *
 * If `localStorage.noDeprecation = true` is set, then it is a no-op.
 *
 * If `localStorage.throwDeprecation = true` is set, then deprecated functions
 * will throw an Error when invoked.
 *
 * If `localStorage.traceDeprecation = true` is set, then deprecated functions
 * will invoke `console.trace()` instead of `console.error()`.
 *
 * @param {Function} fn - the function to deprecate
 * @param {String} msg - the string to print to the console when `fn` is invoked
 * @returns {Function} a new "deprecated" version of `fn`
 * @api public
 */

function deprecate (fn, msg) {
  if (config('noDeprecation')) {
    return fn;
  }

  var warned = false;
  function deprecated() {
    if (!warned) {
      if (config('throwDeprecation')) {
        throw new Error(msg);
      } else if (config('traceDeprecation')) {
        console.trace(msg);
      } else {
        console.warn(msg);
      }
      warned = true;
    }
    return fn.apply(this, arguments);
  }

  return deprecated;
}

/**
 * Checks `localStorage` for boolean values for the given `name`.
 *
 * @param {String} name
 * @returns {Boolean}
 * @api private
 */

function config (name) {
  // accessing global.localStorage can trigger a DOMException in sandboxed iframes
  try {
    if (!commonjsGlobal.localStorage) return false;
  } catch (_) {
    return false;
  }
  var val = commonjsGlobal.localStorage[name];
  if (null == val) return false;
  return String(val).toLowerCase() === 'true';
}

var _stream_writable;
var hasRequired_stream_writable;

function require_stream_writable () {
	if (hasRequired_stream_writable) return _stream_writable;
	hasRequired_stream_writable = 1;

	_stream_writable = Writable;
	// there will be only 2 of these for each stream


	function CorkedRequest(state) {
	  var _this = this;

	  this.next = null;
	  this.entry = null;

	  this.finish = function () {
	    onCorkedFinish(_this, state);
	  };
	}
	/* </replacement> */

	/*<replacement>*/


	var Duplex;
	/*</replacement>*/

	Writable.WritableState = WritableState;
	/*<replacement>*/

	var internalUtil = {
	  deprecate: browser
	};
	/*</replacement>*/

	/*<replacement>*/

	var Stream = streamBrowser;
	/*</replacement>*/


	var Buffer = require$$0.Buffer;

	var OurUint8Array = commonjsGlobal.Uint8Array || function () {};

	function _uint8ArrayToBuffer(chunk) {
	  return Buffer.from(chunk);
	}

	function _isUint8Array(obj) {
	  return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
	}

	var destroyImpl = destroy_1;

	var _require = state,
	    getHighWaterMark = _require.getHighWaterMark;

	var _require$codes = errorsBrowser.codes,
	    ERR_INVALID_ARG_TYPE = _require$codes.ERR_INVALID_ARG_TYPE,
	    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
	    ERR_MULTIPLE_CALLBACK = _require$codes.ERR_MULTIPLE_CALLBACK,
	    ERR_STREAM_CANNOT_PIPE = _require$codes.ERR_STREAM_CANNOT_PIPE,
	    ERR_STREAM_DESTROYED = _require$codes.ERR_STREAM_DESTROYED,
	    ERR_STREAM_NULL_VALUES = _require$codes.ERR_STREAM_NULL_VALUES,
	    ERR_STREAM_WRITE_AFTER_END = _require$codes.ERR_STREAM_WRITE_AFTER_END,
	    ERR_UNKNOWN_ENCODING = _require$codes.ERR_UNKNOWN_ENCODING;

	var errorOrDestroy = destroyImpl.errorOrDestroy;

	inherits_browser.exports(Writable, Stream);

	function nop() {}

	function WritableState(options, stream, isDuplex) {
	  Duplex = Duplex || require_stream_duplex();
	  options = options || {}; // Duplex streams are both readable and writable, but share
	  // the same options object.
	  // However, some cases require setting options to different
	  // values for the readable and the writable sides of the duplex stream,
	  // e.g. options.readableObjectMode vs. options.writableObjectMode, etc.

	  if (typeof isDuplex !== 'boolean') isDuplex = stream instanceof Duplex; // object stream flag to indicate whether or not this stream
	  // contains buffers or objects.

	  this.objectMode = !!options.objectMode;
	  if (isDuplex) this.objectMode = this.objectMode || !!options.writableObjectMode; // the point at which write() starts returning false
	  // Note: 0 is a valid value, means that we always return false if
	  // the entire buffer is not flushed immediately on write()

	  this.highWaterMark = getHighWaterMark(this, options, 'writableHighWaterMark', isDuplex); // if _final has been called

	  this.finalCalled = false; // drain event flag.

	  this.needDrain = false; // at the start of calling end()

	  this.ending = false; // when end() has been called, and returned

	  this.ended = false; // when 'finish' is emitted

	  this.finished = false; // has it been destroyed

	  this.destroyed = false; // should we decode strings into buffers before passing to _write?
	  // this is here so that some node-core streams can optimize string
	  // handling at a lower level.

	  var noDecode = options.decodeStrings === false;
	  this.decodeStrings = !noDecode; // Crypto is kind of old and crusty.  Historically, its default string
	  // encoding is 'binary' so we have to make this configurable.
	  // Everything else in the universe uses 'utf8', though.

	  this.defaultEncoding = options.defaultEncoding || 'utf8'; // not an actual buffer we keep track of, but a measurement
	  // of how much we're waiting to get pushed to some underlying
	  // socket or file.

	  this.length = 0; // a flag to see when we're in the middle of a write.

	  this.writing = false; // when true all writes will be buffered until .uncork() call

	  this.corked = 0; // a flag to be able to tell if the onwrite cb is called immediately,
	  // or on a later tick.  We set this to true at first, because any
	  // actions that shouldn't happen until "later" should generally also
	  // not happen before the first write call.

	  this.sync = true; // a flag to know if we're processing previously buffered items, which
	  // may call the _write() callback in the same tick, so that we don't
	  // end up in an overlapped onwrite situation.

	  this.bufferProcessing = false; // the callback that's passed to _write(chunk,cb)

	  this.onwrite = function (er) {
	    onwrite(stream, er);
	  }; // the callback that the user supplies to write(chunk,encoding,cb)


	  this.writecb = null; // the amount that is being written when _write is called.

	  this.writelen = 0;
	  this.bufferedRequest = null;
	  this.lastBufferedRequest = null; // number of pending user-supplied write callbacks
	  // this must be 0 before 'finish' can be emitted

	  this.pendingcb = 0; // emit prefinish if the only thing we're waiting for is _write cbs
	  // This is relevant for synchronous Transform streams

	  this.prefinished = false; // True if the error was already emitted and should not be thrown again

	  this.errorEmitted = false; // Should close be emitted on destroy. Defaults to true.

	  this.emitClose = options.emitClose !== false; // Should .destroy() be called after 'finish' (and potentially 'end')

	  this.autoDestroy = !!options.autoDestroy; // count buffered requests

	  this.bufferedRequestCount = 0; // allocate the first CorkedRequest, there is always
	  // one allocated and free to use, and we maintain at most two

	  this.corkedRequestsFree = new CorkedRequest(this);
	}

	WritableState.prototype.getBuffer = function getBuffer() {
	  var current = this.bufferedRequest;
	  var out = [];

	  while (current) {
	    out.push(current);
	    current = current.next;
	  }

	  return out;
	};

	(function () {
	  try {
	    Object.defineProperty(WritableState.prototype, 'buffer', {
	      get: internalUtil.deprecate(function writableStateBufferGetter() {
	        return this.getBuffer();
	      }, '_writableState.buffer is deprecated. Use _writableState.getBuffer ' + 'instead.', 'DEP0003')
	    });
	  } catch (_) {}
	})(); // Test _writableState for inheritance to account for Duplex streams,
	// whose prototype chain only points to Readable.


	var realHasInstance;

	if (typeof Symbol === 'function' && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] === 'function') {
	  realHasInstance = Function.prototype[Symbol.hasInstance];
	  Object.defineProperty(Writable, Symbol.hasInstance, {
	    value: function value(object) {
	      if (realHasInstance.call(this, object)) return true;
	      if (this !== Writable) return false;
	      return object && object._writableState instanceof WritableState;
	    }
	  });
	} else {
	  realHasInstance = function realHasInstance(object) {
	    return object instanceof this;
	  };
	}

	function Writable(options) {
	  Duplex = Duplex || require_stream_duplex(); // Writable ctor is applied to Duplexes, too.
	  // `realHasInstance` is necessary because using plain `instanceof`
	  // would return false, as no `_writableState` property is attached.
	  // Trying to use the custom `instanceof` for Writable here will also break the
	  // Node.js LazyTransform implementation, which has a non-trivial getter for
	  // `_writableState` that would lead to infinite recursion.
	  // Checking for a Stream.Duplex instance is faster here instead of inside
	  // the WritableState constructor, at least with V8 6.5

	  var isDuplex = this instanceof Duplex;
	  if (!isDuplex && !realHasInstance.call(Writable, this)) return new Writable(options);
	  this._writableState = new WritableState(options, this, isDuplex); // legacy.

	  this.writable = true;

	  if (options) {
	    if (typeof options.write === 'function') this._write = options.write;
	    if (typeof options.writev === 'function') this._writev = options.writev;
	    if (typeof options.destroy === 'function') this._destroy = options.destroy;
	    if (typeof options.final === 'function') this._final = options.final;
	  }

	  Stream.call(this);
	} // Otherwise people can pipe Writable streams, which is just wrong.


	Writable.prototype.pipe = function () {
	  errorOrDestroy(this, new ERR_STREAM_CANNOT_PIPE());
	};

	function writeAfterEnd(stream, cb) {
	  var er = new ERR_STREAM_WRITE_AFTER_END(); // TODO: defer error events consistently everywhere, not just the cb

	  errorOrDestroy(stream, er);
	  process.nextTick(cb, er);
	} // Checks that a user-supplied chunk is valid, especially for the particular
	// mode the stream is in. Currently this means that `null` is never accepted
	// and undefined/non-string values are only allowed in object mode.


	function validChunk(stream, state, chunk, cb) {
	  var er;

	  if (chunk === null) {
	    er = new ERR_STREAM_NULL_VALUES();
	  } else if (typeof chunk !== 'string' && !state.objectMode) {
	    er = new ERR_INVALID_ARG_TYPE('chunk', ['string', 'Buffer'], chunk);
	  }

	  if (er) {
	    errorOrDestroy(stream, er);
	    process.nextTick(cb, er);
	    return false;
	  }

	  return true;
	}

	Writable.prototype.write = function (chunk, encoding, cb) {
	  var state = this._writableState;
	  var ret = false;

	  var isBuf = !state.objectMode && _isUint8Array(chunk);

	  if (isBuf && !Buffer.isBuffer(chunk)) {
	    chunk = _uint8ArrayToBuffer(chunk);
	  }

	  if (typeof encoding === 'function') {
	    cb = encoding;
	    encoding = null;
	  }

	  if (isBuf) encoding = 'buffer';else if (!encoding) encoding = state.defaultEncoding;
	  if (typeof cb !== 'function') cb = nop;
	  if (state.ending) writeAfterEnd(this, cb);else if (isBuf || validChunk(this, state, chunk, cb)) {
	    state.pendingcb++;
	    ret = writeOrBuffer(this, state, isBuf, chunk, encoding, cb);
	  }
	  return ret;
	};

	Writable.prototype.cork = function () {
	  this._writableState.corked++;
	};

	Writable.prototype.uncork = function () {
	  var state = this._writableState;

	  if (state.corked) {
	    state.corked--;
	    if (!state.writing && !state.corked && !state.bufferProcessing && state.bufferedRequest) clearBuffer(this, state);
	  }
	};

	Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
	  // node::ParseEncoding() requires lower case.
	  if (typeof encoding === 'string') encoding = encoding.toLowerCase();
	  if (!(['hex', 'utf8', 'utf-8', 'ascii', 'binary', 'base64', 'ucs2', 'ucs-2', 'utf16le', 'utf-16le', 'raw'].indexOf((encoding + '').toLowerCase()) > -1)) throw new ERR_UNKNOWN_ENCODING(encoding);
	  this._writableState.defaultEncoding = encoding;
	  return this;
	};

	Object.defineProperty(Writable.prototype, 'writableBuffer', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    return this._writableState && this._writableState.getBuffer();
	  }
	});

	function decodeChunk(state, chunk, encoding) {
	  if (!state.objectMode && state.decodeStrings !== false && typeof chunk === 'string') {
	    chunk = Buffer.from(chunk, encoding);
	  }

	  return chunk;
	}

	Object.defineProperty(Writable.prototype, 'writableHighWaterMark', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    return this._writableState.highWaterMark;
	  }
	}); // if we're already writing something, then just put this
	// in the queue, and wait our turn.  Otherwise, call _write
	// If we return false, then we need a drain event, so set that flag.

	function writeOrBuffer(stream, state, isBuf, chunk, encoding, cb) {
	  if (!isBuf) {
	    var newChunk = decodeChunk(state, chunk, encoding);

	    if (chunk !== newChunk) {
	      isBuf = true;
	      encoding = 'buffer';
	      chunk = newChunk;
	    }
	  }

	  var len = state.objectMode ? 1 : chunk.length;
	  state.length += len;
	  var ret = state.length < state.highWaterMark; // we must ensure that previous needDrain will not be reset to false.

	  if (!ret) state.needDrain = true;

	  if (state.writing || state.corked) {
	    var last = state.lastBufferedRequest;
	    state.lastBufferedRequest = {
	      chunk: chunk,
	      encoding: encoding,
	      isBuf: isBuf,
	      callback: cb,
	      next: null
	    };

	    if (last) {
	      last.next = state.lastBufferedRequest;
	    } else {
	      state.bufferedRequest = state.lastBufferedRequest;
	    }

	    state.bufferedRequestCount += 1;
	  } else {
	    doWrite(stream, state, false, len, chunk, encoding, cb);
	  }

	  return ret;
	}

	function doWrite(stream, state, writev, len, chunk, encoding, cb) {
	  state.writelen = len;
	  state.writecb = cb;
	  state.writing = true;
	  state.sync = true;
	  if (state.destroyed) state.onwrite(new ERR_STREAM_DESTROYED('write'));else if (writev) stream._writev(chunk, state.onwrite);else stream._write(chunk, encoding, state.onwrite);
	  state.sync = false;
	}

	function onwriteError(stream, state, sync, er, cb) {
	  --state.pendingcb;

	  if (sync) {
	    // defer the callback if we are being called synchronously
	    // to avoid piling up things on the stack
	    process.nextTick(cb, er); // this can emit finish, and it will always happen
	    // after error

	    process.nextTick(finishMaybe, stream, state);
	    stream._writableState.errorEmitted = true;
	    errorOrDestroy(stream, er);
	  } else {
	    // the caller expect this to happen before if
	    // it is async
	    cb(er);
	    stream._writableState.errorEmitted = true;
	    errorOrDestroy(stream, er); // this can emit finish, but finish must
	    // always follow error

	    finishMaybe(stream, state);
	  }
	}

	function onwriteStateUpdate(state) {
	  state.writing = false;
	  state.writecb = null;
	  state.length -= state.writelen;
	  state.writelen = 0;
	}

	function onwrite(stream, er) {
	  var state = stream._writableState;
	  var sync = state.sync;
	  var cb = state.writecb;
	  if (typeof cb !== 'function') throw new ERR_MULTIPLE_CALLBACK();
	  onwriteStateUpdate(state);
	  if (er) onwriteError(stream, state, sync, er, cb);else {
	    // Check if we're actually ready to finish, but don't emit yet
	    var finished = needFinish(state) || stream.destroyed;

	    if (!finished && !state.corked && !state.bufferProcessing && state.bufferedRequest) {
	      clearBuffer(stream, state);
	    }

	    if (sync) {
	      process.nextTick(afterWrite, stream, state, finished, cb);
	    } else {
	      afterWrite(stream, state, finished, cb);
	    }
	  }
	}

	function afterWrite(stream, state, finished, cb) {
	  if (!finished) onwriteDrain(stream, state);
	  state.pendingcb--;
	  cb();
	  finishMaybe(stream, state);
	} // Must force callback to be called on nextTick, so that we don't
	// emit 'drain' before the write() consumer gets the 'false' return
	// value, and has a chance to attach a 'drain' listener.


	function onwriteDrain(stream, state) {
	  if (state.length === 0 && state.needDrain) {
	    state.needDrain = false;
	    stream.emit('drain');
	  }
	} // if there's something in the buffer waiting, then process it


	function clearBuffer(stream, state) {
	  state.bufferProcessing = true;
	  var entry = state.bufferedRequest;

	  if (stream._writev && entry && entry.next) {
	    // Fast case, write everything using _writev()
	    var l = state.bufferedRequestCount;
	    var buffer = new Array(l);
	    var holder = state.corkedRequestsFree;
	    holder.entry = entry;
	    var count = 0;
	    var allBuffers = true;

	    while (entry) {
	      buffer[count] = entry;
	      if (!entry.isBuf) allBuffers = false;
	      entry = entry.next;
	      count += 1;
	    }

	    buffer.allBuffers = allBuffers;
	    doWrite(stream, state, true, state.length, buffer, '', holder.finish); // doWrite is almost always async, defer these to save a bit of time
	    // as the hot path ends with doWrite

	    state.pendingcb++;
	    state.lastBufferedRequest = null;

	    if (holder.next) {
	      state.corkedRequestsFree = holder.next;
	      holder.next = null;
	    } else {
	      state.corkedRequestsFree = new CorkedRequest(state);
	    }

	    state.bufferedRequestCount = 0;
	  } else {
	    // Slow case, write chunks one-by-one
	    while (entry) {
	      var chunk = entry.chunk;
	      var encoding = entry.encoding;
	      var cb = entry.callback;
	      var len = state.objectMode ? 1 : chunk.length;
	      doWrite(stream, state, false, len, chunk, encoding, cb);
	      entry = entry.next;
	      state.bufferedRequestCount--; // if we didn't call the onwrite immediately, then
	      // it means that we need to wait until it does.
	      // also, that means that the chunk and cb are currently
	      // being processed, so move the buffer counter past them.

	      if (state.writing) {
	        break;
	      }
	    }

	    if (entry === null) state.lastBufferedRequest = null;
	  }

	  state.bufferedRequest = entry;
	  state.bufferProcessing = false;
	}

	Writable.prototype._write = function (chunk, encoding, cb) {
	  cb(new ERR_METHOD_NOT_IMPLEMENTED('_write()'));
	};

	Writable.prototype._writev = null;

	Writable.prototype.end = function (chunk, encoding, cb) {
	  var state = this._writableState;

	  if (typeof chunk === 'function') {
	    cb = chunk;
	    chunk = null;
	    encoding = null;
	  } else if (typeof encoding === 'function') {
	    cb = encoding;
	    encoding = null;
	  }

	  if (chunk !== null && chunk !== undefined) this.write(chunk, encoding); // .end() fully uncorks

	  if (state.corked) {
	    state.corked = 1;
	    this.uncork();
	  } // ignore unnecessary end() calls.


	  if (!state.ending) endWritable(this, state, cb);
	  return this;
	};

	Object.defineProperty(Writable.prototype, 'writableLength', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    return this._writableState.length;
	  }
	});

	function needFinish(state) {
	  return state.ending && state.length === 0 && state.bufferedRequest === null && !state.finished && !state.writing;
	}

	function callFinal(stream, state) {
	  stream._final(function (err) {
	    state.pendingcb--;

	    if (err) {
	      errorOrDestroy(stream, err);
	    }

	    state.prefinished = true;
	    stream.emit('prefinish');
	    finishMaybe(stream, state);
	  });
	}

	function prefinish(stream, state) {
	  if (!state.prefinished && !state.finalCalled) {
	    if (typeof stream._final === 'function' && !state.destroyed) {
	      state.pendingcb++;
	      state.finalCalled = true;
	      process.nextTick(callFinal, stream, state);
	    } else {
	      state.prefinished = true;
	      stream.emit('prefinish');
	    }
	  }
	}

	function finishMaybe(stream, state) {
	  var need = needFinish(state);

	  if (need) {
	    prefinish(stream, state);

	    if (state.pendingcb === 0) {
	      state.finished = true;
	      stream.emit('finish');

	      if (state.autoDestroy) {
	        // In case of duplex streams we need a way to detect
	        // if the readable side is ready for autoDestroy as well
	        var rState = stream._readableState;

	        if (!rState || rState.autoDestroy && rState.endEmitted) {
	          stream.destroy();
	        }
	      }
	    }
	  }

	  return need;
	}

	function endWritable(stream, state, cb) {
	  state.ending = true;
	  finishMaybe(stream, state);

	  if (cb) {
	    if (state.finished) process.nextTick(cb);else stream.once('finish', cb);
	  }

	  state.ended = true;
	  stream.writable = false;
	}

	function onCorkedFinish(corkReq, state, err) {
	  var entry = corkReq.entry;
	  corkReq.entry = null;

	  while (entry) {
	    var cb = entry.callback;
	    state.pendingcb--;
	    cb(err);
	    entry = entry.next;
	  } // reuse the free corkReq.


	  state.corkedRequestsFree.next = corkReq;
	}

	Object.defineProperty(Writable.prototype, 'destroyed', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    if (this._writableState === undefined) {
	      return false;
	    }

	    return this._writableState.destroyed;
	  },
	  set: function set(value) {
	    // we ignore the value if the stream
	    // has not been initialized yet
	    if (!this._writableState) {
	      return;
	    } // backward compatibility, the user is explicitly
	    // managing destroyed


	    this._writableState.destroyed = value;
	  }
	});
	Writable.prototype.destroy = destroyImpl.destroy;
	Writable.prototype._undestroy = destroyImpl.undestroy;

	Writable.prototype._destroy = function (err, cb) {
	  cb(err);
	};
	return _stream_writable;
}

var _stream_duplex;
var hasRequired_stream_duplex;

function require_stream_duplex () {
	if (hasRequired_stream_duplex) return _stream_duplex;
	hasRequired_stream_duplex = 1;
	/*<replacement>*/

	var objectKeys = Object.keys || function (obj) {
	  var keys = [];

	  for (var key in obj) {
	    keys.push(key);
	  }

	  return keys;
	};
	/*</replacement>*/


	_stream_duplex = Duplex;

	var Readable = require_stream_readable();

	var Writable = require_stream_writable();

	inherits_browser.exports(Duplex, Readable);

	{
	  // Allow the keys array to be GC'ed.
	  var keys = objectKeys(Writable.prototype);

	  for (var v = 0; v < keys.length; v++) {
	    var method = keys[v];
	    if (!Duplex.prototype[method]) Duplex.prototype[method] = Writable.prototype[method];
	  }
	}

	function Duplex(options) {
	  if (!(this instanceof Duplex)) return new Duplex(options);
	  Readable.call(this, options);
	  Writable.call(this, options);
	  this.allowHalfOpen = true;

	  if (options) {
	    if (options.readable === false) this.readable = false;
	    if (options.writable === false) this.writable = false;

	    if (options.allowHalfOpen === false) {
	      this.allowHalfOpen = false;
	      this.once('end', onend);
	    }
	  }
	}

	Object.defineProperty(Duplex.prototype, 'writableHighWaterMark', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    return this._writableState.highWaterMark;
	  }
	});
	Object.defineProperty(Duplex.prototype, 'writableBuffer', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    return this._writableState && this._writableState.getBuffer();
	  }
	});
	Object.defineProperty(Duplex.prototype, 'writableLength', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    return this._writableState.length;
	  }
	}); // the no-half-open enforcer

	function onend() {
	  // If the writable side ended, then we're ok.
	  if (this._writableState.ended) return; // no more data can be written.
	  // But allow more writes to happen in this tick.

	  process.nextTick(onEndNT, this);
	}

	function onEndNT(self) {
	  self.end();
	}

	Object.defineProperty(Duplex.prototype, 'destroyed', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    if (this._readableState === undefined || this._writableState === undefined) {
	      return false;
	    }

	    return this._readableState.destroyed && this._writableState.destroyed;
	  },
	  set: function set(value) {
	    // we ignore the value if the stream
	    // has not been initialized yet
	    if (this._readableState === undefined || this._writableState === undefined) {
	      return;
	    } // backward compatibility, the user is explicitly
	    // managing destroyed


	    this._readableState.destroyed = value;
	    this._writableState.destroyed = value;
	  }
	});
	return _stream_duplex;
}

var ERR_STREAM_PREMATURE_CLOSE = errorsBrowser.codes.ERR_STREAM_PREMATURE_CLOSE;

function once$3(callback) {
  var called = false;
  return function () {
    if (called) return;
    called = true;

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    callback.apply(this, args);
  };
}

function noop$2() {}

function isRequest$1(stream) {
  return stream.setHeader && typeof stream.abort === 'function';
}

function eos$1(stream, opts, callback) {
  if (typeof opts === 'function') return eos$1(stream, null, opts);
  if (!opts) opts = {};
  callback = once$3(callback || noop$2);
  var readable = opts.readable || opts.readable !== false && stream.readable;
  var writable = opts.writable || opts.writable !== false && stream.writable;

  var onlegacyfinish = function onlegacyfinish() {
    if (!stream.writable) onfinish();
  };

  var writableEnded = stream._writableState && stream._writableState.finished;

  var onfinish = function onfinish() {
    writable = false;
    writableEnded = true;
    if (!readable) callback.call(stream);
  };

  var readableEnded = stream._readableState && stream._readableState.endEmitted;

  var onend = function onend() {
    readable = false;
    readableEnded = true;
    if (!writable) callback.call(stream);
  };

  var onerror = function onerror(err) {
    callback.call(stream, err);
  };

  var onclose = function onclose() {
    var err;

    if (readable && !readableEnded) {
      if (!stream._readableState || !stream._readableState.ended) err = new ERR_STREAM_PREMATURE_CLOSE();
      return callback.call(stream, err);
    }

    if (writable && !writableEnded) {
      if (!stream._writableState || !stream._writableState.ended) err = new ERR_STREAM_PREMATURE_CLOSE();
      return callback.call(stream, err);
    }
  };

  var onrequest = function onrequest() {
    stream.req.on('finish', onfinish);
  };

  if (isRequest$1(stream)) {
    stream.on('complete', onfinish);
    stream.on('abort', onclose);
    if (stream.req) onrequest();else stream.on('request', onrequest);
  } else if (writable && !stream._writableState) {
    // legacy streams
    stream.on('end', onlegacyfinish);
    stream.on('close', onlegacyfinish);
  }

  stream.on('end', onend);
  stream.on('finish', onfinish);
  if (opts.error !== false) stream.on('error', onerror);
  stream.on('close', onclose);
  return function () {
    stream.removeListener('complete', onfinish);
    stream.removeListener('abort', onclose);
    stream.removeListener('request', onrequest);
    if (stream.req) stream.req.removeListener('finish', onfinish);
    stream.removeListener('end', onlegacyfinish);
    stream.removeListener('close', onlegacyfinish);
    stream.removeListener('finish', onfinish);
    stream.removeListener('end', onend);
    stream.removeListener('error', onerror);
    stream.removeListener('close', onclose);
  };
}

var endOfStream = eos$1;

var async_iterator;
var hasRequiredAsync_iterator;

function requireAsync_iterator () {
	if (hasRequiredAsync_iterator) return async_iterator;
	hasRequiredAsync_iterator = 1;

	var _Object$setPrototypeO;

	function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

	var finished = endOfStream;

	var kLastResolve = Symbol('lastResolve');
	var kLastReject = Symbol('lastReject');
	var kError = Symbol('error');
	var kEnded = Symbol('ended');
	var kLastPromise = Symbol('lastPromise');
	var kHandlePromise = Symbol('handlePromise');
	var kStream = Symbol('stream');

	function createIterResult(value, done) {
	  return {
	    value: value,
	    done: done
	  };
	}

	function readAndResolve(iter) {
	  var resolve = iter[kLastResolve];

	  if (resolve !== null) {
	    var data = iter[kStream].read(); // we defer if data is null
	    // we can be expecting either 'end' or
	    // 'error'

	    if (data !== null) {
	      iter[kLastPromise] = null;
	      iter[kLastResolve] = null;
	      iter[kLastReject] = null;
	      resolve(createIterResult(data, false));
	    }
	  }
	}

	function onReadable(iter) {
	  // we wait for the next tick, because it might
	  // emit an error with process.nextTick
	  process.nextTick(readAndResolve, iter);
	}

	function wrapForNext(lastPromise, iter) {
	  return function (resolve, reject) {
	    lastPromise.then(function () {
	      if (iter[kEnded]) {
	        resolve(createIterResult(undefined, true));
	        return;
	      }

	      iter[kHandlePromise](resolve, reject);
	    }, reject);
	  };
	}

	var AsyncIteratorPrototype = Object.getPrototypeOf(function () {});
	var ReadableStreamAsyncIteratorPrototype = Object.setPrototypeOf((_Object$setPrototypeO = {
	  get stream() {
	    return this[kStream];
	  },

	  next: function next() {
	    var _this = this;

	    // if we have detected an error in the meanwhile
	    // reject straight away
	    var error = this[kError];

	    if (error !== null) {
	      return Promise.reject(error);
	    }

	    if (this[kEnded]) {
	      return Promise.resolve(createIterResult(undefined, true));
	    }

	    if (this[kStream].destroyed) {
	      // We need to defer via nextTick because if .destroy(err) is
	      // called, the error will be emitted via nextTick, and
	      // we cannot guarantee that there is no error lingering around
	      // waiting to be emitted.
	      return new Promise(function (resolve, reject) {
	        process.nextTick(function () {
	          if (_this[kError]) {
	            reject(_this[kError]);
	          } else {
	            resolve(createIterResult(undefined, true));
	          }
	        });
	      });
	    } // if we have multiple next() calls
	    // we will wait for the previous Promise to finish
	    // this logic is optimized to support for await loops,
	    // where next() is only called once at a time


	    var lastPromise = this[kLastPromise];
	    var promise;

	    if (lastPromise) {
	      promise = new Promise(wrapForNext(lastPromise, this));
	    } else {
	      // fast path needed to support multiple this.push()
	      // without triggering the next() queue
	      var data = this[kStream].read();

	      if (data !== null) {
	        return Promise.resolve(createIterResult(data, false));
	      }

	      promise = new Promise(this[kHandlePromise]);
	    }

	    this[kLastPromise] = promise;
	    return promise;
	  }
	}, _defineProperty(_Object$setPrototypeO, Symbol.asyncIterator, function () {
	  return this;
	}), _defineProperty(_Object$setPrototypeO, "return", function _return() {
	  var _this2 = this;

	  // destroy(err, cb) is a private API
	  // we can guarantee we have that here, because we control the
	  // Readable class this is attached to
	  return new Promise(function (resolve, reject) {
	    _this2[kStream].destroy(null, function (err) {
	      if (err) {
	        reject(err);
	        return;
	      }

	      resolve(createIterResult(undefined, true));
	    });
	  });
	}), _Object$setPrototypeO), AsyncIteratorPrototype);

	var createReadableStreamAsyncIterator = function createReadableStreamAsyncIterator(stream) {
	  var _Object$create;

	  var iterator = Object.create(ReadableStreamAsyncIteratorPrototype, (_Object$create = {}, _defineProperty(_Object$create, kStream, {
	    value: stream,
	    writable: true
	  }), _defineProperty(_Object$create, kLastResolve, {
	    value: null,
	    writable: true
	  }), _defineProperty(_Object$create, kLastReject, {
	    value: null,
	    writable: true
	  }), _defineProperty(_Object$create, kError, {
	    value: null,
	    writable: true
	  }), _defineProperty(_Object$create, kEnded, {
	    value: stream._readableState.endEmitted,
	    writable: true
	  }), _defineProperty(_Object$create, kHandlePromise, {
	    value: function value(resolve, reject) {
	      var data = iterator[kStream].read();

	      if (data) {
	        iterator[kLastPromise] = null;
	        iterator[kLastResolve] = null;
	        iterator[kLastReject] = null;
	        resolve(createIterResult(data, false));
	      } else {
	        iterator[kLastResolve] = resolve;
	        iterator[kLastReject] = reject;
	      }
	    },
	    writable: true
	  }), _Object$create));
	  iterator[kLastPromise] = null;
	  finished(stream, function (err) {
	    if (err && err.code !== 'ERR_STREAM_PREMATURE_CLOSE') {
	      var reject = iterator[kLastReject]; // reject if we are waiting for data in the Promise
	      // returned by next() and store the error

	      if (reject !== null) {
	        iterator[kLastPromise] = null;
	        iterator[kLastResolve] = null;
	        iterator[kLastReject] = null;
	        reject(err);
	      }

	      iterator[kError] = err;
	      return;
	    }

	    var resolve = iterator[kLastResolve];

	    if (resolve !== null) {
	      iterator[kLastPromise] = null;
	      iterator[kLastResolve] = null;
	      iterator[kLastReject] = null;
	      resolve(createIterResult(undefined, true));
	    }

	    iterator[kEnded] = true;
	  });
	  stream.on('readable', onReadable.bind(null, iterator));
	  return iterator;
	};

	async_iterator = createReadableStreamAsyncIterator;
	return async_iterator;
}

var fromBrowser;
var hasRequiredFromBrowser;

function requireFromBrowser () {
	if (hasRequiredFromBrowser) return fromBrowser;
	hasRequiredFromBrowser = 1;
	fromBrowser = function () {
	  throw new Error('Readable.from is not available in the browser')
	};
	return fromBrowser;
}

var _stream_readable;
var hasRequired_stream_readable;

function require_stream_readable () {
	if (hasRequired_stream_readable) return _stream_readable;
	hasRequired_stream_readable = 1;

	_stream_readable = Readable;
	/*<replacement>*/

	var Duplex;
	/*</replacement>*/

	Readable.ReadableState = ReadableState;
	/*<replacement>*/

	require$$0$1.EventEmitter;

	var EElistenerCount = function EElistenerCount(emitter, type) {
	  return emitter.listeners(type).length;
	};
	/*</replacement>*/

	/*<replacement>*/


	var Stream = streamBrowser;
	/*</replacement>*/


	var Buffer = require$$0.Buffer;

	var OurUint8Array = commonjsGlobal.Uint8Array || function () {};

	function _uint8ArrayToBuffer(chunk) {
	  return Buffer.from(chunk);
	}

	function _isUint8Array(obj) {
	  return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
	}
	/*<replacement>*/


	var debugUtil = require$$1$1;

	var debug;

	if (debugUtil && debugUtil.debuglog) {
	  debug = debugUtil.debuglog('stream');
	} else {
	  debug = function debug() {};
	}
	/*</replacement>*/


	var BufferList = requireBuffer_list();

	var destroyImpl = destroy_1;

	var _require = state,
	    getHighWaterMark = _require.getHighWaterMark;

	var _require$codes = errorsBrowser.codes,
	    ERR_INVALID_ARG_TYPE = _require$codes.ERR_INVALID_ARG_TYPE,
	    ERR_STREAM_PUSH_AFTER_EOF = _require$codes.ERR_STREAM_PUSH_AFTER_EOF,
	    ERR_METHOD_NOT_IMPLEMENTED = _require$codes.ERR_METHOD_NOT_IMPLEMENTED,
	    ERR_STREAM_UNSHIFT_AFTER_END_EVENT = _require$codes.ERR_STREAM_UNSHIFT_AFTER_END_EVENT; // Lazy loaded to improve the startup performance.


	var StringDecoder;
	var createReadableStreamAsyncIterator;
	var from;

	inherits_browser.exports(Readable, Stream);

	var errorOrDestroy = destroyImpl.errorOrDestroy;
	var kProxyEvents = ['error', 'close', 'destroy', 'pause', 'resume'];

	function prependListener(emitter, event, fn) {
	  // Sadly this is not cacheable as some libraries bundle their own
	  // event emitter implementation with them.
	  if (typeof emitter.prependListener === 'function') return emitter.prependListener(event, fn); // This is a hack to make sure that our error handler is attached before any
	  // userland ones.  NEVER DO THIS. This is here only because this code needs
	  // to continue to work with older versions of Node.js that do not include
	  // the prependListener() method. The goal is to eventually remove this hack.

	  if (!emitter._events || !emitter._events[event]) emitter.on(event, fn);else if (Array.isArray(emitter._events[event])) emitter._events[event].unshift(fn);else emitter._events[event] = [fn, emitter._events[event]];
	}

	function ReadableState(options, stream, isDuplex) {
	  Duplex = Duplex || require_stream_duplex();
	  options = options || {}; // Duplex streams are both readable and writable, but share
	  // the same options object.
	  // However, some cases require setting options to different
	  // values for the readable and the writable sides of the duplex stream.
	  // These options can be provided separately as readableXXX and writableXXX.

	  if (typeof isDuplex !== 'boolean') isDuplex = stream instanceof Duplex; // object stream flag. Used to make read(n) ignore n and to
	  // make all the buffer merging and length checks go away

	  this.objectMode = !!options.objectMode;
	  if (isDuplex) this.objectMode = this.objectMode || !!options.readableObjectMode; // the point at which it stops calling _read() to fill the buffer
	  // Note: 0 is a valid value, means "don't call _read preemptively ever"

	  this.highWaterMark = getHighWaterMark(this, options, 'readableHighWaterMark', isDuplex); // A linked list is used to store data chunks instead of an array because the
	  // linked list can remove elements from the beginning faster than
	  // array.shift()

	  this.buffer = new BufferList();
	  this.length = 0;
	  this.pipes = null;
	  this.pipesCount = 0;
	  this.flowing = null;
	  this.ended = false;
	  this.endEmitted = false;
	  this.reading = false; // a flag to be able to tell if the event 'readable'/'data' is emitted
	  // immediately, or on a later tick.  We set this to true at first, because
	  // any actions that shouldn't happen until "later" should generally also
	  // not happen before the first read call.

	  this.sync = true; // whenever we return null, then we set a flag to say
	  // that we're awaiting a 'readable' event emission.

	  this.needReadable = false;
	  this.emittedReadable = false;
	  this.readableListening = false;
	  this.resumeScheduled = false;
	  this.paused = true; // Should close be emitted on destroy. Defaults to true.

	  this.emitClose = options.emitClose !== false; // Should .destroy() be called after 'end' (and potentially 'finish')

	  this.autoDestroy = !!options.autoDestroy; // has it been destroyed

	  this.destroyed = false; // Crypto is kind of old and crusty.  Historically, its default string
	  // encoding is 'binary' so we have to make this configurable.
	  // Everything else in the universe uses 'utf8', though.

	  this.defaultEncoding = options.defaultEncoding || 'utf8'; // the number of writers that are awaiting a drain event in .pipe()s

	  this.awaitDrain = 0; // if true, a maybeReadMore has been scheduled

	  this.readingMore = false;
	  this.decoder = null;
	  this.encoding = null;

	  if (options.encoding) {
	    if (!StringDecoder) StringDecoder = require$$6$1.StringDecoder;
	    this.decoder = new StringDecoder(options.encoding);
	    this.encoding = options.encoding;
	  }
	}

	function Readable(options) {
	  Duplex = Duplex || require_stream_duplex();
	  if (!(this instanceof Readable)) return new Readable(options); // Checking for a Stream.Duplex instance is faster here instead of inside
	  // the ReadableState constructor, at least with V8 6.5

	  var isDuplex = this instanceof Duplex;
	  this._readableState = new ReadableState(options, this, isDuplex); // legacy

	  this.readable = true;

	  if (options) {
	    if (typeof options.read === 'function') this._read = options.read;
	    if (typeof options.destroy === 'function') this._destroy = options.destroy;
	  }

	  Stream.call(this);
	}

	Object.defineProperty(Readable.prototype, 'destroyed', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    if (this._readableState === undefined) {
	      return false;
	    }

	    return this._readableState.destroyed;
	  },
	  set: function set(value) {
	    // we ignore the value if the stream
	    // has not been initialized yet
	    if (!this._readableState) {
	      return;
	    } // backward compatibility, the user is explicitly
	    // managing destroyed


	    this._readableState.destroyed = value;
	  }
	});
	Readable.prototype.destroy = destroyImpl.destroy;
	Readable.prototype._undestroy = destroyImpl.undestroy;

	Readable.prototype._destroy = function (err, cb) {
	  cb(err);
	}; // Manually shove something into the read() buffer.
	// This returns true if the highWaterMark has not been hit yet,
	// similar to how Writable.write() returns true if you should
	// write() some more.


	Readable.prototype.push = function (chunk, encoding) {
	  var state = this._readableState;
	  var skipChunkCheck;

	  if (!state.objectMode) {
	    if (typeof chunk === 'string') {
	      encoding = encoding || state.defaultEncoding;

	      if (encoding !== state.encoding) {
	        chunk = Buffer.from(chunk, encoding);
	        encoding = '';
	      }

	      skipChunkCheck = true;
	    }
	  } else {
	    skipChunkCheck = true;
	  }

	  return readableAddChunk(this, chunk, encoding, false, skipChunkCheck);
	}; // Unshift should *always* be something directly out of read()


	Readable.prototype.unshift = function (chunk) {
	  return readableAddChunk(this, chunk, null, true, false);
	};

	function readableAddChunk(stream, chunk, encoding, addToFront, skipChunkCheck) {
	  debug('readableAddChunk', chunk);
	  var state = stream._readableState;

	  if (chunk === null) {
	    state.reading = false;
	    onEofChunk(stream, state);
	  } else {
	    var er;
	    if (!skipChunkCheck) er = chunkInvalid(state, chunk);

	    if (er) {
	      errorOrDestroy(stream, er);
	    } else if (state.objectMode || chunk && chunk.length > 0) {
	      if (typeof chunk !== 'string' && !state.objectMode && Object.getPrototypeOf(chunk) !== Buffer.prototype) {
	        chunk = _uint8ArrayToBuffer(chunk);
	      }

	      if (addToFront) {
	        if (state.endEmitted) errorOrDestroy(stream, new ERR_STREAM_UNSHIFT_AFTER_END_EVENT());else addChunk(stream, state, chunk, true);
	      } else if (state.ended) {
	        errorOrDestroy(stream, new ERR_STREAM_PUSH_AFTER_EOF());
	      } else if (state.destroyed) {
	        return false;
	      } else {
	        state.reading = false;

	        if (state.decoder && !encoding) {
	          chunk = state.decoder.write(chunk);
	          if (state.objectMode || chunk.length !== 0) addChunk(stream, state, chunk, false);else maybeReadMore(stream, state);
	        } else {
	          addChunk(stream, state, chunk, false);
	        }
	      }
	    } else if (!addToFront) {
	      state.reading = false;
	      maybeReadMore(stream, state);
	    }
	  } // We can push more data if we are below the highWaterMark.
	  // Also, if we have no data yet, we can stand some more bytes.
	  // This is to work around cases where hwm=0, such as the repl.


	  return !state.ended && (state.length < state.highWaterMark || state.length === 0);
	}

	function addChunk(stream, state, chunk, addToFront) {
	  if (state.flowing && state.length === 0 && !state.sync) {
	    state.awaitDrain = 0;
	    stream.emit('data', chunk);
	  } else {
	    // update the buffer info.
	    state.length += state.objectMode ? 1 : chunk.length;
	    if (addToFront) state.buffer.unshift(chunk);else state.buffer.push(chunk);
	    if (state.needReadable) emitReadable(stream);
	  }

	  maybeReadMore(stream, state);
	}

	function chunkInvalid(state, chunk) {
	  var er;

	  if (!_isUint8Array(chunk) && typeof chunk !== 'string' && chunk !== undefined && !state.objectMode) {
	    er = new ERR_INVALID_ARG_TYPE('chunk', ['string', 'Buffer', 'Uint8Array'], chunk);
	  }

	  return er;
	}

	Readable.prototype.isPaused = function () {
	  return this._readableState.flowing === false;
	}; // backwards compatibility.


	Readable.prototype.setEncoding = function (enc) {
	  if (!StringDecoder) StringDecoder = require$$6$1.StringDecoder;
	  var decoder = new StringDecoder(enc);
	  this._readableState.decoder = decoder; // If setEncoding(null), decoder.encoding equals utf8

	  this._readableState.encoding = this._readableState.decoder.encoding; // Iterate over current buffer to convert already stored Buffers:

	  var p = this._readableState.buffer.head;
	  var content = '';

	  while (p !== null) {
	    content += decoder.write(p.data);
	    p = p.next;
	  }

	  this._readableState.buffer.clear();

	  if (content !== '') this._readableState.buffer.push(content);
	  this._readableState.length = content.length;
	  return this;
	}; // Don't raise the hwm > 1GB


	var MAX_HWM = 0x40000000;

	function computeNewHighWaterMark(n) {
	  if (n >= MAX_HWM) {
	    // TODO(ronag): Throw ERR_VALUE_OUT_OF_RANGE.
	    n = MAX_HWM;
	  } else {
	    // Get the next highest power of 2 to prevent increasing hwm excessively in
	    // tiny amounts
	    n--;
	    n |= n >>> 1;
	    n |= n >>> 2;
	    n |= n >>> 4;
	    n |= n >>> 8;
	    n |= n >>> 16;
	    n++;
	  }

	  return n;
	} // This function is designed to be inlinable, so please take care when making
	// changes to the function body.


	function howMuchToRead(n, state) {
	  if (n <= 0 || state.length === 0 && state.ended) return 0;
	  if (state.objectMode) return 1;

	  if (n !== n) {
	    // Only flow one buffer at a time
	    if (state.flowing && state.length) return state.buffer.head.data.length;else return state.length;
	  } // If we're asking for more than the current hwm, then raise the hwm.


	  if (n > state.highWaterMark) state.highWaterMark = computeNewHighWaterMark(n);
	  if (n <= state.length) return n; // Don't have enough

	  if (!state.ended) {
	    state.needReadable = true;
	    return 0;
	  }

	  return state.length;
	} // you can override either this method, or the async _read(n) below.


	Readable.prototype.read = function (n) {
	  debug('read', n);
	  n = parseInt(n, 10);
	  var state = this._readableState;
	  var nOrig = n;
	  if (n !== 0) state.emittedReadable = false; // if we're doing read(0) to trigger a readable event, but we
	  // already have a bunch of data in the buffer, then just trigger
	  // the 'readable' event and move on.

	  if (n === 0 && state.needReadable && ((state.highWaterMark !== 0 ? state.length >= state.highWaterMark : state.length > 0) || state.ended)) {
	    debug('read: emitReadable', state.length, state.ended);
	    if (state.length === 0 && state.ended) endReadable(this);else emitReadable(this);
	    return null;
	  }

	  n = howMuchToRead(n, state); // if we've ended, and we're now clear, then finish it up.

	  if (n === 0 && state.ended) {
	    if (state.length === 0) endReadable(this);
	    return null;
	  } // All the actual chunk generation logic needs to be
	  // *below* the call to _read.  The reason is that in certain
	  // synthetic stream cases, such as passthrough streams, _read
	  // may be a completely synchronous operation which may change
	  // the state of the read buffer, providing enough data when
	  // before there was *not* enough.
	  //
	  // So, the steps are:
	  // 1. Figure out what the state of things will be after we do
	  // a read from the buffer.
	  //
	  // 2. If that resulting state will trigger a _read, then call _read.
	  // Note that this may be asynchronous, or synchronous.  Yes, it is
	  // deeply ugly to write APIs this way, but that still doesn't mean
	  // that the Readable class should behave improperly, as streams are
	  // designed to be sync/async agnostic.
	  // Take note if the _read call is sync or async (ie, if the read call
	  // has returned yet), so that we know whether or not it's safe to emit
	  // 'readable' etc.
	  //
	  // 3. Actually pull the requested chunks out of the buffer and return.
	  // if we need a readable event, then we need to do some reading.


	  var doRead = state.needReadable;
	  debug('need readable', doRead); // if we currently have less than the highWaterMark, then also read some

	  if (state.length === 0 || state.length - n < state.highWaterMark) {
	    doRead = true;
	    debug('length less than watermark', doRead);
	  } // however, if we've ended, then there's no point, and if we're already
	  // reading, then it's unnecessary.


	  if (state.ended || state.reading) {
	    doRead = false;
	    debug('reading or ended', doRead);
	  } else if (doRead) {
	    debug('do read');
	    state.reading = true;
	    state.sync = true; // if the length is currently zero, then we *need* a readable event.

	    if (state.length === 0) state.needReadable = true; // call internal read method

	    this._read(state.highWaterMark);

	    state.sync = false; // If _read pushed data synchronously, then `reading` will be false,
	    // and we need to re-evaluate how much data we can return to the user.

	    if (!state.reading) n = howMuchToRead(nOrig, state);
	  }

	  var ret;
	  if (n > 0) ret = fromList(n, state);else ret = null;

	  if (ret === null) {
	    state.needReadable = state.length <= state.highWaterMark;
	    n = 0;
	  } else {
	    state.length -= n;
	    state.awaitDrain = 0;
	  }

	  if (state.length === 0) {
	    // If we have nothing in the buffer, then we want to know
	    // as soon as we *do* get something into the buffer.
	    if (!state.ended) state.needReadable = true; // If we tried to read() past the EOF, then emit end on the next tick.

	    if (nOrig !== n && state.ended) endReadable(this);
	  }

	  if (ret !== null) this.emit('data', ret);
	  return ret;
	};

	function onEofChunk(stream, state) {
	  debug('onEofChunk');
	  if (state.ended) return;

	  if (state.decoder) {
	    var chunk = state.decoder.end();

	    if (chunk && chunk.length) {
	      state.buffer.push(chunk);
	      state.length += state.objectMode ? 1 : chunk.length;
	    }
	  }

	  state.ended = true;

	  if (state.sync) {
	    // if we are sync, wait until next tick to emit the data.
	    // Otherwise we risk emitting data in the flow()
	    // the readable code triggers during a read() call
	    emitReadable(stream);
	  } else {
	    // emit 'readable' now to make sure it gets picked up.
	    state.needReadable = false;

	    if (!state.emittedReadable) {
	      state.emittedReadable = true;
	      emitReadable_(stream);
	    }
	  }
	} // Don't emit readable right away in sync mode, because this can trigger
	// another read() call => stack overflow.  This way, it might trigger
	// a nextTick recursion warning, but that's not so bad.


	function emitReadable(stream) {
	  var state = stream._readableState;
	  debug('emitReadable', state.needReadable, state.emittedReadable);
	  state.needReadable = false;

	  if (!state.emittedReadable) {
	    debug('emitReadable', state.flowing);
	    state.emittedReadable = true;
	    process.nextTick(emitReadable_, stream);
	  }
	}

	function emitReadable_(stream) {
	  var state = stream._readableState;
	  debug('emitReadable_', state.destroyed, state.length, state.ended);

	  if (!state.destroyed && (state.length || state.ended)) {
	    stream.emit('readable');
	    state.emittedReadable = false;
	  } // The stream needs another readable event if
	  // 1. It is not flowing, as the flow mechanism will take
	  //    care of it.
	  // 2. It is not ended.
	  // 3. It is below the highWaterMark, so we can schedule
	  //    another readable later.


	  state.needReadable = !state.flowing && !state.ended && state.length <= state.highWaterMark;
	  flow(stream);
	} // at this point, the user has presumably seen the 'readable' event,
	// and called read() to consume some data.  that may have triggered
	// in turn another _read(n) call, in which case reading = true if
	// it's in progress.
	// However, if we're not ended, or reading, and the length < hwm,
	// then go ahead and try to read some more preemptively.


	function maybeReadMore(stream, state) {
	  if (!state.readingMore) {
	    state.readingMore = true;
	    process.nextTick(maybeReadMore_, stream, state);
	  }
	}

	function maybeReadMore_(stream, state) {
	  // Attempt to read more data if we should.
	  //
	  // The conditions for reading more data are (one of):
	  // - Not enough data buffered (state.length < state.highWaterMark). The loop
	  //   is responsible for filling the buffer with enough data if such data
	  //   is available. If highWaterMark is 0 and we are not in the flowing mode
	  //   we should _not_ attempt to buffer any extra data. We'll get more data
	  //   when the stream consumer calls read() instead.
	  // - No data in the buffer, and the stream is in flowing mode. In this mode
	  //   the loop below is responsible for ensuring read() is called. Failing to
	  //   call read here would abort the flow and there's no other mechanism for
	  //   continuing the flow if the stream consumer has just subscribed to the
	  //   'data' event.
	  //
	  // In addition to the above conditions to keep reading data, the following
	  // conditions prevent the data from being read:
	  // - The stream has ended (state.ended).
	  // - There is already a pending 'read' operation (state.reading). This is a
	  //   case where the the stream has called the implementation defined _read()
	  //   method, but they are processing the call asynchronously and have _not_
	  //   called push() with new data. In this case we skip performing more
	  //   read()s. The execution ends in this method again after the _read() ends
	  //   up calling push() with more data.
	  while (!state.reading && !state.ended && (state.length < state.highWaterMark || state.flowing && state.length === 0)) {
	    var len = state.length;
	    debug('maybeReadMore read 0');
	    stream.read(0);
	    if (len === state.length) // didn't get any data, stop spinning.
	      break;
	  }

	  state.readingMore = false;
	} // abstract method.  to be overridden in specific implementation classes.
	// call cb(er, data) where data is <= n in length.
	// for virtual (non-string, non-buffer) streams, "length" is somewhat
	// arbitrary, and perhaps not very meaningful.


	Readable.prototype._read = function (n) {
	  errorOrDestroy(this, new ERR_METHOD_NOT_IMPLEMENTED('_read()'));
	};

	Readable.prototype.pipe = function (dest, pipeOpts) {
	  var src = this;
	  var state = this._readableState;

	  switch (state.pipesCount) {
	    case 0:
	      state.pipes = dest;
	      break;

	    case 1:
	      state.pipes = [state.pipes, dest];
	      break;

	    default:
	      state.pipes.push(dest);
	      break;
	  }

	  state.pipesCount += 1;
	  debug('pipe count=%d opts=%j', state.pipesCount, pipeOpts);
	  var doEnd = (!pipeOpts || pipeOpts.end !== false) && dest !== process.stdout && dest !== process.stderr;
	  var endFn = doEnd ? onend : unpipe;
	  if (state.endEmitted) process.nextTick(endFn);else src.once('end', endFn);
	  dest.on('unpipe', onunpipe);

	  function onunpipe(readable, unpipeInfo) {
	    debug('onunpipe');

	    if (readable === src) {
	      if (unpipeInfo && unpipeInfo.hasUnpiped === false) {
	        unpipeInfo.hasUnpiped = true;
	        cleanup();
	      }
	    }
	  }

	  function onend() {
	    debug('onend');
	    dest.end();
	  } // when the dest drains, it reduces the awaitDrain counter
	  // on the source.  This would be more elegant with a .once()
	  // handler in flow(), but adding and removing repeatedly is
	  // too slow.


	  var ondrain = pipeOnDrain(src);
	  dest.on('drain', ondrain);
	  var cleanedUp = false;

	  function cleanup() {
	    debug('cleanup'); // cleanup event handlers once the pipe is broken

	    dest.removeListener('close', onclose);
	    dest.removeListener('finish', onfinish);
	    dest.removeListener('drain', ondrain);
	    dest.removeListener('error', onerror);
	    dest.removeListener('unpipe', onunpipe);
	    src.removeListener('end', onend);
	    src.removeListener('end', unpipe);
	    src.removeListener('data', ondata);
	    cleanedUp = true; // if the reader is waiting for a drain event from this
	    // specific writer, then it would cause it to never start
	    // flowing again.
	    // So, if this is awaiting a drain, then we just call it now.
	    // If we don't know, then assume that we are waiting for one.

	    if (state.awaitDrain && (!dest._writableState || dest._writableState.needDrain)) ondrain();
	  }

	  src.on('data', ondata);

	  function ondata(chunk) {
	    debug('ondata');
	    var ret = dest.write(chunk);
	    debug('dest.write', ret);

	    if (ret === false) {
	      // If the user unpiped during `dest.write()`, it is possible
	      // to get stuck in a permanently paused state if that write
	      // also returned false.
	      // => Check whether `dest` is still a piping destination.
	      if ((state.pipesCount === 1 && state.pipes === dest || state.pipesCount > 1 && indexOf(state.pipes, dest) !== -1) && !cleanedUp) {
	        debug('false write response, pause', state.awaitDrain);
	        state.awaitDrain++;
	      }

	      src.pause();
	    }
	  } // if the dest has an error, then stop piping into it.
	  // however, don't suppress the throwing behavior for this.


	  function onerror(er) {
	    debug('onerror', er);
	    unpipe();
	    dest.removeListener('error', onerror);
	    if (EElistenerCount(dest, 'error') === 0) errorOrDestroy(dest, er);
	  } // Make sure our error handler is attached before userland ones.


	  prependListener(dest, 'error', onerror); // Both close and finish should trigger unpipe, but only once.

	  function onclose() {
	    dest.removeListener('finish', onfinish);
	    unpipe();
	  }

	  dest.once('close', onclose);

	  function onfinish() {
	    debug('onfinish');
	    dest.removeListener('close', onclose);
	    unpipe();
	  }

	  dest.once('finish', onfinish);

	  function unpipe() {
	    debug('unpipe');
	    src.unpipe(dest);
	  } // tell the dest that it's being piped to


	  dest.emit('pipe', src); // start the flow if it hasn't been started already.

	  if (!state.flowing) {
	    debug('pipe resume');
	    src.resume();
	  }

	  return dest;
	};

	function pipeOnDrain(src) {
	  return function pipeOnDrainFunctionResult() {
	    var state = src._readableState;
	    debug('pipeOnDrain', state.awaitDrain);
	    if (state.awaitDrain) state.awaitDrain--;

	    if (state.awaitDrain === 0 && EElistenerCount(src, 'data')) {
	      state.flowing = true;
	      flow(src);
	    }
	  };
	}

	Readable.prototype.unpipe = function (dest) {
	  var state = this._readableState;
	  var unpipeInfo = {
	    hasUnpiped: false
	  }; // if we're not piping anywhere, then do nothing.

	  if (state.pipesCount === 0) return this; // just one destination.  most common case.

	  if (state.pipesCount === 1) {
	    // passed in one, but it's not the right one.
	    if (dest && dest !== state.pipes) return this;
	    if (!dest) dest = state.pipes; // got a match.

	    state.pipes = null;
	    state.pipesCount = 0;
	    state.flowing = false;
	    if (dest) dest.emit('unpipe', this, unpipeInfo);
	    return this;
	  } // slow case. multiple pipe destinations.


	  if (!dest) {
	    // remove all.
	    var dests = state.pipes;
	    var len = state.pipesCount;
	    state.pipes = null;
	    state.pipesCount = 0;
	    state.flowing = false;

	    for (var i = 0; i < len; i++) {
	      dests[i].emit('unpipe', this, {
	        hasUnpiped: false
	      });
	    }

	    return this;
	  } // try to find the right one.


	  var index = indexOf(state.pipes, dest);
	  if (index === -1) return this;
	  state.pipes.splice(index, 1);
	  state.pipesCount -= 1;
	  if (state.pipesCount === 1) state.pipes = state.pipes[0];
	  dest.emit('unpipe', this, unpipeInfo);
	  return this;
	}; // set up data events if they are asked for
	// Ensure readable listeners eventually get something


	Readable.prototype.on = function (ev, fn) {
	  var res = Stream.prototype.on.call(this, ev, fn);
	  var state = this._readableState;

	  if (ev === 'data') {
	    // update readableListening so that resume() may be a no-op
	    // a few lines down. This is needed to support once('readable').
	    state.readableListening = this.listenerCount('readable') > 0; // Try start flowing on next tick if stream isn't explicitly paused

	    if (state.flowing !== false) this.resume();
	  } else if (ev === 'readable') {
	    if (!state.endEmitted && !state.readableListening) {
	      state.readableListening = state.needReadable = true;
	      state.flowing = false;
	      state.emittedReadable = false;
	      debug('on readable', state.length, state.reading);

	      if (state.length) {
	        emitReadable(this);
	      } else if (!state.reading) {
	        process.nextTick(nReadingNextTick, this);
	      }
	    }
	  }

	  return res;
	};

	Readable.prototype.addListener = Readable.prototype.on;

	Readable.prototype.removeListener = function (ev, fn) {
	  var res = Stream.prototype.removeListener.call(this, ev, fn);

	  if (ev === 'readable') {
	    // We need to check if there is someone still listening to
	    // readable and reset the state. However this needs to happen
	    // after readable has been emitted but before I/O (nextTick) to
	    // support once('readable', fn) cycles. This means that calling
	    // resume within the same tick will have no
	    // effect.
	    process.nextTick(updateReadableListening, this);
	  }

	  return res;
	};

	Readable.prototype.removeAllListeners = function (ev) {
	  var res = Stream.prototype.removeAllListeners.apply(this, arguments);

	  if (ev === 'readable' || ev === undefined) {
	    // We need to check if there is someone still listening to
	    // readable and reset the state. However this needs to happen
	    // after readable has been emitted but before I/O (nextTick) to
	    // support once('readable', fn) cycles. This means that calling
	    // resume within the same tick will have no
	    // effect.
	    process.nextTick(updateReadableListening, this);
	  }

	  return res;
	};

	function updateReadableListening(self) {
	  var state = self._readableState;
	  state.readableListening = self.listenerCount('readable') > 0;

	  if (state.resumeScheduled && !state.paused) {
	    // flowing needs to be set to true now, otherwise
	    // the upcoming resume will not flow.
	    state.flowing = true; // crude way to check if we should resume
	  } else if (self.listenerCount('data') > 0) {
	    self.resume();
	  }
	}

	function nReadingNextTick(self) {
	  debug('readable nexttick read 0');
	  self.read(0);
	} // pause() and resume() are remnants of the legacy readable stream API
	// If the user uses them, then switch into old mode.


	Readable.prototype.resume = function () {
	  var state = this._readableState;

	  if (!state.flowing) {
	    debug('resume'); // we flow only if there is no one listening
	    // for readable, but we still have to call
	    // resume()

	    state.flowing = !state.readableListening;
	    resume(this, state);
	  }

	  state.paused = false;
	  return this;
	};

	function resume(stream, state) {
	  if (!state.resumeScheduled) {
	    state.resumeScheduled = true;
	    process.nextTick(resume_, stream, state);
	  }
	}

	function resume_(stream, state) {
	  debug('resume', state.reading);

	  if (!state.reading) {
	    stream.read(0);
	  }

	  state.resumeScheduled = false;
	  stream.emit('resume');
	  flow(stream);
	  if (state.flowing && !state.reading) stream.read(0);
	}

	Readable.prototype.pause = function () {
	  debug('call pause flowing=%j', this._readableState.flowing);

	  if (this._readableState.flowing !== false) {
	    debug('pause');
	    this._readableState.flowing = false;
	    this.emit('pause');
	  }

	  this._readableState.paused = true;
	  return this;
	};

	function flow(stream) {
	  var state = stream._readableState;
	  debug('flow', state.flowing);

	  while (state.flowing && stream.read() !== null) {
	  }
	} // wrap an old-style stream as the async data source.
	// This is *not* part of the readable stream interface.
	// It is an ugly unfortunate mess of history.


	Readable.prototype.wrap = function (stream) {
	  var _this = this;

	  var state = this._readableState;
	  var paused = false;
	  stream.on('end', function () {
	    debug('wrapped end');

	    if (state.decoder && !state.ended) {
	      var chunk = state.decoder.end();
	      if (chunk && chunk.length) _this.push(chunk);
	    }

	    _this.push(null);
	  });
	  stream.on('data', function (chunk) {
	    debug('wrapped data');
	    if (state.decoder) chunk = state.decoder.write(chunk); // don't skip over falsy values in objectMode

	    if (state.objectMode && (chunk === null || chunk === undefined)) return;else if (!state.objectMode && (!chunk || !chunk.length)) return;

	    var ret = _this.push(chunk);

	    if (!ret) {
	      paused = true;
	      stream.pause();
	    }
	  }); // proxy all the other methods.
	  // important when wrapping filters and duplexes.

	  for (var i in stream) {
	    if (this[i] === undefined && typeof stream[i] === 'function') {
	      this[i] = function methodWrap(method) {
	        return function methodWrapReturnFunction() {
	          return stream[method].apply(stream, arguments);
	        };
	      }(i);
	    }
	  } // proxy certain important events.


	  for (var n = 0; n < kProxyEvents.length; n++) {
	    stream.on(kProxyEvents[n], this.emit.bind(this, kProxyEvents[n]));
	  } // when we try to consume some more bytes, simply unpause the
	  // underlying stream.


	  this._read = function (n) {
	    debug('wrapped _read', n);

	    if (paused) {
	      paused = false;
	      stream.resume();
	    }
	  };

	  return this;
	};

	if (typeof Symbol === 'function') {
	  Readable.prototype[Symbol.asyncIterator] = function () {
	    if (createReadableStreamAsyncIterator === undefined) {
	      createReadableStreamAsyncIterator = requireAsync_iterator();
	    }

	    return createReadableStreamAsyncIterator(this);
	  };
	}

	Object.defineProperty(Readable.prototype, 'readableHighWaterMark', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    return this._readableState.highWaterMark;
	  }
	});
	Object.defineProperty(Readable.prototype, 'readableBuffer', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    return this._readableState && this._readableState.buffer;
	  }
	});
	Object.defineProperty(Readable.prototype, 'readableFlowing', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    return this._readableState.flowing;
	  },
	  set: function set(state) {
	    if (this._readableState) {
	      this._readableState.flowing = state;
	    }
	  }
	}); // exposed for testing purposes only.

	Readable._fromList = fromList;
	Object.defineProperty(Readable.prototype, 'readableLength', {
	  // making it explicit this property is not enumerable
	  // because otherwise some prototype manipulation in
	  // userland will fail
	  enumerable: false,
	  get: function get() {
	    return this._readableState.length;
	  }
	}); // Pluck off n bytes from an array of buffers.
	// Length is the combined lengths of all the buffers in the list.
	// This function is designed to be inlinable, so please take care when making
	// changes to the function body.

	function fromList(n, state) {
	  // nothing buffered
	  if (state.length === 0) return null;
	  var ret;
	  if (state.objectMode) ret = state.buffer.shift();else if (!n || n >= state.length) {
	    // read it all, truncate the list
	    if (state.decoder) ret = state.buffer.join('');else if (state.buffer.length === 1) ret = state.buffer.first();else ret = state.buffer.concat(state.length);
	    state.buffer.clear();
	  } else {
	    // read part of list
	    ret = state.buffer.consume(n, state.decoder);
	  }
	  return ret;
	}

	function endReadable(stream) {
	  var state = stream._readableState;
	  debug('endReadable', state.endEmitted);

	  if (!state.endEmitted) {
	    state.ended = true;
	    process.nextTick(endReadableNT, state, stream);
	  }
	}

	function endReadableNT(state, stream) {
	  debug('endReadableNT', state.endEmitted, state.length); // Check that we didn't get one last unshift.

	  if (!state.endEmitted && state.length === 0) {
	    state.endEmitted = true;
	    stream.readable = false;
	    stream.emit('end');

	    if (state.autoDestroy) {
	      // In case of duplex streams we need a way to detect
	      // if the writable side is ready for autoDestroy as well
	      var wState = stream._writableState;

	      if (!wState || wState.autoDestroy && wState.finished) {
	        stream.destroy();
	      }
	    }
	  }
	}

	if (typeof Symbol === 'function') {
	  Readable.from = function (iterable, opts) {
	    if (from === undefined) {
	      from = requireFromBrowser();
	    }

	    return from(Readable, iterable, opts);
	  };
	}

	function indexOf(xs, x) {
	  for (var i = 0, l = xs.length; i < l; i++) {
	    if (xs[i] === x) return i;
	  }

	  return -1;
	}
	return _stream_readable;
}

var _stream_transform = Transform$1;

var _require$codes$1 = errorsBrowser.codes,
    ERR_METHOD_NOT_IMPLEMENTED = _require$codes$1.ERR_METHOD_NOT_IMPLEMENTED,
    ERR_MULTIPLE_CALLBACK = _require$codes$1.ERR_MULTIPLE_CALLBACK,
    ERR_TRANSFORM_ALREADY_TRANSFORMING = _require$codes$1.ERR_TRANSFORM_ALREADY_TRANSFORMING,
    ERR_TRANSFORM_WITH_LENGTH_0 = _require$codes$1.ERR_TRANSFORM_WITH_LENGTH_0;

var Duplex = require_stream_duplex();

inherits_browser.exports(Transform$1, Duplex);

function afterTransform(er, data) {
  var ts = this._transformState;
  ts.transforming = false;
  var cb = ts.writecb;

  if (cb === null) {
    return this.emit('error', new ERR_MULTIPLE_CALLBACK());
  }

  ts.writechunk = null;
  ts.writecb = null;
  if (data != null) // single equals check for both `null` and `undefined`
    this.push(data);
  cb(er);
  var rs = this._readableState;
  rs.reading = false;

  if (rs.needReadable || rs.length < rs.highWaterMark) {
    this._read(rs.highWaterMark);
  }
}

function Transform$1(options) {
  if (!(this instanceof Transform$1)) return new Transform$1(options);
  Duplex.call(this, options);
  this._transformState = {
    afterTransform: afterTransform.bind(this),
    needTransform: false,
    transforming: false,
    writecb: null,
    writechunk: null,
    writeencoding: null
  }; // start out asking for a readable event once data is transformed.

  this._readableState.needReadable = true; // we have implemented the _read method, and done the other things
  // that Readable wants before the first _read call, so unset the
  // sync guard flag.

  this._readableState.sync = false;

  if (options) {
    if (typeof options.transform === 'function') this._transform = options.transform;
    if (typeof options.flush === 'function') this._flush = options.flush;
  } // When the writable side finishes, then flush out anything remaining.


  this.on('prefinish', prefinish);
}

function prefinish() {
  var _this = this;

  if (typeof this._flush === 'function' && !this._readableState.destroyed) {
    this._flush(function (er, data) {
      done(_this, er, data);
    });
  } else {
    done(this, null, null);
  }
}

Transform$1.prototype.push = function (chunk, encoding) {
  this._transformState.needTransform = false;
  return Duplex.prototype.push.call(this, chunk, encoding);
}; // This is the part where you do stuff!
// override this function in implementation classes.
// 'chunk' is an input chunk.
//
// Call `push(newChunk)` to pass along transformed output
// to the readable side.  You may call 'push' zero or more times.
//
// Call `cb(err)` when you are done with this chunk.  If you pass
// an error, then that'll put the hurt on the whole operation.  If you
// never call cb(), then you'll never get another chunk.


Transform$1.prototype._transform = function (chunk, encoding, cb) {
  cb(new ERR_METHOD_NOT_IMPLEMENTED('_transform()'));
};

Transform$1.prototype._write = function (chunk, encoding, cb) {
  var ts = this._transformState;
  ts.writecb = cb;
  ts.writechunk = chunk;
  ts.writeencoding = encoding;

  if (!ts.transforming) {
    var rs = this._readableState;
    if (ts.needTransform || rs.needReadable || rs.length < rs.highWaterMark) this._read(rs.highWaterMark);
  }
}; // Doesn't matter what the args are here.
// _transform does all the work.
// That we got here means that the readable side wants more data.


Transform$1.prototype._read = function (n) {
  var ts = this._transformState;

  if (ts.writechunk !== null && !ts.transforming) {
    ts.transforming = true;

    this._transform(ts.writechunk, ts.writeencoding, ts.afterTransform);
  } else {
    // mark that we need a transform, so that any data that comes in
    // will get processed, now that we've asked for it.
    ts.needTransform = true;
  }
};

Transform$1.prototype._destroy = function (err, cb) {
  Duplex.prototype._destroy.call(this, err, function (err2) {
    cb(err2);
  });
};

function done(stream, er, data) {
  if (er) return stream.emit('error', er);
  if (data != null) // single equals check for both `null` and `undefined`
    stream.push(data); // TODO(BridgeAR): Write a test for these two error cases
  // if there's nothing in the write buffer, then that means
  // that nothing more will ever be provided

  if (stream._writableState.length) throw new ERR_TRANSFORM_WITH_LENGTH_0();
  if (stream._transformState.transforming) throw new ERR_TRANSFORM_ALREADY_TRANSFORMING();
  return stream.push(null);
}

var _stream_passthrough = PassThrough;

var Transform = _stream_transform;

inherits_browser.exports(PassThrough, Transform);

function PassThrough(options) {
  if (!(this instanceof PassThrough)) return new PassThrough(options);
  Transform.call(this, options);
}

PassThrough.prototype._transform = function (chunk, encoding, cb) {
  cb(null, chunk);
};

var eos;

function once$2(callback) {
  var called = false;
  return function () {
    if (called) return;
    called = true;
    callback.apply(void 0, arguments);
  };
}

var _require$codes = errorsBrowser.codes,
    ERR_MISSING_ARGS = _require$codes.ERR_MISSING_ARGS,
    ERR_STREAM_DESTROYED = _require$codes.ERR_STREAM_DESTROYED;

function noop$1(err) {
  // Rethrow the error if it exists to avoid swallowing it
  if (err) throw err;
}

function isRequest(stream) {
  return stream.setHeader && typeof stream.abort === 'function';
}

function destroyer(stream, reading, writing, callback) {
  callback = once$2(callback);
  var closed = false;
  stream.on('close', function () {
    closed = true;
  });
  if (eos === undefined) eos = endOfStream;
  eos(stream, {
    readable: reading,
    writable: writing
  }, function (err) {
    if (err) return callback(err);
    closed = true;
    callback();
  });
  var destroyed = false;
  return function (err) {
    if (closed) return;
    if (destroyed) return;
    destroyed = true; // request.destroy just do .end - .abort is what we want

    if (isRequest(stream)) return stream.abort();
    if (typeof stream.destroy === 'function') return stream.destroy();
    callback(err || new ERR_STREAM_DESTROYED('pipe'));
  };
}

function call(fn) {
  fn();
}

function pipe(from, to) {
  return from.pipe(to);
}

function popCallback(streams) {
  if (!streams.length) return noop$1;
  if (typeof streams[streams.length - 1] !== 'function') return noop$1;
  return streams.pop();
}

function pipeline() {
  for (var _len = arguments.length, streams = new Array(_len), _key = 0; _key < _len; _key++) {
    streams[_key] = arguments[_key];
  }

  var callback = popCallback(streams);
  if (Array.isArray(streams[0])) streams = streams[0];

  if (streams.length < 2) {
    throw new ERR_MISSING_ARGS('streams');
  }

  var error;
  var destroys = streams.map(function (stream, i) {
    var reading = i < streams.length - 1;
    var writing = i > 0;
    return destroyer(stream, reading, writing, function (err) {
      if (!error) error = err;
      if (err) destroys.forEach(call);
      if (reading) return;
      destroys.forEach(call);
      callback(error);
    });
  });
  return streams.reduce(pipe);
}

var pipeline_1 = pipeline;

(function (module, exports) {
	exports = module.exports = require_stream_readable();
	exports.Stream = exports;
	exports.Readable = exports;
	exports.Writable = require_stream_writable();
	exports.Duplex = require_stream_duplex();
	exports.Transform = _stream_transform;
	exports.PassThrough = _stream_passthrough;
	exports.finished = endOfStream;
	exports.pipeline = pipeline_1;
} (readableBrowser, readableBrowser.exports));

var typedarray = {};

var hasRequiredTypedarray;

function requireTypedarray () {
	if (hasRequiredTypedarray) return typedarray;
	hasRequiredTypedarray = 1;
	(function (exports) {
		var undefined$1 = (void 0); // Paranoia

		// Beyond this value, index getters/setters (i.e. array[0], array[1]) are so slow to
		// create, and consume so much memory, that the browser appears frozen.
		var MAX_ARRAY_LENGTH = 1e5;

		// Approximations of internal ECMAScript conversion functions
		var ECMAScript = (function() {
		  // Stash a copy in case other scripts modify these
		  var opts = Object.prototype.toString,
		      ophop = Object.prototype.hasOwnProperty;

		  return {
		    // Class returns internal [[Class]] property, used to avoid cross-frame instanceof issues:
		    Class: function(v) { return opts.call(v).replace(/^\[object *|\]$/g, ''); },
		    HasProperty: function(o, p) { return p in o; },
		    HasOwnProperty: function(o, p) { return ophop.call(o, p); },
		    IsCallable: function(o) { return typeof o === 'function'; },
		    ToInt32: function(v) { return v >> 0; },
		    ToUint32: function(v) { return v >>> 0; }
		  };
		}());

		// Snapshot intrinsics
		var LN2 = Math.LN2,
		    abs = Math.abs,
		    floor = Math.floor,
		    log = Math.log,
		    min = Math.min,
		    pow = Math.pow,
		    round = Math.round;

		// ES5: lock down object properties
		function configureProperties(obj) {
		  if (getOwnPropNames && defineProp) {
		    var props = getOwnPropNames(obj), i;
		    for (i = 0; i < props.length; i += 1) {
		      defineProp(obj, props[i], {
		        value: obj[props[i]],
		        writable: false,
		        enumerable: false,
		        configurable: false
		      });
		    }
		  }
		}

		// emulate ES5 getter/setter API using legacy APIs
		// http://blogs.msdn.com/b/ie/archive/2010/09/07/transitioning-existing-code-to-the-es5-getter-setter-apis.aspx
		// (second clause tests for Object.defineProperty() in IE<9 that only supports extending DOM prototypes, but
		// note that IE<9 does not support __defineGetter__ or __defineSetter__ so it just renders the method harmless)
		var defineProp;
		if (Object.defineProperty && (function() {
		      try {
		        Object.defineProperty({}, 'x', {});
		        return true;
		      } catch (e) {
		        return false;
		      }
		    })()) {
		  defineProp = Object.defineProperty;
		} else {
		  defineProp = function(o, p, desc) {
		    if (!o === Object(o)) throw new TypeError("Object.defineProperty called on non-object");
		    if (ECMAScript.HasProperty(desc, 'get') && Object.prototype.__defineGetter__) { Object.prototype.__defineGetter__.call(o, p, desc.get); }
		    if (ECMAScript.HasProperty(desc, 'set') && Object.prototype.__defineSetter__) { Object.prototype.__defineSetter__.call(o, p, desc.set); }
		    if (ECMAScript.HasProperty(desc, 'value')) { o[p] = desc.value; }
		    return o;
		  };
		}

		var getOwnPropNames = Object.getOwnPropertyNames || function (o) {
		  if (o !== Object(o)) throw new TypeError("Object.getOwnPropertyNames called on non-object");
		  var props = [], p;
		  for (p in o) {
		    if (ECMAScript.HasOwnProperty(o, p)) {
		      props.push(p);
		    }
		  }
		  return props;
		};

		// ES5: Make obj[index] an alias for obj._getter(index)/obj._setter(index, value)
		// for index in 0 ... obj.length
		function makeArrayAccessors(obj) {
		  if (!defineProp) { return; }

		  if (obj.length > MAX_ARRAY_LENGTH) throw new RangeError("Array too large for polyfill");

		  function makeArrayAccessor(index) {
		    defineProp(obj, index, {
		      'get': function() { return obj._getter(index); },
		      'set': function(v) { obj._setter(index, v); },
		      enumerable: true,
		      configurable: false
		    });
		  }

		  var i;
		  for (i = 0; i < obj.length; i += 1) {
		    makeArrayAccessor(i);
		  }
		}

		// Internal conversion functions:
		//    pack<Type>()   - take a number (interpreted as Type), output a byte array
		//    unpack<Type>() - take a byte array, output a Type-like number

		function as_signed(value, bits) { var s = 32 - bits; return (value << s) >> s; }
		function as_unsigned(value, bits) { var s = 32 - bits; return (value << s) >>> s; }

		function packI8(n) { return [n & 0xff]; }
		function unpackI8(bytes) { return as_signed(bytes[0], 8); }

		function packU8(n) { return [n & 0xff]; }
		function unpackU8(bytes) { return as_unsigned(bytes[0], 8); }

		function packU8Clamped(n) { n = round(Number(n)); return [n < 0 ? 0 : n > 0xff ? 0xff : n & 0xff]; }

		function packI16(n) { return [(n >> 8) & 0xff, n & 0xff]; }
		function unpackI16(bytes) { return as_signed(bytes[0] << 8 | bytes[1], 16); }

		function packU16(n) { return [(n >> 8) & 0xff, n & 0xff]; }
		function unpackU16(bytes) { return as_unsigned(bytes[0] << 8 | bytes[1], 16); }

		function packI32(n) { return [(n >> 24) & 0xff, (n >> 16) & 0xff, (n >> 8) & 0xff, n & 0xff]; }
		function unpackI32(bytes) { return as_signed(bytes[0] << 24 | bytes[1] << 16 | bytes[2] << 8 | bytes[3], 32); }

		function packU32(n) { return [(n >> 24) & 0xff, (n >> 16) & 0xff, (n >> 8) & 0xff, n & 0xff]; }
		function unpackU32(bytes) { return as_unsigned(bytes[0] << 24 | bytes[1] << 16 | bytes[2] << 8 | bytes[3], 32); }

		function packIEEE754(v, ebits, fbits) {

		  var bias = (1 << (ebits - 1)) - 1,
		      s, e, f, i, bits, str, bytes;

		  function roundToEven(n) {
		    var w = floor(n), f = n - w;
		    if (f < 0.5)
		      return w;
		    if (f > 0.5)
		      return w + 1;
		    return w % 2 ? w + 1 : w;
		  }

		  // Compute sign, exponent, fraction
		  if (v !== v) {
		    // NaN
		    // http://dev.w3.org/2006/webapi/WebIDL/#es-type-mapping
		    e = (1 << ebits) - 1; f = pow(2, fbits - 1); s = 0;
		  } else if (v === Infinity || v === -Infinity) {
		    e = (1 << ebits) - 1; f = 0; s = (v < 0) ? 1 : 0;
		  } else if (v === 0) {
		    e = 0; f = 0; s = (1 / v === -Infinity) ? 1 : 0;
		  } else {
		    s = v < 0;
		    v = abs(v);

		    if (v >= pow(2, 1 - bias)) {
		      e = min(floor(log(v) / LN2), 1023);
		      f = roundToEven(v / pow(2, e) * pow(2, fbits));
		      if (f / pow(2, fbits) >= 2) {
		        e = e + 1;
		        f = 1;
		      }
		      if (e > bias) {
		        // Overflow
		        e = (1 << ebits) - 1;
		        f = 0;
		      } else {
		        // Normalized
		        e = e + bias;
		        f = f - pow(2, fbits);
		      }
		    } else {
		      // Denormalized
		      e = 0;
		      f = roundToEven(v / pow(2, 1 - bias - fbits));
		    }
		  }

		  // Pack sign, exponent, fraction
		  bits = [];
		  for (i = fbits; i; i -= 1) { bits.push(f % 2 ? 1 : 0); f = floor(f / 2); }
		  for (i = ebits; i; i -= 1) { bits.push(e % 2 ? 1 : 0); e = floor(e / 2); }
		  bits.push(s ? 1 : 0);
		  bits.reverse();
		  str = bits.join('');

		  // Bits to bytes
		  bytes = [];
		  while (str.length) {
		    bytes.push(parseInt(str.substring(0, 8), 2));
		    str = str.substring(8);
		  }
		  return bytes;
		}

		function unpackIEEE754(bytes, ebits, fbits) {

		  // Bytes to bits
		  var bits = [], i, j, b, str,
		      bias, s, e, f;

		  for (i = bytes.length; i; i -= 1) {
		    b = bytes[i - 1];
		    for (j = 8; j; j -= 1) {
		      bits.push(b % 2 ? 1 : 0); b = b >> 1;
		    }
		  }
		  bits.reverse();
		  str = bits.join('');

		  // Unpack sign, exponent, fraction
		  bias = (1 << (ebits - 1)) - 1;
		  s = parseInt(str.substring(0, 1), 2) ? -1 : 1;
		  e = parseInt(str.substring(1, 1 + ebits), 2);
		  f = parseInt(str.substring(1 + ebits), 2);

		  // Produce number
		  if (e === (1 << ebits) - 1) {
		    return f !== 0 ? NaN : s * Infinity;
		  } else if (e > 0) {
		    // Normalized
		    return s * pow(2, e - bias) * (1 + f / pow(2, fbits));
		  } else if (f !== 0) {
		    // Denormalized
		    return s * pow(2, -(bias - 1)) * (f / pow(2, fbits));
		  } else {
		    return s < 0 ? -0 : 0;
		  }
		}

		function unpackF64(b) { return unpackIEEE754(b, 11, 52); }
		function packF64(v) { return packIEEE754(v, 11, 52); }
		function unpackF32(b) { return unpackIEEE754(b, 8, 23); }
		function packF32(v) { return packIEEE754(v, 8, 23); }


		//
		// 3 The ArrayBuffer Type
		//

		(function() {

		  /** @constructor */
		  var ArrayBuffer = function ArrayBuffer(length) {
		    length = ECMAScript.ToInt32(length);
		    if (length < 0) throw new RangeError('ArrayBuffer size is not a small enough positive integer');

		    this.byteLength = length;
		    this._bytes = [];
		    this._bytes.length = length;

		    var i;
		    for (i = 0; i < this.byteLength; i += 1) {
		      this._bytes[i] = 0;
		    }

		    configureProperties(this);
		  };

		  exports.ArrayBuffer = exports.ArrayBuffer || ArrayBuffer;

		  //
		  // 4 The ArrayBufferView Type
		  //

		  // NOTE: this constructor is not exported
		  /** @constructor */
		  var ArrayBufferView = function ArrayBufferView() {
		    //this.buffer = null;
		    //this.byteOffset = 0;
		    //this.byteLength = 0;
		  };

		  //
		  // 5 The Typed Array View Types
		  //

		  function makeConstructor(bytesPerElement, pack, unpack) {
		    // Each TypedArray type requires a distinct constructor instance with
		    // identical logic, which this produces.

		    var ctor;
		    ctor = function(buffer, byteOffset, length) {
		      var array, sequence, i, s;

		      if (!arguments.length || typeof arguments[0] === 'number') {
		        // Constructor(unsigned long length)
		        this.length = ECMAScript.ToInt32(arguments[0]);
		        if (length < 0) throw new RangeError('ArrayBufferView size is not a small enough positive integer');

		        this.byteLength = this.length * this.BYTES_PER_ELEMENT;
		        this.buffer = new ArrayBuffer(this.byteLength);
		        this.byteOffset = 0;
		      } else if (typeof arguments[0] === 'object' && arguments[0].constructor === ctor) {
		        // Constructor(TypedArray array)
		        array = arguments[0];

		        this.length = array.length;
		        this.byteLength = this.length * this.BYTES_PER_ELEMENT;
		        this.buffer = new ArrayBuffer(this.byteLength);
		        this.byteOffset = 0;

		        for (i = 0; i < this.length; i += 1) {
		          this._setter(i, array._getter(i));
		        }
		      } else if (typeof arguments[0] === 'object' &&
		                 !(arguments[0] instanceof ArrayBuffer || ECMAScript.Class(arguments[0]) === 'ArrayBuffer')) {
		        // Constructor(sequence<type> array)
		        sequence = arguments[0];

		        this.length = ECMAScript.ToUint32(sequence.length);
		        this.byteLength = this.length * this.BYTES_PER_ELEMENT;
		        this.buffer = new ArrayBuffer(this.byteLength);
		        this.byteOffset = 0;

		        for (i = 0; i < this.length; i += 1) {
		          s = sequence[i];
		          this._setter(i, Number(s));
		        }
		      } else if (typeof arguments[0] === 'object' &&
		                 (arguments[0] instanceof ArrayBuffer || ECMAScript.Class(arguments[0]) === 'ArrayBuffer')) {
		        // Constructor(ArrayBuffer buffer,
		        //             optional unsigned long byteOffset, optional unsigned long length)
		        this.buffer = buffer;

		        this.byteOffset = ECMAScript.ToUint32(byteOffset);
		        if (this.byteOffset > this.buffer.byteLength) {
		          throw new RangeError("byteOffset out of range");
		        }

		        if (this.byteOffset % this.BYTES_PER_ELEMENT) {
		          // The given byteOffset must be a multiple of the element
		          // size of the specific type, otherwise an exception is raised.
		          throw new RangeError("ArrayBuffer length minus the byteOffset is not a multiple of the element size.");
		        }

		        if (arguments.length < 3) {
		          this.byteLength = this.buffer.byteLength - this.byteOffset;

		          if (this.byteLength % this.BYTES_PER_ELEMENT) {
		            throw new RangeError("length of buffer minus byteOffset not a multiple of the element size");
		          }
		          this.length = this.byteLength / this.BYTES_PER_ELEMENT;
		        } else {
		          this.length = ECMAScript.ToUint32(length);
		          this.byteLength = this.length * this.BYTES_PER_ELEMENT;
		        }

		        if ((this.byteOffset + this.byteLength) > this.buffer.byteLength) {
		          throw new RangeError("byteOffset and length reference an area beyond the end of the buffer");
		        }
		      } else {
		        throw new TypeError("Unexpected argument type(s)");
		      }

		      this.constructor = ctor;

		      configureProperties(this);
		      makeArrayAccessors(this);
		    };

		    ctor.prototype = new ArrayBufferView();
		    ctor.prototype.BYTES_PER_ELEMENT = bytesPerElement;
		    ctor.prototype._pack = pack;
		    ctor.prototype._unpack = unpack;
		    ctor.BYTES_PER_ELEMENT = bytesPerElement;

		    // getter type (unsigned long index);
		    ctor.prototype._getter = function(index) {
		      if (arguments.length < 1) throw new SyntaxError("Not enough arguments");

		      index = ECMAScript.ToUint32(index);
		      if (index >= this.length) {
		        return undefined$1;
		      }

		      var bytes = [], i, o;
		      for (i = 0, o = this.byteOffset + index * this.BYTES_PER_ELEMENT;
		           i < this.BYTES_PER_ELEMENT;
		           i += 1, o += 1) {
		        bytes.push(this.buffer._bytes[o]);
		      }
		      return this._unpack(bytes);
		    };

		    // NONSTANDARD: convenience alias for getter: type get(unsigned long index);
		    ctor.prototype.get = ctor.prototype._getter;

		    // setter void (unsigned long index, type value);
		    ctor.prototype._setter = function(index, value) {
		      if (arguments.length < 2) throw new SyntaxError("Not enough arguments");

		      index = ECMAScript.ToUint32(index);
		      if (index >= this.length) {
		        return undefined$1;
		      }

		      var bytes = this._pack(value), i, o;
		      for (i = 0, o = this.byteOffset + index * this.BYTES_PER_ELEMENT;
		           i < this.BYTES_PER_ELEMENT;
		           i += 1, o += 1) {
		        this.buffer._bytes[o] = bytes[i];
		      }
		    };

		    // void set(TypedArray array, optional unsigned long offset);
		    // void set(sequence<type> array, optional unsigned long offset);
		    ctor.prototype.set = function(index, value) {
		      if (arguments.length < 1) throw new SyntaxError("Not enough arguments");
		      var array, sequence, offset, len,
		          i, s, d,
		          byteOffset, byteLength, tmp;

		      if (typeof arguments[0] === 'object' && arguments[0].constructor === this.constructor) {
		        // void set(TypedArray array, optional unsigned long offset);
		        array = arguments[0];
		        offset = ECMAScript.ToUint32(arguments[1]);

		        if (offset + array.length > this.length) {
		          throw new RangeError("Offset plus length of array is out of range");
		        }

		        byteOffset = this.byteOffset + offset * this.BYTES_PER_ELEMENT;
		        byteLength = array.length * this.BYTES_PER_ELEMENT;

		        if (array.buffer === this.buffer) {
		          tmp = [];
		          for (i = 0, s = array.byteOffset; i < byteLength; i += 1, s += 1) {
		            tmp[i] = array.buffer._bytes[s];
		          }
		          for (i = 0, d = byteOffset; i < byteLength; i += 1, d += 1) {
		            this.buffer._bytes[d] = tmp[i];
		          }
		        } else {
		          for (i = 0, s = array.byteOffset, d = byteOffset;
		               i < byteLength; i += 1, s += 1, d += 1) {
		            this.buffer._bytes[d] = array.buffer._bytes[s];
		          }
		        }
		      } else if (typeof arguments[0] === 'object' && typeof arguments[0].length !== 'undefined') {
		        // void set(sequence<type> array, optional unsigned long offset);
		        sequence = arguments[0];
		        len = ECMAScript.ToUint32(sequence.length);
		        offset = ECMAScript.ToUint32(arguments[1]);

		        if (offset + len > this.length) {
		          throw new RangeError("Offset plus length of array is out of range");
		        }

		        for (i = 0; i < len; i += 1) {
		          s = sequence[i];
		          this._setter(offset + i, Number(s));
		        }
		      } else {
		        throw new TypeError("Unexpected argument type(s)");
		      }
		    };

		    // TypedArray subarray(long begin, optional long end);
		    ctor.prototype.subarray = function(start, end) {
		      function clamp(v, min, max) { return v < min ? min : v > max ? max : v; }

		      start = ECMAScript.ToInt32(start);
		      end = ECMAScript.ToInt32(end);

		      if (arguments.length < 1) { start = 0; }
		      if (arguments.length < 2) { end = this.length; }

		      if (start < 0) { start = this.length + start; }
		      if (end < 0) { end = this.length + end; }

		      start = clamp(start, 0, this.length);
		      end = clamp(end, 0, this.length);

		      var len = end - start;
		      if (len < 0) {
		        len = 0;
		      }

		      return new this.constructor(
		        this.buffer, this.byteOffset + start * this.BYTES_PER_ELEMENT, len);
		    };

		    return ctor;
		  }

		  var Int8Array = makeConstructor(1, packI8, unpackI8);
		  var Uint8Array = makeConstructor(1, packU8, unpackU8);
		  var Uint8ClampedArray = makeConstructor(1, packU8Clamped, unpackU8);
		  var Int16Array = makeConstructor(2, packI16, unpackI16);
		  var Uint16Array = makeConstructor(2, packU16, unpackU16);
		  var Int32Array = makeConstructor(4, packI32, unpackI32);
		  var Uint32Array = makeConstructor(4, packU32, unpackU32);
		  var Float32Array = makeConstructor(4, packF32, unpackF32);
		  var Float64Array = makeConstructor(8, packF64, unpackF64);

		  exports.Int8Array = exports.Int8Array || Int8Array;
		  exports.Uint8Array = exports.Uint8Array || Uint8Array;
		  exports.Uint8ClampedArray = exports.Uint8ClampedArray || Uint8ClampedArray;
		  exports.Int16Array = exports.Int16Array || Int16Array;
		  exports.Uint16Array = exports.Uint16Array || Uint16Array;
		  exports.Int32Array = exports.Int32Array || Int32Array;
		  exports.Uint32Array = exports.Uint32Array || Uint32Array;
		  exports.Float32Array = exports.Float32Array || Float32Array;
		  exports.Float64Array = exports.Float64Array || Float64Array;
		}());

		//
		// 6 The DataView View Type
		//

		(function() {
		  function r(array, index) {
		    return ECMAScript.IsCallable(array.get) ? array.get(index) : array[index];
		  }

		  var IS_BIG_ENDIAN = (function() {
		    var u16array = new(exports.Uint16Array)([0x1234]),
		        u8array = new(exports.Uint8Array)(u16array.buffer);
		    return r(u8array, 0) === 0x12;
		  }());

		  // Constructor(ArrayBuffer buffer,
		  //             optional unsigned long byteOffset,
		  //             optional unsigned long byteLength)
		  /** @constructor */
		  var DataView = function DataView(buffer, byteOffset, byteLength) {
		    if (arguments.length === 0) {
		      buffer = new exports.ArrayBuffer(0);
		    } else if (!(buffer instanceof exports.ArrayBuffer || ECMAScript.Class(buffer) === 'ArrayBuffer')) {
		      throw new TypeError("TypeError");
		    }

		    this.buffer = buffer || new exports.ArrayBuffer(0);

		    this.byteOffset = ECMAScript.ToUint32(byteOffset);
		    if (this.byteOffset > this.buffer.byteLength) {
		      throw new RangeError("byteOffset out of range");
		    }

		    if (arguments.length < 3) {
		      this.byteLength = this.buffer.byteLength - this.byteOffset;
		    } else {
		      this.byteLength = ECMAScript.ToUint32(byteLength);
		    }

		    if ((this.byteOffset + this.byteLength) > this.buffer.byteLength) {
		      throw new RangeError("byteOffset and length reference an area beyond the end of the buffer");
		    }

		    configureProperties(this);
		  };

		  function makeGetter(arrayType) {
		    return function(byteOffset, littleEndian) {

		      byteOffset = ECMAScript.ToUint32(byteOffset);

		      if (byteOffset + arrayType.BYTES_PER_ELEMENT > this.byteLength) {
		        throw new RangeError("Array index out of range");
		      }
		      byteOffset += this.byteOffset;

		      var uint8Array = new exports.Uint8Array(this.buffer, byteOffset, arrayType.BYTES_PER_ELEMENT),
		          bytes = [], i;
		      for (i = 0; i < arrayType.BYTES_PER_ELEMENT; i += 1) {
		        bytes.push(r(uint8Array, i));
		      }

		      if (Boolean(littleEndian) === Boolean(IS_BIG_ENDIAN)) {
		        bytes.reverse();
		      }

		      return r(new arrayType(new exports.Uint8Array(bytes).buffer), 0);
		    };
		  }

		  DataView.prototype.getUint8 = makeGetter(exports.Uint8Array);
		  DataView.prototype.getInt8 = makeGetter(exports.Int8Array);
		  DataView.prototype.getUint16 = makeGetter(exports.Uint16Array);
		  DataView.prototype.getInt16 = makeGetter(exports.Int16Array);
		  DataView.prototype.getUint32 = makeGetter(exports.Uint32Array);
		  DataView.prototype.getInt32 = makeGetter(exports.Int32Array);
		  DataView.prototype.getFloat32 = makeGetter(exports.Float32Array);
		  DataView.prototype.getFloat64 = makeGetter(exports.Float64Array);

		  function makeSetter(arrayType) {
		    return function(byteOffset, value, littleEndian) {

		      byteOffset = ECMAScript.ToUint32(byteOffset);
		      if (byteOffset + arrayType.BYTES_PER_ELEMENT > this.byteLength) {
		        throw new RangeError("Array index out of range");
		      }

		      // Get bytes
		      var typeArray = new arrayType([value]),
		          byteArray = new exports.Uint8Array(typeArray.buffer),
		          bytes = [], i, byteView;

		      for (i = 0; i < arrayType.BYTES_PER_ELEMENT; i += 1) {
		        bytes.push(r(byteArray, i));
		      }

		      // Flip if necessary
		      if (Boolean(littleEndian) === Boolean(IS_BIG_ENDIAN)) {
		        bytes.reverse();
		      }

		      // Write them
		      byteView = new exports.Uint8Array(this.buffer, byteOffset, arrayType.BYTES_PER_ELEMENT);
		      byteView.set(bytes);
		    };
		  }

		  DataView.prototype.setUint8 = makeSetter(exports.Uint8Array);
		  DataView.prototype.setInt8 = makeSetter(exports.Int8Array);
		  DataView.prototype.setUint16 = makeSetter(exports.Uint16Array);
		  DataView.prototype.setInt16 = makeSetter(exports.Int16Array);
		  DataView.prototype.setUint32 = makeSetter(exports.Uint32Array);
		  DataView.prototype.setInt32 = makeSetter(exports.Int32Array);
		  DataView.prototype.setFloat32 = makeSetter(exports.Float32Array);
		  DataView.prototype.setFloat64 = makeSetter(exports.Float64Array);

		  exports.DataView = exports.DataView || DataView;

		}());
} (typedarray));
	return typedarray;
}

var Writable = readableBrowser.exports.Writable;
var inherits = inherits_browser.exports;
var bufferFrom = Buffer.from;

if (typeof Uint8Array === 'undefined') {
  var U8 = requireTypedarray().Uint8Array;
} else {
  var U8 = Uint8Array;
}

function ConcatStream(opts, cb) {
  if (!(this instanceof ConcatStream)) return new ConcatStream(opts, cb)

  if (typeof opts === 'function') {
    cb = opts;
    opts = {};
  }
  if (!opts) opts = {};

  var encoding = opts.encoding;
  var shouldInferEncoding = false;

  if (!encoding) {
    shouldInferEncoding = true;
  } else {
    encoding =  String(encoding).toLowerCase();
    if (encoding === 'u8' || encoding === 'uint8') {
      encoding = 'uint8array';
    }
  }

  Writable.call(this, { objectMode: true });

  this.encoding = encoding;
  this.shouldInferEncoding = shouldInferEncoding;

  if (cb) this.on('finish', function () { cb(this.getBody()); });
  this.body = [];
}

var concatStream = ConcatStream;
inherits(ConcatStream, Writable);

ConcatStream.prototype._write = function(chunk, enc, next) {
  this.body.push(chunk);
  next();
};

ConcatStream.prototype.inferEncoding = function (buff) {
  var firstBuffer = buff === undefined ? this.body[0] : buff;
  if (Buffer.isBuffer(firstBuffer)) return 'buffer'
  if (typeof Uint8Array !== 'undefined' && firstBuffer instanceof Uint8Array) return 'uint8array'
  if (Array.isArray(firstBuffer)) return 'array'
  if (typeof firstBuffer === 'string') return 'string'
  if (Object.prototype.toString.call(firstBuffer) === "[object Object]") return 'object'
  return 'buffer'
};

ConcatStream.prototype.getBody = function () {
  if (!this.encoding && this.body.length === 0) return []
  if (this.shouldInferEncoding) this.encoding = this.inferEncoding();
  if (this.encoding === 'array') return arrayConcat(this.body)
  if (this.encoding === 'string') return stringConcat(this.body)
  if (this.encoding === 'buffer') return bufferConcat(this.body)
  if (this.encoding === 'uint8array') return u8Concat(this.body)
  return this.body
};

function isArrayish (arr) {
  return /Array\]$/.test(Object.prototype.toString.call(arr))
}

function isBufferish (p) {
  return typeof p === 'string' || isArrayish(p) || (p && typeof p.subarray === 'function')
}

function stringConcat (parts) {
  var strings = [];
  for (var i = 0; i < parts.length; i++) {
    var p = parts[i];
    if (typeof p === 'string') {
      strings.push(p);
    } else if (Buffer.isBuffer(p)) {
      strings.push(p);
    } else if (isBufferish(p)) {
      strings.push(bufferFrom(p));
    } else {
      strings.push(bufferFrom(String(p)));
    }
  }
  if (Buffer.isBuffer(parts[0])) {
    strings = Buffer.concat(strings);
    strings = strings.toString('utf8');
  } else {
    strings = strings.join('');
  }
  return strings
}

function bufferConcat (parts) {
  var bufs = [];
  for (var i = 0; i < parts.length; i++) {
    var p = parts[i];
    if (Buffer.isBuffer(p)) {
      bufs.push(p);
    } else if (isBufferish(p)) {
      bufs.push(bufferFrom(p));
    } else {
      bufs.push(bufferFrom(String(p)));
    }
  }
  return Buffer.concat(bufs)
}

function arrayConcat (parts) {
  var res = [];
  for (var i = 0; i < parts.length; i++) {
    res.push.apply(res, parts[i]);
  }
  return res
}

function u8Concat (parts) {
  var len = 0;
  for (var i = 0; i < parts.length; i++) {
    if (typeof parts[i] === 'string') {
      parts[i] = bufferFrom(parts[i]);
    }
    len += parts[i].length;
  }
  var u8 = new U8(len);
  for (var i = 0, offset = 0; i < parts.length; i++) {
    var part = parts[i];
    for (var j = 0; j < part.length; j++) {
      u8[offset++] = part[j];
    }
  }
  return u8
}

var toDate = function(date) {
	if (!date) return new Date();
	if (typeof date === 'string') return new Date(date);
	return date;
};

var Stat = function(opts) {
	this.uid = opts.uid || 0;
	this.gid = opts.gid || 0;
	this.mode = opts.mode || 0;
	this.size = opts.size || 0;
	this.mtime = toDate(opts.mtime);
	this.atime = toDate(opts.atime);
	this.ctime = toDate(opts.ctime);
	this.type = opts.type;
	this.target = opts.target;
	this.link = opts.link;
	this.blob = opts.blob;
};

Stat.prototype.isDirectory = function() {
	return this.type === 'directory';
};

Stat.prototype.isFile = function() {
	return this.type === 'file';
};

Stat.prototype.isBlockDevice = function() {
	return false;
};

Stat.prototype.isCharacterDevice = function() {
	return false;
};

Stat.prototype.isSymbolicLink = function() {
	return this.type === 'symlink';
};

Stat.prototype.isFIFO = function() {
	return false;
};

Stat.prototype.isSocket = function() {
	return false;
};

var stat$1 = function(opts) {
	return new Stat(opts);
};

var path = require$$0$2;
var once$1 = require$$4;
var concat = concatStream;
var octal$1 = octal$2;
var stat = stat$1;
var xtend = immutable;
var errno$1 = errno$2;

var ROOT = stat({
	type: 'directory',
	mode: octal$1(777),
	size: 4096
});

var normalize = function(key) {
	key = key[0] === '/' ? key : '/' + key;
	key = path.normalize(key);
	if (key === '/') return key;
	return key[key.length-1] === '/' ? key.slice(0, -1) : key;
};

var prefix = function(key) {
	var depth = key.split('/').length.toString(36);
	return '0000000000'.slice(depth.length)+depth+key;
};

var paths$1 = function(db) {
	var that = {};

	that.normalize = normalize;

	that.get = function(key, cb) {
		key = normalize(key);
		if (key === '/') return process.nextTick(cb.bind(null, null, ROOT, '/'));
		db.get(prefix(key), {valueEncoding:'json'}, function(err, doc) {
			if (err && err.notFound) return cb(errno$1.ENOENT(key), null, key);
			if (err) return cb(err, null, key);
			cb(null, stat(doc), key);
		});
	};

	that.writable = function(key, cb) {
		key = normalize(key);
		if (key === '/') return process.nextTick(cb.bind(null, errno$1.EPERM(key)));
		that.follow(path.dirname(key), function(err, parent) {
			if (err) return cb(err);
			if (!parent.isDirectory()) return cb(errno$1.ENOTDIR(key));
			cb(null, key);
		});
	};

	that.list = function(key, cb) {
		key = normalize(key);

		var start = prefix(key === '/' ? key : key + '/');
		var keys = db.createKeyStream({start: start, end: start+'\xff'});

		cb = once$1(cb);

		keys.on('error', cb);
		keys.pipe(concat({encoding:'object'}, function(files) {
			files = files.map(function(file) {
				return file.split('/').pop();
			});

			cb(null, files);
		}));
	};

	var resolve = function(dir, cb) {
		var root = '/';
		var parts = dir.split('/').slice(1);

		var loop = function() {
			that.get(path.join(root, parts.shift()), function(err, doc, key) {
				if (err) return cb(err, doc, dir);
				root = doc.target || key;
				if (!parts.length) return cb(null, doc, key);
				loop();
			});
		};

		loop();
	};

	that.follow = function(key, cb) {
		resolve(normalize(key), function loop(err, doc, key) {
			if (err) return cb(err, null, key);
			if (doc.target) return that.get(doc.target, loop);
			cb(null, stat(doc), key);
		});
	};

	that.update = function(key, opts, cb) {
		that.get(key, function(err, doc, key) {
			if (err) return cb(err);
			if (key === '/') return cb(errno$1.EPERM(key));
			that.put(key, xtend(doc, opts), cb);
		});
	};

	that.put = function(key, opts, cb) {
		that.writable(key, function(err, key) {
			if (err) return cb(err);
			db.put(prefix(key), stat(opts), {valueEncoding:'json'}, cb);
		});
	};

	that.del = function(key, cb) {
		key = normalize(key);
		if (key === '/') return process.nextTick(cb.bind(null, errno$1.EPERM(key)));
		db.del(prefix(key), cb);
	};

	return that;
};

var events = require$$0$1;

var watchers$1 = function() {
	var listeners = {};
	var that = new events.EventEmitter();

	that.watch = function(key, cb) {
		if (!listeners[key]) {
			listeners[key] = new events.EventEmitter();
			listeners[key].setMaxListeners(0);
		}

		if (cb) listeners[key].on('change', cb);
		return listeners[key];
	};

	that.watcher = function(key, cb) {
		var watcher = new events.EventEmitter();
		var onchange = function() {
			watcher.emit('change', 'change', key);
		};

		that.watch(key, onchange);
		if (cb) watcher.on('change', cb);
		watcher.close = function() {
			that.unwatch(key, onchange);
		};

		return watcher;
	};

	that.unwatch = function(key, cb) {
		if (!listeners[key]) return;
		if (cb) listeners[key].removeListener('change', cb);
		else listeners[key].removeAllListeners('change');
		if (!listeners[key].listeners('change').length) delete listeners[key];	};

	that.change = function(key) {
		if (listeners[key]) listeners[key].emit('change');
		that.emit('change', key);
	};

	that.cb = function(key, cb) {
		return function(err, val) {
			if (key) that.change(key);
			if (cb) cb(err, val);
		};
	};

	return that;
};

var fwd = fwdStream;
var sublevel = levelSublevel;
var blobs = levelBlobs;
var peek = levelPeek;
var once = require$$4;
var octal = octal$2;
var errno = errno$2;
var paths = paths$1;
var watchers = watchers$1;

var nextTick = function(cb, err, val) {
	process.nextTick(function() {
		cb(err, val);
	});
};

var noop = function() {};

var levelFilesystem = function(db, opts) {
	var fs = {};

	db = sublevel(db);

	var bl = blobs(db.sublevel('blobs'), opts);
	var ps = paths(db.sublevel('stats'));
	var links = db.sublevel('links');

	var listeners = watchers();
	var fds = [];

	var now = Date.now();
	var inc = function() {
		return ++now;
	};

	fs.mkdir = function(key, mode, cb) {
		if (typeof mode === 'function') return fs.mkdir(key, null, mode);
		if (!mode) mode = octal(777);
		if (!cb) cb = noop;

		ps.follow(key, function(err, stat, key) {
			if (err && err.code !== 'ENOENT') return cb(err);
			if (stat) return cb(errno.EEXIST(key));

			ps.put(key, {
				type:'directory',
				mode: mode,
				size: 4096
			}, listeners.cb(key, cb));
		});
	};

	fs.rmdir = function(key, cb) {
		if (!cb) cb = noop;
		ps.follow(key, function(err, stat, key) {
			if (err) return cb(err);
			fs.readdir(key, function(err, files) {
				if (err) return cb(err);
				if (files.length) return cb(errno.ENOTEMPTY(key));
				ps.del(key, listeners.cb(key, cb));
			});
		});

	};

	fs.readdir = function(key, cb) {
		ps.follow(key, function(err, stat, key) {
			if (err) return cb(err);
			if (!stat) return cb(errno.ENOENT(key));
			if (!stat.isDirectory()) return cb(errno.ENOTDIR(key));
			ps.list(key, cb);
		});
	};

	var stat = function(key, lookup, cb) {
		lookup(key, function(err, stat, key) {
			if (err) return cb(err);
			if (!stat.isFile()) return cb(null, stat);
			var blob = stat && stat.blob || key;
			bl.size(blob, function(err, size) {
				if (err) return cb(err);
				stat.size = size;
				cb(null, stat);
			});
		});
	};

	fs.stat = function(key, cb) {
		stat(key, ps.follow, cb);
	};

	fs.lstat = function(key, cb) {
		stat(key, ps.get, cb);
	};

	fs.exists = function(key, cb) {
		ps.follow(key, function(err) {
			cb(!err);
		});
	};

	var chmod = function(key, lookup, mode, cb) {
		if (!cb) cb = noop;
		lookup(key, function(err, stat, key) {
			if (err) return cb(err);
			ps.update(key, {mode:mode}, listeners.cb(key, cb));
		});
	};

	fs.chmod = function(key, mode, cb) {
		chmod(key, ps.follow, mode, cb);
	};

	fs.lchmod = function(key, mode, cb) {
		chmod(key, ps.get, mode, cb);
	};

	var chown = function(key, lookup, uid, gid, cb) {
		if (!cb) cb = noop;
		lookup(key, function(err, stat, key) {
			if (err) return cb(err);
			ps.update(key, {uid:uid, gid:gid}, listeners.cb(key, cb));
		});
	};

	fs.chown = function(key, uid, gid, cb) {
		chown(key, ps.follow, uid, gid, cb);
	};

	fs.lchown = function(key, uid, gid, cb) {
		chown(key, ps.get, uid, gid, cb);
	};

	fs.utimes = function(key, atime, mtime, cb) {
		if (!cb) cb = noop;
		ps.follow(key, function(err, stat, key) {
			if (err) return cb(err);
			var upd = {};
			if (atime) upd.atime = atime;
			if (mtime) upd.mtime = mtime;
			ps.update(key, upd, listeners.cb(key, cb));
		});
	};

	fs.rename = function(from, to, cb) {
		if (!cb) cb = noop;

		ps.follow(from, function(err, statFrom, from) {
			if (err) return cb(err);

			var rename = function() {
				cb = listeners.cb(to, listeners.cb(from, cb));
				ps.put(to, statFrom, function(err) {
					if (err) return cb(err);
					ps.del(from, cb);
				});
			};

			ps.follow(to, function(err, statTo, to) {
				if (err && err.code !== 'ENOENT') return cb(err);
				if (!statTo) return rename();
				if (statFrom.isDirectory() !== statTo.isDirectory()) return cb(errno.EISDIR(from));

				if (statTo.isDirectory()) {
					fs.readdir(to, function(err, list) {
						if (err) return cb(err);
						if (list.length) return cb(errno.ENOTEMPTY(from));
						rename();
					});
					return;
				}

				rename();
			});
		});
	};

	fs.realpath = function(key, cache, cb) {
		if (typeof cache === 'function') return fs.realpath(key, null, cache);
		ps.follow(key, function(err, stat, key) {
			if (err) return cb(err);
			cb(null, key);
		});
	};

	fs.writeFile = function(key, data, opts, cb) {
		if (typeof opts === 'function') return fs.writeFile(key, data, null, opts);
		if (typeof opts === 'string') opts = {encoding:opts};
		if (!opts) opts = {};
		if (!cb) cb = noop;

		if (!Buffer.isBuffer(data)) data = new Buffer(data, opts.encoding || 'utf-8');

		var flags = opts.flags || 'w';
		opts.append = flags[0] !== 'w';

		ps.follow(key, function(err, stat, key) {
			if (err && err.code !== 'ENOENT') return cb(err);
			if (stat && stat.isDirectory()) return cb(errno.EISDIR(key));
			if (stat && flags[1] === 'x') return cb(errno.EEXIST(key));

			var blob = stat && stat.blob || key;
			ps.writable(key, function(err) {
				if (err) return cb(err);

				bl.write(blob, data, opts, function(err) {
					if (err) return cb(err);

					ps.put(key, {
						ctime: stat && stat.ctime,
						mtime: new Date(),
						mode: opts.mode || octal(666),
						type:'file'
					}, listeners.cb(key, cb));
				});
			});
		});
	};

	fs.appendFile = function(key, data, opts, cb) {
		if (typeof opts === 'function') return fs.appendFile(key, data, null, opts);
		if (typeof opts === 'string') opts = {encoding:opts};
		if (!opts) opts = {};

		opts.flags = 'a';
		fs.writeFile(key, data, opts, cb);
	};

	fs.unlink = function(key, cb) {
		if (!cb) cb = noop;

		ps.get(key, function(err, stat, key) {
			if (err) return cb(err);
			if (stat.isDirectory()) return cb(errno.EISDIR(key));

			var clean = function(target) {
				peek(links, {start:target+'\xff', end:target+'\xff\xff'}, function(err) {
					if (err) return bl.remove(target, cb); // no more links
					cb();
				});
			};

			var onlink = function() {
				var target = stat.link.slice(0, stat.link.indexOf('\xff'));
				links.del(stat.link, function(err) {
					if (err) return cb(err);
					clean(target);
				});
			};

			ps.del(key, listeners.cb(key, function(err) {
				if (err) return cb(err);
				if (stat.link) return onlink();
				links.del(key+'\xff', function(err) {
					if (err) return cb(err);
					clean(key);
				});
			}));
		});
	};

	fs.readFile = function(key, opts, cb) {
		if (typeof opts === 'function') return fs.readFile(key, null, opts);
		if (typeof opts === 'string') opts = {encoding:opts};
		if (!opts) opts = {};

		opts.encoding || 'binary';
		opts.flag || 'r';

		ps.follow(key, function(err, stat, key) {
			if (err) return cb(err);
			if (stat.isDirectory()) return cb(errno.EISDIR(key));

			var blob = stat && stat.blob || key;
			bl.read(blob, function(err, data) {
				if (err) return cb(err);
				cb(null, opts.encoding ? data.toString(opts.encoding) : data);
			});
		});
	};

	fs.createReadStream = function(key, opts) {
		if (!opts) opts = {};

		var closed = false;
		var rs = fwd.readable(function(cb) {
			ps.follow(key, function(err, stat, key) {
				if (err) return cb(err);
				if (stat.isDirectory()) return cb(errno.EISDIR(key));

				var blob = stat && stat.blob || key;
				var r = bl.createReadStream(blob, opts);

				rs.emit('open');
				r.on('end', function() {
					process.nextTick(function() {
						if (!closed) rs.emit('close');
					});
				});

				cb(null, r);
			});
		});

		rs.on('close', function() {
			closed = true;
		});

		return rs;
	};

	fs.createWriteStream = function(key, opts) {
		if (!opts) opts = {};

		var flags = opts.flags || 'w';
		var closed = false;
		var mode = opts.mode || octal(666);

		opts.append = flags[0] === 'a';

		var ws = fwd.writable(function(cb) {
			ps.follow(key, function(err, stat, key) {
				if (err && err.code !== 'ENOENT') return cb(err);
				if (stat && stat.isDirectory()) return cb(errno.EISDIR(key));
				if (stat && flags[1] === 'x') return cb(errno.EEXIST(key));

				var blob = stat && stat.blob || key;
				ps.writable(blob, function(err) {
					if (err) return cb(err);

					var ctime = stat ? stat.ctime : new Date();
					var s = {
						ctime: ctime,
						mtime: new Date(),
						mode: mode,
						type:'file'
					};

					ps.put(key, s, function(err) {
						if (err) return cb(err);

						var w = bl.createWriteStream(blob, opts);

						ws.emit('open');
						w.on('finish', function() {
							s.mtime = new Date();
							ps.put(key, s, function() {
								listeners.change(key);
								if (!closed) ws.emit('close');
							});
						});

						cb(null, w);
					});
				});
			});
		});

		ws.on('close', function() {
			closed = true;
		});

		return ws;
	};

	fs.truncate = function(key, len, cb) {
		ps.follow(key, function(err, stat, key) {
			if (err) return cb(err);

			var blob = stat && stat.blob || key;
			bl.size(blob, function(err, size) {
				if (err) return cb(err);

				ps.writable(key, function(err) {
					if (err) return cb(err);

					cb = once(listeners.cb(key, cb));
					if (!len) return bl.remove(blob, cb);

					var ws = bl.createWriteStream(blob, {
						start:size < len ? len-1 : len
					});

					ws.on('error', cb);
					ws.on('finish', cb);

					if (size < len) ws.write(new Buffer([0]));
					ws.end();
				});
			});
		});
	};

	fs.watchFile = function(key, opts, cb) {
		if (typeof opts === 'function') return fs.watchFile(key, null, opts);
		return listeners.watch(ps.normalize(key), cb);
	};

	fs.unwatchFile = function(key, cb) {
		listeners.unwatch(ps.normalize(key), cb);
	};

	fs.watch = function(key, opts, cb) {
		if (typeof opts === 'function') return fs.watch(key, null, opts)
		return listeners.watcher(ps.normalize(key), cb);
	};

	fs.notify = function(cb) {
		listeners.on('change', cb);
	};

	fs.open = function(key, flags, mode, cb) {
		if (typeof mode === 'function') return fs.open(key, flags, null, mode);

		ps.follow(key, function(err, stat, key) {
			if (err && err.code !== 'ENOENT') return cb(err);

			var fl = flags[0];
			var plus = flags[1] === '+' || flags[2] === '+';
			var blob = stat && stat.blob || key;

			var f = {
				key: key,
				blob: blob,
				mode: mode || octal(666),
				readable: fl === 'r' || ((fl === 'w' || fl === 'a') && plus),
				writable: fl === 'w' || fl === 'a' || (fl === 'r' && plus),
				append: fl === 'a'
			};

			if (fl === 'r' && err) return cb(err);
			if (flags[1] === 'x' && stat) return cb(errno.EEXIST(key));
			if (stat && stat.isDirectory()) return cb(errno.EISDIR(key));

			bl.size(blob, function(err, size) {
				if (err) return cb(err);

				if (f.append) f.writePos = size;

				ps.writable(key, function(err) {
					if (err) return cb(err);

					var onready = function(err) {
						if (err) return cb(err);

						var i = fds.indexOf(null);
						if (i === -1) i = 10+fds.push(fds.length+10)-1;

						f.fd = i;
						fds[i] = f;
						listeners.change(key);

						cb(null, f.fd);
					};

					var ontruncate = function(err) {
						if (err) return cb(err);
						if (stat) return onready();
						ps.put(blob, {ctime:stat && stat.ctime, type:'file'}, onready);
					};

					if (!f.append && f.writable) return bl.remove(blob, ontruncate);
					ontruncate();
				});
			});
		});
	};

	fs.close = function(fd, cb) {
		var f = fds[fd];
		if (!f) return nextTick(cb, errno.EBADF());

		fds[fd] = null;
		nextTick(listeners.cb(f.key, cb));
	};

	fs.write = function(fd, buf, off, len, pos, cb) {
		var f = fds[fd];
		if (!cb) cb = noop;
		if (!f || !f.writable) return nextTick(cb, errno.EBADF());

		if (pos === null) pos = f.writePos || 0;

		var slice = buf.slice(off, off+len);
		f.writePos = pos + slice.length;

		bl.write(f.blob, slice, {start:pos, append:true}, function(err) {
			if (err) return cb(err);
			cb(null, len, buf);
		});
	};

	fs.read = function(fd, buf, off, len, pos, cb) {
		var f = fds[fd];
		if (!cb) cb = noop;
		if (!f || !f.readable) return nextTick(cb, errno.EBADF());

		if (pos === null) pos = fs.readPos || 0;

		bl.read(f.blob, {start:pos, end:pos+len-1}, function(err, read) {
			if (err) return cb(err);
			var slice = read.slice(0, len);
			slice.copy(buf, off);
			fs.readPos = pos+slice.length;
			cb(null, slice.length, buf);
		});
	};

	fs.fsync = function(fd, cb) {
		var f = fds[fd];
		if (!cb) cb = noop;
		if (!f || !f.writable) return nextTick(cb, errno.EBADF());

		nextTick(cb);
	};

	fs.ftruncate = function(fd, len, cb) {
		var f = fds[fd];
		if (!cb) cb = noop;
		if (!f) return nextTick(cb, errno.EBADF());

		fs.truncate(f.blob, len, cb);
	};

	fs.fchown = function(fd, uid, gid, cb) {
		var f = fds[fd];
		if (!cb) cb = noop;
		if (!f) return nextTick(cb, errno.EBADF());

		fs.chown(f.key, uid, gid, cb);
	};

	fs.fchmod = function(fd, mode, cb) {
		var f = fds[fd];
		if (!cb) cb = noop;
		if (!f) return nextTick(cb, errno.EBADF());

		fs.chmod(f.key, mode, cb);
	};

	fs.futimes = function(fd, atime, mtime, cb) {
		var f = fds[fd];
		if (!cb) cb = noop;
		if (!f) return nextTick(cb, errno.EBADF());

		fs.utimes(f.key, atime, mtime, cb);
	};

	fs.fstat = function(fd, cb) {
		var f = fds[fd];
		if (!f) return nextTick(cb, errno.EBADF());

		fs.stat(f.key, cb);
	};

	fs.symlink = function(target, name, cb) {
		if (!cb) cb = noop;
		ps.follow(target, function(err, stat, target) {
			if (err) return cb(err);
			ps.get(name, function(err, stat) {
				if (err && err.code !== 'ENOENT') return cb(err);
				if (stat) return cb(errno.EEXIST(name));
				ps.put(name, {type:'symlink', target:target, mode:octal(777)}, cb);
			});
		});
	};

	fs.readlink = function(key, cb) {
		ps.get(key, function(err, stat) {
			if (err) return cb(err);
			if (!stat.target) return cb(errno.EINVAL(key));
			cb(null, stat.target);
		});
	};

	fs.link = function(target, name, cb) {
		if (!cb) cb = noop;
		ps.follow(target, function(err, stat, target) {
			if (err) return cb(err);
			if (!stat.isFile()) return cb(errno.EINVAL(target));
			ps.get(name, function(err, st) {
				if (err && err.code !== 'ENOENT') return cb(err);
				if (st) return cb(errno.EEXIST(name));
				var link = target+'\xff'+inc();
				links.put(target+'\xff', target, function(err) {
					if (err) return cb(err);
					links.put(link, target, function(err) {
						if (err) return cb(err);
						ps.put(name, {type:'file', link:link, blob:target, mode:stat.mode}, cb);
					});
				});
			});
		});
	};

	return fs;
};

var leveljs = levelJs;
var levelup = levelup$1;
var fs = levelFilesystem;

var db = levelup('level-filesystem', {db:leveljs});
var browserifyFs = fs(db);

export { browserifyFs as default };
