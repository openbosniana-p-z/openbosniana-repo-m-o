import { initDevTools } from './devtools';

initDevTools();

