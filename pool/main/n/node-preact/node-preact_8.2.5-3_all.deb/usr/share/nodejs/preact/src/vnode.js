/** Virtual DOM Node */
export function VNode() {}
