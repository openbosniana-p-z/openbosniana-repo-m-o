var parents = require('parents');
var dirs = parents(__dirname);
console.dir(dirs);
