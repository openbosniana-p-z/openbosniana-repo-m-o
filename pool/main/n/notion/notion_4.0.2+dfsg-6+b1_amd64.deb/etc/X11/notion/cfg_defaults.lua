--
-- Notion default settings
--

dopath("cfg_kludges")
dopath("cfg_layouts")

dopath("mod_query")
dopath("mod_menu")
dopath("mod_tiling")
dopath("mod_dock")
dopath("mod_sp")
dopath("mod_notionflux")
dopath("mod_xrandr")

dopath("net_client_list")

-- loads cfg_bindings
dopath("cfg_notioncore")

-- Debian extra configuration files
dopath("cfg_debian_ext")
