-- Settings common to "emboss" styles.

dopath("lookcommon_emboss_stdisp")
dopath("lookcommon_emboss_tab")
dopath("lookcommon_emboss_frame")
