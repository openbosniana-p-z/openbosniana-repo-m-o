-- Settings common to the "clean" styles.

dopath("lookcommon_clean_stdisp")
dopath("lookcommon_clean_tab")
dopath("lookcommon_clean_frame")
