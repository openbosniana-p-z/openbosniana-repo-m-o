de.defstyle("frame-tiled", {
    border_style = "inlaid",
    padding_pixels = 1,
    spacing = 1,
})

de.defstyle("frame-floating", {
    border_style = "ridge",
    bar = "shaped"
})

de.defstyle("frame-tiled-alt", {
    bar = "none",
})
