import { Field } from './field';
export declare class Load extends Field {
    constructor(name: string, field: string);
}
