import { Field } from './field';
export declare class Store extends Field {
    constructor(name: string, field: string);
}
