import { Node } from './base';
export declare class Empty extends Node {
}
