export declare abstract class TrieNode {
}
