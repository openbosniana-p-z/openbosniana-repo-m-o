import { External } from './external';
export declare class Match extends External {
    constructor(name: string);
}
