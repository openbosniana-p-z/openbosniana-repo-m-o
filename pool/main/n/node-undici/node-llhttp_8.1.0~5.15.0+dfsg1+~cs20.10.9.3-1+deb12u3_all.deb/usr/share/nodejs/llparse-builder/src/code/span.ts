import { Match } from './match';

export class Span extends Match {
  // no-op
}
