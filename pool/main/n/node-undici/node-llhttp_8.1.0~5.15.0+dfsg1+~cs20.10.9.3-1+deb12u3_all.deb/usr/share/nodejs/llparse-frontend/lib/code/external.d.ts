import { Code, Signature } from './base';
export declare abstract class External extends Code {
    constructor(signature: Signature, name: string);
}
