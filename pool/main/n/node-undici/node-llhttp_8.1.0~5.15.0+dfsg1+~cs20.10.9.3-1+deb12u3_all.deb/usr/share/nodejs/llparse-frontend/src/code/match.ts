import { External } from './external';

export class Match extends External {
  constructor(name: string) {
    super('match', name);
  }
}
