export abstract class TrieNode {
}
