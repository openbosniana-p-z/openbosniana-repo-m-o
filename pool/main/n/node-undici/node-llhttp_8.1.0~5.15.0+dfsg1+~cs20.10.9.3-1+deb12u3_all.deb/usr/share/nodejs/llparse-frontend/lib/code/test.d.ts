import { FieldValue } from './field-value';
export declare class Test extends FieldValue {
    constructor(name: string, field: string, value: number);
}
