import { External } from './external';
export declare class Value extends External {
    constructor(name: string);
}
