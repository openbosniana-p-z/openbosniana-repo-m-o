import { Node } from './base';

export class Empty extends Node {
}
