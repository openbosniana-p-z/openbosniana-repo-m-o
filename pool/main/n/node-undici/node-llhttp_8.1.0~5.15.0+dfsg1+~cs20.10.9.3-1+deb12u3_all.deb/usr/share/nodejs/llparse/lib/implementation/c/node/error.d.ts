import * as frontend from 'llparse-frontend';
import { Node } from './base';
declare class ErrorNode<T extends frontend.node.Error> extends Node<T> {
    storeError(out: string[]): void;
    doBuild(out: string[]): void;
}
export { ErrorNode as Error };
