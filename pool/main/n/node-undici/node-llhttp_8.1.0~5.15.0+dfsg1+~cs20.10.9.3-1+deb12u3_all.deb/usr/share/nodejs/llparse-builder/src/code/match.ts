import { Code } from './base';

export class Match extends Code {
  constructor(name: string) {
    super('match', name);
  }
}
