import { Node } from './node';
import { IWrap } from './wrap';
export declare class Enumerator {
    getAllNodes(root: IWrap<Node>): ReadonlyArray<IWrap<Node>>;
}
