import { Field } from './field';
export declare class Load extends Field {
    constructor(field: string);
}
