import { Error as ErrorNode } from './error';
export declare class Pause extends ErrorNode {
}
