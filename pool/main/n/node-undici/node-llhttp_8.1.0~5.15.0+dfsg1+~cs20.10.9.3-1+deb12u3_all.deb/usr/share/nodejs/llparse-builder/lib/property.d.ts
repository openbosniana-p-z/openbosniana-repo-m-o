export declare type PropertyType = 'i8' | 'i16' | 'i32' | 'i64' | 'ptr';
/**
 * Class describing allocated property in parser's state
 */
export declare class Property {
    readonly ty: PropertyType;
    readonly name: string;
    constructor(ty: PropertyType, name: string);
}
