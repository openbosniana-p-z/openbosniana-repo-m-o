export abstract class Transform {
  constructor(public readonly name: string) {
  }
}
