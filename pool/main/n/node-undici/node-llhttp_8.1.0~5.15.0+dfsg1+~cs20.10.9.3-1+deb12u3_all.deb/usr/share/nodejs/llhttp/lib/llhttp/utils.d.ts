export interface IEnumMap {
    [key: string]: number;
}
export declare function enumToMap(obj: any, filter?: ReadonlyArray<number>, exceptions?: ReadonlyArray<number>): IEnumMap;
