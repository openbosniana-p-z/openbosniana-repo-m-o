import { FieldValue } from './field-value';
export declare class And extends FieldValue {
    constructor(field: string, value: number);
}
