import { Transform } from './base';

export class ToLower extends Transform {
  constructor() {
    super('to_lower');
  }
}
