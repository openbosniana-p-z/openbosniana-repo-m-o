import { Transform } from './base';

export class ID extends Transform {
  constructor() {
    super('id');
  }
}
