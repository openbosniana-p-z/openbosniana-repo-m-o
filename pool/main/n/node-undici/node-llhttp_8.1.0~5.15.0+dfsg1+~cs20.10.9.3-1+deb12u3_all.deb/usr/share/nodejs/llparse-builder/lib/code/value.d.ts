import { Code } from './base';
export declare class Value extends Code {
    constructor(name: string);
}
