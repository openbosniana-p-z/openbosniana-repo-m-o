import { FieldValue } from './field-value';
export declare class IsEqual extends FieldValue {
    constructor(field: string, value: number);
}
