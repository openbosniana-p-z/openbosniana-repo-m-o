import * as frontend from 'llparse-frontend';
import { Node } from './base';
export declare class TableLookup extends Node<frontend.node.TableLookup> {
    doBuild(out: string[]): void;
    private buildSSE;
    private buildTable;
}
