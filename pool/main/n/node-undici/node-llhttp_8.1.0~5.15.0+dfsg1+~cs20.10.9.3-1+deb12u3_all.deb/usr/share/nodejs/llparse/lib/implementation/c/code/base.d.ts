import * as frontend from 'llparse-frontend';
import { Compilation } from '../compilation';
export declare abstract class Code<T extends frontend.code.Code> {
    readonly ref: T;
    cachedDecl: string | undefined;
    constructor(ref: T);
    abstract build(ctx: Compilation, out: string[]): void;
}
