import { Field } from './field';
export declare class Store extends Field {
    constructor(field: string);
}
