import { Transform } from './base';

export class ToLowerUnsafe extends Transform {
  constructor() {
    super('to_lower_unsafe');
  }
}
