import * as frontend from 'llparse-frontend';
import { Transform } from '../transform';
import { Compilation } from '../compilation';
declare type TransformWrap = Transform<frontend.transform.Transform>;
export declare class MatchSequence {
    private readonly transform;
    constructor(transform: TransformWrap);
    static buildGlobals(out: string[]): void;
    getName(): string;
    build(ctx: Compilation, out: string[]): void;
}
export {};
