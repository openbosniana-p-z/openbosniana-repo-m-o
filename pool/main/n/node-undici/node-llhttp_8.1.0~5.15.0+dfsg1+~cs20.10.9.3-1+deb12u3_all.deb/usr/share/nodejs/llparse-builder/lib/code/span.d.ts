import { Match } from './match';
export declare class Span extends Match {
}
