import * as frontend from 'llparse-frontend';
import { Consume } from './consume';
import { Empty } from './empty';
import { Invoke } from './invoke';
import { Pause } from './pause';
import { Sequence } from './sequence';
import { Single } from './single';
import { SpanEnd } from './span-end';
import { SpanStart } from './span-start';
import { TableLookup } from './table-lookup';
export { Node } from './base';
declare const _default: {
    Consume: typeof Consume;
    Empty: typeof Empty;
    Error: {
        new (ref: frontend.node.Error): {
            storeError(out: string[]): void;
            doBuild(out: string[]): void;
            cachedDecl: string | undefined;
            privCompilation: import("../compilation").Compilation | undefined;
            readonly ref: frontend.node.Error;
            build(compilation: import("../compilation").Compilation): string;
            readonly compilation: import("../compilation").Compilation;
            prologue(out: string[]): void;
            pause(out: string[]): void;
            tailTo(out: string[], edge: import("./base").INodeEdge): void;
        };
    };
    Invoke: typeof Invoke;
    Pause: typeof Pause;
    Sequence: typeof Sequence;
    Single: typeof Single;
    SpanEnd: typeof SpanEnd;
    SpanStart: typeof SpanStart;
    TableLookup: typeof TableLookup;
};
export default _default;
