import { External } from './external';
export declare class Span extends External {
    constructor(name: string);
}
