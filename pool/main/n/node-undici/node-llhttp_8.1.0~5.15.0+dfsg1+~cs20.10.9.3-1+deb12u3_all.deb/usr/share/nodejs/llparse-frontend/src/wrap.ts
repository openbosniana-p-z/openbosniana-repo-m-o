export interface IWrap<T> {
  readonly ref: T;
}
