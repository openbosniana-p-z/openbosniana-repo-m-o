import { Transform } from './base';
export declare class ID extends Transform {
    constructor();
}
