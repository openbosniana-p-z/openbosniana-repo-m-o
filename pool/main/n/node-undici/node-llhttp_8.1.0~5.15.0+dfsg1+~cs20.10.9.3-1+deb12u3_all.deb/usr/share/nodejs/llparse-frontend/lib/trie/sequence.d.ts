/// <reference types="node" />
import { TrieNode } from './node';
export declare class TrieSequence extends TrieNode {
    readonly select: Buffer;
    readonly child: TrieNode;
    constructor(select: Buffer, child: TrieNode);
}
