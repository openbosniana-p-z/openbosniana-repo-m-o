import { Error as ErrorNode } from './error';

export class Pause extends ErrorNode {
}
