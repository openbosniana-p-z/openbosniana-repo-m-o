export declare class CHeaders {
    build(): string;
    private buildEnum;
    private buildMap;
}
