import { Node } from './node';
import { IWrap } from './wrap';
declare type WrapNode = IWrap<Node>;
declare type WrapList = ReadonlyArray<WrapNode>;
export declare class Peephole {
    optimize(root: WrapNode, nodes: WrapList): WrapNode;
    optimizeNode(node: WrapNode): boolean;
}
export {};
