import { FieldValue } from './field-value';
export declare class And extends FieldValue {
    constructor(name: string, field: string, value: number);
}
