import { Transform } from './base';
export declare class ToLowerUnsafe extends Transform {
    constructor();
}
