import * as frontend from 'llparse-frontend';
import { And } from './and';
import { IsEqual } from './is-equal';
import { Load } from './load';
import { MulAdd } from './mul-add';
import { Or } from './or';
import { Store } from './store';
import { Test } from './test';
import { Update } from './update';
export * from './base';
declare const _default: {
    And: typeof And;
    IsEqual: typeof IsEqual;
    Load: typeof Load;
    Match: {
        new (ref: frontend.code.External): {
            build(ctx: import("../compilation").Compilation, out: string[]): void;
            cachedDecl: string | undefined;
            readonly ref: frontend.code.External;
        };
    };
    MulAdd: typeof MulAdd;
    Or: typeof Or;
    Span: {
        new (ref: frontend.code.Span): {
            build(ctx: import("../compilation").Compilation, out: string[]): void;
            cachedDecl: string | undefined;
            readonly ref: frontend.code.Span;
        };
    };
    Store: typeof Store;
    Test: typeof Test;
    Update: typeof Update;
    Value: {
        new (ref: frontend.code.Value): {
            build(ctx: import("../compilation").Compilation, out: string[]): void;
            cachedDecl: string | undefined;
            readonly ref: frontend.code.Value;
        };
    };
};
export default _default;
