import { LLParse, source } from 'llparse';
import Node = source.node.Node;
import { HTTPMode } from './constants';
export interface IURLResult {
    readonly entry: {
        readonly normal: Node;
        readonly connect: Node;
    };
    readonly exit: {
        readonly toHTTP: Node;
        readonly toHTTP09: Node;
    };
}
export declare class URL {
    private readonly llparse;
    private readonly mode;
    private readonly span;
    private readonly spanTable;
    private readonly errorInvalid;
    private readonly errorStrictInvalid;
    private readonly URL_CHAR;
    constructor(llparse: LLParse, mode?: HTTPMode, separateSpans?: boolean);
    build(): IURLResult;
    private spanStart;
    private spanEnd;
    private node;
}
