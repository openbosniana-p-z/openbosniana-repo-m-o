import { FieldValue } from './field-value';
export declare class Update extends FieldValue {
    constructor(field: string, value: number);
}
