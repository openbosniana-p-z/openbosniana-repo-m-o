import { Transform } from './base';
export declare class ToLower extends Transform {
    constructor();
}
