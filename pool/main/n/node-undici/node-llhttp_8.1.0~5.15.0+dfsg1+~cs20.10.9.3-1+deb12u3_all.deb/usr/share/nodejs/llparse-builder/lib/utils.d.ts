/// <reference types="node" />
import { Buffer } from 'buffer';
/**
 * Internal
 */
export declare function toBuffer(value: number | string | Buffer): Buffer;
