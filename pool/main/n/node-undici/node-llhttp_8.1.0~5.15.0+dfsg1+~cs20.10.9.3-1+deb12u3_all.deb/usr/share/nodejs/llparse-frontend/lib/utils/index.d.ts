export { Identifier, IUniqueName } from './identifier';
export declare function toCacheKey(value: number | boolean): string;
