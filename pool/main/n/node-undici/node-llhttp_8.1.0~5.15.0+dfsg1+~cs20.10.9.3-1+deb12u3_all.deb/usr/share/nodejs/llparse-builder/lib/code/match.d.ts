import { Code } from './base';
export declare class Match extends Code {
    constructor(name: string);
}
