export declare abstract class Transform {
    readonly name: string;
    constructor(name: string);
}
