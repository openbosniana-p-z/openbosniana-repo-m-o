import { CompactSign } from "../jws/compact/sign.js";
import { JWTInvalid } from "../util/errors.js";
import { encoder } from "../lib/buffer_utils.js";
import { ProduceJWT } from "./produce.js";
class SignJWT extends ProduceJWT {
  /**
   * Sets the JWS Protected Header on the SignJWT object.
   *
   * @param protectedHeader JWS Protected Header. Must contain an "alg" (JWS Algorithm) property.
   */
  setProtectedHeader(protectedHeader) {
    this._protectedHeader = protectedHeader;
    return this;
  }
  /**
   * Signs and returns the JWT.
   *
   * @param key Private Key or Secret to sign the JWT with.
   * @param options JWT Sign options.
   */
  async sign(key, options) {
    var _a;
    const sig = new CompactSign(encoder.encode(JSON.stringify(this._payload)));
    sig.setProtectedHeader(this._protectedHeader);
    if (Array.isArray((_a = this._protectedHeader) == null ? void 0 : _a.crit) && this._protectedHeader.crit.includes("b64") && // @ts-expect-error
    this._protectedHeader.b64 === false) {
      throw new JWTInvalid("JWTs MUST NOT use unencoded payload");
    }
    return sig.sign(key, options);
  }
}
export {
  SignJWT
};
