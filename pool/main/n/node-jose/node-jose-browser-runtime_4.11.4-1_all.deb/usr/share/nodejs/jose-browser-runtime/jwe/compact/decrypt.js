import { flattenedDecrypt } from "../flattened/decrypt.js";
import { JWEInvalid } from "../../util/errors.js";
import { decoder } from "../../lib/buffer_utils.js";
async function compactDecrypt(jwe, key, options) {
  if (jwe instanceof Uint8Array) {
    jwe = decoder.decode(jwe);
  }
  if (typeof jwe !== "string") {
    throw new JWEInvalid("Compact JWE must be a string or Uint8Array");
  }
  const {
    0: protectedHeader,
    1: encryptedKey,
    2: iv,
    3: ciphertext,
    4: tag,
    length
  } = jwe.split(".");
  if (length !== 5) {
    throw new JWEInvalid("Invalid Compact JWE");
  }
  const decrypted = await flattenedDecrypt(
    {
      ciphertext,
      iv: iv || void 0,
      protected: protectedHeader || void 0,
      tag: tag || void 0,
      encrypted_key: encryptedKey || void 0
    },
    key,
    options
  );
  const result = { plaintext: decrypted.plaintext, protectedHeader: decrypted.protectedHeader };
  if (typeof key === "function") {
    return { ...result, key: decrypted.key };
  }
  return result;
}
export {
  compactDecrypt
};
