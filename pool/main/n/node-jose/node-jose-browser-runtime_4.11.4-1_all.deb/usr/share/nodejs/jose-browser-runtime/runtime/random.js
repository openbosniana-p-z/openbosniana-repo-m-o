import crypto from "./webcrypto.js";
var random_default = crypto.getRandomValues.bind(crypto);
export {
  random_default as default
};
