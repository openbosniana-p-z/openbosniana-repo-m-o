import * as base64url from "../runtime/base64url.js";
const encode = base64url.encode;
const decode = base64url.decode;
export {
  decode,
  encode
};
