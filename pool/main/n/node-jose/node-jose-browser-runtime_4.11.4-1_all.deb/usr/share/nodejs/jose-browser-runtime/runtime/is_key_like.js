import { isCryptoKey } from "./webcrypto.js";
var is_key_like_default = (key) => {
  return isCryptoKey(key);
};
const types = ["CryptoKey"];
export {
  is_key_like_default as default,
  types
};
