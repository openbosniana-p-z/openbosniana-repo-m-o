var webcrypto_default = crypto;
const isCryptoKey = (key) => key instanceof CryptoKey;
export {
  webcrypto_default as default,
  isCryptoKey
};
