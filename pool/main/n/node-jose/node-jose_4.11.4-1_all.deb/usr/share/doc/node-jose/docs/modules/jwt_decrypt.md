# Module: jwt/decrypt

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [jwtDecrypt](../functions/jwt_decrypt.jwtDecrypt.md)

### Interfaces

- [JWTDecryptGetKey](../interfaces/jwt_decrypt.JWTDecryptGetKey.md)
- [JWTDecryptOptions](../interfaces/jwt_decrypt.JWTDecryptOptions.md)
