# Module: jwks/remote

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [createRemoteJWKSet](../functions/jwks_remote.createRemoteJWKSet.md)

### Interfaces

- [RemoteJWKSetOptions](../interfaces/jwks_remote.RemoteJWKSetOptions.md)
