# Module: jwe/compact/encrypt

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Classes

- [CompactEncrypt](../classes/jwe_compact_encrypt.CompactEncrypt.md)
