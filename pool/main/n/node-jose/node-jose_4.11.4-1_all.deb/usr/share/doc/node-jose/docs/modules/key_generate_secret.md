# Module: key/generate\_secret

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [generateSecret](../functions/key_generate_secret.generateSecret.md)

### Interfaces

- [GenerateSecretOptions](../interfaces/key_generate_secret.GenerateSecretOptions.md)
