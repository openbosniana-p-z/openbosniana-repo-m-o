# Module: jws/general/verify

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [generalVerify](../functions/jws_general_verify.generalVerify.md)

### Interfaces

- [GeneralVerifyGetKey](../interfaces/jws_general_verify.GeneralVerifyGetKey.md)
