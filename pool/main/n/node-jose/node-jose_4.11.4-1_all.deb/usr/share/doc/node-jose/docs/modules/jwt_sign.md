# Module: jwt/sign

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Classes

- [SignJWT](../classes/jwt_sign.SignJWT.md)
