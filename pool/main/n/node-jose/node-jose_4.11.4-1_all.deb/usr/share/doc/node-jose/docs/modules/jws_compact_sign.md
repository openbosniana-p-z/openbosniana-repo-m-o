# Module: jws/compact/sign

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Classes

- [CompactSign](../classes/jws_compact_sign.CompactSign.md)
