# Module: jwe/flattened/decrypt

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [flattenedDecrypt](../functions/jwe_flattened_decrypt.flattenedDecrypt.md)

### Interfaces

- [FlattenedDecryptGetKey](../interfaces/jwe_flattened_decrypt.FlattenedDecryptGetKey.md)
