# Module: jwt/produce

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Classes

- [ProduceJWT](../classes/jwt_produce.ProduceJWT.md)
