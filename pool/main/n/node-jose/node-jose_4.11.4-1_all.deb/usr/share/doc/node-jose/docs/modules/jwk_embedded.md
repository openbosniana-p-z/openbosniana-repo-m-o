# Module: jwk/embedded

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [EmbeddedJWK](../functions/jwk_embedded.EmbeddedJWK.md)
