# Module: key/generate\_key\_pair

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [generateKeyPair](../functions/key_generate_key_pair.generateKeyPair.md)

### Interfaces

- [GenerateKeyPairOptions](../interfaces/key_generate_key_pair.GenerateKeyPairOptions.md)
- [GenerateKeyPairResult](../interfaces/key_generate_key_pair.GenerateKeyPairResult.md)
