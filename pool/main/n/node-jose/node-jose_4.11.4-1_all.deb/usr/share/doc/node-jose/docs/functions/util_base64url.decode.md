# Function: decode

[💗 Help the project](https://github.com/sponsors/panva)

▸ **decode**(`input`): `Uint8Array`

#### Parameters

| Name | Type |
| :------ | :------ |
| `input` | `string` \| `Uint8Array` |

#### Returns

`Uint8Array`
