# Module: jwe/flattened/encrypt

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Classes

- [FlattenedEncrypt](../classes/jwe_flattened_encrypt.FlattenedEncrypt.md)
