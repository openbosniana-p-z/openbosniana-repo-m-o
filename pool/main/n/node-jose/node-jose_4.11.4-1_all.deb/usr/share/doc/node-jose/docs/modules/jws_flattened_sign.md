# Module: jws/flattened/sign

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Classes

- [FlattenedSign](../classes/jws_flattened_sign.FlattenedSign.md)
