# Interface: ResolvedKey

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Properties

- [key](types.ResolvedKey.md#key)

## Properties

### key

• **key**: `Uint8Array` \| [`KeyLike`](../types/types.KeyLike.md)

Key resolved from the key resolver function.
