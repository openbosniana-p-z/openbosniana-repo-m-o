# Module: jws/compact/verify

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [compactVerify](../functions/jws_compact_verify.compactVerify.md)

### Interfaces

- [CompactVerifyGetKey](../interfaces/jws_compact_verify.CompactVerifyGetKey.md)
