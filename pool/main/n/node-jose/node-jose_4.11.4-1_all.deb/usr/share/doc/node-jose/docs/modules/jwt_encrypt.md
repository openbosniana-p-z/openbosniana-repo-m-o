# Module: jwt/encrypt

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Classes

- [EncryptJWT](../classes/jwt_encrypt.EncryptJWT.md)
