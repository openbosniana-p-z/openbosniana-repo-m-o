# Module: jwks/local

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [createLocalJWKSet](../functions/jwks_local.createLocalJWKSet.md)
