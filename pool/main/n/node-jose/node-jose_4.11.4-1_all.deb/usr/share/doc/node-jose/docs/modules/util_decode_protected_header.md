# Module: util/decode\_protected\_header

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [decodeProtectedHeader](../functions/util_decode_protected_header.decodeProtectedHeader.md)

### Type Aliases

- [ProtectedHeaderParameters](../types/util_decode_protected_header.ProtectedHeaderParameters.md)
