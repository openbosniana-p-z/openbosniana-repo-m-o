# Module: jws/general/sign

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Interfaces

- [Signature](../interfaces/jws_general_sign.Signature.md)

### Classes

- [GeneralSign](../classes/jws_general_sign.GeneralSign.md)
