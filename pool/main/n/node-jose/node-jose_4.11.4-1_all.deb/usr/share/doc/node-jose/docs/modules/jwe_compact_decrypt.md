# Module: jwe/compact/decrypt

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [compactDecrypt](../functions/jwe_compact_decrypt.compactDecrypt.md)

### Interfaces

- [CompactDecryptGetKey](../interfaces/jwe_compact_decrypt.CompactDecryptGetKey.md)
