# Module: util/base64url

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [decode](../functions/util_base64url.decode.md)
- [encode](../functions/util_base64url.encode.md)
