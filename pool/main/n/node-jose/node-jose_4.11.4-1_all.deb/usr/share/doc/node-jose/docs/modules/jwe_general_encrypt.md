# Module: jwe/general/encrypt

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Interfaces

- [Recipient](../interfaces/jwe_general_encrypt.Recipient.md)

### Classes

- [GeneralEncrypt](../classes/jwe_general_encrypt.GeneralEncrypt.md)
