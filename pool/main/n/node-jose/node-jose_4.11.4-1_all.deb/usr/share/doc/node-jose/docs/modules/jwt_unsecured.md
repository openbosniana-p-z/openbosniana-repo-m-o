# Module: jwt/unsecured

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Interfaces

- [UnsecuredResult](../interfaces/jwt_unsecured.UnsecuredResult.md)

### Classes

- [UnsecuredJWT](../classes/jwt_unsecured.UnsecuredJWT.md)
