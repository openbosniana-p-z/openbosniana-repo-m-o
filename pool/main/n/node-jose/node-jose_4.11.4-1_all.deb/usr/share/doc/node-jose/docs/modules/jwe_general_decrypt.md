# Module: jwe/general/decrypt

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [generalDecrypt](../functions/jwe_general_decrypt.generalDecrypt.md)

### Interfaces

- [GeneralDecryptGetKey](../interfaces/jwe_general_decrypt.GeneralDecryptGetKey.md)
