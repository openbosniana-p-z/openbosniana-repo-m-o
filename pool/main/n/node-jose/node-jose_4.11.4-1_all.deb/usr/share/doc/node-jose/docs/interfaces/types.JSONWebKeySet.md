# Interface: JSONWebKeySet

[💗 Help the project](https://github.com/sponsors/panva)

JSON Web Key Set

## Table of contents

### Properties

- [keys](types.JSONWebKeySet.md#keys)

## Properties

### keys

• **keys**: [`JWK`](types.JWK.md)[]
