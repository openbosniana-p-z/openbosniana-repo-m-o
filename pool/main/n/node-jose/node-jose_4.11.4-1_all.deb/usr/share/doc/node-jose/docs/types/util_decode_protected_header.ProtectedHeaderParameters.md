# Type alias: ProtectedHeaderParameters

[💗 Help the project](https://github.com/sponsors/panva)

Ƭ **ProtectedHeaderParameters**: [`JWSHeaderParameters`](../interfaces/types.JWSHeaderParameters.md) & [`JWEHeaderParameters`](../interfaces/types.JWEHeaderParameters.md)
