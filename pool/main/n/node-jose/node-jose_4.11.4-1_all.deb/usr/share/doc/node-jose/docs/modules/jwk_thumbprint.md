# Module: jwk/thumbprint

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [calculateJwkThumbprint](../functions/jwk_thumbprint.calculateJwkThumbprint.md)
- [calculateJwkThumbprintUri](../functions/jwk_thumbprint.calculateJwkThumbprintUri.md)
