# Function: encode

[💗 Help the project](https://github.com/sponsors/panva)

▸ **encode**(`input`): `string`

#### Parameters

| Name | Type |
| :------ | :------ |
| `input` | `string` \| `Uint8Array` |

#### Returns

`string`
