# Module: jws/flattened/verify

[💗 Help the project](https://github.com/sponsors/panva)

## Table of contents

### Functions

- [flattenedVerify](../functions/jws_flattened_verify.flattenedVerify.md)

### Interfaces

- [FlattenedVerifyGetKey](../interfaces/jws_flattened_verify.FlattenedVerifyGetKey.md)
