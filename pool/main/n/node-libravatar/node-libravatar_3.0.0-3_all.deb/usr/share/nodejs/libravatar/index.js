module.exports = require('./lib/libravatar');
