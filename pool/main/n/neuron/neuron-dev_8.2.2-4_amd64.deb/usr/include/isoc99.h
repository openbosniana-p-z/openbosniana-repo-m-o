#ifndef NRN_ISOC99_H
#define NRN_ISOC99_H

extern "C" int nrn_isdouble(double* pd, double min, double max);

#endif  // NRN_ISOC99_H
