#pragma once
#define NRN_VERSION_MAJOR 8
#define NRN_VERSION_MINOR 2
#define NRN_VERSION_PATCH 2
