/* define to 1 if allowing NEOSIM */
/* #undef USENEOSIM */
/* define to 1 if allowing NCS */
/* #undef USENCS */
/* define to 1 (default) if Observer is a base class of DiscreteEvent */
#define DISCRETE_EVENT_OBSERVER 1
