#ifndef nrnpthread_h
#define nrnpthread_h

/* Configure with use_pthread=no if pthread.h exists but you do not want to use it */
#define USE_PTHREAD 1

#endif
