"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.create = exports.FreeStyle = exports.Rule = exports.Style = exports.Selector = exports.Cache = void 0;
/**
 * The unique id is used for unique hashes.
 */
var uniqueId = 0;
/**
 * Quick dictionary lookup for unit-less numbers.
 */
var CSS_NUMBER = Object.create(null);
/**
 * CSS properties that are valid unit-less numbers.
 *
 * Ref: https://github.com/facebook/react/blob/master/packages/react-dom/src/shared/CSSProperty.js
 */
var CSS_NUMBER_KEYS = [
    "animation-iteration-count",
    "border-image-outset",
    "border-image-slice",
    "border-image-width",
    "box-flex",
    "box-flex-group",
    "box-ordinal-group",
    "column-count",
    "columns",
    "counter-increment",
    "counter-reset",
    "flex",
    "flex-grow",
    "flex-positive",
    "flex-shrink",
    "flex-negative",
    "flex-order",
    "font-weight",
    "grid-area",
    "grid-column",
    "grid-column-end",
    "grid-column-span",
    "grid-column-start",
    "grid-row",
    "grid-row-end",
    "grid-row-span",
    "grid-row-start",
    "line-clamp",
    "line-height",
    "opacity",
    "order",
    "orphans",
    "tab-size",
    "widows",
    "z-index",
    "zoom",
    // SVG properties.
    "fill-opacity",
    "flood-opacity",
    "stop-opacity",
    "stroke-dasharray",
    "stroke-dashoffset",
    "stroke-miterlimit",
    "stroke-opacity",
    "stroke-width",
];
// Add vendor prefixes to all unit-less properties.
for (var _i = 0, CSS_NUMBER_KEYS_1 = CSS_NUMBER_KEYS; _i < CSS_NUMBER_KEYS_1.length; _i++) {
    var property = CSS_NUMBER_KEYS_1[_i];
    for (var _a = 0, _b = ["-webkit-", "-ms-", "-moz-", "-o-", ""]; _a < _b.length; _a++) {
        var prefix = _b[_a];
        CSS_NUMBER[prefix + property] = true;
    }
}
/**
 * Escape a CSS class name.
 */
function escape(str) {
    return str.replace(/[ !#$%&()*+,./;<=>?@[\]^`{|}~"'\\]/g, "\\$&");
}
/**
 * Interpolate the `&` with style name.
 */
function interpolate(selector, styleName) {
    return selector.replace(/&/g, styleName);
}
/**
 * Transform a JavaScript property into a CSS property.
 */
function hyphenate(propertyName) {
    return propertyName
        .replace(/[A-Z]/g, function (m) { return "-".concat(m.toLowerCase()); })
        .replace(/^ms-/, "-ms-"); // Internet Explorer vendor prefix.
}
/**
 * Generate a hash value from a string.
 */
function stringHash(str) {
    var value = 5381;
    var len = str.length;
    while (len--)
        value = (value * 33) ^ str.charCodeAt(len);
    return (value >>> 0).toString(36);
}
/**
 * Interpolate CSS selectors.
 */
function child(selector, parent) {
    if (selector.indexOf("&") === -1)
        return "".concat(parent, " ").concat(selector);
    return interpolate(selector, parent);
}
/**
 * Implement a stable sort by falling back on a third numeric property.
 *
 * Node.js < 12 and IE do not support stable sort.
 */
function tupleSort(a, b) {
    return a[0] > b[0] ? 1 : a[0] < b[0] ? -1 : a[2] - b[2];
}
/**
 * Transform a style string to a CSS string.
 */
function tupleToStyle(_a) {
    var name = _a[0], value = _a[1];
    if (typeof value === "number" && value && !CSS_NUMBER[name]) {
        return "".concat(name, ":").concat(value, "px");
    }
    return "".concat(name, ":").concat(String(value));
}
/**
 * Recursive loop building styles with deferred selectors.
 */
function stylize(rulesList, stylesList, key, styles, parentClassName) {
    var properties = [];
    var nestedStyles = [];
    // Sort keys before adding to styles.
    for (var _i = 0, _a = Object.keys(styles); _i < _a.length; _i++) {
        var key_1 = _a[_i];
        var value = styles[key_1];
        if (key_1.charCodeAt(0) !== 36 /* $ */ && value != null) {
            if (Array.isArray(value)) {
                var name = hyphenate(key_1);
                for (var i = 0; i < value.length; i++) {
                    var style_1 = value[i];
                    if (style_1 != null)
                        properties.push([name, style_1, i]);
                }
            }
            else if (typeof value === "object") {
                nestedStyles.push([key_1, value, 0]);
            }
            else {
                properties.push([hyphenate(key_1), value, 0]);
            }
        }
    }
    var isUnique = !!styles.$unique;
    var parent = styles.$global ? "" : parentClassName;
    var nested = parent ? nestedStyles : nestedStyles.sort(tupleSort);
    var style = properties.sort(tupleSort).map(tupleToStyle).join(";");
    var pid = style;
    var selector = parent;
    var childRules = rulesList;
    var childStyles = stylesList;
    if (key.charCodeAt(0) === 64 /* @ */) {
        childRules = [];
        childStyles = [];
        // Nested styles support (e.g. `.foo > @media`).
        if (parent && style) {
            childStyles.push({ selector: selector, style: style, isUnique: isUnique });
        }
        // Add new rule to parent.
        rulesList.push({
            selector: key,
            rules: childRules,
            styles: childStyles,
            style: parent ? "" : style,
        });
    }
    else {
        selector = parent ? (key ? child(key, parent) : parent) : key;
        if (style) {
            stylesList.push({ selector: selector, style: style, isUnique: isUnique });
        }
    }
    for (var _b = 0, nested_1 = nested; _b < nested_1.length; _b++) {
        var _c = nested_1[_b], name = _c[0], value = _c[1];
        pid += "|".concat(name, "#").concat(stylize(childRules, childStyles, name, value, selector));
    }
    return pid;
}
/**
 * Transform `stylize` tree into style objects.
 */
function compose(cache, rulesList, stylesList, id, name) {
    for (var _i = 0, stylesList_1 = stylesList; _i < stylesList_1.length; _i++) {
        var _a = stylesList_1[_i], selector = _a.selector, style = _a.style, isUnique = _a.isUnique;
        var key = interpolate(selector, name);
        var item = new Style(style, isUnique ? (++uniqueId).toString(36) : id);
        item.add(new Selector(key));
        cache.add(item);
    }
    for (var _b = 0, rulesList_1 = rulesList; _b < rulesList_1.length; _b++) {
        var _c = rulesList_1[_b], selector = _c.selector, style = _c.style, rules = _c.rules, styles = _c.styles;
        var key = interpolate(selector, name);
        var item = new Rule(key, style, id);
        compose(item, rules, styles, id, name);
        cache.add(item);
    }
}
/**
 * Cache to list to styles.
 */
function join(arr) {
    var res = "";
    for (var i = 0; i < arr.length; i++)
        res += arr[i];
    return res;
}
/**
 * Implement a cache/event emitter.
 */
var Cache = /** @class */ (function () {
    function Cache(changes) {
        this.changes = changes;
        this.sheet = [];
        this.changeId = 0;
        this._keys = [];
        this._children = Object.create(null);
        this._counters = Object.create(null);
    }
    Cache.prototype.add = function (style) {
        var id = style.id;
        var count = this._counters[id] || 0;
        var item = this._children[id] || style.clone();
        this._counters[id] = count + 1;
        if (count === 0) {
            this._children[id] = item;
            this._keys.push(id);
            this.sheet.push(item.getStyles());
            this.changeId++;
            if (this.changes)
                this.changes.add(item, this._keys.length - 1);
        }
        else if (item instanceof Cache && style instanceof Cache) {
            var prevItemChangeId = item.changeId;
            item.merge(style);
            if (item.changeId !== prevItemChangeId) {
                var index = this._keys.indexOf(id);
                this.sheet.splice(index, 1, item.getStyles());
                this.changeId++;
                if (this.changes)
                    this.changes.change(item, index, index);
            }
        }
    };
    Cache.prototype.remove = function (style) {
        var id = style.id;
        var count = this._counters[id];
        if (count) {
            this._counters[id] = count - 1;
            var item = this._children[id];
            var index = this._keys.indexOf(id);
            if (count === 1) {
                delete this._counters[id];
                delete this._children[id];
                this._keys.splice(index, 1);
                this.sheet.splice(index, 1);
                this.changeId++;
                if (this.changes)
                    this.changes.remove(item, index);
            }
            else if (item instanceof Cache && style instanceof Cache) {
                var prevChangeId = item.changeId;
                item.unmerge(style);
                if (item.changeId !== prevChangeId) {
                    this.sheet.splice(index, 1, item.getStyles());
                    this.changeId++;
                    if (this.changes)
                        this.changes.change(item, index, index);
                }
            }
        }
    };
    Cache.prototype.values = function () {
        var _this = this;
        return this._keys.map(function (key) { return _this._children[key]; });
    };
    Cache.prototype.merge = function (cache) {
        for (var _i = 0, _a = cache.values(); _i < _a.length; _i++) {
            var item = _a[_i];
            this.add(item);
        }
        return this;
    };
    Cache.prototype.unmerge = function (cache) {
        for (var _i = 0, _a = cache.values(); _i < _a.length; _i++) {
            var item = _a[_i];
            this.remove(item);
        }
        return this;
    };
    Cache.prototype.clone = function () {
        return new Cache().merge(this);
    };
    return Cache;
}());
exports.Cache = Cache;
/**
 * Selector is a dumb class made to represent nested CSS selectors.
 */
var Selector = /** @class */ (function () {
    function Selector(selector) {
        this.selector = selector;
    }
    Object.defineProperty(Selector.prototype, "id", {
        get: function () {
            return "k:".concat(this.selector);
        },
        enumerable: false,
        configurable: true
    });
    Selector.prototype.getStyles = function () {
        return this.selector;
    };
    Selector.prototype.clone = function () {
        return this;
    };
    return Selector;
}());
exports.Selector = Selector;
/**
 * The style container registers a style string with selectors.
 */
var Style = /** @class */ (function (_super) {
    __extends(Style, _super);
    function Style(style, pid) {
        var _this = _super.call(this) || this;
        _this.style = style;
        _this.pid = pid;
        return _this;
    }
    Object.defineProperty(Style.prototype, "id", {
        get: function () {
            return "s:".concat(this.pid, ":").concat(this.style);
        },
        enumerable: false,
        configurable: true
    });
    Style.prototype.getStyles = function () {
        return "".concat(this.sheet.join(","), "{").concat(this.style, "}");
    };
    Style.prototype.clone = function () {
        return new Style(this.style, this.pid).merge(this);
    };
    return Style;
}(Cache));
exports.Style = Style;
/**
 * Implement rule logic for style output.
 */
var Rule = /** @class */ (function (_super) {
    __extends(Rule, _super);
    function Rule(rule, style, pid) {
        var _this = _super.call(this) || this;
        _this.rule = rule;
        _this.style = style;
        _this.pid = pid;
        return _this;
    }
    Object.defineProperty(Rule.prototype, "id", {
        get: function () {
            return "r:".concat(this.pid, ":").concat(this.rule, ":").concat(this.style);
        },
        enumerable: false,
        configurable: true
    });
    Rule.prototype.getStyles = function () {
        return "".concat(this.rule, "{").concat(this.style).concat(join(this.sheet), "}");
    };
    Rule.prototype.clone = function () {
        return new Rule(this.rule, this.style, this.pid).merge(this);
    };
    return Rule;
}(Cache));
exports.Rule = Rule;
/**
 * The FreeStyle class implements the API for everything else.
 */
var FreeStyle = /** @class */ (function (_super) {
    __extends(FreeStyle, _super);
    function FreeStyle(id, changes) {
        var _this = _super.call(this, changes) || this;
        _this.id = id;
        return _this;
    }
    FreeStyle.prototype.registerStyle = function (styles) {
        var ruleList = [];
        var styleList = [];
        var pid = stylize(ruleList, styleList, "", styles, ".&");
        var id = "f".concat(stringHash(pid));
        if (process.env.NODE_ENV !== "production" && styles.$displayName) {
            var name = "".concat(styles.$displayName, "_").concat(id);
            compose(this, ruleList, styleList, id, escape(name));
            return name;
        }
        compose(this, ruleList, styleList, id, id);
        return id;
    };
    FreeStyle.prototype.getStyles = function () {
        return join(this.sheet);
    };
    FreeStyle.prototype.clone = function () {
        return new FreeStyle(this.id, this.changes).merge(this);
    };
    return FreeStyle;
}(Cache));
exports.FreeStyle = FreeStyle;
/**
 * Exports a simple function to create a new instance.
 */
function create(changes) {
    return new FreeStyle("f".concat((++uniqueId).toString(36)), changes);
}
exports.create = create;
//# sourceMappingURL=index.js.map