export { NumberAllocator } from './lib/number-allocator'
