export default function(target, type, selection) {
  this.target = target;
  this.type = type;
  this.selection = selection;
}
