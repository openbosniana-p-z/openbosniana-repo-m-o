# tinycolor #

This is a no-fuzz, barebone, zero muppetry color module for node.js.