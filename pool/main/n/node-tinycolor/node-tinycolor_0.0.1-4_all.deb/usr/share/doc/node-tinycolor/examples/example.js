require('./tinycolor');
console.log('this should be red and have an underline!'.grey.underline);
console.log('this should have a blue background!'.bgBlue);