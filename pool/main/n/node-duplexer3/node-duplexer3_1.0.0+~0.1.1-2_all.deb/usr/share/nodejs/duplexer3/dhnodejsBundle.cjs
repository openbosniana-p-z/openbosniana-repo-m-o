Object.defineProperty(exports, '__esModule', { value: true });

var stream = require('stream');

function _interopDefault (e) { return e && e.__esModule ? e : { default: e }; }

var stream__default = /*#__PURE__*/_interopDefault(stream);

function DuplexWrapper(options, writable, readable) {
	if (typeof readable === 'undefined') {
		readable = writable;
		writable = options;
		options = undefined;
	}

	stream__default.default.Duplex.call(this, options);

	if (typeof readable.read !== 'function') {
		readable = (new stream__default.default.Readable(options)).wrap(readable);
	}

	this._writable = writable;
	this._readable = readable;
	this._waiting = false;

	writable.once('finish', () => {
		this.end();
	});

	this.once('finish', () => {
		writable.end();
	});

	readable.on('readable', () => {
		if (this._waiting) {
			this._waiting = false;
			this._read();
		}
	});

	readable.once('end', () => {
		this.push(null);
	});

	if (!options || typeof options.bubbleErrors === 'undefined' || options.bubbleErrors) {
		writable.on('error', error => {
			this.emit('error', error);
		});

		readable.on('error', error => {
			this.emit('error', error);
		});
	}
}

DuplexWrapper.prototype = Object.create(stream__default.default.Duplex.prototype, {constructor: {value: DuplexWrapper}});

DuplexWrapper.prototype._write = function (input, encoding, done) {
	this._writable.write(input, encoding, done);
};

DuplexWrapper.prototype._read = function () {
	let buffer;
	let readCount = 0;
	while ((buffer = this._readable.read()) !== null) {
		this.push(buffer);
		readCount++;
	}

	if (readCount === 0) {
		this._waiting = true;
	}
};

function duplexer(options, writable, readable) {
	return new DuplexWrapper(options, writable, readable);
}

exports.DuplexWrapper = DuplexWrapper;
exports.default = duplexer;
