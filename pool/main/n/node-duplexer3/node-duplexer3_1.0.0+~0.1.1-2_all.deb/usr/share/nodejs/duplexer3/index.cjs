const m=require('./dhnodejsBundle.cjs')
const r=m.default;
Object.keys(m).forEach(k => {
  r[k]=m[k];
});
module.exports = r
