export declare const colorStringRegExp: RegExp;
export declare const colorStringAlphaRegExp: RegExp;
export declare const base64RegExp: RegExp;
export declare const uuid4RegExp: RegExp;
export declare const iso8601RegExp: RegExp;
