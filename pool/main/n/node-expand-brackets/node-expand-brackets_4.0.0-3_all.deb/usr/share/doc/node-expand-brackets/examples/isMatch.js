'use strict';

var brackets = require('..');

console.log(brackets.isMatch('1.2', '[[:alpha:]].[[:alpha:]]'));
