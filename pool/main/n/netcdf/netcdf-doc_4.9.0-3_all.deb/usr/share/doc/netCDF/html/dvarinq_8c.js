var dvarinq_8c =
[
    [ "nc_inq_unlimdims", "group__variables.html#ga11f93294c8a4c007f637695aa56c7223", null ],
    [ "nc_inq_var", "group__variables.html#ga96d4a6d7b778be4c3f587e7d5b2650f1", null ],
    [ "nc_inq_var_chunking", "group__variables.html#gac032fa5af90c7cbf0147ed745e49adad", null ],
    [ "nc_inq_var_deflate", "group__variables.html#ga23ada36ecd3d157aad489fb9125a5dc2", null ],
    [ "nc_inq_var_endian", "group__variables.html#ga036b23fb5e75abc94f5e30ecda606abe", null ],
    [ "nc_inq_var_fill", "group__variables.html#gaf4a2635933f4b58a5cc2025e4e2e120f", null ],
    [ "nc_inq_var_fletcher32", "group__variables.html#ga2e4999ccf1df31d8aebcc0989913bccc", null ],
    [ "nc_inq_var_quantize", "group__variables.html#ga1a33f31de49b6f5937103c2ede06cc5f", null ],
    [ "nc_inq_var_szip", "group__variables.html#ga980ff1fac75620f2151e696a6443d025", null ],
    [ "nc_inq_vardimid", "group__variables.html#gaa15ff7ff987ca6b1760447da955eb137", null ],
    [ "nc_inq_varid", "group__variables.html#ga3ab100e1a6b75b15deec7b1a5c6c9d92", null ],
    [ "nc_inq_varname", "group__variables.html#ga121d13bce28dd6f72e74be80dbb0d4e5", null ],
    [ "nc_inq_varnatts", "group__variables.html#ga4df3b5bbf48e98cbd6847bd24f072ec8", null ],
    [ "nc_inq_varndims", "group__variables.html#ga045123c8084dd019fc87213f5cf9d500", null ],
    [ "nc_inq_vartype", "group__variables.html#ga299c12093fb0725273b59ea9b3ca1684", null ]
];