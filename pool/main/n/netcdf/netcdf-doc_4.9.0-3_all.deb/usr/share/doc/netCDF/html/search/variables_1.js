var searchData=
[
  ['nc_5finitialized_0',['NC_initialized',['../dfile_8c.html#ab7f0d8e956305b5240f451b481323c3c',1,'dfile.c']]],
  ['ncerr_1',['ncerr',['../dv2i_8c.html#a5d6516e4878a9547338e640bb5fcd241',1,'dv2i.c']]],
  ['ncopts_2',['ncopts',['../netcdf_8h.html#a67517ad315806d931efa3fc63989266c',1,'ncopts():&#160;netcdf.h'],['../dv2i_8c.html#ad666765b7d4bbdd6a39ad40e7ee3c73a',1,'ncopts():&#160;dv2i.c']]]
];
