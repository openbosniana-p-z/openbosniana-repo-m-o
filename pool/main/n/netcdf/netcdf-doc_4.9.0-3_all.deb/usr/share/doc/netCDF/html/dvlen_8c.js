var dvlen_8c =
[
    [ "nc_def_vlen", "group__user__types.html#ga51fc6e88b172a3ba278c7060bedd08ff", null ],
    [ "nc_free_vlen", "group__user__types.html#ga6b66ea3c91077a68182bfc401c6ce0a6", null ],
    [ "nc_free_vlens", "group__user__types.html#ga9ead9b1beac343be4b1471241794502a", null ],
    [ "nc_inq_vlen", "group__user__types.html#ga79f9197957b425933c43f4dac4e70280", null ]
];