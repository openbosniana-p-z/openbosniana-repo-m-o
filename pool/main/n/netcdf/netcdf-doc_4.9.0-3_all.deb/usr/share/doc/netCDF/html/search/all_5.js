var searchData=
[
  ['error_20handling_0',['Error Handling',['../error_handling.html',1,'tutorial.dox']]],
  ['externl_1',['EXTERNL',['../netcdf_8h.html#a642c2ebcdafb48642490d3a498b81d4c',1,'netcdf.h']]]
];
