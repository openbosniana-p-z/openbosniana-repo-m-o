var searchData=
[
  ['check_5fcreate_5fmode_0',['check_create_mode',['../dfile_8c.html#ab961bbb024f23ccf632c8610b5ac06c0',1,'dfile.c']]],
  ['copyright_1',['COPYRIGHT',['../copyright.html',1,'']]],
  ['creating_20new_20files_20and_20metadata_2c_20an_20overview_2',['Creating New Files and Metadata, an Overview',['../creating.html',1,'tutorial.dox']]]
];
