var nc4var_8c =
[
    [ "BIT_XPL_NBR_SGN_DBL", "nc4var_8c.html#a6599eaf56c5b987489f5a8feebaac7d9", null ],
    [ "BIT_XPL_NBR_SGN_FLT", "nc4var_8c.html#a9fc90250fb8464e58dd765d863433edc", null ],
    [ "M_LN10", "nc4var_8c.html#a0a53871497a155afe91424c28a8ec3c4", null ],
    [ "M_LN2", "nc4var_8c.html#a92428112a5d24721208748774a4f23e6", null ]
];