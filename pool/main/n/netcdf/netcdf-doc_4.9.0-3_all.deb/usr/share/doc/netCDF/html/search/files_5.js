var searchData=
[
  ['sfc_5fpres_5ftemp_5frd_2ec_0',['sfc_pres_temp_rd.c',['../sfc__pres__temp__rd_8c.html',1,'']]],
  ['sfc_5fpres_5ftemp_5fwr_2ec_1',['sfc_pres_temp_wr.c',['../sfc__pres__temp__wr_8c.html',1,'']]],
  ['simple_5fnc4_5frd_2ec_2',['simple_nc4_rd.c',['../simple__nc4__rd_8c.html',1,'']]],
  ['simple_5fnc4_5fwr_2ec_3',['simple_nc4_wr.c',['../simple__nc4__wr_8c.html',1,'']]],
  ['simple_5fxy_5fnc4_5frd_2ec_4',['simple_xy_nc4_rd.c',['../simple__xy__nc4__rd_8c.html',1,'']]],
  ['simple_5fxy_5fnc4_5fwr_2ec_5',['simple_xy_nc4_wr.c',['../simple__xy__nc4__wr_8c.html',1,'']]],
  ['simple_5fxy_5frd_2ec_6',['simple_xy_rd.c',['../simple__xy__rd_8c.html',1,'']]],
  ['simple_5fxy_5fwr_2ec_7',['simple_xy_wr.c',['../simple__xy__wr_8c.html',1,'']]]
];
