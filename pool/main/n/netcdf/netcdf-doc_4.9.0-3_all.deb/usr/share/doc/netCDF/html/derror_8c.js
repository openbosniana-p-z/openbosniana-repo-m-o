var derror_8c =
[
    [ "nc_inq_libvers", "derror_8c.html#a457f64eb88599d02c0e786b1221dd9b3", null ],
    [ "nc_strerror", "group__error.html#ga1d965e9202ac294fded38809ec834c1c", null ]
];