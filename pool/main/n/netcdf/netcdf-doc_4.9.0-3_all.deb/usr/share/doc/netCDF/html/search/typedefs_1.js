var searchData=
[
  ['schar_0',['schar',['../dv2i_8c.html#a0fd9ce9d735064461bebfe6037026093',1,'dv2i.c']]]
];
