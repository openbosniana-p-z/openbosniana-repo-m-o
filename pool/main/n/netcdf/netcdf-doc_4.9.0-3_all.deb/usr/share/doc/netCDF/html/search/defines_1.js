var searchData=
[
  ['a_5ffree_0',['A_FREE',['../dv2i_8c.html#ad74ac22ed8a0335e0704cd41f57dc3c4',1,'dv2i.c']]],
  ['a_5finit_1',['A_INIT',['../dv2i_8c.html#a7ec60eaf8b00e5de57709606aa05bde3',1,'dv2i.c']]]
];
