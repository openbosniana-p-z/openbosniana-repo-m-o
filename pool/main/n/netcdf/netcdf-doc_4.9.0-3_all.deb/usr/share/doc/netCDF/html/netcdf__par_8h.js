var netcdf__par_8h =
[
    [ "NC_COLLECTIVE", "netcdf__par_8h.html#a7431665c6bf7b168d976a257dd5bf538", null ],
    [ "NC_INDEPENDENT", "netcdf__par_8h.html#aed1f11d39ef62692c0621a004e413695", null ],
    [ "nc_create_par", "group__datasets.html#ga5e03371d14dfac165734b3d0d2c3adc6", null ],
    [ "nc_create_par_fortran", "group__datasets.html#gaa3cdb3059f7c9aedddea37c90a173ca0", null ],
    [ "nc_open_par", "group__datasets.html#ga019098e9d5265006a11c9a841eb81b74", null ],
    [ "nc_open_par_fortran", "group__datasets.html#ga8e38c3c46bb1871f841ddd8e811dbed5", null ],
    [ "nc_var_par_access", "group__datasets.html#ga6dc46e4ab82584360518db5cb0cad841", null ]
];