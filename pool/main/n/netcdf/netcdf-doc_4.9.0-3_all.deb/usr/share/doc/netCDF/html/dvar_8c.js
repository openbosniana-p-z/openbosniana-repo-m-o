var dvar_8c =
[
    [ "nc_def_var", "group__variables.html#gac7e8662c51f3bb07d1fc6d6c6d9052c8", null ],
    [ "nc_def_var_chunking", "group__variables.html#gae6439bae5a863994a175ac65f6e97b71", null ],
    [ "nc_def_var_deflate", "group__variables.html#ga59dad3301f241a7eb86f31b339af2d26", null ],
    [ "nc_def_var_endian", "group__variables.html#ga0d31c75b8e73ea91e19f4de4c706bcca", null ],
    [ "nc_def_var_fill", "group__variables.html#gabe75b6aa066e6b10a8cf644fb1c55f83", null ],
    [ "nc_def_var_fletcher32", "group__variables.html#ga65ddd594d4c0398c10348f2750e05069", null ],
    [ "nc_def_var_quantize", "group__variables.html#ga669e4b23b9b7fb321b995982972cdd93", null ],
    [ "nc_def_var_szip", "group__variables.html#ga1d2c0135c3f6aeb2458b470486f80e9a", null ],
    [ "nc_free_string", "group__variables.html#ga1550362159c34d6e39729b5376def82c", null ],
    [ "nc_get_var_chunk_cache", "group__variables.html#gae6b59e92d1140b5fec56481b0f41b610", null ],
    [ "nc_rename_var", "group__variables.html#gaca781f9f72b189d1eeb2a949c300324e", null ],
    [ "nc_set_var_chunk_cache", "group__variables.html#ga2788cbfc6880ec70c304292af2bc7546", null ]
];