var searchData=
[
  ['the_20netcdf_20data_20model_0',['The NetCDF Data Model',['../netcdf_data_model.html',1,'tutorial.dox']]],
  ['the_20netcdf_20nczarr_20implementation_1',['The NetCDF NCZarr Implementation',['../md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html',1,'']]],
  ['the_20netcdf_20programming_20apis_2',['The NetCDF Programming APIs',['../netcdf_apis.html',1,'tutorial.dox']]],
  ['the_20netcdf_2dc_20tutorial_3',['The NetCDF-C Tutorial',['../tutorial_8dox.html',1,'']]]
];
