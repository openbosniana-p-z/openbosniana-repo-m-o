var dfilter_8c =
[
    [ "nc_def_var_blosc", "group__variables.html#ga59cc48a864c142ebd5897779ed703006", null ],
    [ "nc_def_var_bzip2", "dfilter_8c.html#a88189edd7b1d51b5d46b7ad6fe0c9c69", null ],
    [ "nc_def_var_filter", "dfilter_8c.html#ae020dba94fd11013be88a810f74548b2", null ],
    [ "nc_def_var_zstandard", "dfilter_8c.html#a2841c7012840195954194f51f9750817", null ],
    [ "nc_inq_filter_avail", "dfilter_8c.html#a9138a7a60876e7b9dbba0d6625a8767c", null ],
    [ "nc_inq_var_blosc", "dfilter_8c.html#a27cdad27aba57bb9a3b978caa71e6f16", null ],
    [ "nc_inq_var_bzip2", "dfilter_8c.html#a5f97d0b4949f82cfb8c6238bc32640ae", null ],
    [ "nc_inq_var_filter", "group__variables.html#ga9e5527da0854f7ec5d95419dab885594", null ],
    [ "nc_inq_var_filter_ids", "group__variables.html#gadb6b0584c25010e7310528659c7e1f30", null ],
    [ "nc_inq_var_filter_info", "group__variables.html#ga8515ac4283164fb220bd3809eec2ad39", null ],
    [ "nc_inq_var_zstandard", "dfilter_8c.html#aaeaf2c244842189fea0e28bd37bff0ef", null ]
];