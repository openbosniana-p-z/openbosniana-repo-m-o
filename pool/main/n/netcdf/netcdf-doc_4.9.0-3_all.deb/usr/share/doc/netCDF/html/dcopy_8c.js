var dcopy_8c =
[
    [ "NC_copy_att", "dcopy_8c.html#aaa0dbe2f14f3b84ea4fca252954ade0f", null ],
    [ "nc_copy_att", "dcopy_8c.html#a4b5807c452e6792b84d0086dd28128b1", null ],
    [ "nc_copy_var", "dcopy_8c.html#a0e56756107114ced0c3bf727752ff1ac", null ]
];