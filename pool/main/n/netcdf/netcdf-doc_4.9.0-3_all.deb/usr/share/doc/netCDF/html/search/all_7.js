var searchData=
[
  ['groups_0',['Groups',['../group__groups.html',1,'(Global Namespace)'],['../groups.html',1,'tutorial.dox']]]
];
