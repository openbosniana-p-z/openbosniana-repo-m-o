var dgroup_8c =
[
    [ "nc_def_grp", "group__groups.html#gab44c2c921edb7a5f5570842b86cafa01", null ],
    [ "nc_inq_dimids", "group__groups.html#ga32c50c1c7ad61d071574f99458b51601", null ],
    [ "nc_inq_grp_full_ncid", "group__groups.html#ga41d2e214f1a880493ed8ea3fbddab806", null ],
    [ "nc_inq_grp_ncid", "group__groups.html#gaf9a4ca873f41198fec89225695e02390", null ],
    [ "nc_inq_grp_parent", "group__groups.html#ga7c338b12dee45bdae6e74bbd001ffd27", null ],
    [ "nc_inq_grpname", "group__groups.html#ga47b3abc447a3df06c936663a2e14f1fe", null ],
    [ "nc_inq_grpname_full", "group__groups.html#gaaee42fa8747f94ed784575d3050417b5", null ],
    [ "nc_inq_grpname_len", "group__groups.html#ga83aea5b3cd6e8b42a41bc85aa4f85ce0", null ],
    [ "nc_inq_grps", "group__groups.html#ga33eb934cc6810770be78eaa822656a00", null ],
    [ "nc_inq_ncid", "group__groups.html#ga489aefe98168cfeccb75b1dc04f32beb", null ],
    [ "nc_inq_typeids", "group__groups.html#ga20ec76fc10c26a8c71bf9a4627f2e758", null ],
    [ "nc_inq_varids", "group__groups.html#ga7bb913f6eb67da57f7ef41b589f492f5", null ],
    [ "nc_rename_grp", "group__groups.html#gaefcb47414491c418269a865b3299406b", null ],
    [ "nc_show_metadata", "group__groups.html#ga3ab8d9d14985a08ddd45150afe785479", null ]
];