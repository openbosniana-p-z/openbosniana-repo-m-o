var group__error =
[
    [ "nc_strerror", "group__error.html#ga1d965e9202ac294fded38809ec834c1c", null ]
];