var searchData=
[
  ['bit_5fxpl_5fnbr_5fsgn_5fdbl_0',['BIT_XPL_NBR_SGN_DBL',['../nc4var_8c.html#a6599eaf56c5b987489f5a8feebaac7d9',1,'nc4var.c']]],
  ['bit_5fxpl_5fnbr_5fsgn_5fflt_1',['BIT_XPL_NBR_SGN_FLT',['../nc4var_8c.html#a9fc90250fb8464e58dd765d863433edc',1,'nc4var.c']]],
  ['build_20instructions_20for_20netcdf_2dc_20using_20cmake_2',['Build Instructions for NetCDF-C using CMake',['../netCDF-CMake.html',1,'']]],
  ['building_20the_20netcdf_2d4_2e2_20and_20later_20fortran_20libraries_3',['Building the NetCDF-4.2 and later Fortran libraries',['../building_netcdf_fortran.html',1,'']]]
];
