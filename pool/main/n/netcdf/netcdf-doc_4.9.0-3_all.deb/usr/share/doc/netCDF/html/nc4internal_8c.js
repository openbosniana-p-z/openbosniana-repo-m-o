var nc4internal_8c =
[
    [ "NC_createglobalstate", "nc4internal_8c.html#a783d9b994ac1a0ca8ceb1838c8406c0d", null ],
    [ "nc_get_alignment", "group__datasets.html#ga0138ea8c854855522d1232909ad7fb9b", null ],
    [ "nc_set_alignment", "group__datasets.html#ga93c4c9227c568b7bbd01be17ff23790c", null ]
];