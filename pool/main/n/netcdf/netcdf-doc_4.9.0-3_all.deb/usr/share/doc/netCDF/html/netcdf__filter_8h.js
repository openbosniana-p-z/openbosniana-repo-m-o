var netcdf__filter_8h =
[
    [ "NC_MAX_PIXELS_PER_BLOCK", "netcdf__filter_8h.html#a750c58a2a8b57383b8183507ef51a729", null ],
    [ "NC_SZIP_EC", "netcdf__filter_8h.html#a2daa4e9eec734e2839a114d2cc704373", null ],
    [ "NC_SZIP_NN", "netcdf__filter_8h.html#ac92ed9a8e8600d15cbf96ee222df1efe", null ],
    [ "nc_def_var_blosc", "group__variables.html#ga59cc48a864c142ebd5897779ed703006", null ],
    [ "nc_def_var_bzip2", "netcdf__filter_8h.html#a6f0038befa623732c8d1578c2e47736b", null ],
    [ "nc_def_var_filter", "netcdf__filter_8h.html#ac36bab2513510fc20576f6549b2d32c7", null ],
    [ "nc_def_var_zstandard", "netcdf__filter_8h.html#a01c702426610d3cd335da1430dfc9326", null ],
    [ "nc_inq_filter_avail", "netcdf__filter_8h.html#a9138a7a60876e7b9dbba0d6625a8767c", null ],
    [ "nc_inq_var_blosc", "netcdf__filter_8h.html#adeca093b7e25977975f97aa123c9fd43", null ],
    [ "nc_inq_var_bzip2", "netcdf__filter_8h.html#aeb7059092bacbda685d797ec573a2248", null ],
    [ "nc_inq_var_filter", "group__variables.html#ga9e5527da0854f7ec5d95419dab885594", null ],
    [ "nc_inq_var_filter_ids", "group__variables.html#gadb6b0584c25010e7310528659c7e1f30", null ],
    [ "nc_inq_var_filter_info", "group__variables.html#ga8515ac4283164fb220bd3809eec2ad39", null ],
    [ "nc_inq_var_zstandard", "netcdf__filter_8h.html#af626672020391cba46737f3941a0c6d4", null ]
];