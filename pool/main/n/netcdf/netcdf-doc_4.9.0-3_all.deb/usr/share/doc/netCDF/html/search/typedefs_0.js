var searchData=
[
  ['nc_5ftype_0',['nc_type',['../netcdf_8h.html#afe40bef4fdf46f2820e9cd64c64a11b5',1,'netcdf.h']]],
  ['nclong_1',['nclong',['../netcdf_8h.html#a8afcf532a112782c076c150a69804182',1,'netcdf.h']]]
];
