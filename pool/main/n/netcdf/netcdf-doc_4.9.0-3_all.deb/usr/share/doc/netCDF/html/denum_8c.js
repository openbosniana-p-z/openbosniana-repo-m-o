var denum_8c =
[
    [ "nc_def_enum", "group__user__types.html#ga05a639c94ac2babcbeeb49eaae223322", null ],
    [ "nc_inq_enum", "group__user__types.html#gacb9e7c9bac19abef743a052b68057dcb", null ],
    [ "nc_inq_enum_ident", "group__user__types.html#gacf4a6d23ade61ae3b65b6b121c6c096d", null ],
    [ "nc_inq_enum_member", "group__user__types.html#ga3df6c73ecab76a6d8579e9ffe71cee69", null ],
    [ "nc_insert_enum", "group__user__types.html#gab27c14e16911c4cb88432755678f2b46", null ]
];