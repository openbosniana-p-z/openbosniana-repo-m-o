var dopaque_8c =
[
    [ "nc_def_opaque", "group__user__types.html#ga49cfe053a3fceff80227409e9ef123f7", null ],
    [ "nc_inq_opaque", "group__user__types.html#ga84a48cfbb8e18c6ef43ea97e3579e448", null ]
];