var searchData=
[
  ['lossy_20compression_20with_20quantize_0',['Lossy Compression with Quantize',['../md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html',1,'']]]
];
