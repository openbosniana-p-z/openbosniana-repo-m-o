var searchData=
[
  ['reading_20and_20writing_20subsets_20of_20data_0',['Reading and Writing Subsets of Data',['../accessing_subsets.html',1,'tutorial.dox']]],
  ['reading_20netcdf_20files_20of_20known_20structure_1',['Reading NetCDF Files of Known Structure',['../reading_known.html',1,'tutorial.dox']]],
  ['reading_20netcdf_20files_20of_20unknown_20structure_2',['Reading NetCDF Files of Unknown Structure',['../reading_unknown.html',1,'tutorial.dox']]],
  ['release_20notes_3',['Release Notes',['../RELEASE_NOTES.html',1,'index']]]
];
