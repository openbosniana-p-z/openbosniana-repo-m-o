var searchData=
[
  ['dimsizes_0',['dimsizes',['../dv2i_8c.html#a923f1d996482cb3572c20da464fb44d1',1,'dv2i.c']]]
];
