var searchData=
[
  ['netcdf_20error_20handling_0',['NetCDF Error Handling',['../group__error.html',1,'']]],
  ['netcdf_20file_20and_20data_20i_2fo_1',['NetCDF File and Data I/O',['../group__datasets.html',1,'']]]
];
