var tutorial_8dox =
[
    [ "Tutorial Documentation", "tutorial_8dox.html#sec_tut", [
      [ "Tutorial Pages", "tutorial_8dox.html#tutorial_pages", null ],
      [ "Background and Further Reading", "tutorial_8dox.html#background_further_reading", null ],
      [ "NetCDF Data Model:", "tutorial_8dox.html#sub_sec_netcdf_data_model", null ],
      [ "Important Conventions:", "tutorial_8dox.html#sub_sec_important_conventions", null ],
      [ "Tools for NetCDF:", "tutorial_8dox.html#sub_sec_tools_for_netcdf", null ],
      [ "Programming with NetCDF:", "tutorial_8dox.html#sub_sec_programming_with_netcdf", null ],
      [ "Example Programs:", "tutorial_8dox.html#sub_sec_example_programs", null ]
    ] ],
    [ "Working with NetCDF Files from the command line.", "netcdf_working_with_netcdf_files.html", [
      [ "The NetCDF Utilities", "netcdf_working_with_netcdf_files.html#netcdf_utilities", [
        [ "ncdump", "netcdf_working_with_netcdf_files.html#netcdf_utilities_ncdump", null ],
        [ "ncgen", "netcdf_working_with_netcdf_files.html#netcdf_utilities_ncgen", null ],
        [ "nccopy", "netcdf_working_with_netcdf_files.html#netcdf_utilities_nccopy", null ]
      ] ],
      [ "Tools for Manipulating NetCDF Files", "netcdf_working_with_netcdf_files.html#external_netcdf_tools", null ]
    ] ],
    [ "Numbering of NetCDF IDs", "tutorial_ncids.html", null ],
    [ "Creating New Files and Metadata, an Overview", "creating.html", null ],
    [ "Reading NetCDF Files of Known Structure", "reading_known.html", null ],
    [ "Reading NetCDF Files of Unknown Structure", "reading_unknown.html", null ],
    [ "Reading and Writing Subsets of Data", "accessing_subsets.html", null ],
    [ "NetCDF Documentation", "netcdf_documentation.html", null ],
    [ "The NetCDF Data Model", "netcdf_data_model.html", [
      [ "The Classic Model", "netcdf_data_model.html#classic_model", null ],
      [ "The Enhanced Data Model", "netcdf_data_model.html#enhanced_model", null ],
      [ "Meteorological Example", "netcdf_data_model.html#met_example", null ]
    ] ],
    [ "Unlimited Dimensions", "unlimited_dims.html", null ],
    [ "Groups", "groups.html", null ],
    [ "User Defined Types", "user_defined_types.html", [
      [ "Compound Types", "user_defined_types.html#compound_types", null ],
      [ "Opaque Types", "user_defined_types.html#opaque_types", null ],
      [ "Variable Length Arrays (VLEN)", "user_defined_types.html#vlen_type", null ]
    ] ],
    [ "Strings", "string_type.html", null ],
    [ "Fill Values", "fill_values.html", null ],
    [ "The NetCDF Programming APIs", "netcdf_apis.html", null ],
    [ "Error Handling", "error_handling.html", null ],
    [ "Interoperability with HDF5", "interoperability_hdf5.html", [
      [ "Reading and Editing NetCDF-4 Files with HDF5", "interoperability_hdf5.html#reading_with_hdf5", null ],
      [ "Reading and Editing HDF5 Files with NetCDF-4", "interoperability_hdf5.html#accessing_hdf5", null ]
    ] ],
    [ "Parallel I/O with NetCDF-4", "parallel_io.html", [
      [ "Collective/Independent Access", "parallel_io.html#collective_independent", null ]
    ] ],
    [ "NetCDF Example Programs", "examples1.html", [
      [ "The simple_xy Example", "examples1.html#example_simple_xy", null ],
      [ "The sfc_pres_temp Example", "examples1.html#example_sfc_pres_temp", null ],
      [ "The pres_temp_4D Example", "examples1.html#example_pres_temp_4D", null ],
      [ "The simple_nc4 Example", "examples1.html#example_simple_nc4", null ],
      [ "The simple_xy_nc4 Example", "examples1.html#example_simple_xy_nc4", null ],
      [ "The filter example", "examples1.html#example_filter", null ]
    ] ]
];