var dparallel_8c =
[
    [ "nc_create_par", "group__datasets.html#ga5e03371d14dfac165734b3d0d2c3adc6", null ],
    [ "nc_create_par_fortran", "group__datasets.html#gaa3cdb3059f7c9aedddea37c90a173ca0", null ],
    [ "nc_open_par", "group__datasets.html#ga019098e9d5265006a11c9a841eb81b74", null ],
    [ "nc_open_par_fortran", "group__datasets.html#ga8e38c3c46bb1871f841ddd8e811dbed5", null ],
    [ "nc_var_par_access", "group__datasets.html#ga6dc46e4ab82584360518db5cb0cad841", null ]
];