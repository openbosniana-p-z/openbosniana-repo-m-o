var searchData=
[
  ['copyright_0',['COPYRIGHT',['../copyright.html',1,'']]],
  ['creating_20new_20files_20and_20metadata_2c_20an_20overview_1',['Creating New Files and Metadata, an Overview',['../creating.html',1,'tutorial.dox']]]
];
