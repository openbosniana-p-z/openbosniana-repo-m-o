var searchData=
[
  ['nc_5fmemio_0',['NC_memio',['../netcdf__mem_8h.html#structNC__memio',1,'']]],
  ['nc_5fvlen_5ft_1',['nc_vlen_t',['../netcdf_8h.html#structnc__vlen__t',1,'']]]
];
