var nc4info_8c =
[
    [ "HDF5_MAX_NAME", "nc4info_8c.html#aba3c1713e6bd4bf2b58d587f8fb84225", null ],
    [ "NC4_write_ncproperties", "nc4info_8c.html#a7b3ad5854cf410e3dccddfab50894581", null ]
];