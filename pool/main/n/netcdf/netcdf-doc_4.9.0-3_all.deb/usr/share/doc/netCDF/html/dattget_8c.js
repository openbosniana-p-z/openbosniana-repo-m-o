var dattget_8c =
[
    [ "nc_get_att", "group__attributes.html#ga19cae92a58e1bf7f999c3eeab5404189", null ],
    [ "nc_get_att_double", "group__attributes.html#gaa600762cf4211c84bf41233e71d815aa", null ],
    [ "nc_get_att_float", "group__attributes.html#ga1cb4339ace72acc3ac9b85b748e6ae5e", null ],
    [ "nc_get_att_int", "group__attributes.html#ga0d63b41a7afc00e9c7de39c4bdab7db8", null ],
    [ "nc_get_att_long", "group__attributes.html#ga1ea67a67e7ef1073da53d498a8b9a47d", null ],
    [ "nc_get_att_longlong", "group__attributes.html#ga362266f034687180f9aa3d052f8d2069", null ],
    [ "nc_get_att_schar", "group__attributes.html#ga9ec5c0a1d8995e5710539bd4cb2c5dd4", null ],
    [ "nc_get_att_short", "group__attributes.html#ga93907a1a0e99d0aededde645ce03ec66", null ],
    [ "nc_get_att_string", "group__attributes.html#ga0d66350856a4a6dd3f459fd092937c27", null ],
    [ "nc_get_att_text", "group__attributes.html#ga83c961529fa27b1768528e5d27cc3eb4", null ],
    [ "nc_get_att_ubyte", "group__attributes.html#ga42d8b55ce32fe86105cf08185c35ff7f", null ],
    [ "nc_get_att_uchar", "group__attributes.html#ga1fdb56f25547038c14778327e6ff96ce", null ],
    [ "nc_get_att_uint", "group__attributes.html#gaf16ca4a61277ba814e73d34a49bbe90f", null ],
    [ "nc_get_att_ulonglong", "group__attributes.html#ga7c86bbbb7ba4a6942356f1e888d1e66f", null ],
    [ "nc_get_att_ushort", "group__attributes.html#gadb9f939ca91d7bcc52167ec908a4b1c9", null ]
];