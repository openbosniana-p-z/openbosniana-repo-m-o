var datt_8c =
[
    [ "nc_del_att", "group__attributes.html#gac3464ec4072005ce7c7443d9a657f164", null ],
    [ "nc_rename_att", "group__attributes.html#gad0bbaebe4b405f2649d5a1a4ca664bb1", null ]
];