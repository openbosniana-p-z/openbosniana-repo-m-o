var nc4cache_8c =
[
    [ "nc_get_chunk_cache", "group__datasets.html#gaae2dc9ff560def21d87cbac32f98c13f", null ],
    [ "nc_set_chunk_cache", "group__datasets.html#gad5301a7261c62a9718606936fe195896", null ]
];