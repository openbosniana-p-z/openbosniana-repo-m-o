var group__dimensions =
[
    [ "nc_def_dim", "group__dimensions.html#ga6a1e2683ca1acf91437b790979ac7b8a", null ],
    [ "nc_inq_dim", "group__dimensions.html#gaac784257960f7ea39ddd786e7521f4e5", null ],
    [ "nc_inq_dimid", "group__dimensions.html#gaf5bace43c738fe94e81a6afc43226a67", null ],
    [ "nc_inq_dimlen", "group__dimensions.html#ga13f1d56fe9a2461ce74ccc0342e32611", null ],
    [ "nc_inq_dimname", "group__dimensions.html#ga53f9390fa181e5d516fa4a3931869aff", null ],
    [ "nc_inq_ndims", "group__dimensions.html#ga0ebb3e06ae1f58b0a93294e9a950a253", null ],
    [ "nc_inq_unlimdim", "group__dimensions.html#gaaee04a3d65dd6743bbe0c91c2198c759", null ],
    [ "nc_rename_dim", "group__dimensions.html#ga9647494ac434e15b7003ab0a9616d01e", null ]
];