/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "NetCDF", "index.html", [
    [ "Introduction and Overview", "index.html", null ],
    [ "Building the NetCDF-4.2 and later Fortran libraries", "building_netcdf_fortran.html", [
      [ "Building with shared libraries", "building_netcdf_fortran.html#building_fortran_shared_libraries", null ],
      [ "Building with static libraries", "building_netcdf_fortran.html#building_fortran_with_static_libraries", null ],
      [ "Linking your programs with netCDF Fortran libraries", "building_netcdf_fortran.html#linking_against_netcdf_fortran", null ],
      [ "Specifying The Environment for Building", "building_netcdf_fortran.html#specify_build_env_fortran", [
        [ "Environment Variable Description Notes", "building_netcdf_fortran.html#autotoc_md88", null ]
      ] ]
    ] ],
    [ "Installing and Using netCDF-C Libraries in Windows", "winbin.html", [
      [ "Getting pre-built netCDF-C Libraries for Visual Studio", "winbin.html#msvc-prebuilt", [
        [ "Included Dependencies", "winbin.html#msvc-inc-deps", null ],
        [ "Latest Release (netCDF-C 4.9.0)", "winbin.html#msvc-latest-release", null ]
      ] ],
      [ "Using the netCDF-C Libraries with Visual Studio", "winbin.html#msvc-using", [
        [ "Install Hierarchy", "winbin.html#msvc-install-hierarchy", null ]
      ] ],
      [ "Notes", "winbin.html#msvc-notes", null ]
    ] ],
    [ "Appendix A: Attribute Conventions", "attribute_conventions.html", [
      [ "Conventions", "attribute_conventions.html#autotoc_md89", null ],
      [ "Provenance Attributes", "attribute_conventions.html#autotoc_md90", null ]
    ] ],
    [ "Appendix B. File Format Specifications", "file_format_specifications.html", [
      [ "The NetCDF Classic Format Specification", "file_format_specifications.html#classic_format_spec", null ],
      [ "Notes on Computing File Offsets", "file_format_specifications.html#computing_offsets", [
        [ "Examples", "file_format_specifications.html#offset_examples", null ]
      ] ],
      [ "The 64-bit Offset Format", "file_format_specifications.html#offset_format_spec", null ],
      [ "The NetCDF-4 Format", "file_format_specifications.html#netcdf_4_spec", [
        [ "Creation Order", "file_format_specifications.html#creation_order", null ],
        [ "Groups", "file_format_specifications.html#groups_spec", null ],
        [ "Dimensions with HDF5 Dimension Scales", "file_format_specifications.html#dims_spec", null ],
        [ "Dimensions without HDF5 Dimension Scales", "file_format_specifications.html#dim_spec2", null ],
        [ "Dimension and Coordinate Variable Ordering", "file_format_specifications.html#dim_spec3", null ],
        [ "Variables", "file_format_specifications.html#vars_spec", null ],
        [ "Attributes", "file_format_specifications.html#atts_spec", null ],
        [ "User-Defined Data Types", "file_format_specifications.html#user_defined_spec", null ],
        [ "Compression", "file_format_specifications.html#compression_spec", null ]
      ] ],
      [ "The NetCDF-4 Classic Model Format", "file_format_specifications.html#netcdf_4_classic_spec", null ],
      [ "HDF4 SD Format", "file_format_specifications.html#hdf4_sd_format", null ]
    ] ],
    [ "NetCDF In-Memory Support", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html", [
      [ "NetCDF In-Memory Support", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#inmemory", [
        [ "Introduction", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#inmemory_intro", null ],
        [ "Enabling Diskless File Access", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#Enable_Diskless", [
          [ "Diskless File Open", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#autotoc_md91", null ],
          [ "Diskless File Create", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#autotoc_md92", null ]
        ] ],
        [ "Enabling Inmemory File Access", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#Enable_Inmemory", [
          [ "In-Memory API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#autotoc_md93", null ],
          [ "The <strong>nc_open_mem</strong> Function", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#autotoc_md94", null ],
          [ "The <strong>nc_open_memio</strong> Function", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#autotoc_md95", null ],
          [ "The <strong>nc_create_mem</strong> Function", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#autotoc_md96", null ],
          [ "The <strong>nc_close_memio</strong> Function", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#autotoc_md97", null ],
          [ "Support for Writing with <em>NC_MEMIO_LOCKED</em>", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#autotoc_md98", null ]
        ] ],
        [ "Enabling MMAP File Access", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#Enable_MMAP", null ],
        [ "Known Bugs", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#Inmemory_Bugs", null ],
        [ "References", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#Inmemory_References", null ],
        [ "Point of Contact", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_inmemory.html#autotoc_md99", null ]
      ] ]
    ] ],
    [ "NetCDF-4 Filter Support", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html", [
      [ "NetCDF-4 Filter Support", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters", null ],
      [ "Feature Overview", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_overview", null ],
      [ "Introduction to Filters", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_introduction", null ],
      [ "A Warning on Backward Compatibility", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_compatibility", null ],
      [ "Enabling A HDF5 Compression Filter", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_enable", [
        [ "Using The API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_API", [
          [ "nc_def_var_filter", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md100", null ],
          [ "nc_inq_var_filter_ids", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md101", null ],
          [ "nc_inq_var_filter_info", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md102", null ],
          [ "nc_inq_var_filter", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md103", null ]
        ] ],
        [ "Using ncgen", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_NCGEN", [
          [ "Example CDL File (Data elided)", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md104", null ]
        ] ],
        [ "Using nccopy", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_NCCOPY", null ]
      ] ],
      [ "Filter Specification Syntax", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_syntax", null ],
      [ "Dynamic Loading Process", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_Process", [
        [ "Plugin directory", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_plugindir", null ],
        [ "Plugin Library Naming", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_Pluginlib", null ],
        [ "Plugin Verification", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_Pluginverify", null ]
      ] ],
      [ "NCZarr Filter Support", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_nczarr", [
        [ "Processing Overview", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md105", [
          [ "Step 1: Invoking nc_def_var_filter", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md106", null ],
          [ "Step 1a: Reading metadata", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md107", null ],
          [ "Step 2: Convert visible parameters to working parameters", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md108", null ],
          [ "Step 3: Invoking the filter", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md109", null ],
          [ "Step 4: Closing the dataset", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md110", null ]
        ] ],
        [ "Client API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md111", null ],
        [ "Special Codecs Attribute", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md112", null ],
        [ "Pre-Processing Filter Libraries", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md113", null ],
        [ "Using Plugin Libraries", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md114", null ],
        [ "Filter Defaults Library", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md115", null ],
        [ "Using the Codec API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md116", [
          [ "Writing an NCZarr Container", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md117", null ],
          [ "Reading an NCZarr Container", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md118", null ]
        ] ],
        [ "Supporting Filter Chains", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md119", null ],
        [ "Extensions", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md120", null ],
        [ "Using The NetCDF-C Plugins", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md121", null ]
      ] ],
      [ "Lossy One-Way Filters", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md122", [
        [ "Distortions introduced by lossy filters", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md123", null ]
      ] ],
      [ "Debugging", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_debug", [
        [ "Test Cases", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_TestCase", null ],
        [ "HDF5 Example", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_Example", null ]
      ] ],
      [ "Notes", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md124", [
        [ "Order of Invocation for Multiple Filters", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md125", null ],
        [ "Memory Allocation Issues", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md126", null ],
        [ "SZIP Issues", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md127", null ],
        [ "Supported Systems", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md128", null ],
        [ "Generic Plugin Build", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md129", null ]
      ] ],
      [ "References", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_References", null ],
      [ "Appendix A. HDF5 Parameter Encode/Decode", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_appendixa", [
        [ "Encoding Algorithms for HDF5", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md130", [
          [ "Encoding", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md131", null ],
          [ "Decoding", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md132", null ]
        ] ]
      ] ],
      [ "Appendix B. Support Utilities", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_appendixb", null ],
      [ "Appendix C. Build Flags for Detecting the Filter Mechanism", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_appendixc", null ],
      [ "Appendix D. BNF for Specifying Filters in Utilities", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_appendixd", null ],
      [ "Appendix E. Codec API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_appendixe", [
        [ "The Codec Plugin API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md133", [
          [ "NCZ_get_codec_info", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md134", [
            [ "Signature", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md135", null ]
          ] ],
          [ "NCZ_codec_t", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md136", null ],
          [ "NCZ_codec_to_hdf5", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md137", [
            [ "Signature", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md138", null ],
            [ "Arguments", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md139", null ]
          ] ],
          [ "NCZ_hdf5_to_codec", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md140", [
            [ "Signature", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md141", null ],
            [ "Arguments", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md142", null ]
          ] ],
          [ "NCZ_modify_parameters", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md143", [
            [ "Signature", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md144", null ],
            [ "Arguments", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md145", null ]
          ] ],
          [ "NCZ_codec_initialize", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md146", [
            [ "Signature", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md147", null ]
          ] ],
          [ "NCZ_codec_finalize", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md148", [
            [ "Signature", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md149", null ]
          ] ]
        ] ],
        [ "Multi-Codec API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md150", [
          [ "NCZ_codec_info_defaults", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md151", [
            [ "Signature", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md152", null ]
          ] ]
        ] ]
      ] ],
      [ "Appendix F. Standard Filters", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_appendixf", null ],
      [ "Appendix G. Finding Filters", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_appendixg", null ],
      [ "Appendix H. Auto-Install of Filter Wrappers", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_appendixh", [
        [ "HDF5_PLUGIN_PATH", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#autotoc_md153", null ]
      ] ],
      [ "Point of Contact", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_poc", null ]
    ] ],
    [ "The NetCDF NCZarr Implementation", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html", [
      [ "The NetCDF NCZarr Implementation", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_head", null ],
      [ "NCZarr Introduction", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_introduction", null ],
      [ "The NCZarr Data Model", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_data_model", null ],
      [ "Enabling NCZarr Support", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_enable", null ],
      [ "Accessing Data Using the NCZarr Prototocol", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_accessing_data", [
        [ "URL Format", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md159", null ],
        [ "Client Parameters", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md160", null ]
      ] ],
      [ "NCZarr Map Implementation", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_mapimpl", [
        [ "Zmap Implementatons", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md161", null ]
      ] ],
      [ "NCZarr versus Pure Zarr.", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_purezarr", null ],
      [ "Notes on Debugging NCZarr Access", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_debug", null ],
      [ "Zip File Support", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_zip", null ],
      [ "Amazon S3 Storage", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_s3", [
        [ "Addressing Style", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md162", null ]
      ] ],
      [ "Zarr vs NCZarr", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_vs_zarr", [
        [ "Data Model", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md163", null ],
        [ "Storage Format", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md164", null ],
        [ "Translation", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_translation", null ]
      ] ],
      [ "Compatibility", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_compatibility", [
        [ "XArray", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md165", null ]
      ] ],
      [ "Examples", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_examples", null ],
      [ "References", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_bib", null ],
      [ "Appendix A. Building NCZarr Support", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_build", [
        [ "Automake", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md166", null ],
        [ "CMake", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_cmake", null ],
        [ "Testing S3 Support", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_testing_S3_support", null ]
      ] ],
      [ "Appendix B. Building aws-sdk-cpp", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_s3sdk", [
        [ "**nix** Build", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md167", [
          [ "AWS-SDK-CPP Build Recipe", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md168", null ],
          [ "NetCDF Build", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md169", null ]
        ] ],
        [ "Windows build", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md170", [
          [ "AWS-SDK-CPP Build Recipe", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md171", null ],
          [ "NetCDF CMake Build", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md172", null ]
        ] ]
      ] ],
      [ "Appendix C. Amazon S3 Imposed Limits", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_s3limits", null ],
      [ "Appendix D. Alternative Mechanisms for Accessing Remote Datasets", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_altremote", null ],
      [ "Appendix E. AWS Selection Algorithms.", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_awsselect", [
        [ "Profile Selection", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md173", null ],
        [ "Region Selection", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md174", null ],
        [ "Authorization Selection", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#autotoc_md175", null ]
      ] ],
      [ "Appendix F. NCZarr Version 1 Meta-Data Representation.", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_version1", null ],
      [ "Appendix G. JSON Attribute Convention.", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_json", null ],
      [ "Point of Contact", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_nczarr.html#nczarr_poc", null ]
    ] ],
    [ "NetCDF Programming Notes", "programming_notes.html", [
      [ "Ignored if NULL", "programming_notes.html#ignored_if_null", null ],
      [ "Allocating Storage for the Result", "programming_notes.html#allocating_storage_for_the_result", null ],
      [ "Specify a Hyperslab", "programming_notes.html#specify_hyperslab", [
        [ "A Vector Specifying Start Index for Each Dimension", "programming_notes.html#start_vector", null ],
        [ "A Vector Specifying Count for Each Dimension", "programming_notes.html#count_vector", null ],
        [ "A Vector Specifying Stride for Each Dimension", "programming_notes.html#stride_vector", null ],
        [ "A Vector Specifying Mapping for Each Dimension", "programming_notes.html#map_vector", null ]
      ] ],
      [ "NetCDF ID", "programming_notes.html#ncid", null ],
      [ "NetCDF Names", "programming_notes.html#object_name", [
        [ "Permitted Characters in NetCDF Names", "programming_notes.html#autotoc_md176", null ],
        [ "Name Length", "programming_notes.html#autotoc_md177", null ],
        [ "NetCDF Conventions", "programming_notes.html#autotoc_md178", null ]
      ] ]
    ] ],
    [ "Build Instructions for NetCDF-C using CMake", "netCDF-CMake.html", [
      [ "Overview", "netCDF-CMake.html#cmake_overview", null ],
      [ "Requirements", "netCDF-CMake.html#cmake_requirements", null ],
      [ "The CMake Build Process", "netCDF-CMake.html#cmake_build", [
        [ "Configuration", "netCDF-CMake.html#cmake_configuration", [
          [ "Common CMake Options", "netCDF-CMake.html#cmake_common_options", null ],
          [ "Configuring your build from the command line.", "netCDF-CMake.html#cmake_command_line", null ]
        ] ],
        [ "Building", "netCDF-CMake.html#cmake_building", null ],
        [ "Testing", "netCDF-CMake.html#cmake_testing", null ],
        [ "Installation", "netCDF-CMake.html#cmake_installation", null ]
      ] ],
      [ "See Also", "netCDF-CMake.html#cmake_see_also", null ]
    ] ],
    [ "FAQ", "faq.html", [
      [ "General", "faq.html#ncFAQGeneral", [
        [ "What Is netCDF?", "faq.html#What-Is-netCDF", null ],
        [ "How do I get the netCDF software package?", "faq.html#HowdoIgetthenetCDFsoftwarepackage", null ],
        [ "How do I convert netCDF data to ASCII or text?", "faq.html#How-do-I-convert-netCDF-data-to-ASCII-or-text", null ],
        [ "How do I convert ASCII or text data to netCDF?", "faq.html#How-do-I-convert-ASCII-or-text-data-to-netCDF", null ],
        [ "What is the best way to represent [some particular data] using netCDF?", "faq.html#What-is-the-best-way-to-represent-some-particular-data-using-netCDF", null ],
        [ "What convention should be used for the names of netCDF files?", "faq.html#What-convention-should-be-used-for-the-names-of-netCDF-files", null ],
        [ "Is there a mailing list for netCDF discussions and questions?", "faq.html#Is-there-a-mailing-list-for-netCDF-discussions-and-questions", null ],
        [ "Where are some examples of netCDF datasets?", "faq.html#Where-are-some-examples-of-netCDF-datasets", null ],
        [ "What is the best way to handle time using netCDF?", "faq.html#What-is-the-best-way-to-handle-time-using-netCDF", null ],
        [ "Who else uses netCDF?", "faq.html#Who-else-uses-netCDF", null ],
        [ "What are some references to netCDF?", "faq.html#What-are-some-references-to-netCDF", null ],
        [ "I'm submitting a paper for publication and want to include a citation for use of netCDF software. What reference should I use?", "faq.html#How-should-I-cite-use-of-netCDF-software", null ],
        [ "Is there a document describing the actual physical format for a Unidata netCDF file?", "faq.html#Is-there-a-document-describing-the-actual-physical-format-for-a-Unidata-netCDF-file", null ]
      ] ],
      [ "Installation and Porting", "faq.html#Installation-and-Porting", [
        [ "What does netCDF run on?", "faq.html#What-does-netCDF-run-on", null ],
        [ "How can I use current versions of netCDF-4 with Windows?", "faq.html#HowcanIusecu", null ],
        [ "How can I use netCDF-4.1 with Windows?", "faq.html#HowcanIusenetCDF41withWindows", null ],
        [ "How can I use netCDF-4 with Windows?", "faq.html#How-can-I-use-netCDF-4-with-Windows", null ],
        [ "How do I build and install netCDF for a specific development environment?", "faq.html#How-do-I-build-and-install-netCDF-for-a-specific-development-environment", null ],
        [ "How can I tell if I successfully built and installed netCDF?", "faq.html#How-can-I-tell-if-I-successfully-built-and-installed-netCDF", null ],
        [ "How can I tell what version I'm using?", "faq.html#How-can-I-tell-what-version-Im-using", null ],
        [ "Where does netCDF get installed?", "faq.html#Where-does-netCDF-get-installed", null ]
      ] ],
      [ "Formats, Data Models, and Software Releases", "faq.html#formatsdatamodelssoftwarereleases", [
        [ "How many netCDF formats are there, and what are the differences among them?", "faq.html#How-many-netCDF-formats-are-there-and-what-are-the-differences-among-them", null ],
        [ "How can I tell which format a netCDF file uses?", "faq.html#How-can-I-tell-which-format-a-netCDF-file-uses", null ],
        [ "How many netCDF data models are there?", "faq.html#How-many-netCDF-data-models-are-there", null ],
        [ "How many releases of the C-based netCDF software are supported?", "faq.html#How-many-releases-of-the-C-based-netCDF-software-are-supported", null ],
        [ "Should I get netCDF-3 or netCDF-4?", "faq.html#Should-I-get-netCDF-3-or-netCDF-4", null ],
        [ "What is the \"enhanced data model\" of netCDF-4, and how does it differ from the netCDF-3 classic data model?", "faq.html#whatisenhanceddatamodel", null ],
        [ "Why doesn't the new netCDF-4 installation I built seem to support any of the new features?", "faq.html#Whydoesnt-the-new-netCDF-4-installation-I-built-seem-to-support-any-of-the-new-features", null ],
        [ "Will Unidata continue to support netCDF-3?", "faq.html#Will-Unidata-continue-to-support-netCDF-3", null ],
        [ "To read compressed data, what changes do I need to make to my netCDF-3 program?", "faq.html#To-read-compressed-data-what-changes-do-I-need-to-make-to-my-netCDF-3-program", null ],
        [ "To write compressed data, what changes do I need to make to my netCDF-3 program?", "faq.html#To-write-compressed-data-what-changes-do-I-need-to-make-to-my-netCDF-3-program", null ],
        [ "If I create netCDF-4 classic model files, can they be read by IDL, MATLAB, R, Python and ArcGIS?", "faq.html#If-I-create-netCDF-4-classic-model-files-can-they-be-read-by-IDL-MATLAB-R-Python-and-ArcGIS", null ],
        [ "What applications are able to deal with <em>arbitrary</em> netCDF-4 files?", "faq.html#What-applications-are-able-to-deal-with-arbitrary-netCDF-4-files", null ],
        [ "How can I convert netCDF-3 files into netCDF-4 files?", "faq.html#How-can-I-convert-netCDF-3-files-into-netCDF-4-files", null ],
        [ "Why might someone want to convert netCDF-4 files into netCDF-3 files?", "faq.html#Why-might-someone-want-to-convert-netCDF-4-files-into-netCDF-3-files", null ],
        [ "How can I convert netCDF-4 files into netCDF-3 files?", "faq.html#How-can-I-convert-netCDF-4-files-into-netCDF-3-files", null ],
        [ "How can I convert HDF5 files into netCDF-4 files?", "faq.html#How-can-I-convert-HDF5-files-into-netCDF-4-files", null ],
        [ "How can I convert netCDF-4 files into HDF5 files?", "faq.html#How-can-I-convert-netCDF-4-files-into-HDF5-files", null ],
        [ "Why aren't different extensions used for the different formats, for example \".nc3\" and \".nc4\"?", "faq.html#why-arent-different-extensions-used", null ],
        [ "Why is the default of netCDF-4 to continue to create classic files, rather than netCDF-4 files?", "faq.html#Why-is-the-default-of-netCDF-4-to-continue-to-create-classic-files-rather-than-netCDF-4-files", null ],
        [ "Can netCDF-4 read arbitrary HDF5 files?", "faq.html#Can-netCDF-4-read-arbitrary-HDF5-files", null ],
        [ "I installed netCDF-3 with –enable-shared, but it looks like the libraries it installed were netCDF-4, with names like libnetcdf.4.dylib. What's going on?", "faq.html#I-installed-netCDF-3-with---enable-shared-but-it-looks-like-the-libraries-it-installed-were-netCDF-4-with-names-like-libnetcdf4dylib-Whats-going-on", null ],
        [ "NetCDF-3.6.3 permits UTF-8 encoded Unicode names. Won't this break backward compatibility with previous software releases that didn't allow such names?", "faq.html#NetCDF-363-permits-UTF-8-encoded-Unicode-names-Wont-this-break-backward-compatibility-with-previous-software-releases-that-didnt-allow-such-names", null ],
        [ "Can I use UTF-8 File Names with Windows?", "faq.html#Can-I-use-UTF-8-File-Names-with-Windows", null ],
        [ "How difficult is it to convert my application to handle arbitrary netCDF-4 files?", "faq.html#How-difficult-is-it-to-convert-my-application-to-handle-arbitrary-netCDF-4-files", null ]
      ] ],
      [ "Shared Libraries", "faq.html#Shared-Libraries", [
        [ "What are shared libraries?", "faq.html#What-are-shared-libraries", null ],
        [ "Can I build netCDF with shared libraries?", "faq.html#Can-I-build-netCDF-with-shared-libraries", null ],
        [ "How do I use netCDF shared libraries?", "faq.html#How-do-I-use-netCDF-shared-libraries", null ]
      ] ],
      [ "Large File Support", "faq.html#Large-File-Support", [
        [ "Was it possible to create netCDF files larger than 2 GiBytes before version 3.6?", "faq.html#Was-it-possible-to-create-netCDF-files-larger-than-2-GiBytes-before-version-36", null ],
        [ "What is Large File Support?", "faq.html#What-is-Large-File-Support", null ],
        [ "What does Large File Support have to do with netCDF?", "faq.html#What-does-Large-File-Support-have-to-do-with-netCDF", null ],
        [ "Do I have to know which netCDF file format variant is used in order to access or modify a netCDF file?", "faq.html#Do-I-have-to-know-which-netCDF-file-format-variant-is-used-in-order-to-access-or-modify-a-netCDF-file", null ],
        [ "Will future versions of the netCDF library continue to support accessing files in the classic format?", "faq.html#Will-future-versions-of-the-netCDF-library-continue-to-support-accessing-files-in-the-classic-format", null ],
        [ "Should I start using the new 64-bit offset format for all my netCDF files?", "faq.html#Should-I-start-using-the-new-64-bit-offset-format-for-all-my-netCDF-files", null ],
        [ "How can I tell if a netCDF file uses the classic format (CDF-1), 64-bit offset format (CDF-2) or 64-bit data format (CDF-5)?", "faq.html#How-can-I-tell-if-a-netCDF-file-uses-the-classic-format-or-64-bit-offset-format", null ],
        [ "What happens if I create a 64-bit offset format netCDF file and try to open it with an older netCDF application that hasn't been linked with netCDF 3.6?", "faq.html#What-happens-if-I-create-a-64-bit-offset-format-netCDF-file-and-try-to-open-it-with-an-older-netCDF-application-that-hasnt-been-linked-with-netCDF-36", null ],
        [ "Can I create 64-bit offset files on 32-bit platforms?", "faq.html#Can-I-create-64-bit-offset-files-on-32-bit-platforms", null ],
        [ "How do I create a 64-bit offset netCDF file from C, Fortran-77, Fortran-90, or C++?", "faq.html#How-do-I-create-a-64-bit-offset-netCDF-file-from-C-Fortran-77-Fortran-90-or-Cpp", null ],
        [ "How do I create a 64-bit offset netCDF file using the ncgen utility?", "faq.html#How-do-I-create-a-64-bit-offset-netCDF-file-using-the-ncgen-utility", null ],
        [ "Have all netCDF size limits been eliminated?", "faq.html#Have-all-netCDF-size-limits-been-eliminated", null ],
        [ "Why are variables still limited in size?", "faq.html#Why-are-variables-still-limited-in-size", null ],
        [ "How can I write variables larger than 4 GiB?", "faq.html#How-can-I-write-variables-larger-than-4-GiB", null ],
        [ "Why do I get an error message when I try to create a file larger than 2 GiB with the new library?", "faq.html#Why-do-I-get-an-error-message-when-I-try-to-create-a-file-larger-than-2-GiB-with-the-new-library", null ],
        [ "Do I need to use special compiler flags to compile and link my applications that use netCDF with Large File Support?", "faq.html#Do-I-need-to-use-special-compiler-flags-to-compile-and-link-my-applications-that-use-netCDF-with-Large-File-Support", null ],
        [ "Is it possible to create a \"classic\" format netCDF file with netCDF version 3.6.0 that cannot be accessed by applications compiled and linked against earlier versions of the library?", "faq.html#isitpossibleclassic360", null ]
      ] ],
      [ "NetCDF and Other Software", "faq.html#NetCDF-and-Other-Software", [
        [ "What other software is available for accessing, displaying, and manipulating netCDF data?", "faq.html#What-other-software-is-available-for-accessing-displaying-and-manipulating-netCDF-data", null ],
        [ "What other data access interfaces and formats are available for scientific data?", "faq.html#What-other-data-access-interfaces-and-formats-are-available-for-scientific-data", null ],
        [ "What is the connection between netCDF and CDF?", "faq.html#What-is-the-connection-between-netCDF-and-CDF", null ],
        [ "What is the connection between netCDF and HDF?", "faq.html#What-is-the-connection-between-netCDF-and-HDF", null ],
        [ "Has anyone implemented client-server access for netCDF data?", "faq.html#Has-anyone-implemented-client-server-access-for-netCDF-data", null ],
        [ "How do I convert between GRIB and netCDF?", "faq.html#How-do-I-convert-between-GRIB-and-netCDF", null ],
        [ "Problems and Bugs", "faq.html#autotoc_md224", null ],
        [ "Can I recover data from a netCDF file that was not closed properly?", "faq.html#Can-I-recover-data-from-a-netCDF-file-that-was-not-closed-properly", null ],
        [ "Is there a list of reported problems and workarounds?", "faq.html#Is-there-a-list-of-reported-problems-and-workarounds", null ],
        [ "How do I make a bug report?", "faq.html#How-do-I-make-a-bug-report", null ],
        [ "How do I search through past problem reports?", "faq.html#How-do-I-search-through-past-problem-reports", null ]
      ] ],
      [ "Programming with NetCDF", "faq.html#Programming-with-NetCDF", [
        [ "Which programming languages have netCDF interfaces?", "faq.html#Which-programming-languages-have-netCDF-interfaces", null ],
        [ "Are the netCDF libraries thread-safe?", "faq.html#Are-the-netCDF-libraries-thread-safe", null ],
        [ "How does the C++ interface differ from the C interface?", "faq.html#How-does-the-Cpp-interface-differ-from-the-C-interface", null ],
        [ "How does the Fortran interface differ from the C interface?", "faq.html#How-does-the-Fortran-interface-differ-from-the-C-interface", null ],
        [ "How do the Java, Perl, Python, Ruby, ... interfaces differ from the C interface?", "faq.html#How-do-the-Java-Perl-Python-Ruby-interfaces-differ-from-the-C-interface", null ],
        [ "How do I handle errors in C?", "faq.html#How-do-I-handle-errors-in-C", null ]
      ] ],
      [ "CMake-Related Frequently Asked Questions", "faq.html#cmake_faq", [
        [ "How can I see the options available to CMake?", "faq.html#listoptions", null ],
        [ "How do I specify how to build a shared or static library?", "faq.html#sharedstatic", null ],
        [ "Can I build both shared and static libraries at the same time with cmake?", "faq.html#sharedstaticboth", null ],
        [ "How can I specify linking against a particular library?", "faq.html#partlib", null ],
        [ "What if I want to link against multiple libraries in a non-standard location", "faq.html#nonstdloc", null ],
        [ "How can I specify a Parallel Build using HDF5", "faq.html#parallelhdf", null ]
      ] ],
      [ "Plans", "faq.html#Plans", [
        [ "What other future work on netCDF is planned?", "faq.html#What-other-future-work-on-netCDF-is-planned", null ]
      ] ]
    ] ],
    [ "Known Problems with netCDF", "known_problems.html", [
      [ "Known Problems with netCDF 4.3.0", "known_problems.html#autotoc_md236", null ],
      [ "Known Problems with netCDF 4.2", "known_problems.html#autotoc_md237", null ],
      [ "Known Problems with netCDF 4.1.3", "known_problems.html#autotoc_md238", null ],
      [ "Known Problems with netCDF 4.1.2", "known_problems.html#autotoc_md239", null ],
      [ "Known Problems with netCDF 4.1.1", "known_problems.html#autotoc_md240", [
        [ "The clang compiler (default on OSX 10.9 Mavericks) detects error building ncgen3", "known_problems.html#autotoc_md242", null ],
        [ "Fortran options of nc-config utility (–fflags, –flibs, –has-f90) don't work correctly", "known_problems.html#autotoc_md243", null ],
        [ "Using \"--with-hdf5=...\" configure option doesn't seem to work", "known_problems.html#autotoc_md244", null ],
        [ "nccopy -d and -c options for compression and chunking don't work on netCDF-4 input files", "known_problems.html#autotoc_md245", null ],
        [ "Debug statement left in F90 source", "known_problems.html#autotoc_md246", null ],
        [ "Ncgen is known to produce bad output.", "known_problems.html#autotoc_md247", null ],
        [ "Building with Intel Fortran on Mac OS X", "known_problems.html#autotoc_md248", null ],
        [ "Accessing OPeNDAP servers using a constraint expression", "known_problems.html#autotoc_md249", null ],
        [ "Configuring with \"--enable-benchmarks\" option", "known_problems.html#autotoc_md250", null ],
        [ "Problem with disabling fill mode when using Lustre (or other large blksize file system)", "known_problems.html#autotoc_md251", null ],
        [ "\"make check\" fails when linked with HDF5-1.8.6", "known_problems.html#autotoc_md252", null ],
        [ "Make tries to regenerate documentation with texi2dvi command", "known_problems.html#autotoc_md253", null ],
        [ "Accessing a multidimensional variable with more than 4 billion values on a 32-bit platform", "known_problems.html#autotoc_md254", null ]
      ] ],
      [ "Known Problems with netCDF 4.0.1", "known_problems.html#autotoc_md255", [
        [ "Including mpi.h before netcdf.h breaks MPI", "known_problems.html#autotoc_md256", null ],
        [ "With Sun C compiler, 64-bit ncdump fails", "known_problems.html#autotoc_md257", null ],
        [ "Portland Group compilers can't build shared fortran 90 library or shared C++ library", "known_problems.html#autotoc_md258", null ],
        [ "Intel 10.1 64-bit C++ compiler problem", "known_problems.html#autotoc_md259", null ],
        [ "Intel 9.1 C++ compiler problem doesn't build C++ API", "known_problems.html#autotoc_md260", null ],
        [ "ncgen/ncdump test failure with Intel version 11 compilers", "known_problems.html#autotoc_md261", null ],
        [ "\"ncdump -v group/var\" reports \"group not found\"", "known_problems.html#autotoc_md262", null ]
      ] ],
      [ "Known Problems with netCDF 4.0", "known_problems.html#autotoc_md263", [
        [ "Ncdump assumes default fill value for unsigned byte data", "known_problems.html#autotoc_md264", null ],
        [ "Ncdump of compound type with array field", "known_problems.html#autotoc_md265", null ],
        [ "Memory leak with VLEN attributes", "known_problems.html#autotoc_md266", null ],
        [ "Error dyld: Symbol not found: _H5P_CLS_FILE_ACCESS_g", "known_problems.html#autotoc_md267", null ],
        [ "Fortran90 interface Using Intel ifort under Cygwin", "known_problems.html#autotoc_md269", null ],
        [ "ncdump bug for filenames beginning with a numeric character", "known_problems.html#autotoc_md270", null ]
      ] ],
      [ "Known Problems with netCDF 3.6.3", "known_problems.html#autotoc_md271", [
        [ "Can't build shared library with F90 API on IRIX", "known_problems.html#autotoc_md273", null ]
      ] ],
      [ "Known Problems with netCDF 3.6.2", "known_problems.html#autotoc_md275", [
        [ "Setting ARFLAGS does not work", "known_problems.html#autotoc_md277", null ],
        [ "Bugs in support for variables larger than 4 GiB", "known_problems.html#autotoc_md278", null ],
        [ "Bug in C++ interface prevents creating 64-bit offset format files", "known_problems.html#autotoc_md279", null ],
        [ "The tests in nf_test fail with seg fault with the Absoft Version 10.0 fortran compiler.", "known_problems.html#autotoc_md280", null ],
        [ "Shared libraries do not work with the NAG fortran compiler.", "known_problems.html#autotoc_md281", null ],
        [ "The documented –enable-64bit option doesn't work.", "known_problems.html#autotoc_md282", null ],
        [ "Building netCDF-3.6.2 with gfortran version 4.2.x or 4.3.x fails.", "known_problems.html#autotoc_md283", null ],
        [ "Building shared libraries on Macintosh with g95 fails.", "known_problems.html#autotoc_md284", null ],
        [ "Building shared libraries on HPUX with native tools results in only static libraries.", "known_problems.html#autotoc_md285", null ],
        [ "Building shared libraries on AIX fails.", "known_problems.html#autotoc_md286", null ],
        [ "Building with older versions of g++ fails.", "known_problems.html#autotoc_md287", null ],
        [ "The .NET build files are not included in the 3.6.2 release.", "known_problems.html#autotoc_md288", null ],
        [ "Snapshot .NET build files do not work for Visual Studio 8.0 beta.", "known_problems.html#autotoc_md289", null ],
        [ "The -disable-v2 option causes the fortran build to fail with some fortran compilers.", "known_problems.html#autotoc_md290", null ],
        [ "The –disable-c option does not work.", "known_problems.html#autotoc_md291", null ]
      ] ],
      [ "Known Problems with netCDF 3.6.1", "known_problems.html#autotoc_md292", [
        [ "Building on IBM Bluegene login node (SUSE Linux)", "known_problems.html#autotoc_md293", null ],
        [ "Linux x86 Fedora4 with Intel ifort 9.0 compiler", "known_problems.html#autotoc_md294", null ]
      ] ],
      [ "Known Problems with netCDF 3.6.0", "known_problems.html#autotoc_md296", [
        [ "nctest fails on IRIX platform", "known_problems.html#autotoc_md298", null ],
        [ "C++ API doesn't build on Irix", "known_problems.html#autotoc_md299", null ],
        [ "Potentially serious bug with 64-bit offset files", "known_problems.html#autotoc_md300", null ],
        [ "Cygwin Build Doesn't Work", "known_problems.html#autotoc_md301", null ],
        [ "Windows DLL doesn't include F77 API", "known_problems.html#autotoc_md302", null ],
        [ "F90 tests fail with Portland F90 compiler", "known_problems.html#autotoc_md303", null ],
        [ "Config doesn't find working F77 or F90 compiler on AIX", "known_problems.html#autotoc_md304", null ],
        [ "xlf90 fails to compile test program during configure on AIX", "known_problems.html#autotoc_md305", null ],
        [ "F90 functions not added to library on AIX", "known_problems.html#autotoc_md306", null ],
        [ "Problems with fortran compile because of -Df2cFortran being added by configure\"", "known_problems.html#autotoc_md307", null ],
        [ "Message: \"ncgenyy.c is out-of-date with respect to ncgen.l\"", "known_problems.html#autotoc_md308", null ],
        [ "Configure help specifies FCFLAGS instead of FFLAGS", "known_problems.html#autotoc_md309", null ],
        [ "Specifying a count length of zero returns an error instead of no data", "known_problems.html#autotoc_md310", null ],
        [ "C++ library doesn't build under Cygwin", "known_problems.html#autotoc_md311", null ],
        [ "Large file problems in Visual C++ compile", "known_problems.html#autotoc_md312", null ],
        [ "When using TEMP_LARGE, need a trailing slash", "known_problems.html#autotoc_md313", null ]
      ] ]
    ] ],
    [ "COPYRIGHT", "copyright.html", null ],
    [ "The NetCDF-C Tutorial", "tutorial_8dox.html", "tutorial_8dox" ],
    [ "Notes On the Internals of the NetCDF-C Library", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html", [
      [ "Notes On the Internals of the NetCDF-C Library", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#intern_head", null ],
      [ "1. Including C++ Code in the netcdf-c Library {#intern_c++}", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md315", [
        [ "Modifications to <em>lib_flags.am</em>", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md316", null ],
        [ "Modifications to <em>libxxx/Makefile.am</em>", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md317", null ]
      ] ],
      [ "2. Managing instances of complex data types", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md318", [
        [ "nc_get_vars", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md319", null ],
        [ "nc_put_vars", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md320", null ],
        [ "nc_put_att", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md321", null ],
        [ "nc_get_att", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md322", null ],
        [ "New Instance Walking API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md323", null ]
      ] ],
      [ "Internal Changes", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md324", [
        [ "Optimizations", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md325", null ]
      ] ],
      [ "Warnings", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md326", null ],
      [ "3. Inferring File Types", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md327", [
        [ "The Role of URLs", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md328", null ],
        [ "Model Inference Inputs", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md329", [
          [ "Mode", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md330", null ],
          [ "Path", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md331", null ],
          [ "File Contents", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md332", null ],
          [ "Open vs Create", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md333", null ],
          [ "Parallelism", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md334", null ]
        ] ],
        [ "Model Inference Outputs", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md335", null ],
        [ "The Inference Algorithm", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md336", [
          [ "URL processing – processuri()", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md337", null ],
          [ "Macro Processing – processmacros()", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md338", null ],
          [ "Mode Inference – processinferences()", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md339", null ],
          [ "Fragment List Normalization", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md340", null ],
          [ "S3 Rebuild", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md341", null ],
          [ "File Rebuild", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md342", null ],
          [ "Mode Key Processing", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md343", null ],
          [ "Non-Mode Key Processing", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md344", null ],
          [ "URL Defaults", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md345", null ],
          [ "Mode Flags", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md346", null ],
          [ "Content Inference – check_file_type()", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md347", null ],
          [ "Flag Consistency", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md348", null ]
        ] ]
      ] ],
      [ "4. Adding a Standard Filter", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md349", [
        [ "Adding a New Standard Filter", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md350", [
          [ "Build Changes", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md351", [
            [ "Configure.ac", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md352", null ],
            [ "Makefile.am", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md353", null ],
            [ "CMakeLists.txt", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md354", null ]
          ] ],
          [ "Implementation Template", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#autotoc_md355", null ]
        ] ]
      ] ],
      [ "Point of Contact", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_internal.html#intern_poc", null ]
    ] ],
    [ "Internal Dispatch Table Architecture", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html", [
      [ "Internal Dispatch Table Architecture", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md356", null ],
      [ "Introduction", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#dispatch_intro", null ],
      [ "Adding a New Dispatch Table", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md357", [
        [ "Defining configure.ac flags", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md358", null ],
        [ "Defining a \"name space\"", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md359", null ],
        [ "Extend include/netcdf.h", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md360", null ],
        [ "Extend include/ncdispatch.h", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md361", null ],
        [ "Define the dispatch table functions", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md362", null ],
        [ "Adding the dispatch code to libnetcdf", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md363", null ],
        [ "Extend library initialization", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md364", null ],
        [ "Testing the new dispatch table", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md365", null ]
      ] ],
      [ "Top-Level build of the dispatch code", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md366", null ],
      [ "Choosing a Dispatch Table", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md367", null ],
      [ "Special Dispatch Table Signatures.", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md368", [
        [ "Create/Open", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md369", null ],
        [ "Accessing Data with put_vara() and get_vara()", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md370", null ],
        [ "Accessing Attributes with put_attr() and get_attr()", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md371", null ],
        [ "Pre-defined Dispatch Functions", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md372", null ],
        [ "Inquiry Functions", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md373", null ],
        [ "NCDEFAULT get/put Functions", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md374", null ],
        [ "Read-Only Functions", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md375", null ],
        [ "Classic NetCDF Only Functions", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md376", null ]
      ] ],
      [ "HDF4 Dispatch Layer as a Simple Example", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#autotoc_md377", null ],
      [ "Point of Contact", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_dispatch.html#dispatch_poc", null ]
    ] ],
    [ "Lossy Compression with Quantize", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html", [
      [ "Introduction", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#quantize", null ],
      [ "The Quantize Feature", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md416", null ],
      [ "Quantization Algorithms", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md417", [
        [ "Bit Grooming", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md418", null ],
        [ "Granular Bit Round", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md419", null ],
        [ "Bit Round", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md420", null ]
      ] ],
      [ "Quantize Attribute", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md421", null ],
      [ "Handling of Fill Values", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md422", null ],
      [ "Using the Quantize Feature", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md423", [
        [ "Using Quantize with the NetCDF C API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md424", null ],
        [ "Using Quantize with the NetCDF Fortran 90 API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md425", null ],
        [ "Using Quantize with the NetCDF Fortran 77 API", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md426", null ]
      ] ],
      [ "Performance", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md427", null ],
      [ "References", "md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html#autotoc_md428", null ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "NetCDF Functions", "modules.html", "modules" ],
    [ "Files", "files.html", [
      [ "Source Files", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"accessing_subsets.html",
"group__attributes.html#ga362266f034687180f9aa3d052f8d2069",
"group__variables.html#ga74ff169d2d381c30afdcd9ff6e78512a",
"md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_filters.html#filters_NCCOPY",
"netcdf_8h.html#a463f2f8517a9e3eacb2d4a68c18a1523",
"programming_notes.html#autotoc_md178"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';