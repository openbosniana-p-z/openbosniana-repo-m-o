var searchData=
[
  ['len_0',['len',['../netcdf_8h.html#a43f2cf7da36e19680a1642ccce47e03a',1,'nc_vlen_t']]],
  ['lossy_20compression_20with_20quantize_1',['Lossy Compression with Quantize',['../md__build_netcdf_I5mmMi_netcdf_4_9_0_docs_quantize.html',1,'']]]
];
