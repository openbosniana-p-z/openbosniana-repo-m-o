var searchData=
[
  ['variables_0',['Variables',['../group__variables.html',1,'']]]
];
