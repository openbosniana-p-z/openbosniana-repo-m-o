var dattinq_8c =
[
    [ "nc_inq_att", "group__attributes.html#ga9757db7370e0e2e8c23ed1139a6ce6eb", null ],
    [ "nc_inq_attid", "group__attributes.html#ga33868ad9833468ae1c7d63377dcf1e59", null ],
    [ "nc_inq_attlen", "group__attributes.html#gae636cb16de06c5fed9c7d5f337692350", null ],
    [ "nc_inq_attname", "group__attributes.html#gae20821a75d209e296205c4812e91be68", null ],
    [ "nc_inq_atttype", "group__attributes.html#gaa73fe643436728e60a7f028874b6f3c8", null ],
    [ "nc_inq_natts", "group__attributes.html#ga49767fc4c1e60c37d7a0a43c11e74bfe", null ]
];