var searchData=
[
  ['build_20instructions_20for_20netcdf_2dc_20using_20cmake_0',['Build Instructions for NetCDF-C using CMake',['../netCDF-CMake.html',1,'']]],
  ['building_20the_20netcdf_2d4_2e2_20and_20later_20fortran_20libraries_1',['Building the NetCDF-4.2 and later Fortran libraries',['../building_netcdf_fortran.html',1,'']]]
];
