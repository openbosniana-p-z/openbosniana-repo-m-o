var dcompound_8c =
[
    [ "nc_def_compound", "group__user__types.html#ga92f88bce2cd85b7e85ac99c98f27c561", null ],
    [ "nc_inq_compound", "group__user__types.html#ga3d8f5f3fc67489675a38e8d19fc085d5", null ],
    [ "nc_inq_compound_field", "group__user__types.html#ga4be75ee6dd86876ab86076a3a53fbf57", null ],
    [ "nc_inq_compound_fielddim_sizes", "group__user__types.html#ga695ce1bb3c0f9aa8f49a604aa8cbbdff", null ],
    [ "nc_inq_compound_fieldindex", "group__user__types.html#gaa3052b292f7f69144aa5fd6d88471423", null ],
    [ "nc_inq_compound_fieldname", "group__user__types.html#gade281950607d050f5811d25b902d2576", null ],
    [ "nc_inq_compound_fieldndims", "group__user__types.html#gaaa8d1d13b68c4e090df97c056c2ce7d2", null ],
    [ "nc_inq_compound_fieldoffset", "group__user__types.html#gad8c90a2aa61531763b50f62178238a30", null ],
    [ "nc_inq_compound_fieldtype", "group__user__types.html#ga1b0075b8c634801aa60516b3f56d19c7", null ],
    [ "nc_inq_compound_name", "group__user__types.html#ga4bc4ebba3f974db6cf5b92671f0c4f91", null ],
    [ "nc_inq_compound_nfields", "group__user__types.html#gaae3f3bd74f8f46f9cbd13b348a01ddcc", null ],
    [ "nc_inq_compound_size", "group__user__types.html#gadfe62a3f003ae578f77fedb6bfec23d9", null ],
    [ "nc_insert_array_compound", "group__user__types.html#gabb4f2f432c530abcbfd22eb13dfcc9e5", null ],
    [ "nc_insert_compound", "group__user__types.html#ga4315326e6ea70d6451a493e80daec4e9", null ]
];