var netcdf__mem_8h =
[
    [ "NC_memio", "netcdf__mem_8h.html#structNC__memio", null ],
    [ "nc_close_memio", "group__datasets.html#ga5e7dc7cd043ed0b9c75366f2da81d918", null ],
    [ "nc_create_mem", "group__datasets.html#ga813065b4f54533ffd05a5e4a7be720b3", null ],
    [ "nc_open_mem", "group__datasets.html#ga91027f1f0530f8ce54d4072ed10be4c1", null ],
    [ "nc_open_memio", "group__datasets.html#gad641371e0751111c80f102b9613af8cd", null ]
];