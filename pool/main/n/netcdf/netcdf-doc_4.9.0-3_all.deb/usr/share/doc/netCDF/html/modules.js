var modules =
[
    [ "NetCDF File and Data I/O", "group__datasets.html", "group__datasets" ],
    [ "Dimensions", "group__dimensions.html", "group__dimensions" ],
    [ "Variables", "group__variables.html", "group__variables" ],
    [ "Attributes", "group__attributes.html", "group__attributes" ],
    [ "Groups", "group__groups.html", "group__groups" ],
    [ "User-Defined Types", "group__user__types.html", "group__user__types" ],
    [ "The Version 2 API", "group__v2__api.html", "group__v2__api" ],
    [ "NetCDF Error Handling", "group__error.html", "group__error" ]
];