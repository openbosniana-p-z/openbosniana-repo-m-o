var searchData=
[
  ['strings_0',['Strings',['../string_type.html',1,'tutorial.dox']]]
];
