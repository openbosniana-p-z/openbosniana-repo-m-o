var files_dup =
[
    [ "examples", "dir_d28a4824dc47e487b107a5db32ef43c4.html", "dir_d28a4824dc47e487b107a5db32ef43c4" ],
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "libdispatch", "dir_1354dc440b426afd1bd52d9c6b348605.html", "dir_1354dc440b426afd1bd52d9c6b348605" ],
    [ "libhdf5", "dir_2bd793205e25d08e0098c0a87f212831.html", "dir_2bd793205e25d08e0098c0a87f212831" ],
    [ "libnczarr", "dir_4af48c008ed9ab875dc6ef6de7ae2f59.html", "dir_4af48c008ed9ab875dc6ef6de7ae2f59" ],
    [ "libsrc4", "dir_631c2833e5f522ae960c02118f928d2b.html", "dir_631c2833e5f522ae960c02118f928d2b" ]
];