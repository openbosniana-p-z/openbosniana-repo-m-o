var searchData=
[
  ['p_0',['p',['../netcdf_8h.html#a20a5ed2be7e46e2ed8e94d86f4e94585',1,'nc_vlen_t']]],
  ['parallel_20i_2fo_20with_20netcdf_2d4_1',['Parallel I/O with NetCDF-4',['../parallel_io.html',1,'tutorial.dox']]],
  ['pres_5ftemp_5f4d_5frd_2ec_2',['pres_temp_4D_rd.c',['../pres__temp__4D__rd_8c.html',1,'']]],
  ['pres_5ftemp_5f4d_5fwr_2ec_3',['pres_temp_4D_wr.c',['../pres__temp__4D__wr_8c.html',1,'']]]
];
