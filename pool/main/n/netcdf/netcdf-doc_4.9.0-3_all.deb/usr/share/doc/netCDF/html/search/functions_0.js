var searchData=
[
  ['check_5fcreate_5fmode_0',['check_create_mode',['../dfile_8c.html#ab961bbb024f23ccf632c8610b5ac06c0',1,'dfile.c']]]
];
