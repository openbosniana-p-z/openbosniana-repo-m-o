var dtype_8c =
[
    [ "nc_inq_type_equal", "group__user__types.html#ga1edf6802ee9236d58c8917994f77865f", null ],
    [ "nc_inq_typeid", "group__user__types.html#gab828950e2fce25cd415f5a9f0604f838", null ],
    [ "nc_inq_user_type", "group__user__types.html#gaf4340ce9486b1b38e853d75ed23303da", null ]
];