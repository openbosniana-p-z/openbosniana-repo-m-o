import { SVGCommand } from "./types";
export declare function encodeSVGPath(commands: SVGCommand | SVGCommand[]): string;
