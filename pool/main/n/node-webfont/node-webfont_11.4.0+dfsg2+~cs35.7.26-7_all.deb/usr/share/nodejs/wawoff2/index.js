'use strict'

exports.compress = require('./compress')
exports.decompress = require('./decompress')
