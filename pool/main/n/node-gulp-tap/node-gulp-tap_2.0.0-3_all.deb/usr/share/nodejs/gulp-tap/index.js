module.exports = require('./lib/tap.js');
