const USERNAME = 'rajat';
const PASSWORD = 'abc123';

/*
 * Add this secret to your Google Authenticator app.
 * To generate a new secret code, run ./generateSecret.js
 */
const SECRET = '72JTCPPOO2JRL53E';

module.exports = {
  SECRET,
  USERNAME,
  PASSWORD
};
