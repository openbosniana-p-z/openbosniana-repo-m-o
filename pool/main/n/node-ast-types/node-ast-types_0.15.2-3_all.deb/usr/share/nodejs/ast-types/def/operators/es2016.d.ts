export default function (fork: import("../../types").Fork): {
    BinaryOperators: string[];
    AssignmentOperators: string[];
    LogicalOperators: string[];
};
