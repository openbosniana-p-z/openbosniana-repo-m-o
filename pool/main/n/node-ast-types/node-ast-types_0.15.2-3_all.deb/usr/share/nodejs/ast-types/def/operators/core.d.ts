export default function (): {
    BinaryOperators: string[];
    AssignmentOperators: string[];
    LogicalOperators: string[];
};
