/** @param {string} string */
export function decode(string: string): number[];
/** @param {number | number[]} value */
export function encode(value: number | number[]): string;
