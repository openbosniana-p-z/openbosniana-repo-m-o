export declare function attach(comments: any[], ast: any, lines: any): void;
export declare function printComments(path: any, print: any): any;
