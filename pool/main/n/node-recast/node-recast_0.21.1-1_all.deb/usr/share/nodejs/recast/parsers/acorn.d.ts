export declare function parse(source: string, options?: any): any;
