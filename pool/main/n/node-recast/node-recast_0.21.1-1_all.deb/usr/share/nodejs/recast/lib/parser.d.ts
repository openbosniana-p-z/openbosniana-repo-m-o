import { Options } from "./options";
export declare function parse(source: string, options?: Partial<Options>): any;
