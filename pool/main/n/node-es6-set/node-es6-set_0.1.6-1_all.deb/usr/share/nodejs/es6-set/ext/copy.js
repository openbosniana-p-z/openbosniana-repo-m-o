"use strict";

var SetConstructor = require("../");

module.exports = function () { return new SetConstructor(this); };
