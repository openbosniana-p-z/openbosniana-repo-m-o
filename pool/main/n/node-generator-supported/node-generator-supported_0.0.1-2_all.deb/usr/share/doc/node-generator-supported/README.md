# generator-supported


	npm install generator-supported
	require('generator-supported') // true or false
