// Type definitions for global-prefix 3.0
// Project: https://github.com/jonschlinkert/global-prefix
// Definitions by: BendingBender <https://github.com/BendingBender>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

export = globalPrefix;
declare const globalPrefix: string;
