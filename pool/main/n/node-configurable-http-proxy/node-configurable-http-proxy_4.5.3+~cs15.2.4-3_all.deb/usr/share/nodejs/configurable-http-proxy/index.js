module.exports = require("./lib/configproxy.js");
