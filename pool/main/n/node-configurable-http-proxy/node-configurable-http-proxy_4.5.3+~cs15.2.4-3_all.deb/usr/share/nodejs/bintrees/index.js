module.exports = {
    RBTree: require('./lib/rbtree'),
    BinTree: require('./lib/bintree')
};
