export function testUrlParamQuery(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=url.test.d.ts.map