export function testLogging(): void;
//# sourceMappingURL=logging.test.d.ts.map