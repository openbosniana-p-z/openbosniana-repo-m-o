'use strict';

require('./array-3411155e.cjs');
require('./object-ae1fc51e.cjs');
var _function = require('./function-57adae87.cjs');



exports.apply = _function.apply;
exports.callAll = _function.callAll;
exports.equalityDeep = _function.equalityDeep;
exports.equalityFlat = _function.equalityFlat;
exports.equalityStrict = _function.equalityStrict;
exports.id = _function.id;
exports.isOneOf = _function.isOneOf;
exports.nop = _function.nop;
//# sourceMappingURL=function.cjs.map
