export function testEnqueueDequeue(tc: t.TestCase): void;
export function testSelectivePop(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=list.test.d.ts.map