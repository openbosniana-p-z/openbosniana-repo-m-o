export function testRepeatPromise(tc: t.TestCase): Promise<void>;
export function testispromise(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=promise.test.d.ts.map