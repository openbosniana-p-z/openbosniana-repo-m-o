export function median(arr: Array<number>): number;
export function average(arr: Array<number>): number;
//# sourceMappingURL=statistics.d.ts.map