'use strict';

require('./math-1b3e5302.cjs');
var sort = require('./sort-a5fb4cd9.cjs');



exports._insertionSort = sort._insertionSort;
exports.insertionSort = sort.insertionSort;
exports.quicksort = sort.quicksort;
//# sourceMappingURL=sort.cjs.map
