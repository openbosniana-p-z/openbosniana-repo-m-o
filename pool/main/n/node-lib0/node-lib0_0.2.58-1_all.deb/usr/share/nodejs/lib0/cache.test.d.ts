export function testCache(tc: t.TestCase): Promise<void>;
import * as t from "./testing.js";
//# sourceMappingURL=cache.test.d.ts.map