export function callAll(fs: Array<Function>, args: Array<any>, i?: number): void;
export function nop(): void;
export function apply<T>(f: () => T): T;
export function id<A>(a: A): A;
export function equalityStrict<T>(a: T, b: T): boolean;
export function equalityFlat<T>(a: object | T[], b: object | T[]): boolean;
export function equalityDeep(a: any, b: any): boolean;
export function isOneOf<V, OPTS extends V>(value: V, options: OPTS[]): boolean;
//# sourceMappingURL=function.d.ts.map