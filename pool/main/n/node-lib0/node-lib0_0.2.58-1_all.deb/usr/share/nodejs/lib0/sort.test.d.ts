export function testSortUint16(tc: t.TestCase): void;
export function testSortUint32(tc: t.TestCase): void;
export function testSortObjectUint32(tc: t.TestCase): void;
export function testListVsArrayPerformance(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=sort.test.d.ts.map