'use strict';

var isomorphic_js = require('isomorphic.js');



Object.defineProperty(exports, 'cryptoRandomBuffer', {
	enumerable: true,
	get: function () { return isomorphic_js.cryptoRandomBuffer; }
});
Object.defineProperty(exports, 'performance', {
	enumerable: true,
	get: function () { return isomorphic_js.performance; }
});
//# sourceMappingURL=isomorphic.cjs.map
