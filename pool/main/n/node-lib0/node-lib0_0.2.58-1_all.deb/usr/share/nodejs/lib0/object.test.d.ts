export function testObject(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=object.test.d.ts.map