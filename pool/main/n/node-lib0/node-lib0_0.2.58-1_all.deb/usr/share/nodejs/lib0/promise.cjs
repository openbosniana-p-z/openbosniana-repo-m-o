'use strict';

require('./time-65154b95.cjs');
var promise = require('./promise-9e6a3750.cjs');
require('./metric.cjs');
require('./math-1b3e5302.cjs');



exports.all = promise.all;
exports.create = promise.create;
exports.createEmpty = promise.createEmpty;
exports.isPromise = promise.isPromise;
exports.reject = promise.reject;
exports.resolve = promise.resolve;
exports.resolveWith = promise.resolveWith;
exports.until = promise.until;
exports.wait = promise.wait;
//# sourceMappingURL=promise.cjs.map
