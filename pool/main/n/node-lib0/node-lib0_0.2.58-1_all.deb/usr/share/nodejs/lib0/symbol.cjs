'use strict';

var symbol = require('./symbol-df7c8416.cjs');



exports.create = symbol.create;
exports.isSymbol = symbol.isSymbol;
//# sourceMappingURL=symbol.cjs.map
