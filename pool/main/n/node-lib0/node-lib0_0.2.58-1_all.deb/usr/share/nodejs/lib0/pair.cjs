'use strict';

var pair = require('./pair-1a02d870.cjs');



exports.Pair = pair.Pair;
exports.create = pair.create;
exports.createReversed = pair.createReversed;
exports.forEach = pair.forEach;
exports.map = pair.map;
//# sourceMappingURL=pair.cjs.map
