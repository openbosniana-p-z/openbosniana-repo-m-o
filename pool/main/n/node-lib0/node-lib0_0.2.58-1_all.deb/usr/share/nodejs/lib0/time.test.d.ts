export function testTime(tc: t.TestCase): void;
export function testHumanDuration(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=time.test.d.ts.map