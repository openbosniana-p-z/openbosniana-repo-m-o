export function _insertionSort<T>(arr: T[], lo: number, hi: number, compare: (arg0: T, arg1: T) => number): void;
export function insertionSort<T>(arr: T[], compare: (arg0: T, arg1: T) => number): void;
export function quicksort<T>(arr: T[], compare: (arg0: T, arg1: T) => number): void;
//# sourceMappingURL=sort.d.ts.map