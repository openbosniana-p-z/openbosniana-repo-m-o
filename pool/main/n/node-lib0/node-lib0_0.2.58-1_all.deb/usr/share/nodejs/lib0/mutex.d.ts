export function createMutex(): mutex;
export type mutex = (cb: () => void, elseCb?: (() => void) | undefined) => any;
//# sourceMappingURL=mutex.d.ts.map