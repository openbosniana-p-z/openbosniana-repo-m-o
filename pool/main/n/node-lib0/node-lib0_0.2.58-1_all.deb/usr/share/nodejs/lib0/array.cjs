'use strict';

var array = require('./array-3411155e.cjs');



exports.appendTo = array.appendTo;
exports.copy = array.copy;
exports.create = array.create;
exports.equalFlat = array.equalFlat;
exports.every = array.every;
exports.flatten = array.flatten;
exports.from = array.from;
exports.isArray = array.isArray;
exports.last = array.last;
exports.some = array.some;
//# sourceMappingURL=array.cjs.map
