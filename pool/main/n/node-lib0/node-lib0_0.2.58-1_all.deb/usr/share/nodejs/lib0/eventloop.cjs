'use strict';

var eventloop = require('./eventloop-4ee07c3e.cjs');



exports.Animation = eventloop.Animation;
exports.animationFrame = eventloop.animationFrame;
exports.createDebouncer = eventloop.createDebouncer;
exports.enqueue = eventloop.enqueue;
exports.idleCallback = eventloop.idleCallback;
exports.interval = eventloop.interval;
exports.timeout = eventloop.timeout;
//# sourceMappingURL=eventloop.cjs.map
