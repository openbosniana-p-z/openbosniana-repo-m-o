export function testBitx(tc: t.TestCase): void;
export function testBitsx(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=binary.test.d.ts.map