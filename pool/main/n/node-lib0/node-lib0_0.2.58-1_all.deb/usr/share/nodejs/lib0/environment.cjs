'use strict';

require('./map-96a9e7ff.cjs');
require('./string-dd67d7f2.cjs');
require('./conditions-13f28ebd.cjs');
require('./storage.cjs');
require('./function-57adae87.cjs');
var environment = require('./environment-e5fdc92a.cjs');
require('./array-3411155e.cjs');
require('./object-ae1fc51e.cjs');



exports.getConf = environment.getConf;
exports.getParam = environment.getParam;
exports.getVariable = environment.getVariable;
exports.hasConf = environment.hasConf;
exports.hasParam = environment.hasParam;
exports.isBrowser = environment.isBrowser;
exports.isMac = environment.isMac;
exports.isNode = environment.isNode;
exports.production = environment.production;
exports.supportsColor = environment.supportsColor;
//# sourceMappingURL=environment.cjs.map
