'use strict';

var math = require('./math-1b3e5302.cjs');
var binary = require('./binary-d6f1a38d.cjs');
var isomorphic_js = require('isomorphic.js');

const rand = Math.random;

const uint32 = () => new Uint32Array(isomorphic_js.cryptoRandomBuffer(4))[0];

const uint53 = () => {
  const arr = new Uint32Array(isomorphic_js.cryptoRandomBuffer(8));
  return (arr[0] & binary.BITS21) * (binary.BITS32 + 1) + (arr[1] >>> 0)
};

/**
 * @template T
 * @param {Array<T>} arr
 * @return {T}
 */
const oneOf = arr => arr[math.floor(rand() * arr.length)];

// @ts-ignore
const uuidv4Template = [1e7] + -1e3 + -4e3 + -8e3 + -1e11;
const uuidv4 = () => uuidv4Template.replace(/[018]/g, /** @param {number} c */ c =>
  (c ^ uint32() & 15 >> c / 4).toString(16)
);

exports.oneOf = oneOf;
exports.rand = rand;
exports.uint32 = uint32;
exports.uint53 = uint53;
exports.uuidv4 = uuidv4;
//# sourceMappingURL=random.cjs.map
