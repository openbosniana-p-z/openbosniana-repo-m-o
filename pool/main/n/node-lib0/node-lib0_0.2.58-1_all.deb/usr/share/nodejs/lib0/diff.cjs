'use strict';

require('./function-57adae87.cjs');
var diff = require('./diff-9d1c2eeb.cjs');
require('./array-3411155e.cjs');
require('./object-ae1fc51e.cjs');



exports.simpleDiff = diff.simpleDiff;
exports.simpleDiffArray = diff.simpleDiffArray;
exports.simpleDiffString = diff.simpleDiffString;
exports.simpleDiffStringWithCursor = diff.simpleDiffStringWithCursor;
//# sourceMappingURL=diff.cjs.map
