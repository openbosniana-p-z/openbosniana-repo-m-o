export const MAX_SAFE_INTEGER: number;
export const MIN_SAFE_INTEGER: number;
export const LOWEST_INT32: number;
/**
 * @type {number}
 */
export const HIGHEST_INT32: number;
/**
 * @module number
 */
export const isInteger: (number: unknown) => boolean;
export const isNaN: (number: unknown) => boolean;
export const parseInt: (string: string, radix?: number | undefined) => number;
//# sourceMappingURL=number.d.ts.map