'use strict';

require('./math-1b3e5302.cjs');
require('./binary-d6f1a38d.cjs');
var number = require('./number-10f230ff.cjs');



exports.HIGHEST_INT32 = number.HIGHEST_INT32;
exports.LOWEST_INT32 = number.LOWEST_INT32;
exports.MAX_SAFE_INTEGER = number.MAX_SAFE_INTEGER;
exports.MIN_SAFE_INTEGER = number.MIN_SAFE_INTEGER;
exports.isInteger = number.isInteger;
exports.isNaN = number.isNaN;
exports.parseInt = number.parseInt;
//# sourceMappingURL=number.cjs.map
