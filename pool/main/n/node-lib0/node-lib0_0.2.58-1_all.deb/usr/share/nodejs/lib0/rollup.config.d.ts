declare const _default: ({
    input: string;
    output: {
        file: string;
        format: string;
        sourcemap: boolean;
        dir?: undefined;
        entryFileNames?: undefined;
        chunkFileNames?: undefined;
    };
    plugins: import("../../../usr/share/node_modules/rollup/dist/rollup").Plugin[];
    external?: undefined;
} | {
    input: string[];
    output: {
        dir: string;
        format: string;
        sourcemap: boolean;
        entryFileNames: string;
        chunkFileNames: string;
        file?: undefined;
    };
    external: string[];
    plugins?: undefined;
} | {
    input: string;
    output: {
        dir: string;
        format: string;
        sourcemap: boolean;
        entryFileNames: string;
        chunkFileNames: string;
        file?: undefined;
    };
    external: string[];
    plugins?: undefined;
})[];
export default _default;
//# sourceMappingURL=rollup.config.d.ts.map