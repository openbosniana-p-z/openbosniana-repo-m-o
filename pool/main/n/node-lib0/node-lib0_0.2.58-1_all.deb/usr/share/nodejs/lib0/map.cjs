'use strict';

var map = require('./map-96a9e7ff.cjs');



exports.all = map.all;
exports.any = map.any;
exports.copy = map.copy;
exports.create = map.create;
exports.map = map.map;
exports.setIfUndefined = map.setIfUndefined;
//# sourceMappingURL=map.cjs.map
