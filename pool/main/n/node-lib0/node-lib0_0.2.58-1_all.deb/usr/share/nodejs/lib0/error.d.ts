export function create(s: string): Error;
export function methodUnimplemented(): never;
export function unexpectedCase(): never;
//# sourceMappingURL=error.d.ts.map