export function testDiffing(tc: t.TestCase): void;
export function testRepeatDiffing(tc: t.TestCase): void;
export function testSimpleDiffWithCursor(tc: t.TestCase): void;
export function testArrayDiffing(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=diff.test.d.ts.map