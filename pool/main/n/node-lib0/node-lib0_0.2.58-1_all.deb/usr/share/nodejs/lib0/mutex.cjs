'use strict';

var mutex = require('./mutex-80f93169.cjs');



exports.createMutex = mutex.createMutex;
//# sourceMappingURL=mutex.cjs.map
