export function testMedian(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=statistics.test.d.ts.map