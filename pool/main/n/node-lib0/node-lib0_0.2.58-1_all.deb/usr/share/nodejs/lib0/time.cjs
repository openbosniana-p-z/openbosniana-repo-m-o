'use strict';

require('./metric.cjs');
require('./math-1b3e5302.cjs');
var time = require('./time-65154b95.cjs');



exports.getDate = time.getDate;
exports.getUnixTime = time.getUnixTime;
exports.humanizeDuration = time.humanizeDuration;
//# sourceMappingURL=time.cjs.map
