export function testEventloopOrder(tc: t.TestCase): Promise<void[]>;
export function testTimeout(tc: t.TestCase): Promise<void>;
export function testInterval(tc: t.TestCase): Promise<void>;
export function testAnimationFrame(tc: t.TestCase): Promise<void>;
export function testIdleCallback(tc: t.TestCase): Promise<void>;
import * as t from "./testing.js";
//# sourceMappingURL=eventloop.test.d.ts.map