export function testStorageModule(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=storage.test.d.ts.map