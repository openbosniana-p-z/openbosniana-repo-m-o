export function getDate(): Date;
/**
 * Return current unix time.
 *
 * @return {number}
 */
export const getUnixTime: () => number;
export function humanizeDuration(d: number): string;
//# sourceMappingURL=time.d.ts.map