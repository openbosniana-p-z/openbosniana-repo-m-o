export class QueueNode {
    /**
     * @type {QueueNode|null}
     */
    next: QueueNode | null;
}
export class Queue {
    /**
     * @type {QueueNode | null}
     */
    start: QueueNode | null;
    /**
     * @type {QueueNode | null}
     */
    end: QueueNode | null;
}
export function create(): Queue;
export function isEmpty(queue: Queue): boolean;
export function enqueue(queue: Queue, n: QueueNode): void;
export function dequeue(queue: Queue): QueueNode | null;
//# sourceMappingURL=queue.d.ts.map