export const rand: () => number;
export function uint32(): number;
export function uint53(): number;
export function oneOf<T>(arr: T[]): T;
export function uuidv4(): any;
//# sourceMappingURL=random.d.ts.map