export function nottestingNotTested(): void;
export function testComparing(tc: t.TestCase): void;
export function testFailing(): void;
export function testSkipping(): void;
export function testAsync(): Promise<void>;
export function testRepeatRepetition(): void;
import * as t from "./testing.js";
//# sourceMappingURL=testing.test.d.ts.map