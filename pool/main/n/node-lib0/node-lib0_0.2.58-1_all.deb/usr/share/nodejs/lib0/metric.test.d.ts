export function testMetricPrefix(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=metric.test.d.ts.map