export function undefinedToNull<T>(v: T | null | undefined): T | null;
//# sourceMappingURL=conditions.d.ts.map