export function testMap(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=map.test.d.ts.map