'use strict';

require('./math-1b3e5302.cjs');
var statistics = require('./statistics-7f1639fb.cjs');



exports.average = statistics.average;
exports.median = statistics.median;
//# sourceMappingURL=statistics.cjs.map
