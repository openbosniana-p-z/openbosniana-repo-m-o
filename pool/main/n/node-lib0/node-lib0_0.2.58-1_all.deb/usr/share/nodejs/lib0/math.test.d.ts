export function testMath(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=math.test.d.ts.map