'use strict';

var object = require('./object-ae1fc51e.cjs');



exports.assign = object.assign;
exports.create = object.create;
exports.equalFlat = object.equalFlat;
exports.every = object.every;
exports.forEach = object.forEach;
exports.hasProperty = object.hasProperty;
exports.keys = object.keys;
exports.length = object.length;
exports.map = object.map;
exports.some = object.some;
//# sourceMappingURL=object.cjs.map
