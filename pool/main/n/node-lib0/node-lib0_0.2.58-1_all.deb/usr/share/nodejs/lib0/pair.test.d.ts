export function testPair(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=pair.test.d.ts.map