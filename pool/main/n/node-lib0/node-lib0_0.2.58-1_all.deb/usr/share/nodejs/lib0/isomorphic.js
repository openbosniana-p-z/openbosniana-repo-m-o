/**
 * Isomorphic library exports from isomorphic.js.
 *
 * @module isomorphic
 */

// @ts-ignore
export { performance, cryptoRandomBuffer } from 'isomorphic.js'
