export function testRetrieveElements(): Promise<void>;
//# sourceMappingURL=indexeddb.test.d.ts.map