export function testFirst<T>(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=set.test.d.ts.map