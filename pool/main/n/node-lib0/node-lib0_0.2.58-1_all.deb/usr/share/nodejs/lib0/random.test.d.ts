export function testUint32(tc: t.TestCase): void;
export function testUint53(tc: t.TestCase): void;
export function testUuidv4(tc: t.TestCase): void;
export function testUuidv4Overlaps(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=random.test.d.ts.map