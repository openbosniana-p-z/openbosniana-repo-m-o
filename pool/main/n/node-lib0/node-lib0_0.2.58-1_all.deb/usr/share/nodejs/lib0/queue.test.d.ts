export function testEnqueueDequeue(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=queue.test.d.ts.map