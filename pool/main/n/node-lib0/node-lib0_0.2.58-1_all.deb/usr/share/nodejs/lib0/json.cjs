'use strict';

var json = require('./json-4be2e22b.cjs');



exports.parse = json.parse;
exports.stringify = json.stringify;
//# sourceMappingURL=json.cjs.map
