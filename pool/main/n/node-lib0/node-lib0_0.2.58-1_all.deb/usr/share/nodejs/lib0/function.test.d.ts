export function testDeepEquality(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=function.test.d.ts.map