'use strict';

var set = require('./set-9d5d202c.cjs');



exports.create = set.create;
exports.first = set.first;
exports.from = set.from;
exports.toArray = set.toArray;
//# sourceMappingURL=set.cjs.map
