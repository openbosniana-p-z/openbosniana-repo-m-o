export function testNumber(tc: t.TestCase): void;
export function testShiftVsDivision(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=number.test.d.ts.map