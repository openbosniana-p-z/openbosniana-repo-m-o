export function decodeQueryParams(url: string): {
    [x: string]: string;
};
export function encodeQueryParams(params: {
    [x: string]: string;
}): string;
//# sourceMappingURL=url.d.ts.map