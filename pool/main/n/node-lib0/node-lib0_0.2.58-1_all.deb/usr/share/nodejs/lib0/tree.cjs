'use strict';

var tree = require('./tree-08b53a00.cjs');



exports.Tree = tree.Tree;
//# sourceMappingURL=tree.cjs.map
