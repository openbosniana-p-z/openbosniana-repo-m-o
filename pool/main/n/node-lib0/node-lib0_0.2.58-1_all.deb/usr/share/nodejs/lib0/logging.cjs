'use strict';

require('./environment-e5fdc92a.cjs');
require('./symbol-df7c8416.cjs');
require('./pair-1a02d870.cjs');
require('./dom-9a79b2cd.cjs');
require('./json-4be2e22b.cjs');
require('./map-96a9e7ff.cjs');
require('./eventloop-4ee07c3e.cjs');
require('./math-1b3e5302.cjs');
require('./time-65154b95.cjs');
require('./function-57adae87.cjs');
var logging = require('./logging-5ff940fb.cjs');
require('./string-dd67d7f2.cjs');
require('./conditions-13f28ebd.cjs');
require('./storage.cjs');
require('./metric.cjs');
require('./array-3411155e.cjs');
require('./object-ae1fc51e.cjs');



exports.BLUE = logging.BLUE;
exports.BOLD = logging.BOLD;
exports.GREEN = logging.GREEN;
exports.GREY = logging.GREY;
exports.ORANGE = logging.ORANGE;
exports.PURPLE = logging.PURPLE;
exports.RED = logging.RED;
exports.UNBOLD = logging.UNBOLD;
exports.UNCOLOR = logging.UNCOLOR;
exports.VConsole = logging.VConsole;
exports.createModuleLogger = logging.createModuleLogger;
exports.createVConsole = logging.createVConsole;
exports.group = logging.group;
exports.groupCollapsed = logging.groupCollapsed;
exports.groupEnd = logging.groupEnd;
exports.print = logging.print;
exports.printCanvas = logging.printCanvas;
exports.printDom = logging.printDom;
exports.printError = logging.printError;
exports.printImg = logging.printImg;
exports.printImgBase64 = logging.printImgBase64;
exports.vconsoles = logging.vconsoles;
exports.warn = logging.warn;
//# sourceMappingURL=logging.cjs.map
