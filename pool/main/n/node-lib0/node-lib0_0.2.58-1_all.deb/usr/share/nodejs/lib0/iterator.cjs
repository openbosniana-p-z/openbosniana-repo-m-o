'use strict';

var iterator = require('./iterator-0b6eec8d.cjs');



exports.createIterator = iterator.createIterator;
exports.iteratorFilter = iterator.iteratorFilter;
exports.iteratorMap = iterator.iteratorMap;
exports.mapIterator = iterator.mapIterator;
//# sourceMappingURL=iterator.cjs.map
