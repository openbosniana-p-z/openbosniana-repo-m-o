export { performance, cryptoRandomBuffer } from "isomorphic.js";
//# sourceMappingURL=isomorphic.d.ts.map