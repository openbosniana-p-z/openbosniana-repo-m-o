export function testRepeatBase64Encoding(tc: t.TestCase): void;
export function testAnyEncoding(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=buffer.test.d.ts.map