export function testGeneratorXoroshiro128plus(tc: t.TestCase): void;
export function testGeneratorXorshift32(tc: t.TestCase): void;
export function testGeneratorMt19937(tc: t.TestCase): void;
export function testNumberDistributions(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=prng.test.d.ts.map