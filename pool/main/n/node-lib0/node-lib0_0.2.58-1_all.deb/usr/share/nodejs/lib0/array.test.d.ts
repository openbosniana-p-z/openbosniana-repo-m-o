export function testAppend(tc: t.TestCase): void;
export function testflatten(tc: t.TestCase): void;
export function testIsArray(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=array.test.d.ts.map