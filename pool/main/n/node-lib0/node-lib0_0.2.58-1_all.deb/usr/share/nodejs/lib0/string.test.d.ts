export function testLowercaseTransformation(tc: t.TestCase): void;
export function testRepeatStringUtf8Encoding(tc: t.TestCase): void;
export function testRepeatStringUtf8Decoding(tc: t.TestCase): void;
export function testBomEncodingDecoding(tc: t.TestCase): void;
export function testSplice(tc: t.TestCase): void;
import * as t from "./testing.js";
//# sourceMappingURL=string.test.d.ts.map