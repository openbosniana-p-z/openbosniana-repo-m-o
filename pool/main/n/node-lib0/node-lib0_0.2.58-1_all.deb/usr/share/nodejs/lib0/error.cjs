'use strict';

var error = require('./error-3832f9ce.cjs');



exports.create = error.create;
exports.methodUnimplemented = error.methodUnimplemented;
exports.unexpectedCase = error.unexpectedCase;
//# sourceMappingURL=error.cjs.map
