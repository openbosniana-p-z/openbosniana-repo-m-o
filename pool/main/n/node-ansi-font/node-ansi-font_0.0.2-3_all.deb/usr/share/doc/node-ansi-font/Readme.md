# ansi-font #

ANSI font styling utils

## Install ##

    npm install ansi-font

## Require ##

    var font = require('!raw.github.com/Gozala/ansi-font/v0.0.1/index')
