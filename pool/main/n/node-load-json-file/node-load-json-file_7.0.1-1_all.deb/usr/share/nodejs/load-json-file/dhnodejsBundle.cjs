Object.defineProperty(exports, '__esModule', { value: true });

const node_fs = require('fs');

const {readFile} = node_fs.promises;

const parse = (buffer, {beforeParse, reviver} = {}) => {
	// Unlike `buffer.toString()` and `fs.readFile(path, 'utf8')`, `TextDecoder`` will remove BOM.
	let data = new TextDecoder().decode(buffer);

	if (typeof beforeParse === 'function') {
		data = beforeParse(data);
	}

	return JSON.parse(data, reviver);
};

async function loadJsonFile(filePath, options) {
	const buffer = await readFile(filePath);
	return parse(buffer, options);
}

function loadJsonFileSync(filePath, options) {
	const buffer = node_fs.readFileSync(filePath);
	return parse(buffer, options);
}

exports.loadJsonFile = loadJsonFile;
exports.loadJsonFileSync = loadJsonFileSync;
