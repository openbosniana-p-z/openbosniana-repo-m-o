/*
 * NASPRO - The NASPRO Architecture for Sound PROcessing
 * Portable runtime library
 *
 * Copyright (C) 2007-2014 Stefano D'Angelo
 *
 * See the COPYING file for license conditions.
 */

/*
   Title: NASPRO core

   *Version*: 0.5.1, *API*: 5.0.2.

   About:

     <NASPRO core at http://naspro.sourceforge.net/libraries.html#naspro-core>
     is the portable runtime library at the bottom of the <NASPRO Architecture
     for Sound PROcessing at http://naspro.sourceforge.net/>.

     It abstracts away some platform- and compiler-specific features, implements
     a small collection of abstract data types and provides a couple of useful
     APIs to help with software development in general.

     The code is released under the <LGPL 2.1 at
     http://www.gnu.org/licenses/lgpl-2.1.html>.

   Supported platforms/compilers:

     It is written in C99 and should work on all POSIX-1.2008-compliant
     platforms, assuming that malloc() and free() are thread-safe and errno is
     thread-local.

     It should also work (but it's never been tested) on Windows XP and later,
     32 and 64 bit versions.

     It has only been built and tested using the <GCC at http://gcc.gnu.org/>
     compiler, for which it has special support and whose version is supposed to
     be >= 2.95. Adding support for other compilers, if needed at all, should be
     relatively easy.

   API conventions:

     * All functions are thread-safe unless otherwise specified;
     * All strings are null-terminated and UTF-8 encoded according to the
       Unicode 6.0 standard and without BOM (byte-order-mark) characters, unless
       otherwise specified;
     * No function does input validation, hence, in case the API is misused in
       this sense, the results are undefined.

   Runtime dependencies:

     * Standard C and math libraries;
     * Platform-specific threading library (i.e., Pthreads on all platforms
       except Windows).

   Build-time dependencies:

     * An environment capable of running Autotools-based build systems;
     * (optional) <GNU Autoconf at http://www.gnu.org/software/autoconf/> >=
       2.69, <GNU Automake at http://www.gnu.org/software/automake/> and
       <GNU Libtool at http://www.gnu.org/software/libtool/> to regenerate the
       build system;
     * (optional) <Natural Docs at http://www.naturaldocs.org/> >= 1.5 to
       regenerate the build system and/or the documentation.

   Usage:

      Just include <NASPRO/core/lib.h> in your source files and use the
      <pkg-config at http://pkg-config.freedesktop.org/> tool to retrieve
      compiler and linker flags (package name: nacore-5).
 */

#ifndef _NASPRO_CORE_LIB_H
#define _NASPRO_CORE_LIB_H

#include <stddef.h>
#include <stdarg.h>
#include <inttypes.h>
#include <errno.h>
#include <locale.h>

#ifdef _WIN32
# include <windows.h>
#else
# include <pthread.h>
# ifdef __APPLE__
#  include <xlocale.h>
# endif
#endif

#include <NASPRO/core/cc.h>

#ifdef _NACORE_INTERNAL_H
# define _NACORE_DEF	NACORE_PUBLIC NACORE_EXPORT
#else
# define _NACORE_DEF	NACORE_PUBLIC NACORE_IMPORT
#endif

#include <NASPRO/core/types.h>
#include <NASPRO/core/list.h>
#include <NASPRO/core/avl.h>
#include <NASPRO/core/string.h>
#include <NASPRO/core/msg.h>
#include <NASPRO/core/env.h>
#include <NASPRO/core/locale.h>
#include <NASPRO/core/fs.h>
#include <NASPRO/core/dl.h>
#include <NASPRO/core/thread.h>
#include <NASPRO/core/mutex.h>
#include <NASPRO/core/sem.h>

#endif
