<hr>
<p>
Ten system wyszukiwania jest oparty na
<strong><a href="http://www.namazu.org/">Namazu</a> <!-- VERSION --> v <!-- VERSION --></strong>
</p>
<p>Mniej udan�, lecz wi�ksz� cz�� t�umaczenia na j�zyk polski(?) wykona� Tomasz Wittner dn. 07-08-2002, podpuszczony przez Krzysztofa Drewicza (alias hunter), developera PLD i t�umacza list rozwijanych, kt�rego podpu�ci� do zajmowania si� Namazu Tomasz Wittner ...
 </p>
<address>
<!-- ADDRESS -->
<a href="mailto:foobar@namazu.org">foobar@namazu.org</a>
<!-- ADDRESS -->
</address>
</body>
</html>
