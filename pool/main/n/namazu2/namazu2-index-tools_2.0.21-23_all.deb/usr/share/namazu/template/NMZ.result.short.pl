<dt>${namazu::counter}. <strong><a href="${uri}">${title}</a></strong> (wynik: ${namazu::score})</dt>
<dd><a href="${uri}">${uri}</a> (${size} bajt�w)<br><br></dd>
