<dt>${namazu::counter}. <strong><a href="${uri}">${title}</a></strong> (wynik: ${namazu::score})</dt>
<dd><strong>Autor</strong>: <em>${author}</em></dd>
<dd><strong>Data</strong>: <em>${date}</em></dd>
<dd>${summary}</dd>
<dd><a href="${uri}">${uri}</a> (${size} bajt�w)<br><br></dd>
