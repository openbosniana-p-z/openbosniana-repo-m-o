#ifndef _CODECONV_H
#define _CODECONV_H

extern int nmz_codeconv_internal(char *);
extern char *nmz_codeconv_external(const char *);
extern void nmz_codeconv_query ( char *query );

#endif /* _CODECONV_H */
