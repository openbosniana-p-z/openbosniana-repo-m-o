#ifndef _L10N_JA_H
#define _L10N_JA_H

extern int nmz_is_lang_ja ( void );

#endif /* _L10N_JA_H */
