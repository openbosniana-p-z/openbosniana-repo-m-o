#ifndef _WAKATI_H
#define _WAKATI_H

enum {
    KANJI,
    KATAKANA,
    HIRAGANA,
    OTHER
};

extern int nmz_wakati(char*);

#endif /* _WAKATI_H */

