#ifndef _VARIABLE_H
#define _VARIABLE_H

extern struct nmz_names NMZ;
extern struct nmz_files Nmz;

#endif /* _VARIABLE_H */
