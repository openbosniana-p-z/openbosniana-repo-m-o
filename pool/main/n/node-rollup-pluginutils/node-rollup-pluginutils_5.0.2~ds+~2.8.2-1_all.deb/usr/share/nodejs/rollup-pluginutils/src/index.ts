export { default as addExtension } from './addExtension';
export { default as attachScopes } from './attachScopes';
export { default as createFilter } from './createFilter';
export { default as makeLegalIdentifier } from './makeLegalIdentifier';
export { default as dataToEsm } from './dataToEsm';
export { default as extractAssignedNames } from './extractAssignedNames';
