# grunt-known-options

These are the known options used in Grunt.

## Installing

```shell
npm install grunt-known-options --save
```

## Usage

```js
var knownOptions = require('grunt-known-options');
// You now have an object of known Grunt options.
```
