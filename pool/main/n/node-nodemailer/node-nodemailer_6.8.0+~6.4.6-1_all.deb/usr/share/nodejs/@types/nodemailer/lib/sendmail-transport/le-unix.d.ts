/// <reference types="node" />

import { Transform } from 'stream';

declare class LeUnix extends Transform {}

export = LeUnix;
