/// <reference types="node" />

import { Transform } from 'stream';

declare class LeWindows extends Transform {}

export = LeWindows;
