export function detectMimeType(filename: string | false): string;
export function detectExtension(mimeType: string | false): string;
