package router

// This file exists to allow `go fmt` to traverse here on its own. The build tags were keeping it out before
