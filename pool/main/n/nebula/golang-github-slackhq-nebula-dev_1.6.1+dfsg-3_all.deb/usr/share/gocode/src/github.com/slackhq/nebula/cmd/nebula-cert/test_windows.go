package main

const NoSuchFileError = "The system cannot find the file specified."
const NoSuchDirError = "The system cannot find the path specified."
