package nebula

/*

import (
	proto "google.golang.org/protobuf/proto"
)

func HandleMetaProto(p []byte) {
	m := &NebulaMeta{}
	err := proto.Unmarshal(p, m)
	if err != nil {
		l.Debugf("problem unmarshaling meta message: %s", err)
	}
	//fmt.Println(m)
}

*/
