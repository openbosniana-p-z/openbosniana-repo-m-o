//go:build !darwin
// +build !darwin

package nebula

const immediatelyForwardToSelf bool = false
