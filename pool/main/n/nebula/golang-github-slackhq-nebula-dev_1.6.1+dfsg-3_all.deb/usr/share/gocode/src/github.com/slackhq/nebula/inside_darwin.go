package nebula

const immediatelyForwardToSelf bool = true
