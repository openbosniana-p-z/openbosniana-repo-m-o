package main

const NoSuchFileError = "no such file or directory"
const NoSuchDirError = "no such file or directory"
