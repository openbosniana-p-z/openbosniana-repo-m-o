// Type definitions for compressible 2.0
// Project: https://github.com/jshttp/compressible#readme
// Definitions by: BendingBender <https://github.com/BendingBender>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

export = compressible;

declare function compressible(type: string): boolean | undefined;
