# Is Node?
Detects if the current process is a node application or not.

## Install
`$ npm install is-node`

## Usage
```javascript
var isNode = require('is-node');

if (isNode) {
  console.log("Hey, I'm a node process!");
}
```
