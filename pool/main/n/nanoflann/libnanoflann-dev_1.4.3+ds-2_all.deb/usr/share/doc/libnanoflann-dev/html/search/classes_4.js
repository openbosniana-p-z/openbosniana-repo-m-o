var searchData=
[
  ['l1_5fadaptor_0',['L1_Adaptor',['../structnanoflann_1_1L1__Adaptor.html',1,'nanoflann']]],
  ['l2_5fadaptor_1',['L2_Adaptor',['../structnanoflann_1_1L2__Adaptor.html',1,'nanoflann']]],
  ['l2_5fsimple_5fadaptor_2',['L2_Simple_Adaptor',['../structnanoflann_1_1L2__Simple__Adaptor.html',1,'nanoflann']]],
  ['l2_5fsimple_5fadaptor_3c_20t_2c_20datasource_2c_20distancetype_2c_20uint32_5ft_20_3e_3',['L2_Simple_Adaptor&lt; T, DataSource, DistanceType, uint32_t &gt;',['../structnanoflann_1_1L2__Simple__Adaptor.html',1,'nanoflann']]]
];
