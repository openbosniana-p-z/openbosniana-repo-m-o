var searchData=
[
  ['load_2fsave_20auxiliary_20functions_0',['Load/save auxiliary functions',['../group__loadsave__grp.html',1,'']]]
];
