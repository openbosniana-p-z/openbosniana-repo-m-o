var searchData=
[
  ['result_20set_20classes_0',['Result set classes',['../group__result__sets__grp.html',1,'']]]
];
