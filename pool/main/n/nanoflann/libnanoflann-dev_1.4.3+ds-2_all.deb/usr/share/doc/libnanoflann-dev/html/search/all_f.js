var searchData=
[
  ['query_0',['query',['../structnanoflann_1_1KDTreeEigenMatrixAdaptor.html#a4b2bf5cd56879619c6ed7f42ef18b042',1,'nanoflann::KDTreeEigenMatrixAdaptor']]]
];
