var searchData=
[
  ['kd_2dtree_20classes_20and_20adaptors_0',['KD-tree classes and adaptors',['../group__kdtrees__grp.html',1,'']]]
];
