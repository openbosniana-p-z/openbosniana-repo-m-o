var searchData=
[
  ['node_0',['Node',['../structnanoflann_1_1KDTreeBaseClass_1_1Node.html',1,'nanoflann::KDTreeBaseClass']]]
];
