var searchData=
[
  ['memory_20allocation_0',['Memory allocation',['../group__memalloc__grp.html',1,'']]],
  ['metric_20_28distance_29_20classes_1',['Metric (distance) classes',['../group__metric__grp.html',1,'']]]
];
