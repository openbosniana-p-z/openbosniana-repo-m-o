var searchData=
[
  ['worst_5fitem_0',['worst_item',['../classnanoflann_1_1RadiusResultSet.html#aa9cd126887851cae286ff0ec4bcf3e0b',1,'nanoflann::RadiusResultSet']]]
];
