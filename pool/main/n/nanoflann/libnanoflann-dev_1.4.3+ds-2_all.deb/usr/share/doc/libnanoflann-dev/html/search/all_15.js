var searchData=
[
  ['wordsize_0',['WORDSIZE',['../group__memalloc__grp.html#ga40956ef8f797399b4f478df9fc1566f4',1,'nanoflann']]],
  ['worst_5fitem_1',['worst_item',['../classnanoflann_1_1RadiusResultSet.html#aa9cd126887851cae286ff0ec4bcf3e0b',1,'nanoflann::RadiusResultSet']]]
];
