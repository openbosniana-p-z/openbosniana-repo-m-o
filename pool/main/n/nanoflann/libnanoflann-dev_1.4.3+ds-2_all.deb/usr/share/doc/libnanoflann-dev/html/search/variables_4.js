var searchData=
[
  ['node_5ftype_0',['node_type',['../structnanoflann_1_1KDTreeBaseClass_1_1Node.html#ab5d372e7773e0e87e9054fa607dcc903',1,'nanoflann::KDTreeBaseClass::Node']]]
];
