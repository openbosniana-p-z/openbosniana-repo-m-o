var searchData=
[
  ['boundingbox_0',['BoundingBox',['../classnanoflann_1_1KDTreeBaseClass.html#ab26ec45a687c181e39d697fde52776fc',1,'nanoflann::KDTreeBaseClass::BoundingBox()'],['../classnanoflann_1_1KDTreeSingleIndexAdaptor.html#af02a71e7334a64a341e294907f1b80a5',1,'nanoflann::KDTreeSingleIndexAdaptor::BoundingBox()'],['../classnanoflann_1_1KDTreeSingleIndexDynamicAdaptor__.html#a9337dd1b5665928b32c5bfc4a14c13bd',1,'nanoflann::KDTreeSingleIndexDynamicAdaptor_::BoundingBox()']]]
];
