var searchData=
[
  ['radiusresultset_0',['RadiusResultSet',['../classnanoflann_1_1RadiusResultSet.html',1,'nanoflann']]]
];
