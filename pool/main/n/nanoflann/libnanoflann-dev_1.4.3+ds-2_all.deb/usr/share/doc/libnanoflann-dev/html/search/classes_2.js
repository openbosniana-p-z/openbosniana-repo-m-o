var searchData=
[
  ['indexdist_5fsorter_0',['IndexDist_Sorter',['../structnanoflann_1_1IndexDist__Sorter.html',1,'nanoflann']]],
  ['interval_1',['Interval',['../structnanoflann_1_1KDTreeBaseClass_1_1Interval.html',1,'nanoflann::KDTreeBaseClass']]]
];
