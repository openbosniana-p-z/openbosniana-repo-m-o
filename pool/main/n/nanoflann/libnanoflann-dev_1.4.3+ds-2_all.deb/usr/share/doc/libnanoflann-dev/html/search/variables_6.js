var searchData=
[
  ['right_0',['right',['../structnanoflann_1_1KDTreeBaseClass_1_1Node.html#a57064cf768eafff32e086e3f82070be7',1,'nanoflann::KDTreeBaseClass::Node']]],
  ['root_5fbbox_1',['root_bbox',['../classnanoflann_1_1KDTreeBaseClass.html#a54a6ff5162df8c46e70364279cc1f5b0',1,'nanoflann::KDTreeBaseClass']]]
];
