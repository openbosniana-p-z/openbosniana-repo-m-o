var searchData=
[
  ['init_5fvind_0',['init_vind',['../classnanoflann_1_1KDTreeSingleIndexAdaptor.html#ad475debc06ff957c9c51158a83aced31',1,'nanoflann::KDTreeSingleIndexAdaptor']]]
];
