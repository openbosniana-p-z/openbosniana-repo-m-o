var searchData=
[
  ['wordsize_0',['WORDSIZE',['../group__memalloc__grp.html#ga40956ef8f797399b4f478df9fc1566f4',1,'nanoflann']]]
];
