var searchData=
[
  ['m_5fsize_0',['m_size',['../classnanoflann_1_1KDTreeBaseClass.html#ab36be133922c5f3396c6d3b4c7ecfc8d',1,'nanoflann::KDTreeBaseClass']]],
  ['m_5fsize_5fat_5findex_5fbuild_1',['m_size_at_index_build',['../classnanoflann_1_1KDTreeBaseClass.html#a34ffab698631f4dd6fb17ffebb6ff7a5',1,'nanoflann::KDTreeBaseClass']]]
];
