// Deprecated

"use strict";

module.exports = function (obj) { return typeof obj === "function"; };
