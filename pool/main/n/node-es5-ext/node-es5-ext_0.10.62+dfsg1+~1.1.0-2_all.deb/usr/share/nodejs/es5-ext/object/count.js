"use strict";

var keys = require("./keys");

module.exports = function (obj) { return keys(obj).length; };
