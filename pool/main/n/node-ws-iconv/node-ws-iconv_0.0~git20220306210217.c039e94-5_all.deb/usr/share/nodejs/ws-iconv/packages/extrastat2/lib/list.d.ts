import { IList } from './types';
export declare function list(resolvedpath: string): Promise<IList[]>;
