/**
 * Created by user on 2020/5/1.
 */
export declare const defaultEncoding = "GBK";
export declare const sniffHTMLEncoding: import("../index").ICreateFnDecode<string, string>;
export declare const iconvDecode: import("../index").ICreateFnDecode<string, string>;
declare const _default: {
    defaultEncoding: string;
    sniffHTMLEncoding: import("../index").ICreateFnDecode<string, string>;
    iconvDecode: import("../index").ICreateFnDecode<string, string>;
};
export default _default;
