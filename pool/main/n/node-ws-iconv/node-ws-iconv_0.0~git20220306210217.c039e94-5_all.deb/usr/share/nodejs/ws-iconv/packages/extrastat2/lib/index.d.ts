import { IStatsExtra, IOptions } from './types';
export declare function statExtra(pathname: string, options?: IOptions): Promise<IStatsExtra>;
export default statExtra;
