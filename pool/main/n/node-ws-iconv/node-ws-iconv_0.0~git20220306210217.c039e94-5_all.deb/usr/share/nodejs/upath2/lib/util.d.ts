/**
 * Created by user on 2020/6/9.
 */
import { IPath } from './type';
import { PathWrap } from '../core';
import _strip_sep from 'path-strip-sep';
export { _strip_sep };
export declare function _replace_sep(who: Pick<IPath, 'sep' | 'name'>, input: string): string;
export declare function getStatic(who: any): PathWrap;
export declare function defaults(destination: any, ...input: any[]): any;
