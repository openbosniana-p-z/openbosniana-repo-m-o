import { IPath } from './type';
export declare function _fix_special<T extends string>(who: Pick<IPath, 'sep' | 'name'>, path: T, returnOldIfNoPreset?: boolean): T;
