/**
 * Created by user on 2018/1/27/027.
 */

export * from './fs';
import fs = require('./fs');

import { trimFilename } from './util';
export { trimFilename }

export default fs;
