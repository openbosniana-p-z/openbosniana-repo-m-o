"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.statExtra = void 0;
const tslib_1 = require("tslib");
const lib_1 = tslib_1.__importDefault(require("./lib"));
exports.statExtra = lib_1.default;
tslib_1.__exportStar(require("./lib/types"), exports);
exports.default = lib_1.default;
//# sourceMappingURL=index.js.map