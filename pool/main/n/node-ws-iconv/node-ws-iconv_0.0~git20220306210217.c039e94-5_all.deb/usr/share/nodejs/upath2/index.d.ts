/**
 * Created by user on 2017/12/10/010.
 */
import { upath } from './core';
import './lib/fs';
export = upath;
