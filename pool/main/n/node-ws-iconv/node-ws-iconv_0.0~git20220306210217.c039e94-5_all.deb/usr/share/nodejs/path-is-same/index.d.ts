export declare function _pathIsSame(p1: string, p2: string): boolean;
export declare function _assertInputArgv(p1: string, ...ps: string[]): void;
export declare function fsSameRealpath(p1: string, p2: string, ...ps: string[]): boolean;
export declare function pathIsSame(p1: string, p2: string, ...ps: string[]): boolean;
export default pathIsSame;
