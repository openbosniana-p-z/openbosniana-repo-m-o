"use strict";
/**
 * Created by user on 2017/12/10/010.
 */
const core_1 = require("./core");
require("./lib/fs");
module.exports = core_1.upath;
//# sourceMappingURL=index.js.map