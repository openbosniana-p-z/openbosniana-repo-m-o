/**
 * Created by user on 2019/3/17.
 */
export declare function trimFilename(name: any): string;
declare const _default: typeof import("./util");
export default _default;
