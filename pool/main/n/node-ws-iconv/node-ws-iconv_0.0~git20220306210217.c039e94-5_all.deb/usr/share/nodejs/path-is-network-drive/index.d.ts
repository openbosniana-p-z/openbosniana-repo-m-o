export declare function pathIsNetworkDrive(input: string): boolean;
export declare function matchNetworkDriveRoot(input: string): RegExpMatchArray;
export declare function matchNetworkDrive02(input: string): RegExpMatchArray;
export default pathIsNetworkDrive;
