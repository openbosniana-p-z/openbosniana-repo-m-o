"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pathStripSep = void 0;
function pathStripSep(input) {
    return input
        .replace(/([^/\\:])[/\\]+$/, '$1')
        .replace(/(^[/\\])[/\\]{2,}$/, '$1');
}
exports.pathStripSep = pathStripSep;
exports.default = pathStripSep;
//# sourceMappingURL=index.js.map