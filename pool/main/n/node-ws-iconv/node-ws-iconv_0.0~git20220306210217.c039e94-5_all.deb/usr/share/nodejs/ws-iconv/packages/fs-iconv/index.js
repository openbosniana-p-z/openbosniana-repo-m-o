"use strict";
/**
 * Created by user on 2018/1/27/027.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.trimFilename = void 0;
const tslib_1 = require("tslib");
tslib_1.__exportStar(require("./fs"), exports);
const fs = require("./fs");
const util_1 = require("./util");
Object.defineProperty(exports, "trimFilename", { enumerable: true, get: function () { return util_1.trimFilename; } });
exports.default = fs;
//# sourceMappingURL=index.js.map