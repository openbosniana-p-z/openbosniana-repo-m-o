/**
 * Created by user on 2017/12/10/010.
 */
declare module './type' {
    interface IPath {
        vaildNameEntry?<T = string>(name: T): T;
        filterNameEntry?<T = string>(name: T): string;
    }
}
export declare function vaildNameEntry<T = string>(name: T): T;
export declare function filterNameEntry<T = string>(name: T): string;
