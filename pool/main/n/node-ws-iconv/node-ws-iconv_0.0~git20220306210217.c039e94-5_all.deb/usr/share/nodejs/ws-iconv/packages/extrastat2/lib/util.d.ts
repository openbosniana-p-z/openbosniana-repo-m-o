export declare function reassemble(pathparts: string[]): string;
