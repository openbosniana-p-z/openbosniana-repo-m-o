export declare function pathInsideDirectory(input: string, dir: string): boolean;
export default pathInsideDirectory;
