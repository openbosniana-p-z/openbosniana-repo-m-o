'use strict';
const class_1 = require("./class");
module.exports = class_1.LineByLine;
//# sourceMappingURL=index.js.map