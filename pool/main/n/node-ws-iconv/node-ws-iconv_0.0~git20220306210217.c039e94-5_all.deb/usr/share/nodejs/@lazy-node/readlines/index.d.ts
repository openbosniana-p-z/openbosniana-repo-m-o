import { LineByLine } from './class';
export = LineByLine;
