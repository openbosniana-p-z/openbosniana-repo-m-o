export declare function pathStripSep(input: string): string;
export default pathStripSep;
