export var slice = [].slice;
