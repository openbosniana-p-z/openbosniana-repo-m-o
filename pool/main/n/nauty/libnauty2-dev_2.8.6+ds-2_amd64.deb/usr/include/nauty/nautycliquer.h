/* This file has all the included material used by cliquer-1.21
   and prototypes for the interface procedures in nautycliquer.c */

#ifndef NAUTYCLIQUER_H
#define NAUTYCLIQUER_H

#include "nauty.h"
#include "gtools.h"
#include <cliquer.h>

/* Procedures defined in nautycliquer.c */
extern int find_clique(graph *g, int m, int n,
				     int min, int max, boolean maximal);
extern int find_indset(graph *g, int m, int n,
				     int min, int max, boolean maximal);

#endif /* !NAUTYCLIQUER_H */
