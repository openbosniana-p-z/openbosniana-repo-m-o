var quote = require('quote-stream');
process.stdin.pipe(quote()).pipe(process.stdout);
