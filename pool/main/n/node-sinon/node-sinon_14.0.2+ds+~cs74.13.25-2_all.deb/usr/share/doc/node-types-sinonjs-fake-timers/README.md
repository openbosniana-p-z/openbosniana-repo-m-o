# Installation
> `npm install --save @types/sinonjs__fake-timers`

# Summary
This package contains type definitions for @sinonjs/fake-timers (https://github.com/sinonjs/fake-timers).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/sinonjs__fake-timers.

### Additional Details
 * Last updated: Wed, 23 Mar 2022 18:01:46 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Wim Looman](https://github.com/Nemo157), [Rogier Schouten](https://github.com/rogierschouten), [Yishai Zehavi](https://github.com/zyishai), [Remco Haszing](https://github.com/remcohaszing), and [Jaden Simon](https://github.com/JadenSimon).
