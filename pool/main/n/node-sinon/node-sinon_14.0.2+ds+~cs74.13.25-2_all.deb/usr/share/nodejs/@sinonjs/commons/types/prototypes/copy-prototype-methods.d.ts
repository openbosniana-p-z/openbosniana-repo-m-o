declare function _exports(prototype: any): any;
export = _exports;
