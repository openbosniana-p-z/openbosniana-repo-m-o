from . import nvpy
nvpy.main()
