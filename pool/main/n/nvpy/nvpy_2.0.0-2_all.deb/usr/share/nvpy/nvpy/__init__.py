# dummy __init__ for nvpy package
from .version import VERSION
