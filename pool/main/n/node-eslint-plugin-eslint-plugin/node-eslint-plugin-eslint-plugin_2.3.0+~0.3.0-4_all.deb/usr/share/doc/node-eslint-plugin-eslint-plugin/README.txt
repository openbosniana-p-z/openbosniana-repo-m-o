eslint-plugin-eslint-plugin

An ESLint plugin for linting ESLint plugins

Installation

You'll first need to install ESLint:

$ npm i eslint --save-dev

Next, install eslint-plugin-eslint-plugin:

$ npm install eslint-plugin-eslint-plugin --save-dev

Note: If you installed ESLint globally (using the -g flag) then you must also install eslint-plugin-eslint-plugin globally.

Usage

Add eslint-plugin to the plugins section of your .eslintrc configuration file. You can omit the eslint-plugin- prefix:

{
    "plugins": [
        "eslint-plugin"
    ]
}

Then configure the rules you want to use under the rules section.

{
    "rules": {
        "eslint-plugin/no-deprecated-report-api": "error"
    }
}

Supported Rules

✔️ indicates that a rule is recommended for all users.
🛠 indicates that a rule is fixable.

Name | ✔️ | 🛠 | Description
----- | ----- | ----- | -----
consistent-output |  |  | enforce consistent use of output assertions in rule tests
fixer-return | ✔️ |  | require fixer function to always return a value.
meta-property-ordering |  | 🛠 | enforce the order of meta properties
no-deprecated-context-methods |  | 🛠 | disallow usage of deprecated methods on rule context objects
no-deprecated-report-api | ✔️ | 🛠 | disallow use of the deprecated context.report() API
no-identical-tests | ✔️ | 🛠 | disallow identical tests
no-missing-placeholders | ✔️ |  | disallow missing placeholders in rule report messages
no-unused-placeholders | ✔️ |  | disallow unused placeholders in rule report messages
no-useless-token-range | ✔️ | 🛠 | disallow unnecessary calls to sourceCode.getFirstToken and sourceCode.getLastToken
prefer-object-rule |  | 🛠 | disallow rule exports where the export is a function.
prefer-output-null |  | 🛠 | disallow invalid RuleTester test cases with the output the same as the code.
prefer-placeholders |  |  | disallow template literals as report messages
prefer-replace-text |  |  | require using replaceText instead of replaceTextRange.
report-message-format |  |  | enforce a consistent format for rule report messages
require-meta-docs-description |  |  | require rules to implement a meta.docs.description property with the correct format
require-meta-docs-url |  | 🛠 | require rules to implement a meta.docs.url property
require-meta-fixable | ✔️ |  | require rules to implement a meta.fixable property
require-meta-schema |  | 🛠 | require rules to implement a meta.schema property
require-meta-type |  |  | require rules to implement a meta.type property
test-case-property-ordering |  | 🛠 | require the properties of a test case to be placed in a consistent order
test-case-shorthand-strings |  | 🛠 | enforce consistent usage of shorthand strings for test cases with no options

Supported Presets

Presets are enabled by adding a line to the extends list in your config file. For example, to enable the recommended preset, use:

{
    "extends": [
        "plugin:eslint-plugin/recommended"
    ]
}

  - recommended enables all recommended rules from this plugin.

  - rules-recommended enables all recommended rules that are aimed at linting ESLint rule files.

  - tests-recommended enables all recommended rules that are aimed at linting ESLint test files.

  - all enables all rules in this plugin.

  - rules enables all rules that are aimed at linting ESLint rule files.

  - tests enables all rules that are aimed at linting ESLint test files.

The list of recommended rules will only change in a major release of this plugin. However, new non-recommended rules might be added in a minor release of this plugin. Therefore, the using the all, rules, and tests presets is not recommended for production use, because the addition of new rules in a minor release could break your build.
