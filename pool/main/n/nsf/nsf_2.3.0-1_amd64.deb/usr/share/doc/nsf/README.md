# Next Scripting Framework #

## Compilation of Source Distribution: ##

On Unix-like environments (including macOS), do

````
   ./configure
   make
   sudo make install
`````

For more details, and build instructions, binary releases, community
support etc. consult: [https://next-scripting.org/]
