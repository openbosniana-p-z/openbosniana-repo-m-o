#define NTL_ZZ_NBITS (64)
#define NTL_BITS_PER_LIMB_T (64)
#define NTL_ZZ_FRADIX (((double)(1L<<62))*((double)(1L<<2)))
