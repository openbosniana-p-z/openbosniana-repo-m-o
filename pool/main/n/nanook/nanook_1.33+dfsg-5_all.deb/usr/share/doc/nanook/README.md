![NanoOK](https://documentation.tgac.ac.uk/download/thumbnails/7209095/nanook-01.jpg?version=1&modificationDate=1447675247000&api=v2)

Full documentation can be found at http://nanook.readthedocs.io/

Contact richard.leggett@earlham.ac.uk for more information or for comments/bug reports.
