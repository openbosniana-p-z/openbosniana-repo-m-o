#!/bin/bash

# Read name length test removed: max. name length in BAM is 254, replaced with test_5.sh
#bash test/test_1.sh
test/test_2.sh
test/test_3.sh
test/test_4.sh
test/test_5.sh
test/test_6.sh
