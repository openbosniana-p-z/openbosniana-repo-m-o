// Type definitions for caller 1.0
// Project: https://github.com/totherik/caller
// Definitions by: Ignocide <https://github.com/ignocide>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

declare function caller(depth?: number): string;

export = caller;
