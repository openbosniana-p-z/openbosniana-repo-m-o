# frozen_string_literal: true

module Nanoc::RuleDSL
  class RoutingRuleContext < RuleContext
  end
end
