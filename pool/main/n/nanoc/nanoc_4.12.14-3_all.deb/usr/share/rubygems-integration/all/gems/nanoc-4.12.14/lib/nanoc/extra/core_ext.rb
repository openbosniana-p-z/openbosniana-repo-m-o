# frozen_string_literal: true

require 'nanoc/extra/core_ext/time'
