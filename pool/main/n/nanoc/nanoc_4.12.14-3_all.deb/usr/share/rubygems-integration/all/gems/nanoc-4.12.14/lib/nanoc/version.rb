# frozen_string_literal: true

module Nanoc
  # The current Nanoc version.
  VERSION = '4.12.14'
end
