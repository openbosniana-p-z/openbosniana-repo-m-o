![Nanoc logo](https://avatars1.githubusercontent.com/u/3260163?s=140)

# Nanoc

Nanoc is a flexible static-site generator written in Ruby. See the [Nanoc web site](https://nanoc.ws) for more information.
