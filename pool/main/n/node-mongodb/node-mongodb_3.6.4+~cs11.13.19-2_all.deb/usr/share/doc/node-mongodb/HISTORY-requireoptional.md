1.0.1 03-02-2016
================
* Fix dependency resolution issue when a component in peerOptionalDependencies is installed at the level of the module declaring in peerOptionalDependencies.

1.0.0 03-02-2016
================
* Initial release allowing us to optionally resolve dependencies in the package.json file under the peerOptionalDependencies tag.