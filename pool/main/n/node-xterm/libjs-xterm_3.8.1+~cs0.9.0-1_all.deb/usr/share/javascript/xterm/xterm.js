(function (factory) {
	typeof define === 'function' && define.amd ? define(factory) :
	factory();
}((function () { 'use strict';

	Object.defineProperty(exports, "__esModule", { value: true });
	var Terminal_1 = require("./public/Terminal");
	module.exports = Terminal_1.Terminal;

})));
