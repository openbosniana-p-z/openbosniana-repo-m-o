var marked = require('marked');
var readPkgUp = require('read-pkg-up');
var Path = require('path');

function _interopDefault (e) { return e && e.__esModule ? e : { default: e }; }

var Path__default = /*#__PURE__*/_interopDefault(Path);

function quote(str) {
	return '"' + str + '"';
}

function manEsc(str) {
	return str
		.replace(/\\/gm, "\\\\")
		.replace(/-/gm, "\\-")
		.replace(/^\s*\./gm, "\\|.")
		.replace(/\./gm, "\\.")
		.replace(/^'/gm, "\\|'");
}

function htmlEsc(str) {
	return rentities(manEsc(str))
		.replace(/&gt;/gm, '>')
		.replace(/&lt;/gm, '<')
		.replace(/&amp;/gm, '&');
}

function rentities(str) {
	return str.replace(/&(\w+);/gm, (match, ent) => {
		const gr = {
			bull: '[ci]',
			nbsp: '~',
			copy: '(co',
			rdquo: '(rs',
			mdash: '(em',
			reg: '(rg',
			sect: '(sc',
			ge: '(>=',
			le: '(<=',
			ne: '(!=',
			equiv: '(==',
			plusmn: '(+-'
		}[ent];
		if (gr) return '\\' + gr;
		else return match;
	});
}

function parseHeader(str, options) {
	const {
		groups: {
			name = options.name || "",
			section = options.section || "",
			last = ""
		}
	} = /^(?<name>[\w_.[\]~+=@:-]+)\s*(?:\((?<section>\d\w*)\))?(?:\s*-+\s*(?<last>.*))?$/.exec(str) || { groups: {} };

	let text = last;
	if (!text) {
		if (name || section) text = "";
		else text = str;
	}
	if (name && text) text = " - " + text;

	let out = quote(manEsc(name.toUpperCase()))
		+ " "
		+ quote(section || "1")
		+ " "
		+ quote(manDate(options.date))
		+ (options.manVersion ? " " + quote(options.manVersion) : "")
		+ (options.manual ? " " + quote(options.manual) : ""); // use default value
	if (!options.disableLevel2Name) {
		out = out
			+ "\n.SH "
			+ quote("NAME")
			+ "\n\\fB"
			+ name
			+ "\\fR"
			+ manEsc(text);
	} else {
		delete options.disableLevel2Name;
	}
	return out;
}

function manDate(str) {
	let date;
	if (typeof str == "string") {
		const stamp = parseInt(str);
		if (!Number.isNaN(stamp) && stamp.toString().length == str.length) {
			date = new Date(stamp);
		}
	}
	if (!date) {
		date = new Date(str);
	}
	if (Number.isNaN(date.getTime())) {
		throw new Error("Bad date option: " + str);
	}
	return date.toLocaleString('en', {
		month: 'long', year: 'numeric', timeZone: 'UTC'
	});
}

function code(code, infostring, escaped) {
	this.jumps = true;
	return [
		'.RS 2',
		'.nf',
		manEsc(code),
		'.fi',
		'.RE',
		''
	].join('\n');
}

function blockquote(quote) {
	this.jumps = true;
	return [
		'.TS',
		'tab(|) nowarn;',
		'cx.',
		'T{',
		quote,
		'T}',
		'.TE',
		''
	].join('\n');
}

function html(html) {
	return htmlEsc(html);
}


function heading(text, level, raw, slugger) {
	this.jumps = true;
	let macro;
	if (level == 1) {
		macro = 'TH';
		text = parseHeader(raw || "", this.options);
	} else if (level == 2) {
		macro = 'SH';
	} else {
		macro = 'SS';
	}
	return '.'
		+ macro
		+ ' '
		+ text
		+ '\n';
}

function hr() {
	this.jumps = true;
	return '.HR\n';
}

function list(body) {
	return [
		'\n.RS 1',
		body,
		'.RE',
		''
	].join('\n');
}
function listitem(text) {
	// first ^.P
	return [
		`.IP \\(bu 2`,
		text.trim().replace(/^\.P\s/, '').replace(/\.P /, '.br\n'),
		''
	].join('\n');
}

function checkbox(checked) {

}

function paragraph(text) {
	this.jumps = true;
	const ret = [
		'.P',
		text.trim()
	];
	if (text) ret.push('');
	return ret.join('\n');
}

function table(header, body) {
	this.jumps = false;
	const { tableCols } = this;
	delete this.tableCols;
	return [
		'.TS',
		'tab(|) expand nowarn box;',
		tableCols.join(' ') + '.',
		dropLastRowSep(header.trim()),
		'=',
		dropLastRowSep(body.trim()),
		'.TE',
		''
	].join('\n');
}

function tablerow(content) {
	if (this.tableCols) this.tableCols.done = true;
	return dropLastCellSep(content) + '\n_\n';
}

function tablecell(content, flags) {
	if (!this.tableCols) this.tableCols = [];
	if (!this.tableCols.done) {
		this.tableCols.push(getCellAlign(flags.align));
	}
	return ['T{', content, 'T}|'].join('\n');
}
function dropLastRowSep(str) {
	return str.replace(/\n_$/, '');
}
function dropLastCellSep(str) {
	return str.replace(/\|$/, '');
}
function getCellAlign(align) {
	switch (align) {
		case "right":
			return "r";
		case "center":
			return "c";
		default:
			return "l";
	}
}

function strong(text) {
	this.jumps = false;
	return '\\fB'
		+ text
		+ '\\fR';
}

function em(text) {
	this.jumps = false;
	return '\\fI'
		+ text
		+ '\\fR';
}

function codespan(code) {
	this.jumps = false;
	return '\\fB'
		+ htmlEsc(code)
		+ '\\fP';
}

function br() {
	this.jumps = true;
	return '\n.br\n';
}

function del(text) {
	return "-"
		+ text
		+ "-";
}

function image(href, title, text) {
	if (href == text) {
		return '\\fI'
			+ href
			+ '\\fR';
	} else {
		return '\\fI'
			+ text
			+ '\\fR[' + href + ']';
	}
}

function text(text) {
	if (this.jumps) {
		text = text.trimStart();
		this.jumps = false;
	}
	return htmlEsc(text);
}

var renderer = {
	__proto__: null,
	blockquote: blockquote,
	br: br,
	checkbox: checkbox,
	code: code,
	codespan: codespan,
	del: del,
	em: em,
	heading: heading,
	hr: hr,
	html: html,
	image: image,
	list: list,
	listitem: listitem,
	paragraph: paragraph,
	strong: strong,
	table: table,
	tablecell: tablecell,
	tablerow: tablerow,
	text: text
};

function inlineText(src) {
	const cap = this.rules.inline.text.exec(src);
	if (cap) {
		return {
			type: 'text',
			raw: cap[0],
			text: cap[0]
		};
	}
}

var tokenizer = {
	__proto__: null,
	inlineText: inlineText
};

const empty = {
	name: 'empty',
	level: 'inline',
	renderer() {
		return "";
	}
};

const link = {
	name: 'link',
	level: 'inline',
	tokenizer(src, tokens) {
		if (!tokens.length || /^\p{Po}/u.test(src) == false) return;
		const tok = tokens[tokens.length - 1];
		if (tok.type == "link") {
			tok.punctuation = src.charAt(0);
			return { type: "empty", raw: tok.punctuation };
		}
	},
	renderer({ href, title, text, punctuation }) {
		if (href.startsWith('#')) {
			// a local reference, not a link
			return `\\fI${title || text || href.slice(1)}\\fR`;
		}
		const obj = new URL(href, "file://./");
		const ret = [];
		if (!this.parser.renderer.jumps) ret.push("");

		const content = title || text || '';

		if (content == href || obj.protocol + content == href) return text;

		if (obj.protocol == "mailto:") {
			ret.push(".MT " + href, content ? '.I ' + content : '', ".ME");
		} else {
			ret.push(".UR " + href, content ? '.I ' + content : '', ".UE");
		}
		if (punctuation) ret[ret.length - 1] += " " + punctuation;
		ret.push("");
		this.parser.renderer.jumps = true;
		return ret.join('\n');
	}
};

var extensions = [empty, link];

// https://github.com/markedjs/marked/issues/2639
const defaultParse = marked.Parser.parse;
marked.Parser.parse = (tokens, options) => {
	const [{ type, depth }, sec] = tokens;
	if (type != "heading" || depth != 1) {
		tokens.unshift({
			type: 'heading',
			depth: 1,
			tokens: []
		});
	}
	options.disableLevel2Name = sec && sec.type == "heading" && sec.depth == 2 && sec.text && sec.text.toUpperCase() == "NAME";

	return defaultParse.call(marked.Parser, tokens, options);
};

var index = {
	// marked-man defaults
	date: (() => {
		if (typeof process == "undefined" || !process.env.SOURCE_DATE_EPOCH) {
			return Date.now();
		} else {
			return parseInt(process.env.SOURCE_DATE_EPOCH) * 1000;
		}
	})(),
	mangle: false,
	breaks: true,
	name: null,
	section: null,
	manual: null,
	set manVersion(val) {
		this.userDefinedVersion = val;
	},
	get manVersion() {
		if (this.userDefinedVersion) {
			return this.userDefinedVersion;
		} else if (this.fileArg) {
			const pkg = readPkgUp.sync(Path__default.default.dirname(this.fileArg));
			return pkg ? pkg.packageJson.version : null;
		} else {
			return null;
		}
	},
	// output to roff
	renderer,
	tokenizer,
	// custom fixes
	extensions
};

module.exports = index;
