Package development in progress
===============================

The current AFNI package is work-in-progress. It might undergo significant
changes and package content and functionality between package updates. Do not
rely on this package for productive work (yet).

However, testing, bug reports and suggestions for improvements are most welcome!
Please post them to 409849@bugs.debian.org
