Package development in progress
===============================

The current SPM8 package is work-in-progress. It might undergo significant
changes and package content and functionality between package updates. In
particular, only fMRI-related functionality is supposed to work at this time.
All MEG/EEG tools require the fieldtrip toolbox that will be packaged
separately in the future.

However, testing, bug reports and suggestions for improvements are most welcome!
Please post them to 592390@bugs.debian.org
