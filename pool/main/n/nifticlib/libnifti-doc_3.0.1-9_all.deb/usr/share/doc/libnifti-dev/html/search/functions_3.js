var searchData=
[
  ['is_5fnifti_5ffile_366',['is_nifti_file',['../nifti1__io_8c.html#a247e5a0c2b32a30837187b56d1de553a',1,'is_nifti_file(const char *hname):&#160;nifti1_io.c'],['../nifti1__io_8h.html#a247e5a0c2b32a30837187b56d1de553a',1,'is_nifti_file(const char *hname):&#160;nifti1_io.c']]],
  ['is_5fvalid_5fnifti_5ftype_367',['is_valid_nifti_type',['../nifti1__io_8c.html#a5c42d2b1cf63b30950078ec5562e1f58',1,'is_valid_nifti_type(int nifti_type):&#160;nifti1_io.c'],['../nifti1__io_8h.html#a5c42d2b1cf63b30950078ec5562e1f58',1,'is_valid_nifti_type(int nifti_type):&#160;nifti1_io.c']]]
];
