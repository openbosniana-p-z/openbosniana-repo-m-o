var searchData=
[
  ['znzptr_338',['znzptr',['../structznzptr.html',1,'']]]
];
