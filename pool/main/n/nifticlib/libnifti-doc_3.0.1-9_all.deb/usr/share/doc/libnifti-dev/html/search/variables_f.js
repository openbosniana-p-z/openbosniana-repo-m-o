var searchData=
[
  ['vox_5foffset_548',['vox_offset',['../group__NIFTI1__SLICE__ORDER.html#gaa3a09932cda88dd765a438c9b9c46503',1,'nifti_1_header']]]
];
