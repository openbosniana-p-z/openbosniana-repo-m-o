var searchData=
[
  ['xyz_5funits_549',['xyz_units',['../structnifti__image.html#a5fa377516ee62469a9051a5834f080af',1,'nifti_image']]],
  ['xyzt_5funits_550',['xyzt_units',['../group__NIFTI1__SLICE__ORDER.html#ga6b95dab630916801b716f52513305e93',1,'nifti_1_header']]]
];
