var searchData=
[
  ['phase_5fdim_278',['phase_dim',['../structnifti__image.html#a731f0b9d7b95bc17f9f1a0a568d8ca71',1,'nifti_image']]],
  ['pixdim_279',['pixdim',['../group__NIFTI1__SLICE__ORDER.html#gaf3b966e2936cc174b43fedadbbd933dc',1,'nifti_1_header::pixdim()'],['../structnifti__image.html#a85f39f86ade16e714098a3567116e013',1,'nifti_image::pixdim()']]]
];
