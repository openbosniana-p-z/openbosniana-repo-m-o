var searchData=
[
  ['nifti1_5fdatatype_5faliases_552',['NIFTI1_DATATYPE_ALIASES',['../group__NIFTI1__DATATYPE__ALIASES.html',1,'']]],
  ['nifti1_5fdatatypes_553',['NIFTI1_DATATYPES',['../group__NIFTI1__DATATYPES.html',1,'']]],
  ['nifti1_5fintent_5fcodes_554',['NIFTI1_INTENT_CODES',['../group__NIFTI1__INTENT__CODES.html',1,'']]],
  ['nifti1_5fslice_5forder_555',['NIFTI1_SLICE_ORDER',['../group__NIFTI1__SLICE__ORDER.html',1,'']]],
  ['nifti1_5funits_556',['NIFTI1_UNITS',['../group__NIFTI1__UNITS.html',1,'']]],
  ['nifti1_5fxform_5fcodes_557',['NIFTI1_XFORM_CODES',['../group__NIFTI1__XFORM__CODES.html',1,'']]]
];
