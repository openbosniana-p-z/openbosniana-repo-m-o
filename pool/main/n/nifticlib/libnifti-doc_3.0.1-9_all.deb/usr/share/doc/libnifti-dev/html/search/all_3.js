var searchData=
[
  ['d3matrix_9',['d3matrix',['../group__FSL__TYPE.html#gaa826fd45d3abcff5a4e3ea0061d1cf6e',1,'d3matrix(int zh, int yh, int xh):&#160;fslio.c'],['../group__FSL__TYPE.html#gaa826fd45d3abcff5a4e3ea0061d1cf6e',1,'d3matrix(int zh, int yh, int xh):&#160;fslio.c']]],
  ['d4matrix_10',['d4matrix',['../group__FSL__TYPE.html#ga2291e0ab618a23969124cb17da2aff27',1,'d4matrix(int th, int zh, int yh, int xh):&#160;fslio.c'],['../group__FSL__TYPE.html#ga2291e0ab618a23969124cb17da2aff27',1,'d4matrix(int th, int zh, int yh, int xh):&#160;fslio.c']]],
  ['data_11',['data',['../structnifti__image.html#a946b2c63e6fb9f3c1a1fc8f689efeec6',1,'nifti_image']]],
  ['data_5fhistory_12',['data_history',['../structdata__history.html',1,'']]],
  ['data_5ftype_13',['data_type',['../group__NIFTI1__SLICE__ORDER.html#ga4442d6183e4dce5af7e71365d3eed1ec',1,'nifti_1_header']]],
  ['datatype_14',['datatype',['../structnifti__image.html#a51bad5202c3b9943b3c86f80ca5d1cd1',1,'nifti_image::datatype()'],['../group__NIFTI1__SLICE__ORDER.html#gad5f8888fcc5fde14d3e387653721e270',1,'nifti_1_header::datatype()']]],
  ['db_5fname_15',['db_name',['../group__NIFTI1__SLICE__ORDER.html#ga0e0cf033d74cfae329b4ce0d1b7ece8e',1,'nifti_1_header']]],
  ['debug_16',['debug',['../structnifti__global__options.html#a9bbe15ca56b1065b540b594bd0d818eb',1,'nifti_global_options']]],
  ['descrip_17',['descrip',['../group__NIFTI1__SLICE__ORDER.html#ga8725b5f9e0ef6882200bfeb89b11eb3a',1,'nifti_1_header::descrip()'],['../structnifti__image.html#a6fb59082d2217b817e05418747943b29',1,'nifti_image::descrip()']]],
  ['dim_18',['dim',['../group__NIFTI1__SLICE__ORDER.html#gabd0c6bb6b71a2a6d10fbcb516af52b13',1,'nifti_1_header::dim()'],['../structnifti__image.html#a5eacab1dfe27d1ae618740934516ef61',1,'nifti_image::dim()']]],
  ['dim_5finfo_19',['dim_info',['../group__NIFTI1__SLICE__ORDER.html#ga7d3eb58a5415d9c65f3df444ac94fc74',1,'nifti_1_header']]],
  ['disp_5fnifti_5f1_5fheader_20',['disp_nifti_1_header',['../nifti1__io_8h.html#af9d6192cbeeb85cde0a3c41acf9c2208',1,'disp_nifti_1_header(const char *info, const nifti_1_header *hp):&#160;nifti1_io.c'],['../nifti1__io_8c.html#af9d6192cbeeb85cde0a3c41acf9c2208',1,'disp_nifti_1_header(const char *info, const nifti_1_header *hp):&#160;nifti1_io.c']]],
  ['dsr_21',['dsr',['../structdsr.html',1,'']]],
  ['dt_22',['dt',['../structnifti__image.html#ab4e9dd136d1de9fbe03c68f081876b9e',1,'nifti_image']]],
  ['du_23',['du',['../structnifti__image.html#ab1c6399d45bf77d6eff712d318a9d0ca',1,'nifti_image']]],
  ['dv_24',['dv',['../structnifti__image.html#a6155d97e665d879e662bf650c09d0bc1',1,'nifti_image']]],
  ['dw_25',['dw',['../structnifti__image.html#ab7d8391bc07972e0b051f157dde00a04',1,'nifti_image']]],
  ['dx_26',['dx',['../structnifti__image.html#a8d9ddfeecae70399a50dca551d69f774',1,'nifti_image']]],
  ['dy_27',['dy',['../structnifti__image.html#afb6cd106a28d4599326042c43d85022b',1,'nifti_image']]],
  ['dz_28',['dz',['../structnifti__image.html#ac462fb16a688d8dbec164456febdc9c7',1,'nifti_image']]]
];
