var searchData=
[
  ['data_5fhistory_319',['data_history',['../structdata__history.html',1,'']]],
  ['dsr_320',['dsr',['../structdsr.html',1,'']]]
];
