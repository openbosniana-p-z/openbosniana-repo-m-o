var searchData=
[
  ['allow_5fupper_5ffext_0',['allow_upper_fext',['../structnifti__global__options.html#af0e618e55b18bdf7769ac403128bad02',1,'nifti_global_options']]],
  ['analyze75_5forient_1',['analyze75_orient',['../structnifti__image.html#ae164b68a8420c81d86911bb1c45ae413',1,'nifti_image']]],
  ['aux_5ffile_2',['aux_file',['../group__NIFTI1__SLICE__ORDER.html#ga93e288bd39c44188304677f6bdc96a6b',1,'nifti_1_header::aux_file()'],['../structnifti__image.html#a6366032a4535620d2b0be3240303f50e',1,'nifti_image::aux_file()']]]
];
