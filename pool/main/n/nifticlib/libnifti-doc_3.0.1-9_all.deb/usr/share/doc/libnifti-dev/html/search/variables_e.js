var searchData=
[
  ['time_5funits_546',['time_units',['../structnifti__image.html#a43e8d714fac078daffbe590253776d4c',1,'nifti_image']]],
  ['toffset_547',['toffset',['../group__NIFTI1__SLICE__ORDER.html#ga0d2b669f776a2b7fb84807ea2f7b4231',1,'nifti_1_header::toffset()'],['../structnifti__image.html#ae17bdf0913f6672abdac81c453ecb598',1,'nifti_image::toffset()']]]
];
