var searchData=
[
  ['old_5fswap_5fnifti_5fheader_461',['old_swap_nifti_header',['../nifti1__io_8c.html#a6b59987a39c86d4e247c953570784917',1,'old_swap_nifti_header(struct nifti_1_header *h, int is_nifti):&#160;nifti1_io.c'],['../nifti1__io_8h.html#a6b59987a39c86d4e247c953570784917',1,'old_swap_nifti_header(struct nifti_1_header *h, int is_nifti):&#160;nifti1_io.c']]]
];
