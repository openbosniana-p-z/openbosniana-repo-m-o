var searchData=
[
  ['cal_5fmax_5',['cal_max',['../group__NIFTI1__SLICE__ORDER.html#gaf415db2201f47d61354766245c3f2520',1,'nifti_1_header::cal_max()'],['../structnifti__image.html#a7422e0ecfa446e37bd83fc4fe082135d',1,'nifti_image::cal_max()']]],
  ['cal_5fmin_6',['cal_min',['../group__NIFTI1__SLICE__ORDER.html#ga600fb5b0c533454bbbc61b2e0696c9a8',1,'nifti_1_header::cal_min()'],['../structnifti__image.html#a7d7c74c824d3c8b50a27322366d243f9',1,'nifti_image::cal_min()']]],
  ['complex_7',['COMPLEX',['../structCOMPLEX.html',1,'']]],
  ['convertbuffertoscaleddouble_8',['convertBufferToScaledDouble',['../group__FSL__TYPE.html#gab49bea537966913a5c87768a8a073a40',1,'convertBufferToScaledDouble(double *outbuf, void *inbuf, long len, float slope, float inter, int nifti_datatype):&#160;fslio.c'],['../group__FSL__TYPE.html#gab49bea537966913a5c87768a8a073a40',1,'convertBufferToScaledDouble(double *outbuf, void *inbuf, long len, float slope, float inter, int nifti_datatype):&#160;fslio.c']]]
];
