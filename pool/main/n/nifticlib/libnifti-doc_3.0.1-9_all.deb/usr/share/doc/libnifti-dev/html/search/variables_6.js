var searchData=
[
  ['glmax_494',['glmax',['../group__NIFTI1__SLICE__ORDER.html#ga07e91b15b45a914b71ff41f93fe64e56',1,'nifti_1_header']]],
  ['glmin_495',['glmin',['../group__NIFTI1__SLICE__ORDER.html#gacc037ae9773f9e79333f0927ed3a38ce',1,'nifti_1_header']]]
];
