var searchData=
[
  ['convertbuffertoscaleddouble_345',['convertBufferToScaledDouble',['../group__FSL__TYPE.html#gab49bea537966913a5c87768a8a073a40',1,'convertBufferToScaledDouble(double *outbuf, void *inbuf, long len, float slope, float inter, int nifti_datatype):&#160;fslio.c'],['../group__FSL__TYPE.html#gab49bea537966913a5c87768a8a073a40',1,'convertBufferToScaledDouble(double *outbuf, void *inbuf, long len, float slope, float inter, int nifti_datatype):&#160;fslio.c']]]
];
