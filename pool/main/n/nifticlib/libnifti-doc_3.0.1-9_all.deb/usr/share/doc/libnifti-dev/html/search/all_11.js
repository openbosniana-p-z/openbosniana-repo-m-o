var searchData=
[
  ['valid_5fnifti_5fbrick_5flist_311',['valid_nifti_brick_list',['../nifti1__io_8c.html#a4062dff607da27712e1abbcdedd3c82e',1,'valid_nifti_brick_list(nifti_image *nim, int nbricks, const int *blist, int disp_error):&#160;nifti1_io.c'],['../nifti1__io_8h.html#a4062dff607da27712e1abbcdedd3c82e',1,'valid_nifti_brick_list(nifti_image *nim, int nbricks, const int *blist, int disp_error):&#160;nifti1_io.c']]],
  ['valid_5fnifti_5fextensions_312',['valid_nifti_extensions',['../nifti1__io_8c.html#ae4827bde194fb79b17406da16216f81f',1,'valid_nifti_extensions(const nifti_image *nim):&#160;nifti1_io.c'],['../nifti1__io_8h.html#ae4827bde194fb79b17406da16216f81f',1,'valid_nifti_extensions(const nifti_image *nim):&#160;nifti1_io.c']]],
  ['vox_5foffset_313',['vox_offset',['../group__NIFTI1__SLICE__ORDER.html#gaa3a09932cda88dd765a438c9b9c46503',1,'nifti_1_header']]]
];
