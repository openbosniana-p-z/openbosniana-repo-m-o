var searchData=
[
  ['image_5fdimension_61',['image_dimension',['../structimage__dimension.html',1,'']]],
  ['iname_62',['iname',['../structnifti__image.html#aaace950977a636b704e1a45496ba4e22',1,'nifti_image']]],
  ['iname_5foffset_63',['iname_offset',['../structnifti__image.html#a856fc94a5daed16225264dc8daa96013',1,'nifti_image']]],
  ['int_5flist_64',['int_list',['../structint__list.html',1,'']]],
  ['intent_5fcode_65',['intent_code',['../group__NIFTI1__SLICE__ORDER.html#ga017e9d430b66386e569c6b9cd11059ed',1,'nifti_1_header::intent_code()'],['../structnifti__image.html#a56a5855aaf5323044ffdfde0a23214bc',1,'nifti_image::intent_code()']]],
  ['intent_5fname_66',['intent_name',['../group__NIFTI1__SLICE__ORDER.html#gae3d911b886703c6f0976e308d83a3495',1,'nifti_1_header::intent_name()'],['../structnifti__image.html#ab462f3422c9db863ec134bc90c8107b3',1,'nifti_image::intent_name()']]],
  ['intent_5fp1_67',['intent_p1',['../structnifti__image.html#a1c3ebd9911ac46b659c268a95014b5e8',1,'nifti_image::intent_p1()'],['../group__NIFTI1__SLICE__ORDER.html#ga5c875c40271c15601b3389450fba85b3',1,'nifti_1_header::intent_p1()']]],
  ['intent_5fp2_68',['intent_p2',['../group__NIFTI1__SLICE__ORDER.html#gab39ee04eb345e95dd4e5183e0f84c02b',1,'nifti_1_header::intent_p2()'],['../structnifti__image.html#aacd903b0043fd9378de6927a64bafa85',1,'nifti_image::intent_p2()']]],
  ['intent_5fp3_69',['intent_p3',['../group__NIFTI1__SLICE__ORDER.html#gaa1eeee8a4cd325b413c5d368ec8fc534',1,'nifti_1_header::intent_p3()'],['../structnifti__image.html#a45dd58da99fbf651a96f68dc83e504c5',1,'nifti_image::intent_p3()']]],
  ['is_5fnifti_5ffile_70',['is_nifti_file',['../nifti1__io_8c.html#a247e5a0c2b32a30837187b56d1de553a',1,'is_nifti_file(const char *hname):&#160;nifti1_io.c'],['../nifti1__io_8h.html#a247e5a0c2b32a30837187b56d1de553a',1,'is_nifti_file(const char *hname):&#160;nifti1_io.c']]],
  ['is_5fvalid_5fnifti_5ftype_71',['is_valid_nifti_type',['../nifti1__io_8c.html#a5c42d2b1cf63b30950078ec5562e1f58',1,'is_valid_nifti_type(int nifti_type):&#160;nifti1_io.c'],['../nifti1__io_8h.html#a5c42d2b1cf63b30950078ec5562e1f58',1,'is_valid_nifti_type(int nifti_type):&#160;nifti1_io.c']]]
];
