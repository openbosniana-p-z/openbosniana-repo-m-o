var searchData=
[
  ['d3matrix_346',['d3matrix',['../group__FSL__TYPE.html#gaa826fd45d3abcff5a4e3ea0061d1cf6e',1,'d3matrix(int zh, int yh, int xh):&#160;fslio.c'],['../group__FSL__TYPE.html#gaa826fd45d3abcff5a4e3ea0061d1cf6e',1,'d3matrix(int zh, int yh, int xh):&#160;fslio.c']]],
  ['d4matrix_347',['d4matrix',['../group__FSL__TYPE.html#ga2291e0ab618a23969124cb17da2aff27',1,'d4matrix(int th, int zh, int yh, int xh):&#160;fslio.c'],['../group__FSL__TYPE.html#ga2291e0ab618a23969124cb17da2aff27',1,'d4matrix(int th, int zh, int yh, int xh):&#160;fslio.c']]],
  ['disp_5fnifti_5f1_5fheader_348',['disp_nifti_1_header',['../nifti1__io_8c.html#af9d6192cbeeb85cde0a3c41acf9c2208',1,'disp_nifti_1_header(const char *info, const nifti_1_header *hp):&#160;nifti1_io.c'],['../nifti1__io_8h.html#af9d6192cbeeb85cde0a3c41acf9c2208',1,'disp_nifti_1_header(const char *info, const nifti_1_header *hp):&#160;nifti1_io.c']]]
];
