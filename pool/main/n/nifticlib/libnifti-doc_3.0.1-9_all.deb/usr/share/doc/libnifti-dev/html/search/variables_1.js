var searchData=
[
  ['bitpix_468',['bitpix',['../group__NIFTI1__SLICE__ORDER.html#ga60fc36ed5afd638fd7da425ad7ecae94',1,'nifti_1_header']]],
  ['byteorder_469',['byteorder',['../structnifti__image.html#a5ce21d97da49b1dcf9415e83bbf07caf',1,'nifti_image']]]
];
