var searchData=
[
  ['m_503',['m',['../structmat44.html#a337517366bb0b4a84ebe681468fee374',1,'mat44::m()'],['../structmat33.html#ae750d57add810e18a0ca109daa3a240d',1,'mat33::m()']]],
  ['magic_504',['magic',['../group__NIFTI1__SLICE__ORDER.html#ga5c7eff0d659a6a1f69f576d40cf4d3ed',1,'nifti_1_header']]]
];
