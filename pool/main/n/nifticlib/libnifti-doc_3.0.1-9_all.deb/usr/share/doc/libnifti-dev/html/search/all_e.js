var searchData=
[
  ['regular_289',['regular',['../group__NIFTI1__SLICE__ORDER.html#gacd9cfc4f9d1117a803c4a619132583d7',1,'nifti_1_header']]]
];
