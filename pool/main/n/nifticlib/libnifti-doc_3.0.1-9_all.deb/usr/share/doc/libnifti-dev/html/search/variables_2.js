var searchData=
[
  ['cal_5fmax_470',['cal_max',['../group__NIFTI1__SLICE__ORDER.html#gaf415db2201f47d61354766245c3f2520',1,'nifti_1_header::cal_max()'],['../structnifti__image.html#a7422e0ecfa446e37bd83fc4fe082135d',1,'nifti_image::cal_max()']]],
  ['cal_5fmin_471',['cal_min',['../group__NIFTI1__SLICE__ORDER.html#ga600fb5b0c533454bbbc61b2e0696c9a8',1,'nifti_1_header::cal_min()'],['../structnifti__image.html#a7d7c74c824d3c8b50a27322366d243f9',1,'nifti_image::cal_min()']]]
];
