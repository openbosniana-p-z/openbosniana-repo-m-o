var searchData=
[
  ['data_472',['data',['../structnifti__image.html#a946b2c63e6fb9f3c1a1fc8f689efeec6',1,'nifti_image']]],
  ['data_5ftype_473',['data_type',['../group__NIFTI1__SLICE__ORDER.html#ga4442d6183e4dce5af7e71365d3eed1ec',1,'nifti_1_header']]],
  ['datatype_474',['datatype',['../group__NIFTI1__SLICE__ORDER.html#gad5f8888fcc5fde14d3e387653721e270',1,'nifti_1_header::datatype()'],['../structnifti__image.html#a51bad5202c3b9943b3c86f80ca5d1cd1',1,'nifti_image::datatype()']]],
  ['db_5fname_475',['db_name',['../group__NIFTI1__SLICE__ORDER.html#ga0e0cf033d74cfae329b4ce0d1b7ece8e',1,'nifti_1_header']]],
  ['debug_476',['debug',['../structnifti__global__options.html#a9bbe15ca56b1065b540b594bd0d818eb',1,'nifti_global_options']]],
  ['descrip_477',['descrip',['../group__NIFTI1__SLICE__ORDER.html#ga8725b5f9e0ef6882200bfeb89b11eb3a',1,'nifti_1_header::descrip()'],['../structnifti__image.html#a6fb59082d2217b817e05418747943b29',1,'nifti_image::descrip()']]],
  ['dim_478',['dim',['../structnifti__image.html#a5eacab1dfe27d1ae618740934516ef61',1,'nifti_image::dim()'],['../group__NIFTI1__SLICE__ORDER.html#gabd0c6bb6b71a2a6d10fbcb516af52b13',1,'nifti_1_header::dim()']]],
  ['dim_5finfo_479',['dim_info',['../group__NIFTI1__SLICE__ORDER.html#ga7d3eb58a5415d9c65f3df444ac94fc74',1,'nifti_1_header']]],
  ['dt_480',['dt',['../structnifti__image.html#ab4e9dd136d1de9fbe03c68f081876b9e',1,'nifti_image']]],
  ['du_481',['du',['../structnifti__image.html#ab1c6399d45bf77d6eff712d318a9d0ca',1,'nifti_image']]],
  ['dv_482',['dv',['../structnifti__image.html#a6155d97e665d879e662bf650c09d0bc1',1,'nifti_image']]],
  ['dw_483',['dw',['../structnifti__image.html#ab7d8391bc07972e0b051f157dde00a04',1,'nifti_image']]],
  ['dx_484',['dx',['../structnifti__image.html#a8d9ddfeecae70399a50dca551d69f774',1,'nifti_image']]],
  ['dy_485',['dy',['../structnifti__image.html#afb6cd106a28d4599326042c43d85022b',1,'nifti_image']]],
  ['dz_486',['dz',['../structnifti__image.html#ac462fb16a688d8dbec164456febdc9c7',1,'nifti_image']]]
];
