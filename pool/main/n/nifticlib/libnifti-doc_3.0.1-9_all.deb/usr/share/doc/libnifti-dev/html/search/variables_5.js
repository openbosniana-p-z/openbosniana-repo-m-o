var searchData=
[
  ['fname_492',['fname',['../structnifti__image.html#a439fb70fd16ce03d24ff975e4468c0f8',1,'nifti_image']]],
  ['freq_5fdim_493',['freq_dim',['../structnifti__image.html#a50953906569b58e6b1aaeb7759767b34',1,'nifti_image']]]
];
