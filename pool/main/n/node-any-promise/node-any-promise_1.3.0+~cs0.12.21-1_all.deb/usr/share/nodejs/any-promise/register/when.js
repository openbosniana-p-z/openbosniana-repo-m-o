'use strict';
require('../register')('when', {Promise: require('when').Promise})
