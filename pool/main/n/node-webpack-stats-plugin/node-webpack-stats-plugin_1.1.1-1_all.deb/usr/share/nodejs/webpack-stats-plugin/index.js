"use strict";

const StatsWriterPlugin = require("./lib/stats-writer-plugin");

module.exports = {
  StatsWriterPlugin
};
