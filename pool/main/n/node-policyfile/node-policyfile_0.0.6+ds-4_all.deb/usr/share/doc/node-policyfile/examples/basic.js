var http = require('http')
  , fspfs = require('policyfile');

var flash = fspfs.createServer();
flash.listen();