# @babel/plugin-transform-flow-comments

> Turn flow type annotations into comments

See our website [@babel/plugin-transform-flow-comments](https://babeljs.io/docs/en/babel-plugin-transform-flow-comments) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-flow-comments
```

or using yarn:

```sh
yarn add @babel/plugin-transform-flow-comments --dev
```
