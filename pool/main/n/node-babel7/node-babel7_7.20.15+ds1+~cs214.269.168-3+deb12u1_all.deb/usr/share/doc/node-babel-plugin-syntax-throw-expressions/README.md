# @babel/plugin-syntax-throw-expressions

> Allow parsing of Throw Expressions

See our website [@babel/plugin-syntax-throw-expressions](https://babeljs.io/docs/en/babel-plugin-syntax-throw-expressions) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-throw-expressions
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-throw-expressions --dev
```
