# @babel/plugin-proposal-throw-expressions

> Wraps Throw Expressions in an IIFE

See our website [@babel/plugin-proposal-throw-expressions](https://babeljs.io/docs/en/babel-plugin-proposal-throw-expressions) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-throw-expressions
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-throw-expressions --dev
```
