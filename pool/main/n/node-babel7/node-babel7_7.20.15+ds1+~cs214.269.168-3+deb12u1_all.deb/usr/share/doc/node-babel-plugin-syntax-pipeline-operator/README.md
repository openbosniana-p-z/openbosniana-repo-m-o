# @babel/plugin-syntax-pipeline-operator

> Allow parsing of the pipeline operator

See our website [@babel/plugin-syntax-pipeline-operator](https://babeljs.io/docs/en/babel-plugin-syntax-pipeline-operator) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-pipeline-operator
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-pipeline-operator --dev
```
