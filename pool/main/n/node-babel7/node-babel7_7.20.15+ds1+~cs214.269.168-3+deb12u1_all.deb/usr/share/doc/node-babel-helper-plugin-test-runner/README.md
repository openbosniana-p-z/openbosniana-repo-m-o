# @babel/helper-plugin-test-runner

> Helper function to support test runner

See our website [@babel/helper-plugin-test-runner](https://babeljs.io/docs/en/babel-helper-plugin-test-runner) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-plugin-test-runner
```

or using yarn:

```sh
yarn add @babel/helper-plugin-test-runner
```
