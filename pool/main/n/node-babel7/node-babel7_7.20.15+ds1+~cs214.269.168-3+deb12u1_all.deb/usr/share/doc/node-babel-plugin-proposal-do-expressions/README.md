# @babel/plugin-proposal-do-expressions

> Compile do expressions to ES5

See our website [@babel/plugin-proposal-do-expressions](https://babeljs.io/docs/en/babel-plugin-proposal-do-expressions) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-do-expressions
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-do-expressions --dev
```
