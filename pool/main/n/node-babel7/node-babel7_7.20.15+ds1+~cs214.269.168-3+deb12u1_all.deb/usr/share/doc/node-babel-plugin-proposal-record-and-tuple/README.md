# @babel/plugin-proposal-record-and-tuple

> A transform for Record and Tuple syntax.

See our website [@babel/plugin-proposal-record-and-tuple](https://babeljs.io/docs/en/babel-plugin-proposal-record-and-tuple) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-record-and-tuple
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-record-and-tuple --dev
```
