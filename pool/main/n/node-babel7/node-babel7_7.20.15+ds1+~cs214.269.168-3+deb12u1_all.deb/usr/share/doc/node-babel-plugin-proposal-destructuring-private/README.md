# @babel/plugin-proposal-destructuring-private

> Transform destructuring private proposal

See our website [@babel/plugin-proposal-destructuring-private](https://babeljs.io/docs/en/babel-plugin-proposal-destructuring-private) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-destructuring-private
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-destructuring-private --dev
```
