# @babel/helper-bindify-decorators

> Helper function to bindify decorators

See our website [@babel/helper-bindify-decorators](https://babeljs.io/docs/en/babel-helper-bindify-decorators) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/helper-bindify-decorators
```

or using yarn:

```sh
yarn add @babel/helper-bindify-decorators --dev
```
