# @babel/helper-transform-fixture-test-runner

> Transform test runner for @babel/helper-fixtures module

See our website [@babel/helper-transform-fixture-test-runner](https://babeljs.io/docs/en/babel-helper-transform-fixture-test-runner) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-transform-fixture-test-runner
```

or using yarn:

```sh
yarn add @babel/helper-transform-fixture-test-runner
```
