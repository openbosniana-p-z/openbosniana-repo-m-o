#
# set environment variables for boinc
#

# Script returned ok
true
