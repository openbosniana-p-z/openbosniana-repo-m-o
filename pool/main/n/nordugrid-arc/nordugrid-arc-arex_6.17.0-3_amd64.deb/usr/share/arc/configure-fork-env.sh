#
# set environment fork variables:
#

# Script returned ok
true
