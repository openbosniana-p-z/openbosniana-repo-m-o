"use strict";

module.exports = require("./dist/mirage-cjs.js");
