if (typeof global !== "undefined" && global.__pretenderNodePolyfill) {
  delete global.self
  delete global.__pretenderNodePolyfill
}
