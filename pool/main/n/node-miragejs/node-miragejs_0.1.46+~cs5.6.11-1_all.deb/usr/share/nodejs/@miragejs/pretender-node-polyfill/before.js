if (typeof global !== "undefined" && typeof global.self === 'undefined') {
  global.self = {};
  global.__pretenderNodePolyfill = true;
}
