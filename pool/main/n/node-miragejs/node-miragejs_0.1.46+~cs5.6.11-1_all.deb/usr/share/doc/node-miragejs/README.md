# Mirage JS

[![npm version](https://badge.fury.io/js/miragejs.svg)](https://badge.fury.io/js/miragejs)
![example workflow](https://github.com/miragejs/miragejs/actions/workflows/.github/workflows/ci.yml/badge.svg)

A client-side server to develop, test and prototype your JavaScript app.

## Documentation

Visit [miragejs.com](https://miragejs.com) to read the docs.
