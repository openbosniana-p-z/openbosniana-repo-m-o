utilities
=========

[![Build Status](https://travis-ci.org/mde/utilities.png?branch=master)](https://travis-ci.org/mde/utilities)

A classic collection of JavaScript utilities
