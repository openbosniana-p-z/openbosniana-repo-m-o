"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _chalk = _interopRequireDefault(require("chalk"));
var _isUnicodeSupported = _interopRequireDefault(require("is-unicode-supported"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
const main = {
  info: _chalk.default.blue('ℹ'),
  success: _chalk.default.green('✔'),
  warning: _chalk.default.yellow('⚠'),
  error: _chalk.default.red('✖')
};
const fallback = {
  info: _chalk.default.blue('i'),
  success: _chalk.default.green('√'),
  warning: _chalk.default.yellow('‼'),
  error: _chalk.default.red('×')
};
const logSymbols = (0, _isUnicodeSupported.default)() ? main : fallback;
var _default = logSymbols;
exports.default = _default;
