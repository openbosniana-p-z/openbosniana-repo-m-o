var sockjs = (function () {
	'use strict';

	var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

	function getDefaultExportFromCjs (x) {
		return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
	}

	function getAugmentedNamespace(n) {
	  var f = n.default;
		if (typeof f == "function") {
			var a = function a () {
				if (this instanceof a) {
					var args = [null];
					args.push.apply(args, arguments);
					var Ctor = Function.bind.apply(f, args);
					return new Ctor();
				}
				return f.apply(this, arguments);
			};
			a.prototype = f.prototype;
	  } else a = {};
	  Object.defineProperty(a, '__esModule', {value: true});
		Object.keys(n).forEach(function (k) {
			var d = Object.getOwnPropertyDescriptor(n, k);
			Object.defineProperty(a, k, d.get ? d : {
				enumerable: true,
				get: function () {
					return n[k];
				}
			});
		});
		return a;
	}

	var nodeSockjs0_3_24__0_3_33 = {exports: {}};

	var sockjs = {};

	var domain;

	// This constructor is used to store event handlers. Instantiating this is
	// faster than explicitly calling `Object.create(null)` to get a "clean" empty
	// object (tested with v8 v4.9).
	function EventHandlers() {}
	EventHandlers.prototype = Object.create(null);

	function EventEmitter() {
	  EventEmitter.init.call(this);
	}

	// nodejs oddity
	// require('events') === require('events').EventEmitter
	EventEmitter.EventEmitter = EventEmitter;

	EventEmitter.usingDomains = false;

	EventEmitter.prototype.domain = undefined;
	EventEmitter.prototype._events = undefined;
	EventEmitter.prototype._maxListeners = undefined;

	// By default EventEmitters will print a warning if more than 10 listeners are
	// added to it. This is a useful default which helps finding memory leaks.
	EventEmitter.defaultMaxListeners = 10;

	EventEmitter.init = function() {
	  this.domain = null;
	  if (EventEmitter.usingDomains) {
	    // if there is an active domain, then attach to it.
	    if (domain.active ) ;
	  }

	  if (!this._events || this._events === Object.getPrototypeOf(this)._events) {
	    this._events = new EventHandlers();
	    this._eventsCount = 0;
	  }

	  this._maxListeners = this._maxListeners || undefined;
	};

	// Obviously not all Emitters should be limited to 10. This function allows
	// that to be increased. Set to zero for unlimited.
	EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
	  if (typeof n !== 'number' || n < 0 || isNaN(n))
	    throw new TypeError('"n" argument must be a positive number');
	  this._maxListeners = n;
	  return this;
	};

	function $getMaxListeners(that) {
	  if (that._maxListeners === undefined)
	    return EventEmitter.defaultMaxListeners;
	  return that._maxListeners;
	}

	EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
	  return $getMaxListeners(this);
	};

	// These standalone emit* functions are used to optimize calling of event
	// handlers for fast cases because emit() itself often has a variable number of
	// arguments and can be deoptimized because of that. These functions always have
	// the same number of arguments and thus do not get deoptimized, so the code
	// inside them can execute faster.
	function emitNone(handler, isFn, self) {
	  if (isFn)
	    handler.call(self);
	  else {
	    var len = handler.length;
	    var listeners = arrayClone(handler, len);
	    for (var i = 0; i < len; ++i)
	      listeners[i].call(self);
	  }
	}
	function emitOne(handler, isFn, self, arg1) {
	  if (isFn)
	    handler.call(self, arg1);
	  else {
	    var len = handler.length;
	    var listeners = arrayClone(handler, len);
	    for (var i = 0; i < len; ++i)
	      listeners[i].call(self, arg1);
	  }
	}
	function emitTwo(handler, isFn, self, arg1, arg2) {
	  if (isFn)
	    handler.call(self, arg1, arg2);
	  else {
	    var len = handler.length;
	    var listeners = arrayClone(handler, len);
	    for (var i = 0; i < len; ++i)
	      listeners[i].call(self, arg1, arg2);
	  }
	}
	function emitThree(handler, isFn, self, arg1, arg2, arg3) {
	  if (isFn)
	    handler.call(self, arg1, arg2, arg3);
	  else {
	    var len = handler.length;
	    var listeners = arrayClone(handler, len);
	    for (var i = 0; i < len; ++i)
	      listeners[i].call(self, arg1, arg2, arg3);
	  }
	}

	function emitMany(handler, isFn, self, args) {
	  if (isFn)
	    handler.apply(self, args);
	  else {
	    var len = handler.length;
	    var listeners = arrayClone(handler, len);
	    for (var i = 0; i < len; ++i)
	      listeners[i].apply(self, args);
	  }
	}

	EventEmitter.prototype.emit = function emit(type) {
	  var er, handler, len, args, i, events, domain;
	  var doError = (type === 'error');

	  events = this._events;
	  if (events)
	    doError = (doError && events.error == null);
	  else if (!doError)
	    return false;

	  domain = this.domain;

	  // If there is no 'error' event listener then throw.
	  if (doError) {
	    er = arguments[1];
	    if (domain) {
	      if (!er)
	        er = new Error('Uncaught, unspecified "error" event');
	      er.domainEmitter = this;
	      er.domain = domain;
	      er.domainThrown = false;
	      domain.emit('error', er);
	    } else if (er instanceof Error) {
	      throw er; // Unhandled 'error' event
	    } else {
	      // At least give some kind of context to the user
	      var err = new Error('Uncaught, unspecified "error" event. (' + er + ')');
	      err.context = er;
	      throw err;
	    }
	    return false;
	  }

	  handler = events[type];

	  if (!handler)
	    return false;

	  var isFn = typeof handler === 'function';
	  len = arguments.length;
	  switch (len) {
	    // fast cases
	    case 1:
	      emitNone(handler, isFn, this);
	      break;
	    case 2:
	      emitOne(handler, isFn, this, arguments[1]);
	      break;
	    case 3:
	      emitTwo(handler, isFn, this, arguments[1], arguments[2]);
	      break;
	    case 4:
	      emitThree(handler, isFn, this, arguments[1], arguments[2], arguments[3]);
	      break;
	    // slower
	    default:
	      args = new Array(len - 1);
	      for (i = 1; i < len; i++)
	        args[i - 1] = arguments[i];
	      emitMany(handler, isFn, this, args);
	  }

	  return true;
	};

	function _addListener(target, type, listener, prepend) {
	  var m;
	  var events;
	  var existing;

	  if (typeof listener !== 'function')
	    throw new TypeError('"listener" argument must be a function');

	  events = target._events;
	  if (!events) {
	    events = target._events = new EventHandlers();
	    target._eventsCount = 0;
	  } else {
	    // To avoid recursion in the case that type === "newListener"! Before
	    // adding it to the listeners, first emit "newListener".
	    if (events.newListener) {
	      target.emit('newListener', type,
	                  listener.listener ? listener.listener : listener);

	      // Re-assign `events` because a newListener handler could have caused the
	      // this._events to be assigned to a new object
	      events = target._events;
	    }
	    existing = events[type];
	  }

	  if (!existing) {
	    // Optimize the case of one listener. Don't need the extra array object.
	    existing = events[type] = listener;
	    ++target._eventsCount;
	  } else {
	    if (typeof existing === 'function') {
	      // Adding the second element, need to change to array.
	      existing = events[type] = prepend ? [listener, existing] :
	                                          [existing, listener];
	    } else {
	      // If we've already got an array, just append.
	      if (prepend) {
	        existing.unshift(listener);
	      } else {
	        existing.push(listener);
	      }
	    }

	    // Check for listener leak
	    if (!existing.warned) {
	      m = $getMaxListeners(target);
	      if (m && m > 0 && existing.length > m) {
	        existing.warned = true;
	        var w = new Error('Possible EventEmitter memory leak detected. ' +
	                            existing.length + ' ' + type + ' listeners added. ' +
	                            'Use emitter.setMaxListeners() to increase limit');
	        w.name = 'MaxListenersExceededWarning';
	        w.emitter = target;
	        w.type = type;
	        w.count = existing.length;
	        emitWarning(w);
	      }
	    }
	  }

	  return target;
	}
	function emitWarning(e) {
	  typeof console.warn === 'function' ? console.warn(e) : console.log(e);
	}
	EventEmitter.prototype.addListener = function addListener(type, listener) {
	  return _addListener(this, type, listener, false);
	};

	EventEmitter.prototype.on = EventEmitter.prototype.addListener;

	EventEmitter.prototype.prependListener =
	    function prependListener(type, listener) {
	      return _addListener(this, type, listener, true);
	    };

	function _onceWrap(target, type, listener) {
	  var fired = false;
	  function g() {
	    target.removeListener(type, g);
	    if (!fired) {
	      fired = true;
	      listener.apply(target, arguments);
	    }
	  }
	  g.listener = listener;
	  return g;
	}

	EventEmitter.prototype.once = function once(type, listener) {
	  if (typeof listener !== 'function')
	    throw new TypeError('"listener" argument must be a function');
	  this.on(type, _onceWrap(this, type, listener));
	  return this;
	};

	EventEmitter.prototype.prependOnceListener =
	    function prependOnceListener(type, listener) {
	      if (typeof listener !== 'function')
	        throw new TypeError('"listener" argument must be a function');
	      this.prependListener(type, _onceWrap(this, type, listener));
	      return this;
	    };

	// emits a 'removeListener' event iff the listener was removed
	EventEmitter.prototype.removeListener =
	    function removeListener(type, listener) {
	      var list, events, position, i, originalListener;

	      if (typeof listener !== 'function')
	        throw new TypeError('"listener" argument must be a function');

	      events = this._events;
	      if (!events)
	        return this;

	      list = events[type];
	      if (!list)
	        return this;

	      if (list === listener || (list.listener && list.listener === listener)) {
	        if (--this._eventsCount === 0)
	          this._events = new EventHandlers();
	        else {
	          delete events[type];
	          if (events.removeListener)
	            this.emit('removeListener', type, list.listener || listener);
	        }
	      } else if (typeof list !== 'function') {
	        position = -1;

	        for (i = list.length; i-- > 0;) {
	          if (list[i] === listener ||
	              (list[i].listener && list[i].listener === listener)) {
	            originalListener = list[i].listener;
	            position = i;
	            break;
	          }
	        }

	        if (position < 0)
	          return this;

	        if (list.length === 1) {
	          list[0] = undefined;
	          if (--this._eventsCount === 0) {
	            this._events = new EventHandlers();
	            return this;
	          } else {
	            delete events[type];
	          }
	        } else {
	          spliceOne(list, position);
	        }

	        if (events.removeListener)
	          this.emit('removeListener', type, originalListener || listener);
	      }

	      return this;
	    };

	EventEmitter.prototype.removeAllListeners =
	    function removeAllListeners(type) {
	      var listeners, events;

	      events = this._events;
	      if (!events)
	        return this;

	      // not listening for removeListener, no need to emit
	      if (!events.removeListener) {
	        if (arguments.length === 0) {
	          this._events = new EventHandlers();
	          this._eventsCount = 0;
	        } else if (events[type]) {
	          if (--this._eventsCount === 0)
	            this._events = new EventHandlers();
	          else
	            delete events[type];
	        }
	        return this;
	      }

	      // emit removeListener for all listeners on all events
	      if (arguments.length === 0) {
	        var keys = Object.keys(events);
	        for (var i = 0, key; i < keys.length; ++i) {
	          key = keys[i];
	          if (key === 'removeListener') continue;
	          this.removeAllListeners(key);
	        }
	        this.removeAllListeners('removeListener');
	        this._events = new EventHandlers();
	        this._eventsCount = 0;
	        return this;
	      }

	      listeners = events[type];

	      if (typeof listeners === 'function') {
	        this.removeListener(type, listeners);
	      } else if (listeners) {
	        // LIFO order
	        do {
	          this.removeListener(type, listeners[listeners.length - 1]);
	        } while (listeners[0]);
	      }

	      return this;
	    };

	EventEmitter.prototype.listeners = function listeners(type) {
	  var evlistener;
	  var ret;
	  var events = this._events;

	  if (!events)
	    ret = [];
	  else {
	    evlistener = events[type];
	    if (!evlistener)
	      ret = [];
	    else if (typeof evlistener === 'function')
	      ret = [evlistener.listener || evlistener];
	    else
	      ret = unwrapListeners(evlistener);
	  }

	  return ret;
	};

	EventEmitter.listenerCount = function(emitter, type) {
	  if (typeof emitter.listenerCount === 'function') {
	    return emitter.listenerCount(type);
	  } else {
	    return listenerCount$1.call(emitter, type);
	  }
	};

	EventEmitter.prototype.listenerCount = listenerCount$1;
	function listenerCount$1(type) {
	  var events = this._events;

	  if (events) {
	    var evlistener = events[type];

	    if (typeof evlistener === 'function') {
	      return 1;
	    } else if (evlistener) {
	      return evlistener.length;
	    }
	  }

	  return 0;
	}

	EventEmitter.prototype.eventNames = function eventNames() {
	  return this._eventsCount > 0 ? Reflect.ownKeys(this._events) : [];
	};

	// About 1.5x faster than the two-arg version of Array#splice().
	function spliceOne(list, index) {
	  for (var i = index, k = i + 1, n = list.length; k < n; i += 1, k += 1)
	    list[i] = list[k];
	  list.pop();
	}

	function arrayClone(arr, i) {
	  var copy = new Array(i);
	  while (i--)
	    copy[i] = arr[i];
	  return copy;
	}

	function unwrapListeners(arr) {
	  var ret = new Array(arr.length);
	  for (var i = 0; i < ret.length; ++i) {
	    ret[i] = arr[i].listener || arr[i];
	  }
	  return ret;
	}

	var events = /*#__PURE__*/Object.freeze({
		__proto__: null,
		EventEmitter: EventEmitter,
		default: EventEmitter
	});

	var require$$0$4 = /*@__PURE__*/getAugmentedNamespace(events);

	var empty = {};

	var empty$1 = /*#__PURE__*/Object.freeze({
		__proto__: null,
		default: empty
	});

	var require$$1$2 = /*@__PURE__*/getAugmentedNamespace(empty$1);

	var webjs = {};

	/*! https://mths.be/punycode v1.4.1 by @mathias */


	/** Highest positive signed 32-bit float value */
	var maxInt = 2147483647; // aka. 0x7FFFFFFF or 2^31-1

	/** Bootstring parameters */
	var base$1 = 36;
	var tMin = 1;
	var tMax = 26;
	var skew = 38;
	var damp = 700;
	var initialBias = 72;
	var initialN = 128; // 0x80
	var delimiter = '-'; // '\x2D'
	var regexNonASCII = /[^\x20-\x7E]/; // unprintable ASCII chars + non-ASCII chars
	var regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g; // RFC 3490 separators

	/** Error messages */
	var errors = {
	  'overflow': 'Overflow: input needs wider integers to process',
	  'not-basic': 'Illegal input >= 0x80 (not a basic code point)',
	  'invalid-input': 'Invalid input'
	};

	/** Convenience shortcuts */
	var baseMinusTMin = base$1 - tMin;
	var floor = Math.floor;
	var stringFromCharCode = String.fromCharCode;

	/*--------------------------------------------------------------------------*/

	/**
	 * A generic error utility function.
	 * @private
	 * @param {String} type The error type.
	 * @returns {Error} Throws a `RangeError` with the applicable error message.
	 */
	function error(type) {
	  throw new RangeError(errors[type]);
	}

	/**
	 * A generic `Array#map` utility function.
	 * @private
	 * @param {Array} array The array to iterate over.
	 * @param {Function} callback The function that gets called for every array
	 * item.
	 * @returns {Array} A new array of values returned by the callback function.
	 */
	function map$1(array, fn) {
	  var length = array.length;
	  var result = [];
	  while (length--) {
	    result[length] = fn(array[length]);
	  }
	  return result;
	}

	/**
	 * A simple `Array#map`-like wrapper to work with domain name strings or email
	 * addresses.
	 * @private
	 * @param {String} domain The domain name or email address.
	 * @param {Function} callback The function that gets called for every
	 * character.
	 * @returns {Array} A new string of characters returned by the callback
	 * function.
	 */
	function mapDomain(string, fn) {
	  var parts = string.split('@');
	  var result = '';
	  if (parts.length > 1) {
	    // In email addresses, only the domain name should be punycoded. Leave
	    // the local part (i.e. everything up to `@`) intact.
	    result = parts[0] + '@';
	    string = parts[1];
	  }
	  // Avoid `split(regex)` for IE8 compatibility. See #17.
	  string = string.replace(regexSeparators, '\x2E');
	  var labels = string.split('.');
	  var encoded = map$1(labels, fn).join('.');
	  return result + encoded;
	}

	/**
	 * Creates an array containing the numeric code points of each Unicode
	 * character in the string. While JavaScript uses UCS-2 internally,
	 * this function will convert a pair of surrogate halves (each of which
	 * UCS-2 exposes as separate characters) into a single code point,
	 * matching UTF-16.
	 * @see `punycode.ucs2.encode`
	 * @see <https://mathiasbynens.be/notes/javascript-encoding>
	 * @memberOf punycode.ucs2
	 * @name decode
	 * @param {String} string The Unicode input string (UCS-2).
	 * @returns {Array} The new array of code points.
	 */
	function ucs2decode(string) {
	  var output = [],
	    counter = 0,
	    length = string.length,
	    value,
	    extra;
	  while (counter < length) {
	    value = string.charCodeAt(counter++);
	    if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
	      // high surrogate, and there is a next character
	      extra = string.charCodeAt(counter++);
	      if ((extra & 0xFC00) == 0xDC00) { // low surrogate
	        output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
	      } else {
	        // unmatched surrogate; only append this code unit, in case the next
	        // code unit is the high surrogate of a surrogate pair
	        output.push(value);
	        counter--;
	      }
	    } else {
	      output.push(value);
	    }
	  }
	  return output;
	}

	/**
	 * Converts a digit/integer into a basic code point.
	 * @see `basicToDigit()`
	 * @private
	 * @param {Number} digit The numeric value of a basic code point.
	 * @returns {Number} The basic code point whose value (when used for
	 * representing integers) is `digit`, which needs to be in the range
	 * `0` to `base - 1`. If `flag` is non-zero, the uppercase form is
	 * used; else, the lowercase form is used. The behavior is undefined
	 * if `flag` is non-zero and `digit` has no uppercase form.
	 */
	function digitToBasic(digit, flag) {
	  //  0..25 map to ASCII a..z or A..Z
	  // 26..35 map to ASCII 0..9
	  return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
	}

	/**
	 * Bias adaptation function as per section 3.4 of RFC 3492.
	 * https://tools.ietf.org/html/rfc3492#section-3.4
	 * @private
	 */
	function adapt(delta, numPoints, firstTime) {
	  var k = 0;
	  delta = firstTime ? floor(delta / damp) : delta >> 1;
	  delta += floor(delta / numPoints);
	  for ( /* no initialization */ ; delta > baseMinusTMin * tMax >> 1; k += base$1) {
	    delta = floor(delta / baseMinusTMin);
	  }
	  return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
	}

	/**
	 * Converts a string of Unicode symbols (e.g. a domain name label) to a
	 * Punycode string of ASCII-only symbols.
	 * @memberOf punycode
	 * @param {String} input The string of Unicode symbols.
	 * @returns {String} The resulting Punycode string of ASCII-only symbols.
	 */
	function encode(input) {
	  var n,
	    delta,
	    handledCPCount,
	    basicLength,
	    bias,
	    j,
	    m,
	    q,
	    k,
	    t,
	    currentValue,
	    output = [],
	    /** `inputLength` will hold the number of code points in `input`. */
	    inputLength,
	    /** Cached calculation results */
	    handledCPCountPlusOne,
	    baseMinusT,
	    qMinusT;

	  // Convert the input in UCS-2 to Unicode
	  input = ucs2decode(input);

	  // Cache the length
	  inputLength = input.length;

	  // Initialize the state
	  n = initialN;
	  delta = 0;
	  bias = initialBias;

	  // Handle the basic code points
	  for (j = 0; j < inputLength; ++j) {
	    currentValue = input[j];
	    if (currentValue < 0x80) {
	      output.push(stringFromCharCode(currentValue));
	    }
	  }

	  handledCPCount = basicLength = output.length;

	  // `handledCPCount` is the number of code points that have been handled;
	  // `basicLength` is the number of basic code points.

	  // Finish the basic string - if it is not empty - with a delimiter
	  if (basicLength) {
	    output.push(delimiter);
	  }

	  // Main encoding loop:
	  while (handledCPCount < inputLength) {

	    // All non-basic code points < n have been handled already. Find the next
	    // larger one:
	    for (m = maxInt, j = 0; j < inputLength; ++j) {
	      currentValue = input[j];
	      if (currentValue >= n && currentValue < m) {
	        m = currentValue;
	      }
	    }

	    // Increase `delta` enough to advance the decoder's <n,i> state to <m,0>,
	    // but guard against overflow
	    handledCPCountPlusOne = handledCPCount + 1;
	    if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
	      error('overflow');
	    }

	    delta += (m - n) * handledCPCountPlusOne;
	    n = m;

	    for (j = 0; j < inputLength; ++j) {
	      currentValue = input[j];

	      if (currentValue < n && ++delta > maxInt) {
	        error('overflow');
	      }

	      if (currentValue == n) {
	        // Represent delta as a generalized variable-length integer
	        for (q = delta, k = base$1; /* no condition */ ; k += base$1) {
	          t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);
	          if (q < t) {
	            break;
	          }
	          qMinusT = q - t;
	          baseMinusT = base$1 - t;
	          output.push(
	            stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0))
	          );
	          q = floor(qMinusT / baseMinusT);
	        }

	        output.push(stringFromCharCode(digitToBasic(q, 0)));
	        bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
	        delta = 0;
	        ++handledCPCount;
	      }
	    }

	    ++delta;
	    ++n;

	  }
	  return output.join('');
	}

	/**
	 * Converts a Unicode string representing a domain name or an email address to
	 * Punycode. Only the non-ASCII parts of the domain name will be converted,
	 * i.e. it doesn't matter if you call it with a domain that's already in
	 * ASCII.
	 * @memberOf punycode
	 * @param {String} input The domain name or email address to convert, as a
	 * Unicode string.
	 * @returns {String} The Punycode representation of the given domain name or
	 * email address.
	 */
	function toASCII(input) {
	  return mapDomain(input, function(string) {
	    return regexNonASCII.test(string) ?
	      'xn--' + encode(string) :
	      string;
	  });
	}

	// shim for using process in browser
	// based off https://github.com/defunctzombie/node-process/blob/master/browser.js

	function defaultSetTimout() {
	    throw new Error('setTimeout has not been defined');
	}
	function defaultClearTimeout () {
	    throw new Error('clearTimeout has not been defined');
	}
	var cachedSetTimeout = defaultSetTimout;
	var cachedClearTimeout = defaultClearTimeout;
	if (typeof global.setTimeout === 'function') {
	    cachedSetTimeout = setTimeout;
	}
	if (typeof global.clearTimeout === 'function') {
	    cachedClearTimeout = clearTimeout;
	}

	function runTimeout(fun) {
	    if (cachedSetTimeout === setTimeout) {
	        //normal enviroments in sane situations
	        return setTimeout(fun, 0);
	    }
	    // if setTimeout wasn't available but was latter defined
	    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
	        cachedSetTimeout = setTimeout;
	        return setTimeout(fun, 0);
	    }
	    try {
	        // when when somebody has screwed with setTimeout but no I.E. maddness
	        return cachedSetTimeout(fun, 0);
	    } catch(e){
	        try {
	            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
	            return cachedSetTimeout.call(null, fun, 0);
	        } catch(e){
	            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
	            return cachedSetTimeout.call(this, fun, 0);
	        }
	    }


	}
	function runClearTimeout(marker) {
	    if (cachedClearTimeout === clearTimeout) {
	        //normal enviroments in sane situations
	        return clearTimeout(marker);
	    }
	    // if clearTimeout wasn't available but was latter defined
	    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
	        cachedClearTimeout = clearTimeout;
	        return clearTimeout(marker);
	    }
	    try {
	        // when when somebody has screwed with setTimeout but no I.E. maddness
	        return cachedClearTimeout(marker);
	    } catch (e){
	        try {
	            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
	            return cachedClearTimeout.call(null, marker);
	        } catch (e){
	            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
	            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
	            return cachedClearTimeout.call(this, marker);
	        }
	    }



	}
	var queue = [];
	var draining = false;
	var currentQueue;
	var queueIndex = -1;

	function cleanUpNextTick() {
	    if (!draining || !currentQueue) {
	        return;
	    }
	    draining = false;
	    if (currentQueue.length) {
	        queue = currentQueue.concat(queue);
	    } else {
	        queueIndex = -1;
	    }
	    if (queue.length) {
	        drainQueue();
	    }
	}

	function drainQueue() {
	    if (draining) {
	        return;
	    }
	    var timeout = runTimeout(cleanUpNextTick);
	    draining = true;

	    var len = queue.length;
	    while(len) {
	        currentQueue = queue;
	        queue = [];
	        while (++queueIndex < len) {
	            if (currentQueue) {
	                currentQueue[queueIndex].run();
	            }
	        }
	        queueIndex = -1;
	        len = queue.length;
	    }
	    currentQueue = null;
	    draining = false;
	    runClearTimeout(timeout);
	}
	function nextTick(fun) {
	    var args = new Array(arguments.length - 1);
	    if (arguments.length > 1) {
	        for (var i = 1; i < arguments.length; i++) {
	            args[i - 1] = arguments[i];
	        }
	    }
	    queue.push(new Item(fun, args));
	    if (queue.length === 1 && !draining) {
	        runTimeout(drainQueue);
	    }
	}
	// v8 likes predictible objects
	function Item(fun, array) {
	    this.fun = fun;
	    this.array = array;
	}
	Item.prototype.run = function () {
	    this.fun.apply(null, this.array);
	};
	var title = 'browser';
	var platform = 'browser';
	var browser = true;
	var env = {};
	var argv = [];
	var version$1 = ''; // empty string to avoid regexp issues
	var versions = {};
	var release = {};
	var config = {};

	function noop() {}

	var on = noop;
	var addListener = noop;
	var once = noop;
	var off = noop;
	var removeListener = noop;
	var removeAllListeners = noop;
	var emit = noop;

	function binding(name) {
	    throw new Error('process.binding is not supported');
	}

	function cwd () { return '/' }
	function chdir (dir) {
	    throw new Error('process.chdir is not supported');
	}function umask() { return 0; }

	// from https://github.com/kumavis/browser-process-hrtime/blob/master/index.js
	var performance = global.performance || {};
	var performanceNow =
	  performance.now        ||
	  performance.mozNow     ||
	  performance.msNow      ||
	  performance.oNow       ||
	  performance.webkitNow  ||
	  function(){ return (new Date()).getTime() };

	// generate timestamp or delta
	// see http://nodejs.org/api/process.html#process_process_hrtime
	function hrtime(previousTimestamp){
	  var clocktime = performanceNow.call(performance)*1e-3;
	  var seconds = Math.floor(clocktime);
	  var nanoseconds = Math.floor((clocktime%1)*1e9);
	  if (previousTimestamp) {
	    seconds = seconds - previousTimestamp[0];
	    nanoseconds = nanoseconds - previousTimestamp[1];
	    if (nanoseconds<0) {
	      seconds--;
	      nanoseconds += 1e9;
	    }
	  }
	  return [seconds,nanoseconds]
	}

	var startTime = new Date();
	function uptime() {
	  var currentTime = new Date();
	  var dif = currentTime - startTime;
	  return dif / 1000;
	}

	var browser$1 = {
	  nextTick: nextTick,
	  title: title,
	  browser: browser,
	  env: env,
	  argv: argv,
	  version: version$1,
	  versions: versions,
	  on: on,
	  addListener: addListener,
	  once: once,
	  off: off,
	  removeListener: removeListener,
	  removeAllListeners: removeAllListeners,
	  emit: emit,
	  binding: binding,
	  cwd: cwd,
	  chdir: chdir,
	  umask: umask,
	  hrtime: hrtime,
	  platform: platform,
	  release: release,
	  config: config,
	  uptime: uptime
	};

	var inherits;
	if (typeof Object.create === 'function'){
	  inherits = function inherits(ctor, superCtor) {
	    // implementation from standard node.js 'util' module
	    ctor.super_ = superCtor;
	    ctor.prototype = Object.create(superCtor.prototype, {
	      constructor: {
	        value: ctor,
	        enumerable: false,
	        writable: true,
	        configurable: true
	      }
	    });
	  };
	} else {
	  inherits = function inherits(ctor, superCtor) {
	    ctor.super_ = superCtor;
	    var TempCtor = function () {};
	    TempCtor.prototype = superCtor.prototype;
	    ctor.prototype = new TempCtor();
	    ctor.prototype.constructor = ctor;
	  };
	}
	var inherits$1 = inherits;

	// Copyright Joyent, Inc. and other Node contributors.
	var formatRegExp = /%[sdj%]/g;
	function format$1(f) {
	  if (!isString(f)) {
	    var objects = [];
	    for (var i = 0; i < arguments.length; i++) {
	      objects.push(inspect$1(arguments[i]));
	    }
	    return objects.join(' ');
	  }

	  var i = 1;
	  var args = arguments;
	  var len = args.length;
	  var str = String(f).replace(formatRegExp, function(x) {
	    if (x === '%%') return '%';
	    if (i >= len) return x;
	    switch (x) {
	      case '%s': return String(args[i++]);
	      case '%d': return Number(args[i++]);
	      case '%j':
	        try {
	          return JSON.stringify(args[i++]);
	        } catch (_) {
	          return '[Circular]';
	        }
	      default:
	        return x;
	    }
	  });
	  for (var x = args[i]; i < len; x = args[++i]) {
	    if (isNull(x) || !isObject(x)) {
	      str += ' ' + x;
	    } else {
	      str += ' ' + inspect$1(x);
	    }
	  }
	  return str;
	}

	// Mark that a method should not be used.
	// Returns a modified function which warns once by default.
	// If --no-deprecation is set, then it is a no-op.
	function deprecate(fn, msg) {
	  // Allow for deprecating things in the process of starting up.
	  if (isUndefined(global.process)) {
	    return function() {
	      return deprecate(fn, msg).apply(this, arguments);
	    };
	  }

	  if (browser$1.noDeprecation === true) {
	    return fn;
	  }

	  var warned = false;
	  function deprecated() {
	    if (!warned) {
	      if (browser$1.throwDeprecation) {
	        throw new Error(msg);
	      } else if (browser$1.traceDeprecation) {
	        console.trace(msg);
	      } else {
	        console.error(msg);
	      }
	      warned = true;
	    }
	    return fn.apply(this, arguments);
	  }

	  return deprecated;
	}

	var debugs = {};
	var debugEnviron;
	function debuglog(set) {
	  if (isUndefined(debugEnviron))
	    debugEnviron = browser$1.env.NODE_DEBUG || '';
	  set = set.toUpperCase();
	  if (!debugs[set]) {
	    if (new RegExp('\\b' + set + '\\b', 'i').test(debugEnviron)) {
	      var pid = 0;
	      debugs[set] = function() {
	        var msg = format$1.apply(null, arguments);
	        console.error('%s %d: %s', set, pid, msg);
	      };
	    } else {
	      debugs[set] = function() {};
	    }
	  }
	  return debugs[set];
	}

	/**
	 * Echos the value of a value. Trys to print the value out
	 * in the best way possible given the different types.
	 *
	 * @param {Object} obj The object to print out.
	 * @param {Object} opts Optional options object that alters the output.
	 */
	/* legacy: obj, showHidden, depth, colors*/
	function inspect$1(obj, opts) {
	  // default options
	  var ctx = {
	    seen: [],
	    stylize: stylizeNoColor
	  };
	  // legacy...
	  if (arguments.length >= 3) ctx.depth = arguments[2];
	  if (arguments.length >= 4) ctx.colors = arguments[3];
	  if (isBoolean(opts)) {
	    // legacy...
	    ctx.showHidden = opts;
	  } else if (opts) {
	    // got an "options" object
	    _extend(ctx, opts);
	  }
	  // set default options
	  if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
	  if (isUndefined(ctx.depth)) ctx.depth = 2;
	  if (isUndefined(ctx.colors)) ctx.colors = false;
	  if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
	  if (ctx.colors) ctx.stylize = stylizeWithColor;
	  return formatValue(ctx, obj, ctx.depth);
	}

	// http://en.wikipedia.org/wiki/ANSI_escape_code#graphics
	inspect$1.colors = {
	  'bold' : [1, 22],
	  'italic' : [3, 23],
	  'underline' : [4, 24],
	  'inverse' : [7, 27],
	  'white' : [37, 39],
	  'grey' : [90, 39],
	  'black' : [30, 39],
	  'blue' : [34, 39],
	  'cyan' : [36, 39],
	  'green' : [32, 39],
	  'magenta' : [35, 39],
	  'red' : [31, 39],
	  'yellow' : [33, 39]
	};

	// Don't use 'blue' not visible on cmd.exe
	inspect$1.styles = {
	  'special': 'cyan',
	  'number': 'yellow',
	  'boolean': 'yellow',
	  'undefined': 'grey',
	  'null': 'bold',
	  'string': 'green',
	  'date': 'magenta',
	  // "name": intentionally not styling
	  'regexp': 'red'
	};


	function stylizeWithColor(str, styleType) {
	  var style = inspect$1.styles[styleType];

	  if (style) {
	    return '\u001b[' + inspect$1.colors[style][0] + 'm' + str +
	           '\u001b[' + inspect$1.colors[style][1] + 'm';
	  } else {
	    return str;
	  }
	}


	function stylizeNoColor(str, styleType) {
	  return str;
	}


	function arrayToHash(array) {
	  var hash = {};

	  array.forEach(function(val, idx) {
	    hash[val] = true;
	  });

	  return hash;
	}


	function formatValue(ctx, value, recurseTimes) {
	  // Provide a hook for user-specified inspect functions.
	  // Check that value is an object with an inspect function on it
	  if (ctx.customInspect &&
	      value &&
	      isFunction$1(value.inspect) &&
	      // Filter out the util module, it's inspect function is special
	      value.inspect !== inspect$1 &&
	      // Also filter out any prototype objects using the circular check.
	      !(value.constructor && value.constructor.prototype === value)) {
	    var ret = value.inspect(recurseTimes, ctx);
	    if (!isString(ret)) {
	      ret = formatValue(ctx, ret, recurseTimes);
	    }
	    return ret;
	  }

	  // Primitive types cannot have properties
	  var primitive = formatPrimitive(ctx, value);
	  if (primitive) {
	    return primitive;
	  }

	  // Look up the keys of the object.
	  var keys = Object.keys(value);
	  var visibleKeys = arrayToHash(keys);

	  if (ctx.showHidden) {
	    keys = Object.getOwnPropertyNames(value);
	  }

	  // IE doesn't make error fields non-enumerable
	  // http://msdn.microsoft.com/en-us/library/ie/dww52sbt(v=vs.94).aspx
	  if (isError(value)
	      && (keys.indexOf('message') >= 0 || keys.indexOf('description') >= 0)) {
	    return formatError(value);
	  }

	  // Some type of object without properties can be shortcutted.
	  if (keys.length === 0) {
	    if (isFunction$1(value)) {
	      var name = value.name ? ': ' + value.name : '';
	      return ctx.stylize('[Function' + name + ']', 'special');
	    }
	    if (isRegExp(value)) {
	      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
	    }
	    if (isDate(value)) {
	      return ctx.stylize(Date.prototype.toString.call(value), 'date');
	    }
	    if (isError(value)) {
	      return formatError(value);
	    }
	  }

	  var base = '', array = false, braces = ['{', '}'];

	  // Make Array say that they are Array
	  if (isArray$2(value)) {
	    array = true;
	    braces = ['[', ']'];
	  }

	  // Make functions say that they are functions
	  if (isFunction$1(value)) {
	    var n = value.name ? ': ' + value.name : '';
	    base = ' [Function' + n + ']';
	  }

	  // Make RegExps say that they are RegExps
	  if (isRegExp(value)) {
	    base = ' ' + RegExp.prototype.toString.call(value);
	  }

	  // Make dates with properties first say the date
	  if (isDate(value)) {
	    base = ' ' + Date.prototype.toUTCString.call(value);
	  }

	  // Make error with message first say the error
	  if (isError(value)) {
	    base = ' ' + formatError(value);
	  }

	  if (keys.length === 0 && (!array || value.length == 0)) {
	    return braces[0] + base + braces[1];
	  }

	  if (recurseTimes < 0) {
	    if (isRegExp(value)) {
	      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
	    } else {
	      return ctx.stylize('[Object]', 'special');
	    }
	  }

	  ctx.seen.push(value);

	  var output;
	  if (array) {
	    output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
	  } else {
	    output = keys.map(function(key) {
	      return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
	    });
	  }

	  ctx.seen.pop();

	  return reduceToSingleString(output, base, braces);
	}


	function formatPrimitive(ctx, value) {
	  if (isUndefined(value))
	    return ctx.stylize('undefined', 'undefined');
	  if (isString(value)) {
	    var simple = '\'' + JSON.stringify(value).replace(/^"|"$/g, '')
	                                             .replace(/'/g, "\\'")
	                                             .replace(/\\"/g, '"') + '\'';
	    return ctx.stylize(simple, 'string');
	  }
	  if (isNumber(value))
	    return ctx.stylize('' + value, 'number');
	  if (isBoolean(value))
	    return ctx.stylize('' + value, 'boolean');
	  // For some reason typeof null is "object", so special case here.
	  if (isNull(value))
	    return ctx.stylize('null', 'null');
	}


	function formatError(value) {
	  return '[' + Error.prototype.toString.call(value) + ']';
	}


	function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
	  var output = [];
	  for (var i = 0, l = value.length; i < l; ++i) {
	    if (hasOwnProperty$1(value, String(i))) {
	      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
	          String(i), true));
	    } else {
	      output.push('');
	    }
	  }
	  keys.forEach(function(key) {
	    if (!key.match(/^\d+$/)) {
	      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
	          key, true));
	    }
	  });
	  return output;
	}


	function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
	  var name, str, desc;
	  desc = Object.getOwnPropertyDescriptor(value, key) || { value: value[key] };
	  if (desc.get) {
	    if (desc.set) {
	      str = ctx.stylize('[Getter/Setter]', 'special');
	    } else {
	      str = ctx.stylize('[Getter]', 'special');
	    }
	  } else {
	    if (desc.set) {
	      str = ctx.stylize('[Setter]', 'special');
	    }
	  }
	  if (!hasOwnProperty$1(visibleKeys, key)) {
	    name = '[' + key + ']';
	  }
	  if (!str) {
	    if (ctx.seen.indexOf(desc.value) < 0) {
	      if (isNull(recurseTimes)) {
	        str = formatValue(ctx, desc.value, null);
	      } else {
	        str = formatValue(ctx, desc.value, recurseTimes - 1);
	      }
	      if (str.indexOf('\n') > -1) {
	        if (array) {
	          str = str.split('\n').map(function(line) {
	            return '  ' + line;
	          }).join('\n').substr(2);
	        } else {
	          str = '\n' + str.split('\n').map(function(line) {
	            return '   ' + line;
	          }).join('\n');
	        }
	      }
	    } else {
	      str = ctx.stylize('[Circular]', 'special');
	    }
	  }
	  if (isUndefined(name)) {
	    if (array && key.match(/^\d+$/)) {
	      return str;
	    }
	    name = JSON.stringify('' + key);
	    if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
	      name = name.substr(1, name.length - 2);
	      name = ctx.stylize(name, 'name');
	    } else {
	      name = name.replace(/'/g, "\\'")
	                 .replace(/\\"/g, '"')
	                 .replace(/(^"|"$)/g, "'");
	      name = ctx.stylize(name, 'string');
	    }
	  }

	  return name + ': ' + str;
	}


	function reduceToSingleString(output, base, braces) {
	  var length = output.reduce(function(prev, cur) {
	    if (cur.indexOf('\n') >= 0) ;
	    return prev + cur.replace(/\u001b\[\d\d?m/g, '').length + 1;
	  }, 0);

	  if (length > 60) {
	    return braces[0] +
	           (base === '' ? '' : base + '\n ') +
	           ' ' +
	           output.join(',\n  ') +
	           ' ' +
	           braces[1];
	  }

	  return braces[0] + base + ' ' + output.join(', ') + ' ' + braces[1];
	}


	// NOTE: These type checking functions intentionally don't use `instanceof`
	// because it is fragile and can be easily faked with `Object.create()`.
	function isArray$2(ar) {
	  return Array.isArray(ar);
	}

	function isBoolean(arg) {
	  return typeof arg === 'boolean';
	}

	function isNull(arg) {
	  return arg === null;
	}

	function isNullOrUndefined(arg) {
	  return arg == null;
	}

	function isNumber(arg) {
	  return typeof arg === 'number';
	}

	function isString(arg) {
	  return typeof arg === 'string';
	}

	function isSymbol(arg) {
	  return typeof arg === 'symbol';
	}

	function isUndefined(arg) {
	  return arg === void 0;
	}

	function isRegExp(re) {
	  return isObject(re) && objectToString(re) === '[object RegExp]';
	}

	function isObject(arg) {
	  return typeof arg === 'object' && arg !== null;
	}

	function isDate(d) {
	  return isObject(d) && objectToString(d) === '[object Date]';
	}

	function isError(e) {
	  return isObject(e) &&
	      (objectToString(e) === '[object Error]' || e instanceof Error);
	}

	function isFunction$1(arg) {
	  return typeof arg === 'function';
	}

	function isPrimitive(arg) {
	  return arg === null ||
	         typeof arg === 'boolean' ||
	         typeof arg === 'number' ||
	         typeof arg === 'string' ||
	         typeof arg === 'symbol' ||  // ES6 symbol
	         typeof arg === 'undefined';
	}

	function isBuffer$1(maybeBuf) {
	  return Buffer.isBuffer(maybeBuf);
	}

	function objectToString(o) {
	  return Object.prototype.toString.call(o);
	}


	function pad(n) {
	  return n < 10 ? '0' + n.toString(10) : n.toString(10);
	}


	var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep',
	              'Oct', 'Nov', 'Dec'];

	// 26 Feb 16:19:34
	function timestamp() {
	  var d = new Date();
	  var time = [pad(d.getHours()),
	              pad(d.getMinutes()),
	              pad(d.getSeconds())].join(':');
	  return [d.getDate(), months[d.getMonth()], time].join(' ');
	}


	// log is just a thin wrapper to console.log that prepends a timestamp
	function log() {
	  console.log('%s - %s', timestamp(), format$1.apply(null, arguments));
	}

	function _extend(origin, add) {
	  // Don't do anything if add isn't an object
	  if (!add || !isObject(add)) return origin;

	  var keys = Object.keys(add);
	  var i = keys.length;
	  while (i--) {
	    origin[keys[i]] = add[keys[i]];
	  }
	  return origin;
	}
	function hasOwnProperty$1(obj, prop) {
	  return Object.prototype.hasOwnProperty.call(obj, prop);
	}

	var util = {
	  inherits: inherits$1,
	  _extend: _extend,
	  log: log,
	  isBuffer: isBuffer$1,
	  isPrimitive: isPrimitive,
	  isFunction: isFunction$1,
	  isError: isError,
	  isDate: isDate,
	  isObject: isObject,
	  isRegExp: isRegExp,
	  isUndefined: isUndefined,
	  isSymbol: isSymbol,
	  isString: isString,
	  isNumber: isNumber,
	  isNullOrUndefined: isNullOrUndefined,
	  isNull: isNull,
	  isBoolean: isBoolean,
	  isArray: isArray$2,
	  inspect: inspect$1,
	  deprecate: deprecate,
	  format: format$1,
	  debuglog: debuglog
	};

	var util$1 = /*#__PURE__*/Object.freeze({
		__proto__: null,
		_extend: _extend,
		debuglog: debuglog,
		default: util,
		deprecate: deprecate,
		format: format$1,
		inherits: inherits$1,
		inspect: inspect$1,
		isArray: isArray$2,
		isBoolean: isBoolean,
		isBuffer: isBuffer$1,
		isDate: isDate,
		isError: isError,
		isFunction: isFunction$1,
		isNull: isNull,
		isNullOrUndefined: isNullOrUndefined,
		isNumber: isNumber,
		isObject: isObject,
		isPrimitive: isPrimitive,
		isRegExp: isRegExp,
		isString: isString,
		isSymbol: isSymbol,
		isUndefined: isUndefined,
		log: log
	});

	// Copyright Joyent, Inc. and other Node contributors.
	//
	// Permission is hereby granted, free of charge, to any person obtaining a
	// copy of this software and associated documentation files (the
	// "Software"), to deal in the Software without restriction, including
	// without limitation the rights to use, copy, modify, merge, publish,
	// distribute, sublicense, and/or sell copies of the Software, and to permit
	// persons to whom the Software is furnished to do so, subject to the
	// following conditions:
	//
	// The above copyright notice and this permission notice shall be included
	// in all copies or substantial portions of the Software.
	//
	// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
	// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
	// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
	// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
	// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
	// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
	// USE OR OTHER DEALINGS IN THE SOFTWARE.


	// If obj.hasOwnProperty has been overridden, then calling
	// obj.hasOwnProperty(prop) will break.
	// See: https://github.com/joyent/node/issues/1707
	function hasOwnProperty(obj, prop) {
	  return Object.prototype.hasOwnProperty.call(obj, prop);
	}
	var isArray$1 = Array.isArray || function (xs) {
	  return Object.prototype.toString.call(xs) === '[object Array]';
	};
	function stringifyPrimitive(v) {
	  switch (typeof v) {
	    case 'string':
	      return v;

	    case 'boolean':
	      return v ? 'true' : 'false';

	    case 'number':
	      return isFinite(v) ? v : '';

	    default:
	      return '';
	  }
	}

	function stringify$1 (obj, sep, eq, name) {
	  sep = sep || '&';
	  eq = eq || '=';
	  if (obj === null) {
	    obj = undefined;
	  }

	  if (typeof obj === 'object') {
	    return map(objectKeys$1(obj), function(k) {
	      var ks = encodeURIComponent(stringifyPrimitive(k)) + eq;
	      if (isArray$1(obj[k])) {
	        return map(obj[k], function(v) {
	          return ks + encodeURIComponent(stringifyPrimitive(v));
	        }).join(sep);
	      } else {
	        return ks + encodeURIComponent(stringifyPrimitive(obj[k]));
	      }
	    }).join(sep);

	  }

	  if (!name) return '';
	  return encodeURIComponent(stringifyPrimitive(name)) + eq +
	         encodeURIComponent(stringifyPrimitive(obj));
	}
	function map (xs, f) {
	  if (xs.map) return xs.map(f);
	  var res = [];
	  for (var i = 0; i < xs.length; i++) {
	    res.push(f(xs[i], i));
	  }
	  return res;
	}

	var objectKeys$1 = Object.keys || function (obj) {
	  var res = [];
	  for (var key in obj) {
	    if (Object.prototype.hasOwnProperty.call(obj, key)) res.push(key);
	  }
	  return res;
	};

	function parse$2(qs, sep, eq, options) {
	  sep = sep || '&';
	  eq = eq || '=';
	  var obj = {};

	  if (typeof qs !== 'string' || qs.length === 0) {
	    return obj;
	  }

	  var regexp = /\+/g;
	  qs = qs.split(sep);

	  var maxKeys = 1000;
	  if (options && typeof options.maxKeys === 'number') {
	    maxKeys = options.maxKeys;
	  }

	  var len = qs.length;
	  // maxKeys <= 0 means that we should not limit keys count
	  if (maxKeys > 0 && len > maxKeys) {
	    len = maxKeys;
	  }

	  for (var i = 0; i < len; ++i) {
	    var x = qs[i].replace(regexp, '%20'),
	        idx = x.indexOf(eq),
	        kstr, vstr, k, v;

	    if (idx >= 0) {
	      kstr = x.substr(0, idx);
	      vstr = x.substr(idx + 1);
	    } else {
	      kstr = x;
	      vstr = '';
	    }

	    k = decodeURIComponent(kstr);
	    v = decodeURIComponent(vstr);

	    if (!hasOwnProperty(obj, k)) {
	      obj[k] = v;
	    } else if (isArray$1(obj[k])) {
	      obj[k].push(v);
	    } else {
	      obj[k] = [obj[k], v];
	    }
	  }

	  return obj;
	}var qs = {
	  encode: stringify$1,
	  stringify: stringify$1,
	  decode: parse$2,
	  parse: parse$2
	};

	var qs$1 = /*#__PURE__*/Object.freeze({
		__proto__: null,
		decode: parse$2,
		default: qs,
		encode: stringify$1,
		parse: parse$2,
		stringify: stringify$1
	});

	// Copyright Joyent, Inc. and other Node contributors.
	var url = {
	  parse: urlParse,
	  resolve: urlResolve,
	  resolveObject: urlResolveObject,
	  format: urlFormat,
	  Url: Url
	};
	function Url() {
	  this.protocol = null;
	  this.slashes = null;
	  this.auth = null;
	  this.host = null;
	  this.port = null;
	  this.hostname = null;
	  this.hash = null;
	  this.search = null;
	  this.query = null;
	  this.pathname = null;
	  this.path = null;
	  this.href = null;
	}

	// Reference: RFC 3986, RFC 1808, RFC 2396

	// define these here so at least they only have to be
	// compiled once on the first module load.
	var protocolPattern = /^([a-z0-9.+-]+:)/i,
	  portPattern = /:[0-9]*$/,

	  // Special case for a simple path URL
	  simplePathPattern = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/,

	  // RFC 2396: characters reserved for delimiting URLs.
	  // We actually just auto-escape these.
	  delims = ['<', '>', '"', '`', ' ', '\r', '\n', '\t'],

	  // RFC 2396: characters not allowed for various reasons.
	  unwise = ['{', '}', '|', '\\', '^', '`'].concat(delims),

	  // Allowed by RFCs, but cause of XSS attacks.  Always escape these.
	  autoEscape = ['\''].concat(unwise),
	  // Characters that are never ever allowed in a hostname.
	  // Note that any invalid chars are also handled, but these
	  // are the ones that are *expected* to be seen, so we fast-path
	  // them.
	  nonHostChars = ['%', '/', '?', ';', '#'].concat(autoEscape),
	  hostEndingChars = ['/', '?', '#'],
	  hostnameMaxLen = 255,
	  hostnamePartPattern = /^[+a-z0-9A-Z_-]{0,63}$/,
	  hostnamePartStart = /^([+a-z0-9A-Z_-]{0,63})(.*)$/,
	  // protocols that can allow "unsafe" and "unwise" chars.
	  unsafeProtocol = {
	    'javascript': true,
	    'javascript:': true
	  },
	  // protocols that never have a hostname.
	  hostlessProtocol = {
	    'javascript': true,
	    'javascript:': true
	  },
	  // protocols that always contain a // bit.
	  slashedProtocol = {
	    'http': true,
	    'https': true,
	    'ftp': true,
	    'gopher': true,
	    'file': true,
	    'http:': true,
	    'https:': true,
	    'ftp:': true,
	    'gopher:': true,
	    'file:': true
	  };

	function urlParse(url, parseQueryString, slashesDenoteHost) {
	  if (url && isObject(url) && url instanceof Url) return url;

	  var u = new Url;
	  u.parse(url, parseQueryString, slashesDenoteHost);
	  return u;
	}
	Url.prototype.parse = function(url, parseQueryString, slashesDenoteHost) {
	  return parse$1(this, url, parseQueryString, slashesDenoteHost);
	};

	function parse$1(self, url, parseQueryString, slashesDenoteHost) {
	  if (!isString(url)) {
	    throw new TypeError('Parameter \'url\' must be a string, not ' + typeof url);
	  }

	  // Copy chrome, IE, opera backslash-handling behavior.
	  // Back slashes before the query string get converted to forward slashes
	  // See: https://code.google.com/p/chromium/issues/detail?id=25916
	  var queryIndex = url.indexOf('?'),
	    splitter =
	    (queryIndex !== -1 && queryIndex < url.indexOf('#')) ? '?' : '#',
	    uSplit = url.split(splitter),
	    slashRegex = /\\/g;
	  uSplit[0] = uSplit[0].replace(slashRegex, '/');
	  url = uSplit.join(splitter);

	  var rest = url;

	  // trim before proceeding.
	  // This is to support parse stuff like "  http://foo.com  \n"
	  rest = rest.trim();

	  if (!slashesDenoteHost && url.split('#').length === 1) {
	    // Try fast path regexp
	    var simplePath = simplePathPattern.exec(rest);
	    if (simplePath) {
	      self.path = rest;
	      self.href = rest;
	      self.pathname = simplePath[1];
	      if (simplePath[2]) {
	        self.search = simplePath[2];
	        if (parseQueryString) {
	          self.query = parse$2(self.search.substr(1));
	        } else {
	          self.query = self.search.substr(1);
	        }
	      } else if (parseQueryString) {
	        self.search = '';
	        self.query = {};
	      }
	      return self;
	    }
	  }

	  var proto = protocolPattern.exec(rest);
	  if (proto) {
	    proto = proto[0];
	    var lowerProto = proto.toLowerCase();
	    self.protocol = lowerProto;
	    rest = rest.substr(proto.length);
	  }

	  // figure out if it's got a host
	  // user@server is *always* interpreted as a hostname, and url
	  // resolution will treat //foo/bar as host=foo,path=bar because that's
	  // how the browser resolves relative URLs.
	  if (slashesDenoteHost || proto || rest.match(/^\/\/[^@\/]+@[^@\/]+/)) {
	    var slashes = rest.substr(0, 2) === '//';
	    if (slashes && !(proto && hostlessProtocol[proto])) {
	      rest = rest.substr(2);
	      self.slashes = true;
	    }
	  }
	  var i, hec, l, p;
	  if (!hostlessProtocol[proto] &&
	    (slashes || (proto && !slashedProtocol[proto]))) {

	    // there's a hostname.
	    // the first instance of /, ?, ;, or # ends the host.
	    //
	    // If there is an @ in the hostname, then non-host chars *are* allowed
	    // to the left of the last @ sign, unless some host-ending character
	    // comes *before* the @-sign.
	    // URLs are obnoxious.
	    //
	    // ex:
	    // http://a@b@c/ => user:a@b host:c
	    // http://a@b?@c => user:a host:c path:/?@c

	    // v0.12 TODO(isaacs): This is not quite how Chrome does things.
	    // Review our test case against browsers more comprehensively.

	    // find the first instance of any hostEndingChars
	    var hostEnd = -1;
	    for (i = 0; i < hostEndingChars.length; i++) {
	      hec = rest.indexOf(hostEndingChars[i]);
	      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
	        hostEnd = hec;
	    }

	    // at this point, either we have an explicit point where the
	    // auth portion cannot go past, or the last @ char is the decider.
	    var auth, atSign;
	    if (hostEnd === -1) {
	      // atSign can be anywhere.
	      atSign = rest.lastIndexOf('@');
	    } else {
	      // atSign must be in auth portion.
	      // http://a@b/c@d => host:b auth:a path:/c@d
	      atSign = rest.lastIndexOf('@', hostEnd);
	    }

	    // Now we have a portion which is definitely the auth.
	    // Pull that off.
	    if (atSign !== -1) {
	      auth = rest.slice(0, atSign);
	      rest = rest.slice(atSign + 1);
	      self.auth = decodeURIComponent(auth);
	    }

	    // the host is the remaining to the left of the first non-host char
	    hostEnd = -1;
	    for (i = 0; i < nonHostChars.length; i++) {
	      hec = rest.indexOf(nonHostChars[i]);
	      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
	        hostEnd = hec;
	    }
	    // if we still have not hit it, then the entire thing is a host.
	    if (hostEnd === -1)
	      hostEnd = rest.length;

	    self.host = rest.slice(0, hostEnd);
	    rest = rest.slice(hostEnd);

	    // pull out port.
	    parseHost(self);

	    // we've indicated that there is a hostname,
	    // so even if it's empty, it has to be present.
	    self.hostname = self.hostname || '';

	    // if hostname begins with [ and ends with ]
	    // assume that it's an IPv6 address.
	    var ipv6Hostname = self.hostname[0] === '[' &&
	      self.hostname[self.hostname.length - 1] === ']';

	    // validate a little.
	    if (!ipv6Hostname) {
	      var hostparts = self.hostname.split(/\./);
	      for (i = 0, l = hostparts.length; i < l; i++) {
	        var part = hostparts[i];
	        if (!part) continue;
	        if (!part.match(hostnamePartPattern)) {
	          var newpart = '';
	          for (var j = 0, k = part.length; j < k; j++) {
	            if (part.charCodeAt(j) > 127) {
	              // we replace non-ASCII char with a temporary placeholder
	              // we need this to make sure size of hostname is not
	              // broken by replacing non-ASCII by nothing
	              newpart += 'x';
	            } else {
	              newpart += part[j];
	            }
	          }
	          // we test again with ASCII char only
	          if (!newpart.match(hostnamePartPattern)) {
	            var validParts = hostparts.slice(0, i);
	            var notHost = hostparts.slice(i + 1);
	            var bit = part.match(hostnamePartStart);
	            if (bit) {
	              validParts.push(bit[1]);
	              notHost.unshift(bit[2]);
	            }
	            if (notHost.length) {
	              rest = '/' + notHost.join('.') + rest;
	            }
	            self.hostname = validParts.join('.');
	            break;
	          }
	        }
	      }
	    }

	    if (self.hostname.length > hostnameMaxLen) {
	      self.hostname = '';
	    } else {
	      // hostnames are always lower case.
	      self.hostname = self.hostname.toLowerCase();
	    }

	    if (!ipv6Hostname) {
	      // IDNA Support: Returns a punycoded representation of "domain".
	      // It only converts parts of the domain name that
	      // have non-ASCII characters, i.e. it doesn't matter if
	      // you call it with a domain that already is ASCII-only.
	      self.hostname = toASCII(self.hostname);
	    }

	    p = self.port ? ':' + self.port : '';
	    var h = self.hostname || '';
	    self.host = h + p;
	    self.href += self.host;

	    // strip [ and ] from the hostname
	    // the host field still retains them, though
	    if (ipv6Hostname) {
	      self.hostname = self.hostname.substr(1, self.hostname.length - 2);
	      if (rest[0] !== '/') {
	        rest = '/' + rest;
	      }
	    }
	  }

	  // now rest is set to the post-host stuff.
	  // chop off any delim chars.
	  if (!unsafeProtocol[lowerProto]) {

	    // First, make 100% sure that any "autoEscape" chars get
	    // escaped, even if encodeURIComponent doesn't think they
	    // need to be.
	    for (i = 0, l = autoEscape.length; i < l; i++) {
	      var ae = autoEscape[i];
	      if (rest.indexOf(ae) === -1)
	        continue;
	      var esc = encodeURIComponent(ae);
	      if (esc === ae) {
	        esc = escape(ae);
	      }
	      rest = rest.split(ae).join(esc);
	    }
	  }


	  // chop off from the tail first.
	  var hash = rest.indexOf('#');
	  if (hash !== -1) {
	    // got a fragment string.
	    self.hash = rest.substr(hash);
	    rest = rest.slice(0, hash);
	  }
	  var qm = rest.indexOf('?');
	  if (qm !== -1) {
	    self.search = rest.substr(qm);
	    self.query = rest.substr(qm + 1);
	    if (parseQueryString) {
	      self.query = parse$2(self.query);
	    }
	    rest = rest.slice(0, qm);
	  } else if (parseQueryString) {
	    // no query string, but parseQueryString still requested
	    self.search = '';
	    self.query = {};
	  }
	  if (rest) self.pathname = rest;
	  if (slashedProtocol[lowerProto] &&
	    self.hostname && !self.pathname) {
	    self.pathname = '/';
	  }

	  //to support http.request
	  if (self.pathname || self.search) {
	    p = self.pathname || '';
	    var s = self.search || '';
	    self.path = p + s;
	  }

	  // finally, reconstruct the href based on what has been validated.
	  self.href = format(self);
	  return self;
	}

	// format a parsed object into a url string
	function urlFormat(obj) {
	  // ensure it's an object, and not a string url.
	  // If it's an obj, this is a no-op.
	  // this way, you can call url_format() on strings
	  // to clean up potentially wonky urls.
	  if (isString(obj)) obj = parse$1({}, obj);
	  return format(obj);
	}

	function format(self) {
	  var auth = self.auth || '';
	  if (auth) {
	    auth = encodeURIComponent(auth);
	    auth = auth.replace(/%3A/i, ':');
	    auth += '@';
	  }

	  var protocol = self.protocol || '',
	    pathname = self.pathname || '',
	    hash = self.hash || '',
	    host = false,
	    query = '';

	  if (self.host) {
	    host = auth + self.host;
	  } else if (self.hostname) {
	    host = auth + (self.hostname.indexOf(':') === -1 ?
	      self.hostname :
	      '[' + this.hostname + ']');
	    if (self.port) {
	      host += ':' + self.port;
	    }
	  }

	  if (self.query &&
	    isObject(self.query) &&
	    Object.keys(self.query).length) {
	    query = stringify$1(self.query);
	  }

	  var search = self.search || (query && ('?' + query)) || '';

	  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

	  // only the slashedProtocols get the //.  Not mailto:, xmpp:, etc.
	  // unless they had them to begin with.
	  if (self.slashes ||
	    (!protocol || slashedProtocol[protocol]) && host !== false) {
	    host = '//' + (host || '');
	    if (pathname && pathname.charAt(0) !== '/') pathname = '/' + pathname;
	  } else if (!host) {
	    host = '';
	  }

	  if (hash && hash.charAt(0) !== '#') hash = '#' + hash;
	  if (search && search.charAt(0) !== '?') search = '?' + search;

	  pathname = pathname.replace(/[?#]/g, function(match) {
	    return encodeURIComponent(match);
	  });
	  search = search.replace('#', '%23');

	  return protocol + host + pathname + search + hash;
	}

	Url.prototype.format = function() {
	  return format(this);
	};

	function urlResolve(source, relative) {
	  return urlParse(source, false, true).resolve(relative);
	}

	Url.prototype.resolve = function(relative) {
	  return this.resolveObject(urlParse(relative, false, true)).format();
	};

	function urlResolveObject(source, relative) {
	  if (!source) return relative;
	  return urlParse(source, false, true).resolveObject(relative);
	}

	Url.prototype.resolveObject = function(relative) {
	  if (isString(relative)) {
	    var rel = new Url();
	    rel.parse(relative, false, true);
	    relative = rel;
	  }

	  var result = new Url();
	  var tkeys = Object.keys(this);
	  for (var tk = 0; tk < tkeys.length; tk++) {
	    var tkey = tkeys[tk];
	    result[tkey] = this[tkey];
	  }

	  // hash is always overridden, no matter what.
	  // even href="" will remove it.
	  result.hash = relative.hash;

	  // if the relative url is empty, then there's nothing left to do here.
	  if (relative.href === '') {
	    result.href = result.format();
	    return result;
	  }

	  // hrefs like //foo/bar always cut to the protocol.
	  if (relative.slashes && !relative.protocol) {
	    // take everything except the protocol from relative
	    var rkeys = Object.keys(relative);
	    for (var rk = 0; rk < rkeys.length; rk++) {
	      var rkey = rkeys[rk];
	      if (rkey !== 'protocol')
	        result[rkey] = relative[rkey];
	    }

	    //urlParse appends trailing / to urls like http://www.example.com
	    if (slashedProtocol[result.protocol] &&
	      result.hostname && !result.pathname) {
	      result.path = result.pathname = '/';
	    }

	    result.href = result.format();
	    return result;
	  }
	  var relPath;
	  if (relative.protocol && relative.protocol !== result.protocol) {
	    // if it's a known url protocol, then changing
	    // the protocol does weird things
	    // first, if it's not file:, then we MUST have a host,
	    // and if there was a path
	    // to begin with, then we MUST have a path.
	    // if it is file:, then the host is dropped,
	    // because that's known to be hostless.
	    // anything else is assumed to be absolute.
	    if (!slashedProtocol[relative.protocol]) {
	      var keys = Object.keys(relative);
	      for (var v = 0; v < keys.length; v++) {
	        var k = keys[v];
	        result[k] = relative[k];
	      }
	      result.href = result.format();
	      return result;
	    }

	    result.protocol = relative.protocol;
	    if (!relative.host && !hostlessProtocol[relative.protocol]) {
	      relPath = (relative.pathname || '').split('/');
	      while (relPath.length && !(relative.host = relPath.shift()));
	      if (!relative.host) relative.host = '';
	      if (!relative.hostname) relative.hostname = '';
	      if (relPath[0] !== '') relPath.unshift('');
	      if (relPath.length < 2) relPath.unshift('');
	      result.pathname = relPath.join('/');
	    } else {
	      result.pathname = relative.pathname;
	    }
	    result.search = relative.search;
	    result.query = relative.query;
	    result.host = relative.host || '';
	    result.auth = relative.auth;
	    result.hostname = relative.hostname || relative.host;
	    result.port = relative.port;
	    // to support http.request
	    if (result.pathname || result.search) {
	      var p = result.pathname || '';
	      var s = result.search || '';
	      result.path = p + s;
	    }
	    result.slashes = result.slashes || relative.slashes;
	    result.href = result.format();
	    return result;
	  }

	  var isSourceAbs = (result.pathname && result.pathname.charAt(0) === '/'),
	    isRelAbs = (
	      relative.host ||
	      relative.pathname && relative.pathname.charAt(0) === '/'
	    ),
	    mustEndAbs = (isRelAbs || isSourceAbs ||
	      (result.host && relative.pathname)),
	    removeAllDots = mustEndAbs,
	    srcPath = result.pathname && result.pathname.split('/') || [],
	    psychotic = result.protocol && !slashedProtocol[result.protocol];
	  relPath = relative.pathname && relative.pathname.split('/') || [];
	  // if the url is a non-slashed url, then relative
	  // links like ../.. should be able
	  // to crawl up to the hostname, as well.  This is strange.
	  // result.protocol has already been set by now.
	  // Later on, put the first path part into the host field.
	  if (psychotic) {
	    result.hostname = '';
	    result.port = null;
	    if (result.host) {
	      if (srcPath[0] === '') srcPath[0] = result.host;
	      else srcPath.unshift(result.host);
	    }
	    result.host = '';
	    if (relative.protocol) {
	      relative.hostname = null;
	      relative.port = null;
	      if (relative.host) {
	        if (relPath[0] === '') relPath[0] = relative.host;
	        else relPath.unshift(relative.host);
	      }
	      relative.host = null;
	    }
	    mustEndAbs = mustEndAbs && (relPath[0] === '' || srcPath[0] === '');
	  }
	  var authInHost;
	  if (isRelAbs) {
	    // it's absolute.
	    result.host = (relative.host || relative.host === '') ?
	      relative.host : result.host;
	    result.hostname = (relative.hostname || relative.hostname === '') ?
	      relative.hostname : result.hostname;
	    result.search = relative.search;
	    result.query = relative.query;
	    srcPath = relPath;
	    // fall through to the dot-handling below.
	  } else if (relPath.length) {
	    // it's relative
	    // throw away the existing file, and take the new path instead.
	    if (!srcPath) srcPath = [];
	    srcPath.pop();
	    srcPath = srcPath.concat(relPath);
	    result.search = relative.search;
	    result.query = relative.query;
	  } else if (!isNullOrUndefined(relative.search)) {
	    // just pull out the search.
	    // like href='?foo'.
	    // Put this after the other two cases because it simplifies the booleans
	    if (psychotic) {
	      result.hostname = result.host = srcPath.shift();
	      //occationaly the auth can get stuck only in host
	      //this especially happens in cases like
	      //url.resolveObject('mailto:local1@domain1', 'local2@domain2')
	      authInHost = result.host && result.host.indexOf('@') > 0 ?
	        result.host.split('@') : false;
	      if (authInHost) {
	        result.auth = authInHost.shift();
	        result.host = result.hostname = authInHost.shift();
	      }
	    }
	    result.search = relative.search;
	    result.query = relative.query;
	    //to support http.request
	    if (!isNull(result.pathname) || !isNull(result.search)) {
	      result.path = (result.pathname ? result.pathname : '') +
	        (result.search ? result.search : '');
	    }
	    result.href = result.format();
	    return result;
	  }

	  if (!srcPath.length) {
	    // no path at all.  easy.
	    // we've already handled the other stuff above.
	    result.pathname = null;
	    //to support http.request
	    if (result.search) {
	      result.path = '/' + result.search;
	    } else {
	      result.path = null;
	    }
	    result.href = result.format();
	    return result;
	  }

	  // if a url ENDs in . or .., then it must get a trailing slash.
	  // however, if it ends in anything else non-slashy,
	  // then it must NOT get a trailing slash.
	  var last = srcPath.slice(-1)[0];
	  var hasTrailingSlash = (
	    (result.host || relative.host || srcPath.length > 1) &&
	    (last === '.' || last === '..') || last === '');

	  // strip single dots, resolve double dots to parent dir
	  // if the path tries to go above the root, `up` ends up > 0
	  var up = 0;
	  for (var i = srcPath.length; i >= 0; i--) {
	    last = srcPath[i];
	    if (last === '.') {
	      srcPath.splice(i, 1);
	    } else if (last === '..') {
	      srcPath.splice(i, 1);
	      up++;
	    } else if (up) {
	      srcPath.splice(i, 1);
	      up--;
	    }
	  }

	  // if the path is allowed to go above the root, restore leading ..s
	  if (!mustEndAbs && !removeAllDots) {
	    for (; up--; up) {
	      srcPath.unshift('..');
	    }
	  }

	  if (mustEndAbs && srcPath[0] !== '' &&
	    (!srcPath[0] || srcPath[0].charAt(0) !== '/')) {
	    srcPath.unshift('');
	  }

	  if (hasTrailingSlash && (srcPath.join('/').substr(-1) !== '/')) {
	    srcPath.push('');
	  }

	  var isAbsolute = srcPath[0] === '' ||
	    (srcPath[0] && srcPath[0].charAt(0) === '/');

	  // put the host back
	  if (psychotic) {
	    result.hostname = result.host = isAbsolute ? '' :
	      srcPath.length ? srcPath.shift() : '';
	    //occationaly the auth can get stuck only in host
	    //this especially happens in cases like
	    //url.resolveObject('mailto:local1@domain1', 'local2@domain2')
	    authInHost = result.host && result.host.indexOf('@') > 0 ?
	      result.host.split('@') : false;
	    if (authInHost) {
	      result.auth = authInHost.shift();
	      result.host = result.hostname = authInHost.shift();
	    }
	  }

	  mustEndAbs = mustEndAbs || (result.host && srcPath.length);

	  if (mustEndAbs && !isAbsolute) {
	    srcPath.unshift('');
	  }

	  if (!srcPath.length) {
	    result.pathname = null;
	    result.path = null;
	  } else {
	    result.pathname = srcPath.join('/');
	  }

	  //to support request.http
	  if (!isNull(result.pathname) || !isNull(result.search)) {
	    result.path = (result.pathname ? result.pathname : '') +
	      (result.search ? result.search : '');
	  }
	  result.auth = relative.auth || result.auth;
	  result.slashes = result.slashes || relative.slashes;
	  result.href = result.format();
	  return result;
	};

	Url.prototype.parseHost = function() {
	  return parseHost(this);
	};

	function parseHost(self) {
	  var host = self.host;
	  var port = portPattern.exec(host);
	  if (port) {
	    port = port[0];
	    if (port !== ':') {
	      self.port = port.substr(1);
	    }
	    host = host.substr(0, host.length - port.length);
	  }
	  if (host) self.hostname = host;
	}

	var url$1 = /*#__PURE__*/Object.freeze({
		__proto__: null,
		Url: Url,
		default: url,
		format: urlFormat,
		parse: urlParse,
		resolve: urlResolve,
		resolveObject: urlResolveObject
	});

	var require$$3$1 = /*@__PURE__*/getAugmentedNamespace(url$1);

	var require$$1$1 = /*@__PURE__*/getAugmentedNamespace(qs$1);

	var hasFetch = isFunction(global.fetch) && isFunction(global.ReadableStream);

	var _blobConstructor;
	function blobConstructor() {
	  if (typeof _blobConstructor !== 'undefined') {
	    return _blobConstructor;
	  }
	  try {
	    new global.Blob([new ArrayBuffer(1)]);
	    _blobConstructor = true;
	  } catch (e) {
	    _blobConstructor = false;
	  }
	  return _blobConstructor
	}
	var xhr;

	function checkTypeSupport(type) {
	  if (!xhr) {
	    xhr = new global.XMLHttpRequest();
	    // If location.host is empty, e.g. if this page/worker was loaded
	    // from a Blob, then use example.com to avoid an error
	    xhr.open('GET', global.location.host ? '/' : 'https://example.com');
	  }
	  try {
	    xhr.responseType = type;
	    return xhr.responseType === type
	  } catch (e) {
	    return false
	  }

	}

	// For some strange reason, Safari 7.0 reports typeof global.ArrayBuffer === 'object'.
	// Safari 7.1 appears to have fixed this bug.
	var haveArrayBuffer = typeof global.ArrayBuffer !== 'undefined';
	var haveSlice = haveArrayBuffer && isFunction(global.ArrayBuffer.prototype.slice);

	var arraybuffer = haveArrayBuffer && checkTypeSupport('arraybuffer');
	  // These next two tests unavoidably show warnings in Chrome. Since fetch will always
	  // be used if it's available, just return false for these to avoid the warnings.
	var msstream = !hasFetch && haveSlice && checkTypeSupport('ms-stream');
	var mozchunkedarraybuffer = !hasFetch && haveArrayBuffer &&
	  checkTypeSupport('moz-chunked-arraybuffer');
	var overrideMimeType = isFunction(xhr.overrideMimeType);
	var vbArray = isFunction(global.VBArray);

	function isFunction(value) {
	  return typeof value === 'function'
	}

	xhr = null; // Help gc

	var lookup = [];
	var revLookup = [];
	var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array;
	var inited = false;
	function init () {
	  inited = true;
	  var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
	  for (var i = 0, len = code.length; i < len; ++i) {
	    lookup[i] = code[i];
	    revLookup[code.charCodeAt(i)] = i;
	  }

	  revLookup['-'.charCodeAt(0)] = 62;
	  revLookup['_'.charCodeAt(0)] = 63;
	}

	function toByteArray (b64) {
	  if (!inited) {
	    init();
	  }
	  var i, j, l, tmp, placeHolders, arr;
	  var len = b64.length;

	  if (len % 4 > 0) {
	    throw new Error('Invalid string. Length must be a multiple of 4')
	  }

	  // the number of equal signs (place holders)
	  // if there are two placeholders, than the two characters before it
	  // represent one byte
	  // if there is only one, then the three characters before it represent 2 bytes
	  // this is just a cheap hack to not do indexOf twice
	  placeHolders = b64[len - 2] === '=' ? 2 : b64[len - 1] === '=' ? 1 : 0;

	  // base64 is 4/3 + up to two characters of the original data
	  arr = new Arr(len * 3 / 4 - placeHolders);

	  // if there are placeholders, only get up to the last complete 4 chars
	  l = placeHolders > 0 ? len - 4 : len;

	  var L = 0;

	  for (i = 0, j = 0; i < l; i += 4, j += 3) {
	    tmp = (revLookup[b64.charCodeAt(i)] << 18) | (revLookup[b64.charCodeAt(i + 1)] << 12) | (revLookup[b64.charCodeAt(i + 2)] << 6) | revLookup[b64.charCodeAt(i + 3)];
	    arr[L++] = (tmp >> 16) & 0xFF;
	    arr[L++] = (tmp >> 8) & 0xFF;
	    arr[L++] = tmp & 0xFF;
	  }

	  if (placeHolders === 2) {
	    tmp = (revLookup[b64.charCodeAt(i)] << 2) | (revLookup[b64.charCodeAt(i + 1)] >> 4);
	    arr[L++] = tmp & 0xFF;
	  } else if (placeHolders === 1) {
	    tmp = (revLookup[b64.charCodeAt(i)] << 10) | (revLookup[b64.charCodeAt(i + 1)] << 4) | (revLookup[b64.charCodeAt(i + 2)] >> 2);
	    arr[L++] = (tmp >> 8) & 0xFF;
	    arr[L++] = tmp & 0xFF;
	  }

	  return arr
	}

	function tripletToBase64 (num) {
	  return lookup[num >> 18 & 0x3F] + lookup[num >> 12 & 0x3F] + lookup[num >> 6 & 0x3F] + lookup[num & 0x3F]
	}

	function encodeChunk (uint8, start, end) {
	  var tmp;
	  var output = [];
	  for (var i = start; i < end; i += 3) {
	    tmp = (uint8[i] << 16) + (uint8[i + 1] << 8) + (uint8[i + 2]);
	    output.push(tripletToBase64(tmp));
	  }
	  return output.join('')
	}

	function fromByteArray (uint8) {
	  if (!inited) {
	    init();
	  }
	  var tmp;
	  var len = uint8.length;
	  var extraBytes = len % 3; // if we have 1 byte left, pad 2 bytes
	  var output = '';
	  var parts = [];
	  var maxChunkLength = 16383; // must be multiple of 3

	  // go through the array every three bytes, we'll deal with trailing stuff later
	  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
	    parts.push(encodeChunk(uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)));
	  }

	  // pad the end with zeros, but make sure to not forget the extra bytes
	  if (extraBytes === 1) {
	    tmp = uint8[len - 1];
	    output += lookup[tmp >> 2];
	    output += lookup[(tmp << 4) & 0x3F];
	    output += '==';
	  } else if (extraBytes === 2) {
	    tmp = (uint8[len - 2] << 8) + (uint8[len - 1]);
	    output += lookup[tmp >> 10];
	    output += lookup[(tmp >> 4) & 0x3F];
	    output += lookup[(tmp << 2) & 0x3F];
	    output += '=';
	  }

	  parts.push(output);

	  return parts.join('')
	}

	function read (buffer, offset, isLE, mLen, nBytes) {
	  var e, m;
	  var eLen = nBytes * 8 - mLen - 1;
	  var eMax = (1 << eLen) - 1;
	  var eBias = eMax >> 1;
	  var nBits = -7;
	  var i = isLE ? (nBytes - 1) : 0;
	  var d = isLE ? -1 : 1;
	  var s = buffer[offset + i];

	  i += d;

	  e = s & ((1 << (-nBits)) - 1);
	  s >>= (-nBits);
	  nBits += eLen;
	  for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {}

	  m = e & ((1 << (-nBits)) - 1);
	  e >>= (-nBits);
	  nBits += mLen;
	  for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {}

	  if (e === 0) {
	    e = 1 - eBias;
	  } else if (e === eMax) {
	    return m ? NaN : ((s ? -1 : 1) * Infinity)
	  } else {
	    m = m + Math.pow(2, mLen);
	    e = e - eBias;
	  }
	  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
	}

	function write (buffer, value, offset, isLE, mLen, nBytes) {
	  var e, m, c;
	  var eLen = nBytes * 8 - mLen - 1;
	  var eMax = (1 << eLen) - 1;
	  var eBias = eMax >> 1;
	  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0);
	  var i = isLE ? 0 : (nBytes - 1);
	  var d = isLE ? 1 : -1;
	  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0;

	  value = Math.abs(value);

	  if (isNaN(value) || value === Infinity) {
	    m = isNaN(value) ? 1 : 0;
	    e = eMax;
	  } else {
	    e = Math.floor(Math.log(value) / Math.LN2);
	    if (value * (c = Math.pow(2, -e)) < 1) {
	      e--;
	      c *= 2;
	    }
	    if (e + eBias >= 1) {
	      value += rt / c;
	    } else {
	      value += rt * Math.pow(2, 1 - eBias);
	    }
	    if (value * c >= 2) {
	      e++;
	      c /= 2;
	    }

	    if (e + eBias >= eMax) {
	      m = 0;
	      e = eMax;
	    } else if (e + eBias >= 1) {
	      m = (value * c - 1) * Math.pow(2, mLen);
	      e = e + eBias;
	    } else {
	      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
	      e = 0;
	    }
	  }

	  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

	  e = (e << mLen) | m;
	  eLen += mLen;
	  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

	  buffer[offset + i - d] |= s * 128;
	}

	var toString = {}.toString;

	var isArray = Array.isArray || function (arr) {
	  return toString.call(arr) == '[object Array]';
	};

	/*!
	 * The buffer module from node.js, for the browser.
	 *
	 * @author   Feross Aboukhadijeh <feross@feross.org> <http://feross.org>
	 * @license  MIT
	 */

	var INSPECT_MAX_BYTES = 50;

	/**
	 * If `Buffer.TYPED_ARRAY_SUPPORT`:
	 *   === true    Use Uint8Array implementation (fastest)
	 *   === false   Use Object implementation (most compatible, even IE6)
	 *
	 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
	 * Opera 11.6+, iOS 4.2+.
	 *
	 * Due to various browser bugs, sometimes the Object implementation will be used even
	 * when the browser supports typed arrays.
	 *
	 * Note:
	 *
	 *   - Firefox 4-29 lacks support for adding new properties to `Uint8Array` instances,
	 *     See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438.
	 *
	 *   - Chrome 9-10 is missing the `TypedArray.prototype.subarray` function.
	 *
	 *   - IE10 has a broken `TypedArray.prototype.subarray` function which returns arrays of
	 *     incorrect length in some situations.

	 * We detect these buggy browsers and set `Buffer.TYPED_ARRAY_SUPPORT` to `false` so they
	 * get the Object implementation, which is slower but behaves correctly.
	 */
	Buffer$1.TYPED_ARRAY_SUPPORT = global.TYPED_ARRAY_SUPPORT !== undefined
	  ? global.TYPED_ARRAY_SUPPORT
	  : true;

	/*
	 * Export kMaxLength after typed array support is determined.
	 */
	var _kMaxLength = kMaxLength();

	function kMaxLength () {
	  return Buffer$1.TYPED_ARRAY_SUPPORT
	    ? 0x7fffffff
	    : 0x3fffffff
	}

	function createBuffer (that, length) {
	  if (kMaxLength() < length) {
	    throw new RangeError('Invalid typed array length')
	  }
	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    // Return an augmented `Uint8Array` instance, for best performance
	    that = new Uint8Array(length);
	    Object.setPrototypeOf(that, Buffer$1.prototype);
	  } else {
	    // Fallback: Return an object instance of the Buffer class
	    if (that === null) {
	      that = new Buffer$1(length);
	    }
	    that.length = length;
	  }

	  return that
	}

	/**
	 * The Buffer constructor returns instances of `Uint8Array` that have their
	 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
	 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
	 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
	 * returns a single octet.
	 *
	 * The `Uint8Array` prototype remains unmodified.
	 */

	function Buffer$1 (arg, encodingOrOffset, length) {
	  if (!Buffer$1.TYPED_ARRAY_SUPPORT && !(this instanceof Buffer$1)) {
	    return new Buffer$1(arg, encodingOrOffset, length)
	  }

	  // Common case.
	  if (typeof arg === 'number') {
	    if (typeof encodingOrOffset === 'string') {
	      throw new Error(
	        'If encoding is specified then the first argument must be a string'
	      )
	    }
	    return allocUnsafe(this, arg)
	  }
	  return from(this, arg, encodingOrOffset, length)
	}

	Buffer$1.poolSize = 8192; // not used by this implementation

	// TODO: Legacy, not needed anymore. Remove in next major version.
	Buffer$1._augment = function (arr) {
	  Object.setPrototypeOf(arr, Buffer$1.prototype);
	  return arr
	};

	function from (that, value, encodingOrOffset, length) {
	  if (typeof value === 'number') {
	    throw new TypeError('"value" argument must not be a number')
	  }

	  if (typeof ArrayBuffer !== 'undefined' && value instanceof ArrayBuffer) {
	    return fromArrayBuffer(that, value, encodingOrOffset, length)
	  }

	  if (typeof value === 'string') {
	    return fromString(that, value, encodingOrOffset)
	  }

	  return fromObject(that, value)
	}

	/**
	 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
	 * if value is a number.
	 * Buffer.from(str[, encoding])
	 * Buffer.from(array)
	 * Buffer.from(buffer)
	 * Buffer.from(arrayBuffer[, byteOffset[, length]])
	 **/
	Buffer$1.from = function (value, encodingOrOffset, length) {
	  return from(null, value, encodingOrOffset, length)
	};

	if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	  Object.setPrototypeOf(Buffer$1.prototype, Uint8Array.prototype);
	  Object.setPrototypeOf(Buffer$1, Uint8Array);
	  if (typeof Symbol !== 'undefined' && Symbol.species &&
	      Buffer$1[Symbol.species] === Buffer$1) ;
	}

	function assertSize (size) {
	  if (typeof size !== 'number') {
	    throw new TypeError('"size" argument must be a number')
	  } else if (size < 0) {
	    throw new RangeError('"size" argument must not be negative')
	  }
	}

	function alloc (that, size, fill, encoding) {
	  assertSize(size);
	  if (size <= 0) {
	    return createBuffer(that, size)
	  }
	  if (fill !== undefined) {
	    // Only pay attention to encoding if it's a string. This
	    // prevents accidentally sending in a number that would
	    // be interpretted as a start offset.
	    return typeof encoding === 'string'
	      ? createBuffer(that, size).fill(fill, encoding)
	      : createBuffer(that, size).fill(fill)
	  }
	  return createBuffer(that, size)
	}

	/**
	 * Creates a new filled Buffer instance.
	 * alloc(size[, fill[, encoding]])
	 **/
	Buffer$1.alloc = function (size, fill, encoding) {
	  return alloc(null, size, fill, encoding)
	};

	function allocUnsafe (that, size) {
	  assertSize(size);
	  that = createBuffer(that, size < 0 ? 0 : checked(size) | 0);
	  if (!Buffer$1.TYPED_ARRAY_SUPPORT) {
	    for (var i = 0; i < size; ++i) {
	      that[i] = 0;
	    }
	  }
	  return that
	}

	/**
	 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
	 * */
	Buffer$1.allocUnsafe = function (size) {
	  return allocUnsafe(null, size)
	};
	/**
	 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
	 */
	Buffer$1.allocUnsafeSlow = function (size) {
	  return allocUnsafe(null, size)
	};

	function fromString (that, string, encoding) {
	  if (typeof encoding !== 'string' || encoding === '') {
	    encoding = 'utf8';
	  }

	  if (!Buffer$1.isEncoding(encoding)) {
	    throw new TypeError('"encoding" must be a valid string encoding')
	  }

	  var length = byteLength(string, encoding) | 0;
	  that = createBuffer(that, length);

	  var actual = that.write(string, encoding);

	  if (actual !== length) {
	    // Writing a hex string, for example, that contains invalid characters will
	    // cause everything after the first invalid character to be ignored. (e.g.
	    // 'abxxcd' will be treated as 'ab')
	    that = that.slice(0, actual);
	  }

	  return that
	}

	function fromArrayLike (that, array) {
	  var length = array.length < 0 ? 0 : checked(array.length) | 0;
	  that = createBuffer(that, length);
	  for (var i = 0; i < length; i += 1) {
	    that[i] = array[i] & 255;
	  }
	  return that
	}

	function fromArrayBuffer (that, array, byteOffset, length) {
	  array.byteLength; // this throws if `array` is not a valid ArrayBuffer

	  if (byteOffset < 0 || array.byteLength < byteOffset) {
	    throw new RangeError('\'offset\' is out of bounds')
	  }

	  if (array.byteLength < byteOffset + (length || 0)) {
	    throw new RangeError('\'length\' is out of bounds')
	  }

	  if (byteOffset === undefined && length === undefined) {
	    array = new Uint8Array(array);
	  } else if (length === undefined) {
	    array = new Uint8Array(array, byteOffset);
	  } else {
	    array = new Uint8Array(array, byteOffset, length);
	  }

	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    // Return an augmented `Uint8Array` instance, for best performance
	    that = array;
	    Object.setPrototypeOf(that, Buffer$1.prototype);
	  } else {
	    // Fallback: Return an object instance of the Buffer class
	    that = fromArrayLike(that, array);
	  }
	  return that
	}

	function fromObject (that, obj) {
	  if (internalIsBuffer(obj)) {
	    var len = checked(obj.length) | 0;
	    that = createBuffer(that, len);

	    if (that.length === 0) {
	      return that
	    }

	    obj.copy(that, 0, 0, len);
	    return that
	  }

	  if (obj) {
	    if ((typeof ArrayBuffer !== 'undefined' &&
	        obj.buffer instanceof ArrayBuffer) || 'length' in obj) {
	      if (typeof obj.length !== 'number' || isnan(obj.length)) {
	        return createBuffer(that, 0)
	      }
	      return fromArrayLike(that, obj)
	    }

	    if (obj.type === 'Buffer' && isArray(obj.data)) {
	      return fromArrayLike(that, obj.data)
	    }
	  }

	  throw new TypeError('First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.')
	}

	function checked (length) {
	  // Note: cannot use `length < kMaxLength()` here because that fails when
	  // length is NaN (which is otherwise coerced to zero.)
	  if (length >= kMaxLength()) {
	    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
	                         'size: 0x' + kMaxLength().toString(16) + ' bytes')
	  }
	  return length | 0
	}

	function SlowBuffer (length) {
	  if (+length != length) { // eslint-disable-line eqeqeq
	    length = 0;
	  }
	  return Buffer$1.alloc(+length)
	}
	Buffer$1.isBuffer = isBuffer;
	function internalIsBuffer (b) {
	  return !!(b != null && b._isBuffer)
	}

	Buffer$1.compare = function compare (a, b) {
	  if (!internalIsBuffer(a) || !internalIsBuffer(b)) {
	    throw new TypeError('Arguments must be Buffers')
	  }

	  if (a === b) return 0

	  var x = a.length;
	  var y = b.length;

	  for (var i = 0, len = Math.min(x, y); i < len; ++i) {
	    if (a[i] !== b[i]) {
	      x = a[i];
	      y = b[i];
	      break
	    }
	  }

	  if (x < y) return -1
	  if (y < x) return 1
	  return 0
	};

	Buffer$1.isEncoding = function isEncoding (encoding) {
	  switch (String(encoding).toLowerCase()) {
	    case 'hex':
	    case 'utf8':
	    case 'utf-8':
	    case 'ascii':
	    case 'latin1':
	    case 'binary':
	    case 'base64':
	    case 'ucs2':
	    case 'ucs-2':
	    case 'utf16le':
	    case 'utf-16le':
	      return true
	    default:
	      return false
	  }
	};

	Buffer$1.concat = function concat (list, length) {
	  if (!isArray(list)) {
	    throw new TypeError('"list" argument must be an Array of Buffers')
	  }

	  if (list.length === 0) {
	    return Buffer$1.alloc(0)
	  }

	  var i;
	  if (length === undefined) {
	    length = 0;
	    for (i = 0; i < list.length; ++i) {
	      length += list[i].length;
	    }
	  }

	  var buffer = Buffer$1.allocUnsafe(length);
	  var pos = 0;
	  for (i = 0; i < list.length; ++i) {
	    var buf = list[i];
	    if (!internalIsBuffer(buf)) {
	      throw new TypeError('"list" argument must be an Array of Buffers')
	    }
	    buf.copy(buffer, pos);
	    pos += buf.length;
	  }
	  return buffer
	};

	function byteLength (string, encoding) {
	  if (internalIsBuffer(string)) {
	    return string.length
	  }
	  if (typeof ArrayBuffer !== 'undefined' && typeof ArrayBuffer.isView === 'function' &&
	      (ArrayBuffer.isView(string) || string instanceof ArrayBuffer)) {
	    return string.byteLength
	  }
	  if (typeof string !== 'string') {
	    string = '' + string;
	  }

	  var len = string.length;
	  if (len === 0) return 0

	  // Use a for loop to avoid recursion
	  var loweredCase = false;
	  for (;;) {
	    switch (encoding) {
	      case 'ascii':
	      case 'latin1':
	      case 'binary':
	        return len
	      case 'utf8':
	      case 'utf-8':
	      case undefined:
	        return utf8ToBytes(string).length
	      case 'ucs2':
	      case 'ucs-2':
	      case 'utf16le':
	      case 'utf-16le':
	        return len * 2
	      case 'hex':
	        return len >>> 1
	      case 'base64':
	        return base64ToBytes(string).length
	      default:
	        if (loweredCase) return utf8ToBytes(string).length // assume utf8
	        encoding = ('' + encoding).toLowerCase();
	        loweredCase = true;
	    }
	  }
	}
	Buffer$1.byteLength = byteLength;

	function slowToString (encoding, start, end) {
	  var loweredCase = false;

	  // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
	  // property of a typed array.

	  // This behaves neither like String nor Uint8Array in that we set start/end
	  // to their upper/lower bounds if the value passed is out of range.
	  // undefined is handled specially as per ECMA-262 6th Edition,
	  // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
	  if (start === undefined || start < 0) {
	    start = 0;
	  }
	  // Return early if start > this.length. Done here to prevent potential uint32
	  // coercion fail below.
	  if (start > this.length) {
	    return ''
	  }

	  if (end === undefined || end > this.length) {
	    end = this.length;
	  }

	  if (end <= 0) {
	    return ''
	  }

	  // Force coersion to uint32. This will also coerce falsey/NaN values to 0.
	  end >>>= 0;
	  start >>>= 0;

	  if (end <= start) {
	    return ''
	  }

	  if (!encoding) encoding = 'utf8';

	  while (true) {
	    switch (encoding) {
	      case 'hex':
	        return hexSlice(this, start, end)

	      case 'utf8':
	      case 'utf-8':
	        return utf8Slice(this, start, end)

	      case 'ascii':
	        return asciiSlice(this, start, end)

	      case 'latin1':
	      case 'binary':
	        return latin1Slice(this, start, end)

	      case 'base64':
	        return base64Slice(this, start, end)

	      case 'ucs2':
	      case 'ucs-2':
	      case 'utf16le':
	      case 'utf-16le':
	        return utf16leSlice(this, start, end)

	      default:
	        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
	        encoding = (encoding + '').toLowerCase();
	        loweredCase = true;
	    }
	  }
	}

	// The property is used by `Buffer.isBuffer` and `is-buffer` (in Safari 5-7) to detect
	// Buffer instances.
	Buffer$1.prototype._isBuffer = true;

	function swap (b, n, m) {
	  var i = b[n];
	  b[n] = b[m];
	  b[m] = i;
	}

	Buffer$1.prototype.swap16 = function swap16 () {
	  var len = this.length;
	  if (len % 2 !== 0) {
	    throw new RangeError('Buffer size must be a multiple of 16-bits')
	  }
	  for (var i = 0; i < len; i += 2) {
	    swap(this, i, i + 1);
	  }
	  return this
	};

	Buffer$1.prototype.swap32 = function swap32 () {
	  var len = this.length;
	  if (len % 4 !== 0) {
	    throw new RangeError('Buffer size must be a multiple of 32-bits')
	  }
	  for (var i = 0; i < len; i += 4) {
	    swap(this, i, i + 3);
	    swap(this, i + 1, i + 2);
	  }
	  return this
	};

	Buffer$1.prototype.swap64 = function swap64 () {
	  var len = this.length;
	  if (len % 8 !== 0) {
	    throw new RangeError('Buffer size must be a multiple of 64-bits')
	  }
	  for (var i = 0; i < len; i += 8) {
	    swap(this, i, i + 7);
	    swap(this, i + 1, i + 6);
	    swap(this, i + 2, i + 5);
	    swap(this, i + 3, i + 4);
	  }
	  return this
	};

	Buffer$1.prototype.toString = function toString () {
	  var length = this.length | 0;
	  if (length === 0) return ''
	  if (arguments.length === 0) return utf8Slice(this, 0, length)
	  return slowToString.apply(this, arguments)
	};

	Buffer$1.prototype.equals = function equals (b) {
	  if (!internalIsBuffer(b)) throw new TypeError('Argument must be a Buffer')
	  if (this === b) return true
	  return Buffer$1.compare(this, b) === 0
	};

	Buffer$1.prototype.inspect = function inspect () {
	  var str = '';
	  var max = INSPECT_MAX_BYTES;
	  if (this.length > 0) {
	    str = this.toString('hex', 0, max).match(/.{2}/g).join(' ');
	    if (this.length > max) str += ' ... ';
	  }
	  return '<Buffer ' + str + '>'
	};

	Buffer$1.prototype.compare = function compare (target, start, end, thisStart, thisEnd) {
	  if (!internalIsBuffer(target)) {
	    throw new TypeError('Argument must be a Buffer')
	  }

	  if (start === undefined) {
	    start = 0;
	  }
	  if (end === undefined) {
	    end = target ? target.length : 0;
	  }
	  if (thisStart === undefined) {
	    thisStart = 0;
	  }
	  if (thisEnd === undefined) {
	    thisEnd = this.length;
	  }

	  if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
	    throw new RangeError('out of range index')
	  }

	  if (thisStart >= thisEnd && start >= end) {
	    return 0
	  }
	  if (thisStart >= thisEnd) {
	    return -1
	  }
	  if (start >= end) {
	    return 1
	  }

	  start >>>= 0;
	  end >>>= 0;
	  thisStart >>>= 0;
	  thisEnd >>>= 0;

	  if (this === target) return 0

	  var x = thisEnd - thisStart;
	  var y = end - start;
	  var len = Math.min(x, y);

	  var thisCopy = this.slice(thisStart, thisEnd);
	  var targetCopy = target.slice(start, end);

	  for (var i = 0; i < len; ++i) {
	    if (thisCopy[i] !== targetCopy[i]) {
	      x = thisCopy[i];
	      y = targetCopy[i];
	      break
	    }
	  }

	  if (x < y) return -1
	  if (y < x) return 1
	  return 0
	};

	// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
	// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
	//
	// Arguments:
	// - buffer - a Buffer to search
	// - val - a string, Buffer, or number
	// - byteOffset - an index into `buffer`; will be clamped to an int32
	// - encoding - an optional encoding, relevant is val is a string
	// - dir - true for indexOf, false for lastIndexOf
	function bidirectionalIndexOf (buffer, val, byteOffset, encoding, dir) {
	  // Empty buffer means no match
	  if (buffer.length === 0) return -1

	  // Normalize byteOffset
	  if (typeof byteOffset === 'string') {
	    encoding = byteOffset;
	    byteOffset = 0;
	  } else if (byteOffset > 0x7fffffff) {
	    byteOffset = 0x7fffffff;
	  } else if (byteOffset < -0x80000000) {
	    byteOffset = -0x80000000;
	  }
	  byteOffset = +byteOffset;  // Coerce to Number.
	  if (isNaN(byteOffset)) {
	    // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
	    byteOffset = dir ? 0 : (buffer.length - 1);
	  }

	  // Normalize byteOffset: negative offsets start from the end of the buffer
	  if (byteOffset < 0) byteOffset = buffer.length + byteOffset;
	  if (byteOffset >= buffer.length) {
	    if (dir) return -1
	    else byteOffset = buffer.length - 1;
	  } else if (byteOffset < 0) {
	    if (dir) byteOffset = 0;
	    else return -1
	  }

	  // Normalize val
	  if (typeof val === 'string') {
	    val = Buffer$1.from(val, encoding);
	  }

	  // Finally, search either indexOf (if dir is true) or lastIndexOf
	  if (internalIsBuffer(val)) {
	    // Special case: looking for empty string/buffer always fails
	    if (val.length === 0) {
	      return -1
	    }
	    return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
	  } else if (typeof val === 'number') {
	    val = val & 0xFF; // Search for a byte value [0-255]
	    if (Buffer$1.TYPED_ARRAY_SUPPORT &&
	        typeof Uint8Array.prototype.indexOf === 'function') {
	      if (dir) {
	        return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset)
	      } else {
	        return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
	      }
	    }
	    return arrayIndexOf(buffer, [ val ], byteOffset, encoding, dir)
	  }

	  throw new TypeError('val must be string, number or Buffer')
	}

	function arrayIndexOf (arr, val, byteOffset, encoding, dir) {
	  var indexSize = 1;
	  var arrLength = arr.length;
	  var valLength = val.length;

	  if (encoding !== undefined) {
	    encoding = String(encoding).toLowerCase();
	    if (encoding === 'ucs2' || encoding === 'ucs-2' ||
	        encoding === 'utf16le' || encoding === 'utf-16le') {
	      if (arr.length < 2 || val.length < 2) {
	        return -1
	      }
	      indexSize = 2;
	      arrLength /= 2;
	      valLength /= 2;
	      byteOffset /= 2;
	    }
	  }

	  function read (buf, i) {
	    if (indexSize === 1) {
	      return buf[i]
	    } else {
	      return buf.readUInt16BE(i * indexSize)
	    }
	  }

	  var i;
	  if (dir) {
	    var foundIndex = -1;
	    for (i = byteOffset; i < arrLength; i++) {
	      if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
	        if (foundIndex === -1) foundIndex = i;
	        if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
	      } else {
	        if (foundIndex !== -1) i -= i - foundIndex;
	        foundIndex = -1;
	      }
	    }
	  } else {
	    if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
	    for (i = byteOffset; i >= 0; i--) {
	      var found = true;
	      for (var j = 0; j < valLength; j++) {
	        if (read(arr, i + j) !== read(val, j)) {
	          found = false;
	          break
	        }
	      }
	      if (found) return i
	    }
	  }

	  return -1
	}

	Buffer$1.prototype.includes = function includes (val, byteOffset, encoding) {
	  return this.indexOf(val, byteOffset, encoding) !== -1
	};

	Buffer$1.prototype.indexOf = function indexOf (val, byteOffset, encoding) {
	  return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
	};

	Buffer$1.prototype.lastIndexOf = function lastIndexOf (val, byteOffset, encoding) {
	  return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
	};

	function hexWrite (buf, string, offset, length) {
	  offset = Number(offset) || 0;
	  var remaining = buf.length - offset;
	  if (!length) {
	    length = remaining;
	  } else {
	    length = Number(length);
	    if (length > remaining) {
	      length = remaining;
	    }
	  }

	  // must be an even number of digits
	  var strLen = string.length;
	  if (strLen % 2 !== 0) throw new TypeError('Invalid hex string')

	  if (length > strLen / 2) {
	    length = strLen / 2;
	  }
	  for (var i = 0; i < length; ++i) {
	    var parsed = parseInt(string.substr(i * 2, 2), 16);
	    if (isNaN(parsed)) return i
	    buf[offset + i] = parsed;
	  }
	  return i
	}

	function utf8Write (buf, string, offset, length) {
	  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
	}

	function asciiWrite (buf, string, offset, length) {
	  return blitBuffer(asciiToBytes(string), buf, offset, length)
	}

	function latin1Write (buf, string, offset, length) {
	  return asciiWrite(buf, string, offset, length)
	}

	function base64Write (buf, string, offset, length) {
	  return blitBuffer(base64ToBytes(string), buf, offset, length)
	}

	function ucs2Write (buf, string, offset, length) {
	  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
	}

	Buffer$1.prototype.write = function write (string, offset, length, encoding) {
	  // Buffer#write(string)
	  if (offset === undefined) {
	    encoding = 'utf8';
	    length = this.length;
	    offset = 0;
	  // Buffer#write(string, encoding)
	  } else if (length === undefined && typeof offset === 'string') {
	    encoding = offset;
	    length = this.length;
	    offset = 0;
	  // Buffer#write(string, offset[, length][, encoding])
	  } else if (isFinite(offset)) {
	    offset = offset | 0;
	    if (isFinite(length)) {
	      length = length | 0;
	      if (encoding === undefined) encoding = 'utf8';
	    } else {
	      encoding = length;
	      length = undefined;
	    }
	  // legacy write(string, encoding, offset, length) - remove in v0.13
	  } else {
	    throw new Error(
	      'Buffer.write(string, encoding, offset[, length]) is no longer supported'
	    )
	  }

	  var remaining = this.length - offset;
	  if (length === undefined || length > remaining) length = remaining;

	  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
	    throw new RangeError('Attempt to write outside buffer bounds')
	  }

	  if (!encoding) encoding = 'utf8';

	  var loweredCase = false;
	  for (;;) {
	    switch (encoding) {
	      case 'hex':
	        return hexWrite(this, string, offset, length)

	      case 'utf8':
	      case 'utf-8':
	        return utf8Write(this, string, offset, length)

	      case 'ascii':
	        return asciiWrite(this, string, offset, length)

	      case 'latin1':
	      case 'binary':
	        return latin1Write(this, string, offset, length)

	      case 'base64':
	        // Warning: maxLength not taken into account in base64Write
	        return base64Write(this, string, offset, length)

	      case 'ucs2':
	      case 'ucs-2':
	      case 'utf16le':
	      case 'utf-16le':
	        return ucs2Write(this, string, offset, length)

	      default:
	        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
	        encoding = ('' + encoding).toLowerCase();
	        loweredCase = true;
	    }
	  }
	};

	Buffer$1.prototype.toJSON = function toJSON () {
	  return {
	    type: 'Buffer',
	    data: Array.prototype.slice.call(this._arr || this, 0)
	  }
	};

	function base64Slice (buf, start, end) {
	  if (start === 0 && end === buf.length) {
	    return fromByteArray(buf)
	  } else {
	    return fromByteArray(buf.slice(start, end))
	  }
	}

	function utf8Slice (buf, start, end) {
	  end = Math.min(buf.length, end);
	  var res = [];

	  var i = start;
	  while (i < end) {
	    var firstByte = buf[i];
	    var codePoint = null;
	    var bytesPerSequence = (firstByte > 0xEF) ? 4
	      : (firstByte > 0xDF) ? 3
	      : (firstByte > 0xBF) ? 2
	      : 1;

	    if (i + bytesPerSequence <= end) {
	      var secondByte, thirdByte, fourthByte, tempCodePoint;

	      switch (bytesPerSequence) {
	        case 1:
	          if (firstByte < 0x80) {
	            codePoint = firstByte;
	          }
	          break
	        case 2:
	          secondByte = buf[i + 1];
	          if ((secondByte & 0xC0) === 0x80) {
	            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F);
	            if (tempCodePoint > 0x7F) {
	              codePoint = tempCodePoint;
	            }
	          }
	          break
	        case 3:
	          secondByte = buf[i + 1];
	          thirdByte = buf[i + 2];
	          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
	            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F);
	            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
	              codePoint = tempCodePoint;
	            }
	          }
	          break
	        case 4:
	          secondByte = buf[i + 1];
	          thirdByte = buf[i + 2];
	          fourthByte = buf[i + 3];
	          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
	            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F);
	            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
	              codePoint = tempCodePoint;
	            }
	          }
	      }
	    }

	    if (codePoint === null) {
	      // we did not generate a valid codePoint so insert a
	      // replacement char (U+FFFD) and advance only 1 byte
	      codePoint = 0xFFFD;
	      bytesPerSequence = 1;
	    } else if (codePoint > 0xFFFF) {
	      // encode to utf16 (surrogate pair dance)
	      codePoint -= 0x10000;
	      res.push(codePoint >>> 10 & 0x3FF | 0xD800);
	      codePoint = 0xDC00 | codePoint & 0x3FF;
	    }

	    res.push(codePoint);
	    i += bytesPerSequence;
	  }

	  return decodeCodePointsArray(res)
	}

	// Based on http://stackoverflow.com/a/22747272/680742, the browser with
	// the lowest limit is Chrome, with 0x10000 args.
	// We go 1 magnitude less, for safety
	var MAX_ARGUMENTS_LENGTH = 0x1000;

	function decodeCodePointsArray (codePoints) {
	  var len = codePoints.length;
	  if (len <= MAX_ARGUMENTS_LENGTH) {
	    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
	  }

	  // Decode in chunks to avoid "call stack size exceeded".
	  var res = '';
	  var i = 0;
	  while (i < len) {
	    res += String.fromCharCode.apply(
	      String,
	      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
	    );
	  }
	  return res
	}

	function asciiSlice (buf, start, end) {
	  var ret = '';
	  end = Math.min(buf.length, end);

	  for (var i = start; i < end; ++i) {
	    ret += String.fromCharCode(buf[i] & 0x7F);
	  }
	  return ret
	}

	function latin1Slice (buf, start, end) {
	  var ret = '';
	  end = Math.min(buf.length, end);

	  for (var i = start; i < end; ++i) {
	    ret += String.fromCharCode(buf[i]);
	  }
	  return ret
	}

	function hexSlice (buf, start, end) {
	  var len = buf.length;

	  if (!start || start < 0) start = 0;
	  if (!end || end < 0 || end > len) end = len;

	  var out = '';
	  for (var i = start; i < end; ++i) {
	    out += toHex(buf[i]);
	  }
	  return out
	}

	function utf16leSlice (buf, start, end) {
	  var bytes = buf.slice(start, end);
	  var res = '';
	  for (var i = 0; i < bytes.length; i += 2) {
	    res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
	  }
	  return res
	}

	Buffer$1.prototype.slice = function slice (start, end) {
	  var len = this.length;
	  start = ~~start;
	  end = end === undefined ? len : ~~end;

	  if (start < 0) {
	    start += len;
	    if (start < 0) start = 0;
	  } else if (start > len) {
	    start = len;
	  }

	  if (end < 0) {
	    end += len;
	    if (end < 0) end = 0;
	  } else if (end > len) {
	    end = len;
	  }

	  if (end < start) end = start;

	  var newBuf;
	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    newBuf = this.subarray(start, end);
	    Object.setPrototypeOf(newBuf, Buffer$1.prototype);
	  } else {
	    var sliceLen = end - start;
	    newBuf = new Buffer$1(sliceLen, undefined);
	    for (var i = 0; i < sliceLen; ++i) {
	      newBuf[i] = this[i + start];
	    }
	  }

	  return newBuf
	};

	/*
	 * Need to make sure that buffer isn't trying to write out of bounds.
	 */
	function checkOffset (offset, ext, length) {
	  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
	  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
	}

	Buffer$1.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
	  offset = offset | 0;
	  byteLength = byteLength | 0;
	  if (!noAssert) checkOffset(offset, byteLength, this.length);

	  var val = this[offset];
	  var mul = 1;
	  var i = 0;
	  while (++i < byteLength && (mul *= 0x100)) {
	    val += this[offset + i] * mul;
	  }

	  return val
	};

	Buffer$1.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
	  offset = offset | 0;
	  byteLength = byteLength | 0;
	  if (!noAssert) {
	    checkOffset(offset, byteLength, this.length);
	  }

	  var val = this[offset + --byteLength];
	  var mul = 1;
	  while (byteLength > 0 && (mul *= 0x100)) {
	    val += this[offset + --byteLength] * mul;
	  }

	  return val
	};

	Buffer$1.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 1, this.length);
	  return this[offset]
	};

	Buffer$1.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 2, this.length);
	  return this[offset] | (this[offset + 1] << 8)
	};

	Buffer$1.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 2, this.length);
	  return (this[offset] << 8) | this[offset + 1]
	};

	Buffer$1.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length);

	  return ((this[offset]) |
	      (this[offset + 1] << 8) |
	      (this[offset + 2] << 16)) +
	      (this[offset + 3] * 0x1000000)
	};

	Buffer$1.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length);

	  return (this[offset] * 0x1000000) +
	    ((this[offset + 1] << 16) |
	    (this[offset + 2] << 8) |
	    this[offset + 3])
	};

	Buffer$1.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
	  offset = offset | 0;
	  byteLength = byteLength | 0;
	  if (!noAssert) checkOffset(offset, byteLength, this.length);

	  var val = this[offset];
	  var mul = 1;
	  var i = 0;
	  while (++i < byteLength && (mul *= 0x100)) {
	    val += this[offset + i] * mul;
	  }
	  mul *= 0x80;

	  if (val >= mul) val -= Math.pow(2, 8 * byteLength);

	  return val
	};

	Buffer$1.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
	  offset = offset | 0;
	  byteLength = byteLength | 0;
	  if (!noAssert) checkOffset(offset, byteLength, this.length);

	  var i = byteLength;
	  var mul = 1;
	  var val = this[offset + --i];
	  while (i > 0 && (mul *= 0x100)) {
	    val += this[offset + --i] * mul;
	  }
	  mul *= 0x80;

	  if (val >= mul) val -= Math.pow(2, 8 * byteLength);

	  return val
	};

	Buffer$1.prototype.readInt8 = function readInt8 (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 1, this.length);
	  if (!(this[offset] & 0x80)) return (this[offset])
	  return ((0xff - this[offset] + 1) * -1)
	};

	Buffer$1.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 2, this.length);
	  var val = this[offset] | (this[offset + 1] << 8);
	  return (val & 0x8000) ? val | 0xFFFF0000 : val
	};

	Buffer$1.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 2, this.length);
	  var val = this[offset + 1] | (this[offset] << 8);
	  return (val & 0x8000) ? val | 0xFFFF0000 : val
	};

	Buffer$1.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length);

	  return (this[offset]) |
	    (this[offset + 1] << 8) |
	    (this[offset + 2] << 16) |
	    (this[offset + 3] << 24)
	};

	Buffer$1.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length);

	  return (this[offset] << 24) |
	    (this[offset + 1] << 16) |
	    (this[offset + 2] << 8) |
	    (this[offset + 3])
	};

	Buffer$1.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length);
	  return read(this, offset, true, 23, 4)
	};

	Buffer$1.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length);
	  return read(this, offset, false, 23, 4)
	};

	Buffer$1.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 8, this.length);
	  return read(this, offset, true, 52, 8)
	};

	Buffer$1.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 8, this.length);
	  return read(this, offset, false, 52, 8)
	};

	function checkInt (buf, value, offset, ext, max, min) {
	  if (!internalIsBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
	  if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
	  if (offset + ext > buf.length) throw new RangeError('Index out of range')
	}

	Buffer$1.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  byteLength = byteLength | 0;
	  if (!noAssert) {
	    var maxBytes = Math.pow(2, 8 * byteLength) - 1;
	    checkInt(this, value, offset, byteLength, maxBytes, 0);
	  }

	  var mul = 1;
	  var i = 0;
	  this[offset] = value & 0xFF;
	  while (++i < byteLength && (mul *= 0x100)) {
	    this[offset + i] = (value / mul) & 0xFF;
	  }

	  return offset + byteLength
	};

	Buffer$1.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  byteLength = byteLength | 0;
	  if (!noAssert) {
	    var maxBytes = Math.pow(2, 8 * byteLength) - 1;
	    checkInt(this, value, offset, byteLength, maxBytes, 0);
	  }

	  var i = byteLength - 1;
	  var mul = 1;
	  this[offset + i] = value & 0xFF;
	  while (--i >= 0 && (mul *= 0x100)) {
	    this[offset + i] = (value / mul) & 0xFF;
	  }

	  return offset + byteLength
	};

	Buffer$1.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0);
	  if (!Buffer$1.TYPED_ARRAY_SUPPORT) value = Math.floor(value);
	  this[offset] = (value & 0xff);
	  return offset + 1
	};

	function objectWriteUInt16 (buf, value, offset, littleEndian) {
	  if (value < 0) value = 0xffff + value + 1;
	  for (var i = 0, j = Math.min(buf.length - offset, 2); i < j; ++i) {
	    buf[offset + i] = (value & (0xff << (8 * (littleEndian ? i : 1 - i)))) >>>
	      (littleEndian ? i : 1 - i) * 8;
	  }
	}

	Buffer$1.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0);
	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value & 0xff);
	    this[offset + 1] = (value >>> 8);
	  } else {
	    objectWriteUInt16(this, value, offset, true);
	  }
	  return offset + 2
	};

	Buffer$1.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0);
	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value >>> 8);
	    this[offset + 1] = (value & 0xff);
	  } else {
	    objectWriteUInt16(this, value, offset, false);
	  }
	  return offset + 2
	};

	function objectWriteUInt32 (buf, value, offset, littleEndian) {
	  if (value < 0) value = 0xffffffff + value + 1;
	  for (var i = 0, j = Math.min(buf.length - offset, 4); i < j; ++i) {
	    buf[offset + i] = (value >>> (littleEndian ? i : 3 - i) * 8) & 0xff;
	  }
	}

	Buffer$1.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0);
	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    this[offset + 3] = (value >>> 24);
	    this[offset + 2] = (value >>> 16);
	    this[offset + 1] = (value >>> 8);
	    this[offset] = (value & 0xff);
	  } else {
	    objectWriteUInt32(this, value, offset, true);
	  }
	  return offset + 4
	};

	Buffer$1.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0);
	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value >>> 24);
	    this[offset + 1] = (value >>> 16);
	    this[offset + 2] = (value >>> 8);
	    this[offset + 3] = (value & 0xff);
	  } else {
	    objectWriteUInt32(this, value, offset, false);
	  }
	  return offset + 4
	};

	Buffer$1.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) {
	    var limit = Math.pow(2, 8 * byteLength - 1);

	    checkInt(this, value, offset, byteLength, limit - 1, -limit);
	  }

	  var i = 0;
	  var mul = 1;
	  var sub = 0;
	  this[offset] = value & 0xFF;
	  while (++i < byteLength && (mul *= 0x100)) {
	    if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
	      sub = 1;
	    }
	    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF;
	  }

	  return offset + byteLength
	};

	Buffer$1.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) {
	    var limit = Math.pow(2, 8 * byteLength - 1);

	    checkInt(this, value, offset, byteLength, limit - 1, -limit);
	  }

	  var i = byteLength - 1;
	  var mul = 1;
	  var sub = 0;
	  this[offset + i] = value & 0xFF;
	  while (--i >= 0 && (mul *= 0x100)) {
	    if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
	      sub = 1;
	    }
	    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF;
	  }

	  return offset + byteLength
	};

	Buffer$1.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80);
	  if (!Buffer$1.TYPED_ARRAY_SUPPORT) value = Math.floor(value);
	  if (value < 0) value = 0xff + value + 1;
	  this[offset] = (value & 0xff);
	  return offset + 1
	};

	Buffer$1.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000);
	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value & 0xff);
	    this[offset + 1] = (value >>> 8);
	  } else {
	    objectWriteUInt16(this, value, offset, true);
	  }
	  return offset + 2
	};

	Buffer$1.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000);
	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value >>> 8);
	    this[offset + 1] = (value & 0xff);
	  } else {
	    objectWriteUInt16(this, value, offset, false);
	  }
	  return offset + 2
	};

	Buffer$1.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000);
	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value & 0xff);
	    this[offset + 1] = (value >>> 8);
	    this[offset + 2] = (value >>> 16);
	    this[offset + 3] = (value >>> 24);
	  } else {
	    objectWriteUInt32(this, value, offset, true);
	  }
	  return offset + 4
	};

	Buffer$1.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
	  value = +value;
	  offset = offset | 0;
	  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000);
	  if (value < 0) value = 0xffffffff + value + 1;
	  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value >>> 24);
	    this[offset + 1] = (value >>> 16);
	    this[offset + 2] = (value >>> 8);
	    this[offset + 3] = (value & 0xff);
	  } else {
	    objectWriteUInt32(this, value, offset, false);
	  }
	  return offset + 4
	};

	function checkIEEE754 (buf, value, offset, ext, max, min) {
	  if (offset + ext > buf.length) throw new RangeError('Index out of range')
	  if (offset < 0) throw new RangeError('Index out of range')
	}

	function writeFloat (buf, value, offset, littleEndian, noAssert) {
	  if (!noAssert) {
	    checkIEEE754(buf, value, offset, 4);
	  }
	  write(buf, value, offset, littleEndian, 23, 4);
	  return offset + 4
	}

	Buffer$1.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
	  return writeFloat(this, value, offset, true, noAssert)
	};

	Buffer$1.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
	  return writeFloat(this, value, offset, false, noAssert)
	};

	function writeDouble (buf, value, offset, littleEndian, noAssert) {
	  if (!noAssert) {
	    checkIEEE754(buf, value, offset, 8);
	  }
	  write(buf, value, offset, littleEndian, 52, 8);
	  return offset + 8
	}

	Buffer$1.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
	  return writeDouble(this, value, offset, true, noAssert)
	};

	Buffer$1.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
	  return writeDouble(this, value, offset, false, noAssert)
	};

	// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
	Buffer$1.prototype.copy = function copy (target, targetStart, start, end) {
	  if (!start) start = 0;
	  if (!end && end !== 0) end = this.length;
	  if (targetStart >= target.length) targetStart = target.length;
	  if (!targetStart) targetStart = 0;
	  if (end > 0 && end < start) end = start;

	  // Copy 0 bytes; we're done
	  if (end === start) return 0
	  if (target.length === 0 || this.length === 0) return 0

	  // Fatal error conditions
	  if (targetStart < 0) {
	    throw new RangeError('targetStart out of bounds')
	  }
	  if (start < 0 || start >= this.length) throw new RangeError('sourceStart out of bounds')
	  if (end < 0) throw new RangeError('sourceEnd out of bounds')

	  // Are we oob?
	  if (end > this.length) end = this.length;
	  if (target.length - targetStart < end - start) {
	    end = target.length - targetStart + start;
	  }

	  var len = end - start;
	  var i;

	  if (this === target && start < targetStart && targetStart < end) {
	    // descending copy from end
	    for (i = len - 1; i >= 0; --i) {
	      target[i + targetStart] = this[i + start];
	    }
	  } else if (len < 1000 || !Buffer$1.TYPED_ARRAY_SUPPORT) {
	    // ascending copy from start
	    for (i = 0; i < len; ++i) {
	      target[i + targetStart] = this[i + start];
	    }
	  } else {
	    Uint8Array.prototype.set.call(
	      target,
	      this.subarray(start, start + len),
	      targetStart
	    );
	  }

	  return len
	};

	// Usage:
	//    buffer.fill(number[, offset[, end]])
	//    buffer.fill(buffer[, offset[, end]])
	//    buffer.fill(string[, offset[, end]][, encoding])
	Buffer$1.prototype.fill = function fill (val, start, end, encoding) {
	  // Handle string cases:
	  if (typeof val === 'string') {
	    if (typeof start === 'string') {
	      encoding = start;
	      start = 0;
	      end = this.length;
	    } else if (typeof end === 'string') {
	      encoding = end;
	      end = this.length;
	    }
	    if (val.length === 1) {
	      var code = val.charCodeAt(0);
	      if (code < 256) {
	        val = code;
	      }
	    }
	    if (encoding !== undefined && typeof encoding !== 'string') {
	      throw new TypeError('encoding must be a string')
	    }
	    if (typeof encoding === 'string' && !Buffer$1.isEncoding(encoding)) {
	      throw new TypeError('Unknown encoding: ' + encoding)
	    }
	  } else if (typeof val === 'number') {
	    val = val & 255;
	  }

	  // Invalid ranges are not set to a default, so can range check early.
	  if (start < 0 || this.length < start || this.length < end) {
	    throw new RangeError('Out of range index')
	  }

	  if (end <= start) {
	    return this
	  }

	  start = start >>> 0;
	  end = end === undefined ? this.length : end >>> 0;

	  if (!val) val = 0;

	  var i;
	  if (typeof val === 'number') {
	    for (i = start; i < end; ++i) {
	      this[i] = val;
	    }
	  } else {
	    var bytes = internalIsBuffer(val)
	      ? val
	      : utf8ToBytes(new Buffer$1(val, encoding).toString());
	    var len = bytes.length;
	    for (i = 0; i < end - start; ++i) {
	      this[i + start] = bytes[i % len];
	    }
	  }

	  return this
	};

	// HELPER FUNCTIONS
	// ================

	var INVALID_BASE64_RE = /[^+\/0-9A-Za-z-_]/g;

	function base64clean (str) {
	  // Node strips out invalid characters like \n and \t from the string, base64-js does not
	  str = stringtrim(str).replace(INVALID_BASE64_RE, '');
	  // Node converts strings with length < 2 to ''
	  if (str.length < 2) return ''
	  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
	  while (str.length % 4 !== 0) {
	    str = str + '=';
	  }
	  return str
	}

	function stringtrim (str) {
	  if (str.trim) return str.trim()
	  return str.replace(/^\s+|\s+$/g, '')
	}

	function toHex (n) {
	  if (n < 16) return '0' + n.toString(16)
	  return n.toString(16)
	}

	function utf8ToBytes (string, units) {
	  units = units || Infinity;
	  var codePoint;
	  var length = string.length;
	  var leadSurrogate = null;
	  var bytes = [];

	  for (var i = 0; i < length; ++i) {
	    codePoint = string.charCodeAt(i);

	    // is surrogate component
	    if (codePoint > 0xD7FF && codePoint < 0xE000) {
	      // last char was a lead
	      if (!leadSurrogate) {
	        // no lead yet
	        if (codePoint > 0xDBFF) {
	          // unexpected trail
	          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
	          continue
	        } else if (i + 1 === length) {
	          // unpaired lead
	          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
	          continue
	        }

	        // valid lead
	        leadSurrogate = codePoint;

	        continue
	      }

	      // 2 leads in a row
	      if (codePoint < 0xDC00) {
	        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
	        leadSurrogate = codePoint;
	        continue
	      }

	      // valid surrogate pair
	      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000;
	    } else if (leadSurrogate) {
	      // valid bmp char, but last char was a lead
	      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
	    }

	    leadSurrogate = null;

	    // encode utf8
	    if (codePoint < 0x80) {
	      if ((units -= 1) < 0) break
	      bytes.push(codePoint);
	    } else if (codePoint < 0x800) {
	      if ((units -= 2) < 0) break
	      bytes.push(
	        codePoint >> 0x6 | 0xC0,
	        codePoint & 0x3F | 0x80
	      );
	    } else if (codePoint < 0x10000) {
	      if ((units -= 3) < 0) break
	      bytes.push(
	        codePoint >> 0xC | 0xE0,
	        codePoint >> 0x6 & 0x3F | 0x80,
	        codePoint & 0x3F | 0x80
	      );
	    } else if (codePoint < 0x110000) {
	      if ((units -= 4) < 0) break
	      bytes.push(
	        codePoint >> 0x12 | 0xF0,
	        codePoint >> 0xC & 0x3F | 0x80,
	        codePoint >> 0x6 & 0x3F | 0x80,
	        codePoint & 0x3F | 0x80
	      );
	    } else {
	      throw new Error('Invalid code point')
	    }
	  }

	  return bytes
	}

	function asciiToBytes (str) {
	  var byteArray = [];
	  for (var i = 0; i < str.length; ++i) {
	    // Node's code seems to be doing this and not & 0x7F..
	    byteArray.push(str.charCodeAt(i) & 0xFF);
	  }
	  return byteArray
	}

	function utf16leToBytes (str, units) {
	  var c, hi, lo;
	  var byteArray = [];
	  for (var i = 0; i < str.length; ++i) {
	    if ((units -= 2) < 0) break

	    c = str.charCodeAt(i);
	    hi = c >> 8;
	    lo = c % 256;
	    byteArray.push(lo);
	    byteArray.push(hi);
	  }

	  return byteArray
	}


	function base64ToBytes (str) {
	  return toByteArray(base64clean(str))
	}

	function blitBuffer (src, dst, offset, length) {
	  for (var i = 0; i < length; ++i) {
	    if ((i + offset >= dst.length) || (i >= src.length)) break
	    dst[i + offset] = src[i];
	  }
	  return i
	}

	function isnan (val) {
	  return val !== val // eslint-disable-line no-self-compare
	}


	// the following is from is-buffer, also by Feross Aboukhadijeh and with same lisence
	// The _isBuffer check is for Safari 5-7 support, because it's missing
	// Object.prototype.constructor. Remove this eventually
	function isBuffer(obj) {
	  return obj != null && (!!obj._isBuffer || isFastBuffer(obj) || isSlowBuffer(obj))
	}

	function isFastBuffer (obj) {
	  return !!obj.constructor && typeof obj.constructor.isBuffer === 'function' && obj.constructor.isBuffer(obj)
	}

	// For Node v0.10 support. Remove this eventually.
	function isSlowBuffer (obj) {
	  return typeof obj.readFloatLE === 'function' && typeof obj.slice === 'function' && isFastBuffer(obj.slice(0, 0))
	}

	var bufferEs6 = /*#__PURE__*/Object.freeze({
		__proto__: null,
		Buffer: Buffer$1,
		INSPECT_MAX_BYTES: INSPECT_MAX_BYTES,
		SlowBuffer: SlowBuffer,
		isBuffer: isBuffer,
		kMaxLength: _kMaxLength
	});

	function BufferList() {
	  this.head = null;
	  this.tail = null;
	  this.length = 0;
	}

	BufferList.prototype.push = function (v) {
	  var entry = { data: v, next: null };
	  if (this.length > 0) this.tail.next = entry;else this.head = entry;
	  this.tail = entry;
	  ++this.length;
	};

	BufferList.prototype.unshift = function (v) {
	  var entry = { data: v, next: this.head };
	  if (this.length === 0) this.tail = entry;
	  this.head = entry;
	  ++this.length;
	};

	BufferList.prototype.shift = function () {
	  if (this.length === 0) return;
	  var ret = this.head.data;
	  if (this.length === 1) this.head = this.tail = null;else this.head = this.head.next;
	  --this.length;
	  return ret;
	};

	BufferList.prototype.clear = function () {
	  this.head = this.tail = null;
	  this.length = 0;
	};

	BufferList.prototype.join = function (s) {
	  if (this.length === 0) return '';
	  var p = this.head;
	  var ret = '' + p.data;
	  while (p = p.next) {
	    ret += s + p.data;
	  }return ret;
	};

	BufferList.prototype.concat = function (n) {
	  if (this.length === 0) return Buffer$1.alloc(0);
	  if (this.length === 1) return this.head.data;
	  var ret = Buffer$1.allocUnsafe(n >>> 0);
	  var p = this.head;
	  var i = 0;
	  while (p) {
	    p.data.copy(ret, i);
	    i += p.data.length;
	    p = p.next;
	  }
	  return ret;
	};

	// Copyright Joyent, Inc. and other Node contributors.
	var isBufferEncoding = Buffer$1.isEncoding
	  || function(encoding) {
	       switch (encoding && encoding.toLowerCase()) {
	         case 'hex': case 'utf8': case 'utf-8': case 'ascii': case 'binary': case 'base64': case 'ucs2': case 'ucs-2': case 'utf16le': case 'utf-16le': case 'raw': return true;
	         default: return false;
	       }
	     };


	function assertEncoding(encoding) {
	  if (encoding && !isBufferEncoding(encoding)) {
	    throw new Error('Unknown encoding: ' + encoding);
	  }
	}

	// StringDecoder provides an interface for efficiently splitting a series of
	// buffers into a series of JS strings without breaking apart multi-byte
	// characters. CESU-8 is handled as part of the UTF-8 encoding.
	//
	// @TODO Handling all encodings inside a single object makes it very difficult
	// to reason about this code, so it should be split up in the future.
	// @TODO There should be a utf8-strict encoding that rejects invalid UTF-8 code
	// points as used by CESU-8.
	function StringDecoder(encoding) {
	  this.encoding = (encoding || 'utf8').toLowerCase().replace(/[-_]/, '');
	  assertEncoding(encoding);
	  switch (this.encoding) {
	    case 'utf8':
	      // CESU-8 represents each of Surrogate Pair by 3-bytes
	      this.surrogateSize = 3;
	      break;
	    case 'ucs2':
	    case 'utf16le':
	      // UTF-16 represents each of Surrogate Pair by 2-bytes
	      this.surrogateSize = 2;
	      this.detectIncompleteChar = utf16DetectIncompleteChar;
	      break;
	    case 'base64':
	      // Base-64 stores 3 bytes in 4 chars, and pads the remainder.
	      this.surrogateSize = 3;
	      this.detectIncompleteChar = base64DetectIncompleteChar;
	      break;
	    default:
	      this.write = passThroughWrite;
	      return;
	  }

	  // Enough space to store all bytes of a single character. UTF-8 needs 4
	  // bytes, but CESU-8 may require up to 6 (3 bytes per surrogate).
	  this.charBuffer = new Buffer$1(6);
	  // Number of bytes received for the current incomplete multi-byte character.
	  this.charReceived = 0;
	  // Number of bytes expected for the current incomplete multi-byte character.
	  this.charLength = 0;
	}

	// write decodes the given buffer and returns it as JS string that is
	// guaranteed to not contain any partial multi-byte characters. Any partial
	// character found at the end of the buffer is buffered up, and will be
	// returned when calling write again with the remaining bytes.
	//
	// Note: Converting a Buffer containing an orphan surrogate to a String
	// currently works, but converting a String to a Buffer (via `new Buffer`, or
	// Buffer#write) will replace incomplete surrogates with the unicode
	// replacement character. See https://codereview.chromium.org/121173009/ .
	StringDecoder.prototype.write = function(buffer) {
	  var charStr = '';
	  // if our last write ended with an incomplete multibyte character
	  while (this.charLength) {
	    // determine how many remaining bytes this buffer has to offer for this char
	    var available = (buffer.length >= this.charLength - this.charReceived) ?
	        this.charLength - this.charReceived :
	        buffer.length;

	    // add the new bytes to the char buffer
	    buffer.copy(this.charBuffer, this.charReceived, 0, available);
	    this.charReceived += available;

	    if (this.charReceived < this.charLength) {
	      // still not enough chars in this buffer? wait for more ...
	      return '';
	    }

	    // remove bytes belonging to the current character from the buffer
	    buffer = buffer.slice(available, buffer.length);

	    // get the character that was split
	    charStr = this.charBuffer.slice(0, this.charLength).toString(this.encoding);

	    // CESU-8: lead surrogate (D800-DBFF) is also the incomplete character
	    var charCode = charStr.charCodeAt(charStr.length - 1);
	    if (charCode >= 0xD800 && charCode <= 0xDBFF) {
	      this.charLength += this.surrogateSize;
	      charStr = '';
	      continue;
	    }
	    this.charReceived = this.charLength = 0;

	    // if there are no more bytes in this buffer, just emit our char
	    if (buffer.length === 0) {
	      return charStr;
	    }
	    break;
	  }

	  // determine and set charLength / charReceived
	  this.detectIncompleteChar(buffer);

	  var end = buffer.length;
	  if (this.charLength) {
	    // buffer the incomplete character bytes we got
	    buffer.copy(this.charBuffer, 0, buffer.length - this.charReceived, end);
	    end -= this.charReceived;
	  }

	  charStr += buffer.toString(this.encoding, 0, end);

	  var end = charStr.length - 1;
	  var charCode = charStr.charCodeAt(end);
	  // CESU-8: lead surrogate (D800-DBFF) is also the incomplete character
	  if (charCode >= 0xD800 && charCode <= 0xDBFF) {
	    var size = this.surrogateSize;
	    this.charLength += size;
	    this.charReceived += size;
	    this.charBuffer.copy(this.charBuffer, size, 0, size);
	    buffer.copy(this.charBuffer, 0, 0, size);
	    return charStr.substring(0, end);
	  }

	  // or just emit the charStr
	  return charStr;
	};

	// detectIncompleteChar determines if there is an incomplete UTF-8 character at
	// the end of the given buffer. If so, it sets this.charLength to the byte
	// length that character, and sets this.charReceived to the number of bytes
	// that are available for this character.
	StringDecoder.prototype.detectIncompleteChar = function(buffer) {
	  // determine how many bytes we have to check at the end of this buffer
	  var i = (buffer.length >= 3) ? 3 : buffer.length;

	  // Figure out if one of the last i bytes of our buffer announces an
	  // incomplete char.
	  for (; i > 0; i--) {
	    var c = buffer[buffer.length - i];

	    // See http://en.wikipedia.org/wiki/UTF-8#Description

	    // 110XXXXX
	    if (i == 1 && c >> 5 == 0x06) {
	      this.charLength = 2;
	      break;
	    }

	    // 1110XXXX
	    if (i <= 2 && c >> 4 == 0x0E) {
	      this.charLength = 3;
	      break;
	    }

	    // 11110XXX
	    if (i <= 3 && c >> 3 == 0x1E) {
	      this.charLength = 4;
	      break;
	    }
	  }
	  this.charReceived = i;
	};

	StringDecoder.prototype.end = function(buffer) {
	  var res = '';
	  if (buffer && buffer.length)
	    res = this.write(buffer);

	  if (this.charReceived) {
	    var cr = this.charReceived;
	    var buf = this.charBuffer;
	    var enc = this.encoding;
	    res += buf.slice(0, cr).toString(enc);
	  }

	  return res;
	};

	function passThroughWrite(buffer) {
	  return buffer.toString(this.encoding);
	}

	function utf16DetectIncompleteChar(buffer) {
	  this.charReceived = buffer.length % 2;
	  this.charLength = this.charReceived ? 2 : 0;
	}

	function base64DetectIncompleteChar(buffer) {
	  this.charReceived = buffer.length % 3;
	  this.charLength = this.charReceived ? 3 : 0;
	}

	Readable.ReadableState = ReadableState;

	var debug = debuglog('stream');
	inherits$1(Readable, EventEmitter);

	function prependListener(emitter, event, fn) {
	  // Sadly this is not cacheable as some libraries bundle their own
	  // event emitter implementation with them.
	  if (typeof emitter.prependListener === 'function') {
	    return emitter.prependListener(event, fn);
	  } else {
	    // This is a hack to make sure that our error handler is attached before any
	    // userland ones.  NEVER DO THIS. This is here only because this code needs
	    // to continue to work with older versions of Node.js that do not include
	    // the prependListener() method. The goal is to eventually remove this hack.
	    if (!emitter._events || !emitter._events[event])
	      emitter.on(event, fn);
	    else if (Array.isArray(emitter._events[event]))
	      emitter._events[event].unshift(fn);
	    else
	      emitter._events[event] = [fn, emitter._events[event]];
	  }
	}
	function listenerCount (emitter, type) {
	  return emitter.listeners(type).length;
	}
	function ReadableState(options, stream) {

	  options = options || {};

	  // object stream flag. Used to make read(n) ignore n and to
	  // make all the buffer merging and length checks go away
	  this.objectMode = !!options.objectMode;

	  if (stream instanceof Duplex) this.objectMode = this.objectMode || !!options.readableObjectMode;

	  // the point at which it stops calling _read() to fill the buffer
	  // Note: 0 is a valid value, means "don't call _read preemptively ever"
	  var hwm = options.highWaterMark;
	  var defaultHwm = this.objectMode ? 16 : 16 * 1024;
	  this.highWaterMark = hwm || hwm === 0 ? hwm : defaultHwm;

	  // cast to ints.
	  this.highWaterMark = ~ ~this.highWaterMark;

	  // A linked list is used to store data chunks instead of an array because the
	  // linked list can remove elements from the beginning faster than
	  // array.shift()
	  this.buffer = new BufferList();
	  this.length = 0;
	  this.pipes = null;
	  this.pipesCount = 0;
	  this.flowing = null;
	  this.ended = false;
	  this.endEmitted = false;
	  this.reading = false;

	  // a flag to be able to tell if the onwrite cb is called immediately,
	  // or on a later tick.  We set this to true at first, because any
	  // actions that shouldn't happen until "later" should generally also
	  // not happen before the first write call.
	  this.sync = true;

	  // whenever we return null, then we set a flag to say
	  // that we're awaiting a 'readable' event emission.
	  this.needReadable = false;
	  this.emittedReadable = false;
	  this.readableListening = false;
	  this.resumeScheduled = false;

	  // Crypto is kind of old and crusty.  Historically, its default string
	  // encoding is 'binary' so we have to make this configurable.
	  // Everything else in the universe uses 'utf8', though.
	  this.defaultEncoding = options.defaultEncoding || 'utf8';

	  // when piping, we only care about 'readable' events that happen
	  // after read()ing all the bytes and not getting any pushback.
	  this.ranOut = false;

	  // the number of writers that are awaiting a drain event in .pipe()s
	  this.awaitDrain = 0;

	  // if true, a maybeReadMore has been scheduled
	  this.readingMore = false;

	  this.decoder = null;
	  this.encoding = null;
	  if (options.encoding) {
	    this.decoder = new StringDecoder(options.encoding);
	    this.encoding = options.encoding;
	  }
	}
	function Readable(options) {

	  if (!(this instanceof Readable)) return new Readable(options);

	  this._readableState = new ReadableState(options, this);

	  // legacy
	  this.readable = true;

	  if (options && typeof options.read === 'function') this._read = options.read;

	  EventEmitter.call(this);
	}

	// Manually shove something into the read() buffer.
	// This returns true if the highWaterMark has not been hit yet,
	// similar to how Writable.write() returns true if you should
	// write() some more.
	Readable.prototype.push = function (chunk, encoding) {
	  var state = this._readableState;

	  if (!state.objectMode && typeof chunk === 'string') {
	    encoding = encoding || state.defaultEncoding;
	    if (encoding !== state.encoding) {
	      chunk = Buffer.from(chunk, encoding);
	      encoding = '';
	    }
	  }

	  return readableAddChunk(this, state, chunk, encoding, false);
	};

	// Unshift should *always* be something directly out of read()
	Readable.prototype.unshift = function (chunk) {
	  var state = this._readableState;
	  return readableAddChunk(this, state, chunk, '', true);
	};

	Readable.prototype.isPaused = function () {
	  return this._readableState.flowing === false;
	};

	function readableAddChunk(stream, state, chunk, encoding, addToFront) {
	  var er = chunkInvalid(state, chunk);
	  if (er) {
	    stream.emit('error', er);
	  } else if (chunk === null) {
	    state.reading = false;
	    onEofChunk(stream, state);
	  } else if (state.objectMode || chunk && chunk.length > 0) {
	    if (state.ended && !addToFront) {
	      var e = new Error('stream.push() after EOF');
	      stream.emit('error', e);
	    } else if (state.endEmitted && addToFront) {
	      var _e = new Error('stream.unshift() after end event');
	      stream.emit('error', _e);
	    } else {
	      var skipAdd;
	      if (state.decoder && !addToFront && !encoding) {
	        chunk = state.decoder.write(chunk);
	        skipAdd = !state.objectMode && chunk.length === 0;
	      }

	      if (!addToFront) state.reading = false;

	      // Don't add to the buffer if we've decoded to an empty string chunk and
	      // we're not in object mode
	      if (!skipAdd) {
	        // if we want the data now, just emit it.
	        if (state.flowing && state.length === 0 && !state.sync) {
	          stream.emit('data', chunk);
	          stream.read(0);
	        } else {
	          // update the buffer info.
	          state.length += state.objectMode ? 1 : chunk.length;
	          if (addToFront) state.buffer.unshift(chunk);else state.buffer.push(chunk);

	          if (state.needReadable) emitReadable(stream);
	        }
	      }

	      maybeReadMore(stream, state);
	    }
	  } else if (!addToFront) {
	    state.reading = false;
	  }

	  return needMoreData(state);
	}

	// if it's past the high water mark, we can push in some more.
	// Also, if we have no data yet, we can stand some
	// more bytes.  This is to work around cases where hwm=0,
	// such as the repl.  Also, if the push() triggered a
	// readable event, and the user called read(largeNumber) such that
	// needReadable was set, then we ought to push more, so that another
	// 'readable' event will be triggered.
	function needMoreData(state) {
	  return !state.ended && (state.needReadable || state.length < state.highWaterMark || state.length === 0);
	}

	// backwards compatibility.
	Readable.prototype.setEncoding = function (enc) {
	  this._readableState.decoder = new StringDecoder(enc);
	  this._readableState.encoding = enc;
	  return this;
	};

	// Don't raise the hwm > 8MB
	var MAX_HWM = 0x800000;
	function computeNewHighWaterMark(n) {
	  if (n >= MAX_HWM) {
	    n = MAX_HWM;
	  } else {
	    // Get the next highest power of 2 to prevent increasing hwm excessively in
	    // tiny amounts
	    n--;
	    n |= n >>> 1;
	    n |= n >>> 2;
	    n |= n >>> 4;
	    n |= n >>> 8;
	    n |= n >>> 16;
	    n++;
	  }
	  return n;
	}

	// This function is designed to be inlinable, so please take care when making
	// changes to the function body.
	function howMuchToRead(n, state) {
	  if (n <= 0 || state.length === 0 && state.ended) return 0;
	  if (state.objectMode) return 1;
	  if (n !== n) {
	    // Only flow one buffer at a time
	    if (state.flowing && state.length) return state.buffer.head.data.length;else return state.length;
	  }
	  // If we're asking for more than the current hwm, then raise the hwm.
	  if (n > state.highWaterMark) state.highWaterMark = computeNewHighWaterMark(n);
	  if (n <= state.length) return n;
	  // Don't have enough
	  if (!state.ended) {
	    state.needReadable = true;
	    return 0;
	  }
	  return state.length;
	}

	// you can override either this method, or the async _read(n) below.
	Readable.prototype.read = function (n) {
	  debug('read', n);
	  n = parseInt(n, 10);
	  var state = this._readableState;
	  var nOrig = n;

	  if (n !== 0) state.emittedReadable = false;

	  // if we're doing read(0) to trigger a readable event, but we
	  // already have a bunch of data in the buffer, then just trigger
	  // the 'readable' event and move on.
	  if (n === 0 && state.needReadable && (state.length >= state.highWaterMark || state.ended)) {
	    debug('read: emitReadable', state.length, state.ended);
	    if (state.length === 0 && state.ended) endReadable(this);else emitReadable(this);
	    return null;
	  }

	  n = howMuchToRead(n, state);

	  // if we've ended, and we're now clear, then finish it up.
	  if (n === 0 && state.ended) {
	    if (state.length === 0) endReadable(this);
	    return null;
	  }

	  // All the actual chunk generation logic needs to be
	  // *below* the call to _read.  The reason is that in certain
	  // synthetic stream cases, such as passthrough streams, _read
	  // may be a completely synchronous operation which may change
	  // the state of the read buffer, providing enough data when
	  // before there was *not* enough.
	  //
	  // So, the steps are:
	  // 1. Figure out what the state of things will be after we do
	  // a read from the buffer.
	  //
	  // 2. If that resulting state will trigger a _read, then call _read.
	  // Note that this may be asynchronous, or synchronous.  Yes, it is
	  // deeply ugly to write APIs this way, but that still doesn't mean
	  // that the Readable class should behave improperly, as streams are
	  // designed to be sync/async agnostic.
	  // Take note if the _read call is sync or async (ie, if the read call
	  // has returned yet), so that we know whether or not it's safe to emit
	  // 'readable' etc.
	  //
	  // 3. Actually pull the requested chunks out of the buffer and return.

	  // if we need a readable event, then we need to do some reading.
	  var doRead = state.needReadable;
	  debug('need readable', doRead);

	  // if we currently have less than the highWaterMark, then also read some
	  if (state.length === 0 || state.length - n < state.highWaterMark) {
	    doRead = true;
	    debug('length less than watermark', doRead);
	  }

	  // however, if we've ended, then there's no point, and if we're already
	  // reading, then it's unnecessary.
	  if (state.ended || state.reading) {
	    doRead = false;
	    debug('reading or ended', doRead);
	  } else if (doRead) {
	    debug('do read');
	    state.reading = true;
	    state.sync = true;
	    // if the length is currently zero, then we *need* a readable event.
	    if (state.length === 0) state.needReadable = true;
	    // call internal read method
	    this._read(state.highWaterMark);
	    state.sync = false;
	    // If _read pushed data synchronously, then `reading` will be false,
	    // and we need to re-evaluate how much data we can return to the user.
	    if (!state.reading) n = howMuchToRead(nOrig, state);
	  }

	  var ret;
	  if (n > 0) ret = fromList(n, state);else ret = null;

	  if (ret === null) {
	    state.needReadable = true;
	    n = 0;
	  } else {
	    state.length -= n;
	  }

	  if (state.length === 0) {
	    // If we have nothing in the buffer, then we want to know
	    // as soon as we *do* get something into the buffer.
	    if (!state.ended) state.needReadable = true;

	    // If we tried to read() past the EOF, then emit end on the next tick.
	    if (nOrig !== n && state.ended) endReadable(this);
	  }

	  if (ret !== null) this.emit('data', ret);

	  return ret;
	};

	function chunkInvalid(state, chunk) {
	  var er = null;
	  if (!Buffer.isBuffer(chunk) && typeof chunk !== 'string' && chunk !== null && chunk !== undefined && !state.objectMode) {
	    er = new TypeError('Invalid non-string/buffer chunk');
	  }
	  return er;
	}

	function onEofChunk(stream, state) {
	  if (state.ended) return;
	  if (state.decoder) {
	    var chunk = state.decoder.end();
	    if (chunk && chunk.length) {
	      state.buffer.push(chunk);
	      state.length += state.objectMode ? 1 : chunk.length;
	    }
	  }
	  state.ended = true;

	  // emit 'readable' now to make sure it gets picked up.
	  emitReadable(stream);
	}

	// Don't emit readable right away in sync mode, because this can trigger
	// another read() call => stack overflow.  This way, it might trigger
	// a nextTick recursion warning, but that's not so bad.
	function emitReadable(stream) {
	  var state = stream._readableState;
	  state.needReadable = false;
	  if (!state.emittedReadable) {
	    debug('emitReadable', state.flowing);
	    state.emittedReadable = true;
	    if (state.sync) nextTick(emitReadable_, stream);else emitReadable_(stream);
	  }
	}

	function emitReadable_(stream) {
	  debug('emit readable');
	  stream.emit('readable');
	  flow(stream);
	}

	// at this point, the user has presumably seen the 'readable' event,
	// and called read() to consume some data.  that may have triggered
	// in turn another _read(n) call, in which case reading = true if
	// it's in progress.
	// However, if we're not ended, or reading, and the length < hwm,
	// then go ahead and try to read some more preemptively.
	function maybeReadMore(stream, state) {
	  if (!state.readingMore) {
	    state.readingMore = true;
	    nextTick(maybeReadMore_, stream, state);
	  }
	}

	function maybeReadMore_(stream, state) {
	  var len = state.length;
	  while (!state.reading && !state.flowing && !state.ended && state.length < state.highWaterMark) {
	    debug('maybeReadMore read 0');
	    stream.read(0);
	    if (len === state.length)
	      // didn't get any data, stop spinning.
	      break;else len = state.length;
	  }
	  state.readingMore = false;
	}

	// abstract method.  to be overridden in specific implementation classes.
	// call cb(er, data) where data is <= n in length.
	// for virtual (non-string, non-buffer) streams, "length" is somewhat
	// arbitrary, and perhaps not very meaningful.
	Readable.prototype._read = function (n) {
	  this.emit('error', new Error('not implemented'));
	};

	Readable.prototype.pipe = function (dest, pipeOpts) {
	  var src = this;
	  var state = this._readableState;

	  switch (state.pipesCount) {
	    case 0:
	      state.pipes = dest;
	      break;
	    case 1:
	      state.pipes = [state.pipes, dest];
	      break;
	    default:
	      state.pipes.push(dest);
	      break;
	  }
	  state.pipesCount += 1;
	  debug('pipe count=%d opts=%j', state.pipesCount, pipeOpts);

	  var doEnd = (!pipeOpts || pipeOpts.end !== false);

	  var endFn = doEnd ? onend : cleanup;
	  if (state.endEmitted) nextTick(endFn);else src.once('end', endFn);

	  dest.on('unpipe', onunpipe);
	  function onunpipe(readable) {
	    debug('onunpipe');
	    if (readable === src) {
	      cleanup();
	    }
	  }

	  function onend() {
	    debug('onend');
	    dest.end();
	  }

	  // when the dest drains, it reduces the awaitDrain counter
	  // on the source.  This would be more elegant with a .once()
	  // handler in flow(), but adding and removing repeatedly is
	  // too slow.
	  var ondrain = pipeOnDrain(src);
	  dest.on('drain', ondrain);

	  var cleanedUp = false;
	  function cleanup() {
	    debug('cleanup');
	    // cleanup event handlers once the pipe is broken
	    dest.removeListener('close', onclose);
	    dest.removeListener('finish', onfinish);
	    dest.removeListener('drain', ondrain);
	    dest.removeListener('error', onerror);
	    dest.removeListener('unpipe', onunpipe);
	    src.removeListener('end', onend);
	    src.removeListener('end', cleanup);
	    src.removeListener('data', ondata);

	    cleanedUp = true;

	    // if the reader is waiting for a drain event from this
	    // specific writer, then it would cause it to never start
	    // flowing again.
	    // So, if this is awaiting a drain, then we just call it now.
	    // If we don't know, then assume that we are waiting for one.
	    if (state.awaitDrain && (!dest._writableState || dest._writableState.needDrain)) ondrain();
	  }

	  // If the user pushes more data while we're writing to dest then we'll end up
	  // in ondata again. However, we only want to increase awaitDrain once because
	  // dest will only emit one 'drain' event for the multiple writes.
	  // => Introduce a guard on increasing awaitDrain.
	  var increasedAwaitDrain = false;
	  src.on('data', ondata);
	  function ondata(chunk) {
	    debug('ondata');
	    increasedAwaitDrain = false;
	    var ret = dest.write(chunk);
	    if (false === ret && !increasedAwaitDrain) {
	      // If the user unpiped during `dest.write()`, it is possible
	      // to get stuck in a permanently paused state if that write
	      // also returned false.
	      // => Check whether `dest` is still a piping destination.
	      if ((state.pipesCount === 1 && state.pipes === dest || state.pipesCount > 1 && indexOf(state.pipes, dest) !== -1) && !cleanedUp) {
	        debug('false write response, pause', src._readableState.awaitDrain);
	        src._readableState.awaitDrain++;
	        increasedAwaitDrain = true;
	      }
	      src.pause();
	    }
	  }

	  // if the dest has an error, then stop piping into it.
	  // however, don't suppress the throwing behavior for this.
	  function onerror(er) {
	    debug('onerror', er);
	    unpipe();
	    dest.removeListener('error', onerror);
	    if (listenerCount(dest, 'error') === 0) dest.emit('error', er);
	  }

	  // Make sure our error handler is attached before userland ones.
	  prependListener(dest, 'error', onerror);

	  // Both close and finish should trigger unpipe, but only once.
	  function onclose() {
	    dest.removeListener('finish', onfinish);
	    unpipe();
	  }
	  dest.once('close', onclose);
	  function onfinish() {
	    debug('onfinish');
	    dest.removeListener('close', onclose);
	    unpipe();
	  }
	  dest.once('finish', onfinish);

	  function unpipe() {
	    debug('unpipe');
	    src.unpipe(dest);
	  }

	  // tell the dest that it's being piped to
	  dest.emit('pipe', src);

	  // start the flow if it hasn't been started already.
	  if (!state.flowing) {
	    debug('pipe resume');
	    src.resume();
	  }

	  return dest;
	};

	function pipeOnDrain(src) {
	  return function () {
	    var state = src._readableState;
	    debug('pipeOnDrain', state.awaitDrain);
	    if (state.awaitDrain) state.awaitDrain--;
	    if (state.awaitDrain === 0 && src.listeners('data').length) {
	      state.flowing = true;
	      flow(src);
	    }
	  };
	}

	Readable.prototype.unpipe = function (dest) {
	  var state = this._readableState;

	  // if we're not piping anywhere, then do nothing.
	  if (state.pipesCount === 0) return this;

	  // just one destination.  most common case.
	  if (state.pipesCount === 1) {
	    // passed in one, but it's not the right one.
	    if (dest && dest !== state.pipes) return this;

	    if (!dest) dest = state.pipes;

	    // got a match.
	    state.pipes = null;
	    state.pipesCount = 0;
	    state.flowing = false;
	    if (dest) dest.emit('unpipe', this);
	    return this;
	  }

	  // slow case. multiple pipe destinations.

	  if (!dest) {
	    // remove all.
	    var dests = state.pipes;
	    var len = state.pipesCount;
	    state.pipes = null;
	    state.pipesCount = 0;
	    state.flowing = false;

	    for (var _i = 0; _i < len; _i++) {
	      dests[_i].emit('unpipe', this);
	    }return this;
	  }

	  // try to find the right one.
	  var i = indexOf(state.pipes, dest);
	  if (i === -1) return this;

	  state.pipes.splice(i, 1);
	  state.pipesCount -= 1;
	  if (state.pipesCount === 1) state.pipes = state.pipes[0];

	  dest.emit('unpipe', this);

	  return this;
	};

	// set up data events if they are asked for
	// Ensure readable listeners eventually get something
	Readable.prototype.on = function (ev, fn) {
	  var res = EventEmitter.prototype.on.call(this, ev, fn);

	  if (ev === 'data') {
	    // Start flowing on next tick if stream isn't explicitly paused
	    if (this._readableState.flowing !== false) this.resume();
	  } else if (ev === 'readable') {
	    var state = this._readableState;
	    if (!state.endEmitted && !state.readableListening) {
	      state.readableListening = state.needReadable = true;
	      state.emittedReadable = false;
	      if (!state.reading) {
	        nextTick(nReadingNextTick, this);
	      } else if (state.length) {
	        emitReadable(this);
	      }
	    }
	  }

	  return res;
	};
	Readable.prototype.addListener = Readable.prototype.on;

	function nReadingNextTick(self) {
	  debug('readable nexttick read 0');
	  self.read(0);
	}

	// pause() and resume() are remnants of the legacy readable stream API
	// If the user uses them, then switch into old mode.
	Readable.prototype.resume = function () {
	  var state = this._readableState;
	  if (!state.flowing) {
	    debug('resume');
	    state.flowing = true;
	    resume(this, state);
	  }
	  return this;
	};

	function resume(stream, state) {
	  if (!state.resumeScheduled) {
	    state.resumeScheduled = true;
	    nextTick(resume_, stream, state);
	  }
	}

	function resume_(stream, state) {
	  if (!state.reading) {
	    debug('resume read 0');
	    stream.read(0);
	  }

	  state.resumeScheduled = false;
	  state.awaitDrain = 0;
	  stream.emit('resume');
	  flow(stream);
	  if (state.flowing && !state.reading) stream.read(0);
	}

	Readable.prototype.pause = function () {
	  debug('call pause flowing=%j', this._readableState.flowing);
	  if (false !== this._readableState.flowing) {
	    debug('pause');
	    this._readableState.flowing = false;
	    this.emit('pause');
	  }
	  return this;
	};

	function flow(stream) {
	  var state = stream._readableState;
	  debug('flow', state.flowing);
	  while (state.flowing && stream.read() !== null) {}
	}

	// wrap an old-style stream as the async data source.
	// This is *not* part of the readable stream interface.
	// It is an ugly unfortunate mess of history.
	Readable.prototype.wrap = function (stream) {
	  var state = this._readableState;
	  var paused = false;

	  var self = this;
	  stream.on('end', function () {
	    debug('wrapped end');
	    if (state.decoder && !state.ended) {
	      var chunk = state.decoder.end();
	      if (chunk && chunk.length) self.push(chunk);
	    }

	    self.push(null);
	  });

	  stream.on('data', function (chunk) {
	    debug('wrapped data');
	    if (state.decoder) chunk = state.decoder.write(chunk);

	    // don't skip over falsy values in objectMode
	    if (state.objectMode && (chunk === null || chunk === undefined)) return;else if (!state.objectMode && (!chunk || !chunk.length)) return;

	    var ret = self.push(chunk);
	    if (!ret) {
	      paused = true;
	      stream.pause();
	    }
	  });

	  // proxy all the other methods.
	  // important when wrapping filters and duplexes.
	  for (var i in stream) {
	    if (this[i] === undefined && typeof stream[i] === 'function') {
	      this[i] = function (method) {
	        return function () {
	          return stream[method].apply(stream, arguments);
	        };
	      }(i);
	    }
	  }

	  // proxy certain important events.
	  var events = ['error', 'close', 'destroy', 'pause', 'resume'];
	  forEach(events, function (ev) {
	    stream.on(ev, self.emit.bind(self, ev));
	  });

	  // when we try to consume some more bytes, simply unpause the
	  // underlying stream.
	  self._read = function (n) {
	    debug('wrapped _read', n);
	    if (paused) {
	      paused = false;
	      stream.resume();
	    }
	  };

	  return self;
	};

	// exposed for testing purposes only.
	Readable._fromList = fromList;

	// Pluck off n bytes from an array of buffers.
	// Length is the combined lengths of all the buffers in the list.
	// This function is designed to be inlinable, so please take care when making
	// changes to the function body.
	function fromList(n, state) {
	  // nothing buffered
	  if (state.length === 0) return null;

	  var ret;
	  if (state.objectMode) ret = state.buffer.shift();else if (!n || n >= state.length) {
	    // read it all, truncate the list
	    if (state.decoder) ret = state.buffer.join('');else if (state.buffer.length === 1) ret = state.buffer.head.data;else ret = state.buffer.concat(state.length);
	    state.buffer.clear();
	  } else {
	    // read part of list
	    ret = fromListPartial(n, state.buffer, state.decoder);
	  }

	  return ret;
	}

	// Extracts only enough buffered data to satisfy the amount requested.
	// This function is designed to be inlinable, so please take care when making
	// changes to the function body.
	function fromListPartial(n, list, hasStrings) {
	  var ret;
	  if (n < list.head.data.length) {
	    // slice is the same for buffers and strings
	    ret = list.head.data.slice(0, n);
	    list.head.data = list.head.data.slice(n);
	  } else if (n === list.head.data.length) {
	    // first chunk is a perfect match
	    ret = list.shift();
	  } else {
	    // result spans more than one buffer
	    ret = hasStrings ? copyFromBufferString(n, list) : copyFromBuffer(n, list);
	  }
	  return ret;
	}

	// Copies a specified amount of characters from the list of buffered data
	// chunks.
	// This function is designed to be inlinable, so please take care when making
	// changes to the function body.
	function copyFromBufferString(n, list) {
	  var p = list.head;
	  var c = 1;
	  var ret = p.data;
	  n -= ret.length;
	  while (p = p.next) {
	    var str = p.data;
	    var nb = n > str.length ? str.length : n;
	    if (nb === str.length) ret += str;else ret += str.slice(0, n);
	    n -= nb;
	    if (n === 0) {
	      if (nb === str.length) {
	        ++c;
	        if (p.next) list.head = p.next;else list.head = list.tail = null;
	      } else {
	        list.head = p;
	        p.data = str.slice(nb);
	      }
	      break;
	    }
	    ++c;
	  }
	  list.length -= c;
	  return ret;
	}

	// Copies a specified amount of bytes from the list of buffered data chunks.
	// This function is designed to be inlinable, so please take care when making
	// changes to the function body.
	function copyFromBuffer(n, list) {
	  var ret = Buffer.allocUnsafe(n);
	  var p = list.head;
	  var c = 1;
	  p.data.copy(ret);
	  n -= p.data.length;
	  while (p = p.next) {
	    var buf = p.data;
	    var nb = n > buf.length ? buf.length : n;
	    buf.copy(ret, ret.length - n, 0, nb);
	    n -= nb;
	    if (n === 0) {
	      if (nb === buf.length) {
	        ++c;
	        if (p.next) list.head = p.next;else list.head = list.tail = null;
	      } else {
	        list.head = p;
	        p.data = buf.slice(nb);
	      }
	      break;
	    }
	    ++c;
	  }
	  list.length -= c;
	  return ret;
	}

	function endReadable(stream) {
	  var state = stream._readableState;

	  // If we get here before consuming all the bytes, then that is a
	  // bug in node.  Should never happen.
	  if (state.length > 0) throw new Error('"endReadable()" called on non-empty stream');

	  if (!state.endEmitted) {
	    state.ended = true;
	    nextTick(endReadableNT, state, stream);
	  }
	}

	function endReadableNT(state, stream) {
	  // Check that we didn't get one last unshift.
	  if (!state.endEmitted && state.length === 0) {
	    state.endEmitted = true;
	    stream.readable = false;
	    stream.emit('end');
	  }
	}

	function forEach(xs, f) {
	  for (var i = 0, l = xs.length; i < l; i++) {
	    f(xs[i], i);
	  }
	}

	function indexOf(xs, x) {
	  for (var i = 0, l = xs.length; i < l; i++) {
	    if (xs[i] === x) return i;
	  }
	  return -1;
	}

	// A bit simpler than readable streams.
	Writable.WritableState = WritableState;
	inherits$1(Writable, EventEmitter);

	function nop() {}

	function WriteReq(chunk, encoding, cb) {
	  this.chunk = chunk;
	  this.encoding = encoding;
	  this.callback = cb;
	  this.next = null;
	}

	function WritableState(options, stream) {
	  Object.defineProperty(this, 'buffer', {
	    get: deprecate(function () {
	      return this.getBuffer();
	    }, '_writableState.buffer is deprecated. Use _writableState.getBuffer ' + 'instead.')
	  });
	  options = options || {};

	  // object stream flag to indicate whether or not this stream
	  // contains buffers or objects.
	  this.objectMode = !!options.objectMode;

	  if (stream instanceof Duplex) this.objectMode = this.objectMode || !!options.writableObjectMode;

	  // the point at which write() starts returning false
	  // Note: 0 is a valid value, means that we always return false if
	  // the entire buffer is not flushed immediately on write()
	  var hwm = options.highWaterMark;
	  var defaultHwm = this.objectMode ? 16 : 16 * 1024;
	  this.highWaterMark = hwm || hwm === 0 ? hwm : defaultHwm;

	  // cast to ints.
	  this.highWaterMark = ~ ~this.highWaterMark;

	  this.needDrain = false;
	  // at the start of calling end()
	  this.ending = false;
	  // when end() has been called, and returned
	  this.ended = false;
	  // when 'finish' is emitted
	  this.finished = false;

	  // should we decode strings into buffers before passing to _write?
	  // this is here so that some node-core streams can optimize string
	  // handling at a lower level.
	  var noDecode = options.decodeStrings === false;
	  this.decodeStrings = !noDecode;

	  // Crypto is kind of old and crusty.  Historically, its default string
	  // encoding is 'binary' so we have to make this configurable.
	  // Everything else in the universe uses 'utf8', though.
	  this.defaultEncoding = options.defaultEncoding || 'utf8';

	  // not an actual buffer we keep track of, but a measurement
	  // of how much we're waiting to get pushed to some underlying
	  // socket or file.
	  this.length = 0;

	  // a flag to see when we're in the middle of a write.
	  this.writing = false;

	  // when true all writes will be buffered until .uncork() call
	  this.corked = 0;

	  // a flag to be able to tell if the onwrite cb is called immediately,
	  // or on a later tick.  We set this to true at first, because any
	  // actions that shouldn't happen until "later" should generally also
	  // not happen before the first write call.
	  this.sync = true;

	  // a flag to know if we're processing previously buffered items, which
	  // may call the _write() callback in the same tick, so that we don't
	  // end up in an overlapped onwrite situation.
	  this.bufferProcessing = false;

	  // the callback that's passed to _write(chunk,cb)
	  this.onwrite = function (er) {
	    onwrite(stream, er);
	  };

	  // the callback that the user supplies to write(chunk,encoding,cb)
	  this.writecb = null;

	  // the amount that is being written when _write is called.
	  this.writelen = 0;

	  this.bufferedRequest = null;
	  this.lastBufferedRequest = null;

	  // number of pending user-supplied write callbacks
	  // this must be 0 before 'finish' can be emitted
	  this.pendingcb = 0;

	  // emit prefinish if the only thing we're waiting for is _write cbs
	  // This is relevant for synchronous Transform streams
	  this.prefinished = false;

	  // True if the error was already emitted and should not be thrown again
	  this.errorEmitted = false;

	  // count buffered requests
	  this.bufferedRequestCount = 0;

	  // allocate the first CorkedRequest, there is always
	  // one allocated and free to use, and we maintain at most two
	  this.corkedRequestsFree = new CorkedRequest(this);
	}

	WritableState.prototype.getBuffer = function writableStateGetBuffer() {
	  var current = this.bufferedRequest;
	  var out = [];
	  while (current) {
	    out.push(current);
	    current = current.next;
	  }
	  return out;
	};
	function Writable(options) {

	  // Writable ctor is applied to Duplexes, though they're not
	  // instanceof Writable, they're instanceof Readable.
	  if (!(this instanceof Writable) && !(this instanceof Duplex)) return new Writable(options);

	  this._writableState = new WritableState(options, this);

	  // legacy.
	  this.writable = true;

	  if (options) {
	    if (typeof options.write === 'function') this._write = options.write;

	    if (typeof options.writev === 'function') this._writev = options.writev;
	  }

	  EventEmitter.call(this);
	}

	// Otherwise people can pipe Writable streams, which is just wrong.
	Writable.prototype.pipe = function () {
	  this.emit('error', new Error('Cannot pipe, not readable'));
	};

	function writeAfterEnd(stream, cb) {
	  var er = new Error('write after end');
	  // TODO: defer error events consistently everywhere, not just the cb
	  stream.emit('error', er);
	  nextTick(cb, er);
	}

	// If we get something that is not a buffer, string, null, or undefined,
	// and we're not in objectMode, then that's an error.
	// Otherwise stream chunks are all considered to be of length=1, and the
	// watermarks determine how many objects to keep in the buffer, rather than
	// how many bytes or characters.
	function validChunk(stream, state, chunk, cb) {
	  var valid = true;
	  var er = false;
	  // Always throw error if a null is written
	  // if we are not in object mode then throw
	  // if it is not a buffer, string, or undefined.
	  if (chunk === null) {
	    er = new TypeError('May not write null values to stream');
	  } else if (!Buffer$1.isBuffer(chunk) && typeof chunk !== 'string' && chunk !== undefined && !state.objectMode) {
	    er = new TypeError('Invalid non-string/buffer chunk');
	  }
	  if (er) {
	    stream.emit('error', er);
	    nextTick(cb, er);
	    valid = false;
	  }
	  return valid;
	}

	Writable.prototype.write = function (chunk, encoding, cb) {
	  var state = this._writableState;
	  var ret = false;

	  if (typeof encoding === 'function') {
	    cb = encoding;
	    encoding = null;
	  }

	  if (Buffer$1.isBuffer(chunk)) encoding = 'buffer';else if (!encoding) encoding = state.defaultEncoding;

	  if (typeof cb !== 'function') cb = nop;

	  if (state.ended) writeAfterEnd(this, cb);else if (validChunk(this, state, chunk, cb)) {
	    state.pendingcb++;
	    ret = writeOrBuffer(this, state, chunk, encoding, cb);
	  }

	  return ret;
	};

	Writable.prototype.cork = function () {
	  var state = this._writableState;

	  state.corked++;
	};

	Writable.prototype.uncork = function () {
	  var state = this._writableState;

	  if (state.corked) {
	    state.corked--;

	    if (!state.writing && !state.corked && !state.finished && !state.bufferProcessing && state.bufferedRequest) clearBuffer(this, state);
	  }
	};

	Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
	  // node::ParseEncoding() requires lower case.
	  if (typeof encoding === 'string') encoding = encoding.toLowerCase();
	  if (!(['hex', 'utf8', 'utf-8', 'ascii', 'binary', 'base64', 'ucs2', 'ucs-2', 'utf16le', 'utf-16le', 'raw'].indexOf((encoding + '').toLowerCase()) > -1)) throw new TypeError('Unknown encoding: ' + encoding);
	  this._writableState.defaultEncoding = encoding;
	  return this;
	};

	function decodeChunk(state, chunk, encoding) {
	  if (!state.objectMode && state.decodeStrings !== false && typeof chunk === 'string') {
	    chunk = Buffer$1.from(chunk, encoding);
	  }
	  return chunk;
	}

	// if we're already writing something, then just put this
	// in the queue, and wait our turn.  Otherwise, call _write
	// If we return false, then we need a drain event, so set that flag.
	function writeOrBuffer(stream, state, chunk, encoding, cb) {
	  chunk = decodeChunk(state, chunk, encoding);

	  if (Buffer$1.isBuffer(chunk)) encoding = 'buffer';
	  var len = state.objectMode ? 1 : chunk.length;

	  state.length += len;

	  var ret = state.length < state.highWaterMark;
	  // we must ensure that previous needDrain will not be reset to false.
	  if (!ret) state.needDrain = true;

	  if (state.writing || state.corked) {
	    var last = state.lastBufferedRequest;
	    state.lastBufferedRequest = new WriteReq(chunk, encoding, cb);
	    if (last) {
	      last.next = state.lastBufferedRequest;
	    } else {
	      state.bufferedRequest = state.lastBufferedRequest;
	    }
	    state.bufferedRequestCount += 1;
	  } else {
	    doWrite(stream, state, false, len, chunk, encoding, cb);
	  }

	  return ret;
	}

	function doWrite(stream, state, writev, len, chunk, encoding, cb) {
	  state.writelen = len;
	  state.writecb = cb;
	  state.writing = true;
	  state.sync = true;
	  if (writev) stream._writev(chunk, state.onwrite);else stream._write(chunk, encoding, state.onwrite);
	  state.sync = false;
	}

	function onwriteError(stream, state, sync, er, cb) {
	  --state.pendingcb;
	  if (sync) nextTick(cb, er);else cb(er);

	  stream._writableState.errorEmitted = true;
	  stream.emit('error', er);
	}

	function onwriteStateUpdate(state) {
	  state.writing = false;
	  state.writecb = null;
	  state.length -= state.writelen;
	  state.writelen = 0;
	}

	function onwrite(stream, er) {
	  var state = stream._writableState;
	  var sync = state.sync;
	  var cb = state.writecb;

	  onwriteStateUpdate(state);

	  if (er) onwriteError(stream, state, sync, er, cb);else {
	    // Check if we're actually ready to finish, but don't emit yet
	    var finished = needFinish(state);

	    if (!finished && !state.corked && !state.bufferProcessing && state.bufferedRequest) {
	      clearBuffer(stream, state);
	    }

	    if (sync) {
	      /*<replacement>*/
	        nextTick(afterWrite, stream, state, finished, cb);
	      /*</replacement>*/
	    } else {
	        afterWrite(stream, state, finished, cb);
	      }
	  }
	}

	function afterWrite(stream, state, finished, cb) {
	  if (!finished) onwriteDrain(stream, state);
	  state.pendingcb--;
	  cb();
	  finishMaybe(stream, state);
	}

	// Must force callback to be called on nextTick, so that we don't
	// emit 'drain' before the write() consumer gets the 'false' return
	// value, and has a chance to attach a 'drain' listener.
	function onwriteDrain(stream, state) {
	  if (state.length === 0 && state.needDrain) {
	    state.needDrain = false;
	    stream.emit('drain');
	  }
	}

	// if there's something in the buffer waiting, then process it
	function clearBuffer(stream, state) {
	  state.bufferProcessing = true;
	  var entry = state.bufferedRequest;

	  if (stream._writev && entry && entry.next) {
	    // Fast case, write everything using _writev()
	    var l = state.bufferedRequestCount;
	    var buffer = new Array(l);
	    var holder = state.corkedRequestsFree;
	    holder.entry = entry;

	    var count = 0;
	    while (entry) {
	      buffer[count] = entry;
	      entry = entry.next;
	      count += 1;
	    }

	    doWrite(stream, state, true, state.length, buffer, '', holder.finish);

	    // doWrite is almost always async, defer these to save a bit of time
	    // as the hot path ends with doWrite
	    state.pendingcb++;
	    state.lastBufferedRequest = null;
	    if (holder.next) {
	      state.corkedRequestsFree = holder.next;
	      holder.next = null;
	    } else {
	      state.corkedRequestsFree = new CorkedRequest(state);
	    }
	  } else {
	    // Slow case, write chunks one-by-one
	    while (entry) {
	      var chunk = entry.chunk;
	      var encoding = entry.encoding;
	      var cb = entry.callback;
	      var len = state.objectMode ? 1 : chunk.length;

	      doWrite(stream, state, false, len, chunk, encoding, cb);
	      entry = entry.next;
	      // if we didn't call the onwrite immediately, then
	      // it means that we need to wait until it does.
	      // also, that means that the chunk and cb are currently
	      // being processed, so move the buffer counter past them.
	      if (state.writing) {
	        break;
	      }
	    }

	    if (entry === null) state.lastBufferedRequest = null;
	  }

	  state.bufferedRequestCount = 0;
	  state.bufferedRequest = entry;
	  state.bufferProcessing = false;
	}

	Writable.prototype._write = function (chunk, encoding, cb) {
	  cb(new Error('not implemented'));
	};

	Writable.prototype._writev = null;

	Writable.prototype.end = function (chunk, encoding, cb) {
	  var state = this._writableState;

	  if (typeof chunk === 'function') {
	    cb = chunk;
	    chunk = null;
	    encoding = null;
	  } else if (typeof encoding === 'function') {
	    cb = encoding;
	    encoding = null;
	  }

	  if (chunk !== null && chunk !== undefined) this.write(chunk, encoding);

	  // .end() fully uncorks
	  if (state.corked) {
	    state.corked = 1;
	    this.uncork();
	  }

	  // ignore unnecessary end() calls.
	  if (!state.ending && !state.finished) endWritable(this, state, cb);
	};

	function needFinish(state) {
	  return state.ending && state.length === 0 && state.bufferedRequest === null && !state.finished && !state.writing;
	}

	function prefinish(stream, state) {
	  if (!state.prefinished) {
	    state.prefinished = true;
	    stream.emit('prefinish');
	  }
	}

	function finishMaybe(stream, state) {
	  var need = needFinish(state);
	  if (need) {
	    if (state.pendingcb === 0) {
	      prefinish(stream, state);
	      state.finished = true;
	      stream.emit('finish');
	    } else {
	      prefinish(stream, state);
	    }
	  }
	  return need;
	}

	function endWritable(stream, state, cb) {
	  state.ending = true;
	  finishMaybe(stream, state);
	  if (cb) {
	    if (state.finished) nextTick(cb);else stream.once('finish', cb);
	  }
	  state.ended = true;
	  stream.writable = false;
	}

	// It seems a linked list but it is not
	// there will be only 2 of these for each stream
	function CorkedRequest(state) {
	  var _this = this;

	  this.next = null;
	  this.entry = null;

	  this.finish = function (err) {
	    var entry = _this.entry;
	    _this.entry = null;
	    while (entry) {
	      var cb = entry.callback;
	      state.pendingcb--;
	      cb(err);
	      entry = entry.next;
	    }
	    if (state.corkedRequestsFree) {
	      state.corkedRequestsFree.next = _this;
	    } else {
	      state.corkedRequestsFree = _this;
	    }
	  };
	}

	inherits$1(Duplex, Readable);

	var keys = Object.keys(Writable.prototype);
	for (var v = 0; v < keys.length; v++) {
	  var method = keys[v];
	  if (!Duplex.prototype[method]) Duplex.prototype[method] = Writable.prototype[method];
	}
	function Duplex(options) {
	  if (!(this instanceof Duplex)) return new Duplex(options);

	  Readable.call(this, options);
	  Writable.call(this, options);

	  if (options && options.readable === false) this.readable = false;

	  if (options && options.writable === false) this.writable = false;

	  this.allowHalfOpen = true;
	  if (options && options.allowHalfOpen === false) this.allowHalfOpen = false;

	  this.once('end', onend);
	}

	// the no-half-open enforcer
	function onend() {
	  // if we allow half-open state, or if the writable side ended,
	  // then we're ok.
	  if (this.allowHalfOpen || this._writableState.ended) return;

	  // no more data can be written.
	  // But allow more writes to happen in this tick.
	  nextTick(onEndNT, this);
	}

	function onEndNT(self) {
	  self.end();
	}

	// a transform stream is a readable/writable stream where you do
	inherits$1(Transform, Duplex);

	function TransformState(stream) {
	  this.afterTransform = function (er, data) {
	    return afterTransform(stream, er, data);
	  };

	  this.needTransform = false;
	  this.transforming = false;
	  this.writecb = null;
	  this.writechunk = null;
	  this.writeencoding = null;
	}

	function afterTransform(stream, er, data) {
	  var ts = stream._transformState;
	  ts.transforming = false;

	  var cb = ts.writecb;

	  if (!cb) return stream.emit('error', new Error('no writecb in Transform class'));

	  ts.writechunk = null;
	  ts.writecb = null;

	  if (data !== null && data !== undefined) stream.push(data);

	  cb(er);

	  var rs = stream._readableState;
	  rs.reading = false;
	  if (rs.needReadable || rs.length < rs.highWaterMark) {
	    stream._read(rs.highWaterMark);
	  }
	}
	function Transform(options) {
	  if (!(this instanceof Transform)) return new Transform(options);

	  Duplex.call(this, options);

	  this._transformState = new TransformState(this);

	  // when the writable side finishes, then flush out anything remaining.
	  var stream = this;

	  // start out asking for a readable event once data is transformed.
	  this._readableState.needReadable = true;

	  // we have implemented the _read method, and done the other things
	  // that Readable wants before the first _read call, so unset the
	  // sync guard flag.
	  this._readableState.sync = false;

	  if (options) {
	    if (typeof options.transform === 'function') this._transform = options.transform;

	    if (typeof options.flush === 'function') this._flush = options.flush;
	  }

	  this.once('prefinish', function () {
	    if (typeof this._flush === 'function') this._flush(function (er) {
	      done(stream, er);
	    });else done(stream);
	  });
	}

	Transform.prototype.push = function (chunk, encoding) {
	  this._transformState.needTransform = false;
	  return Duplex.prototype.push.call(this, chunk, encoding);
	};

	// This is the part where you do stuff!
	// override this function in implementation classes.
	// 'chunk' is an input chunk.
	//
	// Call `push(newChunk)` to pass along transformed output
	// to the readable side.  You may call 'push' zero or more times.
	//
	// Call `cb(err)` when you are done with this chunk.  If you pass
	// an error, then that'll put the hurt on the whole operation.  If you
	// never call cb(), then you'll never get another chunk.
	Transform.prototype._transform = function (chunk, encoding, cb) {
	  throw new Error('Not implemented');
	};

	Transform.prototype._write = function (chunk, encoding, cb) {
	  var ts = this._transformState;
	  ts.writecb = cb;
	  ts.writechunk = chunk;
	  ts.writeencoding = encoding;
	  if (!ts.transforming) {
	    var rs = this._readableState;
	    if (ts.needTransform || rs.needReadable || rs.length < rs.highWaterMark) this._read(rs.highWaterMark);
	  }
	};

	// Doesn't matter what the args are here.
	// _transform does all the work.
	// That we got here means that the readable side wants more data.
	Transform.prototype._read = function (n) {
	  var ts = this._transformState;

	  if (ts.writechunk !== null && ts.writecb && !ts.transforming) {
	    ts.transforming = true;
	    this._transform(ts.writechunk, ts.writeencoding, ts.afterTransform);
	  } else {
	    // mark that we need a transform, so that any data that comes in
	    // will get processed, now that we've asked for it.
	    ts.needTransform = true;
	  }
	};

	function done(stream, er) {
	  if (er) return stream.emit('error', er);

	  // if there's nothing in the write buffer, then that means
	  // that nothing more will ever be provided
	  var ws = stream._writableState;
	  var ts = stream._transformState;

	  if (ws.length) throw new Error('Calling transform done when ws.length != 0');

	  if (ts.transforming) throw new Error('Calling transform done when still transforming');

	  return stream.push(null);
	}

	inherits$1(PassThrough, Transform);
	function PassThrough(options) {
	  if (!(this instanceof PassThrough)) return new PassThrough(options);

	  Transform.call(this, options);
	}

	PassThrough.prototype._transform = function (chunk, encoding, cb) {
	  cb(null, chunk);
	};

	inherits$1(Stream, EventEmitter);
	Stream.Readable = Readable;
	Stream.Writable = Writable;
	Stream.Duplex = Duplex;
	Stream.Transform = Transform;
	Stream.PassThrough = PassThrough;

	// Backwards-compat with node 0.4.x
	Stream.Stream = Stream;

	// old-style streams.  Note that the pipe method (the only relevant
	// part of this class) is overridden in the Readable class.

	function Stream() {
	  EventEmitter.call(this);
	}

	Stream.prototype.pipe = function(dest, options) {
	  var source = this;

	  function ondata(chunk) {
	    if (dest.writable) {
	      if (false === dest.write(chunk) && source.pause) {
	        source.pause();
	      }
	    }
	  }

	  source.on('data', ondata);

	  function ondrain() {
	    if (source.readable && source.resume) {
	      source.resume();
	    }
	  }

	  dest.on('drain', ondrain);

	  // If the 'end' option is not supplied, dest.end() will be called when
	  // source gets the 'end' or 'close' events.  Only dest.end() once.
	  if (!dest._isStdio && (!options || options.end !== false)) {
	    source.on('end', onend);
	    source.on('close', onclose);
	  }

	  var didOnEnd = false;
	  function onend() {
	    if (didOnEnd) return;
	    didOnEnd = true;

	    dest.end();
	  }


	  function onclose() {
	    if (didOnEnd) return;
	    didOnEnd = true;

	    if (typeof dest.destroy === 'function') dest.destroy();
	  }

	  // don't leave dangling pipes when there are errors.
	  function onerror(er) {
	    cleanup();
	    if (EventEmitter.listenerCount(this, 'error') === 0) {
	      throw er; // Unhandled stream error in pipe.
	    }
	  }

	  source.on('error', onerror);
	  dest.on('error', onerror);

	  // remove all the event listeners that were added.
	  function cleanup() {
	    source.removeListener('data', ondata);
	    dest.removeListener('drain', ondrain);

	    source.removeListener('end', onend);
	    source.removeListener('close', onclose);

	    source.removeListener('error', onerror);
	    dest.removeListener('error', onerror);

	    source.removeListener('end', cleanup);
	    source.removeListener('close', cleanup);

	    dest.removeListener('close', cleanup);
	  }

	  source.on('end', cleanup);
	  source.on('close', cleanup);

	  dest.on('close', cleanup);

	  dest.emit('pipe', source);

	  // Allow for unix-like usage: A.pipe(B).pipe(C)
	  return dest;
	};

	var stream = /*#__PURE__*/Object.freeze({
		__proto__: null,
		Duplex: Duplex,
		PassThrough: PassThrough,
		Readable: Readable,
		Stream: Stream,
		Transform: Transform,
		Writable: Writable,
		default: Stream
	});

	var rStates = {
	  UNSENT: 0,
	  OPENED: 1,
	  HEADERS_RECEIVED: 2,
	  LOADING: 3,
	  DONE: 4
	};
	function IncomingMessage(xhr, response, mode) {
	  var self = this;
	  Readable.call(self);

	  self._mode = mode;
	  self.headers = {};
	  self.rawHeaders = [];
	  self.trailers = {};
	  self.rawTrailers = [];

	  // Fake the 'close' event, but only once 'end' fires
	  self.on('end', function() {
	    // The nextTick is necessary to prevent the 'request' module from causing an infinite loop
	    process.nextTick(function() {
	      self.emit('close');
	    });
	  });
	  var read;
	  if (mode === 'fetch') {
	    self._fetchResponse = response;

	    self.url = response.url;
	    self.statusCode = response.status;
	    self.statusMessage = response.statusText;
	      // backwards compatible version of for (<item> of <iterable>):
	      // for (var <item>,_i,_it = <iterable>[Symbol.iterator](); <item> = (_i = _it.next()).value,!_i.done;)
	    for (var header, _i, _it = response.headers[Symbol.iterator](); header = (_i = _it.next()).value, !_i.done;) {
	      self.headers[header[0].toLowerCase()] = header[1];
	      self.rawHeaders.push(header[0], header[1]);
	    }

	    // TODO: this doesn't respect backpressure. Once WritableStream is available, this can be fixed
	    var reader = response.body.getReader();

	    read = function () {
	      reader.read().then(function(result) {
	        if (self._destroyed)
	          return
	        if (result.done) {
	          self.push(null);
	          return
	        }
	        self.push(new Buffer(result.value));
	        read();
	      });
	    };
	    read();

	  } else {
	    self._xhr = xhr;
	    self._pos = 0;

	    self.url = xhr.responseURL;
	    self.statusCode = xhr.status;
	    self.statusMessage = xhr.statusText;
	    var headers = xhr.getAllResponseHeaders().split(/\r?\n/);
	    headers.forEach(function(header) {
	      var matches = header.match(/^([^:]+):\s*(.*)/);
	      if (matches) {
	        var key = matches[1].toLowerCase();
	        if (key === 'set-cookie') {
	          if (self.headers[key] === undefined) {
	            self.headers[key] = [];
	          }
	          self.headers[key].push(matches[2]);
	        } else if (self.headers[key] !== undefined) {
	          self.headers[key] += ', ' + matches[2];
	        } else {
	          self.headers[key] = matches[2];
	        }
	        self.rawHeaders.push(matches[1], matches[2]);
	      }
	    });

	    self._charset = 'x-user-defined';
	    if (!overrideMimeType) {
	      var mimeType = self.rawHeaders['mime-type'];
	      if (mimeType) {
	        var charsetMatch = mimeType.match(/;\s*charset=([^;])(;|$)/);
	        if (charsetMatch) {
	          self._charset = charsetMatch[1].toLowerCase();
	        }
	      }
	      if (!self._charset)
	        self._charset = 'utf-8'; // best guess
	    }
	  }
	}

	inherits$1(IncomingMessage, Readable);

	IncomingMessage.prototype._read = function() {};

	IncomingMessage.prototype._onXHRProgress = function() {
	  var self = this;

	  var xhr = self._xhr;

	  var response = null;
	  switch (self._mode) {
	  case 'text:vbarray': // For IE9
	    if (xhr.readyState !== rStates.DONE)
	      break
	    try {
	      // This fails in IE8
	      response = new global.VBArray(xhr.responseBody).toArray();
	    } catch (e) {
	      // pass
	    }
	    if (response !== null) {
	      self.push(new Buffer(response));
	      break
	    }
	    // Falls through in IE8
	  case 'text':
	    try { // This will fail when readyState = 3 in IE9. Switch mode and wait for readyState = 4
	      response = xhr.responseText;
	    } catch (e) {
	      self._mode = 'text:vbarray';
	      break
	    }
	    if (response.length > self._pos) {
	      var newData = response.substr(self._pos);
	      if (self._charset === 'x-user-defined') {
	        var buffer = new Buffer(newData.length);
	        for (var i = 0; i < newData.length; i++)
	          buffer[i] = newData.charCodeAt(i) & 0xff;

	        self.push(buffer);
	      } else {
	        self.push(newData, self._charset);
	      }
	      self._pos = response.length;
	    }
	    break
	  case 'arraybuffer':
	    if (xhr.readyState !== rStates.DONE || !xhr.response)
	      break
	    response = xhr.response;
	    self.push(new Buffer(new Uint8Array(response)));
	    break
	  case 'moz-chunked-arraybuffer': // take whole
	    response = xhr.response;
	    if (xhr.readyState !== rStates.LOADING || !response)
	      break
	    self.push(new Buffer(new Uint8Array(response)));
	    break
	  case 'ms-stream':
	    response = xhr.response;
	    if (xhr.readyState !== rStates.LOADING)
	      break
	    var reader = new global.MSStreamReader();
	    reader.onprogress = function() {
	      if (reader.result.byteLength > self._pos) {
	        self.push(new Buffer(new Uint8Array(reader.result.slice(self._pos))));
	        self._pos = reader.result.byteLength;
	      }
	    };
	    reader.onload = function() {
	      self.push(null);
	    };
	      // reader.onerror = ??? // TODO: this
	    reader.readAsArrayBuffer(response);
	    break
	  }

	  // The ms-stream case handles end separately in reader.onload()
	  if (self._xhr.readyState === rStates.DONE && self._mode !== 'ms-stream') {
	    self.push(null);
	  }
	};

	// from https://github.com/jhiesey/to-arraybuffer/blob/6502d9850e70ba7935a7df4ad86b358fc216f9f0/index.js
	function toArrayBuffer (buf) {
	  // If the buffer is backed by a Uint8Array, a faster version will work
	  if (buf instanceof Uint8Array) {
	    // If the buffer isn't a subarray, return the underlying ArrayBuffer
	    if (buf.byteOffset === 0 && buf.byteLength === buf.buffer.byteLength) {
	      return buf.buffer
	    } else if (typeof buf.buffer.slice === 'function') {
	      // Otherwise we need to get a proper copy
	      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength)
	    }
	  }

	  if (isBuffer(buf)) {
	    // This is the slow version that will work with any Buffer
	    // implementation (even in old browsers)
	    var arrayCopy = new Uint8Array(buf.length);
	    var len = buf.length;
	    for (var i = 0; i < len; i++) {
	      arrayCopy[i] = buf[i];
	    }
	    return arrayCopy.buffer
	  } else {
	    throw new Error('Argument must be a Buffer')
	  }
	}

	function decideMode(preferBinary, useFetch) {
	  if (hasFetch && useFetch) {
	    return 'fetch'
	  } else if (mozchunkedarraybuffer) {
	    return 'moz-chunked-arraybuffer'
	  } else if (msstream) {
	    return 'ms-stream'
	  } else if (arraybuffer && preferBinary) {
	    return 'arraybuffer'
	  } else if (vbArray && preferBinary) {
	    return 'text:vbarray'
	  } else {
	    return 'text'
	  }
	}

	function ClientRequest(opts) {
	  var self = this;
	  Writable.call(self);

	  self._opts = opts;
	  self._body = [];
	  self._headers = {};
	  if (opts.auth)
	    self.setHeader('Authorization', 'Basic ' + new Buffer(opts.auth).toString('base64'));
	  Object.keys(opts.headers).forEach(function(name) {
	    self.setHeader(name, opts.headers[name]);
	  });

	  var preferBinary;
	  var useFetch = true;
	  if (opts.mode === 'disable-fetch') {
	    // If the use of XHR should be preferred and includes preserving the 'content-type' header
	    useFetch = false;
	    preferBinary = true;
	  } else if (opts.mode === 'prefer-streaming') {
	    // If streaming is a high priority but binary compatibility and
	    // the accuracy of the 'content-type' header aren't
	    preferBinary = false;
	  } else if (opts.mode === 'allow-wrong-content-type') {
	    // If streaming is more important than preserving the 'content-type' header
	    preferBinary = !overrideMimeType;
	  } else if (!opts.mode || opts.mode === 'default' || opts.mode === 'prefer-fast') {
	    // Use binary if text streaming may corrupt data or the content-type header, or for speed
	    preferBinary = true;
	  } else {
	    throw new Error('Invalid value for opts.mode')
	  }
	  self._mode = decideMode(preferBinary, useFetch);

	  self.on('finish', function() {
	    self._onFinish();
	  });
	}

	inherits$1(ClientRequest, Writable);
	// Taken from http://www.w3.org/TR/XMLHttpRequest/#the-setrequestheader%28%29-method
	var unsafeHeaders = [
	  'accept-charset',
	  'accept-encoding',
	  'access-control-request-headers',
	  'access-control-request-method',
	  'connection',
	  'content-length',
	  'cookie',
	  'cookie2',
	  'date',
	  'dnt',
	  'expect',
	  'host',
	  'keep-alive',
	  'origin',
	  'referer',
	  'te',
	  'trailer',
	  'transfer-encoding',
	  'upgrade',
	  'user-agent',
	  'via'
	];
	ClientRequest.prototype.setHeader = function(name, value) {
	  var self = this;
	  var lowerName = name.toLowerCase();
	    // This check is not necessary, but it prevents warnings from browsers about setting unsafe
	    // headers. To be honest I'm not entirely sure hiding these warnings is a good thing, but
	    // http-browserify did it, so I will too.
	  if (unsafeHeaders.indexOf(lowerName) !== -1)
	    return

	  self._headers[lowerName] = {
	    name: name,
	    value: value
	  };
	};

	ClientRequest.prototype.getHeader = function(name) {
	  var self = this;
	  return self._headers[name.toLowerCase()].value
	};

	ClientRequest.prototype.removeHeader = function(name) {
	  var self = this;
	  delete self._headers[name.toLowerCase()];
	};

	ClientRequest.prototype._onFinish = function() {
	  var self = this;

	  if (self._destroyed)
	    return
	  var opts = self._opts;

	  var headersObj = self._headers;
	  var body;
	  if (opts.method === 'POST' || opts.method === 'PUT' || opts.method === 'PATCH') {
	    if (blobConstructor()) {
	      body = new global.Blob(self._body.map(function(buffer) {
	        return toArrayBuffer(buffer)
	      }), {
	        type: (headersObj['content-type'] || {}).value || ''
	      });
	    } else {
	      // get utf8 string
	      body = Buffer.concat(self._body).toString();
	    }
	  }

	  if (self._mode === 'fetch') {
	    var headers = Object.keys(headersObj).map(function(name) {
	      return [headersObj[name].name, headersObj[name].value]
	    });

	    global.fetch(self._opts.url, {
	      method: self._opts.method,
	      headers: headers,
	      body: body,
	      mode: 'cors',
	      credentials: opts.withCredentials ? 'include' : 'same-origin'
	    }).then(function(response) {
	      self._fetchResponse = response;
	      self._connect();
	    }, function(reason) {
	      self.emit('error', reason);
	    });
	  } else {
	    var xhr = self._xhr = new global.XMLHttpRequest();
	    try {
	      xhr.open(self._opts.method, self._opts.url, true);
	    } catch (err) {
	      process.nextTick(function() {
	        self.emit('error', err);
	      });
	      return
	    }

	    // Can't set responseType on really old browsers
	    if ('responseType' in xhr)
	      xhr.responseType = self._mode.split(':')[0];

	    if ('withCredentials' in xhr)
	      xhr.withCredentials = !!opts.withCredentials;

	    if (self._mode === 'text' && 'overrideMimeType' in xhr)
	      xhr.overrideMimeType('text/plain; charset=x-user-defined');

	    Object.keys(headersObj).forEach(function(name) {
	      xhr.setRequestHeader(headersObj[name].name, headersObj[name].value);
	    });

	    self._response = null;
	    xhr.onreadystatechange = function() {
	      switch (xhr.readyState) {
	      case rStates.LOADING:
	      case rStates.DONE:
	        self._onXHRProgress();
	        break
	      }
	    };
	      // Necessary for streaming in Firefox, since xhr.response is ONLY defined
	      // in onprogress, not in onreadystatechange with xhr.readyState = 3
	    if (self._mode === 'moz-chunked-arraybuffer') {
	      xhr.onprogress = function() {
	        self._onXHRProgress();
	      };
	    }

	    xhr.onerror = function() {
	      if (self._destroyed)
	        return
	      self.emit('error', new Error('XHR error'));
	    };

	    try {
	      xhr.send(body);
	    } catch (err) {
	      process.nextTick(function() {
	        self.emit('error', err);
	      });
	      return
	    }
	  }
	};

	/**
	 * Checks if xhr.status is readable and non-zero, indicating no error.
	 * Even though the spec says it should be available in readyState 3,
	 * accessing it throws an exception in IE8
	 */
	function statusValid(xhr) {
	  try {
	    var status = xhr.status;
	    return (status !== null && status !== 0)
	  } catch (e) {
	    return false
	  }
	}

	ClientRequest.prototype._onXHRProgress = function() {
	  var self = this;

	  if (!statusValid(self._xhr) || self._destroyed)
	    return

	  if (!self._response)
	    self._connect();

	  self._response._onXHRProgress();
	};

	ClientRequest.prototype._connect = function() {
	  var self = this;

	  if (self._destroyed)
	    return

	  self._response = new IncomingMessage(self._xhr, self._fetchResponse, self._mode);
	  self.emit('response', self._response);
	};

	ClientRequest.prototype._write = function(chunk, encoding, cb) {
	  var self = this;

	  self._body.push(chunk);
	  cb();
	};

	ClientRequest.prototype.abort = ClientRequest.prototype.destroy = function() {
	  var self = this;
	  self._destroyed = true;
	  if (self._response)
	    self._response._destroyed = true;
	  if (self._xhr)
	    self._xhr.abort();
	    // Currently, there isn't a way to truly abort a fetch.
	    // If you like bikeshedding, see https://github.com/whatwg/fetch/issues/27
	};

	ClientRequest.prototype.end = function(data, encoding, cb) {
	  var self = this;
	  if (typeof data === 'function') {
	    cb = data;
	    data = undefined;
	  }

	  Writable.prototype.end.call(self, data, encoding, cb);
	};

	ClientRequest.prototype.flushHeaders = function() {};
	ClientRequest.prototype.setTimeout = function() {};
	ClientRequest.prototype.setNoDelay = function() {};
	ClientRequest.prototype.setSocketKeepAlive = function() {};

	/*
	this and http-lib folder

	The MIT License

	Copyright (c) 2015 John Hiesey

	Permission is hereby granted, free of charge,
	to any person obtaining a copy of this software and
	associated documentation files (the "Software"), to
	deal in the Software without restriction, including
	without limitation the rights to use, copy, modify,
	merge, publish, distribute, sublicense, and/or sell
	copies of the Software, and to permit persons to whom
	the Software is furnished to do so,
	subject to the following conditions:

	The above copyright notice and this permission notice
	shall be included in all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
	EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
	OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
	ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
	TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

	*/

	function request(opts, cb) {
	  if (typeof opts === 'string')
	    opts = urlParse(opts);


	  // Normally, the page is loaded from http or https, so not specifying a protocol
	  // will result in a (valid) protocol-relative url. However, this won't work if
	  // the protocol is something else, like 'file:'
	  var defaultProtocol = global.location.protocol.search(/^https?:$/) === -1 ? 'http:' : '';

	  var protocol = opts.protocol || defaultProtocol;
	  var host = opts.hostname || opts.host;
	  var port = opts.port;
	  var path = opts.path || '/';

	  // Necessary for IPv6 addresses
	  if (host && host.indexOf(':') !== -1)
	    host = '[' + host + ']';

	  // This may be a relative url. The browser should always be able to interpret it correctly.
	  opts.url = (host ? (protocol + '//' + host) : '') + (port ? ':' + port : '') + path;
	  opts.method = (opts.method || 'GET').toUpperCase();
	  opts.headers = opts.headers || {};

	  // Also valid opts.auth, opts.mode

	  var req = new ClientRequest(opts);
	  if (cb)
	    req.on('response', cb);
	  return req
	}

	function get(opts, cb) {
	  var req = request(opts, cb);
	  req.end();
	  return req
	}

	function Agent() {}
	Agent.defaultMaxSockets = 4;

	var METHODS = [
	  'CHECKOUT',
	  'CONNECT',
	  'COPY',
	  'DELETE',
	  'GET',
	  'HEAD',
	  'LOCK',
	  'M-SEARCH',
	  'MERGE',
	  'MKACTIVITY',
	  'MKCOL',
	  'MOVE',
	  'NOTIFY',
	  'OPTIONS',
	  'PATCH',
	  'POST',
	  'PROPFIND',
	  'PROPPATCH',
	  'PURGE',
	  'PUT',
	  'REPORT',
	  'SEARCH',
	  'SUBSCRIBE',
	  'TRACE',
	  'UNLOCK',
	  'UNSUBSCRIBE'
	];
	var STATUS_CODES = {
	  100: 'Continue',
	  101: 'Switching Protocols',
	  102: 'Processing', // RFC 2518, obsoleted by RFC 4918
	  200: 'OK',
	  201: 'Created',
	  202: 'Accepted',
	  203: 'Non-Authoritative Information',
	  204: 'No Content',
	  205: 'Reset Content',
	  206: 'Partial Content',
	  207: 'Multi-Status', // RFC 4918
	  300: 'Multiple Choices',
	  301: 'Moved Permanently',
	  302: 'Moved Temporarily',
	  303: 'See Other',
	  304: 'Not Modified',
	  305: 'Use Proxy',
	  307: 'Temporary Redirect',
	  400: 'Bad Request',
	  401: 'Unauthorized',
	  402: 'Payment Required',
	  403: 'Forbidden',
	  404: 'Not Found',
	  405: 'Method Not Allowed',
	  406: 'Not Acceptable',
	  407: 'Proxy Authentication Required',
	  408: 'Request Time-out',
	  409: 'Conflict',
	  410: 'Gone',
	  411: 'Length Required',
	  412: 'Precondition Failed',
	  413: 'Request Entity Too Large',
	  414: 'Request-URI Too Large',
	  415: 'Unsupported Media Type',
	  416: 'Requested Range Not Satisfiable',
	  417: 'Expectation Failed',
	  418: 'I\'m a teapot', // RFC 2324
	  422: 'Unprocessable Entity', // RFC 4918
	  423: 'Locked', // RFC 4918
	  424: 'Failed Dependency', // RFC 4918
	  425: 'Unordered Collection', // RFC 4918
	  426: 'Upgrade Required', // RFC 2817
	  428: 'Precondition Required', // RFC 6585
	  429: 'Too Many Requests', // RFC 6585
	  431: 'Request Header Fields Too Large', // RFC 6585
	  500: 'Internal Server Error',
	  501: 'Not Implemented',
	  502: 'Bad Gateway',
	  503: 'Service Unavailable',
	  504: 'Gateway Time-out',
	  505: 'HTTP Version Not Supported',
	  506: 'Variant Also Negotiates', // RFC 2295
	  507: 'Insufficient Storage', // RFC 4918
	  509: 'Bandwidth Limit Exceeded',
	  510: 'Not Extended', // RFC 2774
	  511: 'Network Authentication Required' // RFC 6585
	};

	var http = {
	  request,
	  get,
	  Agent,
	  METHODS,
	  STATUS_CODES
	};

	var http$1 = /*#__PURE__*/Object.freeze({
		__proto__: null,
		Agent: Agent,
		METHODS: METHODS,
		STATUS_CODES: STATUS_CODES,
		default: http,
		get: get,
		request: request
	});

	var require$$3 = /*@__PURE__*/getAugmentedNamespace(http$1);

	var utils = {};

	var hasRequiredUtils;

	function requireUtils () {
		if (hasRequiredUtils) return utils;
		hasRequiredUtils = 1;
		(function (exports) {
			// Generated by CoffeeScript 1.12.7
			(function() {
			  var crypto, escapable, lookup, unroll_lookup;

			  crypto = require$$1$2;

			  exports.array_intersection = function(arr_a, arr_b) {
			    var a, j, len, r;
			    r = [];
			    for (j = 0, len = arr_a.length; j < len; j++) {
			      a = arr_a[j];
			      if (arr_b.indexOf(a) !== -1) {
			        r.push(a);
			      }
			    }
			    return r;
			  };

			  exports.escape_selected = function(str, chars) {
			    var c, i, j, l, len, map, parts, r, ref, v;
			    map = {};
			    chars = '%' + chars;
			    for (j = 0, len = chars.length; j < len; j++) {
			      c = chars[j];
			      map[c] = escape(c);
			    }
			    r = new RegExp('([' + chars + '])');
			    parts = str.split(r);
			    for (i = l = 0, ref = parts.length; 0 <= ref ? l < ref : l > ref; i = 0 <= ref ? ++l : --l) {
			      v = parts[i];
			      if (v.length === 1 && v in map) {
			        parts[i] = map[v];
			      }
			    }
			    return parts.join('');
			  };

			  exports.buffer_concat = function(buf_a, buf_b) {
			    var dst;
			    dst = new Buffer(buf_a.length + buf_b.length);
			    buf_a.copy(dst);
			    buf_b.copy(dst, buf_a.length);
			    return dst;
			  };

			  exports.md5_hex = function(data) {
			    return crypto.createHash('md5').update(data).digest('hex');
			  };

			  exports.sha1_base64 = function(data) {
			    return crypto.createHash('sha1').update(data).digest('base64');
			  };

			  exports.timeout_chain = function(arr) {
			    var fun, ref, timeout, user_fun;
			    arr = arr.slice(0);
			    if (!arr.length) {
			      return;
			    }
			    ref = arr.shift(), timeout = ref[0], user_fun = ref[1];
			    fun = (function(_this) {
			      return function() {
			        user_fun();
			        return exports.timeout_chain(arr);
			      };
			    })();
			    return setTimeout(fun, timeout);
			  };

			  exports.objectExtend = function(dst, src) {
			    var k;
			    for (k in src) {
			      if (src.hasOwnProperty(k)) {
			        dst[k] = src[k];
			      }
			    }
			    return dst;
			  };

			  exports.overshadowListeners = function(ee, event, handler) {
			    var new_handler, old_listeners;
			    old_listeners = ee.listeners(event).slice(0);
			    ee.removeAllListeners(event);
			    new_handler = function() {
			      var j, len, listener;
			      if (handler.apply(this, arguments) !== true) {
			        for (j = 0, len = old_listeners.length; j < len; j++) {
			          listener = old_listeners[j];
			          listener.apply(this, arguments);
			        }
			        return false;
			      }
			      return true;
			    };
			    return ee.addListener(event, new_handler);
			  };

			  escapable = /[\x00-\x1f\ud800-\udfff\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufff0-\uffff]/g;

			  unroll_lookup = function(escapable) {
			    var c, i, unrolled;
			    unrolled = {};
			    c = (function() {
			      var j, results;
			      results = [];
			      for (i = j = 0; j < 65536; i = ++j) {
			        results.push(String.fromCharCode(i));
			      }
			      return results;
			    })();
			    escapable.lastIndex = 0;
			    c.join('').replace(escapable, function(a) {
			      return unrolled[a] = '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
			    });
			    return unrolled;
			  };

			  lookup = unroll_lookup(escapable);

			  exports.quote = function(string) {
			    var quoted;
			    quoted = JSON.stringify(string);
			    escapable.lastIndex = 0;
			    if (!escapable.test(quoted)) {
			      return quoted;
			    }
			    return quoted.replace(escapable, function(a) {
			      return lookup[a];
			    });
			  };

			  exports.parseCookie = function(cookie_header) {
			    var cookie, cookies, j, len, parts, ref;
			    cookies = {};
			    if (cookie_header) {
			      ref = cookie_header.split(';');
			      for (j = 0, len = ref.length; j < len; j++) {
			        cookie = ref[j];
			        parts = cookie.split('=');
			        cookies[parts[0].trim()] = (parts[1] || '').trim();
			      }
			    }
			    return cookies;
			  };

			  exports.random32 = function() {
			    var foo, v;
			    foo = crypto.randomBytes(4);
			    v = [foo[0], foo[1], foo[2], foo[3]];
			    return v[0] + (v[1] * 256) + (v[2] * 256 * 256) + (v[3] * 256 * 256 * 256);
			  };

			}).call(commonjsGlobal);
	} (utils));
		return utils;
	}

	var hasRequiredWebjs;

	function requireWebjs () {
		if (hasRequiredWebjs) return webjs;
		hasRequiredWebjs = 1;
		// Generated by CoffeeScript 1.12.7
		(function() {
		  var execute_request, fake_response, fs, http, querystring, url, utils;

		  url = require$$3$1;

		  querystring = require$$1$1;

		  fs = require$$1$2;

		  http = require$$3;

		  utils = requireUtils();

		  execute_request = function(app, funs, req, res, data) {
		    var fun, results, x;
		    try {
		      results = [];
		      while (funs.length > 0) {
		        fun = funs.shift();
		        req.last_fun = fun;
		        results.push(data = app[fun](req, res, data, req.next_filter));
		      }
		      return results;
		    } catch (error1) {
		      x = error1;
		      if (typeof x === 'object' && 'status' in x) {
		        if (x.status === 0) {
		          return;
		        } else if ('handle_' + x.status in app) {
		          app['handle_' + x.status](req, res, x);
		        } else {
		          app['handle_error'](req, res, x);
		        }
		      } else {
		        app['handle_error'](req, res, x);
		      }
		      return app['log_request'](req, res, true);
		    }
		  };

		  fake_response = function(req, res) {
		    var headers;
		    headers = {
		      'Connection': 'close'
		    };
		    res.writeHead = function(status, user_headers) {
		      var k, r;
		      if (user_headers == null) {
		        user_headers = {};
		      }
		      r = [];
		      r.push('HTTP/' + req.httpVersion + ' ' + status + ' ' + http.STATUS_CODES[status]);
		      utils.objectExtend(headers, user_headers);
		      for (k in headers) {
		        r.push(k + ': ' + headers[k]);
		      }
		      r = r.concat(['', '']);
		      try {
		        return res.write(r.join('\r\n'));
		      } catch (error1) {
		      }
		    };
		    return res.setHeader = function(k, v) {
		      return headers[k] = v;
		    };
		  };

		  webjs.generateHandler = function(app, dispatcher) {
		    return function(req, res, head) {
		      var allowed_methods, found, funs, i, j, l, len, m, method, path, ref, row;
		      if (typeof res.writeHead === "undefined") {
		        fake_response(req, res);
		      }
		      utils.objectExtend(req, url.parse(req.url, true));
		      req.start_date = new Date();
		      found = false;
		      allowed_methods = [];
		      for (j = 0, len = dispatcher.length; j < len; j++) {
		        row = dispatcher[j];
		        method = row[0], path = row[1], funs = row[2];
		        if (path.constructor !== Array) {
		          path = [path];
		        }
		        m = req.pathname.match(path[0]);
		        if (!m) {
		          continue;
		        }
		        if (!req.method.match(new RegExp(method))) {
		          allowed_methods.push(method);
		          continue;
		        }
		        for (i = l = 1, ref = path.length; 1 <= ref ? l < ref : l > ref; i = 1 <= ref ? ++l : --l) {
		          req[path[i]] = m[i];
		        }
		        funs = funs.slice(0);
		        funs.push('log_request');
		        req.next_filter = function(data) {
		          return execute_request(app, funs, req, res, data);
		        };
		        req.next_filter(head);
		        found = true;
		        break;
		      }
		      if (!found) {
		        if (allowed_methods.length !== 0) {
		          app['handle_405'](req, res, allowed_methods);
		        } else {
		          app['handle_404'](req, res);
		        }
		        app['log_request'](req, res, true);
		      }
		    };
		  };

		  webjs.GenericApp = (function() {
		    function GenericApp() {}

		    GenericApp.prototype.handle_404 = function(req, res, x) {
		      if (res.finished) {
		        return x;
		      }
		      res.writeHead(404, {});
		      res.end();
		      return true;
		    };

		    GenericApp.prototype.handle_405 = function(req, res, methods) {
		      res.writeHead(405, {
		        'Allow': methods.join(', ')
		      });
		      res.end();
		      return true;
		    };

		    GenericApp.prototype.handle_error = function(req, res, x) {
		      if (res.finished) {
		        return x;
		      }
		      if (typeof x === 'object' && 'status' in x) {
		        res.writeHead(x.status, {});
		        res.end(x.message || "");
		      } else {
		        try {
		          res.writeHead(500, {});
		          res.end("500 - Internal Server Error");
		        } catch (error1) {
		          x = error1;
		        }
		        this.log('error', 'Exception on "' + req.method + ' ' + req.href + '" in filter "' + req.last_fun + '":\n' + (x.stack || x));
		      }
		      return true;
		    };

		    GenericApp.prototype.log_request = function(req, res, data) {
		      var td;
		      td = (new Date()) - req.start_date;
		      this.log('info', req.method + ' ' + req.url + ' ' + td + 'ms ' + (res.finished ? res.statusCode : '(unfinished)'));
		      return data;
		    };

		    GenericApp.prototype.log = function(severity, line) {
		      return console.log(line);
		    };

		    GenericApp.prototype.expose_html = function(req, res, content) {
		      if (res.finished) {
		        return content;
		      }
		      if (!res.getHeader('Content-Type')) {
		        res.setHeader('Content-Type', 'text/html; charset=UTF-8');
		      }
		      return this.expose(req, res, content);
		    };

		    GenericApp.prototype.expose_json = function(req, res, content) {
		      if (res.finished) {
		        return content;
		      }
		      if (!res.getHeader('Content-Type')) {
		        res.setHeader('Content-Type', 'application/json');
		      }
		      return this.expose(req, res, JSON.stringify(content));
		    };

		    GenericApp.prototype.expose = function(req, res, content) {
		      if (res.finished) {
		        return content;
		      }
		      if (content && !res.getHeader('Content-Type')) {
		        res.setHeader('Content-Type', 'text/plain');
		      }
		      if (content) {
		        res.setHeader('Content-Length', content.length);
		      }
		      res.writeHead(res.statusCode);
		      res.end(content, 'utf8');
		      return true;
		    };

		    GenericApp.prototype.serve_file = function(req, res, filename, next_filter) {
		      var a;
		      a = function(error, content) {
		        if (error) {
		          res.writeHead(500);
		          res.end("can't read file");
		        } else {
		          res.setHeader('Content-length', content.length);
		          res.writeHead(res.statusCode, res.headers);
		          res.end(content, 'utf8');
		        }
		        return next_filter(true);
		      };
		      fs.readFile(filename, a);
		      throw {
		        status: 0
		      };
		    };

		    GenericApp.prototype.cache_for = function(req, res, content) {
		      var exp;
		      res.cache_for = res.cache_for || 365 * 24 * 60 * 60;
		      res.setHeader('Cache-Control', 'public, max-age=' + res.cache_for);
		      exp = new Date();
		      exp.setTime(exp.getTime() + res.cache_for * 1000);
		      res.setHeader('Expires', exp.toGMTString());
		      return content;
		    };

		    GenericApp.prototype.h_no_cache = function(req, res, content) {
		      res.setHeader('Cache-Control', 'no-store, no-cache, no-transform, must-revalidate, max-age=0');
		      return content;
		    };

		    GenericApp.prototype.expect_form = function(req, res, _data, next_filter) {
		      var data;
		      data = new Buffer(0);
		      req.on('data', (function(_this) {
		        return function(d) {
		          return data = utils.buffer_concat(data, new Buffer(d, 'binary'));
		        };
		      })());
		      req.on('end', (function(_this) {
		        return function() {
		          var q;
		          data = data.toString('utf-8');
		          switch ((req.headers['content-type'] || '').split(';')[0]) {
		            case 'application/x-www-form-urlencoded':
		              q = querystring.parse(data);
		              break;
		            case 'text/plain':
		            case '':
		              q = data;
		              break;
		            default:
		              _this.log('error', "Unsupported content-type " + req.headers['content-type']);
		              q = void 0;
		          }
		          return next_filter(q);
		        };
		      })(this));
		      throw {
		        status: 0
		      };
		    };

		    GenericApp.prototype.expect_xhr = function(req, res, _data, next_filter) {
		      var data;
		      data = new Buffer(0);
		      req.on('data', (function(_this) {
		        return function(d) {
		          return data = utils.buffer_concat(data, new Buffer(d, 'binary'));
		        };
		      })());
		      req.on('end', (function(_this) {
		        return function() {
		          var q;
		          data = data.toString('utf-8');
		          switch ((req.headers['content-type'] || '').split(';')[0]) {
		            case 'text/plain':
		            case 'T':
		            case 'application/json':
		            case 'application/xml':
		            case '':
		            case 'text/xml':
		              q = data;
		              break;
		            default:
		              _this.log('error', 'Unsupported content-type ' + req.headers['content-type']);
		              q = void 0;
		          }
		          return next_filter(q);
		        };
		      })(this));
		      throw {
		        status: 0
		      };
		    };

		    return GenericApp;

		  })();

		}).call(commonjsGlobal);
		return webjs;
	}

	var transWebsocket = {};

	var require$$0$3 = /*@__PURE__*/getAugmentedNamespace(util$1);

	var safeBuffer = {exports: {}};

	var require$$0$2 = /*@__PURE__*/getAugmentedNamespace(bufferEs6);

	/* eslint-disable node/no-deprecated-api */

	var hasRequiredSafeBuffer;

	function requireSafeBuffer () {
		if (hasRequiredSafeBuffer) return safeBuffer.exports;
		hasRequiredSafeBuffer = 1;
		(function (module, exports) {
			var buffer = require$$0$2;
			var Buffer = buffer.Buffer;

			// alternative to using Object.keys for old browsers
			function copyProps (src, dst) {
			  for (var key in src) {
			    dst[key] = src[key];
			  }
			}
			if (Buffer.from && Buffer.alloc && Buffer.allocUnsafe && Buffer.allocUnsafeSlow) {
			  module.exports = buffer;
			} else {
			  // Copy properties from require('buffer')
			  copyProps(buffer, exports);
			  exports.Buffer = SafeBuffer;
			}

			function SafeBuffer (arg, encodingOrOffset, length) {
			  return Buffer(arg, encodingOrOffset, length)
			}

			SafeBuffer.prototype = Object.create(Buffer.prototype);

			// Copy static methods from Buffer
			copyProps(Buffer, SafeBuffer);

			SafeBuffer.from = function (arg, encodingOrOffset, length) {
			  if (typeof arg === 'number') {
			    throw new TypeError('Argument must not be a number')
			  }
			  return Buffer(arg, encodingOrOffset, length)
			};

			SafeBuffer.alloc = function (size, fill, encoding) {
			  if (typeof size !== 'number') {
			    throw new TypeError('Argument must be a number')
			  }
			  var buf = Buffer(size);
			  if (fill !== undefined) {
			    if (typeof encoding === 'string') {
			      buf.fill(fill, encoding);
			    } else {
			      buf.fill(fill);
			    }
			  } else {
			    buf.fill(0);
			  }
			  return buf
			};

			SafeBuffer.allocUnsafe = function (size) {
			  if (typeof size !== 'number') {
			    throw new TypeError('Argument must be a number')
			  }
			  return Buffer(size)
			};

			SafeBuffer.allocUnsafeSlow = function (size) {
			  if (typeof size !== 'number') {
			    throw new TypeError('Argument must be a number')
			  }
			  return buffer.SlowBuffer(size)
			};
	} (safeBuffer, safeBuffer.exports));
		return safeBuffer.exports;
	}

	var streams = {};

	var require$$0$1 = /*@__PURE__*/getAugmentedNamespace(stream);

	var hasRequiredStreams;

	function requireStreams () {
		if (hasRequiredStreams) return streams;
		hasRequiredStreams = 1;

		/**

		Streams in a WebSocket connection
		---------------------------------

		We model a WebSocket as two duplex streams: one stream is for the wire protocol
		over an I/O socket, and the other is for incoming/outgoing messages.


		                        +----------+      +---------+      +----------+
		    [1] write(chunk) -->| ~~~~~~~~ +----->| parse() +----->| ~~~~~~~~ +--> emit('data') [2]
		                        |          |      +----+----+      |          |
		                        |          |           |           |          |
		                        |    IO    |           | [5]       | Messages |
		                        |          |           V           |          |
		                        |          |      +---------+      |          |
		    [4] emit('data') <--+ ~~~~~~~~ |<-----+ frame() |<-----+ ~~~~~~~~ |<-- write(chunk) [3]
		                        +----------+      +---------+      +----------+


		Message transfer in each direction is simple: IO receives a byte stream [1] and
		sends this stream for parsing. The parser will periodically emit a complete
		message text on the Messages stream [2]. Similarly, when messages are written
		to the Messages stream [3], they are framed using the WebSocket wire format and
		emitted via IO [4].

		There is a feedback loop via [5] since some input from [1] will be things like
		ping, pong and close frames. In these cases the protocol responds by emitting
		responses directly back to [4] rather than emitting messages via [2].

		For the purposes of flow control, we consider the sources of each Readable
		stream to be as follows:

		* [2] receives input from [1]
		* [4] receives input from [1] and [3]

		The classes below express the relationships described above without prescribing
		anything about how parse() and frame() work, other than assuming they emit
		'data' events to the IO and Messages streams. They will work with any protocol
		driver having these two methods.
		**/


		var Stream = require$$0$1.Stream,
		    util   = require$$0$3;


		var IO = function(driver) {
		  this.readable = this.writable = true;
		  this._paused  = false;
		  this._driver  = driver;
		};
		util.inherits(IO, Stream);

		// The IO pause() and resume() methods will be called when the socket we are
		// piping to gets backed up and drains. Since IO output [4] comes from IO input
		// [1] and Messages input [3], we need to tell both of those to return false
		// from write() when this stream is paused.

		IO.prototype.pause = function() {
		  this._paused = true;
		  this._driver.messages._paused = true;
		};

		IO.prototype.resume = function() {
		  this._paused = false;
		  this.emit('drain');

		  var messages = this._driver.messages;
		  messages._paused = false;
		  messages.emit('drain');
		};

		// When we receive input from a socket, send it to the parser and tell the
		// source whether to back off.
		IO.prototype.write = function(chunk) {
		  if (!this.writable) return false;
		  this._driver.parse(chunk);
		  return !this._paused;
		};

		// The IO end() method will be called when the socket piping into it emits
		// 'close' or 'end', i.e. the socket is closed. In this situation the Messages
		// stream will not emit any more data so we emit 'end'.
		IO.prototype.end = function(chunk) {
		  if (!this.writable) return;
		  if (chunk !== undefined) this.write(chunk);
		  this.writable = false;

		  var messages = this._driver.messages;
		  if (messages.readable) {
		    messages.readable = messages.writable = false;
		    messages.emit('end');
		  }
		};

		IO.prototype.destroy = function() {
		  this.end();
		};


		var Messages = function(driver) {
		  this.readable = this.writable = true;
		  this._paused  = false;
		  this._driver  = driver;
		};
		util.inherits(Messages, Stream);

		// The Messages pause() and resume() methods will be called when the app that's
		// processing the messages gets backed up and drains. If we're emitting
		// messages too fast we should tell the source to slow down. Message output [2]
		// comes from IO input [1].

		Messages.prototype.pause = function() {
		  this._driver.io._paused = true;
		};

		Messages.prototype.resume = function() {
		  this._driver.io._paused = false;
		  this._driver.io.emit('drain');
		};

		// When we receive messages from the user, send them to the formatter and tell
		// the source whether to back off.
		Messages.prototype.write = function(message) {
		  if (!this.writable) return false;
		  if (typeof message === 'string') this._driver.text(message);
		  else this._driver.binary(message);
		  return !this._paused;
		};

		// The Messages end() method will be called when a stream piping into it emits
		// 'end'. Many streams may be piped into the WebSocket and one of them ending
		// does not mean the whole socket is done, so just process the input and move
		// on leaving the socket open.
		Messages.prototype.end = function(message) {
		  if (message !== undefined) this.write(message);
		};

		Messages.prototype.destroy = function() {};


		streams.IO = IO;
		streams.Messages = Messages;
		return streams;
	}

	var headers;
	var hasRequiredHeaders;

	function requireHeaders () {
		if (hasRequiredHeaders) return headers;
		hasRequiredHeaders = 1;

		var Headers = function() {
		  this.clear();
		};

		Headers.prototype.ALLOWED_DUPLICATES = ['set-cookie', 'set-cookie2', 'warning', 'www-authenticate'];

		Headers.prototype.clear = function() {
		  this._sent  = {};
		  this._lines = [];
		};

		Headers.prototype.set = function(name, value) {
		  if (value === undefined) return;

		  name = this._strip(name);
		  value = this._strip(value);

		  var key = name.toLowerCase();
		  if (!this._sent.hasOwnProperty(key) || this.ALLOWED_DUPLICATES.indexOf(key) >= 0) {
		    this._sent[key] = true;
		    this._lines.push(name + ': ' + value + '\r\n');
		  }
		};

		Headers.prototype.toString = function() {
		  return this._lines.join('');
		};

		Headers.prototype._strip = function(string) {
		  return string.toString().replace(/^ */, '').replace(/ *$/, '');
		};

		headers = Headers;
		return headers;
	}

	var stream_reader;
	var hasRequiredStream_reader;

	function requireStream_reader () {
		if (hasRequiredStream_reader) return stream_reader;
		hasRequiredStream_reader = 1;

		var Buffer = requireSafeBuffer().Buffer;

		var StreamReader = function() {
		  this._queue     = [];
		  this._queueSize = 0;
		  this._offset    = 0;
		};

		StreamReader.prototype.put = function(buffer) {
		  if (!buffer || buffer.length === 0) return;
		  if (!Buffer.isBuffer(buffer)) buffer = Buffer.from(buffer);
		  this._queue.push(buffer);
		  this._queueSize += buffer.length;
		};

		StreamReader.prototype.read = function(length) {
		  if (length > this._queueSize) return null;
		  if (length === 0) return Buffer.alloc(0);

		  this._queueSize -= length;

		  var queue  = this._queue,
		      remain = length,
		      first  = queue[0],
		      buffers, buffer;

		  if (first.length >= length) {
		    if (first.length === length) {
		      return queue.shift();
		    } else {
		      buffer = first.slice(0, length);
		      queue[0] = first.slice(length);
		      return buffer;
		    }
		  }

		  for (var i = 0, n = queue.length; i < n; i++) {
		    if (remain < queue[i].length) break;
		    remain -= queue[i].length;
		  }
		  buffers = queue.splice(0, i);

		  if (remain > 0 && queue.length > 0) {
		    buffers.push(queue[0].slice(0, remain));
		    queue[0] = queue[0].slice(remain);
		  }
		  return Buffer.concat(buffers, length);
		};

		StreamReader.prototype.eachByte = function(callback, context) {
		  var buffer, n, index;

		  while (this._queue.length > 0) {
		    buffer = this._queue[0];
		    n = buffer.length;

		    while (this._offset < n) {
		      index = this._offset;
		      this._offset += 1;
		      callback.call(context, buffer[index]);
		    }
		    this._offset = 0;
		    this._queue.shift();
		  }
		};

		stream_reader = StreamReader;
		return stream_reader;
	}

	var base;
	var hasRequiredBase;

	function requireBase () {
		if (hasRequiredBase) return base;
		hasRequiredBase = 1;

		var Buffer  = requireSafeBuffer().Buffer,
		    Emitter = require$$0$4.EventEmitter,
		    util    = require$$0$3,
		    streams = requireStreams(),
		    Headers = requireHeaders(),
		    Reader  = requireStream_reader();

		var Base = function(request, url, options) {
		  Emitter.call(this);
		  Base.validateOptions(options || {}, ['maxLength', 'masking', 'requireMasking', 'protocols']);

		  this._request   = request;
		  this._reader    = new Reader();
		  this._options   = options || {};
		  this._maxLength = this._options.maxLength || this.MAX_LENGTH;
		  this._headers   = new Headers();
		  this.__queue    = [];
		  this.readyState = 0;
		  this.url        = url;

		  this.io = new streams.IO(this);
		  this.messages = new streams.Messages(this);
		  this._bindEventListeners();
		};
		util.inherits(Base, Emitter);

		Base.isWebSocket = function(request) {
		  var connection = request.headers.connection || '',
		      upgrade    = request.headers.upgrade || '';

		  return request.method === 'GET' &&
		         connection.toLowerCase().split(/ *, */).indexOf('upgrade') >= 0 &&
		         upgrade.toLowerCase() === 'websocket';
		};

		Base.validateOptions = function(options, validKeys) {
		  for (var key in options) {
		    if (validKeys.indexOf(key) < 0)
		      throw new Error('Unrecognized option: ' + key);
		  }
		};

		var instance = {
		  // This is 64MB, small enough for an average VPS to handle without
		  // crashing from process out of memory
		  MAX_LENGTH: 0x3ffffff,

		  STATES: ['connecting', 'open', 'closing', 'closed'],

		  _bindEventListeners: function() {
		    var self = this;

		    // Protocol errors are informational and do not have to be handled
		    this.messages.on('error', function() {});

		    this.on('message', function(event) {
		      var messages = self.messages;
		      if (messages.readable) messages.emit('data', event.data);
		    });

		    this.on('error', function(error) {
		      var messages = self.messages;
		      if (messages.readable) messages.emit('error', error);
		    });

		    this.on('close', function() {
		      var messages = self.messages;
		      if (!messages.readable) return;
		      messages.readable = messages.writable = false;
		      messages.emit('end');
		    });
		  },

		  getState: function() {
		    return this.STATES[this.readyState] || null;
		  },

		  addExtension: function(extension) {
		    return false;
		  },

		  setHeader: function(name, value) {
		    if (this.readyState > 0) return false;
		    this._headers.set(name, value);
		    return true;
		  },

		  start: function() {
		    if (this.readyState !== 0) return false;

		    if (!Base.isWebSocket(this._request))
		      return this._failHandshake(new Error('Not a WebSocket request'));

		    var response;

		    try {
		      response = this._handshakeResponse();
		    } catch (error) {
		      return this._failHandshake(error);
		    }

		    this._write(response);
		    if (this._stage !== -1) this._open();
		    return true;
		  },

		  _failHandshake: function(error) {
		    var headers = new Headers();
		    headers.set('Content-Type', 'text/plain');
		    headers.set('Content-Length', Buffer.byteLength(error.message, 'utf8'));

		    headers = ['HTTP/1.1 400 Bad Request', headers.toString(), error.message];
		    this._write(Buffer.from(headers.join('\r\n'), 'utf8'));
		    this._fail('protocol_error', error.message);

		    return false;
		  },

		  text: function(message) {
		    return this.frame(message);
		  },

		  binary: function(message) {
		    return false;
		  },

		  ping: function() {
		    return false;
		  },

		  pong: function() {
		      return false;
		  },

		  close: function(reason, code) {
		    if (this.readyState !== 1) return false;
		    this.readyState = 3;
		    this.emit('close', new Base.CloseEvent(null, null));
		    return true;
		  },

		  _open: function() {
		    this.readyState = 1;
		    this.__queue.forEach(function(args) { this.frame.apply(this, args); }, this);
		    this.__queue = [];
		    this.emit('open', new Base.OpenEvent());
		  },

		  _queue: function(message) {
		    this.__queue.push(message);
		    return true;
		  },

		  _write: function(chunk) {
		    var io = this.io;
		    if (io.readable) io.emit('data', chunk);
		  },

		  _fail: function(type, message) {
		    this.readyState = 2;
		    this.emit('error', new Error(message));
		    this.close();
		  }
		};

		for (var key in instance)
		  Base.prototype[key] = instance[key];


		Base.ConnectEvent = function() {};

		Base.OpenEvent = function() {};

		Base.CloseEvent = function(code, reason) {
		  this.code   = code;
		  this.reason = reason;
		};

		Base.MessageEvent = function(data) {
		  this.data = data;
		};

		Base.PingEvent = function(data) {
		  this.data = data;
		};

		Base.PongEvent = function(data) {
		  this.data = data;
		};

		base = Base;
		return base;
	}

	var httpParser = {};

	function compare(a, b) {
	  if (a === b) {
	    return 0;
	  }

	  var x = a.length;
	  var y = b.length;

	  for (var i = 0, len = Math.min(x, y); i < len; ++i) {
	    if (a[i] !== b[i]) {
	      x = a[i];
	      y = b[i];
	      break;
	    }
	  }

	  if (x < y) {
	    return -1;
	  }
	  if (y < x) {
	    return 1;
	  }
	  return 0;
	}
	var hasOwn = Object.prototype.hasOwnProperty;

	var objectKeys = Object.keys || function (obj) {
	  var keys = [];
	  for (var key in obj) {
	    if (hasOwn.call(obj, key)) keys.push(key);
	  }
	  return keys;
	};
	var pSlice = Array.prototype.slice;
	var _functionsHaveNames;
	function functionsHaveNames() {
	  if (typeof _functionsHaveNames !== 'undefined') {
	    return _functionsHaveNames;
	  }
	  return _functionsHaveNames = (function () {
	    return function foo() {}.name === 'foo';
	  }());
	}
	function pToString (obj) {
	  return Object.prototype.toString.call(obj);
	}
	function isView(arrbuf) {
	  if (isBuffer(arrbuf)) {
	    return false;
	  }
	  if (typeof global.ArrayBuffer !== 'function') {
	    return false;
	  }
	  if (typeof ArrayBuffer.isView === 'function') {
	    return ArrayBuffer.isView(arrbuf);
	  }
	  if (!arrbuf) {
	    return false;
	  }
	  if (arrbuf instanceof DataView) {
	    return true;
	  }
	  if (arrbuf.buffer && arrbuf.buffer instanceof ArrayBuffer) {
	    return true;
	  }
	  return false;
	}
	// 1. The assert module provides functions that throw
	// AssertionError's when particular conditions are not met. The
	// assert module must conform to the following interface.

	function assert(value, message) {
	  if (!value) fail(value, true, message, '==', ok);
	}

	// 2. The AssertionError is defined in assert.
	// new assert.AssertionError({ message: message,
	//                             actual: actual,
	//                             expected: expected })

	var regex = /\s*function\s+([^\(\s]*)\s*/;
	// based on https://github.com/ljharb/function.prototype.name/blob/adeeeec8bfcc6068b187d7d9fb3d5bb1d3a30899/implementation.js
	function getName(func) {
	  if (!isFunction$1(func)) {
	    return;
	  }
	  if (functionsHaveNames()) {
	    return func.name;
	  }
	  var str = func.toString();
	  var match = str.match(regex);
	  return match && match[1];
	}
	assert.AssertionError = AssertionError;
	function AssertionError(options) {
	  this.name = 'AssertionError';
	  this.actual = options.actual;
	  this.expected = options.expected;
	  this.operator = options.operator;
	  if (options.message) {
	    this.message = options.message;
	    this.generatedMessage = false;
	  } else {
	    this.message = getMessage(this);
	    this.generatedMessage = true;
	  }
	  var stackStartFunction = options.stackStartFunction || fail;
	  if (Error.captureStackTrace) {
	    Error.captureStackTrace(this, stackStartFunction);
	  } else {
	    // non v8 browsers so we can have a stacktrace
	    var err = new Error();
	    if (err.stack) {
	      var out = err.stack;

	      // try to strip useless frames
	      var fn_name = getName(stackStartFunction);
	      var idx = out.indexOf('\n' + fn_name);
	      if (idx >= 0) {
	        // once we have located the function frame
	        // we need to strip out everything before it (and its line)
	        var next_line = out.indexOf('\n', idx + 1);
	        out = out.substring(next_line + 1);
	      }

	      this.stack = out;
	    }
	  }
	}

	// assert.AssertionError instanceof Error
	inherits$1(AssertionError, Error);

	function truncate(s, n) {
	  if (typeof s === 'string') {
	    return s.length < n ? s : s.slice(0, n);
	  } else {
	    return s;
	  }
	}
	function inspect(something) {
	  if (functionsHaveNames() || !isFunction$1(something)) {
	    return inspect$1(something);
	  }
	  var rawname = getName(something);
	  var name = rawname ? ': ' + rawname : '';
	  return '[Function' +  name + ']';
	}
	function getMessage(self) {
	  return truncate(inspect(self.actual), 128) + ' ' +
	         self.operator + ' ' +
	         truncate(inspect(self.expected), 128);
	}

	// At present only the three keys mentioned above are used and
	// understood by the spec. Implementations or sub modules can pass
	// other keys to the AssertionError's constructor - they will be
	// ignored.

	// 3. All of the following functions must throw an AssertionError
	// when a corresponding condition is not met, with a message that
	// may be undefined if not provided.  All assertion methods provide
	// both the actual and expected values to the assertion error for
	// display purposes.

	function fail(actual, expected, message, operator, stackStartFunction) {
	  throw new AssertionError({
	    message: message,
	    actual: actual,
	    expected: expected,
	    operator: operator,
	    stackStartFunction: stackStartFunction
	  });
	}

	// EXTENSION! allows for well behaved errors defined elsewhere.
	assert.fail = fail;

	// 4. Pure assertion tests whether a value is truthy, as determined
	// by !!guard.
	// assert.ok(guard, message_opt);
	// This statement is equivalent to assert.equal(true, !!guard,
	// message_opt);. To test strictly for the value true, use
	// assert.strictEqual(true, guard, message_opt);.

	function ok(value, message) {
	  if (!value) fail(value, true, message, '==', ok);
	}
	assert.ok = ok;

	// 5. The equality assertion tests shallow, coercive equality with
	// ==.
	// assert.equal(actual, expected, message_opt);
	assert.equal = equal;
	function equal(actual, expected, message) {
	  if (actual != expected) fail(actual, expected, message, '==', equal);
	}

	// 6. The non-equality assertion tests for whether two objects are not equal
	// with != assert.notEqual(actual, expected, message_opt);
	assert.notEqual = notEqual;
	function notEqual(actual, expected, message) {
	  if (actual == expected) {
	    fail(actual, expected, message, '!=', notEqual);
	  }
	}

	// 7. The equivalence assertion tests a deep equality relation.
	// assert.deepEqual(actual, expected, message_opt);
	assert.deepEqual = deepEqual;
	function deepEqual(actual, expected, message) {
	  if (!_deepEqual(actual, expected, false)) {
	    fail(actual, expected, message, 'deepEqual', deepEqual);
	  }
	}
	assert.deepStrictEqual = deepStrictEqual;
	function deepStrictEqual(actual, expected, message) {
	  if (!_deepEqual(actual, expected, true)) {
	    fail(actual, expected, message, 'deepStrictEqual', deepStrictEqual);
	  }
	}

	function _deepEqual(actual, expected, strict, memos) {
	  // 7.1. All identical values are equivalent, as determined by ===.
	  if (actual === expected) {
	    return true;
	  } else if (isBuffer(actual) && isBuffer(expected)) {
	    return compare(actual, expected) === 0;

	  // 7.2. If the expected value is a Date object, the actual value is
	  // equivalent if it is also a Date object that refers to the same time.
	  } else if (isDate(actual) && isDate(expected)) {
	    return actual.getTime() === expected.getTime();

	  // 7.3 If the expected value is a RegExp object, the actual value is
	  // equivalent if it is also a RegExp object with the same source and
	  // properties (`global`, `multiline`, `lastIndex`, `ignoreCase`).
	  } else if (isRegExp(actual) && isRegExp(expected)) {
	    return actual.source === expected.source &&
	           actual.global === expected.global &&
	           actual.multiline === expected.multiline &&
	           actual.lastIndex === expected.lastIndex &&
	           actual.ignoreCase === expected.ignoreCase;

	  // 7.4. Other pairs that do not both pass typeof value == 'object',
	  // equivalence is determined by ==.
	  } else if ((actual === null || typeof actual !== 'object') &&
	             (expected === null || typeof expected !== 'object')) {
	    return strict ? actual === expected : actual == expected;

	  // If both values are instances of typed arrays, wrap their underlying
	  // ArrayBuffers in a Buffer each to increase performance
	  // This optimization requires the arrays to have the same type as checked by
	  // Object.prototype.toString (aka pToString). Never perform binary
	  // comparisons for Float*Arrays, though, since e.g. +0 === -0 but their
	  // bit patterns are not identical.
	  } else if (isView(actual) && isView(expected) &&
	             pToString(actual) === pToString(expected) &&
	             !(actual instanceof Float32Array ||
	               actual instanceof Float64Array)) {
	    return compare(new Uint8Array(actual.buffer),
	                   new Uint8Array(expected.buffer)) === 0;

	  // 7.5 For all other Object pairs, including Array objects, equivalence is
	  // determined by having the same number of owned properties (as verified
	  // with Object.prototype.hasOwnProperty.call), the same set of keys
	  // (although not necessarily the same order), equivalent values for every
	  // corresponding key, and an identical 'prototype' property. Note: this
	  // accounts for both named and indexed properties on Arrays.
	  } else if (isBuffer(actual) !== isBuffer(expected)) {
	    return false;
	  } else {
	    memos = memos || {actual: [], expected: []};

	    var actualIndex = memos.actual.indexOf(actual);
	    if (actualIndex !== -1) {
	      if (actualIndex === memos.expected.indexOf(expected)) {
	        return true;
	      }
	    }

	    memos.actual.push(actual);
	    memos.expected.push(expected);

	    return objEquiv(actual, expected, strict, memos);
	  }
	}

	function isArguments(object) {
	  return Object.prototype.toString.call(object) == '[object Arguments]';
	}

	function objEquiv(a, b, strict, actualVisitedObjects) {
	  if (a === null || a === undefined || b === null || b === undefined)
	    return false;
	  // if one is a primitive, the other must be same
	  if (isPrimitive(a) || isPrimitive(b))
	    return a === b;
	  if (strict && Object.getPrototypeOf(a) !== Object.getPrototypeOf(b))
	    return false;
	  var aIsArgs = isArguments(a);
	  var bIsArgs = isArguments(b);
	  if ((aIsArgs && !bIsArgs) || (!aIsArgs && bIsArgs))
	    return false;
	  if (aIsArgs) {
	    a = pSlice.call(a);
	    b = pSlice.call(b);
	    return _deepEqual(a, b, strict);
	  }
	  var ka = objectKeys(a);
	  var kb = objectKeys(b);
	  var key, i;
	  // having the same number of owned properties (keys incorporates
	  // hasOwnProperty)
	  if (ka.length !== kb.length)
	    return false;
	  //the same set of keys (although not necessarily the same order),
	  ka.sort();
	  kb.sort();
	  //~~~cheap key test
	  for (i = ka.length - 1; i >= 0; i--) {
	    if (ka[i] !== kb[i])
	      return false;
	  }
	  //equivalent values for every corresponding key, and
	  //~~~possibly expensive deep test
	  for (i = ka.length - 1; i >= 0; i--) {
	    key = ka[i];
	    if (!_deepEqual(a[key], b[key], strict, actualVisitedObjects))
	      return false;
	  }
	  return true;
	}

	// 8. The non-equivalence assertion tests for any deep inequality.
	// assert.notDeepEqual(actual, expected, message_opt);
	assert.notDeepEqual = notDeepEqual;
	function notDeepEqual(actual, expected, message) {
	  if (_deepEqual(actual, expected, false)) {
	    fail(actual, expected, message, 'notDeepEqual', notDeepEqual);
	  }
	}

	assert.notDeepStrictEqual = notDeepStrictEqual;
	function notDeepStrictEqual(actual, expected, message) {
	  if (_deepEqual(actual, expected, true)) {
	    fail(actual, expected, message, 'notDeepStrictEqual', notDeepStrictEqual);
	  }
	}


	// 9. The strict equality assertion tests strict equality, as determined by ===.
	// assert.strictEqual(actual, expected, message_opt);
	assert.strictEqual = strictEqual;
	function strictEqual(actual, expected, message) {
	  if (actual !== expected) {
	    fail(actual, expected, message, '===', strictEqual);
	  }
	}

	// 10. The strict non-equality assertion tests for strict inequality, as
	// determined by !==.  assert.notStrictEqual(actual, expected, message_opt);
	assert.notStrictEqual = notStrictEqual;
	function notStrictEqual(actual, expected, message) {
	  if (actual === expected) {
	    fail(actual, expected, message, '!==', notStrictEqual);
	  }
	}

	function expectedException(actual, expected) {
	  if (!actual || !expected) {
	    return false;
	  }

	  if (Object.prototype.toString.call(expected) == '[object RegExp]') {
	    return expected.test(actual);
	  }

	  try {
	    if (actual instanceof expected) {
	      return true;
	    }
	  } catch (e) {
	    // Ignore.  The instanceof check doesn't work for arrow functions.
	  }

	  if (Error.isPrototypeOf(expected)) {
	    return false;
	  }

	  return expected.call({}, actual) === true;
	}

	function _tryBlock(block) {
	  var error;
	  try {
	    block();
	  } catch (e) {
	    error = e;
	  }
	  return error;
	}

	function _throws(shouldThrow, block, expected, message) {
	  var actual;

	  if (typeof block !== 'function') {
	    throw new TypeError('"block" argument must be a function');
	  }

	  if (typeof expected === 'string') {
	    message = expected;
	    expected = null;
	  }

	  actual = _tryBlock(block);

	  message = (expected && expected.name ? ' (' + expected.name + ').' : '.') +
	            (message ? ' ' + message : '.');

	  if (shouldThrow && !actual) {
	    fail(actual, expected, 'Missing expected exception' + message);
	  }

	  var userProvidedMessage = typeof message === 'string';
	  var isUnwantedException = !shouldThrow && isError(actual);
	  var isUnexpectedException = !shouldThrow && actual && !expected;

	  if ((isUnwantedException &&
	      userProvidedMessage &&
	      expectedException(actual, expected)) ||
	      isUnexpectedException) {
	    fail(actual, expected, 'Got unwanted exception' + message);
	  }

	  if ((shouldThrow && actual && expected &&
	      !expectedException(actual, expected)) || (!shouldThrow && actual)) {
	    throw actual;
	  }
	}

	// 11. Expected to throw an error:
	// assert.throws(block, Error_opt, message_opt);
	assert.throws = throws;
	function throws(block, /*optional*/error, /*optional*/message) {
	  _throws(true, block, error, message);
	}

	// EXTENSION! This is annoying to write outside this module.
	assert.doesNotThrow = doesNotThrow;
	function doesNotThrow(block, /*optional*/error, /*optional*/message) {
	  _throws(false, block, error, message);
	}

	assert.ifError = ifError;
	function ifError(err) {
	  if (err) throw err;
	}

	var assert$1 = /*#__PURE__*/Object.freeze({
		__proto__: null,
		AssertionError: AssertionError,
		assert: ok,
		deepEqual: deepEqual,
		deepStrictEqual: deepStrictEqual,
		default: assert,
		doesNotThrow: doesNotThrow,
		equal: equal,
		fail: fail,
		ifError: ifError,
		notDeepEqual: notDeepEqual,
		notDeepStrictEqual: notDeepStrictEqual,
		notEqual: notEqual,
		notStrictEqual: notStrictEqual,
		ok: ok,
		strictEqual: strictEqual,
		throws: throws
	});

	var require$$0 = /*@__PURE__*/getAugmentedNamespace(assert$1);

	/*jshint node:true */

	var hasRequiredHttpParser;

	function requireHttpParser () {
		if (hasRequiredHttpParser) return httpParser;
		hasRequiredHttpParser = 1;
		var assert = require$$0;

		httpParser.HTTPParser = HTTPParser;
		function HTTPParser(type) {
		  assert.ok(type === HTTPParser.REQUEST || type === HTTPParser.RESPONSE || type === undefined);
		  if (type === undefined) ; else {
		    this.initialize(type);
		  }
		}
		HTTPParser.prototype.initialize = function (type, async_resource) {
		  assert.ok(type === HTTPParser.REQUEST || type === HTTPParser.RESPONSE);
		  this.type = type;
		  this.state = type + '_LINE';
		  this.info = {
		    headers: [],
		    upgrade: false
		  };
		  this.trailers = [];
		  this.line = '';
		  this.isChunked = false;
		  this.connection = '';
		  this.headerSize = 0; // for preventing too big headers
		  this.body_bytes = null;
		  this.isUserCall = false;
		  this.hadError = false;
		};

		HTTPParser.encoding = 'ascii';
		HTTPParser.maxHeaderSize = 80 * 1024; // maxHeaderSize (in bytes) is configurable, but 80kb by default;
		HTTPParser.REQUEST = 'REQUEST';
		HTTPParser.RESPONSE = 'RESPONSE';

		// Note: *not* starting with kOnHeaders=0 line the Node parser, because any
		//   newly added constants (kOnTimeout in Node v12.19.0) will overwrite 0!
		var kOnHeaders = HTTPParser.kOnHeaders = 1;
		var kOnHeadersComplete = HTTPParser.kOnHeadersComplete = 2;
		var kOnBody = HTTPParser.kOnBody = 3;
		var kOnMessageComplete = HTTPParser.kOnMessageComplete = 4;

		// Some handler stubs, needed for compatibility
		HTTPParser.prototype[kOnHeaders] =
		HTTPParser.prototype[kOnHeadersComplete] =
		HTTPParser.prototype[kOnBody] =
		HTTPParser.prototype[kOnMessageComplete] = function () {};

		var compatMode0_12 = true;
		Object.defineProperty(HTTPParser, 'kOnExecute', {
		    get: function () {
		      // hack for backward compatibility
		      compatMode0_12 = false;
		      return 99;
		    }
		  });

		var methods = httpParser.methods = HTTPParser.methods = [
		  'DELETE',
		  'GET',
		  'HEAD',
		  'POST',
		  'PUT',
		  'CONNECT',
		  'OPTIONS',
		  'TRACE',
		  'COPY',
		  'LOCK',
		  'MKCOL',
		  'MOVE',
		  'PROPFIND',
		  'PROPPATCH',
		  'SEARCH',
		  'UNLOCK',
		  'BIND',
		  'REBIND',
		  'UNBIND',
		  'ACL',
		  'REPORT',
		  'MKACTIVITY',
		  'CHECKOUT',
		  'MERGE',
		  'M-SEARCH',
		  'NOTIFY',
		  'SUBSCRIBE',
		  'UNSUBSCRIBE',
		  'PATCH',
		  'PURGE',
		  'MKCALENDAR',
		  'LINK',
		  'UNLINK'
		];
		var method_connect = methods.indexOf('CONNECT');
		HTTPParser.prototype.reinitialize = HTTPParser;
		HTTPParser.prototype.close =
		HTTPParser.prototype.pause =
		HTTPParser.prototype.resume =
		HTTPParser.prototype.free = function () {};
		HTTPParser.prototype._compatMode0_11 = false;
		HTTPParser.prototype.getAsyncId = function() { return 0; };

		var headerState = {
		  REQUEST_LINE: true,
		  RESPONSE_LINE: true,
		  HEADER: true
		};
		HTTPParser.prototype.execute = function (chunk, start, length) {
		  if (!(this instanceof HTTPParser)) {
		    throw new TypeError('not a HTTPParser');
		  }

		  // backward compat to node < 0.11.4
		  // Note: the start and length params were removed in newer version
		  start = start || 0;
		  length = typeof length === 'number' ? length : chunk.length;

		  this.chunk = chunk;
		  this.offset = start;
		  var end = this.end = start + length;
		  try {
		    while (this.offset < end) {
		      if (this[this.state]()) {
		        break;
		      }
		    }
		  } catch (err) {
		    if (this.isUserCall) {
		      throw err;
		    }
		    this.hadError = true;
		    return err;
		  }
		  this.chunk = null;
		  length = this.offset - start;
		  if (headerState[this.state]) {
		    this.headerSize += length;
		    if (this.headerSize > HTTPParser.maxHeaderSize) {
		      return new Error('max header size exceeded');
		    }
		  }
		  return length;
		};

		var stateFinishAllowed = {
		  REQUEST_LINE: true,
		  RESPONSE_LINE: true,
		  BODY_RAW: true
		};
		HTTPParser.prototype.finish = function () {
		  if (this.hadError) {
		    return;
		  }
		  if (!stateFinishAllowed[this.state]) {
		    return new Error('invalid state for EOF');
		  }
		  if (this.state === 'BODY_RAW') {
		    this.userCall()(this[kOnMessageComplete]());
		  }
		};

		// These three methods are used for an internal speed optimization, and it also
		// works if theses are noops. Basically consume() asks us to read the bytes
		// ourselves, but if we don't do it we get them through execute().
		HTTPParser.prototype.consume =
		HTTPParser.prototype.unconsume =
		HTTPParser.prototype.getCurrentBuffer = function () {};

		//For correct error handling - see HTTPParser#execute
		//Usage: this.userCall()(userFunction('arg'));
		HTTPParser.prototype.userCall = function () {
		  this.isUserCall = true;
		  var self = this;
		  return function (ret) {
		    self.isUserCall = false;
		    return ret;
		  };
		};

		HTTPParser.prototype.nextRequest = function () {
		  this.userCall()(this[kOnMessageComplete]());
		  this.reinitialize(this.type);
		};

		HTTPParser.prototype.consumeLine = function () {
		  var end = this.end,
		      chunk = this.chunk;
		  for (var i = this.offset; i < end; i++) {
		    if (chunk[i] === 0x0a) { // \n
		      var line = this.line + chunk.toString(HTTPParser.encoding, this.offset, i);
		      if (line.charAt(line.length - 1) === '\r') {
		        line = line.substr(0, line.length - 1);
		      }
		      this.line = '';
		      this.offset = i + 1;
		      return line;
		    }
		  }
		  //line split over multiple chunks
		  this.line += chunk.toString(HTTPParser.encoding, this.offset, this.end);
		  this.offset = this.end;
		};

		var headerExp = /^([^: \t]+):[ \t]*((?:.*[^ \t])|)/;
		var headerContinueExp = /^[ \t]+(.*[^ \t])/;
		HTTPParser.prototype.parseHeader = function (line, headers) {
		  if (line.indexOf('\r') !== -1) {
		    throw parseErrorCode('HPE_LF_EXPECTED');
		  }

		  var match = headerExp.exec(line);
		  var k = match && match[1];
		  if (k) { // skip empty string (malformed header)
		    headers.push(k);
		    headers.push(match[2]);
		  } else {
		    var matchContinue = headerContinueExp.exec(line);
		    if (matchContinue && headers.length) {
		      if (headers[headers.length - 1]) {
		        headers[headers.length - 1] += ' ';
		      }
		      headers[headers.length - 1] += matchContinue[1];
		    }
		  }
		};

		var requestExp = /^([A-Z-]+) ([^ ]+) HTTP\/(\d)\.(\d)$/;
		HTTPParser.prototype.REQUEST_LINE = function () {
		  var line = this.consumeLine();
		  if (!line) {
		    return;
		  }
		  var match = requestExp.exec(line);
		  if (match === null) {
		    throw parseErrorCode('HPE_INVALID_CONSTANT');
		  }
		  this.info.method = this._compatMode0_11 ? match[1] : methods.indexOf(match[1]);
		  if (this.info.method === -1) {
		    throw new Error('invalid request method');
		  }
		  this.info.url = match[2];
		  this.info.versionMajor = +match[3];
		  this.info.versionMinor = +match[4];
		  this.body_bytes = 0;
		  this.state = 'HEADER';
		};

		var responseExp = /^HTTP\/(\d)\.(\d) (\d{3}) ?(.*)$/;
		HTTPParser.prototype.RESPONSE_LINE = function () {
		  var line = this.consumeLine();
		  if (!line) {
		    return;
		  }
		  var match = responseExp.exec(line);
		  if (match === null) {
		    throw parseErrorCode('HPE_INVALID_CONSTANT');
		  }
		  this.info.versionMajor = +match[1];
		  this.info.versionMinor = +match[2];
		  var statusCode = this.info.statusCode = +match[3];
		  this.info.statusMessage = match[4];
		  // Implied zero length.
		  if ((statusCode / 100 | 0) === 1 || statusCode === 204 || statusCode === 304) {
		    this.body_bytes = 0;
		  }
		  this.state = 'HEADER';
		};

		HTTPParser.prototype.shouldKeepAlive = function () {
		  if (this.info.versionMajor > 0 && this.info.versionMinor > 0) {
		    if (this.connection.indexOf('close') !== -1) {
		      return false;
		    }
		  } else if (this.connection.indexOf('keep-alive') === -1) {
		    return false;
		  }
		  if (this.body_bytes !== null || this.isChunked) { // || skipBody
		    return true;
		  }
		  return false;
		};

		HTTPParser.prototype.HEADER = function () {
		  var line = this.consumeLine();
		  if (line === undefined) {
		    return;
		  }
		  var info = this.info;
		  if (line) {
		    this.parseHeader(line, info.headers);
		  } else {
		    var headers = info.headers;
		    var hasContentLength = false;
		    var currentContentLengthValue;
		    var hasUpgradeHeader = false;
		    for (var i = 0; i < headers.length; i += 2) {
		      switch (headers[i].toLowerCase()) {
		        case 'transfer-encoding':
		          this.isChunked = headers[i + 1].toLowerCase() === 'chunked';
		          break;
		        case 'content-length':
		          currentContentLengthValue = +headers[i + 1];
		          if (hasContentLength) {
		            // Fix duplicate Content-Length header with same values.
		            // Throw error only if values are different.
		            // Known issues:
		            // https://github.com/request/request/issues/2091#issuecomment-328715113
		            // https://github.com/nodejs/node/issues/6517#issuecomment-216263771
		            if (currentContentLengthValue !== this.body_bytes) {
		              throw parseErrorCode('HPE_UNEXPECTED_CONTENT_LENGTH');
		            }
		          } else {
		            hasContentLength = true;
		            this.body_bytes = currentContentLengthValue;
		          }
		          break;
		        case 'connection':
		          this.connection += headers[i + 1].toLowerCase();
		          break;
		        case 'upgrade':
		          hasUpgradeHeader = true;
		          break;
		      }
		    }

		    // if both isChunked and hasContentLength, isChunked wins
		    // This is required so the body is parsed using the chunked method, and matches
		    // Chrome's behavior.  We could, maybe, ignore them both (would get chunked
		    // encoding into the body), and/or disable shouldKeepAlive to be more
		    // resilient.
		    if (this.isChunked && hasContentLength) {
		      hasContentLength = false;
		      this.body_bytes = null;
		    }

		    // Logic from https://github.com/nodejs/http-parser/blob/921d5585515a153fa00e411cf144280c59b41f90/http_parser.c#L1727-L1737
		    // "For responses, "Upgrade: foo" and "Connection: upgrade" are
		    //   mandatory only when it is a 101 Switching Protocols response,
		    //   otherwise it is purely informational, to announce support.
		    if (hasUpgradeHeader && this.connection.indexOf('upgrade') != -1) {
		      info.upgrade = this.type === HTTPParser.REQUEST || info.statusCode === 101;
		    } else {
		      info.upgrade = info.method === method_connect;
		    }

		    if (this.isChunked && info.upgrade) {
		      this.isChunked = false;
		    }

		    info.shouldKeepAlive = this.shouldKeepAlive();
		    //problem which also exists in original node: we should know skipBody before calling onHeadersComplete
		    var skipBody;
		    if (compatMode0_12) {
		      skipBody = this.userCall()(this[kOnHeadersComplete](info));
		    } else {
		      skipBody = this.userCall()(this[kOnHeadersComplete](info.versionMajor,
		          info.versionMinor, info.headers, info.method, info.url, info.statusCode,
		          info.statusMessage, info.upgrade, info.shouldKeepAlive));
		    }
		    if (skipBody === 2) {
		      this.nextRequest();
		      return true;
		    } else if (this.isChunked && !skipBody) {
		      this.state = 'BODY_CHUNKHEAD';
		    } else if (skipBody || this.body_bytes === 0) {
		      this.nextRequest();
		      // For older versions of node (v6.x and older?), that return skipBody=1 or skipBody=true,
		      //   need this "return true;" if it's an upgrade request.
		      return info.upgrade;
		    } else if (this.body_bytes === null) {
		      this.state = 'BODY_RAW';
		    } else {
		      this.state = 'BODY_SIZED';
		    }
		  }
		};

		HTTPParser.prototype.BODY_CHUNKHEAD = function () {
		  var line = this.consumeLine();
		  if (line === undefined) {
		    return;
		  }
		  this.body_bytes = parseInt(line, 16);
		  if (!this.body_bytes) {
		    this.state = 'BODY_CHUNKTRAILERS';
		  } else {
		    this.state = 'BODY_CHUNK';
		  }
		};

		HTTPParser.prototype.BODY_CHUNK = function () {
		  var length = Math.min(this.end - this.offset, this.body_bytes);
		  this.userCall()(this[kOnBody](this.chunk, this.offset, length));
		  this.offset += length;
		  this.body_bytes -= length;
		  if (!this.body_bytes) {
		    this.state = 'BODY_CHUNKEMPTYLINE';
		  }
		};

		HTTPParser.prototype.BODY_CHUNKEMPTYLINE = function () {
		  var line = this.consumeLine();
		  if (line === undefined) {
		    return;
		  }
		  assert.equal(line, '');
		  this.state = 'BODY_CHUNKHEAD';
		};

		HTTPParser.prototype.BODY_CHUNKTRAILERS = function () {
		  var line = this.consumeLine();
		  if (line === undefined) {
		    return;
		  }
		  if (line) {
		    this.parseHeader(line, this.trailers);
		  } else {
		    if (this.trailers.length) {
		      this.userCall()(this[kOnHeaders](this.trailers, ''));
		    }
		    this.nextRequest();
		  }
		};

		HTTPParser.prototype.BODY_RAW = function () {
		  var length = this.end - this.offset;
		  this.userCall()(this[kOnBody](this.chunk, this.offset, length));
		  this.offset = this.end;
		};

		HTTPParser.prototype.BODY_SIZED = function () {
		  var length = Math.min(this.end - this.offset, this.body_bytes);
		  this.userCall()(this[kOnBody](this.chunk, this.offset, length));
		  this.offset += length;
		  this.body_bytes -= length;
		  if (!this.body_bytes) {
		    this.nextRequest();
		  }
		};

		// backward compat to node < 0.11.6
		['Headers', 'HeadersComplete', 'Body', 'MessageComplete'].forEach(function (name) {
		  var k = HTTPParser['kOn' + name];
		  Object.defineProperty(HTTPParser.prototype, 'on' + name, {
		    get: function () {
		      return this[k];
		    },
		    set: function (to) {
		      // hack for backward compatibility
		      this._compatMode0_11 = true;
		      method_connect = 'CONNECT';
		      return (this[k] = to);
		    }
		  });
		});

		function parseErrorCode(code) {
		  var err = new Error('Parse Error');
		  err.code = code;
		  return err;
		}
		return httpParser;
	}

	var http_parser;
	var hasRequiredHttp_parser;

	function requireHttp_parser () {
		if (hasRequiredHttp_parser) return http_parser;
		hasRequiredHttp_parser = 1;

		var NodeHTTPParser = requireHttpParser().HTTPParser,
		    Buffer         = requireSafeBuffer().Buffer;

		var TYPES = {
		  request:  NodeHTTPParser.REQUEST  || 'request',
		  response: NodeHTTPParser.RESPONSE || 'response'
		};

		var HttpParser = function(type) {
		  this._type     = type;
		  this._parser   = new NodeHTTPParser(TYPES[type]);
		  this._complete = false;
		  this.headers   = {};

		  var current = null,
		      self    = this;

		  this._parser.onHeaderField = function(b, start, length) {
		    current = b.toString('utf8', start, start + length).toLowerCase();
		  };

		  this._parser.onHeaderValue = function(b, start, length) {
		    var value = b.toString('utf8', start, start + length);

		    if (self.headers.hasOwnProperty(current))
		      self.headers[current] += ', ' + value;
		    else
		      self.headers[current] = value;
		  };

		  this._parser.onHeadersComplete = this._parser[NodeHTTPParser.kOnHeadersComplete] =
		  function(majorVersion, minorVersion, headers, method, pathname, statusCode) {
		    var info = arguments[0];

		    if (typeof info === 'object') {
		      method     = info.method;
		      pathname   = info.url;
		      statusCode = info.statusCode;
		      headers    = info.headers;
		    }

		    self.method     = (typeof method === 'number') ? HttpParser.METHODS[method] : method;
		    self.statusCode = statusCode;
		    self.url        = pathname;

		    if (!headers) return;

		    for (var i = 0, n = headers.length, key, value; i < n; i += 2) {
		      key   = headers[i].toLowerCase();
		      value = headers[i+1];
		      if (self.headers.hasOwnProperty(key))
		        self.headers[key] += ', ' + value;
		      else
		        self.headers[key] = value;
		    }

		    self._complete = true;
		  };
		};

		HttpParser.METHODS = {
		  0:  'DELETE',
		  1:  'GET',
		  2:  'HEAD',
		  3:  'POST',
		  4:  'PUT',
		  5:  'CONNECT',
		  6:  'OPTIONS',
		  7:  'TRACE',
		  8:  'COPY',
		  9:  'LOCK',
		  10: 'MKCOL',
		  11: 'MOVE',
		  12: 'PROPFIND',
		  13: 'PROPPATCH',
		  14: 'SEARCH',
		  15: 'UNLOCK',
		  16: 'BIND',
		  17: 'REBIND',
		  18: 'UNBIND',
		  19: 'ACL',
		  20: 'REPORT',
		  21: 'MKACTIVITY',
		  22: 'CHECKOUT',
		  23: 'MERGE',
		  24: 'M-SEARCH',
		  25: 'NOTIFY',
		  26: 'SUBSCRIBE',
		  27: 'UNSUBSCRIBE',
		  28: 'PATCH',
		  29: 'PURGE',
		  30: 'MKCALENDAR',
		  31: 'LINK',
		  32: 'UNLINK'
		};

		var VERSION = process.version
		  ? process.version.match(/[0-9]+/g).map(function(n) { return parseInt(n, 10) })
		  : [];

		if (VERSION[0] === 0 && VERSION[1] === 12) {
		  HttpParser.METHODS[16] = 'REPORT';
		  HttpParser.METHODS[17] = 'MKACTIVITY';
		  HttpParser.METHODS[18] = 'CHECKOUT';
		  HttpParser.METHODS[19] = 'MERGE';
		  HttpParser.METHODS[20] = 'M-SEARCH';
		  HttpParser.METHODS[21] = 'NOTIFY';
		  HttpParser.METHODS[22] = 'SUBSCRIBE';
		  HttpParser.METHODS[23] = 'UNSUBSCRIBE';
		  HttpParser.METHODS[24] = 'PATCH';
		  HttpParser.METHODS[25] = 'PURGE';
		}

		HttpParser.prototype.isComplete = function() {
		  return this._complete;
		};

		HttpParser.prototype.parse = function(chunk) {
		  var consumed = this._parser.execute(chunk, 0, chunk.length);

		  if (typeof consumed !== 'number') {
		    this.error     = consumed;
		    this._complete = true;
		    return;
		  }

		  if (this._complete)
		    this.body = (consumed < chunk.length)
		              ? chunk.slice(consumed)
		              : Buffer.alloc(0);
		};

		http_parser = HttpParser;
		return http_parser;
	}

	var parser;
	var hasRequiredParser;

	function requireParser () {
		if (hasRequiredParser) return parser;
		hasRequiredParser = 1;

		var TOKEN    = /([!#\$%&'\*\+\-\.\^_`\|~0-9A-Za-z]+)/,
		    NOTOKEN  = /([^!#\$%&'\*\+\-\.\^_`\|~0-9A-Za-z])/g,
		    QUOTED   = /"((?:\\[\x00-\x7f]|[^\x00-\x08\x0a-\x1f\x7f"\\])*)"/,
		    PARAM    = new RegExp(TOKEN.source + '(?:=(?:' + TOKEN.source + '|' + QUOTED.source + '))?'),
		    EXT      = new RegExp(TOKEN.source + '(?: *; *' + PARAM.source + ')*', 'g'),
		    EXT_LIST = new RegExp('^' + EXT.source + '(?: *, *' + EXT.source + ')*$'),
		    NUMBER   = /^-?(0|[1-9][0-9]*)(\.[0-9]+)?$/;

		var hasOwnProperty = Object.prototype.hasOwnProperty;

		var Parser = {
		  parseHeader: function(header) {
		    var offers = new Offers();
		    if (header === '' || header === undefined) return offers;

		    if (!EXT_LIST.test(header))
		      throw new SyntaxError('Invalid Sec-WebSocket-Extensions header: ' + header);

		    var values = header.match(EXT);

		    values.forEach(function(value) {
		      var params = value.match(new RegExp(PARAM.source, 'g')),
		          name   = params.shift(),
		          offer  = {};

		      params.forEach(function(param) {
		        var args = param.match(PARAM), key = args[1], data;

		        if (args[2] !== undefined) {
		          data = args[2];
		        } else if (args[3] !== undefined) {
		          data = args[3].replace(/\\/g, '');
		        } else {
		          data = true;
		        }
		        if (NUMBER.test(data)) data = parseFloat(data);

		        if (hasOwnProperty.call(offer, key)) {
		          offer[key] = [].concat(offer[key]);
		          offer[key].push(data);
		        } else {
		          offer[key] = data;
		        }
		      }, this);
		      offers.push(name, offer);
		    }, this);

		    return offers;
		  },

		  serializeParams: function(name, params) {
		    var values = [];

		    var print = function(key, value) {
		      if (value instanceof Array) {
		        value.forEach(function(v) { print(key, v); });
		      } else if (value === true) {
		        values.push(key);
		      } else if (typeof value === 'number') {
		        values.push(key + '=' + value);
		      } else if (NOTOKEN.test(value)) {
		        values.push(key + '="' + value.replace(/"/g, '\\"') + '"');
		      } else {
		        values.push(key + '=' + value);
		      }
		    };

		    for (var key in params) print(key, params[key]);

		    return [name].concat(values).join('; ');
		  }
		};

		var Offers = function() {
		  this._byName  = {};
		  this._inOrder = [];
		};

		Offers.prototype.push = function(name, params) {
		  if (!hasOwnProperty.call(this._byName, name))
		    this._byName[name] = [];

		  this._byName[name].push(params);
		  this._inOrder.push({ name: name, params: params });
		};

		Offers.prototype.eachOffer = function(callback, context) {
		  var list = this._inOrder;
		  for (var i = 0, n = list.length; i < n; i++)
		    callback.call(context, list[i].name, list[i].params);
		};

		Offers.prototype.byName = function(name) {
		  return this._byName[name] || [];
		};

		Offers.prototype.toArray = function() {
		  return this._inOrder.slice();
		};

		parser = Parser;
		return parser;
	}

	var ring_buffer;
	var hasRequiredRing_buffer;

	function requireRing_buffer () {
		if (hasRequiredRing_buffer) return ring_buffer;
		hasRequiredRing_buffer = 1;

		var RingBuffer = function(bufferSize) {
		  this._bufferSize = bufferSize;
		  this.clear();
		};

		RingBuffer.prototype.clear = function() {
		  this._buffer     = new Array(this._bufferSize);
		  this._ringOffset = 0;
		  this._ringSize   = this._bufferSize;
		  this._head       = 0;
		  this._tail       = 0;
		  this.length      = 0;
		};

		RingBuffer.prototype.push = function(value) {
		  var expandBuffer = false,
		      expandRing   = false;

		  if (this._ringSize < this._bufferSize) {
		    expandBuffer = (this._tail === 0);
		  } else if (this._ringOffset === this._ringSize) {
		    expandBuffer = true;
		    expandRing   = (this._tail === 0);
		  }

		  if (expandBuffer) {
		    this._tail       = this._bufferSize;
		    this._buffer     = this._buffer.concat(new Array(this._bufferSize));
		    this._bufferSize = this._buffer.length;

		    if (expandRing)
		      this._ringSize = this._bufferSize;
		  }

		  this._buffer[this._tail] = value;
		  this.length += 1;
		  if (this._tail < this._ringSize) this._ringOffset += 1;
		  this._tail = (this._tail + 1) % this._bufferSize;
		};

		RingBuffer.prototype.peek = function() {
		  if (this.length === 0) return void 0;
		  return this._buffer[this._head];
		};

		RingBuffer.prototype.shift = function() {
		  if (this.length === 0) return void 0;

		  var value = this._buffer[this._head];
		  this._buffer[this._head] = void 0;
		  this.length -= 1;
		  this._ringOffset -= 1;

		  if (this._ringOffset === 0 && this.length > 0) {
		    this._head       = this._ringSize;
		    this._ringOffset = this.length;
		    this._ringSize   = this._bufferSize;
		  } else {
		    this._head = (this._head + 1) % this._ringSize;
		  }
		  return value;
		};

		ring_buffer = RingBuffer;
		return ring_buffer;
	}

	var functor;
	var hasRequiredFunctor;

	function requireFunctor () {
		if (hasRequiredFunctor) return functor;
		hasRequiredFunctor = 1;

		var RingBuffer = requireRing_buffer();

		var Functor = function(session, method) {
		  this._session = session;
		  this._method  = method;
		  this._queue   = new RingBuffer(Functor.QUEUE_SIZE);
		  this._stopped = false;
		  this.pending  = 0;
		};

		Functor.QUEUE_SIZE = 8;

		Functor.prototype.call = function(error, message, callback, context) {
		  if (this._stopped) return;

		  var record = { error: error, message: message, callback: callback, context: context, done: false },
		      called = false,
		      self   = this;

		  this._queue.push(record);

		  if (record.error) {
		    record.done = true;
		    this._stop();
		    return this._flushQueue();
		  }

		  var handler = function(err, msg) {
		    if (!(called ^ (called = true))) return;

		    if (err) {
		      self._stop();
		      record.error   = err;
		      record.message = null;
		    } else {
		      record.message = msg;
		    }

		    record.done = true;
		    self._flushQueue();
		  };

		  try {
		    this._session[this._method](message, handler);
		  } catch (err) {
		    handler(err);
		  }
		};

		Functor.prototype._stop = function() {
		  this.pending  = this._queue.length;
		  this._stopped = true;
		};

		Functor.prototype._flushQueue = function() {
		  var queue = this._queue, record;

		  while (queue.length > 0 && queue.peek().done) {
		    record = queue.shift();
		    if (record.error) {
		      this.pending = 0;
		      queue.clear();
		    } else {
		      this.pending -= 1;
		    }
		    record.callback.call(record.context, record.error, record.message);
		  }
		};

		functor = Functor;
		return functor;
	}

	var pledge;
	var hasRequiredPledge;

	function requirePledge () {
		if (hasRequiredPledge) return pledge;
		hasRequiredPledge = 1;

		var RingBuffer = requireRing_buffer();

		var Pledge = function() {
		  this._complete  = false;
		  this._callbacks = new RingBuffer(Pledge.QUEUE_SIZE);
		};

		Pledge.QUEUE_SIZE = 4;

		Pledge.all = function(list) {
		  var pledge  = new Pledge(),
		      pending = list.length,
		      n       = pending;

		  if (pending === 0) pledge.done();

		  while (n--) list[n].then(function() {
		    pending -= 1;
		    if (pending === 0) pledge.done();
		  });
		  return pledge;
		};

		Pledge.prototype.then = function(callback) {
		  if (this._complete) callback();
		  else this._callbacks.push(callback);
		};

		Pledge.prototype.done = function() {
		  this._complete = true;
		  var callbacks = this._callbacks, callback;
		  while (callback = callbacks.shift()) callback();
		};

		pledge = Pledge;
		return pledge;
	}

	var cell;
	var hasRequiredCell;

	function requireCell () {
		if (hasRequiredCell) return cell;
		hasRequiredCell = 1;

		var Functor = requireFunctor(),
		    Pledge  = requirePledge();

		var Cell = function(tuple) {
		  this._ext     = tuple[0];
		  this._session = tuple[1];

		  this._functors = {
		    incoming: new Functor(this._session, 'processIncomingMessage'),
		    outgoing: new Functor(this._session, 'processOutgoingMessage')
		  };
		};

		Cell.prototype.pending = function(direction) {
		  var functor = this._functors[direction];
		  if (!functor._stopped) functor.pending += 1;
		};

		Cell.prototype.incoming = function(error, message, callback, context) {
		  this._exec('incoming', error, message, callback, context);
		};

		Cell.prototype.outgoing = function(error, message, callback, context) {
		  this._exec('outgoing', error, message, callback, context);
		};

		Cell.prototype.close = function() {
		  this._closed = this._closed || new Pledge();
		  this._doClose();
		  return this._closed;
		};

		Cell.prototype._exec = function(direction, error, message, callback, context) {
		  this._functors[direction].call(error, message, function(err, msg) {
		    if (err) err.message = this._ext.name + ': ' + err.message;
		    callback.call(context, err, msg);
		    this._doClose();
		  }, this);
		};

		Cell.prototype._doClose = function() {
		  var fin  = this._functors.incoming,
		      fout = this._functors.outgoing;

		  if (!this._closed || fin.pending + fout.pending !== 0) return;
		  if (this._session) this._session.close();
		  this._session = null;
		  this._closed.done();
		};

		cell = Cell;
		return cell;
	}

	var pipeline;
	var hasRequiredPipeline;

	function requirePipeline () {
		if (hasRequiredPipeline) return pipeline;
		hasRequiredPipeline = 1;

		var Cell   = requireCell(),
		    Pledge = requirePledge();

		var Pipeline = function(sessions) {
		  this._cells   = sessions.map(function(session) { return new Cell(session) });
		  this._stopped = { incoming: false, outgoing: false };
		};

		Pipeline.prototype.processIncomingMessage = function(message, callback, context) {
		  if (this._stopped.incoming) return;
		  this._loop('incoming', this._cells.length - 1, -1, -1, message, callback, context);
		};

		Pipeline.prototype.processOutgoingMessage = function(message, callback, context) {
		  if (this._stopped.outgoing) return;
		  this._loop('outgoing', 0, this._cells.length, 1, message, callback, context);
		};

		Pipeline.prototype.close = function(callback, context) {
		  this._stopped = { incoming: true, outgoing: true };

		  var closed = this._cells.map(function(a) { return a.close() });
		  if (callback)
		    Pledge.all(closed).then(function() { callback.call(context); });
		};

		Pipeline.prototype._loop = function(direction, start, end, step, message, callback, context) {
		  var cells = this._cells,
		      n     = cells.length,
		      self  = this;

		  while (n--) cells[n].pending(direction);

		  var pipe = function(index, error, msg) {
		    if (index === end) return callback.call(context, error, msg);

		    cells[index][direction](error, msg, function(err, m) {
		      if (err) self._stopped[direction] = true;
		      pipe(index + step, err, m);
		    });
		  };
		  pipe(start, null, message);
		};

		pipeline = Pipeline;
		return pipeline;
	}

	var websocket_extensions;
	var hasRequiredWebsocket_extensions;

	function requireWebsocket_extensions () {
		if (hasRequiredWebsocket_extensions) return websocket_extensions;
		hasRequiredWebsocket_extensions = 1;

		var Parser   = requireParser(),
		    Pipeline = requirePipeline();

		var Extensions = function() {
		  this._rsv1 = this._rsv2 = this._rsv3 = null;

		  this._byName   = {};
		  this._inOrder  = [];
		  this._sessions = [];
		  this._index    = {};
		};

		Extensions.MESSAGE_OPCODES = [1, 2];

		var instance = {
		  add: function(ext) {
		    if (typeof ext.name !== 'string') throw new TypeError('extension.name must be a string');
		    if (ext.type !== 'permessage') throw new TypeError('extension.type must be "permessage"');

		    if (typeof ext.rsv1 !== 'boolean') throw new TypeError('extension.rsv1 must be true or false');
		    if (typeof ext.rsv2 !== 'boolean') throw new TypeError('extension.rsv2 must be true or false');
		    if (typeof ext.rsv3 !== 'boolean') throw new TypeError('extension.rsv3 must be true or false');

		    if (this._byName.hasOwnProperty(ext.name))
		      throw new TypeError('An extension with name "' + ext.name + '" is already registered');

		    this._byName[ext.name] = ext;
		    this._inOrder.push(ext);
		  },

		  generateOffer: function() {
		    var sessions = [],
		        offer    = [],
		        index    = {};

		    this._inOrder.forEach(function(ext) {
		      var session = ext.createClientSession();
		      if (!session) return;

		      var record = [ext, session];
		      sessions.push(record);
		      index[ext.name] = record;

		      var offers = session.generateOffer();
		      offers = offers ? [].concat(offers) : [];

		      offers.forEach(function(off) {
		        offer.push(Parser.serializeParams(ext.name, off));
		      }, this);
		    }, this);

		    this._sessions = sessions;
		    this._index    = index;

		    return offer.length > 0 ? offer.join(', ') : null;
		  },

		  activate: function(header) {
		    var responses = Parser.parseHeader(header),
		        sessions  = [];

		    responses.eachOffer(function(name, params) {
		      var record = this._index[name];

		      if (!record)
		        throw new Error('Server sent an extension response for unknown extension "' + name + '"');

		      var ext      = record[0],
		          session  = record[1],
		          reserved = this._reserved(ext);

		      if (reserved)
		        throw new Error('Server sent two extension responses that use the RSV' +
		                        reserved[0] + ' bit: "' +
		                        reserved[1] + '" and "' + ext.name + '"');

		      if (session.activate(params) !== true)
		        throw new Error('Server sent unacceptable extension parameters: ' +
		                        Parser.serializeParams(name, params));

		      this._reserve(ext);
		      sessions.push(record);
		    }, this);

		    this._sessions = sessions;
		    this._pipeline = new Pipeline(sessions);
		  },

		  generateResponse: function(header) {
		    var sessions = [],
		        response = [],
		        offers   = Parser.parseHeader(header);

		    this._inOrder.forEach(function(ext) {
		      var offer = offers.byName(ext.name);
		      if (offer.length === 0 || this._reserved(ext)) return;

		      var session = ext.createServerSession(offer);
		      if (!session) return;

		      this._reserve(ext);
		      sessions.push([ext, session]);
		      response.push(Parser.serializeParams(ext.name, session.generateResponse()));
		    }, this);

		    this._sessions = sessions;
		    this._pipeline = new Pipeline(sessions);

		    return response.length > 0 ? response.join(', ') : null;
		  },

		  validFrameRsv: function(frame) {
		    var allowed = { rsv1: false, rsv2: false, rsv3: false },
		        ext;

		    if (Extensions.MESSAGE_OPCODES.indexOf(frame.opcode) >= 0) {
		      for (var i = 0, n = this._sessions.length; i < n; i++) {
		        ext = this._sessions[i][0];
		        allowed.rsv1 = allowed.rsv1 || ext.rsv1;
		        allowed.rsv2 = allowed.rsv2 || ext.rsv2;
		        allowed.rsv3 = allowed.rsv3 || ext.rsv3;
		      }
		    }

		    return (allowed.rsv1 || !frame.rsv1) &&
		           (allowed.rsv2 || !frame.rsv2) &&
		           (allowed.rsv3 || !frame.rsv3);
		  },

		  processIncomingMessage: function(message, callback, context) {
		    this._pipeline.processIncomingMessage(message, callback, context);
		  },

		  processOutgoingMessage: function(message, callback, context) {
		    this._pipeline.processOutgoingMessage(message, callback, context);
		  },

		  close: function(callback, context) {
		    if (!this._pipeline) return callback.call(context);
		    this._pipeline.close(callback, context);
		  },

		  _reserve: function(ext) {
		    this._rsv1 = this._rsv1 || (ext.rsv1 && ext.name);
		    this._rsv2 = this._rsv2 || (ext.rsv2 && ext.name);
		    this._rsv3 = this._rsv3 || (ext.rsv3 && ext.name);
		  },

		  _reserved: function(ext) {
		    if (this._rsv1 && ext.rsv1) return [1, this._rsv1];
		    if (this._rsv2 && ext.rsv2) return [2, this._rsv2];
		    if (this._rsv3 && ext.rsv3) return [3, this._rsv3];
		    return false;
		  }
		};

		for (var key in instance)
		  Extensions.prototype[key] = instance[key];

		websocket_extensions = Extensions;
		return websocket_extensions;
	}

	var frame;
	var hasRequiredFrame;

	function requireFrame () {
		if (hasRequiredFrame) return frame;
		hasRequiredFrame = 1;

		var Frame = function() {};

		var instance = {
		  final:        false,
		  rsv1:         false,
		  rsv2:         false,
		  rsv3:         false,
		  opcode:       null,
		  masked:       false,
		  maskingKey:   null,
		  lengthBytes:  1,
		  length:       0,
		  payload:      null
		};

		for (var key in instance)
		  Frame.prototype[key] = instance[key];

		frame = Frame;
		return frame;
	}

	var message;
	var hasRequiredMessage;

	function requireMessage () {
		if (hasRequiredMessage) return message;
		hasRequiredMessage = 1;

		var Buffer = requireSafeBuffer().Buffer;

		var Message = function() {
		  this.rsv1    = false;
		  this.rsv2    = false;
		  this.rsv3    = false;
		  this.opcode  = null;
		  this.length  = 0;
		  this._chunks = [];
		};

		var instance = {
		  read: function() {
		    return this.data = this.data || Buffer.concat(this._chunks, this.length);
		  },

		  pushFrame: function(frame) {
		    this.rsv1 = this.rsv1 || frame.rsv1;
		    this.rsv2 = this.rsv2 || frame.rsv2;
		    this.rsv3 = this.rsv3 || frame.rsv3;

		    if (this.opcode === null) this.opcode = frame.opcode;

		    this._chunks.push(frame.payload);
		    this.length += frame.length;
		  }
		};

		for (var key in instance)
		  Message.prototype[key] = instance[key];

		message = Message;
		return message;
	}

	var hybi;
	var hasRequiredHybi;

	function requireHybi () {
		if (hasRequiredHybi) return hybi;
		hasRequiredHybi = 1;

		var Buffer     = requireSafeBuffer().Buffer,
		    crypto     = require$$1$2,
		    util       = require$$0$3,
		    Extensions = requireWebsocket_extensions(),
		    Base       = requireBase(),
		    Frame      = requireFrame(),
		    Message    = requireMessage();

		var Hybi = function(request, url, options) {
		  Base.apply(this, arguments);

		  this._extensions     = new Extensions();
		  this._stage          = 0;
		  this._masking        = this._options.masking;
		  this._protocols      = this._options.protocols || [];
		  this._requireMasking = this._options.requireMasking;
		  this._pingCallbacks  = {};

		  if (typeof this._protocols === 'string')
		    this._protocols = this._protocols.split(/ *, */);

		  if (!this._request) return;

		  var protos    = this._request.headers['sec-websocket-protocol'],
		      supported = this._protocols;

		  if (protos !== undefined) {
		    if (typeof protos === 'string') protos = protos.split(/ *, */);
		    this.protocol = protos.filter(function(p) { return supported.indexOf(p) >= 0 })[0];
		  }

		  this.version = 'hybi-' + Hybi.VERSION;
		};
		util.inherits(Hybi, Base);

		Hybi.VERSION = '13';

		Hybi.mask = function(payload, mask, offset) {
		  if (!mask || mask.length === 0) return payload;
		  offset = offset || 0;

		  for (var i = 0, n = payload.length - offset; i < n; i++) {
		    payload[offset + i] = payload[offset + i] ^ mask[i % 4];
		  }
		  return payload;
		};

		Hybi.generateAccept = function(key) {
		  var sha1 = crypto.createHash('sha1');
		  sha1.update(key + Hybi.GUID);
		  return sha1.digest('base64');
		};

		Hybi.GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

		var instance = {
		  FIN:    0x80,
		  MASK:   0x80,
		  RSV1:   0x40,
		  RSV2:   0x20,
		  RSV3:   0x10,
		  OPCODE: 0x0F,
		  LENGTH: 0x7F,

		  OPCODES: {
		    continuation: 0,
		    text:         1,
		    binary:       2,
		    close:        8,
		    ping:         9,
		    pong:         10
		  },

		  OPCODE_CODES:    [0, 1, 2, 8, 9, 10],
		  MESSAGE_OPCODES: [0, 1, 2],
		  OPENING_OPCODES: [1, 2],

		  ERRORS: {
		    normal_closure:       1000,
		    going_away:           1001,
		    protocol_error:       1002,
		    unacceptable:         1003,
		    encoding_error:       1007,
		    policy_violation:     1008,
		    too_large:            1009,
		    extension_error:      1010,
		    unexpected_condition: 1011
		  },

		  ERROR_CODES:        [1000, 1001, 1002, 1003, 1007, 1008, 1009, 1010, 1011],
		  DEFAULT_ERROR_CODE: 1000,
		  MIN_RESERVED_ERROR: 3000,
		  MAX_RESERVED_ERROR: 4999,

		  // http://www.w3.org/International/questions/qa-forms-utf-8.en.php
		  UTF8_MATCH: /^([\x00-\x7F]|[\xC2-\xDF][\x80-\xBF]|\xE0[\xA0-\xBF][\x80-\xBF]|[\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}|\xED[\x80-\x9F][\x80-\xBF]|\xF0[\x90-\xBF][\x80-\xBF]{2}|[\xF1-\xF3][\x80-\xBF]{3}|\xF4[\x80-\x8F][\x80-\xBF]{2})*$/,

		  addExtension: function(extension) {
		    this._extensions.add(extension);
		    return true;
		  },

		  parse: function(chunk) {
		    this._reader.put(chunk);
		    var buffer = true;
		    while (buffer) {
		      switch (this._stage) {
		        case 0:
		          buffer = this._reader.read(1);
		          if (buffer) this._parseOpcode(buffer[0]);
		          break;

		        case 1:
		          buffer = this._reader.read(1);
		          if (buffer) this._parseLength(buffer[0]);
		          break;

		        case 2:
		          buffer = this._reader.read(this._frame.lengthBytes);
		          if (buffer) this._parseExtendedLength(buffer);
		          break;

		        case 3:
		          buffer = this._reader.read(4);
		          if (buffer) {
		            this._stage = 4;
		            this._frame.maskingKey = buffer;
		          }
		          break;

		        case 4:
		          buffer = this._reader.read(this._frame.length);
		          if (buffer) {
		            this._stage = 0;
		            this._emitFrame(buffer);
		          }
		          break;

		        default:
		          buffer = null;
		      }
		    }
		  },

		  text: function(message) {
		    if (this.readyState > 1) return false;
		    return this.frame(message, 'text');
		  },

		  binary: function(message) {
		    if (this.readyState > 1) return false;
		    return this.frame(message, 'binary');
		  },

		  ping: function(message, callback) {
		    if (this.readyState > 1) return false;
		    message = message || '';
		    if (callback) this._pingCallbacks[message] = callback;
		    return this.frame(message, 'ping');
		  },

		  pong: function(message) {
		      if (this.readyState > 1) return false;
		      message = message ||'';
		      return this.frame(message, 'pong');
		  },

		  close: function(reason, code) {
		    reason = reason || '';
		    code   = code   || this.ERRORS.normal_closure;

		    if (this.readyState <= 0) {
		      this.readyState = 3;
		      this.emit('close', new Base.CloseEvent(code, reason));
		      return true;
		    } else if (this.readyState === 1) {
		      this.readyState = 2;
		      this._extensions.close(function() { this.frame(reason, 'close', code); }, this);
		      return true;
		    } else {
		      return false;
		    }
		  },

		  frame: function(buffer, type, code) {
		    if (this.readyState <= 0) return this._queue([buffer, type, code]);
		    if (this.readyState > 2) return false;

		    if (buffer instanceof Array)    buffer = Buffer.from(buffer);
		    if (typeof buffer === 'number') buffer = buffer.toString();

		    var message = new Message(),
		        isText  = (typeof buffer === 'string'),
		        payload, copy;

		    message.rsv1   = message.rsv2 = message.rsv3 = false;
		    message.opcode = this.OPCODES[type || (isText ? 'text' : 'binary')];

		    payload = isText ? Buffer.from(buffer, 'utf8') : buffer;

		    if (code) {
		      copy = payload;
		      payload = Buffer.allocUnsafe(2 + copy.length);
		      payload.writeUInt16BE(code, 0);
		      copy.copy(payload, 2);
		    }
		    message.data = payload;

		    var onMessageReady = function(message) {
		      var frame = new Frame();

		      frame.final   = true;
		      frame.rsv1    = message.rsv1;
		      frame.rsv2    = message.rsv2;
		      frame.rsv3    = message.rsv3;
		      frame.opcode  = message.opcode;
		      frame.masked  = !!this._masking;
		      frame.length  = message.data.length;
		      frame.payload = message.data;

		      if (frame.masked) frame.maskingKey = crypto.randomBytes(4);

		      this._sendFrame(frame);
		    };

		    if (this.MESSAGE_OPCODES.indexOf(message.opcode) >= 0)
		      this._extensions.processOutgoingMessage(message, function(error, message) {
		        if (error) return this._fail('extension_error', error.message);
		        onMessageReady.call(this, message);
		      }, this);
		    else
		      onMessageReady.call(this, message);

		    return true;
		  },

		  _sendFrame: function(frame) {
		    var length = frame.length,
		        header = (length <= 125) ? 2 : (length <= 65535 ? 4 : 10),
		        offset = header + (frame.masked ? 4 : 0),
		        buffer = Buffer.allocUnsafe(offset + length),
		        masked = frame.masked ? this.MASK : 0;

		    buffer[0] = (frame.final ? this.FIN : 0) |
		                (frame.rsv1 ? this.RSV1 : 0) |
		                (frame.rsv2 ? this.RSV2 : 0) |
		                (frame.rsv3 ? this.RSV3 : 0) |
		                frame.opcode;

		    if (length <= 125) {
		      buffer[1] = masked | length;
		    } else if (length <= 65535) {
		      buffer[1] = masked | 126;
		      buffer.writeUInt16BE(length, 2);
		    } else {
		      buffer[1] = masked | 127;
		      buffer.writeUInt32BE(Math.floor(length / 0x100000000), 2);
		      buffer.writeUInt32BE(length % 0x100000000, 6);
		    }

		    frame.payload.copy(buffer, offset);

		    if (frame.masked) {
		      frame.maskingKey.copy(buffer, header);
		      Hybi.mask(buffer, frame.maskingKey, offset);
		    }

		    this._write(buffer);
		  },

		  _handshakeResponse: function() {
		    var secKey  = this._request.headers['sec-websocket-key'],
		        version = this._request.headers['sec-websocket-version'];

		    if (version !== Hybi.VERSION)
		      throw new Error('Unsupported WebSocket version: ' + version);

		    if (typeof secKey !== 'string')
		      throw new Error('Missing handshake request header: Sec-WebSocket-Key');

		    this._headers.set('Upgrade', 'websocket');
		    this._headers.set('Connection', 'Upgrade');
		    this._headers.set('Sec-WebSocket-Accept', Hybi.generateAccept(secKey));

		    if (this.protocol) this._headers.set('Sec-WebSocket-Protocol', this.protocol);

		    var extensions = this._extensions.generateResponse(this._request.headers['sec-websocket-extensions']);
		    if (extensions) this._headers.set('Sec-WebSocket-Extensions', extensions);

		    var start   = 'HTTP/1.1 101 Switching Protocols',
		        headers = [start, this._headers.toString(), ''];

		    return Buffer.from(headers.join('\r\n'), 'utf8');
		  },

		  _shutdown: function(code, reason, error) {
		    delete this._frame;
		    delete this._message;
		    this._stage = 5;

		    var sendCloseFrame = (this.readyState === 1);
		    this.readyState = 2;

		    this._extensions.close(function() {
		      if (sendCloseFrame) this.frame(reason, 'close', code);
		      this.readyState = 3;
		      if (error) this.emit('error', new Error(reason));
		      this.emit('close', new Base.CloseEvent(code, reason));
		    }, this);
		  },

		  _fail: function(type, message) {
		    if (this.readyState > 1) return;
		    this._shutdown(this.ERRORS[type], message, true);
		  },

		  _parseOpcode: function(octet) {
		    var rsvs = [this.RSV1, this.RSV2, this.RSV3].map(function(rsv) {
		      return (octet & rsv) === rsv;
		    });

		    var frame = this._frame = new Frame();

		    frame.final  = (octet & this.FIN) === this.FIN;
		    frame.rsv1   = rsvs[0];
		    frame.rsv2   = rsvs[1];
		    frame.rsv3   = rsvs[2];
		    frame.opcode = (octet & this.OPCODE);

		    this._stage = 1;

		    if (!this._extensions.validFrameRsv(frame))
		      return this._fail('protocol_error',
		          'One or more reserved bits are on: reserved1 = ' + (frame.rsv1 ? 1 : 0) +
		          ', reserved2 = ' + (frame.rsv2 ? 1 : 0) +
		          ', reserved3 = ' + (frame.rsv3 ? 1 : 0));

		    if (this.OPCODE_CODES.indexOf(frame.opcode) < 0)
		      return this._fail('protocol_error', 'Unrecognized frame opcode: ' + frame.opcode);

		    if (this.MESSAGE_OPCODES.indexOf(frame.opcode) < 0 && !frame.final)
		      return this._fail('protocol_error', 'Received fragmented control frame: opcode = ' + frame.opcode);

		    if (this._message && this.OPENING_OPCODES.indexOf(frame.opcode) >= 0)
		      return this._fail('protocol_error', 'Received new data frame but previous continuous frame is unfinished');
		  },

		  _parseLength: function(octet) {
		    var frame = this._frame;
		    frame.masked = (octet & this.MASK) === this.MASK;
		    frame.length = (octet & this.LENGTH);

		    if (frame.length >= 0 && frame.length <= 125) {
		      this._stage = frame.masked ? 3 : 4;
		      if (!this._checkFrameLength()) return;
		    } else {
		      this._stage = 2;
		      frame.lengthBytes = (frame.length === 126 ? 2 : 8);
		    }

		    if (this._requireMasking && !frame.masked)
		      return this._fail('unacceptable', 'Received unmasked frame but masking is required');
		  },

		  _parseExtendedLength: function(buffer) {
		    var frame = this._frame;
		    frame.length = this._readUInt(buffer);

		    this._stage = frame.masked ? 3 : 4;

		    if (this.MESSAGE_OPCODES.indexOf(frame.opcode) < 0 && frame.length > 125)
		      return this._fail('protocol_error', 'Received control frame having too long payload: ' + frame.length);

		    if (!this._checkFrameLength()) return;
		  },

		  _checkFrameLength: function() {
		    var length = this._message ? this._message.length : 0;

		    if (length + this._frame.length > this._maxLength) {
		      this._fail('too_large', 'WebSocket frame length too large');
		      return false;
		    } else {
		      return true;
		    }
		  },

		  _emitFrame: function(buffer) {
		    var frame   = this._frame,
		        payload = frame.payload = Hybi.mask(buffer, frame.maskingKey),
		        opcode  = frame.opcode,
		        message,
		        code, reason,
		        callbacks, callback;

		    delete this._frame;

		    if (opcode === this.OPCODES.continuation) {
		      if (!this._message) return this._fail('protocol_error', 'Received unexpected continuation frame');
		      this._message.pushFrame(frame);
		    }

		    if (opcode === this.OPCODES.text || opcode === this.OPCODES.binary) {
		      this._message = new Message();
		      this._message.pushFrame(frame);
		    }

		    if (frame.final && this.MESSAGE_OPCODES.indexOf(opcode) >= 0)
		      return this._emitMessage(this._message);

		    if (opcode === this.OPCODES.close) {
		      code   = (payload.length >= 2) ? payload.readUInt16BE(0) : null;
		      reason = (payload.length > 2) ? this._encode(payload.slice(2)) : null;

		      if (!(payload.length === 0) &&
		          !(code !== null && code >= this.MIN_RESERVED_ERROR && code <= this.MAX_RESERVED_ERROR) &&
		          this.ERROR_CODES.indexOf(code) < 0)
		        code = this.ERRORS.protocol_error;

		      if (payload.length > 125 || (payload.length > 2 && !reason))
		        code = this.ERRORS.protocol_error;

		      this._shutdown(code || this.DEFAULT_ERROR_CODE, reason || '');
		    }

		    if (opcode === this.OPCODES.ping) {
		      this.frame(payload, 'pong');
		      this.emit('ping', new Base.PingEvent(payload.toString()));
		    }

		    if (opcode === this.OPCODES.pong) {
		      callbacks = this._pingCallbacks;
		      message   = this._encode(payload);
		      callback  = callbacks[message];

		      delete callbacks[message];
		      if (callback) callback();

		      this.emit('pong', new Base.PongEvent(payload.toString()));
		    }
		  },

		  _emitMessage: function(message) {
		    var message = this._message;
		    message.read();

		    delete this._message;

		    this._extensions.processIncomingMessage(message, function(error, message) {
		      if (error) return this._fail('extension_error', error.message);

		      var payload = message.data;
		      if (message.opcode === this.OPCODES.text) payload = this._encode(payload);

		      if (payload === null)
		        return this._fail('encoding_error', 'Could not decode a text frame as UTF-8');
		      else
		        this.emit('message', new Base.MessageEvent(payload));
		    }, this);
		  },

		  _encode: function(buffer) {
		    try {
		      var string = buffer.toString('binary', 0, buffer.length);
		      if (!this.UTF8_MATCH.test(string)) return null;
		    } catch (e) {}
		    return buffer.toString('utf8', 0, buffer.length);
		  },

		  _readUInt: function(buffer) {
		    if (buffer.length === 2) return buffer.readUInt16BE(0);

		    return buffer.readUInt32BE(0) * 0x100000000 +
		           buffer.readUInt32BE(4);
		  }
		};

		for (var key in instance)
		  Hybi.prototype[key] = instance[key];

		hybi = Hybi;
		return hybi;
	}

	var proxy;
	var hasRequiredProxy;

	function requireProxy () {
		if (hasRequiredProxy) return proxy;
		hasRequiredProxy = 1;

		var Buffer     = requireSafeBuffer().Buffer,
		    Stream     = require$$0$1.Stream,
		    url        = require$$3$1,
		    util       = require$$0$3,
		    Base       = requireBase(),
		    Headers    = requireHeaders(),
		    HttpParser = requireHttp_parser();

		var PORTS = { 'ws:': 80, 'wss:': 443 };

		var Proxy = function(client, origin, options) {
		  this._client  = client;
		  this._http    = new HttpParser('response');
		  this._origin  = (typeof client.url === 'object') ? client.url : url.parse(client.url);
		  this._url     = (typeof origin === 'object') ? origin : url.parse(origin);
		  this._options = options || {};
		  this._state   = 0;

		  this.readable = this.writable = true;
		  this._paused  = false;

		  this._headers = new Headers();
		  this._headers.set('Host', this._origin.host);
		  this._headers.set('Connection', 'keep-alive');
		  this._headers.set('Proxy-Connection', 'keep-alive');

		  var auth = this._url.auth && Buffer.from(this._url.auth, 'utf8').toString('base64');
		  if (auth) this._headers.set('Proxy-Authorization', 'Basic ' + auth);
		};
		util.inherits(Proxy, Stream);

		var instance = {
		  setHeader: function(name, value) {
		    if (this._state !== 0) return false;
		    this._headers.set(name, value);
		    return true;
		  },

		  start: function() {
		    if (this._state !== 0) return false;
		    this._state = 1;

		    var origin = this._origin,
		        port   = origin.port || PORTS[origin.protocol],
		        start  = 'CONNECT ' + origin.hostname + ':' + port + ' HTTP/1.1';

		    var headers = [start, this._headers.toString(), ''];

		    this.emit('data', Buffer.from(headers.join('\r\n'), 'utf8'));
		    return true;
		  },

		  pause: function() {
		    this._paused = true;
		  },

		  resume: function() {
		    this._paused = false;
		    this.emit('drain');
		  },

		  write: function(chunk) {
		    if (!this.writable) return false;

		    this._http.parse(chunk);
		    if (!this._http.isComplete()) return !this._paused;

		    this.statusCode = this._http.statusCode;
		    this.headers    = this._http.headers;

		    if (this.statusCode === 200) {
		      this.emit('connect', new Base.ConnectEvent());
		    } else {
		      var message = "Can't establish a connection to the server at " + this._origin.href;
		      this.emit('error', new Error(message));
		    }
		    this.end();
		    return !this._paused;
		  },

		  end: function(chunk) {
		    if (!this.writable) return;
		    if (chunk !== undefined) this.write(chunk);
		    this.readable = this.writable = false;
		    this.emit('close');
		    this.emit('end');
		  },

		  destroy: function() {
		    this.end();
		  }
		};

		for (var key in instance)
		  Proxy.prototype[key] = instance[key];

		proxy = Proxy;
		return proxy;
	}

	var client$1;
	var hasRequiredClient$1;

	function requireClient$1 () {
		if (hasRequiredClient$1) return client$1;
		hasRequiredClient$1 = 1;

		var Buffer     = requireSafeBuffer().Buffer,
		    crypto     = require$$1$2,
		    url        = require$$3$1,
		    util       = require$$0$3,
		    HttpParser = requireHttp_parser(),
		    Base       = requireBase(),
		    Hybi       = requireHybi(),
		    Proxy      = requireProxy();

		var Client = function(_url, options) {
		  this.version = 'hybi-' + Hybi.VERSION;
		  Hybi.call(this, null, _url, options);

		  this.readyState = -1;
		  this._key       = Client.generateKey();
		  this._accept    = Hybi.generateAccept(this._key);
		  this._http      = new HttpParser('response');

		  var uri  = url.parse(this.url),
		      auth = uri.auth && Buffer.from(uri.auth, 'utf8').toString('base64');

		  if (this.VALID_PROTOCOLS.indexOf(uri.protocol) < 0)
		    throw new Error(this.url + ' is not a valid WebSocket URL');

		  this._pathname = (uri.pathname || '/') + (uri.search || '');

		  this._headers.set('Host', uri.host);
		  this._headers.set('Upgrade', 'websocket');
		  this._headers.set('Connection', 'Upgrade');
		  this._headers.set('Sec-WebSocket-Key', this._key);
		  this._headers.set('Sec-WebSocket-Version', Hybi.VERSION);

		  if (this._protocols.length > 0)
		    this._headers.set('Sec-WebSocket-Protocol', this._protocols.join(', '));

		  if (auth)
		    this._headers.set('Authorization', 'Basic ' + auth);
		};
		util.inherits(Client, Hybi);

		Client.generateKey = function() {
		  return crypto.randomBytes(16).toString('base64');
		};

		var instance = {
		  VALID_PROTOCOLS: ['ws:', 'wss:'],

		  proxy: function(origin, options) {
		    return new Proxy(this, origin, options);
		  },

		  start: function() {
		    if (this.readyState !== -1) return false;
		    this._write(this._handshakeRequest());
		    this.readyState = 0;
		    return true;
		  },

		  parse: function(chunk) {
		    if (this.readyState === 3) return;
		    if (this.readyState > 0) return Hybi.prototype.parse.call(this, chunk);

		    this._http.parse(chunk);
		    if (!this._http.isComplete()) return;

		    this._validateHandshake();
		    if (this.readyState === 3) return;

		    this._open();
		    this.parse(this._http.body);
		  },

		  _handshakeRequest: function() {
		    var extensions = this._extensions.generateOffer();
		    if (extensions)
		      this._headers.set('Sec-WebSocket-Extensions', extensions);

		    var start   = 'GET ' + this._pathname + ' HTTP/1.1',
		        headers = [start, this._headers.toString(), ''];

		    return Buffer.from(headers.join('\r\n'), 'utf8');
		  },

		  _failHandshake: function(message) {
		    message = 'Error during WebSocket handshake: ' + message;
		    this.readyState = 3;
		    this.emit('error', new Error(message));
		    this.emit('close', new Base.CloseEvent(this.ERRORS.protocol_error, message));
		  },

		  _validateHandshake: function() {
		    this.statusCode = this._http.statusCode;
		    this.headers    = this._http.headers;

		    if (this._http.error)
		      return this._failHandshake(this._http.error.message);

		    if (this._http.statusCode !== 101)
		      return this._failHandshake('Unexpected response code: ' + this._http.statusCode);

		    var headers    = this._http.headers,
		        upgrade    = headers['upgrade'] || '',
		        connection = headers['connection'] || '',
		        accept     = headers['sec-websocket-accept'] || '',
		        protocol   = headers['sec-websocket-protocol'] || '';

		    if (upgrade === '')
		      return this._failHandshake("'Upgrade' header is missing");
		    if (upgrade.toLowerCase() !== 'websocket')
		      return this._failHandshake("'Upgrade' header value is not 'WebSocket'");

		    if (connection === '')
		      return this._failHandshake("'Connection' header is missing");
		    if (connection.toLowerCase() !== 'upgrade')
		      return this._failHandshake("'Connection' header value is not 'Upgrade'");

		    if (accept !== this._accept)
		      return this._failHandshake('Sec-WebSocket-Accept mismatch');

		    this.protocol = null;

		    if (protocol !== '') {
		      if (this._protocols.indexOf(protocol) < 0)
		        return this._failHandshake('Sec-WebSocket-Protocol mismatch');
		      else
		        this.protocol = protocol;
		    }

		    try {
		      this._extensions.activate(this.headers['sec-websocket-extensions']);
		    } catch (e) {
		      return this._failHandshake(e.message);
		    }
		  }
		};

		for (var key in instance)
		  Client.prototype[key] = instance[key];

		client$1 = Client;
		return client$1;
	}

	var draft75;
	var hasRequiredDraft75;

	function requireDraft75 () {
		if (hasRequiredDraft75) return draft75;
		hasRequiredDraft75 = 1;

		var Buffer = requireSafeBuffer().Buffer,
		    Base   = requireBase(),
		    util   = require$$0$3;

		var Draft75 = function(request, url, options) {
		  Base.apply(this, arguments);
		  this._stage  = 0;
		  this.version = 'hixie-75';

		  this._headers.set('Upgrade', 'WebSocket');
		  this._headers.set('Connection', 'Upgrade');
		  this._headers.set('WebSocket-Origin', this._request.headers.origin);
		  this._headers.set('WebSocket-Location', this.url);
		};
		util.inherits(Draft75, Base);

		var instance = {
		  close: function() {
		    if (this.readyState === 3) return false;
		    this.readyState = 3;
		    this.emit('close', new Base.CloseEvent(null, null));
		    return true;
		  },

		  parse: function(chunk) {
		    if (this.readyState > 1) return;

		    this._reader.put(chunk);

		    this._reader.eachByte(function(octet) {
		      var message;

		      switch (this._stage) {
		        case -1:
		          this._body.push(octet);
		          this._sendHandshakeBody();
		          break;

		        case 0:
		          this._parseLeadingByte(octet);
		          break;

		        case 1:
		          this._length = (octet & 0x7F) + 128 * this._length;

		          if (this._closing && this._length === 0) {
		            return this.close();
		          }
		          else if ((octet & 0x80) !== 0x80) {
		            if (this._length === 0) {
		              this._stage = 0;
		            }
		            else {
		              this._skipped = 0;
		              this._stage   = 2;
		            }
		          }
		          break;

		        case 2:
		          if (octet === 0xFF) {
		            this._stage = 0;
		            message = Buffer.from(this._buffer).toString('utf8', 0, this._buffer.length);
		            this.emit('message', new Base.MessageEvent(message));
		          }
		          else {
		            if (this._length) {
		              this._skipped += 1;
		              if (this._skipped === this._length)
		                this._stage = 0;
		            } else {
		              this._buffer.push(octet);
		              if (this._buffer.length > this._maxLength) return this.close();
		            }
		          }
		          break;
		      }
		    }, this);
		  },

		  frame: function(buffer) {
		    if (this.readyState === 0) return this._queue([buffer]);
		    if (this.readyState > 1) return false;

		    if (typeof buffer !== 'string') buffer = buffer.toString();

		    var length = Buffer.byteLength(buffer),
		        frame  = Buffer.allocUnsafe(length + 2);

		    frame[0] = 0x00;
		    frame.write(buffer, 1);
		    frame[frame.length - 1] = 0xFF;

		    this._write(frame);
		    return true;
		  },

		  _handshakeResponse: function() {
		    var start   = 'HTTP/1.1 101 Web Socket Protocol Handshake',
		        headers = [start, this._headers.toString(), ''];

		    return Buffer.from(headers.join('\r\n'), 'utf8');
		  },

		  _parseLeadingByte: function(octet) {
		    if ((octet & 0x80) === 0x80) {
		      this._length = 0;
		      this._stage  = 1;
		    } else {
		      delete this._length;
		      delete this._skipped;
		      this._buffer = [];
		      this._stage  = 2;
		    }
		  }
		};

		for (var key in instance)
		  Draft75.prototype[key] = instance[key];

		draft75 = Draft75;
		return draft75;
	}

	var draft76;
	var hasRequiredDraft76;

	function requireDraft76 () {
		if (hasRequiredDraft76) return draft76;
		hasRequiredDraft76 = 1;

		var Buffer  = requireSafeBuffer().Buffer,
		    Base    = requireBase(),
		    Draft75 = requireDraft75(),
		    crypto  = require$$1$2,
		    util    = require$$0$3;


		var numberFromKey = function(key) {
		  return parseInt((key.match(/[0-9]/g) || []).join(''), 10);
		};

		var spacesInKey = function(key) {
		  return (key.match(/ /g) || []).length;
		};


		var Draft76 = function(request, url, options) {
		  Draft75.apply(this, arguments);
		  this._stage  = -1;
		  this._body   = [];
		  this.version = 'hixie-76';

		  this._headers.clear();

		  this._headers.set('Upgrade', 'WebSocket');
		  this._headers.set('Connection', 'Upgrade');
		  this._headers.set('Sec-WebSocket-Origin', this._request.headers.origin);
		  this._headers.set('Sec-WebSocket-Location', this.url);
		};
		util.inherits(Draft76, Draft75);

		var instance = {
		  BODY_SIZE: 8,

		  start: function() {
		    if (!Draft75.prototype.start.call(this)) return false;
		    this._started = true;
		    this._sendHandshakeBody();
		    return true;
		  },

		  close: function() {
		    if (this.readyState === 3) return false;
		    if (this.readyState === 1) this._write(Buffer.from([0xFF, 0x00]));
		    this.readyState = 3;
		    this.emit('close', new Base.CloseEvent(null, null));
		    return true;
		  },

		  _handshakeResponse: function() {
		    var headers = this._request.headers,
		        key1    = headers['sec-websocket-key1'],
		        key2    = headers['sec-websocket-key2'];

		    if (!key1) throw new Error('Missing required header: Sec-WebSocket-Key1');
		    if (!key2) throw new Error('Missing required header: Sec-WebSocket-Key2');

		    var number1 = numberFromKey(key1),
		        spaces1 = spacesInKey(key1),

		        number2 = numberFromKey(key2),
		        spaces2 = spacesInKey(key2);

		    if (number1 % spaces1 !== 0 || number2 % spaces2 !== 0)
		      throw new Error('Client sent invalid Sec-WebSocket-Key headers');

		    this._keyValues = [number1 / spaces1, number2 / spaces2];

		    var start   = 'HTTP/1.1 101 WebSocket Protocol Handshake',
		        headers = [start, this._headers.toString(), ''];

		    return Buffer.from(headers.join('\r\n'), 'binary');
		  },

		  _handshakeSignature: function() {
		    if (this._body.length < this.BODY_SIZE) return null;

		    var md5    = crypto.createHash('md5'),
		        buffer = Buffer.allocUnsafe(8 + this.BODY_SIZE);

		    buffer.writeUInt32BE(this._keyValues[0], 0);
		    buffer.writeUInt32BE(this._keyValues[1], 4);
		    Buffer.from(this._body).copy(buffer, 8, 0, this.BODY_SIZE);

		    md5.update(buffer);
		    return Buffer.from(md5.digest('binary'), 'binary');
		  },

		  _sendHandshakeBody: function() {
		    if (!this._started) return;
		    var signature = this._handshakeSignature();
		    if (!signature) return;

		    this._write(signature);
		    this._stage = 0;
		    this._open();

		    if (this._body.length > this.BODY_SIZE)
		      this.parse(this._body.slice(this.BODY_SIZE));
		  },

		  _parseLeadingByte: function(octet) {
		    if (octet !== 0xFF)
		      return Draft75.prototype._parseLeadingByte.call(this, octet);

		    this._closing = true;
		    this._length  = 0;
		    this._stage   = 1;
		  }
		};

		for (var key in instance)
		  Draft76.prototype[key] = instance[key];

		draft76 = Draft76;
		return draft76;
	}

	var server;
	var hasRequiredServer;

	function requireServer () {
		if (hasRequiredServer) return server;
		hasRequiredServer = 1;

		var util       = require$$0$3,
		    HttpParser = requireHttp_parser(),
		    Base       = requireBase(),
		    Draft75    = requireDraft75(),
		    Draft76    = requireDraft76(),
		    Hybi       = requireHybi();

		var Server = function(options) {
		  Base.call(this, null, null, options);
		  this._http = new HttpParser('request');
		};
		util.inherits(Server, Base);

		var instance = {
		  EVENTS: ['open', 'message', 'error', 'close', 'ping', 'pong'],

		  _bindEventListeners: function() {
		    this.messages.on('error', function() {});
		    this.on('error', function() {});
		  },

		  parse: function(chunk) {
		    if (this._delegate) return this._delegate.parse(chunk);

		    this._http.parse(chunk);
		    if (!this._http.isComplete()) return;

		    this.method  = this._http.method;
		    this.url     = this._http.url;
		    this.headers = this._http.headers;
		    this.body    = this._http.body;

		    var self = this;
		    this._delegate = Server.http(this, this._options);
		    this._delegate.messages = this.messages;
		    this._delegate.io = this.io;
		    this._open();

		    this.EVENTS.forEach(function(event) {
		      this._delegate.on(event, function(e) { self.emit(event, e); });
		    }, this);

		    this.protocol = this._delegate.protocol;
		    this.version  = this._delegate.version;

		    this.parse(this._http.body);
		    this.emit('connect', new Base.ConnectEvent());
		  },

		  _open: function() {
		    this.__queue.forEach(function(msg) {
		      this._delegate[msg[0]].apply(this._delegate, msg[1]);
		    }, this);
		    this.__queue = [];
		  }
		};

		['addExtension', 'setHeader', 'start', 'frame', 'text', 'binary', 'ping', 'close'].forEach(function(method) {
		  instance[method] = function() {
		    if (this._delegate) {
		      return this._delegate[method].apply(this._delegate, arguments);
		    } else {
		      this.__queue.push([method, arguments]);
		      return true;
		    }
		  };
		});

		for (var key in instance)
		  Server.prototype[key] = instance[key];

		Server.isSecureRequest = function(request) {
		  if (request.connection && request.connection.authorized !== undefined) return true;
		  if (request.socket && request.socket.secure) return true;

		  var headers = request.headers;
		  if (!headers) return false;
		  if (headers['https'] === 'on') return true;
		  if (headers['x-forwarded-ssl'] === 'on') return true;
		  if (headers['x-forwarded-scheme'] === 'https') return true;
		  if (headers['x-forwarded-proto'] === 'https') return true;

		  return false;
		};

		Server.determineUrl = function(request) {
		  var scheme = this.isSecureRequest(request) ? 'wss:' : 'ws:';
		  return scheme + '//' + request.headers.host + request.url;
		};

		Server.http = function(request, options) {
		  options = options || {};
		  if (options.requireMasking === undefined) options.requireMasking = true;

		  var headers = request.headers,
		      version = headers['sec-websocket-version'],
		      key     = headers['sec-websocket-key'],
		      key1    = headers['sec-websocket-key1'],
		      key2    = headers['sec-websocket-key2'],
		      url     = this.determineUrl(request);

		  if (version || key)
		    return new Hybi(request, url, options);
		  else if (key1 || key2)
		    return new Draft76(request, url, options);
		  else
		    return new Draft75(request, url, options);
		};

		server = Server;
		return server;
	}

	var driver;
	var hasRequiredDriver;

	function requireDriver () {
		if (hasRequiredDriver) return driver;
		hasRequiredDriver = 1;

		// Protocol references:
		//
		// * http://tools.ietf.org/html/draft-hixie-thewebsocketprotocol-75
		// * http://tools.ietf.org/html/draft-hixie-thewebsocketprotocol-76
		// * http://tools.ietf.org/html/draft-ietf-hybi-thewebsocketprotocol-17

		var Base   = requireBase(),
		    Client = requireClient$1(),
		    Server = requireServer();

		var Driver = {
		  client: function(url, options) {
		    options = options || {};
		    if (options.masking === undefined) options.masking = true;
		    return new Client(url, options);
		  },

		  server: function(options) {
		    options = options || {};
		    if (options.requireMasking === undefined) options.requireMasking = true;
		    return new Server(options);
		  },

		  http: function() {
		    return Server.http.apply(Server, arguments);
		  },

		  isSecureRequest: function(request) {
		    return Server.isSecureRequest(request);
		  },

		  isWebSocket: function(request) {
		    return Base.isWebSocket(request);
		  },

		  validateOptions: function(options, validKeys) {
		    Base.validateOptions(options, validKeys);
		  }
		};

		driver = Driver;
		return driver;
	}

	var event;
	var hasRequiredEvent;

	function requireEvent () {
		if (hasRequiredEvent) return event;
		hasRequiredEvent = 1;

		var Event = function(eventType, options) {
		  this.type = eventType;
		  for (var key in options)
		    this[key] = options[key];
		};

		Event.prototype.initEvent = function(eventType, canBubble, cancelable) {
		  this.type       = eventType;
		  this.bubbles    = canBubble;
		  this.cancelable = cancelable;
		};

		Event.prototype.stopPropagation = function() {};
		Event.prototype.preventDefault  = function() {};

		Event.CAPTURING_PHASE = 1;
		Event.AT_TARGET       = 2;
		Event.BUBBLING_PHASE  = 3;

		event = Event;
		return event;
	}

	var event_target;
	var hasRequiredEvent_target;

	function requireEvent_target () {
		if (hasRequiredEvent_target) return event_target;
		hasRequiredEvent_target = 1;

		var Event = requireEvent();

		var EventTarget = {
		  onopen:     null,
		  onmessage:  null,
		  onerror:    null,
		  onclose:    null,

		  addEventListener: function(eventType, listener, useCapture) {
		    this.on(eventType, listener);
		  },

		  removeEventListener: function(eventType, listener, useCapture) {
		    this.removeListener(eventType, listener);
		  },

		  dispatchEvent: function(event) {
		    event.target = event.currentTarget = this;
		    event.eventPhase = Event.AT_TARGET;

		    if (this['on' + event.type])
		      this['on' + event.type](event);

		    this.emit(event.type, event);
		  }
		};

		event_target = EventTarget;
		return event_target;
	}

	var api;
	var hasRequiredApi;

	function requireApi () {
		if (hasRequiredApi) return api;
		hasRequiredApi = 1;

		var Stream      = require$$0$1.Stream,
		    util        = require$$0$3,
		    driver      = requireDriver(),
		    EventTarget = requireEvent_target(),
		    Event       = requireEvent();

		var API = function(options) {
		  options = options || {};
		  driver.validateOptions(options, ['headers', 'extensions', 'maxLength', 'ping', 'proxy', 'tls', 'ca']);

		  this.readable = this.writable = true;

		  var headers = options.headers;
		  if (headers) {
		    for (var name in headers) this._driver.setHeader(name, headers[name]);
		  }

		  var extensions = options.extensions;
		  if (extensions) {
		    [].concat(extensions).forEach(this._driver.addExtension, this._driver);
		  }

		  this._ping          = options.ping;
		  this._pingId        = 0;
		  this.readyState     = API.CONNECTING;
		  this.bufferedAmount = 0;
		  this.protocol       = '';
		  this.url            = this._driver.url;
		  this.version        = this._driver.version;

		  var self = this;

		  this._driver.on('open',    function(e) { self._open(); });
		  this._driver.on('message', function(e) { self._receiveMessage(e.data); });
		  this._driver.on('close',   function(e) { self._beginClose(e.reason, e.code); });

		  this._driver.on('error', function(error) {
		    self._emitError(error.message);
		  });
		  this.on('error', function() {});

		  this._driver.messages.on('drain', function() {
		    self.emit('drain');
		  });

		  if (this._ping)
		    this._pingTimer = setInterval(function() {
		      self._pingId += 1;
		      self.ping(self._pingId.toString());
		    }, this._ping * 1000);

		  this._configureStream();

		  if (!this._proxy) {
		    this._stream.pipe(this._driver.io);
		    this._driver.io.pipe(this._stream);
		  }
		};
		util.inherits(API, Stream);

		API.CONNECTING = 0;
		API.OPEN       = 1;
		API.CLOSING    = 2;
		API.CLOSED     = 3;

		API.CLOSE_TIMEOUT = 30000;

		var instance = {
		  write: function(data) {
		    return this.send(data);
		  },

		  end: function(data) {
		    if (data !== undefined) this.send(data);
		    this.close();
		  },

		  pause: function() {
		    return this._driver.messages.pause();
		  },

		  resume: function() {
		    return this._driver.messages.resume();
		  },

		  send: function(data) {
		    if (this.readyState > API.OPEN) return false;
		    if (!(data instanceof Buffer)) data = String(data);
		    return this._driver.messages.write(data);
		  },

		  ping: function(message, callback) {
		    if (this.readyState > API.OPEN) return false;
		    return this._driver.ping(message, callback);
		  },

		  close: function(code, reason) {
		    if (code === undefined) code = 1000;
		    if (reason === undefined) reason = '';

		    if (code !== 1000 && (code < 3000 || code > 4999))
		      throw new Error("Failed to execute 'close' on WebSocket: " +
		                      "The code must be either 1000, or between 3000 and 4999. " +
		                      code + " is neither.");

		    if (this.readyState < API.CLOSING) {
		      var self = this;
		      this._closeTimer = setTimeout(function() {
		        self._beginClose('', 1006);
		      }, API.CLOSE_TIMEOUT);
		    }

		    if (this.readyState !== API.CLOSED) this.readyState = API.CLOSING;

		    this._driver.close(reason, code);
		  },

		  _configureStream: function() {
		    var self = this;

		    this._stream.setTimeout(0);
		    this._stream.setNoDelay(true);

		    ['close', 'end'].forEach(function(event) {
		      this._stream.on(event, function() { self._finalizeClose(); });
		    }, this);

		    this._stream.on('error', function(error) {
		      self._emitError('Network error: ' + self.url + ': ' + error.message);
		      self._finalizeClose();
		    });
		  },

		  _open: function() {
		    if (this.readyState !== API.CONNECTING) return;

		    this.readyState = API.OPEN;
		    this.protocol = this._driver.protocol || '';

		    var event = new Event('open');
		    event.initEvent('open', false, false);
		    this.dispatchEvent(event);
		  },

		  _receiveMessage: function(data) {
		    if (this.readyState > API.OPEN) return false;

		    if (this.readable) this.emit('data', data);

		    var event = new Event('message', { data: data });
		    event.initEvent('message', false, false);
		    this.dispatchEvent(event);
		  },

		  _emitError: function(message) {
		    if (this.readyState >= API.CLOSING) return;

		    var event = new Event('error', { message: message });
		    event.initEvent('error', false, false);
		    this.dispatchEvent(event);
		  },

		  _beginClose: function(reason, code) {
		    if (this.readyState === API.CLOSED) return;
		    this.readyState = API.CLOSING;
		    this._closeParams = [reason, code];

		    if (this._stream) {
		      this._stream.destroy();
		      if (!this._stream.readable) this._finalizeClose();
		    }
		  },

		  _finalizeClose: function() {
		    if (this.readyState === API.CLOSED) return;
		    this.readyState = API.CLOSED;

		    if (this._closeTimer) clearTimeout(this._closeTimer);
		    if (this._pingTimer) clearInterval(this._pingTimer);
		    if (this._stream) this._stream.end();

		    if (this.readable) this.emit('end');
		    this.readable = this.writable = false;

		    var reason = this._closeParams ? this._closeParams[0] : '',
		        code   = this._closeParams ? this._closeParams[1] : 1006;

		    var event = new Event('close', { code: code, reason: reason });
		    event.initEvent('close', false, false);
		    this.dispatchEvent(event);
		  }
		};

		for (var method in instance) API.prototype[method] = instance[method];
		for (var key in EventTarget) API.prototype[key] = EventTarget[key];

		api = API;
		return api;
	}

	var client;
	var hasRequiredClient;

	function requireClient () {
		if (hasRequiredClient) return client;
		hasRequiredClient = 1;

		var util   = require$$0$3,
		    net    = require$$1$2,
		    tls    = require$$1$2,
		    url    = require$$3$1,
		    driver = requireDriver(),
		    API    = requireApi();
		    requireEvent();

		var DEFAULT_PORTS    = { 'http:': 80, 'https:': 443, 'ws:':80, 'wss:': 443 },
		    SECURE_PROTOCOLS = ['https:', 'wss:'];

		var Client = function(_url, protocols, options) {
		  options = options || {};

		  this.url     = _url;
		  this._driver = driver.client(this.url, { maxLength: options.maxLength, protocols: protocols });

		  ['open', 'error'].forEach(function(event) {
		    this._driver.on(event, function() {
		      self.headers    = self._driver.headers;
		      self.statusCode = self._driver.statusCode;
		    });
		  }, this);

		  var proxy      = options.proxy || {},
		      endpoint   = url.parse(proxy.origin || this.url),
		      port       = endpoint.port || DEFAULT_PORTS[endpoint.protocol],
		      secure     = SECURE_PROTOCOLS.indexOf(endpoint.protocol) >= 0,
		      onConnect  = function() { self._onConnect(); },
		      netOptions = options.net || {},
		      originTLS  = options.tls || {},
		      socketTLS  = proxy.origin ? (proxy.tls || {}) : originTLS,
		      self       = this;

		  netOptions.host = socketTLS.host = endpoint.hostname;
		  netOptions.port = socketTLS.port = port;

		  originTLS.ca = originTLS.ca || options.ca;
		  socketTLS.servername = socketTLS.servername || endpoint.hostname;

		  this._stream = secure
		               ? tls.connect(socketTLS, onConnect)
		               : net.connect(netOptions, onConnect);

		  if (proxy.origin) this._configureProxy(proxy, originTLS);

		  API.call(this, options);
		};
		util.inherits(Client, API);

		Client.prototype._onConnect = function() {
		  var worker = this._proxy || this._driver;
		  worker.start();
		};

		Client.prototype._configureProxy = function(proxy, originTLS) {
		  var uri    = url.parse(this.url),
		      secure = SECURE_PROTOCOLS.indexOf(uri.protocol) >= 0,
		      self   = this,
		      name;

		  this._proxy = this._driver.proxy(proxy.origin);

		  if (proxy.headers) {
		    for (name in proxy.headers) this._proxy.setHeader(name, proxy.headers[name]);
		  }

		  this._proxy.pipe(this._stream, { end: false });
		  this._stream.pipe(this._proxy);

		  this._proxy.on('connect', function() {
		    if (secure) {
		      var options = { socket: self._stream, servername: uri.hostname };
		      for (name in originTLS) options[name] = originTLS[name];
		      self._stream = tls.connect(options);
		      self._configureStream();
		    }
		    self._driver.io.pipe(self._stream);
		    self._stream.pipe(self._driver.io);
		    self._driver.start();
		  });

		  this._proxy.on('error', function(error) {
		    self._driver.emit('error', error);
		  });
		};

		client = Client;
		return client;
	}

	var eventsource;
	var hasRequiredEventsource;

	function requireEventsource () {
		if (hasRequiredEventsource) return eventsource;
		hasRequiredEventsource = 1;

		var Stream      = require$$0$1.Stream,
		    util        = require$$0$3,
		    driver      = requireDriver(),
		    Headers     = requireHeaders(),
		    API         = requireApi(),
		    EventTarget = requireEvent_target(),
		    Event       = requireEvent();

		var EventSource = function(request, response, options) {
		  this.writable = true;
		  options = options || {};

		  this._stream = response.socket;
		  this._ping   = options.ping  || this.DEFAULT_PING;
		  this._retry  = options.retry || this.DEFAULT_RETRY;

		  var scheme       = driver.isSecureRequest(request) ? 'https:' : 'http:';
		  this.url         = scheme + '//' + request.headers.host + request.url;
		  this.lastEventId = request.headers['last-event-id'] || '';
		  this.readyState  = API.CONNECTING;

		  var headers = new Headers(),
		      self    = this;

		  if (options.headers) {
		    for (var key in options.headers) headers.set(key, options.headers[key]);
		  }

		  if (!this._stream || !this._stream.writable) return;
		  process.nextTick(function() { self._open(); });

		  this._stream.setTimeout(0);
		  this._stream.setNoDelay(true);

		  var handshake = 'HTTP/1.1 200 OK\r\n' +
		                  'Content-Type: text/event-stream\r\n' +
		                  'Cache-Control: no-cache, no-store\r\n' +
		                  'Connection: close\r\n' +
		                  headers.toString() +
		                  '\r\n' +
		                  'retry: ' + Math.floor(this._retry * 1000) + '\r\n\r\n';

		  this._write(handshake);

		  this._stream.on('drain', function() { self.emit('drain'); });

		  if (this._ping)
		    this._pingTimer = setInterval(function() { self.ping(); }, this._ping * 1000);

		  ['error', 'end'].forEach(function(event) {
		    self._stream.on(event, function() { self.close(); });
		  });
		};
		util.inherits(EventSource, Stream);

		EventSource.isEventSource = function(request) {
		  if (request.method !== 'GET') return false;
		  var accept = (request.headers.accept || '').split(/\s*,\s*/);
		  return accept.indexOf('text/event-stream') >= 0;
		};

		var instance = {
		  DEFAULT_PING:   10,
		  DEFAULT_RETRY:  5,

		  _write: function(chunk) {
		    if (!this.writable) return false;
		    try {
		      return this._stream.write(chunk, 'utf8');
		    } catch (e) {
		      return false;
		    }
		  },

		  _open: function() {
		    if (this.readyState !== API.CONNECTING) return;

		    this.readyState = API.OPEN;

		    var event = new Event('open');
		    event.initEvent('open', false, false);
		    this.dispatchEvent(event);
		  },

		  write: function(message) {
		    return this.send(message);
		  },

		  end: function(message) {
		    if (message !== undefined) this.write(message);
		    this.close();
		  },

		  send: function(message, options) {
		    if (this.readyState > API.OPEN) return false;

		    message = String(message).replace(/(\r\n|\r|\n)/g, '$1data: ');
		    options = options || {};

		    var frame = '';
		    if (options.event) frame += 'event: ' + options.event + '\r\n';
		    if (options.id)    frame += 'id: '    + options.id    + '\r\n';
		    frame += 'data: ' + message + '\r\n\r\n';

		    return this._write(frame);
		  },

		  ping: function() {
		    return this._write(':\r\n\r\n');
		  },

		  close: function() {
		    if (this.readyState > API.OPEN) return false;

		    this.readyState = API.CLOSED;
		    this.writable = false;
		    if (this._pingTimer) clearInterval(this._pingTimer);
		    if (this._stream) this._stream.end();

		    var event = new Event('close');
		    event.initEvent('close', false, false);
		    this.dispatchEvent(event);

		    return true;
		  }
		};

		for (var method in instance) EventSource.prototype[method] = instance[method];
		for (var key in EventTarget) EventSource.prototype[key] = EventTarget[key];

		eventsource = EventSource;
		return eventsource;
	}

	var websocket;
	var hasRequiredWebsocket;

	function requireWebsocket () {
		if (hasRequiredWebsocket) return websocket;
		hasRequiredWebsocket = 1;

		var util   = require$$0$3,
		    driver = requireDriver(),
		    API    = requireApi();

		var WebSocket = function(request, socket, body, protocols, options) {
		  options = options || {};

		  this._stream = socket;
		  this._driver = driver.http(request, { maxLength: options.maxLength, protocols: protocols });

		  var self = this;
		  if (!this._stream || !this._stream.writable) return;
		  if (!this._stream.readable) return this._stream.end();

		  var catchup = function() { self._stream.removeListener('data', catchup); };
		  this._stream.on('data', catchup);

		  API.call(this, options);

		  process.nextTick(function() {
		    self._driver.start();
		    self._driver.io.write(body);
		  });
		};
		util.inherits(WebSocket, API);

		WebSocket.isWebSocket = function(request) {
		  return driver.isWebSocket(request);
		};

		WebSocket.validateOptions = function(options, validKeys) {
		  driver.validateOptions(options, validKeys);
		};

		WebSocket.WebSocket   = WebSocket;
		WebSocket.Client      = requireClient();
		WebSocket.EventSource = requireEventsource();

		websocket        = WebSocket;
		return websocket;
	}

	var transport = {};

	// Unique ID creation requires a high quality random # generator. In the browser we therefore
	// require the crypto API and do not support built-in fallback to lower quality random number
	// generators (like Math.random()).

	var getRandomValues;
	var rnds8 = new Uint8Array(16);
	function rng() {
	  // lazy load so that environments that need to polyfill have a chance to do so
	  if (!getRandomValues) {
	    // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation. Also,
	    // find the complete implementation of crypto (msCrypto) on IE11.
	    getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto !== 'undefined' && typeof msCrypto.getRandomValues === 'function' && msCrypto.getRandomValues.bind(msCrypto);
	    if (!getRandomValues) {
	      throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
	    }
	  }
	  return getRandomValues(rnds8);
	}

	var REGEX = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;

	function validate(uuid) {
	  return typeof uuid === 'string' && REGEX.test(uuid);
	}

	/**
	 * Convert array of 16 byte values to UUID string format of the form:
	 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
	 */
	var byteToHex = [];
	for (var i = 0; i < 256; ++i) {
	  byteToHex.push((i + 0x100).toString(16).substr(1));
	}
	function stringify(arr) {
	  var offset = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
	  // Note: Be careful editing this code!  It's been tuned for performance
	  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
	  var uuid = (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();

	  // Consistency check for valid UUID.  If this throws, it's likely due to one
	  // of the following:
	  // - One or more input array values don't map to a hex octet (leading to
	  // "undefined" in the uuid)
	  // - Invalid input values for the RFC `version` or `variant` fields
	  if (!validate(uuid)) {
	    throw TypeError('Stringified UUID is invalid');
	  }
	  return uuid;
	}

	// **`v1()` - Generate time-based UUID**
	//
	// Inspired by https://github.com/LiosK/UUID.js
	// and http://docs.python.org/library/uuid.html

	var _nodeId;
	var _clockseq;

	// Previous uuid creation time
	var _lastMSecs = 0;
	var _lastNSecs = 0;

	// See https://github.com/uuidjs/uuid for API details
	function v1(options, buf, offset) {
	  var i = buf && offset || 0;
	  var b = buf || new Array(16);
	  options = options || {};
	  var node = options.node || _nodeId;
	  var clockseq = options.clockseq !== undefined ? options.clockseq : _clockseq;

	  // node and clockseq need to be initialized to random values if they're not
	  // specified.  We do this lazily to minimize issues related to insufficient
	  // system entropy.  See #189
	  if (node == null || clockseq == null) {
	    var seedBytes = options.random || (options.rng || rng)();
	    if (node == null) {
	      // Per 4.5, create and 48-bit node id, (47 random bits + multicast bit = 1)
	      node = _nodeId = [seedBytes[0] | 0x01, seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
	    }
	    if (clockseq == null) {
	      // Per 4.2.2, randomize (14 bit) clockseq
	      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 0x3fff;
	    }
	  }

	  // UUID timestamps are 100 nano-second units since the Gregorian epoch,
	  // (1582-10-15 00:00).  JSNumbers aren't precise enough for this, so
	  // time is handled internally as 'msecs' (integer milliseconds) and 'nsecs'
	  // (100-nanoseconds offset from msecs) since unix epoch, 1970-01-01 00:00.
	  var msecs = options.msecs !== undefined ? options.msecs : Date.now();

	  // Per 4.2.1.2, use count of uuid's generated during the current clock
	  // cycle to simulate higher resolution clock
	  var nsecs = options.nsecs !== undefined ? options.nsecs : _lastNSecs + 1;

	  // Time since last uuid creation (in msecs)
	  var dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 10000;

	  // Per 4.2.1.2, Bump clockseq on clock regression
	  if (dt < 0 && options.clockseq === undefined) {
	    clockseq = clockseq + 1 & 0x3fff;
	  }

	  // Reset nsecs if clock regresses (new clockseq) or we've moved onto a new
	  // time interval
	  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === undefined) {
	    nsecs = 0;
	  }

	  // Per 4.2.1.2 Throw error if too many uuids are requested
	  if (nsecs >= 10000) {
	    throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
	  }
	  _lastMSecs = msecs;
	  _lastNSecs = nsecs;
	  _clockseq = clockseq;

	  // Per 4.1.4 - Convert from unix epoch to Gregorian epoch
	  msecs += 12219292800000;

	  // `time_low`
	  var tl = ((msecs & 0xfffffff) * 10000 + nsecs) % 0x100000000;
	  b[i++] = tl >>> 24 & 0xff;
	  b[i++] = tl >>> 16 & 0xff;
	  b[i++] = tl >>> 8 & 0xff;
	  b[i++] = tl & 0xff;

	  // `time_mid`
	  var tmh = msecs / 0x100000000 * 10000 & 0xfffffff;
	  b[i++] = tmh >>> 8 & 0xff;
	  b[i++] = tmh & 0xff;

	  // `time_high_and_version`
	  b[i++] = tmh >>> 24 & 0xf | 0x10; // include version
	  b[i++] = tmh >>> 16 & 0xff;

	  // `clock_seq_hi_and_reserved` (Per 4.2.2 - include variant)
	  b[i++] = clockseq >>> 8 | 0x80;

	  // `clock_seq_low`
	  b[i++] = clockseq & 0xff;

	  // `node`
	  for (var n = 0; n < 6; ++n) {
	    b[i + n] = node[n];
	  }
	  return buf || stringify(b);
	}

	function parse(uuid) {
	  if (!validate(uuid)) {
	    throw TypeError('Invalid UUID');
	  }
	  var v;
	  var arr = new Uint8Array(16);

	  // Parse ########-....-....-....-............
	  arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
	  arr[1] = v >>> 16 & 0xff;
	  arr[2] = v >>> 8 & 0xff;
	  arr[3] = v & 0xff;

	  // Parse ........-####-....-....-............
	  arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
	  arr[5] = v & 0xff;

	  // Parse ........-....-####-....-............
	  arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
	  arr[7] = v & 0xff;

	  // Parse ........-....-....-####-............
	  arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
	  arr[9] = v & 0xff;

	  // Parse ........-....-....-....-############
	  // (Use "/" to avoid 32-bit truncation when bit-shifting high-order bytes)
	  arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 0x10000000000 & 0xff;
	  arr[11] = v / 0x100000000 & 0xff;
	  arr[12] = v >>> 24 & 0xff;
	  arr[13] = v >>> 16 & 0xff;
	  arr[14] = v >>> 8 & 0xff;
	  arr[15] = v & 0xff;
	  return arr;
	}

	function stringToBytes(str) {
	  str = unescape(encodeURIComponent(str)); // UTF8 escape

	  var bytes = [];
	  for (var i = 0; i < str.length; ++i) {
	    bytes.push(str.charCodeAt(i));
	  }
	  return bytes;
	}
	var DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
	var URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';
	function v35 (name, version, hashfunc) {
	  function generateUUID(value, namespace, buf, offset) {
	    if (typeof value === 'string') {
	      value = stringToBytes(value);
	    }
	    if (typeof namespace === 'string') {
	      namespace = parse(namespace);
	    }
	    if (namespace.length !== 16) {
	      throw TypeError('Namespace must be array-like (16 iterable integer values, 0-255)');
	    }

	    // Compute hash of namespace and value, Per 4.3
	    // Future: Use spread syntax when supported on all platforms, e.g. `bytes =
	    // hashfunc([...namespace, ... value])`
	    var bytes = new Uint8Array(16 + value.length);
	    bytes.set(namespace);
	    bytes.set(value, namespace.length);
	    bytes = hashfunc(bytes);
	    bytes[6] = bytes[6] & 0x0f | version;
	    bytes[8] = bytes[8] & 0x3f | 0x80;
	    if (buf) {
	      offset = offset || 0;
	      for (var i = 0; i < 16; ++i) {
	        buf[offset + i] = bytes[i];
	      }
	      return buf;
	    }
	    return stringify(bytes);
	  }

	  // Function#name is not settable on some platforms (#270)
	  try {
	    generateUUID.name = name;
	    // eslint-disable-next-line no-empty
	  } catch (err) {}

	  // For CommonJS default export support
	  generateUUID.DNS = DNS;
	  generateUUID.URL = URL;
	  return generateUUID;
	}

	/*
	 * Browser-compatible JavaScript MD5
	 *
	 * Modification of JavaScript MD5
	 * https://github.com/blueimp/JavaScript-MD5
	 *
	 * Copyright 2011, Sebastian Tschan
	 * https://blueimp.net
	 *
	 * Licensed under the MIT license:
	 * https://opensource.org/licenses/MIT
	 *
	 * Based on
	 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
	 * Digest Algorithm, as defined in RFC 1321.
	 * Version 2.2 Copyright (C) Paul Johnston 1999 - 2009
	 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
	 * Distributed under the BSD License
	 * See http://pajhome.org.uk/crypt/md5 for more info.
	 */
	function md5(bytes) {
	  if (typeof bytes === 'string') {
	    var msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

	    bytes = new Uint8Array(msg.length);
	    for (var i = 0; i < msg.length; ++i) {
	      bytes[i] = msg.charCodeAt(i);
	    }
	  }
	  return md5ToHexEncodedArray(wordsToMd5(bytesToWords(bytes), bytes.length * 8));
	}

	/*
	 * Convert an array of little-endian words to an array of bytes
	 */
	function md5ToHexEncodedArray(input) {
	  var output = [];
	  var length32 = input.length * 32;
	  var hexTab = '0123456789abcdef';
	  for (var i = 0; i < length32; i += 8) {
	    var x = input[i >> 5] >>> i % 32 & 0xff;
	    var hex = parseInt(hexTab.charAt(x >>> 4 & 0x0f) + hexTab.charAt(x & 0x0f), 16);
	    output.push(hex);
	  }
	  return output;
	}

	/**
	 * Calculate output length with padding and bit length
	 */
	function getOutputLength(inputLength8) {
	  return (inputLength8 + 64 >>> 9 << 4) + 14 + 1;
	}

	/*
	 * Calculate the MD5 of an array of little-endian words, and a bit length.
	 */
	function wordsToMd5(x, len) {
	  /* append padding */
	  x[len >> 5] |= 0x80 << len % 32;
	  x[getOutputLength(len) - 1] = len;
	  var a = 1732584193;
	  var b = -271733879;
	  var c = -1732584194;
	  var d = 271733878;
	  for (var i = 0; i < x.length; i += 16) {
	    var olda = a;
	    var oldb = b;
	    var oldc = c;
	    var oldd = d;
	    a = md5ff(a, b, c, d, x[i], 7, -680876936);
	    d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
	    c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
	    b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
	    a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
	    d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
	    c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
	    b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
	    a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
	    d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
	    c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
	    b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
	    a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
	    d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
	    c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
	    b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
	    a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
	    d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
	    c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
	    b = md5gg(b, c, d, a, x[i], 20, -373897302);
	    a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
	    d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
	    c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
	    b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
	    a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
	    d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
	    c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
	    b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
	    a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
	    d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
	    c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
	    b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
	    a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
	    d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
	    c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
	    b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
	    a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
	    d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
	    c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
	    b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
	    a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
	    d = md5hh(d, a, b, c, x[i], 11, -358537222);
	    c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
	    b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
	    a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
	    d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
	    c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
	    b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
	    a = md5ii(a, b, c, d, x[i], 6, -198630844);
	    d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
	    c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
	    b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
	    a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
	    d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
	    c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
	    b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
	    a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
	    d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
	    c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
	    b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
	    a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
	    d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
	    c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
	    b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
	    a = safeAdd(a, olda);
	    b = safeAdd(b, oldb);
	    c = safeAdd(c, oldc);
	    d = safeAdd(d, oldd);
	  }
	  return [a, b, c, d];
	}

	/*
	 * Convert an array bytes to an array of little-endian words
	 * Characters >255 have their high-byte silently ignored.
	 */
	function bytesToWords(input) {
	  if (input.length === 0) {
	    return [];
	  }
	  var length8 = input.length * 8;
	  var output = new Uint32Array(getOutputLength(length8));
	  for (var i = 0; i < length8; i += 8) {
	    output[i >> 5] |= (input[i / 8] & 0xff) << i % 32;
	  }
	  return output;
	}

	/*
	 * Add integers, wrapping at 2^32. This uses 16-bit operations internally
	 * to work around bugs in some JS interpreters.
	 */
	function safeAdd(x, y) {
	  var lsw = (x & 0xffff) + (y & 0xffff);
	  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
	  return msw << 16 | lsw & 0xffff;
	}

	/*
	 * Bitwise rotate a 32-bit number to the left.
	 */
	function bitRotateLeft(num, cnt) {
	  return num << cnt | num >>> 32 - cnt;
	}

	/*
	 * These functions implement the four basic operations the algorithm uses.
	 */
	function md5cmn(q, a, b, x, s, t) {
	  return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
	}
	function md5ff(a, b, c, d, x, s, t) {
	  return md5cmn(b & c | ~b & d, a, b, x, s, t);
	}
	function md5gg(a, b, c, d, x, s, t) {
	  return md5cmn(b & d | c & ~d, a, b, x, s, t);
	}
	function md5hh(a, b, c, d, x, s, t) {
	  return md5cmn(b ^ c ^ d, a, b, x, s, t);
	}
	function md5ii(a, b, c, d, x, s, t) {
	  return md5cmn(c ^ (b | ~d), a, b, x, s, t);
	}

	var v3 = v35('v3', 0x30, md5);
	var v3$1 = v3;

	function v4(options, buf, offset) {
	  options = options || {};
	  var rnds = options.random || (options.rng || rng)();

	  // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
	  rnds[6] = rnds[6] & 0x0f | 0x40;
	  rnds[8] = rnds[8] & 0x3f | 0x80;

	  // Copy bytes to buffer, if provided
	  if (buf) {
	    offset = offset || 0;
	    for (var i = 0; i < 16; ++i) {
	      buf[offset + i] = rnds[i];
	    }
	    return buf;
	  }
	  return stringify(rnds);
	}

	// Adapted from Chris Veness' SHA1 code at
	// http://www.movable-type.co.uk/scripts/sha1.html
	function f(s, x, y, z) {
	  switch (s) {
	    case 0:
	      return x & y ^ ~x & z;
	    case 1:
	      return x ^ y ^ z;
	    case 2:
	      return x & y ^ x & z ^ y & z;
	    case 3:
	      return x ^ y ^ z;
	  }
	}
	function ROTL(x, n) {
	  return x << n | x >>> 32 - n;
	}
	function sha1(bytes) {
	  var K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];
	  var H = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];
	  if (typeof bytes === 'string') {
	    var msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

	    bytes = [];
	    for (var i = 0; i < msg.length; ++i) {
	      bytes.push(msg.charCodeAt(i));
	    }
	  } else if (!Array.isArray(bytes)) {
	    // Convert Array-like to Array
	    bytes = Array.prototype.slice.call(bytes);
	  }
	  bytes.push(0x80);
	  var l = bytes.length / 4 + 2;
	  var N = Math.ceil(l / 16);
	  var M = new Array(N);
	  for (var _i = 0; _i < N; ++_i) {
	    var arr = new Uint32Array(16);
	    for (var j = 0; j < 16; ++j) {
	      arr[j] = bytes[_i * 64 + j * 4] << 24 | bytes[_i * 64 + j * 4 + 1] << 16 | bytes[_i * 64 + j * 4 + 2] << 8 | bytes[_i * 64 + j * 4 + 3];
	    }
	    M[_i] = arr;
	  }
	  M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
	  M[N - 1][14] = Math.floor(M[N - 1][14]);
	  M[N - 1][15] = (bytes.length - 1) * 8 & 0xffffffff;
	  for (var _i2 = 0; _i2 < N; ++_i2) {
	    var W = new Uint32Array(80);
	    for (var t = 0; t < 16; ++t) {
	      W[t] = M[_i2][t];
	    }
	    for (var _t = 16; _t < 80; ++_t) {
	      W[_t] = ROTL(W[_t - 3] ^ W[_t - 8] ^ W[_t - 14] ^ W[_t - 16], 1);
	    }
	    var a = H[0];
	    var b = H[1];
	    var c = H[2];
	    var d = H[3];
	    var e = H[4];
	    for (var _t2 = 0; _t2 < 80; ++_t2) {
	      var s = Math.floor(_t2 / 20);
	      var T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[_t2] >>> 0;
	      e = d;
	      d = c;
	      c = ROTL(b, 30) >>> 0;
	      b = a;
	      a = T;
	    }
	    H[0] = H[0] + a >>> 0;
	    H[1] = H[1] + b >>> 0;
	    H[2] = H[2] + c >>> 0;
	    H[3] = H[3] + d >>> 0;
	    H[4] = H[4] + e >>> 0;
	  }
	  return [H[0] >> 24 & 0xff, H[0] >> 16 & 0xff, H[0] >> 8 & 0xff, H[0] & 0xff, H[1] >> 24 & 0xff, H[1] >> 16 & 0xff, H[1] >> 8 & 0xff, H[1] & 0xff, H[2] >> 24 & 0xff, H[2] >> 16 & 0xff, H[2] >> 8 & 0xff, H[2] & 0xff, H[3] >> 24 & 0xff, H[3] >> 16 & 0xff, H[3] >> 8 & 0xff, H[3] & 0xff, H[4] >> 24 & 0xff, H[4] >> 16 & 0xff, H[4] >> 8 & 0xff, H[4] & 0xff];
	}

	var v5 = v35('v5', 0x50, sha1);
	var v5$1 = v5;

	var nil = '00000000-0000-0000-0000-000000000000';

	function version(uuid) {
	  if (!validate(uuid)) {
	    throw TypeError('Invalid UUID');
	  }
	  return parseInt(uuid.substr(14, 1), 16);
	}

	var esmBrowser = /*#__PURE__*/Object.freeze({
		__proto__: null,
		NIL: nil,
		parse: parse,
		stringify: stringify,
		v1: v1,
		v3: v3$1,
		v4: v4,
		v5: v5$1,
		validate: validate,
		version: version
	});

	var require$$1 = /*@__PURE__*/getAugmentedNamespace(esmBrowser);

	var hasRequiredTransport;

	function requireTransport () {
		if (hasRequiredTransport) return transport;
		hasRequiredTransport = 1;
		// Generated by CoffeeScript 1.12.7
		(function() {
		  var GenericReceiver, MAP, ResponseReceiver, Session, SockJSConnection, Transport, closeFrame, register, stream, utils, uuidv4,
		    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
		    hasProp = {}.hasOwnProperty;

		  stream = require$$0$1;

		  uuidv4 = require$$1.v4;

		  utils = requireUtils();

		  Transport = (function() {
		    function Transport() {}

		    return Transport;

		  })();

		  Transport.CONNECTING = 0;

		  Transport.OPEN = 1;

		  Transport.CLOSING = 2;

		  Transport.CLOSED = 3;

		  closeFrame = function(status, reason) {
		    return 'c' + JSON.stringify([status, reason]);
		  };

		  SockJSConnection = (function(superClass) {
		    extend(SockJSConnection, superClass);

		    function SockJSConnection(_session) {
		      this._session = _session;
		      this.id = uuidv4();
		      this.headers = {};
		      this.prefix = this._session.prefix;
		    }

		    SockJSConnection.prototype.toString = function() {
		      return '<SockJSConnection ' + this.id + '>';
		    };

		    SockJSConnection.prototype.write = function(string) {
		      return this._session.send('' + string);
		    };

		    SockJSConnection.prototype.end = function(string) {
		      if (string) {
		        this.write(string);
		      }
		      this.close();
		      return null;
		    };

		    SockJSConnection.prototype.close = function(code, reason) {
		      return this._session.close(code, reason);
		    };

		    SockJSConnection.prototype.destroy = function() {
		      this.end();
		      return this.removeAllListeners();
		    };

		    SockJSConnection.prototype.destroySoon = function() {
		      return this.destroy();
		    };

		    return SockJSConnection;

		  })(stream.Stream);

		  SockJSConnection.prototype.__defineGetter__('readable', function() {
		    return this._session.readyState === Transport.OPEN;
		  });

		  SockJSConnection.prototype.__defineGetter__('writable', function() {
		    return this._session.readyState === Transport.OPEN;
		  });

		  SockJSConnection.prototype.__defineGetter__('readyState', function() {
		    return this._session.readyState;
		  });

		  MAP = {};

		  Session = (function() {
		    function Session(session_id1, server) {
		      this.session_id = session_id1;
		      this.heartbeat_delay = server.options.heartbeat_delay;
		      this.disconnect_delay = server.options.disconnect_delay;
		      this.prefix = server.options.prefix;
		      this.send_buffer = [];
		      this.is_closing = false;
		      this.readyState = Transport.CONNECTING;
		      if (this.session_id) {
		        MAP[this.session_id] = this;
		      }
		      this.timeout_cb = (function(_this) {
		        return function() {
		          return _this.didTimeout();
		        };
		      })(this);
		      this.to_tref = setTimeout(this.timeout_cb, this.disconnect_delay);
		      this.connection = new SockJSConnection(this);
		      this.emit_open = (function(_this) {
		        return function() {
		          _this.emit_open = null;
		          return server.emit('connection', _this.connection);
		        };
		      })(this);
		    }

		    Session.prototype.register = function(req, recv) {
		      if (this.recv) {
		        recv.doSendFrame(closeFrame(2010, "Another connection still open"));
		        recv.didClose();
		        return;
		      }
		      if (this.to_tref) {
		        clearTimeout(this.to_tref);
		        this.to_tref = null;
		      }
		      if (this.readyState === Transport.CLOSING) {
		        this.flushToRecv(recv);
		        recv.doSendFrame(this.close_frame);
		        recv.didClose();
		        this.to_tref = setTimeout(this.timeout_cb, this.disconnect_delay);
		        return;
		      }
		      this.recv = recv;
		      this.recv.session = this;
		      this.decorateConnection(req);
		      if (this.readyState === Transport.CONNECTING) {
		        this.recv.doSendFrame('o');
		        this.readyState = Transport.OPEN;
		        process.nextTick(this.emit_open);
		      }
		      if (!this.recv) {
		        return;
		      }
		      this.tryFlush();
		    };

		    Session.prototype.decorateConnection = function(req) {
		      var address, headers, i, key, len, ref, remoteAddress, remotePort, socket;
		      if (!(socket = this.recv.connection)) {
		        socket = this.recv.response.connection;
		      }
		      try {
		        remoteAddress = socket.remoteAddress;
		        remotePort = socket.remotePort;
		        address = socket.address();
		      } catch (error) {
		      }
		      if (remoteAddress) {
		        this.connection.remoteAddress = remoteAddress;
		        this.connection.remotePort = remotePort;
		        this.connection.address = address;
		      }
		      this.connection.url = req.url;
		      this.connection.pathname = req.pathname;
		      this.connection.protocol = this.recv.protocol;
		      headers = {};
		      ref = ['referer', 'x-client-ip', 'x-forwarded-for', 'x-forwarded-host', 'x-forwarded-port', 'x-cluster-client-ip', 'via', 'x-real-ip', 'x-forwarded-proto', 'x-ssl', 'dnt', 'host', 'user-agent', 'accept-language'];
		      for (i = 0, len = ref.length; i < len; i++) {
		        key = ref[i];
		        if (req.headers[key]) {
		          headers[key] = req.headers[key];
		        }
		      }
		      if (headers) {
		        return this.connection.headers = headers;
		      }
		    };

		    Session.prototype.unregister = function() {
		      var delay;
		      delay = this.recv.delay_disconnect;
		      this.recv.session = null;
		      this.recv = null;
		      if (this.to_tref) {
		        clearTimeout(this.to_tref);
		      }
		      if (delay) {
		        return this.to_tref = setTimeout(this.timeout_cb, this.disconnect_delay);
		      } else {
		        return this.timeout_cb();
		      }
		    };

		    Session.prototype.flushToRecv = function(recv) {
		      var ref, sb;
		      if (this.send_buffer.length > 0) {
		        ref = [this.send_buffer, []], sb = ref[0], this.send_buffer = ref[1];
		        recv.doSendBulk(sb);
		        return true;
		      }
		      return false;
		    };

		    Session.prototype.tryFlush = function() {
		      var x;
		      if (!this.flushToRecv(this.recv) || !this.to_tref) {
		        if (this.to_tref) {
		          clearTimeout(this.to_tref);
		        }
		        x = (function(_this) {
		          return function() {
		            if (_this.recv) {
		              _this.to_tref = setTimeout(x, _this.heartbeat_delay);
		              return _this.recv.heartbeat();
		            }
		          };
		        })(this);
		        this.to_tref = setTimeout(x, this.heartbeat_delay);
		      }
		    };

		    Session.prototype.didTimeout = function() {
		      if (this.to_tref) {
		        clearTimeout(this.to_tref);
		        this.to_tref = null;
		      }
		      if (this.readyState !== Transport.CONNECTING && this.readyState !== Transport.OPEN && this.readyState !== Transport.CLOSING) {
		        throw Error('INVALID_STATE_ERR');
		      }
		      if (this.recv) {
		        throw Error('RECV_STILL_THERE');
		      }
		      this.readyState = Transport.CLOSED;
		      this.connection.emit('end');
		      this.connection.emit('close');
		      this.connection = null;
		      if (this.session_id) {
		        delete MAP[this.session_id];
		        return this.session_id = null;
		      }
		    };

		    Session.prototype.didMessage = function(payload) {
		      if (this.readyState === Transport.OPEN) {
		        this.connection.emit('data', payload);
		      }
		    };

		    Session.prototype.send = function(payload) {
		      if (this.readyState !== Transport.OPEN) {
		        return false;
		      }
		      this.send_buffer.push('' + payload);
		      if (this.recv) {
		        this.tryFlush();
		      }
		      return true;
		    };

		    Session.prototype.close = function(status, reason) {
		      if (status == null) {
		        status = 1000;
		      }
		      if (reason == null) {
		        reason = "Normal closure";
		      }
		      if (this.readyState !== Transport.OPEN) {
		        return false;
		      }
		      this.readyState = Transport.CLOSING;
		      this.close_frame = closeFrame(status, reason);
		      if (this.recv) {
		        this.recv.doSendFrame(this.close_frame);
		        if (this.recv) {
		          this.recv.didClose();
		        }
		        if (this.recv) {
		          this.unregister();
		        }
		      }
		      return true;
		    };

		    return Session;

		  })();

		  Session.bySessionId = function(session_id) {
		    if (!session_id) {
		      return null;
		    }
		    return MAP[session_id] || null;
		  };

		  register = function(req, server, session_id, receiver) {
		    var session;
		    session = Session.bySessionId(session_id);
		    if (!session) {
		      session = new Session(session_id, server);
		    }
		    session.register(req, receiver);
		    return session;
		  };

		  transport.register = function(req, server, receiver) {
		    return register(req, server, req.session, receiver);
		  };

		  transport.registerNoSession = function(req, server, receiver) {
		    return register(req, server, void 0, receiver);
		  };

		  GenericReceiver = (function() {
		    function GenericReceiver(thingy) {
		      this.thingy = thingy;
		      this.setUp(this.thingy);
		    }

		    GenericReceiver.prototype.setUp = function() {
		      this.thingy_end_cb = (function(_this) {
		        return function() {
		          return _this.didAbort();
		        };
		      })(this);
		      this.thingy.addListener('close', this.thingy_end_cb);
		      return this.thingy.addListener('end', this.thingy_end_cb);
		    };

		    GenericReceiver.prototype.tearDown = function() {
		      this.thingy.removeListener('close', this.thingy_end_cb);
		      this.thingy.removeListener('end', this.thingy_end_cb);
		      return this.thingy_end_cb = null;
		    };

		    GenericReceiver.prototype.didAbort = function() {
		      this.delay_disconnect = false;
		      return this.didClose();
		    };

		    GenericReceiver.prototype.didClose = function() {
		      if (this.thingy) {
		        this.tearDown(this.thingy);
		        this.thingy = null;
		      }
		      if (this.session) {
		        return this.session.unregister();
		      }
		    };

		    GenericReceiver.prototype.doSendBulk = function(messages) {
		      var m, q_msgs;
		      q_msgs = (function() {
		        var i, len, results;
		        results = [];
		        for (i = 0, len = messages.length; i < len; i++) {
		          m = messages[i];
		          results.push(utils.quote(m));
		        }
		        return results;
		      })();
		      return this.doSendFrame('a' + '[' + q_msgs.join(',') + ']');
		    };

		    GenericReceiver.prototype.heartbeat = function() {
		      return this.doSendFrame('h');
		    };

		    return GenericReceiver;

		  })();

		  ResponseReceiver = (function(superClass) {
		    extend(ResponseReceiver, superClass);

		    ResponseReceiver.prototype.max_response_size = void 0;

		    ResponseReceiver.prototype.delay_disconnect = true;

		    function ResponseReceiver(request, response, options) {
		      this.request = request;
		      this.response = response;
		      this.options = options;
		      this.curr_response_size = 0;
		      try {
		        this.request.connection.setKeepAlive(true, 5000);
		      } catch (error) {
		      }
		      ResponseReceiver.__super__.constructor.call(this, this.request.connection);
		      if (this.max_response_size === void 0) {
		        this.max_response_size = this.options.response_limit;
		      }
		    }

		    ResponseReceiver.prototype.doSendFrame = function(payload) {
		      var r;
		      this.curr_response_size += payload.length;
		      r = false;
		      try {
		        this.response.write(payload);
		        r = true;
		      } catch (error) {
		      }
		      if (this.max_response_size && this.curr_response_size >= this.max_response_size) {
		        this.didClose();
		      }
		      return r;
		    };

		    ResponseReceiver.prototype.didClose = function() {
		      ResponseReceiver.__super__.didClose.apply(this, arguments);
		      try {
		        this.response.end();
		      } catch (error) {
		      }
		      return this.response = null;
		    };

		    return ResponseReceiver;

		  })(GenericReceiver);

		  transport.GenericReceiver = GenericReceiver;

		  transport.Transport = Transport;

		  transport.Session = Session;

		  transport.ResponseReceiver = ResponseReceiver;

		  transport.SockJSConnection = SockJSConnection;

		}).call(commonjsGlobal);
		return transport;
	}

	var hasRequiredTransWebsocket;

	function requireTransWebsocket () {
		if (hasRequiredTransWebsocket) return transWebsocket;
		hasRequiredTransWebsocket = 1;
		// Generated by CoffeeScript 1.12.7
		(function() {
		  var FayeWebsocket, RawWebsocketSessionReceiver, Transport, WebSocketReceiver, transport, extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
		    hasProp = {}.hasOwnProperty;

		  FayeWebsocket = requireWebsocket();

		  requireUtils();

		  transport = requireTransport();

		  transWebsocket.app = {
		    _websocket_check: function(req, connection, head) {
		      if (!FayeWebsocket.isWebSocket(req)) {
		        throw {
		          status: 400,
		          message: 'Not a valid websocket request'
		        };
		      }
		    },
		    sockjs_websocket: function(req, connection, head) {
		      var ws;
		      this._websocket_check(req, connection, head);
		      ws = new FayeWebsocket(req, connection, head, null, this.options.faye_server_options);
		      ws.onopen = (function(_this) {
		        return function() {
		          return transport.registerNoSession(req, _this, new WebSocketReceiver(ws, connection));
		        };
		      })(this);
		      return true;
		    },
		    raw_websocket: function(req, connection, head) {
		      var ver, ws;
		      this._websocket_check(req, connection, head);
		      ver = req.headers['sec-websocket-version'] || '';
		      if (['8', '13'].indexOf(ver) === -1) {
		        throw {
		          status: 400,
		          message: 'Only supported WebSocket protocol is RFC 6455.'
		        };
		      }
		      ws = new FayeWebsocket(req, connection, head, null, this.options.faye_server_options);
		      ws.onopen = (function(_this) {
		        return function() {
		          return new RawWebsocketSessionReceiver(req, connection, _this, ws);
		        };
		      })(this);
		      return true;
		    }
		  };

		  WebSocketReceiver = (function(superClass) {
		    extend(WebSocketReceiver, superClass);

		    WebSocketReceiver.prototype.protocol = "websocket";

		    function WebSocketReceiver(ws1, connection1) {
		      this.ws = ws1;
		      this.connection = connection1;
		      try {
		        this.connection.setKeepAlive(true, 5000);
		        this.connection.setNoDelay(true);
		      } catch (error) {
		      }
		      this.ws.addEventListener('message', (function(_this) {
		        return function(m) {
		          return _this.didMessage(m.data);
		        };
		      })(this));
		      this.heartbeat_cb = (function(_this) {
		        return function() {
		          return _this.heartbeat_timeout();
		        };
		      })(this);
		      WebSocketReceiver.__super__.constructor.call(this, this.connection);
		    }

		    WebSocketReceiver.prototype.setUp = function() {
		      WebSocketReceiver.__super__.setUp.apply(this, arguments);
		      return this.ws.addEventListener('close', this.thingy_end_cb);
		    };

		    WebSocketReceiver.prototype.tearDown = function() {
		      this.ws.removeEventListener('close', this.thingy_end_cb);
		      return WebSocketReceiver.__super__.tearDown.apply(this, arguments);
		    };

		    WebSocketReceiver.prototype.didMessage = function(payload) {
		      var i, len, message, msg, results;
		      if (this.ws && this.session && payload.length > 0) {
		        try {
		          message = JSON.parse(payload);
		        } catch (error) {
		          return this.didClose(3000, 'Broken framing.');
		        }
		        if (payload[0] === '[') {
		          results = [];
		          for (i = 0, len = message.length; i < len; i++) {
		            msg = message[i];
		            results.push(this.session.didMessage(msg));
		          }
		          return results;
		        } else {
		          return this.session.didMessage(message);
		        }
		      }
		    };

		    WebSocketReceiver.prototype.doSendFrame = function(payload) {
		      if (this.ws) {
		        try {
		          this.ws.send(payload);
		          return true;
		        } catch (error) {
		        }
		      }
		      return false;
		    };

		    WebSocketReceiver.prototype.didClose = function(status, reason) {
		      if (status == null) {
		        status = 1000;
		      }
		      if (reason == null) {
		        reason = "Normal closure";
		      }
		      WebSocketReceiver.__super__.didClose.apply(this, arguments);
		      try {
		        this.ws.close(status, reason, false);
		      } catch (error) {
		      }
		      this.ws = null;
		      return this.connection = null;
		    };

		    WebSocketReceiver.prototype.heartbeat = function() {
		      var hto_ref, supportsHeartbeats;
		      supportsHeartbeats = this.ws.ping(null, function() {
		        return clearTimeout(hto_ref);
		      });
		      if (supportsHeartbeats) {
		        return hto_ref = setTimeout(this.heartbeat_cb, 10000);
		      } else {
		        return WebSocketReceiver.__super__.heartbeat.apply(this, arguments);
		      }
		    };

		    WebSocketReceiver.prototype.heartbeat_timeout = function() {
		      if (this.session != null) {
		        return this.session.close(3000, 'No response from heartbeat');
		      }
		    };

		    return WebSocketReceiver;

		  })(transport.GenericReceiver);

		  Transport = transport.Transport;

		  RawWebsocketSessionReceiver = (function(superClass) {
		    extend(RawWebsocketSessionReceiver, superClass);

		    function RawWebsocketSessionReceiver(req, conn, server, ws1) {
		      this.ws = ws1;
		      this.prefix = server.options.prefix;
		      this.readyState = Transport.OPEN;
		      this.recv = {
		        connection: conn,
		        protocol: "websocket-raw"
		      };
		      this.connection = new transport.SockJSConnection(this);
		      this.decorateConnection(req);
		      server.emit('connection', this.connection);
		      this._end_cb = (function(_this) {
		        return function() {
		          return _this.didClose();
		        };
		      })(this);
		      this.ws.addEventListener('close', this._end_cb);
		      this._message_cb = (function(_this) {
		        return function(m) {
		          return _this.didMessage(m);
		        };
		      })(this);
		      this.ws.addEventListener('message', this._message_cb);
		    }

		    RawWebsocketSessionReceiver.prototype.didMessage = function(m) {
		      if (this.readyState === Transport.OPEN) {
		        this.connection.emit('data', m.data);
		      }
		    };

		    RawWebsocketSessionReceiver.prototype.send = function(payload) {
		      if (this.readyState !== Transport.OPEN) {
		        return false;
		      }
		      this.ws.send(payload);
		      return true;
		    };

		    RawWebsocketSessionReceiver.prototype.close = function(status, reason) {
		      if (status == null) {
		        status = 1000;
		      }
		      if (reason == null) {
		        reason = "Normal closure";
		      }
		      if (this.readyState !== Transport.OPEN) {
		        return false;
		      }
		      this.readyState = Transport.CLOSING;
		      this.ws.close(status, reason, false);
		      return true;
		    };

		    RawWebsocketSessionReceiver.prototype.didClose = function() {
		      if (!this.ws) {
		        return;
		      }
		      this.ws.removeEventListener('message', this._message_cb);
		      this.ws.removeEventListener('close', this._end_cb);
		      try {
		        this.ws.close(1000, "Normal closure", false);
		      } catch (error) {
		      }
		      this.ws = null;
		      this.readyState = Transport.CLOSED;
		      this.connection.emit('end');
		      this.connection.emit('close');
		      return this.connection = null;
		    };

		    return RawWebsocketSessionReceiver;

		  })(transport.Session);

		}).call(commonjsGlobal);
		return transWebsocket;
	}

	var transJsonp = {};

	var hasRequiredTransJsonp;

	function requireTransJsonp () {
		if (hasRequiredTransJsonp) return transJsonp;
		hasRequiredTransJsonp = 1;
		// Generated by CoffeeScript 1.12.7
		(function() {
		  var JsonpReceiver, transport,
		    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
		    hasProp = {}.hasOwnProperty;

		  transport = requireTransport();

		  JsonpReceiver = (function(superClass) {
		    extend(JsonpReceiver, superClass);

		    JsonpReceiver.prototype.protocol = "jsonp-polling";

		    JsonpReceiver.prototype.max_response_size = 1;

		    function JsonpReceiver(req, res, options, callback1) {
		      this.callback = callback1;
		      JsonpReceiver.__super__.constructor.call(this, req, res, options);
		    }

		    JsonpReceiver.prototype.doSendFrame = function(payload) {
		      return JsonpReceiver.__super__.doSendFrame.call(this, "/**/" + this.callback + "(" + JSON.stringify(payload) + ");\r\n");
		    };

		    return JsonpReceiver;

		  })(transport.ResponseReceiver);

		  transJsonp.app = {
		    jsonp: function(req, res, _, next_filter) {
		      var callback;
		      if (!('c' in req.query || 'callback' in req.query)) {
		        throw {
		          status: 500,
		          message: '"callback" parameter required'
		        };
		      }
		      callback = 'c' in req.query ? req.query['c'] : req.query['callback'];
		      if (/[^a-zA-Z0-9-_.]/.test(callback) || callback.length > 32) {
		        throw {
		          status: 500,
		          message: 'invalid "callback" parameter'
		        };
		      }
		      res.setHeader('X-Content-Type-Options', 'nosniff');
		      res.setHeader('Content-Type', 'application/javascript; charset=UTF-8');
		      res.writeHead(200);
		      transport.register(req, this, new JsonpReceiver(req, res, this.options, callback));
		      return true;
		    },
		    jsonp_send: function(req, res, query) {
		      var d, i, jsonp, len, message;
		      if (!query) {
		        throw {
		          status: 500,
		          message: 'Payload expected.'
		        };
		      }
		      if (typeof query === 'string') {
		        try {
		          d = JSON.parse(query);
		        } catch (error) {
		          throw {
		            status: 500,
		            message: 'Broken JSON encoding.'
		          };
		        }
		      } else {
		        d = query.d;
		      }
		      if (typeof d === 'string' && d) {
		        try {
		          d = JSON.parse(d);
		        } catch (error) {
		          throw {
		            status: 500,
		            message: 'Broken JSON encoding.'
		          };
		        }
		      }
		      if (!d || d.__proto__.constructor !== Array) {
		        throw {
		          status: 500,
		          message: 'Payload expected.'
		        };
		      }
		      jsonp = transport.Session.bySessionId(req.session);
		      if (jsonp === null) {
		        throw {
		          status: 404
		        };
		      }
		      for (i = 0, len = d.length; i < len; i++) {
		        message = d[i];
		        jsonp.didMessage(message);
		      }
		      res.setHeader('Content-Length', '2');
		      res.setHeader('Content-Type', 'text/plain; charset=UTF-8');
		      res.writeHead(200);
		      res.end('ok');
		      return true;
		    }
		  };

		}).call(commonjsGlobal);
		return transJsonp;
	}

	var transXhr = {};

	var hasRequiredTransXhr;

	function requireTransXhr () {
		if (hasRequiredTransXhr) return transXhr;
		hasRequiredTransXhr = 1;
		// Generated by CoffeeScript 1.12.7
		(function() {
		  var XhrPollingReceiver, XhrStreamingReceiver, transport, extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
		    hasProp = {}.hasOwnProperty;

		  transport = requireTransport();

		  requireUtils();

		  XhrStreamingReceiver = (function(superClass) {
		    extend(XhrStreamingReceiver, superClass);

		    function XhrStreamingReceiver() {
		      return XhrStreamingReceiver.__super__.constructor.apply(this, arguments);
		    }

		    XhrStreamingReceiver.prototype.protocol = "xhr-streaming";

		    XhrStreamingReceiver.prototype.doSendFrame = function(payload) {
		      return XhrStreamingReceiver.__super__.doSendFrame.call(this, payload + '\n');
		    };

		    return XhrStreamingReceiver;

		  })(transport.ResponseReceiver);

		  XhrPollingReceiver = (function(superClass) {
		    extend(XhrPollingReceiver, superClass);

		    function XhrPollingReceiver() {
		      return XhrPollingReceiver.__super__.constructor.apply(this, arguments);
		    }

		    XhrPollingReceiver.prototype.protocol = "xhr-polling";

		    XhrPollingReceiver.prototype.max_response_size = 1;

		    return XhrPollingReceiver;

		  })(XhrStreamingReceiver);

		  transXhr.app = {
		    xhr_options: function(req, res) {
		      res.statusCode = 204;
		      res.setHeader('Access-Control-Allow-Methods', 'OPTIONS, POST');
		      res.setHeader('Access-Control-Max-Age', res.cache_for);
		      return '';
		    },
		    xhr_send: function(req, res, data) {
		      var d, i, jsonp, len, message;
		      if (!data) {
		        throw {
		          status: 500,
		          message: 'Payload expected.'
		        };
		      }
		      try {
		        d = JSON.parse(data);
		      } catch (error) {
		        throw {
		          status: 500,
		          message: 'Broken JSON encoding.'
		        };
		      }
		      if (!d || d.__proto__.constructor !== Array) {
		        throw {
		          status: 500,
		          message: 'Payload expected.'
		        };
		      }
		      jsonp = transport.Session.bySessionId(req.session);
		      if (!jsonp) {
		        throw {
		          status: 404
		        };
		      }
		      for (i = 0, len = d.length; i < len; i++) {
		        message = d[i];
		        jsonp.didMessage(message);
		      }
		      res.setHeader('Content-Type', 'text/plain; charset=UTF-8');
		      res.writeHead(204);
		      res.end();
		      return true;
		    },
		    xhr_cors: function(req, res, content) {
		      var headers, origin;
		      if (this.options.disable_cors) {
		        return content;
		      }
		      if (!req.headers['origin']) {
		        origin = '*';
		      } else {
		        origin = req.headers['origin'];
		        res.setHeader('Access-Control-Allow-Credentials', 'true');
		      }
		      res.setHeader('Access-Control-Allow-Origin', origin);
		      res.setHeader('Vary', 'Origin');
		      headers = req.headers['access-control-request-headers'];
		      if (headers) {
		        res.setHeader('Access-Control-Allow-Headers', headers);
		      }
		      return content;
		    },
		    xhr_poll: function(req, res, _, next_filter) {
		      res.setHeader('Content-Type', 'application/javascript; charset=UTF-8');
		      res.writeHead(200);
		      transport.register(req, this, new XhrPollingReceiver(req, res, this.options));
		      return true;
		    },
		    xhr_streaming: function(req, res, _, next_filter) {
		      res.setHeader('Content-Type', 'application/javascript; charset=UTF-8');
		      res.writeHead(200);
		      res.write(Array(2049).join('h') + '\n');
		      transport.register(req, this, new XhrStreamingReceiver(req, res, this.options));
		      return true;
		    }
		  };

		}).call(commonjsGlobal);
		return transXhr;
	}

	var iframe = {};

	var hasRequiredIframe;

	function requireIframe () {
		if (hasRequiredIframe) return iframe;
		hasRequiredIframe = 1;
		// Generated by CoffeeScript 1.12.7
		(function() {
		  var iframe_template, utils;

		  utils = requireUtils();

		  iframe_template = "<!DOCTYPE html>\n<html>\n<head>\n  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />\n  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n  <script src=\"{{ sockjs_url }}\"></script>\n  <script>\n    document.domain = document.domain;\n    SockJS.bootstrap_iframe();\n  </script>\n</head>\n<body>\n  <h2>Don't panic!</h2>\n  <p>This is a SockJS hidden iframe. It's used for cross domain magic.</p>\n</body>\n</html>";

		  iframe.app = {
		    iframe: function(req, res) {
		      var content, context, k, quoted_md5;
		      context = {
		        '{{ sockjs_url }}': this.options.sockjs_url
		      };
		      content = iframe_template;
		      for (k in context) {
		        content = content.replace(k, context[k]);
		      }
		      quoted_md5 = '"' + utils.md5_hex(content) + '"';
		      if ('if-none-match' in req.headers && req.headers['if-none-match'] === quoted_md5) {
		        res.statusCode = 304;
		        return '';
		      }
		      res.setHeader('Content-Type', 'text/html; charset=UTF-8');
		      res.setHeader('ETag', quoted_md5);
		      return content;
		    }
		  };

		}).call(commonjsGlobal);
		return iframe;
	}

	var transEventsource = {};

	var hasRequiredTransEventsource;

	function requireTransEventsource () {
		if (hasRequiredTransEventsource) return transEventsource;
		hasRequiredTransEventsource = 1;
		// Generated by CoffeeScript 1.12.7
		(function() {
		  var EventSourceReceiver, transport, utils,
		    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
		    hasProp = {}.hasOwnProperty;

		  utils = requireUtils();

		  transport = requireTransport();

		  EventSourceReceiver = (function(superClass) {
		    extend(EventSourceReceiver, superClass);

		    function EventSourceReceiver() {
		      return EventSourceReceiver.__super__.constructor.apply(this, arguments);
		    }

		    EventSourceReceiver.prototype.protocol = "eventsource";

		    EventSourceReceiver.prototype.doSendFrame = function(payload) {
		      var data;
		      data = ['data: ', utils.escape_selected(payload, '\r\n\x00'), '\r\n\r\n'];
		      return EventSourceReceiver.__super__.doSendFrame.call(this, data.join(''));
		    };

		    return EventSourceReceiver;

		  })(transport.ResponseReceiver);

		  transEventsource.app = {
		    eventsource: function(req, res) {
		      var headers, origin;
		      if (!req.headers['origin'] || req.headers['origin'] === 'null') {
		        origin = '*';
		      } else {
		        origin = req.headers['origin'];
		        res.setHeader('Access-Control-Allow-Credentials', 'true');
		      }
		      res.setHeader('Content-Type', 'text/event-stream');
		      res.setHeader('Access-Control-Allow-Origin', origin);
		      res.setHeader('Vary', 'Origin');
		      headers = req.headers['access-control-request-headers'];
		      if (headers) {
		        res.setHeader('Access-Control-Allow-Headers', headers);
		      }
		      res.writeHead(200);
		      res.write('\r\n');
		      transport.register(req, this, new EventSourceReceiver(req, res, this.options));
		      return true;
		    }
		  };

		}).call(commonjsGlobal);
		return transEventsource;
	}

	var transHtmlfile = {};

	var hasRequiredTransHtmlfile;

	function requireTransHtmlfile () {
		if (hasRequiredTransHtmlfile) return transHtmlfile;
		hasRequiredTransHtmlfile = 1;
		// Generated by CoffeeScript 1.12.7
		(function() {
		  var HtmlFileReceiver, iframe_template, transport, extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
		    hasProp = {}.hasOwnProperty;

		  requireUtils();

		  transport = requireTransport();

		  iframe_template = "<!doctype html>\n<html><head>\n  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />\n  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n</head><body><h2>Don't panic!</h2>\n  <script>\n    document.domain = document.domain;\n    var c = parent.{{ callback }};\n    c.start();\n    function p(d) {c.message(d);};\n    window.onload = function() {c.stop();};\n  </script>";

		  iframe_template += Array(1024 - iframe_template.length + 14).join(' ');

		  iframe_template += '\r\n\r\n';

		  HtmlFileReceiver = (function(superClass) {
		    extend(HtmlFileReceiver, superClass);

		    function HtmlFileReceiver() {
		      return HtmlFileReceiver.__super__.constructor.apply(this, arguments);
		    }

		    HtmlFileReceiver.prototype.protocol = "htmlfile";

		    HtmlFileReceiver.prototype.doSendFrame = function(payload) {
		      return HtmlFileReceiver.__super__.doSendFrame.call(this, '<script>\np(' + JSON.stringify(payload) + ');\n</script>\r\n');
		    };

		    return HtmlFileReceiver;

		  })(transport.ResponseReceiver);

		  transHtmlfile.app = {
		    htmlfile: function(req, res) {
		      var callback;
		      if (!('c' in req.query || 'callback' in req.query)) {
		        throw {
		          status: 500,
		          message: '"callback" parameter required'
		        };
		      }
		      callback = 'c' in req.query ? req.query['c'] : req.query['callback'];
		      if (/[^a-zA-Z0-9-_.]/.test(callback)) {
		        throw {
		          status: 500,
		          message: 'invalid "callback" parameter'
		        };
		      }
		      res.setHeader('Content-Type', 'text/html; charset=UTF-8');
		      res.writeHead(200);
		      res.write(iframe_template.replace(/{{ callback }}/g, callback));
		      transport.register(req, this, new HtmlFileReceiver(req, res, this.options));
		      return true;
		    }
		  };

		}).call(commonjsGlobal);
		return transHtmlfile;
	}

	var chunkingTest = {};

	var hasRequiredChunkingTest;

	function requireChunkingTest () {
		if (hasRequiredChunkingTest) return chunkingTest;
		hasRequiredChunkingTest = 1;
		// Generated by CoffeeScript 1.12.7
		(function() {
		  var utils;

		  utils = requireUtils();

		  chunkingTest.app = {
		    chunking_test: function(req, res, _, next_filter) {
		      var write;
		      res.setHeader('Content-Type', 'application/javascript; charset=UTF-8');
		      res.writeHead(200);
		      write = (function(_this) {
		        return function(payload) {
		          try {
		            return res.write(payload + '\n');
		          } catch (error) {
		          }
		        };
		      })();
		      utils.timeout_chain([
		        [
		          0, (function(_this) {
		            return function() {
		              return write('h');
		            };
		          })()
		        ], [
		          1, (function(_this) {
		            return function() {
		              return write(Array(2049).join(' ') + 'h');
		            };
		          })()
		        ], [
		          5, (function(_this) {
		            return function() {
		              return write('h');
		            };
		          })()
		        ], [
		          25, (function(_this) {
		            return function() {
		              return write('h');
		            };
		          })()
		        ], [
		          125, (function(_this) {
		            return function() {
		              return write('h');
		            };
		          })()
		        ], [
		          625, (function(_this) {
		            return function() {
		              return write('h');
		            };
		          })()
		        ], [
		          3125, (function(_this) {
		            return function() {
		              write('h');
		              return res.end();
		            };
		          })()
		        ]
		      ]);
		      return true;
		    },
		    info: function(req, res, _) {
		      var info;
		      info = {
		        websocket: this.options.websocket,
		        origins: !this.options.disable_cors ? ['*:*'] : void 0,
		        cookie_needed: !!this.options.jsessionid,
		        entropy: utils.random32()
		      };
		      if (typeof this.options.base_url === 'function') {
		        info.base_url = this.options.base_url();
		      } else if (this.options.base_url) {
		        info.base_url = this.options.base_url;
		      }
		      res.setHeader('Content-Type', 'application/json; charset=UTF-8');
		      res.writeHead(200);
		      return res.end(JSON.stringify(info));
		    },
		    info_options: function(req, res) {
		      res.statusCode = 204;
		      res.setHeader('Access-Control-Allow-Methods', 'OPTIONS, GET');
		      res.setHeader('Access-Control-Max-Age', res.cache_for);
		      return '';
		    }
		  };

		}).call(commonjsGlobal);
		return chunkingTest;
	}

	(function (exports) {
		// Generated by CoffeeScript 1.12.7
		(function() {
		  var App, Listener, Server, chunking_test, events, fs, generate_dispatcher, iframe, sockjsVersion, trans_eventsource, trans_htmlfile, trans_jsonp, trans_websocket, trans_xhr, utils, webjs,
		    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
		    hasProp = {}.hasOwnProperty,
		    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

		  events = require$$0$4;

		  fs = require$$1$2;

		  webjs = requireWebjs();

		  utils = requireUtils();

		  trans_websocket = requireTransWebsocket();

		  trans_jsonp = requireTransJsonp();

		  trans_xhr = requireTransXhr();

		  iframe = requireIframe();

		  trans_eventsource = requireTransEventsource();

		  trans_htmlfile = requireTransHtmlfile();

		  chunking_test = requireChunkingTest();

		  sockjsVersion = function() {
		    var pkg;
		    try {
		      pkg = fs.readFileSync(__dirname + '/../package.json', 'utf-8');
		    } catch (error) {
		    }
		    if (pkg) {
		      return JSON.parse(pkg).version;
		    } else {
		      return null;
		    }
		  };

		  App = (function(superClass) {
		    extend(App, superClass);

		    function App() {
		      return App.__super__.constructor.apply(this, arguments);
		    }

		    App.prototype.welcome_screen = function(req, res) {
		      res.setHeader('content-type', 'text/plain; charset=UTF-8');
		      res.writeHead(200);
		      res.end("Welcome to SockJS!\n");
		      return true;
		    };

		    App.prototype.handle_404 = function(req, res) {
		      res.setHeader('content-type', 'text/plain; charset=UTF-8');
		      res.writeHead(404);
		      res.end('404 Error: Page not found\n');
		      return true;
		    };

		    App.prototype.disabled_transport = function(req, res, data) {
		      return this.handle_404(req, res, data);
		    };

		    App.prototype.h_sid = function(req, res, data) {
		      var jsid;
		      req.cookies = utils.parseCookie(req.headers.cookie);
		      if (typeof this.options.jsessionid === 'function') {
		        this.options.jsessionid(req, res);
		      } else if (this.options.jsessionid && res.setHeader) {
		        jsid = req.cookies['JSESSIONID'] || 'dummy';
		        res.setHeader('Set-Cookie', 'JSESSIONID=' + jsid + '; path=/');
		      }
		      return data;
		    };

		    App.prototype.log = function(severity, line) {
		      return this.options.log(severity, line);
		    };

		    return App;

		  })(webjs.GenericApp);

		  utils.objectExtend(App.prototype, iframe.app);

		  utils.objectExtend(App.prototype, chunking_test.app);

		  utils.objectExtend(App.prototype, trans_websocket.app);

		  utils.objectExtend(App.prototype, trans_jsonp.app);

		  utils.objectExtend(App.prototype, trans_xhr.app);

		  utils.objectExtend(App.prototype, trans_eventsource.app);

		  utils.objectExtend(App.prototype, trans_htmlfile.app);

		  generate_dispatcher = function(options) {
		    var opts_filters, p, prefix_dispatcher, t, transport_dispatcher;
		    p = (function(_this) {
		      return function(s) {
		        return new RegExp('^' + options.prefix + s + '[/]?$');
		      };
		    })();
		    t = (function(_this) {
		      return function(s) {
		        return [p('/([^/.]+)/([^/.]+)' + s), 'server', 'session'];
		      };
		    })();
		    opts_filters = function(options_filter) {
		      if (options_filter == null) {
		        options_filter = 'xhr_options';
		      }
		      return ['h_sid', 'xhr_cors', 'cache_for', options_filter, 'expose'];
		    };
		    prefix_dispatcher = [['GET', p(''), ['welcome_screen']], ['GET', p('/iframe[0-9-.a-z_]*.html'), ['iframe', 'cache_for', 'expose']], ['OPTIONS', p('/info'), opts_filters('info_options')], ['GET', p('/info'), ['xhr_cors', 'h_no_cache', 'info', 'expose']], ['OPTIONS', p('/chunking_test'), opts_filters()], ['POST', p('/chunking_test'), ['xhr_cors', 'expect_xhr', 'chunking_test']]];
		    transport_dispatcher = [['GET', t('/jsonp'), ['h_sid', 'h_no_cache', 'jsonp']], ['POST', t('/jsonp_send'), ['h_sid', 'h_no_cache', 'expect_form', 'jsonp_send']], ['POST', t('/xhr'), ['h_sid', 'h_no_cache', 'xhr_cors', 'xhr_poll']], ['OPTIONS', t('/xhr'), opts_filters()], ['POST', t('/xhr_send'), ['h_sid', 'h_no_cache', 'xhr_cors', 'expect_xhr', 'xhr_send']], ['OPTIONS', t('/xhr_send'), opts_filters()], ['POST', t('/xhr_streaming'), ['h_sid', 'h_no_cache', 'xhr_cors', 'xhr_streaming']], ['OPTIONS', t('/xhr_streaming'), opts_filters()], ['GET', t('/eventsource'), ['h_sid', 'h_no_cache', 'eventsource']], ['GET', t('/htmlfile'), ['h_sid', 'h_no_cache', 'htmlfile']]];
		    if (options.websocket) {
		      prefix_dispatcher.push(['GET', p('/websocket'), ['raw_websocket']]);
		      transport_dispatcher.push(['GET', t('/websocket'), ['sockjs_websocket']]);
		    } else {
		      prefix_dispatcher.push(['GET', p('/websocket'), ['cache_for', 'disabled_transport']]);
		      transport_dispatcher.push(['GET', t('/websocket'), ['cache_for', 'disabled_transport']]);
		    }
		    return prefix_dispatcher.concat(transport_dispatcher);
		  };

		  Listener = (function() {
		    function Listener(options1, emit) {
		      this.options = options1;
		      this.handler = bind(this.handler, this);
		      this.app = new App();
		      this.app.options = this.options;
		      this.app.emit = emit;
		      this.app.log('debug', 'SockJS v' + sockjsVersion() + ' ' + 'bound to ' + JSON.stringify(this.options.prefix));
		      this.dispatcher = generate_dispatcher(this.options);
		      this.webjs_handler = webjs.generateHandler(this.app, this.dispatcher);
		      this.path_regexp = new RegExp('^' + this.options.prefix + '([/].+|[/]?)$');
		    }

		    Listener.prototype.handler = function(req, res, extra) {
		      if (!req.url.match(this.path_regexp)) {
		        return false;
		      }
		      this.webjs_handler(req, res, extra);
		      return true;
		    };

		    Listener.prototype.getHandler = function() {
		      return (function(_this) {
		        return function(a, b, c) {
		          return _this.handler(a, b, c);
		        };
		      })(this);
		    };

		    return Listener;

		  })();

		  Server = (function(superClass) {
		    extend(Server, superClass);

		    function Server(user_options) {
		      this.options = {
		        prefix: '',
		        response_limit: 128 * 1024,
		        websocket: true,
		        faye_server_options: null,
		        jsessionid: false,
		        heartbeat_delay: 25000,
		        disconnect_delay: 5000,
		        log: function(severity, line) {
		          return console.log(line);
		        },
		        sockjs_url: 'https://localhost/javascript/sockjs/sockjs.min.js'
		      };
		      if (user_options) {
		        utils.objectExtend(this.options, user_options);
		      }
		    }

		    Server.prototype.listener = function(handler_options) {
		      var options;
		      options = utils.objectExtend({}, this.options);
		      if (handler_options) {
		        utils.objectExtend(options, handler_options);
		      }
		      return new Listener(options, (function(_this) {
		        return function() {
		          return _this.emit.apply(_this, arguments);
		        };
		      })(this));
		    };

		    Server.prototype.installHandlers = function(http_server, handler_options) {
		      var handler;
		      handler = this.listener(handler_options).getHandler();
		      utils.overshadowListeners(http_server, 'request', handler);
		      utils.overshadowListeners(http_server, 'upgrade', handler);
		      return true;
		    };

		    Server.prototype.middleware = function(handler_options) {
		      var handler;
		      handler = this.listener(handler_options).getHandler();
		      handler.upgrade = handler;
		      return handler;
		    };

		    return Server;

		  })(events.EventEmitter);

		  exports.createServer = function(options) {
		    return new Server(options);
		  };

		  exports.listen = function(http_server, options) {
		    var srv;
		    srv = exports.createServer(options);
		    if (http_server) {
		      srv.installHandlers(http_server);
		    }
		    return srv;
		  };

		}).call(commonjsGlobal);
	} (sockjs));

	(function (module) {
		module.exports = sockjs;
	} (nodeSockjs0_3_24__0_3_33));

	var index = /*@__PURE__*/getDefaultExportFromCjs(nodeSockjs0_3_24__0_3_33.exports);

	return index;

})();
