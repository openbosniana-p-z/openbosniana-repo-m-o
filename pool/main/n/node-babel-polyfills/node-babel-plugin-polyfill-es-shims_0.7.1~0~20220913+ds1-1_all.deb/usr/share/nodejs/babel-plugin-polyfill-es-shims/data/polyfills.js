module.exports = require("./polyfills.json");
