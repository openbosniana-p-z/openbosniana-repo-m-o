import * as types from './../types';
import { Styles } from 'free-style';
/**
 * We need to do the following to *our* objects before passing to freestyle:
 * - For any `$nest` directive move up to FreeStyle style nesting
 * - For any `$unique` directive map to FreeStyle Unique
 * - For any `$debugName` directive return the debug name
 */
export declare function convertToStyles(object: types.NestedCSSProperties): Styles;
export declare function convertToKeyframes(frames: types.KeyFrames): Styles;
