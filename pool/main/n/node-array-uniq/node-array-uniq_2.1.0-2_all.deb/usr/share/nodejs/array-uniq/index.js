'use strict';

const arrayUniq = array => [...new Set(array)];

module.exports = arrayUniq;
