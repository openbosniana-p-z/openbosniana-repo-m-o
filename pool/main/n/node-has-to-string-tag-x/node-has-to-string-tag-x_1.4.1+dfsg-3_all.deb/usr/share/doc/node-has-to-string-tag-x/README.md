## has-to-string-tag-x
Tests if ES6 @@toStringTag is supported.

**See**: [26.3.1 @@toStringTag](http://www.ecma-international.org/ecma-262/6.0/#sec-@@tostringtag)  
**Version**: 1.4.1  
**Author**: Xotic750 <Xotic750@gmail.com>  
**License**: [MIT](&lt;https://opensource.org/licenses/MIT&gt;)  
**Copyright**: Xotic750  
<a name="exp_module_has-to-string-tag-x--module.exports"></a>

### `module.exports` : <code>boolean</code> ⏏
Indicates if `Symbol.toStringTag`exists and is the correct type.
`true`, if it exists and is the correct type, otherwise `false`.

**Kind**: Exported member  
