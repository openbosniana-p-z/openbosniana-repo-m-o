
A VimL plugin that provides functions and commands for Neovim GUIs. By itself this plugin doesn't do much, it just provides a shim Neovim GUIs can use to implement features. See `:h nvim_gui_shim`.

