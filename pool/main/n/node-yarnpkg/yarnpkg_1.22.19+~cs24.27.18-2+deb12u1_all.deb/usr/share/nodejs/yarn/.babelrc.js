module.exports = {
  "env": {
    "test": {
      "presets": [
        ["env", {
          "targets": {
            "node": "current"
          },
          "modules": false,
          "loose": true
         }],
         "flow",
         "stage-0"
       ],
       "plugins": [
         ["transform-inline-imports-commonjs"]
       ]
     }
   },
   "presets": [
     "@babel/preset-env",
     "@babel/preset-flow"
   ],
   "plugins": [
    "@babel/syntax-dynamic-import",
     ["@babel/transform-runtime"],
     ["@babel/proposal-class-properties"],
     ["@babel/transform-modules-commonjs", {
      "lazy": (source) => true
      }],
     ["@babel/transform-classes", { "globals": ["Error"] } ]
   ]
 }