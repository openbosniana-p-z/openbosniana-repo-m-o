const results = require('../cjs/crc16modbus').default;
module.exports = results;
module.exports.default = results;
