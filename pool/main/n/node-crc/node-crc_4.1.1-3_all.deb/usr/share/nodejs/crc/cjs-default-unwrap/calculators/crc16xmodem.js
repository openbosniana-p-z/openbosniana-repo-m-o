const results = require('../../cjs/calculators/crc16xmodem').default;
module.exports = results;
module.exports.default = results;
