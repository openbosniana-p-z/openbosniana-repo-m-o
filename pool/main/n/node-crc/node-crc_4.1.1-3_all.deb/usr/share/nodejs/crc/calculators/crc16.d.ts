import { CRCCalculator } from '../types.js';
declare const crc16: CRCCalculator<Uint8Array>;
export default crc16;
