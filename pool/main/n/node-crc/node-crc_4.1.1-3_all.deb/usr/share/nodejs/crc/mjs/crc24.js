import crc24 from './calculators/crc24.js';
import defineCrc from './define_crc.js';
export default defineCrc('crc-24', crc24);
