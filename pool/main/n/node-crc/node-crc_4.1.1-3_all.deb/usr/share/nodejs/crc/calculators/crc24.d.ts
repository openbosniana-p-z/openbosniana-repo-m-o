import { CRCCalculator } from '../types.js';
declare const crc24: CRCCalculator<Uint8Array>;
export default crc24;
