declare const _default: import("./types.js").CRCModule;
export default _default;
