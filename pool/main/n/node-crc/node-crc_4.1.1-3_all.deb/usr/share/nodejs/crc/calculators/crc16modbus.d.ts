import { CRCCalculator } from '../types.js';
declare const crc16modbus: CRCCalculator<Uint8Array>;
export default crc16modbus;
