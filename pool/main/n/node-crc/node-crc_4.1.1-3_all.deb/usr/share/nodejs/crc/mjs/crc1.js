import crc1 from './calculators/crc1.js';
import defineCrc from './define_crc.js';
export default defineCrc('crc1', crc1);
