import { CRCCalculator, CRCModule } from './types.js';
export default function defineCrc(model: string, calculator: CRCCalculator<Uint8Array>): CRCModule;
