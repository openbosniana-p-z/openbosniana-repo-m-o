const results = require('../../cjs/calculators/crc8').default;
module.exports = results;
module.exports.default = results;
