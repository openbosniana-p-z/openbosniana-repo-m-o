const results = require('../../cjs/calculators/crc32').default;
module.exports = results;
module.exports.default = results;
