const results = require('../../cjs/calculators/crc16kermit').default;
module.exports = results;
module.exports.default = results;
