import crc16ccitt from './calculators/crc16ccitt.js';
import defineCrc from './define_crc.js';
export default defineCrc('ccitt', crc16ccitt);
