import crc81wire from './calculators/crc81wire.js';
import defineCrc from './define_crc.js';
export default defineCrc('dallas-1-wire', crc81wire);
