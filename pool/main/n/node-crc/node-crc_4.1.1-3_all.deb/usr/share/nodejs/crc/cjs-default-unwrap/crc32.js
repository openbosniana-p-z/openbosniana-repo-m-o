const results = require('../cjs/crc32').default;
module.exports = results;
module.exports.default = results;
