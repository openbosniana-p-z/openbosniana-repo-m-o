import { CRCCalculator } from '../types.js';
declare const crc32: CRCCalculator<Uint8Array>;
export default crc32;
