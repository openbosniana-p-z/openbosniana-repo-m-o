import { CRCCalculator } from '../types.js';
declare const crcjam: CRCCalculator<Uint8Array>;
export default crcjam;
