import crc8 from './calculators/crc8.js';
import defineCrc from './define_crc.js';
export default defineCrc('crc-8', crc8);
