const results = require('../../cjs/calculators/crcjam').default;
module.exports = results;
module.exports.default = results;
