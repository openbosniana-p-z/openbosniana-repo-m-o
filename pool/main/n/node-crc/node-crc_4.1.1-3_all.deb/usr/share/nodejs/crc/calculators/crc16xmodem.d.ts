import { CRCCalculator } from '../types.js';
declare const crc16xmodem: CRCCalculator<Uint8Array>;
export default crc16xmodem;
