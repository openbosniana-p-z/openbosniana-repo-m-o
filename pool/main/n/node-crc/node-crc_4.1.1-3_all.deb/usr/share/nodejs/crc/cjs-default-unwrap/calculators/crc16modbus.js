const results = require('../../cjs/calculators/crc16modbus').default;
module.exports = results;
module.exports.default = results;
