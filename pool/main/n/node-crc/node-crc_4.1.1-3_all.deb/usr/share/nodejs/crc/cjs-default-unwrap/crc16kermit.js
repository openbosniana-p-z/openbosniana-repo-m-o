const results = require('../cjs/crc16kermit').default;
module.exports = results;
module.exports.default = results;
