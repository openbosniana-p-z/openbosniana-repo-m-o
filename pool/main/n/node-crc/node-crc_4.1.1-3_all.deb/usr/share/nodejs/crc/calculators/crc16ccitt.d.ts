import { CRCCalculator } from '../types.js';
declare const crc16ccitt: CRCCalculator<Uint8Array>;
export default crc16ccitt;
