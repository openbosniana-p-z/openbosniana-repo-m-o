const results = require('../../cjs/calculators/crc16ccitt').default;
module.exports = results;
module.exports.default = results;
