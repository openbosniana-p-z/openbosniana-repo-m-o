import crc16modbus from './calculators/crc16modbus.js';
import defineCrc from './define_crc.js';
export default defineCrc('crc-16-modbus', crc16modbus);
