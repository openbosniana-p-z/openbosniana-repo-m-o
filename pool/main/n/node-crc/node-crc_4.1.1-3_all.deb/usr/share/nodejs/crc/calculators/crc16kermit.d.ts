import { CRCCalculator } from '../types.js';
declare const crc16kermit: CRCCalculator<Uint8Array>;
export default crc16kermit;
