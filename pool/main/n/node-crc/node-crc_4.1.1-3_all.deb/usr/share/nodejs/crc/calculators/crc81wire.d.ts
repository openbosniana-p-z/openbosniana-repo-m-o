import { CRCCalculator } from '../types.js';
declare const crc81wire: CRCCalculator<Uint8Array>;
export default crc81wire;
