const results = require('../../cjs/calculators/crc16').default;
module.exports = results;
module.exports.default = results;
