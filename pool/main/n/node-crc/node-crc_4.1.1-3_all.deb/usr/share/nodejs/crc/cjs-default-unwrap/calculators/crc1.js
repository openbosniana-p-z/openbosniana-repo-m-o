const results = require('../../cjs/calculators/crc1').default;
module.exports = results;
module.exports.default = results;
