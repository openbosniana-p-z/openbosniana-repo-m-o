import crc16 from './calculators/crc16.js';
import defineCrc from './define_crc.js';
export default defineCrc('crc-16', crc16);
