import crc32 from './calculators/crc32.js';
import defineCrc from './define_crc.js';
export default defineCrc('crc-32', crc32);
