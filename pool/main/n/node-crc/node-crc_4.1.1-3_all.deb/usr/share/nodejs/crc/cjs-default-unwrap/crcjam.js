const results = require('../cjs/crcjam').default;
module.exports = results;
module.exports.default = results;
