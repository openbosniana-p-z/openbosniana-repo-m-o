const results = require('../../cjs/calculators/crc81wire').default;
module.exports = results;
module.exports.default = results;
