import crcjam from './calculators/crcjam.js';
import defineCrc from './define_crc.js';
export default defineCrc('jam', crcjam);
