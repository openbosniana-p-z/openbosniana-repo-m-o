const results = require('../cjs/crc16xmodem').default;
module.exports = results;
module.exports.default = results;
