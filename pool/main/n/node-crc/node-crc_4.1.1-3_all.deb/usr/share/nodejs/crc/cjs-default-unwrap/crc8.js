const results = require('../cjs/crc8').default;
module.exports = results;
module.exports.default = results;
