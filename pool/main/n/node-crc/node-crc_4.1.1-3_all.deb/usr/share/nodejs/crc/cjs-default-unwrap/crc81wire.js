const results = require('../cjs/crc81wire').default;
module.exports = results;
module.exports.default = results;
