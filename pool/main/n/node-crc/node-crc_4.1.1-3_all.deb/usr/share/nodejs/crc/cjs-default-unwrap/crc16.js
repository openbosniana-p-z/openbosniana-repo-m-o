const results = require('../cjs/crc16').default;
module.exports = results;
module.exports.default = results;
