const results = require('../cjs/crc1').default;
module.exports = results;
module.exports.default = results;
