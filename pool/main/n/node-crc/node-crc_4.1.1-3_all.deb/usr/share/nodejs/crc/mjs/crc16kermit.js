import crc16kermit from './calculators/crc16kermit.js';
import defineCrc from './define_crc.js';
export default defineCrc('kermit', crc16kermit);
