import { CRCCalculator } from '../types.js';
declare const crc1: CRCCalculator<Uint8Array>;
export default crc1;
