module.exports = require('crypto').createHash
