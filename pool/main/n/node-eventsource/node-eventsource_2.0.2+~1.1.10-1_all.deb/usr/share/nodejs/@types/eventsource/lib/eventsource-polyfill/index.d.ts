import * as EventSource from '../../index';
export = EventSource;
