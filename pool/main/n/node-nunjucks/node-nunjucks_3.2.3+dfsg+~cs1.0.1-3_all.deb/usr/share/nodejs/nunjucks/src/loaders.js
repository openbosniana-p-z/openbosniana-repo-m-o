"use strict";

// This file will automatically be rewired to web-loader.js when
// building for the browser
module.exports = require('./node-loaders');