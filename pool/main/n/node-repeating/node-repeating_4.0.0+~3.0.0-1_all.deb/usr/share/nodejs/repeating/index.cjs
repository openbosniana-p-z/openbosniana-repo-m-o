"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = repeating;

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function repeating(count) {
  var repeatString = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : ' ';

  if (typeof repeatString !== 'string') {
    throw new TypeError("Expected `input` to be a `string`, got `".concat(_typeof(repeatString), "`"));
  }

  if (count < 0 || !Number.isFinite(count)) {
    throw new TypeError("Expected `count` to be a positive finite number, got `".concat(count, "`"));
  }

  var returnValue = '';

  do {
    if (count & 1) {
      returnValue += repeatString;
    }

    repeatString += repeatString;
  } while (count >>= 1);

  return returnValue;
}
