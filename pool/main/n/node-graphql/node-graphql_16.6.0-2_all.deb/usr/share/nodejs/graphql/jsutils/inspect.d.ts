/**
 * Used to print values in error messages.
 */
export declare function inspect(value: unknown): string;
