/**
 * Given [ A, B, C ] return ' Did you mean A, B, or C?'.
 */
export declare function didYouMean(suggestions: ReadonlyArray<string>): string;
export declare function didYouMean(subMessage: string, suggestions: ReadonlyArray<string>): string;
