/**
 * The set of allowed kind values for AST nodes.
 */
var Kind;
(function (Kind) {
  Kind["NAME"] = "Name";
  Kind["DOCUMENT"] = "Document";
  Kind["OPERATION_DEFINITION"] = "OperationDefinition";
  Kind["VARIABLE_DEFINITION"] = "VariableDefinition";
  Kind["SELECTION_SET"] = "SelectionSet";
  Kind["FIELD"] = "Field";
  Kind["ARGUMENT"] = "Argument";
  Kind["FRAGMENT_SPREAD"] = "FragmentSpread";
  Kind["INLINE_FRAGMENT"] = "InlineFragment";
  Kind["FRAGMENT_DEFINITION"] = "FragmentDefinition";
  Kind["VARIABLE"] = "Variable";
  Kind["INT"] = "IntValue";
  Kind["FLOAT"] = "FloatValue";
  Kind["STRING"] = "StringValue";
  Kind["BOOLEAN"] = "BooleanValue";
  Kind["NULL"] = "NullValue";
  Kind["ENUM"] = "EnumValue";
  Kind["LIST"] = "ListValue";
  Kind["OBJECT"] = "ObjectValue";
  Kind["OBJECT_FIELD"] = "ObjectField";
  Kind["DIRECTIVE"] = "Directive";
  Kind["NAMED_TYPE"] = "NamedType";
  Kind["LIST_TYPE"] = "ListType";
  Kind["NON_NULL_TYPE"] = "NonNullType";
  Kind["SCHEMA_DEFINITION"] = "SchemaDefinition";
  Kind["OPERATION_TYPE_DEFINITION"] = "OperationTypeDefinition";
  Kind["SCALAR_TYPE_DEFINITION"] = "ScalarTypeDefinition";
  Kind["OBJECT_TYPE_DEFINITION"] = "ObjectTypeDefinition";
  Kind["FIELD_DEFINITION"] = "FieldDefinition";
  Kind["INPUT_VALUE_DEFINITION"] = "InputValueDefinition";
  Kind["INTERFACE_TYPE_DEFINITION"] = "InterfaceTypeDefinition";
  Kind["UNION_TYPE_DEFINITION"] = "UnionTypeDefinition";
  Kind["ENUM_TYPE_DEFINITION"] = "EnumTypeDefinition";
  Kind["ENUM_VALUE_DEFINITION"] = "EnumValueDefinition";
  Kind["INPUT_OBJECT_TYPE_DEFINITION"] = "InputObjectTypeDefinition";
  Kind["DIRECTIVE_DEFINITION"] = "DirectiveDefinition";
  Kind["SCHEMA_EXTENSION"] = "SchemaExtension";
  Kind["SCALAR_TYPE_EXTENSION"] = "ScalarTypeExtension";
  Kind["OBJECT_TYPE_EXTENSION"] = "ObjectTypeExtension";
  Kind["INTERFACE_TYPE_EXTENSION"] = "InterfaceTypeExtension";
  Kind["UNION_TYPE_EXTENSION"] = "UnionTypeExtension";
  Kind["ENUM_TYPE_EXTENSION"] = "EnumTypeExtension";
  Kind["INPUT_OBJECT_TYPE_EXTENSION"] = "InputObjectTypeExtension";
})(Kind || (Kind = {}));
export { Kind };

/**
 * The enum type representing the possible kind values of AST nodes.
 *
 * @deprecated Please use `Kind`. Will be remove in v17.
 */
