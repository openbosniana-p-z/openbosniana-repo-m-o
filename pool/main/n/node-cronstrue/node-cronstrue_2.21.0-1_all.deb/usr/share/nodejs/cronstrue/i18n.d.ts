// This definition file allows dist/cronstrue-i18n.js to be required from Node as:
// var cronstrue = require('cronstrue/i18n');

export { default } from "./dist/cronstrue-i18n.d";
