export default function() {
  return Math.random();
}
