module.exports = require('./javascript/diff_match_patch_uncompressed.js').diff_match_patch;
