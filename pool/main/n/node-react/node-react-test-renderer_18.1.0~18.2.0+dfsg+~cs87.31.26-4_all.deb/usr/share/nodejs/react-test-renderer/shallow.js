'use strict';

module.exports = require('react-shallow-renderer');
