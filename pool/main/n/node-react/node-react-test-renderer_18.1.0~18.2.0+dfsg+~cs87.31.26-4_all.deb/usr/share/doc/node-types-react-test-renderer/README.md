# Installation
> `npm install --save @types/react-test-renderer`

# Summary
This package contains type definitions for react-test-renderer (https://facebook.github.io/react/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-test-renderer.

### Additional Details
 * Last updated: Tue, 12 Apr 2022 06:01:18 GMT
 * Dependencies: [@types/react](https://npmjs.com/package/@types/react)
 * Global values: none

# Credits
These definitions were written by [Arvitaly](https://github.com/arvitaly), [Lochbrunner](https://github.com/lochbrunner), [John Reilly](https://github.com/johnnyreilly), [John Gozde](https://github.com/jgoz), [Jessica Franco](https://github.com/Jessidhia), [Dhruv Jain](https://github.com/maddhruv), and [Sebastian Silbermann](https://github.com/eps1lon).
