export default function collectSiblings(node: Element | null, refNode?: Element | null, selector?: string | null): Element[];
