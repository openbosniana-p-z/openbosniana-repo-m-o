export default function scrollbarSize(recalc?: boolean): number;
