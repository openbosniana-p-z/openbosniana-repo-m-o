import { CamelProperty, Property } from './types';
export default function camelizeStyleName<T extends string = Property>(string: T): CamelProperty;
