export default function getscrollAccessor(offset: 'pageXOffset' | 'pageYOffset'): {
    (node: Element): number;
    (node: Element, val: number): undefined;
};
