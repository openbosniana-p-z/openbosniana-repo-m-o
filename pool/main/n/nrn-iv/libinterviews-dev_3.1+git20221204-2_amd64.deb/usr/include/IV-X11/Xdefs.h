#undef Bitmap
#undef Colormap
#undef Cursor
#undef Display
#undef Drawable
#undef Font
#undef Screen
#undef Window

#define Bitmap XBitmap
#define Colormap XColormap
#define Cursor XCursor
#define Display XDisplay
#define Drawable XDrawable
#define Font XFont
#define Screen XScreen
#define Window XWindow
