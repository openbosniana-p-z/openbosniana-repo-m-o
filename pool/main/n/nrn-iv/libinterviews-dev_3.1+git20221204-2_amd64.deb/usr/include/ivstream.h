#pragma once
#include <iostream>
#include <fstream>
#include <sstream>

#define IOS_OUT std::ios::out
#define IOS_IN  std::ios::in
#define IOS_APP  std::ios::app
