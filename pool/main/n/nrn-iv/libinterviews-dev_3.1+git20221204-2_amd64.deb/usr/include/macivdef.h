#pragma precompile_target "iv_def.h"
#define MSL_USE_PRECOMPILED_HEADERS 1
#include <ansi_prefix.mac.h>

#define SYSV 1
#define MAC 1
#define motif_kit
#define sgi_motif_kit
#define default_kit SMFKit
