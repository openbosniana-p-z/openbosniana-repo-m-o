#include <MacHeadersCarbon.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>
#pragma once off
#define SYSV 1
#define MAC 1
#define motif_kit
#define sgi_motif_kit
#define default_kit SMFKit

#define HAVE_UNISTD_H 1
#define carbon 1
