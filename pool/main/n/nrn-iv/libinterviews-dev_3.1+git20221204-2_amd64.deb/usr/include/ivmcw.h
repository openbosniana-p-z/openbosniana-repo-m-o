#define WIN32 1
#define _WIN32
#define motif_kit
#define sgi_motif_kit
//#define HAVE_DIRENT_H 1
//#define CYGWIN 1
//#define MAC 1
#if __MWERKS__ >= 7
#define _MSL_DIRENT_H
#endif

