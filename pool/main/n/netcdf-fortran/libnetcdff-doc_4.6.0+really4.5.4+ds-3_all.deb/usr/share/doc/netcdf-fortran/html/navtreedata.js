/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "NetCDF-Fortran", "index.html", [
    [ "Unidata NetCDF Fortran Library", "index.html", [
      [ "Overview", "index.html#autotoc_md33", null ],
      [ "Getting NetCDF", "index.html#autotoc_md34", null ],
      [ "Mailing List", "index.html#autotoc_md35", null ]
    ] ],
    [ "Release Notes", "nf_release_notes.html", [
      [ "4.6.0 - Release TBD", "nf_release_notes.html#autotoc_md0", [
        [ "Requirements", "nf_release_notes.html#autotoc_md1", null ],
        [ "Changes", "nf_release_notes.html#autotoc_md2", null ]
      ] ],
      [ "4.5.4 - January 7, 2022", "nf_release_notes.html#autotoc_md3", [
        [ "Requirements", "nf_release_notes.html#autotoc_md4", null ],
        [ "Changes", "nf_release_notes.html#autotoc_md5", null ]
      ] ],
      [ "4.5.3 - June 2, 2020", "nf_release_notes.html#autotoc_md6", [
        [ "Requirements", "nf_release_notes.html#autotoc_md7", null ],
        [ "Changes", "nf_release_notes.html#autotoc_md8", null ]
      ] ],
      [ "4.5.2 - September 18, 2019", "nf_release_notes.html#autotoc_md9", [
        [ "Requirements", "nf_release_notes.html#autotoc_md10", null ],
        [ "Changes", "nf_release_notes.html#autotoc_md11", null ]
      ] ],
      [ "4.5.1 - September 4, 2019", "nf_release_notes.html#autotoc_md12", [
        [ "Requirements", "nf_release_notes.html#autotoc_md13", null ],
        [ "Changes", "nf_release_notes.html#autotoc_md14", null ]
      ] ],
      [ "4.5.0 - August 28, 2019", "nf_release_notes.html#autotoc_md15", [
        [ "Requirements", "nf_release_notes.html#autotoc_md16", null ],
        [ "Changes", "nf_release_notes.html#autotoc_md17", null ]
      ] ],
      [ "4.4.5 - Release Jan 9, 2019", "nf_release_notes.html#autotoc_md18", [
        [ "Requirements", "nf_release_notes.html#autotoc_md19", null ],
        [ "Changes", "nf_release_notes.html#autotoc_md20", null ]
      ] ],
      [ "4.4.4 Released May 13, 2016", "nf_release_notes.html#autotoc_md21", null ],
      [ "4.4.3 Released 2016-01-20", "nf_release_notes.html#autotoc_md22", null ],
      [ "4.4.2 Released 2015-02-02", "nf_release_notes.html#autotoc_md23", null ],
      [ "4.4.1 Released 2014-09-09", "nf_release_notes.html#autotoc_md24", [
        [ "4.4.1-RC1 Released 2014-08-05", "nf_release_notes.html#autotoc_md25", null ]
      ] ],
      [ "4.4 Released 2014-07-08", "nf_release_notes.html#autotoc_md26", [
        [ "4.4-rc1     Released 2013-10-06", "nf_release_notes.html#autotoc_md27", null ],
        [ "4.4-beta5   Released 2013-08-27", "nf_release_notes.html#autotoc_md28", null ],
        [ "4.4-beta4", "nf_release_notes.html#autotoc_md29", null ],
        [ "4.4-beta3   Released 2012-12-07", "nf_release_notes.html#autotoc_md30", null ],
        [ "4.4-beta2   Released 2012-06-29", "nf_release_notes.html#autotoc_md31", null ],
        [ "4.4-beta1   Released 2012-03-02", "nf_release_notes.html#autotoc_md32", null ]
      ] ]
    ] ],
    [ "The NetCDF Fortran 77 Interface Guide", "nc_f77_interface_guide.html", [
      [ "1 Use of the NetCDF Library", "nc_f77_interface_guide.html#f77_Use_of_the_NetCDF_Library", [
        [ "1.1 Creating a NetCDF Dataset", "nc_f77_interface_guide.html#f77_Creating_a_NetCDF_Dataset", null ],
        [ "1.2 Reading a NetCDF Dataset with Known Names", "nc_f77_interface_guide.html#f77_Reading_a_NetCDF_Dataset_with_Known_Names", null ],
        [ "1.3 Reading a netCDF Dataset with Unknown Names", "nc_f77_interface_guide.html#f77_Reading_a_netCDF_Dataset_with_Unknown_Names", null ],
        [ "1.4 Adding New Dimensions, Variables, Attributes", "nc_f77_interface_guide.html#f77_Adding_New_Dimensions__Variables__Attributes", null ],
        [ "1.5 Error Handling", "nc_f77_interface_guide.html#f77_Error_Handling_1_5", null ],
        [ "1.6 Compiling and Linking with the NetCDF Library", "nc_f77_interface_guide.html#f77_Compiling_and_Linking_with_the_NetCDF_Library", null ]
      ] ],
      [ "2. Datasets", "nc_f77_interface_guide.html#f77_Datasets", [
        [ "2.1 Datasets Introduction", "nc_f77_interface_guide.html#f77_Datasets_Introduction", null ],
        [ "2.2 NetCDF Library Interface Descriptions", "nc_f77_interface_guide.html#f77_NetCDF_Library_Interface_Descriptions", null ],
        [ "2.3 NF_STRERROR", "nc_f77_interface_guide.html#f77_NF_STRERROR", [
          [ "Usage", "nc_f77_interface_guide.html#autotoc_md36", null ],
          [ "Errors", "nc_f77_interface_guide.html#autotoc_md37", null ],
          [ "Example", "nc_f77_interface_guide.html#autotoc_md38", null ]
        ] ],
        [ "2.4 Get netCDF library version: NF_INQ_LIBVERS", "nc_f77_interface_guide.html#f77_Get_netCDF_library_version_NF_INQ_LIBVERS", [
          [ "Usage", "nc_f77_interface_guide.html#autotoc_md39", null ],
          [ "Errors", "nc_f77_interface_guide.html#autotoc_md40", null ],
          [ "Example", "nc_f77_interface_guide.html#autotoc_md41", null ]
        ] ],
        [ "2.5 NF_CREATE", "nc_f77_interface_guide.html#f77_NF_CREATE", [
          [ "Usage", "nc_f77_interface_guide.html#autotoc_md42", null ],
          [ "Errors", "nc_f77_interface_guide.html#autotoc_md43", null ],
          [ "Example", "nc_f77_interface_guide.html#autotoc_md44", null ]
        ] ],
        [ "2.6 NF__CREATE", "nc_f77_interface_guide.html#f77_F__CREATE", [
          [ "Usage", "nc_f77_interface_guide.html#autotoc_md45", null ],
          [ "Errors", "nc_f77_interface_guide.html#autotoc_md46", null ],
          [ "Example", "nc_f77_interface_guide.html#autotoc_md47", null ]
        ] ],
        [ "2.7 NF_CREATE_PAR", "nc_f77_interface_guide.html#f77_NF_CREATE_PAR", [
          [ "Usage", "nc_f77_interface_guide.html#autotoc_md48", null ],
          [ "Errors", "nc_f77_interface_guide.html#autotoc_md49", null ],
          [ "Example", "nc_f77_interface_guide.html#autotoc_md50", null ]
        ] ],
        [ "2.8 NF_OPEN", "nc_f77_interface_guide.html#f77_NF_OPEN_", [
          [ "Usage", "nc_f77_interface_guide.html#autotoc_md51", null ],
          [ "Errors", "nc_f77_interface_guide.html#autotoc_md52", null ],
          [ "Example", "nc_f77_interface_guide.html#autotoc_md53", null ]
        ] ],
        [ "2.9 NF__OPEN", "nc_f77_interface_guide.html#NF__OPEN_", [
          [ "Usage", "nc_f77_interface_guide.html#autotoc_md54", null ],
          [ "Errors", "nc_f77_interface_guide.html#autotoc_md55", null ],
          [ "Example", "nc_f77_interface_guide.html#autotoc_md56", null ]
        ] ],
        [ "2.10 NF_OPEN_PAR", "nc_f77_interface_guide.html#f77_NF_OPEN_PAR", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md57", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md58", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md59", null ],
        [ "2.11 NF_REDEF", "nc_f77_interface_guide.html#f77_NF-REDEF", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md60", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md61", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md62", null ],
        [ "2.12 NF_ENDDEF", "nc_f77_interface_guide.html#f77_NF-ENDDEF", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md63", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md64", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md65", null ],
        [ "2.13 NF__ENDDEF", "nc_f77_interface_guide.html#f77_NF__ENDDEF", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md66", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md67", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md68", null ],
        [ "2.14 NF_CLOSE", "nc_f77_interface_guide.html#f77_NF-CLOSE", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md69", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md70", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md71", null ],
        [ "2.15 NF_INQ Family", "nc_f77_interface_guide.html#f77_NF-INQ-Family", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md72", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md73", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md74", null ],
        [ "2.16 NF_SYNC", "nc_f77_interface_guide.html#f77_NF-SYNC", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md75", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md76", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md77", null ],
        [ "2.17 NF_ABORT", "nc_f77_interface_guide.html#f77_NF-ABORT", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md78", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md79", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md80", null ],
        [ "2.18 NF_SET_FILL", "nc_f77_interface_guide.html#f77_NF-SET-FILL", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md81", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md82", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md83", null ],
        [ "2.19 NF_SET_DEFAULT_FORMAT", "nc_f77_interface_guide.html#f77_NF-SET-DEFAULT-FORMAT", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md84", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md85", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md86", null ],
        [ "2.20 Set HDF5 Chunk Cache for Future File Opens/Creates: NF_SET_CHUNK_CACHE", "nc_f77_interface_guide.html#f77_Set-HDF5-Chunk", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md87", null ],
        [ "Return Codes", "nc_f77_interface_guide.html#autotoc_md88", null ],
        [ "2.21 Get the HDF5 Chunk Cache Settings for Future File Opens/Creates: NF_GET_CHUNK_CACHE", "nc_f77_interface_guide.html#f77_NF-GET-CHUNK-CACHE", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md89", null ],
        [ "Return Codes", "nc_f77_interface_guide.html#autotoc_md90", null ]
      ] ],
      [ "3. Groups", "nc_f77_interface_guide.html#f77_Groups", [
        [ "3.1 Find a Group ID: NF_INQ_NCID", "nc_f77_interface_guide.html#f77_NF-INQ-NCID", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md91", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md92", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md93", null ],
        [ "3.2 Get a List of Groups in a Group: NF_INQ_GRPS", "nc_f77_interface_guide.html#f77_NF-INQ-GRPS", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md94", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md95", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md96", null ],
        [ "3.3 Find all the Variables in a Group: NF_INQ_VARIDS", "nc_f77_interface_guide.html#f77_NF-INQ-VARIDS", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md97", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md98", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md99", null ],
        [ "3.4 Find all Dimensions Visible in a Group: NF_INQ_DIMIDS", "nc_f77_interface_guide.html#f77_NF-INQ-DIMIDS", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md100", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md101", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md102", null ],
        [ "3.5 Find the Length of a Group’s Name: NF_INQ_GRPNAME_LE", "nc_f77_interface_guide.html#f77_NF-INQ-GRPNAME-LE", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md103", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md104", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md105", null ],
        [ "3.6 Find a Group’s Name: NF_INQ_GRPNAME", "nc_f77_interface_guide.html#f77_NF-INQ-GRPNAME", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md106", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md107", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md108", null ],
        [ "3.7 Find a Group’s Full Name: NF_INQ_GRPNAME_FULL", "nc_f77_interface_guide.html#f77_NF-INQ-GRPNAME-FULL", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md109", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md110", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md111", null ],
        [ "3.8 Find a Group’s Parent: NF_INQ_GRP_PARENT", "nc_f77_interface_guide.html#f77_NF-INQ-GRP-PARENT", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md112", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md113", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md114", null ],
        [ "3.9 Find a Group by Name: NF_INQ_GRP_NCID", "nc_f77_interface_guide.html#f77_NF-INQ-GRP-NCID", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md115", null ],
        [ "Return Codes", "nc_f77_interface_guide.html#autotoc_md116", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md117", null ],
        [ "3.10 Find a Group by its Fully-qualified Name: NF_INQ_GRP_FULL_NCID", "nc_f77_interface_guide.html#f77_NF-INQ-GRP-FULL-NCID", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md118", null ],
        [ "Return Codes", "nc_f77_interface_guide.html#autotoc_md119", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md120", null ],
        [ "3.11 Create a New Group: NF_DEF_GRP", "nc_f77_interface_guide.html#f77_NF-DEF-GRP", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md121", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md122", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md123", null ]
      ] ],
      [ "4. Dimensions", "nc_f77_interface_guide.html#f77_Dimensions", [
        [ "4.1 Dimensions Introduction", "nc_f77_interface_guide.html#f77_Dimensions-Introduction", null ],
        [ "4.2 NF_DEF_DIM", "nc_f77_interface_guide.html#f77_NF-DEF-DIM", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md124", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md125", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md126", null ],
        [ "4.3 NF_INQ_DIMID", "nc_f77_interface_guide.html#f77_NF-INQ-DIMID", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md127", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md128", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md129", null ],
        [ "4.4 NF_INQ_DIM Family", "nc_f77_interface_guide.html#f77_NF-INQ-DIM-Family", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md130", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md131", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md132", null ],
        [ "4.5 NF_RENAME_DIM", "nc_f77_interface_guide.html#f77_NF-RENAME-DIM", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md133", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md134", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md135", null ]
      ] ],
      [ "5. User Defined Data Types", "nc_f77_interface_guide.html#f77_User-Defined-Data-Types", [
        [ "5.1 User Defined Types Introduction", "nc_f77_interface_guide.html#f77_User-Defined-Types-Introduction", null ],
        [ "5.2 Learn the IDs of All Types in Group: NF_INQ_TYPEIDS", "nc_f77_interface_guide.html#f77_NF-INQ-TYPEIDS", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md136", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md137", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md138", null ],
        [ "5.3 Find a Typeid from Group and Name: NF_INQ_TYPEID", "nc_f77_interface_guide.html#f77_NF-INQ-TYPEID", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md139", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md140", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md141", null ],
        [ "5.4 Learn About a User Defined Type: NF_INQ_TYPE", "nc_f77_interface_guide.html#f77_NF-INQ-TYPE", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md142", null ],
        [ "Return Codes", "nc_f77_interface_guide.html#autotoc_md143", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md144", null ],
        [ "5.5 Learn About a User Defined Type: NF_INQ_USER_TYPE", "nc_f77_interface_guide.html#f77_NF-INQ-USER-TYPE", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md145", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md146", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md147", null ],
        [ "5.6 Compound Types Introduction", "nc_f77_interface_guide.html#f77_Compound-Types-Introduction", [
          [ "5.6.1 Creating a Compound Type: NF_DEF_COMPOUND", "nc_f77_interface_guide.html#f77_NF-DEF-COMPOUND", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md148", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md149", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md150", [
          [ "5.6.2 Inserting a Field into a Compound Type: NF_INSERT_COMPOUND", "nc_f77_interface_guide.html#f77_NF-INSERT-COMPOUND", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md151", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md152", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md153", [
          [ "5.6.3 Inserting an Array Field into a Compound Type: NF_INSERT_ARRAY_COMPOUND", "nc_f77_interface_guide.html#f77_NF-INSERT-ARRAY-COMPOUND", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md154", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md155", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md156", [
          [ "5.6.4 Learn About a Compound Type: NF_INQ_COMPOUND", "nc_f77_interface_guide.html#f77_NF-INQ-COMPOUND", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md157", null ],
        [ "Return Codes", "nc_f77_interface_guide.html#autotoc_md158", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md159", [
          [ "5.6.5 Learn About a Field of a Compound Type: NF_INQ_COMPOUND_FIELD", "nc_f77_interface_guide.html#f77_NF-INQ-COMPOUND-FIELD", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md160", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md161", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md162", null ],
        [ "5.7 Variable Length Array Introduction", "nc_f77_interface_guide.html#autotoc_md163", [
          [ "5.7.1 Define a Variable Length Array (VLEN): NF_DEF_VLEN", "nc_f77_interface_guide.html#autotoc_md164", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md165", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md166", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md167", [
          [ "5.7.2 Learning about a Variable Length Array (VLEN) Type: NF_INQ_VLEN", "nc_f77_interface_guide.html#autotoc_md168", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md169", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md170", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md171", [
          [ "5.7.3 Releasing Memory for a Variable Length Array (VLEN) Type: NF_FREE_VLEN", "nc_f77_interface_guide.html#autotoc_md172", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md173", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md174", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md175", [
          [ "5.7.4 Set a Variable Length Array with NF_PUT_VLEN_ELEMENT", "nc_f77_interface_guide.html#autotoc_md176", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md177", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md178", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md179", [
          [ "5.7.5 Set a Variable Length Array with NF_GET_VLEN_ELEMENT", "nc_f77_interface_guide.html#autotoc_md180", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md181", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md182", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md183", null ],
        [ "5.8 Opaque Type Introduction", "nc_f77_interface_guide.html#autotoc_md184", [
          [ "5.8.1 Creating Opaque Types: NF_DEF_OPAQUE", "nc_f77_interface_guide.html#autotoc_md185", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md186", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md187", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md188", [
          [ "5.8.2 Learn About an Opaque Type: NF_INQ_OPAQUE", "nc_f77_interface_guide.html#autotoc_md189", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md190", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md191", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md192", null ],
        [ "5.9 Enum Type Introduction", "nc_f77_interface_guide.html#autotoc_md193", [
          [ "5.9.1 Creating a Enum Type: NF_DEF_ENUM", "nc_f77_interface_guide.html#autotoc_md194", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md195", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md196", [
          [ "5.9.2 Inserting a Field into a Enum Type: NF_INSERT_ENUM", "nc_f77_interface_guide.html#autotoc_md197", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md198", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md199", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md200", [
          [ "5.9.3 Learn About a Enum Type: NF_INQ_ENUM", "nc_f77_interface_guide.html#autotoc_md201", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md202", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md203", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md204", [
          [ "5.9.4 Learn the Name of a Enum Type: nf_inq_enum_member", "nc_f77_interface_guide.html#autotoc_md205", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md206", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md207", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md208", [
          [ "5.9.5 Learn the Name of a Enum Type: NF_INQ_ENUM_IDENT", "nc_f77_interface_guide.html#autotoc_md209", null ]
        ] ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md210", null ],
        [ "Return Code", "nc_f77_interface_guide.html#autotoc_md211", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md212", null ]
      ] ],
      [ "6. Variables", "nc_f77_interface_guide.html#autotoc_md213", [
        [ "6.1 Variables Introduction", "nc_f77_interface_guide.html#autotoc_md214", null ],
        [ "6.2 Language Types Corresponding to netCDF external data types", "nc_f77_interface_guide.html#autotoc_md215", null ],
        [ "6.3 Create a Variable: <tt>NF_DEF_VAR</tt>", "nc_f77_interface_guide.html#autotoc_md216", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md217", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md218", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md219", null ],
        [ "6.4 Define Chunking Parameters for a Variable: <tt>NF_DEF_VAR_CHUNKING</tt>", "nc_f77_interface_guide.html#autotoc_md220", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md221", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md222", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md223", null ],
        [ "6.5 Learn About Chunking Parameters for a Variable: <tt>NF_INQ_VAR_CHUNKING</tt>", "nc_f77_interface_guide.html#autotoc_md224", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md225", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md226", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md227", null ],
        [ "6.6 Set HDF5 Chunk Cache for a Variable: NF_SET_VAR_CHUNK_CACHE", "nc_f77_interface_guide.html#autotoc_md228", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md229", null ],
        [ "Return Codes", "nc_f77_interface_guide.html#autotoc_md230", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md231", null ],
        [ "6.7 Get the HDF5 Chunk Cache Settings for a variable: NF_GET_VAR_CHUNK_CACHE", "nc_f77_interface_guide.html#autotoc_md232", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md233", null ],
        [ "Return Codes", "nc_f77_interface_guide.html#autotoc_md234", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md235", null ],
        [ "6.8 Define Fill Parameters for a Variable: <tt>nf_def_var_fill</tt>", "nc_f77_interface_guide.html#autotoc_md236", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md237", null ],
        [ "Return Codes", "nc_f77_interface_guide.html#autotoc_md238", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md239", null ],
        [ "6.9 Learn About Fill Parameters for a Variable: <tt>NF_INQ_VAR_FILL</tt>", "nc_f77_interface_guide.html#autotoc_md240", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md241", null ],
        [ "Return Codes", "nc_f77_interface_guide.html#autotoc_md242", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md243", null ],
        [ "6.10 Define Compression Parameters for a Variable: <tt>NF_DEF_VAR_DEFLATE</tt>", "nc_f77_interface_guide.html#autotoc_md244", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md245", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md246", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md247", null ],
        [ "6.11 Learn About Deflate Parameters for a Variable: <tt>NF_INQ_VAR_DEFLATE</tt>", "nc_f77_interface_guide.html#autotoc_md248", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md249", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md250", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md251", null ],
        [ "6.12 Learn About Szip Parameters for a Variable: <tt>NF_INQ_VAR_SZIP</tt>", "nc_f77_interface_guide.html#autotoc_md252", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md253", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md254", null ],
        [ "6.13 Define Checm Parameters for a Variable: <tt>NF_DEF_VAR_FLETCHER32</tt>", "nc_f77_interface_guide.html#autotoc_md255", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md256", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md257", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md258", null ],
        [ "6.14 Learn About Checm Parameters for a Variable: <tt>NF_INQ_VAR_FLETCHER32</tt>", "nc_f77_interface_guide.html#autotoc_md259", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md260", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md261", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md262", null ],
        [ "6.15 Define Endianness of a Variable: <tt>NF_DEF_VAR_ENDIAN</tt>", "nc_f77_interface_guide.html#autotoc_md263", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md264", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md265", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md266", null ],
        [ "6.16 Learn About Endian Parameters for a Variable: <tt>NF_INQ_VAR_ENDIAN</tt>", "nc_f77_interface_guide.html#autotoc_md267", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md268", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md269", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md270", null ],
        [ "6.17 Define Filter for a Variable: <tt>NF_DEF_VAR_FILTER</tt>", "nc_f77_interface_guide.html#autotoc_md271", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md272", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md273", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md274", null ],
        [ "6.18 Learn About Filter Parameters for a Variable: <tt>NF_INQ_VAR_FILTER</tt>", "nc_f77_interface_guide.html#autotoc_md275", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md276", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md277", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md278", null ],
        [ "6.19 Get a Variable ID from Its Name: NF_INQ_VARID", "nc_f77_interface_guide.html#autotoc_md279", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md280", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md281", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md282", null ],
        [ "6.20 Get Information about a Variable from Its ID: NF_INQ_VAR family", "nc_f77_interface_guide.html#autotoc_md283", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md284", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md285", null ],
        [ "6.21 Write a Single Data Value: NF_PUT_VAR1_ type", "nc_f77_interface_guide.html#autotoc_md286", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md287", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md288", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md289", null ],
        [ "6.22 Write an Entire Variable: NF_PUT_VAR_ type", "nc_f77_interface_guide.html#autotoc_md290", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md291", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md292", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md293", null ],
        [ "6.23 Write an Array of Values: NF_PUT_VARA_ type", "nc_f77_interface_guide.html#autotoc_md294", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md295", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md296", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md297", null ],
        [ "6.24 NF_PUT_VARS_ type", "nc_f77_interface_guide.html#autotoc_md298", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md299", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md300", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md301", null ],
        [ "6.25 NF_PUT_VARM_ type", "nc_f77_interface_guide.html#autotoc_md302", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md303", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md304", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md305", null ],
        [ "6.26 NF_GET_VAR1_ type", "nc_f77_interface_guide.html#autotoc_md306", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md307", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md308", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md309", null ],
        [ "6.27 NF_GET_VAR_ type", "nc_f77_interface_guide.html#autotoc_md310", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md311", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md312", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md313", null ],
        [ "6.28 NF_GET_VARA_ type", "nc_f77_interface_guide.html#autotoc_md314", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md315", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md316", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md317", null ],
        [ "6.29 NF_GET_VARS_ type", "nc_f77_interface_guide.html#autotoc_md318", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md319", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md320", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md321", null ],
        [ "6.30 NF_GET_VARM_ type", "nc_f77_interface_guide.html#autotoc_md322", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md323", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md324", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md325", null ],
        [ "6.31 Reading and Writing Character String Values", "nc_f77_interface_guide.html#autotoc_md326", null ],
        [ "6.32 Fill Values", "nc_f77_interface_guide.html#autotoc_md327", null ],
        [ "6.33 NF_RENAME_VAR", "nc_f77_interface_guide.html#autotoc_md328", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md329", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md330", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md331", null ],
        [ "6.34 Change between Collective and Independent Parallel Access: NF_VAR_PAR_ACCESS", "nc_f77_interface_guide.html#autotoc_md332", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md333", null ],
        [ "Return Values", "nc_f77_interface_guide.html#autotoc_md334", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md335", null ]
      ] ],
      [ "7. Attributes", "nc_f77_interface_guide.html#autotoc_md336", [
        [ "7.1 Attributes Introduction", "nc_f77_interface_guide.html#autotoc_md337", null ],
        [ "7.2 NF_PUT_ATT_ type", "nc_f77_interface_guide.html#autotoc_md338", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md339", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md340", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md341", null ],
        [ "7.3 NF_INQ_ATT Family", "nc_f77_interface_guide.html#autotoc_md342", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md343", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md344", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md345", null ],
        [ "7.4 NF_GET_ATT_ type", "nc_f77_interface_guide.html#autotoc_md346", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md347", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md348", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md349", null ],
        [ "7.5 NF_COPY_ATT", "nc_f77_interface_guide.html#autotoc_md350", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md351", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md352", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md353", null ],
        [ "7.6 NF_RENAME_ATT", "nc_f77_interface_guide.html#autotoc_md354", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md355", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md356", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md357", null ],
        [ "7.7 NF_DEL_ATT", "nc_f77_interface_guide.html#autotoc_md358", null ],
        [ "Usage", "nc_f77_interface_guide.html#autotoc_md359", null ],
        [ "Errors", "nc_f77_interface_guide.html#autotoc_md360", null ],
        [ "Example", "nc_f77_interface_guide.html#autotoc_md361", null ]
      ] ],
      [ "A. NetCDF 2 to NetCDF 3 Fortran 77 Transition Guide", "nc_f77_interface_guide.html#f77_nc2_to_nc3_transition_guide", [
        [ "A.1 Overview of FORTRAN interface changes", "nc_f77_interface_guide.html#f77_overview_of_interface_changes", null ],
        [ "A.2 The New FORTRAN Interface", "nc_f77_interface_guide.html#f77_new_fortran_interface", null ],
        [ "A.3 Function Naming Conventions", "nc_f77_interface_guide.html#f77_function_naming_conventions", null ],
        [ "A.4 Type Conversion", "nc_f77_interface_guide.html#f77_type_conversion", null ]
      ] ],
      [ "B. Summary of FORTRAN 77 Interface", "nc_f77_interface_guide.html#f77_interface_summary", null ]
    ] ],
    [ "The NetCDF Fortran 90 Interface Guide", "f90_The-NetCDF-Fortran-90-Interface-Guide.html", "f90_The-NetCDF-Fortran-90-Interface-Guide" ]
  ] ]
];

var NAVTREEINDEX =
[
"f90-attributes.html",
"f90_groups.html#autotoc_md408",
"nc_f77_interface_guide.html#autotoc_md311"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';