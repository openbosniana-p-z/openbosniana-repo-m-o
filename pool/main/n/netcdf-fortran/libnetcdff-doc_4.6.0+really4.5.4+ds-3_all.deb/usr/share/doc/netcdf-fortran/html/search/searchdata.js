var indexSectionsWithContent =
{
  0: "1234567nrtu",
  1: "nr",
  2: "1234567rtu"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Pages"
};

