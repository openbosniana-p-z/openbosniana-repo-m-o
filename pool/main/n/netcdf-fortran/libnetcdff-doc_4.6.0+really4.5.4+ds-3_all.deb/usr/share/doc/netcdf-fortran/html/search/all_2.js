var searchData=
[
  ['3_20groups_0',['3 Groups',['../f90_groups.html',1,'f90_The-NetCDF-Fortran-90-Interface-Guide']]]
];
