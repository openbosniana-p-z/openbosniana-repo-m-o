import * as VueResource from './vue_resource';
export default VueResource