# test-globals

Private package which provides type declarations of Jest's global test APIs for tests of Jest repo.
