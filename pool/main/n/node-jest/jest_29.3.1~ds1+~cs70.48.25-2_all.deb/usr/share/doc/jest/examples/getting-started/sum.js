// Copyright 2004-present Facebook. All Rights Reserved.

function sum(a, b) {
  return a + b;
}

module.exports = sum;
