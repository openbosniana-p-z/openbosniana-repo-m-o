// Copyright 2004-present Facebook. All Rights Reserved.

export default {
  getAuthenticated: () => ({
    age: 26,
    name: 'Real name',
  }),
};
