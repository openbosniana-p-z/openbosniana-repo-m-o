// Copyright 2004-present Facebook. All Rights Reserved.

export const apple = 'apple';

export const strawberry = () => 'strawberry';

export default () => 'banana';
