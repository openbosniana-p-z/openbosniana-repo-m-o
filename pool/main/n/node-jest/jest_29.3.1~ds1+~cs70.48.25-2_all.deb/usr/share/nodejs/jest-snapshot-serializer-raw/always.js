module.exports = require('./lib/always');
