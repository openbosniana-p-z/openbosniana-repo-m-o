declare const RAW: unique symbol;
export interface Wrapper {
    [RAW]: string;
}
export declare function wrap(value: string): Wrapper;
export declare function test(value: any): value is Wrapper;
export declare function print(value: Wrapper): string;
export default wrap;
