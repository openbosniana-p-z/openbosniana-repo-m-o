export declare function test(value: any): value is string;
export declare function print(value: string): string;
