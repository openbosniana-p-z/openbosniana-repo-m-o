/**
 * Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

import ansiRegex = require('ansi-regex');
import style = require('ansi-styles');
import type {NewPlugin} from 'pretty-format';

export const alignedAnsiStyleSerializer: NewPlugin = {
  serialize(val: string): string {
    // Return the string itself, not escaped nor enclosed in double quote marks.
    return val.replace(ansiRegex(), match => {
      switch (match) {
// @ts-ignore
        case style.inverse.open:
          return '<i>';
// @ts-ignore
        case style.inverse.close:
          return '</i>';

// @ts-ignore
        case style.bold.open:
          return '<b>';
// @ts-ignore
        case style.dim.open:
          return '<d>';
// @ts-ignore
        case style.green.open:
          return '<g>';
// @ts-ignore
        case style.red.open:
          return '<r>';
// @ts-ignore
        case style.yellow.open:
          return '<y>';
// @ts-ignore
        case style.bgYellow.open:
          return '<Y>';

// @ts-ignore
        case style.bold.close:
// @ts-ignore
        case style.dim.close:
// @ts-ignore
        case style.green.close:
// @ts-ignore
        case style.red.close:
// @ts-ignore
        case style.yellow.close:
// @ts-ignore
        case style.bgYellow.close:
          return '</>';

        default:
          return match; // unexpected escape sequence
      }
    });
  },
  test(val: unknown): val is string {
    return typeof val === 'string';
  },
};
