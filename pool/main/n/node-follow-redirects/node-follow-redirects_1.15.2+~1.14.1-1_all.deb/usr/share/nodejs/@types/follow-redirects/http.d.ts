import { http } from '.';

export = http;
