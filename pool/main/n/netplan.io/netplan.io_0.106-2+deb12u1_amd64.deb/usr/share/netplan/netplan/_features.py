# Generated file
NETPLAN_FEATURE_FLAGS = [
    "dhcp-use-domains",
    "auth-phase2",
    "ipv6-mtu",
    "modems",
    "sriov",
    "openvswitch",
    "activation-mode",
    "eswitch-mode",
    "infiniband",
    "regdom",
    "vrf",
    "vxlan",
    "dbus-config",
    "generate-just-in-time",
    "generated-supplicant",
    "default-routes",
]
