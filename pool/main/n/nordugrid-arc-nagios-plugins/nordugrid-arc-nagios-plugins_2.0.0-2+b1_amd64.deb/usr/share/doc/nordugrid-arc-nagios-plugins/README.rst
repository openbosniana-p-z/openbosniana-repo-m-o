********************
 ARC Nagios Plugins
********************

This README describes the Nagios plugins for ARC-1 including CEs and
associated services.

Documentation can be found in the ``doc`` subdirectory, as well as using the
``--help`` options of the plugins.  If you have Sphinx installed, you can
create nicer looking documentation by typing

    make -C doc html

or using one of the other targets of the same makefile.  The result is placed
in a subdirectory of ``doc/_build``.


Installation
============

This package uses Python distutils, so you can install it with ::

    python setup.py build
    sudo python setup.py install

For customized installations, please refer to the manual
http://docs.python.org/distutils/ or ``python setup.py --help``.

The package also comes with an RPM spec, so it can be built similar to an
SRPM using ``rpmbuild -tb <TARFILE>``.
