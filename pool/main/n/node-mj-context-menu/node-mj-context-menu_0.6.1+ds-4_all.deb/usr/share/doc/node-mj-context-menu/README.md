# context-menu

A reimplementation of MathJax context menu in TypeScript.

Documentation: 
* [JSDoc](https://zorkow.github.io/context-menu/doc/jsdoc)
* [Typedoc](https://zorkow.github.io/context-menu/doc/typedoc)
* [Simple Class Diagram](https://zorkow.github.io/context-menu/doc/class-diagram-simple.svg)
* [Complete Class Diagram](https://zorkow.github.io/context-menu/doc/class-diagram-complete.svg)
