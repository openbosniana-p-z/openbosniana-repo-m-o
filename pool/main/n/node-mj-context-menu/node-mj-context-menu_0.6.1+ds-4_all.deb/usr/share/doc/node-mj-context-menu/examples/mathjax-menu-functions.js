// Some dummy functions for testing.
var MENU = {};
MENU.ShowSource = function() {};
MENU.isMac = function() {};
MENU.Zoom = function() {};
MENU.Id = function(x) {return x};
