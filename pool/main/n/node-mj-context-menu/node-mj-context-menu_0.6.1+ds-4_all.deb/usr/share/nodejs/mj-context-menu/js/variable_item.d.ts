export interface VariableItem {
    register(): void;
    unregister(): void;
    update(): void;
}
