export declare namespace CssStyles {
    function addMenuStyles(opt_document: HTMLDocument): void;
    function addInfoStyles(opt_document: HTMLDocument): void;
}
