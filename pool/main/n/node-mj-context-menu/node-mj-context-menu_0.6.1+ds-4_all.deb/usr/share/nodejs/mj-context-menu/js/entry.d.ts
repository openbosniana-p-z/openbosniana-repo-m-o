import { Menu } from './menu.js';
export interface Entry {
    menu: Menu;
    type: string;
    hide(): void;
    show(): void;
    isHidden(): boolean;
}
