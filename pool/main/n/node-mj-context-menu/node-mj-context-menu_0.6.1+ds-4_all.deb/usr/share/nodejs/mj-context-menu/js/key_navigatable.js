"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KEY = void 0;
var KEY;
(function (KEY) {
    KEY[KEY["RETURN"] = 13] = "RETURN";
    KEY[KEY["ESCAPE"] = 27] = "ESCAPE";
    KEY[KEY["SPACE"] = 32] = "SPACE";
    KEY[KEY["LEFT"] = 37] = "LEFT";
    KEY[KEY["UP"] = 38] = "UP";
    KEY[KEY["RIGHT"] = 39] = "RIGHT";
    KEY[KEY["DOWN"] = 40] = "DOWN";
})(KEY = exports.KEY || (exports.KEY = {}));
//# sourceMappingURL=key_navigatable.js.map