import { Variable } from './variable.js';
export declare class VariablePool<T> {
    private pool;
    insert(variable: Variable<T>): void;
    lookup(name: string): Variable<T>;
    remove(name: string): void;
    update(): void;
}
