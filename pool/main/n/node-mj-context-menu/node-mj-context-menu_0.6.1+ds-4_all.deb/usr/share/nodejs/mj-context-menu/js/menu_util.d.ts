import { Item } from './item.js';
export declare namespace MenuUtil {
    function close(item: Item): void;
    function getActiveElement(item: Item): HTMLElement;
    function error(_error: Error, msg: string): void;
    function counter(): number;
}
