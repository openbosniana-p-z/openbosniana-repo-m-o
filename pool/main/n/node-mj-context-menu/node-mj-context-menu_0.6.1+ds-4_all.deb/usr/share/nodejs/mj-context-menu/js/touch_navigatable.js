"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TOUCH = void 0;
exports.TOUCH = {
    START: 'touchstart',
    MOVE: 'touchmove',
    END: 'touchend',
    CANCEL: 'touchcancel'
};
//# sourceMappingURL=touch_navigatable.js.map