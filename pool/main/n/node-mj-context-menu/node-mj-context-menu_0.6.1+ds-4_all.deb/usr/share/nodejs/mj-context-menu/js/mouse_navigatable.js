"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MOUSE = void 0;
exports.MOUSE = {
    CLICK: 'click',
    DBLCLICK: 'dblclick',
    DOWN: 'mousedown',
    UP: 'mouseup',
    OVER: 'mouseover',
    OUT: 'mouseout',
    MOVE: 'mousemove',
    SELECTEND: 'selectend',
    SELECTSTART: 'selectstart'
};
//# sourceMappingURL=mouse_navigatable.js.map