export interface Element {
    html: HTMLElement;
    generateHtml(): void;
}
