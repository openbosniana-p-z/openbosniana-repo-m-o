export interface Postable {
    isPosted(): boolean;
    post(): void;
    post(x?: number, y?: number): void;
    unpost(): void;
}
