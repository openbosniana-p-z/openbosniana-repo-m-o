/* A Bison parser, made by GNU Bison 3.7.6.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_GRAM_H_INCLUDED
# define YY_YY_GRAM_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    VAR = 258,                     /* VAR  */
    EXPR = 259,                    /* EXPR  */
    ARRAY = 260,                   /* ARRAY  */
    STRUCT = 261,                  /* STRUCT  */
    UNION = 262,                   /* UNION  */
    ENUM = 263,                    /* ENUM  */
    COMP = 264,                    /* COMP  */
    HASH = 265,                    /* HASH  */
    SEMI = 266,                    /* SEMI  */
    MOD = 267,                     /* MOD  */
    OC = 268,                      /* OC  */
    CC = 269,                      /* CC  */
    DOLLAR = 270,                  /* DOLLAR  */
    DOTDOTDOT = 271,               /* DOTDOTDOT  */
    ENDFILE = 272,                 /* ENDFILE  */
    GLOBAL = 273,                  /* GLOBAL  */
    AUTO = 274,                    /* AUTO  */
    STATIC = 275,                  /* STATIC  */
    CONST = 276,                   /* CONST  */
    POLY = 277,                    /* POLY  */
    INTEGER = 278,                 /* INTEGER  */
    NATURAL = 279,                 /* NATURAL  */
    RATIONAL = 280,                /* RATIONAL  */
    REAL = 281,                    /* REAL  */
    STRING = 282,                  /* STRING  */
    FOREIGN = 283,                 /* FOREIGN  */
    FILET = 284,                   /* FILET  */
    MUTEX = 285,                   /* MUTEX  */
    SEMAPHORE = 286,               /* SEMAPHORE  */
    CONTINUATION = 287,            /* CONTINUATION  */
    THREAD = 288,                  /* THREAD  */
    VOID = 289,                    /* VOID  */
    BOOL = 290,                    /* BOOL  */
    FUNCTION = 291,                /* FUNCTION  */
    FUNC = 292,                    /* FUNC  */
    EXCEPTION = 293,               /* EXCEPTION  */
    RAISE = 294,                   /* RAISE  */
    TYPEDEF = 295,                 /* TYPEDEF  */
    IMPORT = 296,                  /* IMPORT  */
    NEW = 297,                     /* NEW  */
    ANONINIT = 298,                /* ANONINIT  */
    NAMESPACE = 299,               /* NAMESPACE  */
    PUBLIC = 300,                  /* PUBLIC  */
    PROTECTED = 301,               /* PROTECTED  */
    EXTEND = 302,                  /* EXTEND  */
    WHILE = 303,                   /* WHILE  */
    DO = 304,                      /* DO  */
    FOR = 305,                     /* FOR  */
    SWITCH = 306,                  /* SWITCH  */
    BREAK = 307,                   /* BREAK  */
    CONTINUE = 308,                /* CONTINUE  */
    RETURNTOK = 309,               /* RETURNTOK  */
    FORK = 310,                    /* FORK  */
    CASE = 311,                    /* CASE  */
    DEFAULT = 312,                 /* DEFAULT  */
    TWIXT = 313,                   /* TWIXT  */
    NAME = 314,                    /* NAME  */
    TYPENAME = 315,                /* TYPENAME  */
    NAMESPACENAME = 316,           /* NAMESPACENAME  */
    COMMAND = 317,                 /* COMMAND  */
    NAMECOMMAND = 318,             /* NAMECOMMAND  */
    TEN_NUM = 319,                 /* TEN_NUM  */
    OCTAL0_NUM = 320,              /* OCTAL0_NUM  */
    OCTAL_NUM = 321,               /* OCTAL_NUM  */
    BINARY_NUM = 322,              /* BINARY_NUM  */
    HEX_NUM = 323,                 /* HEX_NUM  */
    TEN_FLOAT = 324,               /* TEN_FLOAT  */
    OCTAL0_FLOAT = 325,            /* OCTAL0_FLOAT  */
    OCTAL_FLOAT = 326,             /* OCTAL_FLOAT  */
    BINARY_FLOAT = 327,            /* BINARY_FLOAT  */
    HEX_FLOAT = 328,               /* HEX_FLOAT  */
    CHAR_CONST = 329,              /* CHAR_CONST  */
    STRING_CONST = 330,            /* STRING_CONST  */
    POLY_CONST = 331,              /* POLY_CONST  */
    THREAD_CONST = 332,            /* THREAD_CONST  */
    COMMENT_CONST = 333,           /* COMMENT_CONST  */
    VOIDVAL = 334,                 /* VOIDVAL  */
    BOOLVAL = 335,                 /* BOOLVAL  */
    DARROW = 336,                  /* DARROW  */
    ISTYPE = 337,                  /* ISTYPE  */
    HASMEMBER = 338,               /* HASMEMBER  */
    POUND = 339,                   /* POUND  */
    COMMA = 340,                   /* COMMA  */
    ASSIGN = 341,                  /* ASSIGN  */
    ASSIGNPLUS = 342,              /* ASSIGNPLUS  */
    ASSIGNMINUS = 343,             /* ASSIGNMINUS  */
    ASSIGNTIMES = 344,             /* ASSIGNTIMES  */
    ASSIGNDIVIDE = 345,            /* ASSIGNDIVIDE  */
    ASSIGNDIV = 346,               /* ASSIGNDIV  */
    ASSIGNMOD = 347,               /* ASSIGNMOD  */
    ASSIGNPOW = 348,               /* ASSIGNPOW  */
    ASSIGNSHIFTL = 349,            /* ASSIGNSHIFTL  */
    ASSIGNSHIFTR = 350,            /* ASSIGNSHIFTR  */
    ASSIGNLXOR = 351,              /* ASSIGNLXOR  */
    ASSIGNLAND = 352,              /* ASSIGNLAND  */
    ASSIGNLOR = 353,               /* ASSIGNLOR  */
    ASSIGNOR = 354,                /* ASSIGNOR  */
    ASSIGNAND = 355,               /* ASSIGNAND  */
    QUEST = 356,                   /* QUEST  */
    COLON = 357,                   /* COLON  */
    OR = 358,                      /* OR  */
    AND = 359,                     /* AND  */
    LOR = 360,                     /* LOR  */
    LXOR = 361,                    /* LXOR  */
    LAND = 362,                    /* LAND  */
    EQ = 363,                      /* EQ  */
    NE = 364,                      /* NE  */
    LT = 365,                      /* LT  */
    GT = 366,                      /* GT  */
    LE = 367,                      /* LE  */
    GE = 368,                      /* GE  */
    SHIFTL = 369,                  /* SHIFTL  */
    SHIFTR = 370,                  /* SHIFTR  */
    PLUS = 371,                    /* PLUS  */
    MINUS = 372,                   /* MINUS  */
    TIMES = 373,                   /* TIMES  */
    DIVIDE = 374,                  /* DIVIDE  */
    DIV = 375,                     /* DIV  */
    POW = 376,                     /* POW  */
    STARSTAR = 377,                /* STARSTAR  */
    POW2 = 378,                    /* POW2  */
    POW3 = 379,                    /* POW3  */
    UNIONCAST = 380,               /* UNIONCAST  */
    UMINUS = 381,                  /* UMINUS  */
    BANG = 382,                    /* BANG  */
    FACT = 383,                    /* FACT  */
    LNOT = 384,                    /* LNOT  */
    INC = 385,                     /* INC  */
    DEC = 386,                     /* DEC  */
    STAR = 387,                    /* STAR  */
    AMPER = 388,                   /* AMPER  */
    THREADID = 389,                /* THREADID  */
    OS = 390,                      /* OS  */
    CS = 391,                      /* CS  */
    DOT = 392,                     /* DOT  */
    ARROW = 393,                   /* ARROW  */
    STAROS = 394,                  /* STAROS  */
    CALL = 395,                    /* CALL  */
    OP = 396,                      /* OP  */
    CP = 397,                      /* CP  */
    POINTER = 398,                 /* POINTER  */
    COLONCOLON = 399,              /* COLONCOLON  */
    IF = 400,                      /* IF  */
    TRY = 401,                     /* TRY  */
    NONL = 402,                    /* NONL  */
    ELSE = 403,                    /* ELSE  */
    CATCH = 404,                   /* CATCH  */
    NL = 405                       /* NL  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define VAR 258
#define EXPR 259
#define ARRAY 260
#define STRUCT 261
#define UNION 262
#define ENUM 263
#define COMP 264
#define HASH 265
#define SEMI 266
#define MOD 267
#define OC 268
#define CC 269
#define DOLLAR 270
#define DOTDOTDOT 271
#define ENDFILE 272
#define GLOBAL 273
#define AUTO 274
#define STATIC 275
#define CONST 276
#define POLY 277
#define INTEGER 278
#define NATURAL 279
#define RATIONAL 280
#define REAL 281
#define STRING 282
#define FOREIGN 283
#define FILET 284
#define MUTEX 285
#define SEMAPHORE 286
#define CONTINUATION 287
#define THREAD 288
#define VOID 289
#define BOOL 290
#define FUNCTION 291
#define FUNC 292
#define EXCEPTION 293
#define RAISE 294
#define TYPEDEF 295
#define IMPORT 296
#define NEW 297
#define ANONINIT 298
#define NAMESPACE 299
#define PUBLIC 300
#define PROTECTED 301
#define EXTEND 302
#define WHILE 303
#define DO 304
#define FOR 305
#define SWITCH 306
#define BREAK 307
#define CONTINUE 308
#define RETURNTOK 309
#define FORK 310
#define CASE 311
#define DEFAULT 312
#define TWIXT 313
#define NAME 314
#define TYPENAME 315
#define NAMESPACENAME 316
#define COMMAND 317
#define NAMECOMMAND 318
#define TEN_NUM 319
#define OCTAL0_NUM 320
#define OCTAL_NUM 321
#define BINARY_NUM 322
#define HEX_NUM 323
#define TEN_FLOAT 324
#define OCTAL0_FLOAT 325
#define OCTAL_FLOAT 326
#define BINARY_FLOAT 327
#define HEX_FLOAT 328
#define CHAR_CONST 329
#define STRING_CONST 330
#define POLY_CONST 331
#define THREAD_CONST 332
#define COMMENT_CONST 333
#define VOIDVAL 334
#define BOOLVAL 335
#define DARROW 336
#define ISTYPE 337
#define HASMEMBER 338
#define POUND 339
#define COMMA 340
#define ASSIGN 341
#define ASSIGNPLUS 342
#define ASSIGNMINUS 343
#define ASSIGNTIMES 344
#define ASSIGNDIVIDE 345
#define ASSIGNDIV 346
#define ASSIGNMOD 347
#define ASSIGNPOW 348
#define ASSIGNSHIFTL 349
#define ASSIGNSHIFTR 350
#define ASSIGNLXOR 351
#define ASSIGNLAND 352
#define ASSIGNLOR 353
#define ASSIGNOR 354
#define ASSIGNAND 355
#define QUEST 356
#define COLON 357
#define OR 358
#define AND 359
#define LOR 360
#define LXOR 361
#define LAND 362
#define EQ 363
#define NE 364
#define LT 365
#define GT 366
#define LE 367
#define GE 368
#define SHIFTL 369
#define SHIFTR 370
#define PLUS 371
#define MINUS 372
#define TIMES 373
#define DIVIDE 374
#define DIV 375
#define POW 376
#define STARSTAR 377
#define POW2 378
#define POW3 379
#define UNIONCAST 380
#define UMINUS 381
#define BANG 382
#define FACT 383
#define LNOT 384
#define INC 385
#define DEC 386
#define STAR 387
#define AMPER 388
#define THREADID 389
#define OS 390
#define CS 391
#define DOT 392
#define ARROW 393
#define STAROS 394
#define CALL 395
#define OP 396
#define CP 397
#define POINTER 398
#define COLONCOLON 399
#define IF 400
#define TRY 401
#define NONL 402
#define ELSE 403
#define CATCH 404
#define NL 405

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 71 "gram.y"

    int		    ints;
    Value	    value;
    Class	    class;
    ArgType	    *argType;
    Type	    *type;
    Publish	    publish;
    ExprPtr	    expr;
    Atom	    atom;
    DeclListPtr	    declList;
    MemListPtr	    memList;
    Fulltype	    fulltype;
    ArgDecl	    argDecl;
    SymbolPtr	    symbol;
    NamespacePtr    namespace;
    CodePtr	    code;
    Bool	    bool;
    AtomListPtr	    atomList;
    FuncDecl	    funcDecl;

#line 388 "gram.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_GRAM_H_INCLUDED  */
