/*
 * Copyright © 1988-2004 Keith Packard and Bart Massey.
 * All Rights Reserved.  See the file COPYING in this directory
 * for licensing information.
 */

typedef struct _reference *ReferencePtr;

ReferencePtr	NewReference (void **object);
