# winston-compat
Core functionality from winston < 3.0.0 commonly used by user-created transports.
