# Installation
> `npm install --save @types/gulp-util`

# Summary
This package contains type definitions for gulp-util (https://github.com/gulpjs/gulp-util).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/gulp-util.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 20:33:10 GMT
 * Dependencies: [@types/vinyl](https://npmjs.com/package/@types/vinyl), [@types/chalk](https://npmjs.com/package/@types/chalk), [@types/through2](https://npmjs.com/package/@types/through2), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [jedmao](https://github.com/jedmao).
