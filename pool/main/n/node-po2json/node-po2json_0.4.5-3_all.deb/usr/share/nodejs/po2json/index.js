module.exports = {
  parse: require('./lib/parse'),
  parseFile: require('./lib/parseFile'),
  parseFileSync: require('./lib/parseFileSync')
};