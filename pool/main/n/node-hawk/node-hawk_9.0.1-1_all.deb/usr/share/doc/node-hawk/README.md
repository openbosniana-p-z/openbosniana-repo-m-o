# hawk

#### HTTP Holder-Of-Key Authentication Scheme.

Documentation of the protocol, and the JS API, is in https://github.com/mozilla/hawk/blob/main/API.md.

## Ownership Changes

This was once `hueniverse/hawk` and relased as `hawk`.
Then, after the 7.0.10 release, it was moved to the `hapijs/hawk` repository and released as `@hapi/hawk`.
Hapi later de-supported the library, after releasing version 8.0.0.
It has since been moved to `mozilla/hawk` and is again released as `hawk`.
All of the intermediate versions are also relased as `hawk`.

Changes are represented in GitHub releases on this repository.

Mozilla maintains several Hawk implementations in different langauages, so it is likely to stay at Mozilla for some time.

This library is in "maintenance mode" -- no features will be added, and only security-related bugfixes will be applied.
