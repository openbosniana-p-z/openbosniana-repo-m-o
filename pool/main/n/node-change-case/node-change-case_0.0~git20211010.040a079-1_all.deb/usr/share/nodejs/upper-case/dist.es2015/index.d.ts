/**
 * Localized upper case.
 */
export declare function localeUpperCase(str: string, locale: string): string;
/**
 * Upper case as a function.
 */
export declare function upperCase(str: string): string;
