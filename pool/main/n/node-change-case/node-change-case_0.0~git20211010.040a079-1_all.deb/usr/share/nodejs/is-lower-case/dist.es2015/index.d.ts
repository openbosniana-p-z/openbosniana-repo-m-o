/**
 * Returns a boolean indicating whether the string is lower case.
 */
export declare function isLowerCase(input: string): boolean;
