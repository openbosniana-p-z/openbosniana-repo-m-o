/**
 * Returns a boolean indicating whether the string is upper case.
 */
export function isUpperCase(input) {
    return input.toUpperCase() === input && input.toLowerCase() !== input;
}
//# sourceMappingURL=index.js.map