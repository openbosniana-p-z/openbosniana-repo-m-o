import { Options } from "no-case";
export { Options };
export declare function paramCase(input: string, options?: Options): string;
