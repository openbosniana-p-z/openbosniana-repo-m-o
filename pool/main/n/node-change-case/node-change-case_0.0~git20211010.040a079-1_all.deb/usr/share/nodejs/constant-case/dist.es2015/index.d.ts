import { Options } from "no-case";
export { Options };
export declare function constantCase(input: string, options?: Options): string;
