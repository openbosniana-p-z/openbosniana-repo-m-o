import { Options } from "capital-case";
export { Options };
export declare function headerCase(input: string, options?: Options): string;
