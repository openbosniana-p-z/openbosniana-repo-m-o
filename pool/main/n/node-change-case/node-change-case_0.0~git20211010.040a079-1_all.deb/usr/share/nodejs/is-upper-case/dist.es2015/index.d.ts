/**
 * Returns a boolean indicating whether the string is upper case.
 */
export declare function isUpperCase(input: string): boolean;
