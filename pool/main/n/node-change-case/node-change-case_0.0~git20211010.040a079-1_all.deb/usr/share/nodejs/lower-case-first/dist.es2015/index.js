/**
 * Lower case the first character of an input string.
 */
export function lowerCaseFirst(input) {
    return input.charAt(0).toLowerCase() + input.substr(1);
}
//# sourceMappingURL=index.js.map