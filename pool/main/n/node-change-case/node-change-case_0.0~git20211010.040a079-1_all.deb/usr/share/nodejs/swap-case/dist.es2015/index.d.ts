export declare function swapCase(input: string): string;
