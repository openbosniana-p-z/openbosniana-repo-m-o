import { __assign } from "tslib";
import { capitalCase } from "capital-case";
export function headerCase(input, options) {
    if (options === void 0) { options = {}; }
    return capitalCase(input, __assign({ delimiter: "-" }, options));
}
//# sourceMappingURL=index.js.map