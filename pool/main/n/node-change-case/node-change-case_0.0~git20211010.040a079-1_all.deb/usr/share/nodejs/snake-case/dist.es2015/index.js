import { __assign } from "tslib";
import { noCase } from "no-case";
export function snakeCase(input, options) {
    if (options === void 0) { options = {}; }
    return noCase(input, __assign({ delimiter: "_" }, options));
}
//# sourceMappingURL=index.js.map