/**
 * Returns a boolean indicating whether the string is lower case.
 */
export function isLowerCase(input) {
    return input.toLowerCase() === input && input.toUpperCase() !== input;
}
//# sourceMappingURL=index.js.map