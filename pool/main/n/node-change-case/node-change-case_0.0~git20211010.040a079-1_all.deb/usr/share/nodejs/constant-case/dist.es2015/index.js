import { __assign } from "tslib";
import { noCase } from "no-case";
import { upperCase } from "upper-case";
export function constantCase(input, options) {
    if (options === void 0) { options = {}; }
    return noCase(input, __assign({ delimiter: "_", transform: upperCase }, options));
}
//# sourceMappingURL=index.js.map