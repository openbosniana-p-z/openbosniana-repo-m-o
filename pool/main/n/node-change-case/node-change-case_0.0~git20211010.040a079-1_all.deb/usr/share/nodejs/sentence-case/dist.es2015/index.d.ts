import { Options } from "no-case";
export { Options };
export declare function sentenceCaseTransform(input: string, index: number): string;
export declare function sentenceCase(input: string, options?: Options): string;
