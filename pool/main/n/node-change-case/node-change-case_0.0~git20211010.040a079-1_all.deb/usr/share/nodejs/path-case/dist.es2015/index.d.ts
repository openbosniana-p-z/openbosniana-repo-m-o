import { Options } from "no-case";
export { Options };
export declare function pathCase(input: string, options?: Options): string;
