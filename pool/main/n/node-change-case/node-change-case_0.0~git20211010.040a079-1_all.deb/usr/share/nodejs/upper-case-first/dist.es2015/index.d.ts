/**
 * Upper case the first character of an input string.
 */
export declare function upperCaseFirst(input: string): string;
