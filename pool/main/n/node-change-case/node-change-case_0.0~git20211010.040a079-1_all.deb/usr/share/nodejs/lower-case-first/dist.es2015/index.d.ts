/**
 * Lower case the first character of an input string.
 */
export declare function lowerCaseFirst(input: string): string;
