import { Options } from "no-case";
export { Options };
export declare function snakeCase(input: string, options?: Options): string;
