export declare function titleCase(input: string): string;
