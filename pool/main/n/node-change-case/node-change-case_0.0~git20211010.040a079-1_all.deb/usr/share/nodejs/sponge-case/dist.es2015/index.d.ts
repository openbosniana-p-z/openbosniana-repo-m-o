export declare function spongeCase(input: string): string;
