export {default} from '../lib/worker/main.cjs';
