'use strict';
module.exports = require('../lib/worker/main.cjs');
