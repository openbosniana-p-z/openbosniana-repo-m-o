#!/usr/bin/env node
import run from '../lib/cli.js';

run();
