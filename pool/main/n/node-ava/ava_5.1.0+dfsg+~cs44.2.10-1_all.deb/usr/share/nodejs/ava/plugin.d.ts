// For compatibility with resolution algorithms other than Node16.

export * from './entrypoints/plugin.cjs';
