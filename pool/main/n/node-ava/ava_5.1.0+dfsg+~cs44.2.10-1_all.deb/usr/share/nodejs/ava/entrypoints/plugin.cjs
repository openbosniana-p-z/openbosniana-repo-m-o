'use strict';
module.exports = require('../lib/worker/plugin.cjs');
