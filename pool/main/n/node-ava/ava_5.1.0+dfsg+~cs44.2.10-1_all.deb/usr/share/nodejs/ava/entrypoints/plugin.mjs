import * as plugin from '../lib/worker/plugin.cjs';

const {registerSharedWorker} = plugin;
export {registerSharedWorker};
