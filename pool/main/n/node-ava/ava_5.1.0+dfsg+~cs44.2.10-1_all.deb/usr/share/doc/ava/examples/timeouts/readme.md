# Test timeouts

> Example for [test timeouts](https://github.com/avajs/ava/blob/main/docs/07-test-timeouts.md)

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/avajs/ava/tree/main/examples/timeouts?file=test.js&terminal=test&view=editor)
