'use strict';
const test = require('ava');

test('unicorn', t => {
	t.pass();
});

test('rainbow', t => {
	t.fail();
});
