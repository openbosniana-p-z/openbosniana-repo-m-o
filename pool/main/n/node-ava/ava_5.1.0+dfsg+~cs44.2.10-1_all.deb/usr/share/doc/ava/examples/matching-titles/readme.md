# Running tests with matching titles

> Example for [running tests with matching titles](https://github.com/avajs/ava/blob/main/docs/05-command-line.md#running-tests-with-matching-titles)

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/avajs/ava/tree/main/examples/matching-titles?file=test.js&terminal=test&view=editor)
