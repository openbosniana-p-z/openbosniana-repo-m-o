# Endpoint testing

> Example for [endpoint testing](https://github.com/avajs/ava/blob/main/docs/recipes/endpoint-testing.md)

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/avajs/ava/tree/main/examples/endpoint-testing?file=test.js&terminal=test&view=editor)
