# Using ES modules in AVA

AVA 4 supports ES modules out of the box.
