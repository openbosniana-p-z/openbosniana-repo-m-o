# TypeScript context example

> TypeScript example for [typing `t.context`](https://github.com/avajs/ava/blob/main/docs/recipes/typescript.md#typing-tcontext)

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/avajs/ava/tree/main/examples/typescript-context?file=source%2Ftest.ts&terminal=test&view=editor)
