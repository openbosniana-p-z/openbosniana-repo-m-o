# TypeScript basic example

> Basic example for [AVA with TypeScript](https://github.com/avajs/ava/blob/main/docs/recipes/typescript.md)

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/avajs/ava/tree/main/examples/typescript-basic?file=source%2Ftest.ts&terminal=test&view=editor)
