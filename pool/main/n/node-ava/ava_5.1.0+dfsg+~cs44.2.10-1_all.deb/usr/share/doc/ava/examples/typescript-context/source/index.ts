export const concat = (input: string[]) => input.join(' ');
