module.exports = require('debug-fabulous').spawnable(require('../package.json').name);
