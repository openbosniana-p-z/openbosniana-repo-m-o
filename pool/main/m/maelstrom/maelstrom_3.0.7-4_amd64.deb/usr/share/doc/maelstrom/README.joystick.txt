
				JOYSTICKS

Maelstrom uses SDL's joystick support, so they should just work.  Moving
the joystick left and right rotates the ship, and pushing it forward will
accelerate the ship.  The first joystick button fires the ship's weapons
and the second joystick button activates the shields.

Enjoy!
	-Sam Lantinga			(slouken@libsdl.org)

