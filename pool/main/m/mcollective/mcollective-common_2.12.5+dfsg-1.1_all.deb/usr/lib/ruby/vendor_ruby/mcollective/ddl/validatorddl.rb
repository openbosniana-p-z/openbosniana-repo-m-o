module MCollective
  module DDL
    class ValidatorDDL<Base
    end
  end
end
