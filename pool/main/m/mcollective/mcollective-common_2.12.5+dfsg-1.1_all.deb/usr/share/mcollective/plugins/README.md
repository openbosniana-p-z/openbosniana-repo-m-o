Since mcollective 2.8.0 'core' plugins are shipped in the sitelibdir of
mcollective and not anymore in /usr/share/mcollective directory.

* <https://tickets.puppetlabs.com/browse/MCO-583>
* <https://github.com/puppetlabs/marionette-collective/pull/283/files>

User contributed plugins can still be placed in the /usr/share/mcollective
directory.

* <https://puppet.com/docs/mcollective/current/deploy/plugins.html#about-the-libdir>
