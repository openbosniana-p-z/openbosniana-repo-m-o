dofile(minetest.get_modpath("testformspec").."/dummy_items.lua")
dofile(minetest.get_modpath("testformspec").."/formspec.lua")
dofile(minetest.get_modpath("testformspec").."/callbacks.lua")
