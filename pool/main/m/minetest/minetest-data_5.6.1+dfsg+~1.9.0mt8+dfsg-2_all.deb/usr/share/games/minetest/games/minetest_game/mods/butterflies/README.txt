Minetest Game mod: Butterflies
==============================
Adds butterflies to the world on mapgen, which can be caught in a net if the
fireflies mod is also enabled.

Authors of source code
----------------------
Shara RedCat (MIT)

Authors of media (textures)
---------------------------
Shara RedCat (CC BY-SA 3.0):
  butterflies_butterfly_*.png
  butterflies_butterfly_*_animated.png