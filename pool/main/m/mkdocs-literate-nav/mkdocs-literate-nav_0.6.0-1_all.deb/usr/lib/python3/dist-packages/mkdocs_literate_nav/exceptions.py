class LiterateNavError(Exception):
    pass
