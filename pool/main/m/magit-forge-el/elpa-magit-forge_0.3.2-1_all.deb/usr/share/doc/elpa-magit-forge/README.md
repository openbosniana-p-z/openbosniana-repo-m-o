Work with Git forges from the comfort of Magit
==============================================

Work with Git forges, such as Github and Gitlab, from the comfort
of Magit and the rest of Emacs.

![screenshot-status](http://readme.emacsair.me/forge-status.png)

![screenshot-topic](http://readme.emacsair.me/forge-topic.png)

Please see the [manual] and the [announcement] for more information.

[manual]: https://magit.vc/manual/forge
[announcement]: https://emacsair.me/2018/12/19/forge-0.1
