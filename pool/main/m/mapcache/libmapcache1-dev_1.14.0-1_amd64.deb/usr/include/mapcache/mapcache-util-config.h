#ifndef _MAPCACHE_UTIL_CONFIG_H
#define _MAPCACHE_UTIL_CONFIG_H

#define USE_OGR 1
#define USE_GEOS 1

#endif
