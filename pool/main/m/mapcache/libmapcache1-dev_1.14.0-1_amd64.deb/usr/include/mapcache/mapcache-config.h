#ifndef _MAPCACHE_CONFIG_H
#define _MAPCACHE_CONFIG_H

#define USE_PIXMAN 1
/* #undef USE_FASTCGI */
#define USE_SQLITE 1
/* #undef USE_POSTGRESQL */
/* #undef USE_BDB */
#define USE_LMDB 1
#define USE_MEMCACHE 1
#define USE_REDIS 1
#define USE_TIFF 1
/* #undef USE_TIFF_WRITE */
/* #undef USE_GEOTIFF */
#define USE_PCRE 1
/* #undef USE_MAPSERVER */
/* #undef USE_RIAK */
#define USE_GDAL 1

#define HAVE_STRNCASECMP 1
#define HAVE_SYMLINK 1
#define HAVE_STRPTIME 1
#define HAVE_TIMEGM 1

#endif
