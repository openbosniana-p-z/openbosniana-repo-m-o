#!/usr/bin/python3

"""scan a music directory to find concerts near a specified location"""
__version__ = "2.1.6"
