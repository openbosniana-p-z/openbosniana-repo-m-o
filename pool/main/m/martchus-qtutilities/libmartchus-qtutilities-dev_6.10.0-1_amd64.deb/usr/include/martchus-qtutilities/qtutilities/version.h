// Created via CMake from template version.h.in
// WARNING! Any changes to this file will be overwritten by the next CMake run!

#ifndef QT_UTILITIES_VERSION

#define QT_UTILITIES_VERSION_MAJOR 6
#define QT_UTILITIES_VERSION_MINOR 10
#define QT_UTILITIES_VERSION_PATCH 0
#define QT_UTILITIES_VERSION_VCSRE 
#define QT_UTILITIES_VERSION_VCSID ""

#define QT_UTILITIES_VERSION_STR "6.10.0"
#define QT_UTILITIES_VERSION_CHECK(major, minor, patch) ((major<<16)|(minor<<8)|(patch))
#define QT_UTILITIES_VERSION \
    QT_UTILITIES_VERSION_CHECK(QT_UTILITIES_VERSION_MAJOR, QT_UTILITIES_VERSION_MINOR, QT_UTILITIES_VERSION_PATCH)

/*!
 * \def QT_UTILITIES_VERSION_MAJOR
 * \brief Mayor version of the qtutilities library.
 */

/*!
 * \def QT_UTILITIES_VERSION_MINOR
 * \brief Minor version of the qtutilities library.
 */

/*!
 * \def QT_UTILITIES_VERSION_PATCH
 * \brief Patch version of the qtutilities library.
 */

/*!
 * \def QT_UTILITIES_VERSION_VCSRE
 * \brief Revision number in the version control system of the qtutilities library.
 */

/*!
 * \def QT_UTILITIES_VERSION_VCSID
 * \brief Revision ID in the version control system of the qtutilities library.
 */

/*!
 * \def QT_UTILITIES_VERSION_STR
 * \brief Version of the qtutilities library as string (for display purposes).
 */

/*!
 * \def QT_UTILITIES_VERSION_CHECK
 * \brief Can be used like "#if (QT_UTILITIES_VERSION >= QT_UTILITIES_VERSION_CHECK(5, 1, 0))".
 */

/*!
 * \def QT_UTILITIES_VERSION
 * \brief Defined as (major << 16) + (minor << 8) + patch.
 */

#endif // QT_UTILITIES_VERSION
