libSCmbptr12.LIBSUF
#include <chemistry/qc/wfn/LIBS.h>
#include <chemistry/qc/scf/LIBS.h>
#include <chemistry/qc/intv3/LIBS.h>
#include <chemistry/qc/cints/LIBS.h>
#include <chemistry/qc/mbpt/LIBS.h>
#include <chemistry/molecule/LIBS.h>
#include <util/group/LIBS.h>
#include <util/misc/LIBS.h>
#include <util/keyval/LIBS.h>

