#ifdef CXX_RESTRICT
#define restrictxx restrict
#else
#define restrictxx
#endif
