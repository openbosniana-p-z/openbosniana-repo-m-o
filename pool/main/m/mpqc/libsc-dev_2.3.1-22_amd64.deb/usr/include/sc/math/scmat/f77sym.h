
#define F77_PDSTEQR pdsteqr_
#define F77_DCOPY dcopy_
#define F77_DNRM2 dnrm2_
#define F77_DDOT ddot_
#define F77_DSCAL dscal_
#define F77_DAXPY daxpy_
