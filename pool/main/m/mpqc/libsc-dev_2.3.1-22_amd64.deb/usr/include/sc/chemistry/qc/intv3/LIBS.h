libSCintv3.LIBSUF
#include <util/keyval/LIBS.h>
#include <util/misc/LIBS.h>
#include <chemistry/molecule/LIBS.h>
#include <chemistry/qc/basis/LIBS.h>
#include <chemistry/qc/oint3/LIBS.h>
