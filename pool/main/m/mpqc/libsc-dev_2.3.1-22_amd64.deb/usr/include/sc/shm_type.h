#ifndef SHMTYPE
#define SHMTYPE char*
#endif
