libSCsolvent.LIBSUF
#include <chemistry/molecule/LIBS.h>
