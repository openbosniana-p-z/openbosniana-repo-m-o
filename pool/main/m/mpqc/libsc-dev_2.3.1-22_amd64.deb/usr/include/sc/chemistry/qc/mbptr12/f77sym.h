
#define F77_DGEMM dgemm_
#define F77_DAXPY daxpy_
#define F77_DDOT ddot_
#define F77_DGESVD dgesvd_
#define F77_DSPSVX dspsvx_

