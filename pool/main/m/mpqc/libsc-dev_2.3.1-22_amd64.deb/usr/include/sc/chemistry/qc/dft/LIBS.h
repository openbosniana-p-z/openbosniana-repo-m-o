libSCdft.LIBSUF
#include <chemistry/qc/scf/LIBS.h>
#include <chemistry/qc/wfn/LIBS.h>
#include <chemistry/molecule/LIBS.h>
#include <util/keyval/LIBS.h>

