/* src/lib/scconfig.h.  Generated from scconfig.h.in by configure.  */
/* src/lib/scconfig.h.in.  Generated from configure.in by autoheader.  */

/* */
#define ALWAYS_USE_MPI 1

/* */
/* #undef CXX_RESTRICT */

/* */
/* #undef DEFAULT_ARMCI */

/* */
#define DEFAULT_MPI 1

/* */
/* #undef DEFAULT_MTMPI */

/* */
#define DEFAULT_SC_MEMORY 32000000

/* */
/* #undef EXPLICIT_TEMPLATE_INSTANTIATION */

/* */
/* #undef HAVE_ARMCI */

/* Define to 1 if you have the <asm/fpu.h> header file. */
/* #undef HAVE_ASM_FPU_H */

/* */
#define HAVE_BACKTRACE 1

/* */
/* #undef HAVE_CCA_CHEM_HEADERS */

/* */
/* #undef HAVE_CCA_SPEC_BABEL_HEADERS */

/* Define to 1 if you have the `ctime' function. */
#define HAVE_CTIME 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you don't have `vprintf' but do have `_doprnt.' */
/* #undef HAVE_DOPRNT */

/* Define to 1 if you have the `drand48' function. */
#define HAVE_DRAND48 1

/* Define to 1 if you have the <endian.h> header file. */
#define HAVE_ENDIAN_H 1

/* */
#define HAVE_FCHDIR 1

/* Define to 1 if you have the <fcntl.h> header file. */
#define HAVE_FCNTL_H 1

/* Define to 1 if you have the `fedisableexcept' function. */
#define HAVE_FEDISABLEEXCEPT 1

/* Define to 1 if you have the `feenableexcept' function. */
#define HAVE_FEENABLEEXCEPT 1

/* Define to 1 if you have the <fenv.h> header file. */
#define HAVE_FENV_H 1

/* Define to 1 if you have the <fp.h> header file. */
/* #undef HAVE_FP_H */

/* Define to 1 if you have the `geteuid' function. */
#define HAVE_GETEUID 1

/* Define to 1 if you have the `gethostname' function. */
#define HAVE_GETHOSTNAME 1

/* Define to 1 if you have the `getpwuid' function. */
#define HAVE_GETPWUID 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <iostream> header file. */
#define HAVE_IOSTREAM 1

/* */
#define HAVE_IOS_FMTFLAGS 1

/* */
#define HAVE_ISNAN 1

/* */
#define HAVE_LIBDERIV 1

/* Define to 1 if you have the <libderiv/libderiv.h> header file. */
#define HAVE_LIBDERIV_LIBDERIV_H 1

/* Define to 1 if you have the `dl' library (-ldl). */
#define HAVE_LIBDL 1

/* Define to 1 if you have the `fl' library (-lfl). */
/* #undef HAVE_LIBFL */

/* */
#define HAVE_LIBINT 1

/* Define to 1 if you have the <libint/libint.h> header file. */
#define HAVE_LIBINT_LIBINT_H 1

/* Define to 1 if you have the `m' library (-lm). */
#define HAVE_LIBM 1

/* */
#define HAVE_LIBR12 1

/* Define to 1 if you have the <libr12/libr12.h> header file. */
#define HAVE_LIBR12_LIBR12_H 1

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* */
#define HAVE_LONG_LONG 1

/* Define to 1 if you have the <machine/endian.h> header file. */
/* #undef HAVE_MACHINE_ENDIAN_H */

/* Define to 1 if you have the <machine/fpu.h> header file. */
/* #undef HAVE_MACHINE_FPU_H */

/* */
#define HAVE_MPI 1

/* */
#define HAVE_MPIIO 1

/* */
#define HAVE_MPIPP 1

/* */
#define HAVE_MPI_INIT_THREAD 1

/* */
/* #undef HAVE_NIAMA */

/* */
/* #undef HAVE_PERF */

/* */
#define HAVE_PTHREAD 1

/* */
#define HAVE_PUBSEEKOFF 1

/* Define to 1 if you have the <pwd.h> header file. */
#define HAVE_PWD_H 1

/* */
/* #undef HAVE_SCALABLE_BLAS */

/* */
/* #undef HAVE_SEEKOFF */

/* Define to 1 if you have the `semget' function. */
#define HAVE_SEMGET 1

/* Define to 1 if you have the `setenv' function. */
#define HAVE_SETENV 1

/* Define to 1 if you have the `setrlimit' function. */
#define HAVE_SETRLIMIT 1

/* */
#define HAVE_SGETN 1

/* Define to 1 if you have the `shmget' function. */
#define HAVE_SHMGET 1

/* */
/* #undef HAVE_SIDL_HEADERS */

/* Define to 1 if you have the `sigfillset' function. */
#define HAVE_SIGFILLSET 1

/* Define to 1 if you have the `signal' function. */
#define HAVE_SIGNAL 1

/* Define to 1 if you have the <sstream> header file. */
#define HAVE_SSTREAM 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `strerror' function. */
#define HAVE_STRERROR 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `system' function. */
#define HAVE_SYSTEM 1

/* */
#define HAVE_SYSV_IPC 1

/* Define to 1 if you have the <sys/endian.h> header file. */
/* #undef HAVE_SYS_ENDIAN_H */

/* Define to 1 if you have the <sys/ioctl.h> header file. */
#define HAVE_SYS_IOCTL_H 1

/* Define to 1 if you have the <sys/ipc.h> header file. */
#define HAVE_SYS_IPC_H 1

/* Define to 1 if you have the <sys/machine.h> header file. */
/* #undef HAVE_SYS_MACHINE_H */

/* Define to 1 if you have the <sys/resource.h> header file. */
#define HAVE_SYS_RESOURCE_H 1

/* Define to 1 if you have the <sys/sem.h> header file. */
#define HAVE_SYS_SEM_H 1

/* Define to 1 if you have the <sys/shm.h> header file. */
#define HAVE_SYS_SHM_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/times.h> header file. */
#define HAVE_SYS_TIMES_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <termios.h> header file. */
#define HAVE_TERMIOS_H 1

/* Define to 1 if you have the `time' function. */
#define HAVE_TIME 1

/* Define to 1 if you have the <time.h> header file. */
#define HAVE_TIME_H 1

/* */
#define HAVE_TYPENAME 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the `vprintf' function. */
#define HAVE_VPRINTF 1

/* */
#define HOST_ARCH "x86_64-pc-linux-gnu"

/* */
#define INSTALLED_SCLIBDIR "/usr/lib"

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME ""

/* Define to the full name and version of this package. */
#define PACKAGE_STRING ""

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME ""

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION ""

/* */
#define REF_OPTIMIZE 1

/* Define as the return type of signal handlers (`int' or `void'). */
#define RETSIGTYPE void

/* */
#define SCDATADIR "/usr/share/mpqc"

/* */
#define SC_BUILDID ""

/* */
#define SC_MAJOR_VERSION 2

/* */
#define SC_MICRO_VERSION 1

/* */
#define SC_MINOR_VERSION 3

/* */
#define SC_MPI_THREAD_LEVEL MPI_THREAD_SINGLE

/* */
#define SC_VERSION "2.3.1"

/* */
/* #undef SEMCTL_REQUIRES_SEMUN */

/* */
/* #undef SIGHASELLIP */

/* */
/* #undef SRC_SCLIBDIR */

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* */
#define TARGET_ARCH "x86_64-pc-linux-gnu"

/* Define to 1 if your <sys/time.h> declares `struct tm'. */
/* #undef TM_IN_SYS_TIME */

/* */
#define USING_NAMESPACE_STD 1

/* */
/* #undef WORDS_BIGENDIAN */

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */


#include "shm_type.h"
#include "restrictxx.h"

