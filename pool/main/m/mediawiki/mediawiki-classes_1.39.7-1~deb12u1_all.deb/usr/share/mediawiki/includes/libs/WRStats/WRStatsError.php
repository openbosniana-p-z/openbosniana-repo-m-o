<?php

namespace Wikimedia\WRStats;

/**
 * Exception class for errors thrown by the WRStats library
 *
 * @since 1.39
 */
class WRStatsError extends \Exception {
}
