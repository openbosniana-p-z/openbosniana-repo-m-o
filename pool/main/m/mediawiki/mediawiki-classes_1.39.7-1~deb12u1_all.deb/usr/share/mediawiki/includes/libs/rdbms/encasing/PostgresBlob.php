<?php

namespace Wikimedia\Rdbms;

/**
 * @newable
 */
class PostgresBlob extends Blob {

}
