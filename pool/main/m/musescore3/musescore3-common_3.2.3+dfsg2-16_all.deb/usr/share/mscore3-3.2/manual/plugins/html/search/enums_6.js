var searchData=
[
  ['offsettype_0',['OffsetType',['../namespace_ms.html#a2b2218c26f6052dea57cb7b6427008ab',1,'Ms']]],
  ['ornamentstyle_1',['OrnamentStyle',['../class_ms_1_1_m_score.html#a75ce800262bbec6597c8af6908c624ac',1,'Ms::MScore']]]
];
