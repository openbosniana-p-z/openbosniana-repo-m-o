var searchData=
[
  ['element_0',['Element',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#ac2b0e7fe99346713cc02fd65d555a3c5',1,'Ms::PluginAPI::PluginAPI']]],
  ['element_1',['element',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#ab682fe4c39ffe0cbb5d51affe4db02b8',1,'Ms::PluginAPI::Cursor']]],
  ['elements_2',['elements',['../class_ms_1_1_plugin_a_p_i_1_1_selection.html#a57b9543b1da324db238953503fa4d32a',1,'Ms::PluginAPI::Selection']]],
  ['excerpts_3',['excerpts',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#a5f1d61829e4b9314767d9bbca61e9032',1,'Ms::PluginAPI::Score']]]
];
