var searchData=
[
  ['offset_0',['offset',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a8328f0a340ec3cf9dd7b6441c23ccd0b',1,'Ms::PluginAPI::Element']]],
  ['offsettype_1',['OffsetType',['../namespace_ms.html#a2b2218c26f6052dea57cb7b6427008ab',1,'Ms']]],
  ['offsetx_2',['offsetX',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a0fbd693bb872fd51eda5e1969a65cb2e',1,'Ms::PluginAPI::Element']]],
  ['offsety_3',['offsetY',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#aa3a3428649a29793651843147a216e7e',1,'Ms::PluginAPI::Element']]],
  ['ornamentstyle_4',['OrnamentStyle',['../class_ms_1_1_m_score.html#a75ce800262bbec6597c8af6908c624ac',1,'Ms::MScore::OrnamentStyle()'],['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a9c9cf6f326e546b654632f2c482e0da0',1,'Ms::PluginAPI::PluginAPI::OrnamentStyle()']]],
  ['ossia_5',['OSSIA',['../namespace_ms.html#a16b11be27a8e9362dd122c4d879e01aea75633a8231fdde71c053ec1a9d491cb5',1,'Ms']]],
  ['ottava_6',['OTTAVA',['../namespace_ms.html#a16b11be27a8e9362dd122c4d879e01aea8ff5481d98e85c6dea99f8cd8324240b',1,'Ms::OTTAVA()'],['../namespace_ms.html#aa46ffb71b1b0cd634b2054fa59ec5f90a8ff5481d98e85c6dea99f8cd8324240b',1,'Ms::OTTAVA()']]],
  ['ottava_5fsegment_7',['OTTAVA_SEGMENT',['../namespace_ms.html#a16b11be27a8e9362dd122c4d879e01aea0839bcba4cae85e3792c7974aa156d8a',1,'Ms']]]
];
