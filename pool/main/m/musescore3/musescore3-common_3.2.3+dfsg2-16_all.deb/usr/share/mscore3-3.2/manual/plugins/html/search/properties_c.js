var searchData=
[
  ['name_0',['name',['../class_ms_1_1_plugin_a_p_i_1_1_score_element.html#abc29e461e01cc0c712944f8f47f91331',1,'Ms::PluginAPI::ScoreElement']]],
  ['next_1',['next',['../class_ms_1_1_plugin_a_p_i_1_1_segment.html#af30f6999c573670e4a72d470f68e925f',1,'Ms::PluginAPI::Segment']]],
  ['nextinmeasure_2',['nextInMeasure',['../class_ms_1_1_plugin_a_p_i_1_1_segment.html#ae3d5e821dd600c7461feac1e3c2fe6ce',1,'Ms::PluginAPI::Segment']]],
  ['nmeasures_3',['nmeasures',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#a86db3068831ab1f05fe9c588c0987b76',1,'Ms::PluginAPI::Score']]],
  ['noteheadgroup_4',['NoteHeadGroup',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#ae135b25cd06dc0d12a06b90409078692',1,'Ms::PluginAPI::PluginAPI']]],
  ['noteheadtype_5',['NoteHeadType',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#aca84bce8a1506872982fd2726684a476',1,'Ms::PluginAPI::PluginAPI']]],
  ['notetype_6',['noteType',['../class_ms_1_1_plugin_a_p_i_1_1_note.html#aa7bbaa20492af8cb403f6a59b36666e7',1,'Ms::PluginAPI::Note::noteType()'],['../class_ms_1_1_plugin_a_p_i_1_1_chord.html#aa7bbaa20492af8cb403f6a59b36666e7',1,'Ms::PluginAPI::Chord::noteType()']]],
  ['notetype_7',['NoteType',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#aabf56509bf9993006cff47308c35d3c4',1,'Ms::PluginAPI::PluginAPI']]],
  ['notevaluetype_8',['NoteValueType',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a7b8c7e62d80c97db910170c6a3f7018a',1,'Ms::PluginAPI::PluginAPI']]],
  ['npages_9',['npages',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#a3327ddfaad600eca652cb54a5f23fea4',1,'Ms::PluginAPI::Score']]],
  ['nstaves_10',['nstaves',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#ac2b4c6d71d393428a57cde2fd562aa7b',1,'Ms::PluginAPI::Score']]],
  ['ntracks_11',['ntracks',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#a69ecc84bd4257af0981fbfb3d6e425dd',1,'Ms::PluginAPI::Score']]],
  ['numerator_12',['numerator',['../class_ms_1_1_plugin_a_p_i_1_1_fraction_wrapper.html#afda10a8365f279d4d95a406787507bde',1,'Ms::PluginAPI::FractionWrapper']]]
];
