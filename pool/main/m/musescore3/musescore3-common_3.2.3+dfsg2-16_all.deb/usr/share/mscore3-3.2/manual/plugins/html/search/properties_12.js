var searchData=
[
  ['velotype_0',['veloType',['../class_ms_1_1_plugin_a_p_i_1_1_note.html#a24adbd2a7cd75f13485d4e4506d7a69d',1,'Ms::PluginAPI::Note']]],
  ['version_1',['version',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#accb344ff518c8d35f4e2a0df6fe3a6d1',1,'Ms::PluginAPI::PluginAPI']]],
  ['voice_2',['voice',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#ab758933db0c5cae44eda958f7bef4790',1,'Ms::PluginAPI::Cursor']]]
];
