var searchData=
[
  ['qmlexcerptslistaccess_0',['QmlExcerptsListAccess',['../class_ms_1_1_plugin_a_p_i_1_1_qml_excerpts_list_access.html',1,'Ms::PluginAPI']]],
  ['qmllistaccess_1',['QmlListAccess',['../class_ms_1_1_plugin_a_p_i_1_1_qml_list_access.html',1,'Ms::PluginAPI']]]
];
