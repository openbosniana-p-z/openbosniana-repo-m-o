var searchData=
[
  ['fraction_0',['fraction',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a7056cbff5ffe90ee1f5d3bfac134e137',1,'Ms::PluginAPI::PluginAPI']]]
];
