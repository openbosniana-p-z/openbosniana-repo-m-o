var searchData=
[
  ['accidental_0',['Accidental',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#aacd787c0379a36b7ea3965c62326f2d4',1,'Ms::PluginAPI::PluginAPI']]],
  ['annotations_1',['annotations',['../class_ms_1_1_plugin_a_p_i_1_1_segment.html#a7debc2bde4a3d63b02a279e32ed1cfe1',1,'Ms::PluginAPI::Segment']]],
  ['autoplace_2',['autoplace',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a54712c7bffe80b5c0195edd48e23732f',1,'Ms::PluginAPI::Element']]]
];
