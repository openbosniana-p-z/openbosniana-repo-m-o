var searchData=
[
  ['vbox_0',['VBOX',['../namespace_ms.html#a16b11be27a8e9362dd122c4d879e01aea77a3d52d60bccb4c3cd3da2a1779ce51',1,'Ms']]],
  ['velotype_1',['veloType',['../class_ms_1_1_plugin_a_p_i_1_1_note.html#a24adbd2a7cd75f13485d4e4506d7a69d',1,'Ms::PluginAPI::Note']]],
  ['version_2',['version',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#accb344ff518c8d35f4e2a0df6fe3a6d1',1,'Ms::PluginAPI::PluginAPI']]],
  ['vibrato_3',['VIBRATO',['../namespace_ms.html#a16b11be27a8e9362dd122c4d879e01aeac6390077ba0d2b63294e61d03727d761',1,'Ms']]],
  ['vibrato_5fsegment_4',['VIBRATO_SEGMENT',['../namespace_ms.html#a16b11be27a8e9362dd122c4d879e01aea63f5eeaf7a3d72c0b2132ca85d960ce2',1,'Ms']]],
  ['voice_5',['voice',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#ab758933db0c5cae44eda958f7bef4790',1,'Ms::PluginAPI::Cursor']]],
  ['volta_6',['VOLTA',['../namespace_ms.html#a16b11be27a8e9362dd122c4d879e01aeaf357a3f022e0159d1592664a0990319d',1,'Ms::VOLTA()'],['../namespace_ms.html#aa46ffb71b1b0cd634b2054fa59ec5f90af357a3f022e0159d1592664a0990319d',1,'Ms::VOLTA()']]],
  ['volta_5fsegment_7',['VOLTA_SEGMENT',['../namespace_ms.html#a16b11be27a8e9362dd122c4d879e01aea8a4fb23c1e5362b4567801e8d07b75ab',1,'Ms']]]
];
