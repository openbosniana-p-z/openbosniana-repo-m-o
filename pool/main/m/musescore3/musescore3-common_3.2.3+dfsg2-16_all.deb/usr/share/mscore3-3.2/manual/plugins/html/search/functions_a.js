var searchData=
[
  ['setduration_0',['setDuration',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#ac5a4dacc608176cab4ccf63ecbc08c82',1,'Ms::PluginAPI::Cursor']]],
  ['setmetatag_1',['setMetaTag',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#a6bd38868a449f9c2ce44acef7574c58e',1,'Ms::PluginAPI::Score']]],
  ['startcmd_2',['startCmd',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#abf31b1d2e931e0fabffa12b13de8d40e',1,'Ms::PluginAPI::Score']]]
];
