var searchData=
[
  ['harmonycount_0',['harmonyCount',['../class_ms_1_1_plugin_a_p_i_1_1_part.html#acb5f572451e3137e0ee879a8cb848f79',1,'Ms::PluginAPI::Part::harmonyCount()'],['../class_ms_1_1_plugin_a_p_i_1_1_score.html#acb5f572451e3137e0ee879a8cb848f79',1,'Ms::PluginAPI::Score::harmonyCount()']]],
  ['hasdrumstaff_1',['hasDrumStaff',['../class_ms_1_1_plugin_a_p_i_1_1_part.html#a4bcec852e9f7e72a40f4f40385364b3e',1,'Ms::PluginAPI::Part']]],
  ['hasharmonies_2',['hasHarmonies',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#a2aa7517fa56f8551e0a9552f6634b9e6',1,'Ms::PluginAPI::Score']]],
  ['haslyrics_3',['hasLyrics',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#aff1da8286793da740affad2b2910a42b',1,'Ms::PluginAPI::Score']]],
  ['haspitchedstaff_4',['hasPitchedStaff',['../class_ms_1_1_plugin_a_p_i_1_1_part.html#aa71bc5c580284204c3692332c79c9bdc',1,'Ms::PluginAPI::Part']]],
  ['hastabstaff_5',['hasTabStaff',['../class_ms_1_1_plugin_a_p_i_1_1_part.html#a155df99636c08093e8c9857944588b16',1,'Ms::PluginAPI::Part']]],
  ['headgroup_6',['headGroup',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a95add92f58dd941a9d05b79f5f02c65a',1,'Ms::PluginAPI::Element']]],
  ['headtype_7',['headType',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a04dd26feca1aabf77e3933edc0afd6a3',1,'Ms::PluginAPI::Element']]]
];
