var searchData=
[
  ['parent_0',['parent',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a3348fd22ba6199b853373c2cb57acdb7',1,'Ms::PluginAPI::Element']]],
  ['partname_1',['partName',['../class_ms_1_1_plugin_a_p_i_1_1_part.html#a7d96d07f660516149ffd29540216682d',1,'Ms::PluginAPI::Part']]],
  ['parts_2',['parts',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#abb2af6f29c22c5ab14fbb60aa9ea2f13',1,'Ms::PluginAPI::Score']]],
  ['partscore_3',['partScore',['../class_ms_1_1_plugin_a_p_i_1_1_excerpt.html#a7751fbea19c29c4858c8a5b9afcacbb9',1,'Ms::PluginAPI::Excerpt']]],
  ['pitch_4',['pitch',['../class_ms_1_1_plugin_a_p_i_1_1_note.html#a05c8b22d2905f7a52fa31b13f85c70f3',1,'Ms::PluginAPI::Note']]],
  ['placement_5',['Placement',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a7a2226a7263242f1fcb0e60634b68635',1,'Ms::PluginAPI::PluginAPI']]],
  ['plugintype_6',['pluginType',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a5fac96ae051a9f09f99b423019783fdc',1,'Ms::PluginAPI::PluginAPI']]],
  ['prev_7',['prev',['../class_ms_1_1_plugin_a_p_i_1_1_segment.html#a174b5897246d0a688be51b9cf60e30f2',1,'Ms::PluginAPI::Segment']]],
  ['previnmeasure_8',['prevInMeasure',['../class_ms_1_1_plugin_a_p_i_1_1_segment.html#a9be53a4dcf5a9262e323e7f392a7a992',1,'Ms::PluginAPI::Segment']]]
];
