var searchData=
[
  ['note_0',['Note',['../class_ms_1_1_note.html',1,'Note'],['../class_ms_1_1_plugin_a_p_i_1_1_note.html',1,'Note']]],
  ['notehead_1',['NoteHead',['../class_ms_1_1_note_head.html',1,'Ms']]]
];
