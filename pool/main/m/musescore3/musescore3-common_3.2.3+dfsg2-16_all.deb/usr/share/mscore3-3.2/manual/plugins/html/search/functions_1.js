var searchData=
[
  ['add_0',['add',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#ad648841187c29afcf273a4037d2cb4ba',1,'Ms::PluginAPI::Cursor::add()'],['../class_ms_1_1_plugin_a_p_i_1_1_chord.html#a6f12b506368bb928ae4b2c7761ba2a56',1,'Ms::PluginAPI::Chord::add()']]],
  ['addnote_1',['addNote',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#a4231eff7a9a006b0cd5d96e2f43df9f9',1,'Ms::PluginAPI::Cursor']]],
  ['addtext_2',['addText',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#a64012576ca644ffcddde78a87054267f',1,'Ms::PluginAPI::Score']]],
  ['appendmeasures_3',['appendMeasures',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#a705fc08d414c44279c5cfa9f15258777',1,'Ms::PluginAPI::Score']]]
];
