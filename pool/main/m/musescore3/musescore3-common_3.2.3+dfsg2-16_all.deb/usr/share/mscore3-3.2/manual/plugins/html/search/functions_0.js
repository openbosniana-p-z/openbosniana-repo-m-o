var searchData=
[
  ['_5fname_0',['_name',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a5b8c1d3353810318b29e94bf66e05728',1,'Ms::PluginAPI::Element']]]
];
