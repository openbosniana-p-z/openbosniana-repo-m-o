var searchData=
[
  ['canvaspos_0',['canvasPos',['../class_ms_1_1_beam.html#a9974ddd15f8fd92ad57add627e2c0c9c',1,'Ms::Beam']]],
  ['clone_1',['clone',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a4f21499ff9366e1b3953d2808c32d8be',1,'Ms::PluginAPI::Element']]]
];
