var searchData=
[
  ['offset_0',['offset',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a8328f0a340ec3cf9dd7b6441c23ccd0b',1,'Ms::PluginAPI::Element']]],
  ['offsetx_1',['offsetX',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a0fbd693bb872fd51eda5e1969a65cb2e',1,'Ms::PluginAPI::Element']]],
  ['offsety_2',['offsetY',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#aa3a3428649a29793651843147a216e7e',1,'Ms::PluginAPI::Element']]],
  ['ornamentstyle_3',['OrnamentStyle',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a9c9cf6f326e546b654632f2c482e0da0',1,'Ms::PluginAPI::PluginAPI']]]
];
