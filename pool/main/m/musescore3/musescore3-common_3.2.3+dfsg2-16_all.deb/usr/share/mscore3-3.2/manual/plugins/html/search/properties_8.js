var searchData=
[
  ['instrumentid_0',['instrumentId',['../class_ms_1_1_plugin_a_p_i_1_1_part.html#aa866d95e37c558e73e242eebddda847e',1,'Ms::PluginAPI::Part']]]
];
