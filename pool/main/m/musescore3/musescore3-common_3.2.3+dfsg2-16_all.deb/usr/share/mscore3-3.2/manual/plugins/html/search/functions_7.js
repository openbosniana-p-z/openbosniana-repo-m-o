var searchData=
[
  ['newcursor_0',['newCursor',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#a1bc8f4a235affffb0031fbe9aada3b8c',1,'Ms::PluginAPI::Score']]],
  ['newelement_1',['newElement',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a3e20d3539a463dc9e56883ee8730154d',1,'Ms::PluginAPI::PluginAPI']]],
  ['next_2',['next',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#a80870c233d0237e3588a2d6f8d176916',1,'Ms::PluginAPI::Cursor']]],
  ['nextmeasure_3',['nextMeasure',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#a81ff8e4b8086a49a05008e2a3ebfbe07',1,'Ms::PluginAPI::Cursor']]]
];
