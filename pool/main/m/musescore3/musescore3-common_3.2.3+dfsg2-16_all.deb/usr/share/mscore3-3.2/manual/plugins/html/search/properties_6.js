var searchData=
[
  ['glissando_0',['Glissando',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a25509639a61245b495b192795e0a107e',1,'Ms::PluginAPI::PluginAPI']]],
  ['glissandostyle_1',['GlissandoStyle',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#ad4058da98b3886948f9016726255dde1',1,'Ms::PluginAPI::PluginAPI']]]
];
