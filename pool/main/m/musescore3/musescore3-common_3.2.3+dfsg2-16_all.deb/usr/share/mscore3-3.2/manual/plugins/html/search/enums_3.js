var searchData=
[
  ['glissandostyle_0',['GlissandoStyle',['../namespace_ms.html#aa75b88cb58606dc5b17affc6436eb263',1,'Ms']]],
  ['glissandotype_1',['GlissandoType',['../namespace_ms.html#a80ae4ac7d0dfa9de7aecce4f0ddee69c',1,'Ms']]],
  ['group_2',['Group',['../class_ms_1_1_note_head.html#ab53aba6e9e88c687bf66290251c84c53',1,'Ms::NoteHead']]]
];
