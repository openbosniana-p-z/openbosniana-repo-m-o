var searchData=
[
  ['pagepos_0',['pagePos',['../class_ms_1_1_beam.html#a1ee0fd20d552c104d79c8ed86c6c537e',1,'Ms::Beam']]],
  ['ppitch_1',['ppitch',['../class_ms_1_1_note.html#ab14e40eef799a875fb65faf5ff6b28db',1,'Ms::Note']]]
];
