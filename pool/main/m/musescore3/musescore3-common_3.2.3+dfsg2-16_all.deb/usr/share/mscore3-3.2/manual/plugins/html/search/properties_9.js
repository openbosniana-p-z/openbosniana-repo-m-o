var searchData=
[
  ['keysig_0',['keysig',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#af1b41945f84fde71b7a46b0ef3069c0d',1,'Ms::PluginAPI::Score']]],
  ['keysignature_1',['keySignature',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#ac30d3283cccf1fe4f3d83b63ef416e78',1,'Ms::PluginAPI::Cursor']]]
];
