var searchData=
[
  ['requiresscore_0',['requiresScore',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a1e7fbe5c604cc0e143f744e0b0988222',1,'Ms::PluginAPI::PluginAPI']]]
];
