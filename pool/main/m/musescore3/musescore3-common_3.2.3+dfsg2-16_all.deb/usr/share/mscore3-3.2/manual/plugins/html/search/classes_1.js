var searchData=
[
  ['chord_0',['Chord',['../class_ms_1_1_plugin_a_p_i_1_1_chord.html',1,'Ms::PluginAPI']]],
  ['cursor_1',['Cursor',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html',1,'Ms::PluginAPI']]]
];
