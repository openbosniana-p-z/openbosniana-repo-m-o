var searchData=
[
  ['measure_0',['measure',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#ab3969e5e929a97466fbc4ea2c8693f5a',1,'Ms::PluginAPI::Cursor']]],
  ['menupath_1',['menuPath',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#afb6a06fc30328be2f07f33be372b3319',1,'Ms::PluginAPI::PluginAPI']]],
  ['midichannel_2',['midiChannel',['../class_ms_1_1_plugin_a_p_i_1_1_part.html#aa7d9728ac8a774a923e79270f3663b14',1,'Ms::PluginAPI::Part']]],
  ['midiprogram_3',['midiProgram',['../class_ms_1_1_plugin_a_p_i_1_1_part.html#ae5ae49bb9a87ce8861887a52bb901d52',1,'Ms::PluginAPI::Part']]],
  ['mscoredpi_4',['mscoreDPI',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a4d38d5b8c9e329c019883bcac9d474c3',1,'Ms::PluginAPI::PluginAPI']]],
  ['mscoremajorversion_5',['mscoreMajorVersion',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a1800f322b90292e92307956e899dcfc4',1,'Ms::PluginAPI::PluginAPI']]],
  ['mscoreminorversion_6',['mscoreMinorVersion',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#afeb98a404015a0454625a6c095fe7da9',1,'Ms::PluginAPI::PluginAPI']]],
  ['mscorerevision_7',['mscoreRevision',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#ace92009a565cc34962b0b2b69f937224',1,'Ms::PluginAPI::Score']]],
  ['mscoreupdateversion_8',['mscoreUpdateVersion',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#add65ef1e3c5bb7097c7e8d027266ce7d',1,'Ms::PluginAPI::PluginAPI']]],
  ['mscoreversion_9',['mscoreVersion',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#aa864ecc3f37e9c9524372f5f28dec7f4',1,'Ms::PluginAPI::PluginAPI::mscoreVersion()'],['../class_ms_1_1_plugin_a_p_i_1_1_score.html#afdb356521f63e6478c2b53249e4f3f7f',1,'Ms::PluginAPI::Score::mscoreVersion()']]]
];
