var searchData=
[
  ['color_0',['color',['../class_ms_1_1_plugin_a_p_i_1_1_element.html#a824cb7f78107b86b9ddc2dcbd285f66b',1,'Ms::PluginAPI::Element::color()'],['../class_ms_1_1_plugin_a_p_i_1_1_score_view.html#a824cb7f78107b86b9ddc2dcbd285f66b',1,'Ms::PluginAPI::ScoreView::color()']]],
  ['composer_1',['composer',['../class_ms_1_1_plugin_a_p_i_1_1_score.html#a5f329ba72e9ec0ba5dcc837e2fed1c17',1,'Ms::PluginAPI::Score']]],
  ['curscore_2',['curScore',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#ad2e45485dcc2ae3a54703c7b5e35aa63',1,'Ms::PluginAPI::PluginAPI']]]
];
