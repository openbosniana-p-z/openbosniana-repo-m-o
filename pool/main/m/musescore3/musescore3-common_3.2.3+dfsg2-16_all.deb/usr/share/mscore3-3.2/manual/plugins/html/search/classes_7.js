var searchData=
[
  ['part_0',['Part',['../class_ms_1_1_plugin_a_p_i_1_1_part.html',1,'Ms::PluginAPI']]],
  ['pluginapi_1',['PluginAPI',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html',1,'Ms::PluginAPI']]]
];
