var searchData=
[
  ['beam_0',['Beam',['../class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html#a98659271126c4e2f90e231ca47019c5d',1,'Ms::PluginAPI::PluginAPI']]]
];
