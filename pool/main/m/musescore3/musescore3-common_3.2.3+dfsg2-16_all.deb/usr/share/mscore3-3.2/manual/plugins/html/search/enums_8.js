var searchData=
[
  ['rewindmode_0',['RewindMode',['../class_ms_1_1_plugin_a_p_i_1_1_cursor.html#a44441ecb09579acd4a2a27bd8c96b704',1,'Ms::PluginAPI::Cursor']]]
];
