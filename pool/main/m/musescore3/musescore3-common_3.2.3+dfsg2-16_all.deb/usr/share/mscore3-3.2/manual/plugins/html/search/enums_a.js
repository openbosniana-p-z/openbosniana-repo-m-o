var searchData=
[
  ['tid_0',['Tid',['../namespace_ms.html#aa46ffb71b1b0cd634b2054fa59ec5f90',1,'Ms']]],
  ['type_1',['Type',['../class_ms_1_1_note_head.html#ac2c13fb451406ca2dc4d0e787d211136',1,'Ms::NoteHead::Type()'],['../class_ms_1_1_layout_break.html#a1d1cfd8ffb84e947f82999c682b666a7',1,'Ms::LayoutBreak::Type()']]]
];
