mithril-stream [![NPM Version](https://img.shields.io/npm/v/mithril-stream.svg)](https://www.npmjs.com/package/mithril-stream) [![NPM License](https://img.shields.io/npm/l/mithril-stream.svg)](https://www.npmjs.com/package/mithril-stream)
==============

Mithril's `m.stream` as a standalone module.

See [mithril.js.org/stream.html](https://mithril.js.org/stream.html) for docs/usage.
