
#define HAVE_UNISTD_H 1
/* #undef WORDS_BIGENDIAN */
/* #undef ICA_ALWAYS_USE_SYMM */

#define BUILD_SSE_ATTRIBUTE_VECTOR_CAN_USE_SUBSCRIPT 1

#define ENABLE_DEBUG_MESSAGES 1

#define SOURCE_ROOT "/build/mia-2eh26p/mia-2.4.7"
#define PLUGIN_SEARCH_PATH  "/usr/lib/x86_64-linux-gnu/mia-2.4/plugins"
#define PLUGIN_INSTALL_PATH  "/usr/lib/x86_64-linux-gnu/mia-2.4/plugins"

#define LONG_64BIT 1
/* #undef HAVE_TBB */
