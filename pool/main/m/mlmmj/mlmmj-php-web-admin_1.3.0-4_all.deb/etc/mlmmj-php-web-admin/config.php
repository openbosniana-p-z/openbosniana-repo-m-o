<?php

$topdir = "/var/spool/mlmmj";
$confdir = dirname(__FILE__);
$templatedir = dirname(__FILE__)."/templates";

?>
