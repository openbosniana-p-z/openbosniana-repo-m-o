// Created via CMake from template version.h.in
// WARNING! Any changes to this file will be overwritten by the next CMake run!

#ifndef CPP_UTILITIES_VERSION

#define CPP_UTILITIES_VERSION_MAJOR 5
#define CPP_UTILITIES_VERSION_MINOR 20
#define CPP_UTILITIES_VERSION_PATCH 0
#define CPP_UTILITIES_VERSION_VCSRE 
#define CPP_UTILITIES_VERSION_VCSID ""

#define CPP_UTILITIES_VERSION_STR "5.20.0"
#define CPP_UTILITIES_VERSION_CHECK(major, minor, patch) ((major<<16)|(minor<<8)|(patch))
#define CPP_UTILITIES_VERSION \
    CPP_UTILITIES_VERSION_CHECK(CPP_UTILITIES_VERSION_MAJOR, CPP_UTILITIES_VERSION_MINOR, CPP_UTILITIES_VERSION_PATCH)

/*!
 * \def CPP_UTILITIES_VERSION_MAJOR
 * \brief Mayor version of the c++utilities library.
 */

/*!
 * \def CPP_UTILITIES_VERSION_MINOR
 * \brief Minor version of the c++utilities library.
 */

/*!
 * \def CPP_UTILITIES_VERSION_PATCH
 * \brief Patch version of the c++utilities library.
 */

/*!
 * \def CPP_UTILITIES_VERSION_VCSRE
 * \brief Revision number in the version control system of the c++utilities library.
 */

/*!
 * \def CPP_UTILITIES_VERSION_VCSID
 * \brief Revision ID in the version control system of the c++utilities library.
 */

/*!
 * \def CPP_UTILITIES_VERSION_STR
 * \brief Version of the c++utilities library as string (for display purposes).
 */

/*!
 * \def CPP_UTILITIES_VERSION_CHECK
 * \brief Can be used like "#if (CPP_UTILITIES_VERSION >= CPP_UTILITIES_VERSION_CHECK(5, 1, 0))".
 */

/*!
 * \def CPP_UTILITIES_VERSION
 * \brief Defined as (major << 16) + (minor << 8) + patch.
 */

#endif // CPP_UTILITIES_VERSION
