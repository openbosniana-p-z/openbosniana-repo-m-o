/*
 * clean.h - removing small flyspecks
 */

MDJVU_FUNCTION void mdjvu_clean(mdjvu_image_t);
