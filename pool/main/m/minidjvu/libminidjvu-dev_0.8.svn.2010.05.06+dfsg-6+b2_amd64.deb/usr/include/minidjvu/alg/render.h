/*
 * render.h - rendering a split image into a bitmap
 */

MDJVU_FUNCTION mdjvu_bitmap_t mdjvu_render(mdjvu_image_t);
