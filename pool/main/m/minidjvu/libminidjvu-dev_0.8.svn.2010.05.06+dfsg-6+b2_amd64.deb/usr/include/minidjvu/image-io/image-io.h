/*
 * formats.h - an intermediate header to include format support headers
 */

#ifndef MDJVU_IMAGE_IO_H
#define MDJVU_IMAGE_IO_H

#include "pbm.h"
#include "bmp.h"
#include "tiff.h"

#endif
