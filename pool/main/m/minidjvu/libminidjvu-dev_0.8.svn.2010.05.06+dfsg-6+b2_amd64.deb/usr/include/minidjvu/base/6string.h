/*
 * 6string.h - some standard funtions for string manipulation
 */

MDJVU_FUNCTION int mdjvu_ends_with_ignore_case(const char *s, const char *prefix);

