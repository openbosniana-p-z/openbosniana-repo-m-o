/*
 * blitsort.h - sorting blits in an image
 */

MDJVU_FUNCTION void mdjvu_sort_blits(mdjvu_image_t);
