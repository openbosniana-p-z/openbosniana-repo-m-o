/*
 * erosion.h - determine candidates for flipping by image encoder
 */


MDJVU_FUNCTION mdjvu_bitmap_t mdjvu_get_erosion_mask(mdjvu_bitmap_t bmp);
