#ifndef __CLUTTER_DEPRECATED_H__
#define __CLUTTER_DEPRECATED_H__

#define __CLUTTER_DEPRECATED_H_INSIDE__

#include "deprecated/clutter-box-layout.h"
#include "deprecated/clutter-container.h"

#undef __CLUTTER_DEPRECATED_H_INSIDE__

#endif /* __CLUTTER_DEPRECATED_H__ */
