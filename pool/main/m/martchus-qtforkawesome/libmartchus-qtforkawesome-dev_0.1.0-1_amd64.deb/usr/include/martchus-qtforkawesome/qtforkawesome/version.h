// Created via CMake from template version.h.in
// WARNING! Any changes to this file will be overwritten by the next CMake run!

#ifndef QT_FORK_AWESOME_VERSION

#define QT_FORK_AWESOME_VERSION_MAJOR 0
#define QT_FORK_AWESOME_VERSION_MINOR 1
#define QT_FORK_AWESOME_VERSION_PATCH 0
#define QT_FORK_AWESOME_VERSION_VCSRE 
#define QT_FORK_AWESOME_VERSION_VCSID ""

#define QT_FORK_AWESOME_VERSION_STR "0.1.0"
#define QT_FORK_AWESOME_VERSION_CHECK(major, minor, patch) ((major<<16)|(minor<<8)|(patch))
#define QT_FORK_AWESOME_VERSION \
    QT_FORK_AWESOME_VERSION_CHECK(QT_FORK_AWESOME_VERSION_MAJOR, QT_FORK_AWESOME_VERSION_MINOR, QT_FORK_AWESOME_VERSION_PATCH)

/*!
 * \def QT_FORK_AWESOME_VERSION_MAJOR
 * \brief Mayor version of the qtforkawesome library.
 */

/*!
 * \def QT_FORK_AWESOME_VERSION_MINOR
 * \brief Minor version of the qtforkawesome library.
 */

/*!
 * \def QT_FORK_AWESOME_VERSION_PATCH
 * \brief Patch version of the qtforkawesome library.
 */

/*!
 * \def QT_FORK_AWESOME_VERSION_VCSRE
 * \brief Revision number in the version control system of the qtforkawesome library.
 */

/*!
 * \def QT_FORK_AWESOME_VERSION_VCSID
 * \brief Revision ID in the version control system of the qtforkawesome library.
 */

/*!
 * \def QT_FORK_AWESOME_VERSION_STR
 * \brief Version of the qtforkawesome library as string (for display purposes).
 */

/*!
 * \def QT_FORK_AWESOME_VERSION_CHECK
 * \brief Can be used like "#if (QT_FORK_AWESOME_VERSION >= QT_FORK_AWESOME_VERSION_CHECK(5, 1, 0))".
 */

/*!
 * \def QT_FORK_AWESOME_VERSION
 * \brief Defined as (major << 16) + (minor << 8) + patch.
 */

#endif // QT_FORK_AWESOME_VERSION
