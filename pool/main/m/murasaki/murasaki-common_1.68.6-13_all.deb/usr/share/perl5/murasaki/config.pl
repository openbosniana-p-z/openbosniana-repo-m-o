#!/usr/bin/perl
#config file for the murasaki perl scripts

our $root='/usr/share/perl5/murasaki';
our $seqhome="/var/lib/murasaki/seq";
