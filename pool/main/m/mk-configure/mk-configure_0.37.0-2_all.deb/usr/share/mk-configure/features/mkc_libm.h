/********************************************************************\
 Copyright (c) 2014 by Aleksey Cheusov

 See LICENSE file in the distribution.
\********************************************************************/

#ifndef _MKC_LIBM_H_
#define _MKC_LIBM_H_

#include <math.h>

#endif // _MKC_LIBM_H_
