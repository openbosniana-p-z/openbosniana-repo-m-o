extern int
my_printf (void *my_object, const char *my_format, ...)
	__attribute__ ((format (printf, 2, 3)));

int zzz;
