#ifndef _MKC_EXTERNC_H_
#define _MKC_EXTERNC_H_

#ifdef	__cplusplus
# define __MKC_BEGIN_DECLS	extern "C" {
# define __MKC_END_DECLS	}
#else
# define __MKC_BEGIN_DECLS
# define __MKC_END_DECLS
#endif

#endif /* _MKC_EXTERNC_H_ */
