void _mkcfake(void);
void _mkcfake(void)
{
}
