int square(int v) __attribute__ ((const));

int square(int v)
{
	return v * v;
}
