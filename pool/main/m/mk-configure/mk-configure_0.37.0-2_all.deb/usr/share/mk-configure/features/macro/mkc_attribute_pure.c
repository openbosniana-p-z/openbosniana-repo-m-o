int square(int v) __attribute__ ((pure));

int square(int v)
{
	return v * v;
}
