char array[256] __attribute__((aligned(256)));
