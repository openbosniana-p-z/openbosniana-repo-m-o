extern void putter (const char*);
void print_message (void);

void print_message (void)
{
	putter ("Plugin1 sucessfully activated");
}
