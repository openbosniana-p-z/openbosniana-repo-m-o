#include <stdio.h>

int main (int argc, char **argv)
{
	printf("VALUE=%d\n", VALUE);
	return 0;
}
