int fake6 (void);

int fake6 (void)
{
  return 6;
}
