foo = {}

function foo.get ()
   return "foo"
end

return foo
