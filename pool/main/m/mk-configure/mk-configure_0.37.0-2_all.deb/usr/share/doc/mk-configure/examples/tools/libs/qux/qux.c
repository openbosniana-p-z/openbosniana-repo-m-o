#include "qux.h"

int get_int_size (void)
{
	return INT_SIZE;
}
