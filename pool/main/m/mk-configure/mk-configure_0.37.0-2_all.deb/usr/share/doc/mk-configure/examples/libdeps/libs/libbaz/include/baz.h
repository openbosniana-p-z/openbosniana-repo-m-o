#ifndef _BAZ_H_
#define _BAZ_H_

void baz (void);

#endif // _BAZ_H_
