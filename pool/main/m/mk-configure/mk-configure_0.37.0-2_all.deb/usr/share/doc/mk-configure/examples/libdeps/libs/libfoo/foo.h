#ifndef _FOO_H_
#define _FOO_H_

void foo (void);

#endif // _FOO_H_
