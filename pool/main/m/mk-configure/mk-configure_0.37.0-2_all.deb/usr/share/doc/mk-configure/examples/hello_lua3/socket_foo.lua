module ("foo")

function get ()
   return "foo"
end
