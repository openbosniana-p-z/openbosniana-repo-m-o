module ("bar")

function get ()
   return "bar"
end
