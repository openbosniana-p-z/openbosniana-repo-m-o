#include "baz.h"

#include <stdio.h>

void baz (void)
{
	puts ("I am baz");
}
