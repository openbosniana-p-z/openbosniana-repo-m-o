int fake4 (void);

int fake4 (void)
{
  return 4;
}

/* fake must not be exported */
int fake2 (void);

int fake2 (void)
{
  return 2;
}
