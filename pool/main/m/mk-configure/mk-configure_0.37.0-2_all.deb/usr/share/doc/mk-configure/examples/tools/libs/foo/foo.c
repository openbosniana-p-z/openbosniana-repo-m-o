#include "foo.h"

const char *get_msg1 (void)
{
	return "This is a message #";
}
