void puts_stdout (const char *);

int main (int argc, char **argv)
{
	puts_stdout ("I am a client");
	return 0;
}
