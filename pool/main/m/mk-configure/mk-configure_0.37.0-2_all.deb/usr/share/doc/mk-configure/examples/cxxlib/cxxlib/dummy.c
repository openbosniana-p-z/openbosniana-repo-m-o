/* we do use this function, this is just a part of regression test */
void dummy_func (void);
void dummy_func (void)
{
	/* we do nothing here */
}
