#include <config.h>

#ifdef HAVE_STDIO_H
#include <stdio.h>
#endif

int main (int argc, char **argv)
{
	puts (MSG);
	return 0;
}
