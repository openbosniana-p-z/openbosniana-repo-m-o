#include "hello1.h"

const char *msg1 = "Hello1";
