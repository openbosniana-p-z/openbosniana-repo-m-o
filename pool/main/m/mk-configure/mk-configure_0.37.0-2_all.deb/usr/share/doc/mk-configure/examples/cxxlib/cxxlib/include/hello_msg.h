#ifndef _HELLO_H_
#define _HELLO_H_

#include "impl/hello_msg1.h"
#include "impl/hello_msg2.h"

#endif // _HELLO_H_
