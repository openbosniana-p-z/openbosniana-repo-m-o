bar = {}

function bar.get ()
   return "bar"
end

return bar
