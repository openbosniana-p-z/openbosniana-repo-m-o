#ifndef _HELLO_MSG2_H_
#define _HELLO_MSG2_H_

#include <string>

std::string hello_msg2 ();

#endif // _HELLO_MSG2_H_
