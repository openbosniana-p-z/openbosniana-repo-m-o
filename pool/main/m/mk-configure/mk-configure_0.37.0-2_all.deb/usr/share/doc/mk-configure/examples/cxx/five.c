#include "five.h"

int five (void)
{
	return 5;
}
