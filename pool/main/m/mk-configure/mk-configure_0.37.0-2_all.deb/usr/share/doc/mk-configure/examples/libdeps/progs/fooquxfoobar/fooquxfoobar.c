#include "fooqux.h"
#include "bar.h"

#include <stdio.h>

int main (int argc, char **argv)
{
	fooqux ();
	foo ();
	bar ();
	return 0;
}
