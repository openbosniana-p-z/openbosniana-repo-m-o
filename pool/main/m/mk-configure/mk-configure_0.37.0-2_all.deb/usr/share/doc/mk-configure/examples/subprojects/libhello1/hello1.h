#ifndef _HELLO1_H_
#define _HELLO1_H_

extern const char *msg1;

#endif // _HELLO1_H_
