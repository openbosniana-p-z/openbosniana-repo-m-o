int fake5 (void);

int fake5 (void)
{
  return 5;
}
