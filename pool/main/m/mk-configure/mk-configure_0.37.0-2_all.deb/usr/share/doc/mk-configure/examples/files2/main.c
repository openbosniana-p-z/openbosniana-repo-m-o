#include <stdio.h>

extern const char *msg;

int main (int argc, char **argv)
{
	puts (msg);
	return 0;
}
