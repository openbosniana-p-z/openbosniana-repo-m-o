#include "foo.h"

#include <stdio.h>

void foo (void)
{
	puts ("I am foo");
}
