#include <iostream>
#include <string>

std::string hello_msg3 ()
{
	std::string ret = "hello";
	ret += " world";
	ret += " 3!";
	return ret;
}
