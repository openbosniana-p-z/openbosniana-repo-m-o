#include <stdio.h>
#include <stdlib.h>

int main (int argc, char **argv )
{
  puts ("Hello World 2!");
  exit (0);
}
