const char *get_msg2 (void);
