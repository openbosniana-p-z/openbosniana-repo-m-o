#include "seven.h"

int seven (void)
{
	return 7;
}
