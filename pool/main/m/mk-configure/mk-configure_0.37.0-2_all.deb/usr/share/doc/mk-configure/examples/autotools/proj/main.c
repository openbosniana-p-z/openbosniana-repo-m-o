#include <hello_autotools-config.h>

#ifdef HAVE_STDIO_H
#include <stdio.h>
#endif

int main (int argc, char **argv)
{
	puts ("Hello AutoShi^H^H^HTools!");
	return 0;
}
