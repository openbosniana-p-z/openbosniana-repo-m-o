int fake1 (void);

int fake1 (void)
{
  return 1;
}
