#include <stdin.h>

bad code here
