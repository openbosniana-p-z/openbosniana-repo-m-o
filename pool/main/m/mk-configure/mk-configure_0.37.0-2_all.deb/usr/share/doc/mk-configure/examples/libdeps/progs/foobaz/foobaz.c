#include "foo.h"
#include "baz.h"

#include <stdio.h>

int main (int argc, char **argv)
{
	foo ();
	baz ();
	return 0;
}
