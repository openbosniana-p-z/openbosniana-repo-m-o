#include <stdio.h>

int main (int argc, char **argv)
{
	puts ("fsck fake");
	return 0;
}
