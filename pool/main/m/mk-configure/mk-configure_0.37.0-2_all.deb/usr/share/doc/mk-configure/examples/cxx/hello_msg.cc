#include <iostream>

void hello_msg ()
{
	std::cout << "Hello world!\n";
}
