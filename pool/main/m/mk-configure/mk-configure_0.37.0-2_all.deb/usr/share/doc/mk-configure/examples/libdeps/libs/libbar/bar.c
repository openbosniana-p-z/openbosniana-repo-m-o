#include "bar.h"

#include <stdio.h>

void bar (void)
{
	puts ("I am bar");
}
