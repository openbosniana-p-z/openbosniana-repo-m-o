#include <stdio.h>

int main (int argc, char **argv)
{
	puts ("xxzip compression utility\n");
	return 0;
}
