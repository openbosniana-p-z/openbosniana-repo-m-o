#include <stdio.h>
#include <stdlib.h>

int main (int argc, char **argv )
{
  puts ("Hello World 1!");
  exit (0);
}
