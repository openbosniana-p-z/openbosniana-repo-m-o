#ifndef _HELLO2_H_
#define _HELLO2_H_

#ifdef __cplusplus
extern "C" {
#endif

extern const char *msg2;

#ifdef __cplusplus
};
#endif

#endif // _HELLO2_H_
