extern void putter (const char*);
void print_message (void);

void print_message (void)
{
	putter ("Plugin2 sucessfully activated");
}
