int fake3 (void);

int fake3 (void)
{
  return 3;
}

/* fake22 must not be exported */
int fake22 (void);

int fake22 (void)
{
  return 22;
}
