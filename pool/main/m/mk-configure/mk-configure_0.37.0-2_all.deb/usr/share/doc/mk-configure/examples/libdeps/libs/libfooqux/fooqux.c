#include "fooqux.h"

#include <stdio.h>

void fooqux (void)
{
	foo ();
	puts ("   and qux");
}
