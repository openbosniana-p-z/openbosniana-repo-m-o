#ifndef _SEVEN_H_
#define _SEVEN_H_

#ifdef __cplusplus
extern "C" {
#endif

int seven (void);

#ifdef __cplusplus
};
#endif

#endif // _SEVEN_H_
