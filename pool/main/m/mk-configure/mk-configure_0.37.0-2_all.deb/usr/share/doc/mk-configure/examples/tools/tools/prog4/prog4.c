#include <stdio.h>

#include "qux.h"

int main (int argc, char** argv)
{
	printf ("int_size=%d\n", get_int_size ());
	return 0;
}
