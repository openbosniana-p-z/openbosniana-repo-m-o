#include "bar.h"

const char *get_msg2 (void)
{
	return "Message #";
}
