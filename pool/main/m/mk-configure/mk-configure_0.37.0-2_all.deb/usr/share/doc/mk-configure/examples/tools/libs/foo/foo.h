const char *get_msg1 (void);
