#ifndef _BAR_H_
#define _BAR_H_

void bar (void);

#endif // _BAR_H_
