#include <stdio.h>

#include "hello1.h"
#include "hello2.h"

int main (int argc, char **argv)
{
	printf ("%s\n%s\n", msg1, msg2);
	return 0;
}
