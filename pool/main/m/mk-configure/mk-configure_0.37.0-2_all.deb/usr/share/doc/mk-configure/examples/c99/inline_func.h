#ifndef _INLINE_FUNC_H_
#define _INLINE_FUNC_H_

inline int sum(int a, int b)
{
	return a + b;
}

#endif // _INLINE_FUNC_H_
