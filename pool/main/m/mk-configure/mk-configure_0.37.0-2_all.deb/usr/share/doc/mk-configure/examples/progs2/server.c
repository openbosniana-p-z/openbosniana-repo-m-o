void puts_stdout (const char *);

int main (int argc, char **argv)
{
	puts_stdout ("I am a server");
	return 0;
}
