#include <iostream>

void hello_msg1 ()
{
	std::cout << MSG1;
}
