#ifndef _HELLO_MSG3_H_
#define _HELLO_MSG3_H_

#include <string>

std::string hello_msg3();

#endif // _HELLO_MSG3_H_
