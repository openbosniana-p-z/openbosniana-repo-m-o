#include <stdio.h>

void hello_message (void);

void hello_message (void)
{
	puts ("Plugin2 sucessfully activated");
}
