int fake2 (void);

int fake2 (void)
{
  return 2;
}
