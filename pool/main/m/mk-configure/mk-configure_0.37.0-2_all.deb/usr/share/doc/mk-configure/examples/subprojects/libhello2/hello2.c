#include "hello2.h"

const char *msg2 = "Hello v."HELLO_VERSION;
