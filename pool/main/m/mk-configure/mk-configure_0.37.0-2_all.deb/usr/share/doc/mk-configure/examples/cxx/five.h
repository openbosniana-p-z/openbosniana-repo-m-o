#ifndef _FIVE_H_
#define _FIVE_H_

#ifdef __cplusplus
extern "C" {
#endif

int five (void);

#ifdef __cplusplus
};
#endif

#endif // _FIVE_H_
