#ifndef _FOOQUX_H_
#define _FOOQUX_H_

#include "foo.h"

void fooqux (void);

#endif // _FOOQUX_H_
