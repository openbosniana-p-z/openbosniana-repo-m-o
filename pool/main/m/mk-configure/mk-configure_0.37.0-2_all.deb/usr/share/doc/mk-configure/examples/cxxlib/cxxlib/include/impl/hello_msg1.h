#ifndef _HELLO_MSG1_H_
#define _HELLO_MSG1_H_

void hello_msg1 ();

#endif // _HELLO_MSG1_H_
