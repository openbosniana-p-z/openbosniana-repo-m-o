# == THIS FILE IS GENERATED ==
# DO NOT EDIT OR ADD TO VERSION CONTROL
# The structure is defined in config.py.in
# The generation is done by the BuildConfig command in /build/mypaint-1eeBAR/mypaint-2.0.1/setup.py

# This file is part of MyPaint.
# -*- coding: utf-8 -*-
# Copyright (C) 2007-2013 by Martin Renold <martinxyz@gmx.ch>
# Copyright (C) 2013-2015 by the MyPaint Development Team.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version

mypaint_brushdir = u'/usr/share/mypaint-data/2.0/brushes'
libmypaint_version = u'libmypaint'
libmypaint_locale_dir = None
# List of locales for which translation files are available
supported_locales = [
    'af',
    'ar',
    'as',
    'ast',
    'az',
    'be',
    'bg',
    'bn',
    'br',
    'brx',
    'bs',
    'ca',
    'ca@valencia',
    'ckb',
    'cs',
    'csb',
    'da',
    'de',
    'dz',
    'el',
    'en_CA',
    'en_GB',
    'eo',
    'es',
    'et',
    'eu',
    'fa',
    'fi',
    'fr',
    'fy',
    'ga',
    'gl',
    'gu',
    'he',
    'hi',
    'hr',
    'hu',
    'hy',
    'id',
    'is',
    'it',
    'ja',
    'ka',
    'kab',
    'kk',
    'kn',
    'ko',
    'lt',
    'lv',
    'mai',
    'ml',
    'mn',
    'mr',
    'ms',
    'nb',
    'nl',
    'nn_NO',
    'oc',
    'pa',
    'pl',
    'pt',
    'pt_BR',
    'ro',
    'ru',
    'se',
    'sk',
    'sl',
    'sq',
    'sr',
    'sr@latin',
    'sv',
    'ta',
    'te',
    'tg',
    'th',
    'tr',
    'uk',
    'uz',
    'vi',
    'wa',
    'zh_CN',
    'zh_HK',
    'zh_TW',
]
