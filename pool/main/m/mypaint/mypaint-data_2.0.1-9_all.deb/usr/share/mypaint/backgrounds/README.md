Backgrounds are used by MyPaint to define how the canvas looks. They can be selected from the Layers->Background... menu.

You can create your own Background in this folder.

* Backgrounds work best with widths and heights in multiples of 64
* Backgrounds shouldn't have an alpha channel
* Backgrounds should be PNGs
* In order to add a new background, put the image you want in this directory and restart MyPaint
