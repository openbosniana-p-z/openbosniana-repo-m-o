 
================================================
MyPaint 0.9 (or later) BackgroundPackage release            
                                               
*****  "MrMamurk's backgrounds"  *****                
                                               
Created by: MrMamurk
                                               
storm.86@list.ru

These backgrounds can be used under those terms: 
http://creativecommons.org/publicdomain/zero/1.0/
                                               
================================================

A foreword...
-----------------
Hello everybody! I am glad to share with you some FREE background patterns which I've made for use within MyPaint's workflow. Everything has started as just my experiment with some free paper textures (which I've found in the web). But after a while the experiment has finished as a quite big package (this package) of background patterns, and each of them is based on my own scanning. Enjoy!

Install notes
-------------
Locate the ".mypaint" folder in your user folder and then open the background folder inside. Copy the PNG files there.
Instead of this, if you are using Windows, you can find the "backgrounds" folder in MyPaint's installation folder. For example "c:\Program Files\MyPaint\backgrounds". Copy the PNG-s from this archive there.
Now open MyPaint and go to menu Layers/background
Scroll down till you see some samples with a "+" sign, and then select one of them. Enjoy!

A plus!
-------
Presets are completely tileable.
TIFF files have been added to the archive as well, so if you want a different tone, you only have to open them inside GIMP and make any color, contrast, brightness corrections. Then save the modified pattern as a (FLATTENED!) PNG file.
[Editor's note: TIFF files have been removed for distribution inside MyPaint. You can download the original archive from the link below.]

You can also discuss these patterns in the forum thread:
http://forum.intilinux.com/mypaint-development-and-suggestions/better-background-patterns/
                                               

License 
-------
15/02/2011

MrMamurk has waived all copyright and related or neighboring rights to the images contained within this .zip file

These backgrounds can be used for any purpose without restriction, under those terms: 
http://creativecommons.org/publicdomain/zero/1.0/

================================================

