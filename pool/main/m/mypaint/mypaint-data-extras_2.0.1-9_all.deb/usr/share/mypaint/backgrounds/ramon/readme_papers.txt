 
================================================
MyPaint 0.9 (or later) PaperPackage release            
                                               
*****  "Artistic medium"  *****                
                                               
Created by: Ramon Miranda            
                                               
http://ramonmirandavisualart.blogspot.com 
mirandagraphic@gmail.com  
                                               
================================================

A briefs words...
-----------------
Hi there! It is a pleassure for me to introduce this new set released for this amazing software. I hope you enjoy it!
"Artistic medium" mimic the sufaces like paper,cork,canvas..

Install notes
-------------
Locate the .mypaint folder in your user folder and open the background folder inside and copy the files there.
Now open mypaint and go to menu Layers/background 
Scroll down till you see some squares with a "+" sign, and then select one of them. Enjoy!

A plus!
-------
They are completely tileable
so if you want a different tone, you only have to open the selected .png file  inside the gimp and do the color correction with levels tool or curves tool, you can colorize it too and change the size mantaining always the aspect ratio.

Also if you want to make your own papers, then go to http://registry.gimp.org/node/24636
This is a very interesting script to avoid the tipical artifacts of scanned images or photographies.

License 
-------
15/03/2010

Ramon Miranda has waived all copyright and related or neighboring rights to the images contained within this .zip file

those backgrounds can be used for any purpose without restriction, under those terms: http://creativecommons.org/publicdomain/zero/1.0/ ". 

Enjoy them, and if you want you can send me an e-mail, with your thoughts an impressions although it�s not a must. :D
                                               
================================================

