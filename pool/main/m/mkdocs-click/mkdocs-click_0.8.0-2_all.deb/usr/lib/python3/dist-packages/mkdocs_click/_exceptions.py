class MkDocsClickException(Exception):
    """
    Generic exception class for mkdocs-click errors.
    """
