os.execute("python scratch_pycraft.py")
