#
# Code under the MIT license by Alexander Pruss
#
# for backwards compatibility with earlier versions of
# Pruss's instructable
from mcturtle import *
