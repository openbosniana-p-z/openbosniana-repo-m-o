# Pycraft mod for Minetest
<img src="https://alessandronorfo.files.wordpress.com/2017/09/pycraft_minetest.png" alt="pycraft_minetest icon" height="360">

This is a fork of the https://github.com/arpruss/raspberryjammod-minetest created to support Pycraft in Minetest. Thanks to Arpruss for his amazing work :)

Alessandro Norfo (ale.norfo@gmail.com) & Giuseppe Menegoz (gmenegoz@gmail.com)

# Getting started
## WINDOWS
Download this installer: [pycraft_minetest.exe](https://github.com/sprintingkiwi/craft-with-python/releases/download/0.1/pycraft_minetest.exe)

## LINUX
* Install Minetest from your distribution's repository
* Install Lua (preferably 5.1)
* Install Luarocks for your version of Lua
* In a terminal execute this command as superuser: luarocks install luasocket
* Follow this tutorial on how to install a mod in Minetest: http://dev.minetest.net/Installing_Mods. We suggest to clone this repository inside the "mods" folder of Minetest.
* Create a world (it's better to enable creative mode)
* Click on "configure" and enable "pycraft_mod"
* Because pycraft need to do things that can be used maliciously, such as use UDP sockets and greater access to the system, you need to add "pycraft" to your trusted mods setting in minetest.conf, like so:
    secure.trusted_mods = pycraft
* Play the game

## MAC OSX
Work in progress...
