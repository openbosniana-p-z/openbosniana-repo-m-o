/* +---------------------------------------------------------------------------+
   |                     Mobile Robot Programming Toolkit (MRPT)               |
   |                          https://www.mrpt.org/                            |
   +---------------------------------------------------------------------------+
 */
#pragma once

const char MRPT_version_str[] = "MRPT 2.5.8";

/** Version number of package in hexadecimal:
 * A three digits version code, eg. 1.2.0 -> 0x120, 2.5.11 -> 0x25B */
// clang-format off
#define MRPT_VERSION 0x258
// clang-format on

// See specs: https://reproducible-builds.org/specs/source-date-epoch/
const char MRPT_SOURCE_DATE_EPOCH[] = "1673117237";

const char MRPT_CMAKE_SOURCE_DIR[] = "/build/mrpt-FRVDSJ/mrpt-2.5.8+ds";
const char MRPT_CMAKE_INSTALL_PREFIX[] = "/usr";
