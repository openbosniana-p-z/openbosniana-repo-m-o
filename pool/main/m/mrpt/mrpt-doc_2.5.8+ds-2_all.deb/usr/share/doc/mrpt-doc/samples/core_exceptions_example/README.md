Examples of use for MRPT exceptions macros.

Console output:

\include core_exceptions_example/console.out
