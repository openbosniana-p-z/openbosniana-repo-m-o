This example shows the use of the basic 2D path planning
algorithm implemented in the mrpt-nav class [PlannerSimple2D](class_mrpt_nav_PlannerSimple2D.html).

See also: [index of motion planning algorithms]()

