This example demonstrates how to install a custom OpenGL
shader replacing one of MRPT default ones.

In particular, the fragment shader is modified such that
depth (raw depth, in opengl internal logarithmic scale)
with respect to the eye is visualized as grayscale levels.

