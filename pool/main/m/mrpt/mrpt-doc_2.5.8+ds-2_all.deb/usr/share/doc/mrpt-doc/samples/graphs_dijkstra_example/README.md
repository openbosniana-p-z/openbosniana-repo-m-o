This example demonstrates how to use MRPT C++ implementation of the
Dijkstra algorithm for searching optimal paths in a directed, weighted graph.
See also the docs for the class mrpt::graphs::CDijkstra
