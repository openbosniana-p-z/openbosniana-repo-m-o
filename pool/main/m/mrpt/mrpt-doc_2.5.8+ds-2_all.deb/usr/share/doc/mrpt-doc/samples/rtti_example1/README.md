Example console output:

Part 1:
\include rtti_example1/console-ex1.out

Part 2:
\include rtti_example1/console-ex2.out
