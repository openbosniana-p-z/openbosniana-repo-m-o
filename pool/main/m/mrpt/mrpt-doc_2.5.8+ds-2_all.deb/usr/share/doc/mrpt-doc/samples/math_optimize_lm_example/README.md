See: \ref tutorial_math_levenberg_marquardt

Example implementation source code `LevMarqTest_impl.cpp`:
\include math_optimize_lm_example/LevMarqTest_impl.cpp
