This example demonstrates mrpt::gui::CDisplayWindowPlots capabilities to
show MATLAB/Octave-like plots directly from your C++ program.
