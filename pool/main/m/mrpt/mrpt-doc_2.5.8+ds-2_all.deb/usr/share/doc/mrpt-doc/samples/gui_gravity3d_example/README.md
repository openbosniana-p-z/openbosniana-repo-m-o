This example demonstrates 3D objects rendering with a super simple gravitational
simulator:

[Video](https://www.youtube.com/watch?v=jACGlPgWESw)

[![Video](https://img.youtube.com/vi/jACGlPgWESw/0.jpg)](https://www.youtube.com/watch?v=jACGlPgWESw)
