This examples demonstrates the function mrpt::vision::bundle_adj_full() with
a set of simulated monocular camera observations.
See the bundle adjustment module documentation on the C++ API.

\note This function requires setting `MRPT_ALLOW_LGPLV3=ON` in CMake when building MRPT.
