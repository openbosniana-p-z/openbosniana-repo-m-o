
Example output:

~~~~~~~~~~~~~
Retrieving http://www.google.es/...
Ok: 14160 bytes of type: text/html; charset=ISO-8859-1
~~~~~~~~~~~~~
