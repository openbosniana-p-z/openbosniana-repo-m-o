Console output (for a GNU/Linux build, without debug symbols):

```
[0 ] (unknown file) Foo::func1(int, int)
[1 ] (unknown file) main
[2 ] /build/glibc-S9d2JN/glibc-2.27/csu/../csu/libc-start.c:344 __libc_start_main
[3 ] (unknown file) _start
```
