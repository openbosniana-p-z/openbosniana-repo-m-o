See: \ref tutorial_3D_scenes
