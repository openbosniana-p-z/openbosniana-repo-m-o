Example console output:

```
[thread_reader ID:139741126407936] Started.
[thread_writer ID:139741118015232] Started.
RX: Hello world!
[thread_writer] Finished.
RX pose: (x,y,z,yaw,pitch,roll)=(1.0000,2.0000,3.0000,5.73deg,11.46deg,17.19deg)
[thread_reader] Finished.
```
