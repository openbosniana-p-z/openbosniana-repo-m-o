Demo for the A* generic solver:

Example console output:

```
Input an integer number to solve a problem, or "e" to end.
761
An optimal solution has been found:
	2 coins of 2 piastres.
	0 coins of 7 piastres.
	2 coins of 8 piastres.
	39 coins of 19 piastres.
```
