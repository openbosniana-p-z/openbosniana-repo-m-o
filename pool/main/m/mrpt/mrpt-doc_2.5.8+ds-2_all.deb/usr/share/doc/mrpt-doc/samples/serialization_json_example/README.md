Example console output:

\include serialization_json_example/console.out
