Examples of use for the YAML C++17 container in `mrpt::containers::yaml`.

Console output:

\include containers_yaml_example/console.out
