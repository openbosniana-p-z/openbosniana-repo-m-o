Example for the C++ function mrpt::math::intersect(const TPolygon2D& subject, const TPolygon2D& clipping) 
for polygon clipping or intersection using the [Sutherland-Hodgman algorithm](https://en.wikipedia.org/wiki/Sutherland%E2%80%93Hodgman_algorithm).

