This example illustrates how to implement an Extended Kalman Filter (EKF)
and a particle filter (PF) using mrpt::bayes classes, for the problem of
tracking a 2D mobile target with state space being its location and its
velocity vector.
