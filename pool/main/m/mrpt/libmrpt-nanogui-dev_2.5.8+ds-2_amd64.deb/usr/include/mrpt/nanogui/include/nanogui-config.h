// Automatically generated do not edit

#pragma once

#define NANOGUI_BUILD
#define NVG_BUILD
#define NANOGUI_SHARED
#ifndef NVG_SHARED
# define NVG_SHARED
#endif
