wgsim -N 10  -h -r 0 -R 0 -X 0 -1 70 -2 10 -d 0 -s 0 1seq_90bp.fa 1seq_90bp.reads.fq /dev/null
wgsim -N 200 -h -r 0 -R 0 -X 0 -1 70 -2 10 -d 0 -s 0 1seq_90bp_circ.fa 1seq_90bp_circ.reads.fq /dev/null

