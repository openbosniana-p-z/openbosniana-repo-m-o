file=buchnera
k=22

minia -in buchnera -abundance-min 2 -kmer-size $k

echo "To run tigops this project needs to be packaged: https://github.com/GATB/tigops"
echo "tigops fasta2fastg -tigs "$file".contigs.fa -out "$file".contigs.fastg -kmer-size $k -rename"

echo "Make sure you do  'apt install bandage'  to run this command"
echo "Bandage $file.contigs.fastg"

