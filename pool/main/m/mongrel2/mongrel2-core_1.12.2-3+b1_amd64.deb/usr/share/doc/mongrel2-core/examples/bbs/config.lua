sender_id = 'd1e9738e-a1e3-4c94-81b8-9d54360cccff'
sub_addr = 'tcp://127.0.0.1:9995'
pub_addr = 'tcp://127.0.0.1:9994'
io_threads = 1


