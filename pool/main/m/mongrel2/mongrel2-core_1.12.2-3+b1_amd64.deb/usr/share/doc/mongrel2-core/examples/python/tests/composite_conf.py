from mongrel2.config import *

include('mongrel2', 'tests/mongrel2_org.py')
include('localhost', 'tests/sample_conf.py')


