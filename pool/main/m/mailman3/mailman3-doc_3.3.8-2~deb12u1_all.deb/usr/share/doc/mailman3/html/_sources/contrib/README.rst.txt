=========================
 Community Contributions
=========================

This is a directory contain various contributions from the fantastic GNU
Mailman community.  We welcome and appreciate your contributions.

Please be aware that the files in this directory are not officially supported
by the core Mailman development team.  They are also covered by their own
license terms; consult those files for details.  We do however require GPL
compatible licenses for any contributed code appearing here.

If you have any questions about these files, please contact the author of that
file.  The core Mailman development team may not be able to answer your
questions, but we'll still try to review any issues or merge proposals related
to them.
