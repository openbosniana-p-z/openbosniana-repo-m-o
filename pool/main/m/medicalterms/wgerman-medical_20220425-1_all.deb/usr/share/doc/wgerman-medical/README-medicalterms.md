Bei dem Wörterbuch xxx-medicalterms handelt es sich um ein Addon.
Es enthält alle Wörter des Basiswörterbuchs sowie zusätzlich
medizinische Fachtermini. Diese Ergänzungen sind für Personen
sinnvoll, die häufig medizinische Texte lesen oder schreiben
müssen.

Dieses Wörterbuch basiert auf dem igerman98 Ispell-Wörterbuch,
zu finden unter <https://www.j3e.de/ispell/igerman98/>.

Das Wörterbuch und alle enthaltenen Wortlisten sind lizenziert
unter der GNU GPL, Version 3 oder später.

Fehlermeldungen und Ergänzungswünsche können unter folgender
Adresse eingereicht werden:
<https://github.com/toddy15/medicalterms/issues>

Autor des Grundwörterbuchs:
Bjoern Jacke <bjoern@j3e.de>

Autor der Erweiterung:
Dr. Tobias Quathamer <toddy@debian.org>
