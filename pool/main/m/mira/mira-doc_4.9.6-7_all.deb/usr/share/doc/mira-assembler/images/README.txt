note image:
Downloaded from http://www.deleket.com/softscraps.html as Button-Reminder-icon.png
Renamed and added 20 pixel to the right to get some distance between image and
text in HTML documents from xsltproc.

warning image:
Downloaded from http://www.deleket.com/softscraps.html as Button-Warning-icon.png
Renamed and added 20 pixel to the right to get some distance between image and
text in HTML documents from xsltproc.
