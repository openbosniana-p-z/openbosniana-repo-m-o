var searchData=
[
  ['high_449',['high',['../structmdds_1_1flat__segment__tree_1_1nonleaf__value__type.html#a9ccedde36b6976fdddebbddcfec68506',1,'mdds::flat_segment_tree::nonleaf_value_type::high()'],['../structmdds_1_1segment__tree_1_1nonleaf__value__type.html#a1308cbc31fcb96715c728870f5ac0471',1,'mdds::segment_tree::nonleaf_value_type::high()']]]
];
