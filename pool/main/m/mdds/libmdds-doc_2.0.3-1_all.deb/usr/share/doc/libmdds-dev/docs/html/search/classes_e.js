var searchData=
[
  ['ref_5fpair_323',['ref_pair',['../structmdds_1_1detail_1_1ref__pair.html',1,'mdds::detail']]],
  ['rtree_324',['rtree',['../classmdds_1_1rtree.html',1,'mdds']]]
];
