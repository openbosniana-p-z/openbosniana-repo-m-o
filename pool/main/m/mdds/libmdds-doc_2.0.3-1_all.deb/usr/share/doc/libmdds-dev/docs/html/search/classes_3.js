var searchData=
[
  ['data_5fnot_5ffound_253',['data_not_found',['../classmdds_1_1point__quad__tree_1_1data__not__found.html',1,'mdds::point_quad_tree']]],
  ['default_5felement_5fblock_254',['default_element_block',['../structmdds_1_1mtv_1_1default__element__block.html',1,'mdds::mtv']]],
  ['default_5frtree_5ftrait_255',['default_rtree_trait',['../structmdds_1_1detail_1_1rtree_1_1default__rtree__trait.html',1,'mdds::detail::rtree']]],
  ['default_5ftrait_256',['default_trait',['../structmdds_1_1mtv_1_1default__trait.html',1,'mdds::mtv']]],
  ['dispose_5fhandler_257',['dispose_handler',['../structmdds_1_1flat__segment__tree_1_1dispose__handler.html',1,'mdds::flat_segment_tree&lt; Key, Value &gt;::dispose_handler'],['../structmdds_1_1segment__tree_1_1dispose__handler.html',1,'mdds::segment_tree&lt; _Key, _Value &gt;::dispose_handler']]]
];
