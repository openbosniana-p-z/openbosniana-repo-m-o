var searchData=
[
  ['data_5fchain_442',['data_chain',['../structmdds_1_1segment__tree_1_1nonleaf__value__type.html#a2cd2af88e9b7ad2886763e38247d10f5',1,'mdds::segment_tree::nonleaf_value_type']]],
  ['dimensions_443',['dimensions',['../structmdds_1_1detail_1_1rtree_1_1default__rtree__trait.html#af1ffadc6aa9f05318998b092b1220902',1,'mdds::detail::rtree::default_rtree_trait']]]
];
