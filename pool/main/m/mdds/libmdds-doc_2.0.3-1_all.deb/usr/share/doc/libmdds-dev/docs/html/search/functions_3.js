var searchData=
[
  ['descend_5fto_5fprevius_5fleaf_5fnode_361',['descend_to_previus_leaf_node',['../classmdds_1_1trie_1_1detail_1_1iterator__base.html#af6bac6ef1ade799377ea3b6949fb0d00',1,'mdds::trie::detail::iterator_base']]],
  ['dump_5fstructure_362',['dump_structure',['../classmdds_1_1packed__trie__map.html#ad94cd2cf549f0f0d8b6a859b30bdf109',1,'mdds::packed_trie_map']]]
];
