var searchData=
[
  ['enable_5fforced_5freinsertion_444',['enable_forced_reinsertion',['../structmdds_1_1detail_1_1rtree_1_1default__rtree__trait.html#a790e9031293c2640a89a71b65294d823',1,'mdds::detail::rtree::default_rtree_trait']]],
  ['error_5fon_5fmin_5fnode_5fsize_445',['error_on_min_node_size',['../structmdds_1_1detail_1_1rtree_1_1integrity__check__properties.html#ad647cb69a381b7800b1ad5a2533915be',1,'mdds::detail::rtree::integrity_check_properties']]]
];
