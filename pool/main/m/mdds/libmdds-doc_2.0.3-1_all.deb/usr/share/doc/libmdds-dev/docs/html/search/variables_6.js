var searchData=
[
  ['max_5fnode_5fsize_454',['max_node_size',['../structmdds_1_1detail_1_1rtree_1_1default__rtree__trait.html#a9a541de8b8052516eee4db9e6cea7d5b',1,'mdds::detail::rtree::default_rtree_trait']]],
  ['max_5ftree_5fdepth_455',['max_tree_depth',['../structmdds_1_1detail_1_1rtree_1_1default__rtree__trait.html#a264625797b1a53284fe0a54b6a52013a',1,'mdds::detail::rtree::default_rtree_trait']]],
  ['min_5fnode_5fsize_456',['min_node_size',['../structmdds_1_1detail_1_1rtree_1_1default__rtree__trait.html#a712bc95a8d89b7e2bc02502f5efecdb9',1,'mdds::detail::rtree::default_rtree_trait']]]
];
