var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstvw~",
  1: "abcdefghilmnpqrstv",
  2: "abcdefgilmnopqrstw~",
  3: "defhilmnrt",
  4: "cekv",
  5: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Friends"
};

