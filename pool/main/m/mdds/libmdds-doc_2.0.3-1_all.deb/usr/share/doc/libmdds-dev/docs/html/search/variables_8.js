var searchData=
[
  ['refcount_458',['refcount',['../structmdds_1_1____st_1_1node.html#ab26e80641bff7eaa6087cfc8256b98f3',1,'mdds::__st::node']]],
  ['reinsertion_5fsize_459',['reinsertion_size',['../structmdds_1_1detail_1_1rtree_1_1default__rtree__trait.html#a2005df476c70aac2d4476e09d74461d5',1,'mdds::detail::rtree::default_rtree_trait']]],
  ['right_460',['right',['../structmdds_1_1____st_1_1nonleaf__node.html#a35bc81639bb2cbd5c6cbb43245056fa0',1,'mdds::__st::nonleaf_node']]]
];
