var searchData=
[
  ['leaf_5fvalue_5ftype_295',['leaf_value_type',['../structmdds_1_1flat__segment__tree_1_1leaf__value__type.html',1,'mdds::flat_segment_tree&lt; Key, Value &gt;::leaf_value_type'],['../structmdds_1_1segment__tree_1_1leaf__value__type.html',1,'mdds::segment_tree&lt; _Key, _Value &gt;::leaf_value_type']]]
];
