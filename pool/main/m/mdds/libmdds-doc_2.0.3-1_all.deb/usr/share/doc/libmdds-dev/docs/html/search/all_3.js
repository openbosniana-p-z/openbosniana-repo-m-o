var searchData=
[
  ['data_5fchain_35',['data_chain',['../structmdds_1_1segment__tree_1_1nonleaf__value__type.html#a2cd2af88e9b7ad2886763e38247d10f5',1,'mdds::segment_tree::nonleaf_value_type']]],
  ['data_5fnot_5ffound_36',['data_not_found',['../classmdds_1_1point__quad__tree_1_1data__not__found.html',1,'mdds::point_quad_tree']]],
  ['default_5felement_5fblock_37',['default_element_block',['../structmdds_1_1mtv_1_1default__element__block.html',1,'mdds::mtv']]],
  ['default_5frtree_5ftrait_38',['default_rtree_trait',['../structmdds_1_1detail_1_1rtree_1_1default__rtree__trait.html',1,'mdds::detail::rtree']]],
  ['default_5ftrait_39',['default_trait',['../structmdds_1_1mtv_1_1default__trait.html',1,'mdds::mtv']]],
  ['descend_5fto_5fprevius_5fleaf_5fnode_40',['descend_to_previus_leaf_node',['../classmdds_1_1trie_1_1detail_1_1iterator__base.html#af6bac6ef1ade799377ea3b6949fb0d00',1,'mdds::trie::detail::iterator_base']]],
  ['dimensions_41',['dimensions',['../structmdds_1_1detail_1_1rtree_1_1default__rtree__trait.html#af1ffadc6aa9f05318998b092b1220902',1,'mdds::detail::rtree::default_rtree_trait']]],
  ['dispose_5fhandler_42',['dispose_handler',['../structmdds_1_1flat__segment__tree_1_1dispose__handler.html',1,'mdds::flat_segment_tree&lt; Key, Value &gt;::dispose_handler'],['../structmdds_1_1segment__tree_1_1dispose__handler.html',1,'mdds::segment_tree&lt; _Key, _Value &gt;::dispose_handler']]],
  ['dump_5fstructure_43',['dump_structure',['../classmdds_1_1packed__trie__map.html#ad94cd2cf549f0f0d8b6a859b30bdf109',1,'mdds::packed_trie_map']]]
];
