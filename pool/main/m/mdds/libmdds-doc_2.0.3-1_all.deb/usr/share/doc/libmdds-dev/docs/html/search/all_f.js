var searchData=
[
  ['quad_5fnode_5fbase_167',['quad_node_base',['../structmdds_1_1quad__node__base.html',1,'mdds::quad_node_base&lt; _NodePtr, _NodeType, _Key &gt;'],['../structmdds_1_1quad__node__base.html#a106e1218b4e49b8b94ff6a8c52e5321f',1,'mdds::quad_node_base::quad_node_base()']]],
  ['quad_5fnode_5fbase_3c_20node_5fptr_2c_20node_2c_20key_5ftype_20_3e_168',['quad_node_base&lt; node_ptr, node, key_type &gt;',['../structmdds_1_1quad__node__base.html',1,'mdds']]]
];
