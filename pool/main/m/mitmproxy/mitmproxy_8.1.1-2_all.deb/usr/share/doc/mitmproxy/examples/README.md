# Mitmproxy Examples

Mitmproxy has a powerful scripting API that allows you to control almost any aspect of traffic being
proxied. In fact, much of mitmproxy’s own core functionality is implemented using the exact same API
 (see [mitmproxy/addons](../mitmproxy/addons)).

|  :warning: | If you are browsing this on GitHub, make sure to select the git tag matching your mitmproxy version. |
|------------|------------------------------------------------------------------------------------------------------|
