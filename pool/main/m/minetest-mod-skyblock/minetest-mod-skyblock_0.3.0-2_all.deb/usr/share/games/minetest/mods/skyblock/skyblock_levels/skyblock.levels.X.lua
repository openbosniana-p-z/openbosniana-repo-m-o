--[[

Skyblock for Minetest

Copyright (c) 2015 cornernote, Brett O'Donnell <cornernote@gmail.com>
Source Code: https://github.com/cornernote/minetest-skyblock
License: GPLv3

]]--


--[[

not a real level, just ideas and leftover code

feats:
* place_cactus
* place_papyrus
* dig_flower
* place_bookshelf
* collect_water
* place_water_infinite
* place_sand
* place_desert_sand
* place_stone
* place_cobble
* place_mossycobble
* place_steelblock
* dig_stone_with_copper
* dig_stone
* place_glass

rewards:
* default:lava_source
* default:desert_stone 50
* default:brick 50


	{
		name = 'craft a Small Bag',
		hint = 'unified_inventory:bag_small',
		feat = 'craft_bag',
		count = 1,
		reward = 'protector:protect',
		craft = {'unified_inventory:bag_small'},
	},

--]]
