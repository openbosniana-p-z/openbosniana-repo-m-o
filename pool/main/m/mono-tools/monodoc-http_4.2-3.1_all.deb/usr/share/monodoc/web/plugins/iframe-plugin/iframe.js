  $(document).ready(function () {
    $('iframe').iframeAutoHeight({debug: true});  
  });
