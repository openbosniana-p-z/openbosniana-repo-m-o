<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>helloqml</name>
    <message>
	<location filename="../helloqml.qml" line="8"/>
        <source>This demo plugin shows some basic tasks.</source>
        <translation>Dieses Demo-Plugin zeigt einige einfache Funktionen.</translation>
    </message>
    <message>
	<location filename="../helloqml.qml" line="13"/>
        <source>hello world</source>
        <translation>Hallo Welt</translation>
    </message>
    <message>
	<location filename="../helloqml.qml" line="23"/>
        <source>measure</source>
        <translation>Takt</translation>
    </message>
    <message>
	<location filename="../helloqml.qml" line="26"/>
        <source>  segment</source>
        <translation>  Segment</translation>
    </message>
    <message>
	<location filename="../helloqml.qml" line="29"/>
        <source> ---hello segment</source>
        <translation> ---hallo Segment</translation>
    </message>
    <message>
	<location filename="../helloqml.qml" line="36"/>
        <source>    element</source>
        <translation>    Element</translation>
    </message>
    <message>
	<location filename="../helloqml.qml" line="52"/>
        <source>Hello Qml</source>
        <translation>Hallo Qml</translation>
    </message>
</context>
</TS>
