"use strict";

var helpers = require("../../helpers/helpers");

exports["Africa/Niamey"] = {

	"guess:by:offset" : helpers.makeTestGuess("Africa/Niamey", { offset: true, expect: "Africa/Lagos" }),

	"guess:by:abbr" : helpers.makeTestGuess("Africa/Niamey", { abbr: true, expect: "Africa/Lagos" }),

	"1934" : helpers.makeTestYear("Africa/Niamey", [
		["1934-02-26T00:59:59+00:00", "23:59:59", "-01", 60],
		["1934-02-26T01:00:00+00:00", "01:00:00", "GMT", 0]
	])
};