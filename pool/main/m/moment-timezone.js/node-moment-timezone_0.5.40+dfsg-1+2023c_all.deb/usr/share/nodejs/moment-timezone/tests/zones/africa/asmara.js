"use strict";

var helpers = require("../../helpers/helpers");

exports["Africa/Asmara"] = {

	"guess:by:offset" : helpers.makeTestGuess("Africa/Asmara", { offset: true, expect: "Europe/Moscow" }),

	"guess:by:abbr" : helpers.makeTestGuess("Africa/Asmara", { abbr: true, expect: "Africa/Nairobi" }),

	"1889" : helpers.makeTestYear("Africa/Asmara", [
		["1889-12-31T21:24:27+00:00", "23:59:59", "AMT", -9332 / 60],
		["1889-12-31T21:24:28+00:00", "23:59:48", "ADMT", -9320 / 60]
	])
};