"use strict";

var helpers = require("../../helpers/helpers");

exports["Africa/Nouakchott"] = {

	"guess:by:offset" : helpers.makeTestGuess("Africa/Nouakchott", { offset: true, expect: "Africa/Abidjan" }),

	"guess:by:abbr" : helpers.makeTestGuess("Africa/Nouakchott", { abbr: true, expect: "Africa/Abidjan" }),

	"1934" : helpers.makeTestYear("Africa/Nouakchott", [
		["1934-02-25T23:59:59+00:00", "23:59:59", "GMT", 0],
		["1934-02-26T00:00:00+00:00", "23:00:00", "-01", 60]
	])
};