"use strict";

var helpers = require("../../helpers/helpers");

exports["Africa/Maseru"] = {

	"guess:by:offset" : helpers.makeTestGuess("Africa/Maseru", { offset: true, expect: "Africa/Johannesburg" }),

	"guess:by:abbr" : helpers.makeTestGuess("Africa/Maseru", { abbr: true, expect: "Africa/Johannesburg" }),

	"1943" : helpers.makeTestYear("Africa/Maseru", [
		["1943-09-18T23:59:59+00:00", "01:59:59", "SAST", -120],
		["1943-09-19T00:00:00+00:00", "03:00:00", "SAST", -180]
	])
};