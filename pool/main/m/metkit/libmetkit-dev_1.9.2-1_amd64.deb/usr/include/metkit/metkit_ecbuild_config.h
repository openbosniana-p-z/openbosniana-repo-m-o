/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef METKIT_ecbuild_config_h
#define METKIT_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.7.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.7.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/usr/share/ecbuild/cmake"
#endif

/* config info */

#define METKIT_OS_NAME          "Linux-5.10.0-17-amd64"
#define METKIT_OS_BITS          64
#define METKIT_OS_BITS_STR      "64"
#define METKIT_OS_STR           "linux.64"
#define METKIT_OS_VERSION       "5.10.0-17-amd64"
#define METKIT_SYS_PROCESSOR    "x86_64"

#define METKIT_BUILD_TIMESTAMP  "20220826113520"
#define METKIT_BUILD_TYPE       "Release"

#define METKIT_C_COMPILER_ID      "GNU"
#define METKIT_C_COMPILER_VERSION "12.2.0"

#define METKIT_CXX_COMPILER_ID      "GNU"
#define METKIT_CXX_COMPILER_VERSION "12.2.0"

#define METKIT_C_COMPILER       "/usr/bin/cc"
#define METKIT_C_FLAGS          "-g -O2 -ffile-prefix-map=/build/metkit-IrAFjD/metkit-1.9.2=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -O3 -DNDEBUG"

#define METKIT_CXX_COMPILER     "/usr/bin/c++"
#define METKIT_CXX_FLAGS        "-g -O2 -ffile-prefix-map=/build/metkit-IrAFjD/metkit-1.9.2=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable -Wno-sign-compare -O3 -DNDEBUG"

/* Needed for finding per package config files */

#define METKIT_INSTALL_DIR       "/usr"
#define METKIT_INSTALL_BIN_DIR   "/usr/bin"
#define METKIT_INSTALL_LIB_DIR   "/usr/lib/x86_64-linux-gnu"
#define METKIT_INSTALL_DATA_DIR  "/usr/share/metkit"

#define METKIT_DEVELOPER_SRC_DIR "/build/metkit-IrAFjD/metkit-1.9.2"
#define METKIT_DEVELOPER_BIN_DIR "/build/metkit-IrAFjD/metkit-1.9.2/obj-x86_64-linux-gnu"

/* Fortran support */

#if 0

#define METKIT_Fortran_COMPILER_ID      ""
#define METKIT_Fortran_COMPILER_VERSION ""

#define METKIT_Fortran_COMPILER "gfortran"
#define METKIT_Fortran_FLAGS    ""

#endif

#endif /* METKIT_ecbuild_config_h */
