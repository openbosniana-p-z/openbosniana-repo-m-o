#ifndef MMB_CONFIG_H
#define MMB_CONFIG_H

#define MMB_NTC_ENABLED

#endif // MMB_CONFIG_H
