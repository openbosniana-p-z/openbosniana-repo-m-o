var searchData=
[
  ['_5fmsgpack_5fsync_5fdecr_5fand_5ffetch_0',['_msgpack_sync_decr_and_fetch',['../gcc__atomic_8h.html#a40d6545cfc62376a1e431a6afb575d2c',1,'gcc_atomic.h']]],
  ['_5fmsgpack_5fsync_5fincr_5fand_5ffetch_1',['_msgpack_sync_incr_and_fetch',['../gcc__atomic_8h.html#a0f72ca27386296add35f925a9fd08442',1,'gcc_atomic.h']]]
];
