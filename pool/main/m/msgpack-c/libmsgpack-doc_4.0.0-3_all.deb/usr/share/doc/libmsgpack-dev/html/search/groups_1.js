var searchData=
[
  ['compressed_20buffer_0',['Compressed buffer',['../group__msgpack__zbuffer.html',1,'']]]
];
