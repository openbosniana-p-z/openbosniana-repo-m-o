var searchData=
[
  ['head_0',['head',['../structmsgpack__vrefbuffer__inner__buffer.html#aedc9beaca05e9148329ffee74bada7c3',1,'msgpack_vrefbuffer_inner_buffer::head()'],['../structmsgpack__zone__chunk__list.html#a2ae72ae61115b9ac3c03a1240424ad6d',1,'msgpack_zone_chunk_list::head()']]]
];
