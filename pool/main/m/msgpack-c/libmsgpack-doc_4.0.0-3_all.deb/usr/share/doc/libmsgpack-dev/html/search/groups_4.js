var searchData=
[
  ['memory_20zone_0',['Memory zone',['../group__msgpack__zone.html',1,'']]],
  ['messagepack_20c_1',['MessagePack C',['../group__msgpack.html',1,'']]]
];
