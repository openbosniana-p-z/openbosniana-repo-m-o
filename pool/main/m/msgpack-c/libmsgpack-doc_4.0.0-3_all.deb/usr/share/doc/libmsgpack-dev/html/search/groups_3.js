var searchData=
[
  ['file_2a_20buffer_0',['FILE* buffer',['../group__msgpack__fbuffer.html',1,'']]]
];
