var searchData=
[
  ['callback_0',['callback',['../structmsgpack__packer.html#a324b6abd5822173ea7448ccf33ddc2ea',1,'msgpack_packer']]],
  ['chunk_5flist_1',['chunk_list',['../structmsgpack__zone.html#a992bf7c60a378730342632e4e429235f',1,'msgpack_zone']]],
  ['chunk_5fsize_2',['chunk_size',['../structmsgpack__vrefbuffer.html#a58ed9de9b1940f0d196b7bf3514658a9',1,'msgpack_vrefbuffer::chunk_size()'],['../structmsgpack__zone.html#a2ecc632711b9c693f7b9b155df7182e0',1,'msgpack_zone::chunk_size()']]],
  ['compressed_20buffer_3',['Compressed buffer',['../group__msgpack__zbuffer.html',1,'']]],
  ['cs_4',['cs',['../unpack__template_8h.html#a62ed1336fc8e1441c0b7604555ef2a6b',1,'unpack_template.h']]],
  ['ctx_5',['ctx',['../structmsgpack__unpacker.html#aa91c786b01af0dfdd960c81f75445619',1,'msgpack_unpacker']]]
];
