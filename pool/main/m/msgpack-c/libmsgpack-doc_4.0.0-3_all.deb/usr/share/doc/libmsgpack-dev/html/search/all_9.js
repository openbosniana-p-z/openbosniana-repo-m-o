var searchData=
[
  ['i64_0',['i64',['../unionmsgpack__object__union.html#af10566562341bdebf12c3cfa46c0adf0',1,'msgpack_object_union']]],
  ['if_1',['if',['../unpack__template_8h.html#a9d6bcfaad03e5deefab30eb0c7f092cc',1,'unpack_template.h']]],
  ['init_5fsize_2',['init_size',['../structmsgpack__zbuffer.html#a86dfcd53585939b8abd219658de18b8b',1,'msgpack_zbuffer']]],
  ['initial_5fbuffer_5fsize_3',['initial_buffer_size',['../structmsgpack__unpacker.html#add4bcfd6f8b489c812f8b865c9d27b4b',1,'msgpack_unpacker']]],
  ['inner_5fbuffer_4',['inner_buffer',['../structmsgpack__vrefbuffer.html#ad591565dda8152a7510fdc6fcc062592',1,'msgpack_vrefbuffer']]],
  ['iov_5fbase_5',['iov_base',['../structmsgpack__iovec.html#a3f18eb0086f247b52059491762084882',1,'msgpack_iovec']]],
  ['iov_5flen_6',['iov_len',['../structmsgpack__iovec.html#a17466f280d50a811dc74ebff901babec',1,'msgpack_iovec']]]
];
