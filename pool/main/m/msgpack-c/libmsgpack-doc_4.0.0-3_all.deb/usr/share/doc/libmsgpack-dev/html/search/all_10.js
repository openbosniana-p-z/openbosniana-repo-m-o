var searchData=
[
  ['ref_5fsize_0',['ref_size',['../structmsgpack__vrefbuffer.html#ae652cb4a8b7892e76b266ff067ce3188',1,'msgpack_vrefbuffer']]],
  ['ret_1',['ret',['../unpack__template_8h.html#a339672ff94e6199019102f50d317c3d7',1,'unpack_template.h']]]
];
