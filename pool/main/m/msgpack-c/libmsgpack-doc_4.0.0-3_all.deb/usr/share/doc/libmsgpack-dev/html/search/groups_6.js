var searchData=
[
  ['vectored_20referencing_20buffer_0',['Vectored Referencing buffer',['../group__msgpack__vrefbuffer.html',1,'']]]
];
