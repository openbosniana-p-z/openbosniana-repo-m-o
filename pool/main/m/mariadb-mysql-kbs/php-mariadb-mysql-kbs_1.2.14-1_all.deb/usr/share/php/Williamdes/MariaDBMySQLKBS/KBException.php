<?php

declare(strict_types = 1);

namespace Williamdes\MariaDBMySQLKBS;

use Exception;

class KBException extends Exception
{
}
