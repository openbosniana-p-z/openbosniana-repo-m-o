# -*- coding: utf-8 -*-

require_relative 'model/image'
Plugin.create :skin do
end
