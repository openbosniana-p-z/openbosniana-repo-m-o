require_relative 'patch'
require_relative 'subparts_status_info'

Plugin.create :mastodon_gtk do
end
