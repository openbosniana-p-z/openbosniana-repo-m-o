# -*- coding: utf-8 -*-

require_relative 'entity/blank_entity'
require_relative 'entity/regexp_entity'
require_relative 'entity/segment'
require_relative 'entity/url_entity'
