# -*- coding: utf-8 -*-

require_relative 'mixin/message_mixin'
require_relative 'mixin/photo_interface'
require_relative 'mixin/photo_mixin'
require_relative 'mixin/user_mixin'

