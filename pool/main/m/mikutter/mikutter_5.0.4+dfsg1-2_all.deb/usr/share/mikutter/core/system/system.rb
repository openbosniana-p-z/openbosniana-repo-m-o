# -*- coding: utf-8 -*-

module Mikutter
  module System; end end

require 'system/user'
require 'system/message'
