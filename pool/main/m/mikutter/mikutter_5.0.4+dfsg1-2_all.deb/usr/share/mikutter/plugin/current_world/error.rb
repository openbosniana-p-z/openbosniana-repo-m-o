# -*- coding: utf-8 -*-

module Plugin::CurrentWorld
  Error = Class.new(RuntimeError)
  WorldNotfoundError = Class.new(Error)
end
