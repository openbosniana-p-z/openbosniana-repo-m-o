# -*- coding: utf-8 -*-

module Diva::Model::PhotoInterface
end
