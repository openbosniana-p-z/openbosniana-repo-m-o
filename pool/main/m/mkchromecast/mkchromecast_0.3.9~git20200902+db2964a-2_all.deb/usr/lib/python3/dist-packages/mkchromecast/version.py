# This file is part of mkchromecast.

__version__ = "0.3.9"
