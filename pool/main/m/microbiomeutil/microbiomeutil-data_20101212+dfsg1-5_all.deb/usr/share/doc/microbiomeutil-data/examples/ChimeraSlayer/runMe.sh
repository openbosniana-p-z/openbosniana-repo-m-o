#!/bin/sh

# remove any preexisting outputs from an earlier run.
rm -f chims.NAST.CPS*
rm -f tmp.*

/usr/lib/ChimeraSlayer/ChimeraSlayer.pl --query_NAST chims.NAST --printCSalignments --printFinalAlignments 


