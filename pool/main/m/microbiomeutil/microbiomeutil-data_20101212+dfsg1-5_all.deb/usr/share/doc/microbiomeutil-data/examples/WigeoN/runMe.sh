#!/bin/sh
/usr/lib/WigeoN/run_WigeoN.pl --query_NAST chims.NAST | tee chims.NAST.WigeoN


