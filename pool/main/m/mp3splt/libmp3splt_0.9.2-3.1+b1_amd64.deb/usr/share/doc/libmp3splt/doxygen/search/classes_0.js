var searchData=
[
  ['splt_5fplugin_5ffunc_0',['splt_plugin_func',['../structsplt__plugin__func.html',1,'']]],
  ['splt_5fplugin_5finfo_1',['splt_plugin_info',['../structsplt__plugin__info.html',1,'']]]
];
