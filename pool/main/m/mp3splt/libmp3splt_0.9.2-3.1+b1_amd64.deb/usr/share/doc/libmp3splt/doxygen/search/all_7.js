var searchData=
[
  ['registering_20callback_20functions_0',['Registering callback functions',['../group__splt__callback__.html',1,'']]]
];
