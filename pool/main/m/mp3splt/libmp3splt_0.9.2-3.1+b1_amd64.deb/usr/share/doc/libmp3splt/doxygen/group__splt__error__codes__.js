var group__splt__error__codes__ =
[
    [ "Initialisation of the main state", "group__splt__state__.html", "group__splt__state__" ],
    [ "Options", "group__splt__options__.html", "group__splt__options__" ],
    [ "splt_code", "group__splt__error__codes__.html#gaed8b624746e8485d41a8000e922e9de0", null ],
    [ "mp3splt_get_strerror", "group__splt__error__codes__.html#ga6d8cb03aeee17e519da4a45eba5b8b5a", null ]
];