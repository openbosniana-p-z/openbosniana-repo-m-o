var searchData=
[
  ['extension_0',['extension',['../group__splt__plugin__api.html#gaeb21c91758e5a462cbac08ba9448ab1c',1,'splt_plugin_info']]]
];
