var searchData=
[
  ['version_0',['version',['../group__splt__plugin__api.html#ga8cd4fa926a1762753b50a5af280819fe',1,'splt_plugin_info']]]
];
