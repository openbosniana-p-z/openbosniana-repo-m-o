var group__splt__filepaths__ =
[
    [ "Registering callback functions", "group__splt__callback__.html", "group__splt__callback__" ],
    [ "Splitpoints handling", "group__splt__splitpoints__.html", "group__splt__splitpoints__" ],
    [ "mp3splt_set_filename_to_split", "group__splt__filepaths__.html#gad207ebfce191e68778e86f48a49ce59f", null ],
    [ "mp3splt_set_path_of_split", "group__splt__filepaths__.html#ga1f100023123732efbc6bfb2e7dba21da", null ],
    [ "mp3splt_get_filename_to_split", "group__splt__filepaths__.html#gac36e6b6eaed132bd90f98eb43810592c", null ],
    [ "mp3splt_set_m3u_filename", "group__splt__filepaths__.html#ga9563bd63e76fcd7d0aba9353015feaf8", null ],
    [ "mp3splt_set_silence_log_filename", "group__splt__filepaths__.html#gac9587e12b7ed260d72f8004afc864e1f", null ],
    [ "mp3splt_set_silence_full_log_filename", "group__splt__filepaths__.html#ga614ce1758d2327bc57a53c07180557d0", null ]
];