var group__splt__tags__ =
[
    [ "Split functions", "group__splt__split__.html", "group__splt__split__" ],
    [ "SPLT_UNDEFINED_GENRE", "group__splt__tags__.html#ga2a6dec5262b5b3b5e888f4aa7faf5333", null ],
    [ "SPLT_ID3V1_NUMBER_OF_GENRES", "group__splt__tags__.html#ga3355d9b3231277bffda67bc2d8d2364e", null ],
    [ "splt_tags", "group__splt__tags__.html#ga28f1620a2a86127f60366ec4aa47836d", null ],
    [ "splt_tags_group", "group__splt__tags__.html#ga865404805506c94ca275c75fc409677a", null ],
    [ "splt_tag_key", "group__splt__tags__.html#ga61290003d05c8f5f840a4ccc176cebe9", [
      [ "SPLT_TAGS_ORIGINAL", "group__splt__tags__.html#gga61290003d05c8f5f840a4ccc176cebe9a82d42b1c8f1fd656a3ad2c2e3a62973b", null ]
    ] ],
    [ "mp3splt_tags_new", "group__splt__tags__.html#gac34d98ebee079935cf5a73c6157468c4", null ],
    [ "mp3splt_tags_set", "group__splt__tags__.html#ga905d2032de899f77f0cea38432473f84", null ],
    [ "mp3splt_append_tags", "group__splt__tags__.html#ga65a7682499c5735d876abd4b95722d15", null ],
    [ "mp3splt_get_tags_group", "group__splt__tags__.html#ga2be5bc78950f0b9d41311d4f7e8bde29", null ],
    [ "mp3splt_remove_tags_of_skippoints", "group__splt__tags__.html#ga9e4f8dbe59b80e2ecd96c4c558c20098", null ],
    [ "mp3splt_tags_group_init_iterator", "group__splt__tags__.html#gab7accd000e6a9348f11c8e20a441aad0", null ],
    [ "mp3splt_tags_group_next", "group__splt__tags__.html#ga066e068074d36dc19b1eb03dc3931f96", null ],
    [ "mp3splt_tags_get", "group__splt__tags__.html#gaf02bbf9341e6f4ca3853474b1b32b6ad", null ],
    [ "mp3splt_put_tags_from_string", "group__splt__tags__.html#ga0a860e77fb817d872e48afaecc096443", null ],
    [ "mp3splt_read_original_tags", "group__splt__tags__.html#gac8d45283c4c77b550aed3455fcac62b7", null ],
    [ "mp3splt_erase_all_tags", "group__splt__tags__.html#gad855adfdd068d2e577a75427754b5bfd", null ],
    [ "mp3splt_set_input_filename_regex", "group__splt__tags__.html#ga9804c20a13de20df0aa50cabc453ea6d", null ],
    [ "mp3splt_set_default_comment_tag", "group__splt__tags__.html#ga42a1fe80d9c008b465b76cee54f48254", null ],
    [ "mp3splt_set_default_genre_tag", "group__splt__tags__.html#ga4a79b0afe294aca6c9123dcc1974a070", null ],
    [ "mp3splt_parse_filename_regex", "group__splt__tags__.html#gaa41f714adcb71c39a2a30e7d9a76fb69", null ],
    [ "mp3splt_free_one_tag", "group__splt__tags__.html#gacea1c3f4fd6ee1c390f59741afff8a98", null ],
    [ "splt_id3v1_genres", "group__splt__tags__.html#ga4faf69e6334e36c1a77376e7d96b749d", null ]
];