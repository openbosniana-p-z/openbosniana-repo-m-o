var annotated_dup =
[
    [ "splt_plugin_func", "structsplt__plugin__func.html", "structsplt__plugin__func" ],
    [ "splt_plugin_info", "structsplt__plugin__info.html", "structsplt__plugin__info" ]
];