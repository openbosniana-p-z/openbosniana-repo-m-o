var structsplt__plugin__func =
[
    [ "splt_pl_init", "group__splt__plugin__api.html#ga573cc3733d2fc2f0f83f8f257b03c675", null ],
    [ "splt_pl_end", "group__splt__plugin__api.html#ga48af10fe2515e4c841d6c3ea0695b66c", null ],
    [ "splt_pl_check_plugin_is_for_file", "group__splt__plugin__api.html#gaea948a7d7b980432eafb60378f311390", null ],
    [ "splt_pl_set_plugin_info", "group__splt__plugin__api.html#gafb209592450bc2ae1291e43b5628f1f1", null ],
    [ "splt_pl_split", "group__splt__plugin__api.html#ga189e634c94beab7bb4e6598e6edfd547", null ],
    [ "splt_pl_set_original_tags", "group__splt__plugin__api.html#ga439f36360b7151787e11da53c4702291", null ],
    [ "splt_pl_clear_original_tags", "group__splt__plugin__api.html#gaf425600cbec57dc0307f6795abe9b96e", null ],
    [ "splt_pl_scan_silence", "group__splt__plugin__api.html#ga1a64e3f607e1e724b0c66762df1dd6fa", null ],
    [ "splt_pl_scan_trim_silence", "group__splt__plugin__api.html#ga3c12caa92bcefb125c6d642a48405d91", null ],
    [ "splt_pl_search_syncerrors", "group__splt__plugin__api.html#gaa9bbb25ee7e136f03a0a950a580f2a76", null ],
    [ "splt_pl_offset_split", "group__splt__plugin__api.html#ga7322f467cdf70fd8d91caa9cbecf2aa1", null ],
    [ "splt_pl_dewrap", "group__splt__plugin__api.html#gae5d568af017396cc168780f46b4af1bc", null ],
    [ "splt_pl_import_internal_sheets", "group__splt__plugin__api.html#ga0f51db107c5a6a4d6321377ca7ddf424", null ]
];