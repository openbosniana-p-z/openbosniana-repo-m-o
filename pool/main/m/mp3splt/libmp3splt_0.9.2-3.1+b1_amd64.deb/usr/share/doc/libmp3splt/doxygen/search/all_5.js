var searchData=
[
  ['name_0',['name',['../group__splt__plugin__api.html#gaebbd7f0496dc3ecf1c9c1e282d53e6f2',1,'splt_plugin_info']]]
];
