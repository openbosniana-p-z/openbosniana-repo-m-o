var searchData=
[
  ['options_0',['Options',['../group__splt__options__.html',1,'']]],
  ['other_20utilities_1',['Other utilities',['../group__splt__other__.html',1,'']]]
];
