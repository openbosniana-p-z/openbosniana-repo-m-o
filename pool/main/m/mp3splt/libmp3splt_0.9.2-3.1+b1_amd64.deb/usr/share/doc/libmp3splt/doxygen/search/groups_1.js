var searchData=
[
  ['export_20splitpoints_0',['Export splitpoints',['../group__splt__export__.html',1,'']]]
];
