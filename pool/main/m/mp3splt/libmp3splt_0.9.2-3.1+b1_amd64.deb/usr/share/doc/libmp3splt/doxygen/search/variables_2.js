var searchData=
[
  ['splt_5fid3v1_5fgenres_0',['splt_id3v1_genres',['../group__splt__tags__.html#ga4faf69e6334e36c1a77376e7d96b749d',1,'mp3splt.h']]],
  ['splt_5fpl_5fcheck_5fplugin_5fis_5ffor_5ffile_1',['splt_pl_check_plugin_is_for_file',['../group__splt__plugin__api.html#gaea948a7d7b980432eafb60378f311390',1,'splt_plugin_func']]],
  ['splt_5fpl_5fclear_5foriginal_5ftags_2',['splt_pl_clear_original_tags',['../group__splt__plugin__api.html#gaf425600cbec57dc0307f6795abe9b96e',1,'splt_plugin_func']]],
  ['splt_5fpl_5fdewrap_3',['splt_pl_dewrap',['../group__splt__plugin__api.html#gae5d568af017396cc168780f46b4af1bc',1,'splt_plugin_func']]],
  ['splt_5fpl_5fend_4',['splt_pl_end',['../group__splt__plugin__api.html#ga48af10fe2515e4c841d6c3ea0695b66c',1,'splt_plugin_func']]],
  ['splt_5fpl_5fimport_5finternal_5fsheets_5',['splt_pl_import_internal_sheets',['../group__splt__plugin__api.html#ga0f51db107c5a6a4d6321377ca7ddf424',1,'splt_plugin_func']]],
  ['splt_5fpl_5finit_6',['splt_pl_init',['../group__splt__plugin__api.html#ga573cc3733d2fc2f0f83f8f257b03c675',1,'splt_plugin_func']]],
  ['splt_5fpl_5foffset_5fsplit_7',['splt_pl_offset_split',['../group__splt__plugin__api.html#ga7322f467cdf70fd8d91caa9cbecf2aa1',1,'splt_plugin_func']]],
  ['splt_5fpl_5fscan_5fsilence_8',['splt_pl_scan_silence',['../group__splt__plugin__api.html#ga1a64e3f607e1e724b0c66762df1dd6fa',1,'splt_plugin_func']]],
  ['splt_5fpl_5fscan_5ftrim_5fsilence_9',['splt_pl_scan_trim_silence',['../group__splt__plugin__api.html#ga3c12caa92bcefb125c6d642a48405d91',1,'splt_plugin_func']]],
  ['splt_5fpl_5fsearch_5fsyncerrors_10',['splt_pl_search_syncerrors',['../group__splt__plugin__api.html#gaa9bbb25ee7e136f03a0a950a580f2a76',1,'splt_plugin_func']]],
  ['splt_5fpl_5fset_5foriginal_5ftags_11',['splt_pl_set_original_tags',['../group__splt__plugin__api.html#ga439f36360b7151787e11da53c4702291',1,'splt_plugin_func']]],
  ['splt_5fpl_5fset_5fplugin_5finfo_12',['splt_pl_set_plugin_info',['../group__splt__plugin__api.html#gafb209592450bc2ae1291e43b5628f1f1',1,'splt_plugin_func']]],
  ['splt_5fpl_5fsplit_13',['splt_pl_split',['../group__splt__plugin__api.html#ga189e634c94beab7bb4e6598e6edfd547',1,'splt_plugin_func']]]
];
