var group__splt__other__ =
[
    [ "Creating libmp3splt plugins", "group__splt__plugin__api.html", "group__splt__plugin__api" ],
    [ "SPLT_DIRCHAR", "group__splt__other__.html#ga1e18f9909e642e187820db5cc7ba750e", null ],
    [ "SPLT_DIRSTR", "group__splt__other__.html#ga751674a7c0398f6c015ba906c7654fc1", null ],
    [ "mp3splt_set_silence_points", "group__splt__other__.html#ga5689a2bc5dddc7f544d64b6f72553b4b", null ],
    [ "mp3splt_set_trim_silence_points", "group__splt__other__.html#gaccee263a8de1cc27527091c1b0ec0d9c", null ],
    [ "mp3splt_get_version", "group__splt__other__.html#ga1ea20f248aff7c789ad4dfe0a40a1bff", null ],
    [ "mp3splt_check_if_directory", "group__splt__other__.html#ga21ca2385a4938c6af5353b2426cf5fa8", null ]
];