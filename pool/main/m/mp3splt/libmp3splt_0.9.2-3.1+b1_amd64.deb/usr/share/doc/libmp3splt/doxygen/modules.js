var modules =
[
    [ "Using libmp3splt", "group__using__libmp3splt.html", "group__using__libmp3splt" ],
    [ "Versions", "group__libmp3splt__version.html", null ]
];