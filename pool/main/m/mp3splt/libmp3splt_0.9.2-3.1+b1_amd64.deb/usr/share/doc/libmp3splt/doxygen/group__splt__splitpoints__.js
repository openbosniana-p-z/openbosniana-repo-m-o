var group__splt__splitpoints__ =
[
    [ "Tags handling", "group__splt__tags__.html", "group__splt__tags__" ],
    [ "splt_point", "group__splt__splitpoints__.html#ga15775e21d69c01e5a3a0f2489b5457a1", null ],
    [ "splt_points", "group__splt__splitpoints__.html#ga96483917e91438b77a02efc48ad14989", null ],
    [ "splt_type_of_splitpoint", "group__splt__splitpoints__.html#ga45ddaf29cf5f5d1ae23068ca7f906ec2", [
      [ "SPLT_SPLITPOINT", "group__splt__splitpoints__.html#gga45ddaf29cf5f5d1ae23068ca7f906ec2aca0aef3747d706c0940337a591171b9d", null ],
      [ "SPLT_SKIPPOINT", "group__splt__splitpoints__.html#gga45ddaf29cf5f5d1ae23068ca7f906ec2a570e0e3638f625fccd347a72341d34ea", null ]
    ] ],
    [ "mp3splt_point_new", "group__splt__splitpoints__.html#ga8691ecb2b66d4a15f4b2e77e01a21719", null ],
    [ "mp3splt_point_set_name", "group__splt__splitpoints__.html#gad3efe45faef54941a22a17d5067dec72", null ],
    [ "mp3splt_point_set_type", "group__splt__splitpoints__.html#gac99335237591ccdff5d5aba4bc2ee0b2", null ],
    [ "mp3splt_append_splitpoint", "group__splt__splitpoints__.html#gadcd6b14b4ab7be2a2a5cb2abbe996f2a", null ],
    [ "mp3splt_get_splitpoints", "group__splt__splitpoints__.html#ga1216c7d01e7631d6cb425f2125aad147", null ],
    [ "mp3splt_points_init_iterator", "group__splt__splitpoints__.html#gad7c343db0a04c37061f064a49877c896", null ],
    [ "mp3splt_points_next", "group__splt__splitpoints__.html#ga5f9ea41db1e0a111f3eb7574ce5b303a", null ],
    [ "mp3splt_point_get_value", "group__splt__splitpoints__.html#ga18501ba44c5a50a78641f9db2be126d2", null ],
    [ "mp3splt_point_get_type", "group__splt__splitpoints__.html#ga3da9f4ab322a2d567c6e2beb7d844184", null ],
    [ "mp3splt_point_get_name", "group__splt__splitpoints__.html#ga6d6131c662953c57d706b3f177f81e9c", null ],
    [ "mp3splt_erase_all_splitpoints", "group__splt__splitpoints__.html#ga4f6d4c6f5dd5608de12bef7f20498c38", null ]
];