var searchData=
[
  ['upper_5fextension_0',['upper_extension',['../group__splt__plugin__api.html#ga4838f65d3a4bf8730898556829c094b2',1,'splt_plugin_info']]]
];
