var searchData=
[
  ['confirmation_20and_20error_20codes_0',['Confirmation and error codes',['../group__splt__error__codes__.html',1,'']]],
  ['creating_20libmp3splt_20plugins_1',['Creating libmp3splt plugins',['../group__splt__plugin__api.html',1,'']]]
];
