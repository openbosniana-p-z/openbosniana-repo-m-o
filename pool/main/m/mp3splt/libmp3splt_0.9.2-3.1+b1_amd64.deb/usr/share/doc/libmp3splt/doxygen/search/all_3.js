var searchData=
[
  ['import_20splitpoints_0',['Import splitpoints',['../group__splt__import__.html',1,'']]],
  ['initialisation_20of_20the_20main_20state_1',['Initialisation of the main state',['../group__splt__state__.html',1,'']]],
  ['input_20filename_20and_20paths_2',['Input filename and paths',['../group__splt__filepaths__.html',1,'']]]
];
