var structsplt__plugin__info =
[
    [ "version", "group__splt__plugin__api.html#ga8cd4fa926a1762753b50a5af280819fe", null ],
    [ "name", "group__splt__plugin__api.html#gaebbd7f0496dc3ecf1c9c1e282d53e6f2", null ],
    [ "extension", "group__splt__plugin__api.html#gaeb21c91758e5a462cbac08ba9448ab1c", null ],
    [ "upper_extension", "group__splt__plugin__api.html#ga4838f65d3a4bf8730898556829c094b2", null ]
];