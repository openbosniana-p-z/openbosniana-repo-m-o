var globals_dup =
[
    [ "m", "globals.html", null ],
    [ "s", "globals_s.html", null ]
];