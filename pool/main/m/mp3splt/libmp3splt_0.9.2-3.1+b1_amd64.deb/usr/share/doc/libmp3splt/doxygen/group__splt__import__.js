var group__splt__import__ =
[
    [ "Export splitpoints", "group__splt__export__.html", "group__splt__export__" ],
    [ "SPLT_FREEDB_SEARCH_TYPE_CDDB_CGI", "group__splt__import__.html#ga0728cbbad49aacd755faba2dc0dc4bf7", null ],
    [ "SPLT_FREEDB_GET_FILE_TYPE_CDDB_CGI", "group__splt__import__.html#ga63b0276c95a38ff131d17c472c189785", null ],
    [ "SPLT_FREEDB_GET_FILE_TYPE_CDDB", "group__splt__import__.html#gaef531981f7c79f6ad0d238d1ccf05fa8", null ],
    [ "SPLT_FREEDB_CDDB_CGI_PORT", "group__splt__import__.html#ga2d03dfadc645566ae3dbae916d7d1962", null ],
    [ "SPLT_FREEDB2_CGI_SITE", "group__splt__import__.html#gadb462f680d48e6f0925ec02d25153eb1", null ],
    [ "splt_freedb_results", "group__splt__import__.html#gac2e2689303c3cf96ad35ff3961e1c48e", null ],
    [ "splt_freedb_one_result", "group__splt__import__.html#ga9b1e3f53f54c907c777d62f6212a725e", null ],
    [ "splt_import_type", "group__splt__import__.html#ga7492ffeec6258b8159f5c2e11d88d96f", null ],
    [ "mp3splt_import", "group__splt__import__.html#ga4bde5cba02554f4c678a8d0f9dfccfc5", null ],
    [ "mp3splt_use_proxy", "group__splt__import__.html#ga008d8604119ccc7b43ae2ac3fdf1f217", null ],
    [ "mp3splt_use_base64_authentification", "group__splt__import__.html#gaf5fc415c514ca6aadc265d90a7e5149c", null ],
    [ "mp3splt_encode_in_base64", "group__splt__import__.html#ga098fa19d19d1b0e19bdfd47f5139b504", null ],
    [ "mp3splt_clear_proxy", "group__splt__import__.html#ga1485166aa57e635fb35294442037ab2d", null ],
    [ "mp3splt_get_freedb_search", "group__splt__import__.html#ga816f4930ded21e342476717fa012f9e4", null ],
    [ "mp3splt_freedb_init_iterator", "group__splt__import__.html#ga4e88c756b044dae2af96f4f26e7f643b", null ],
    [ "mp3splt_freedb_next", "group__splt__import__.html#ga5d35b96d2d33c9f1c26bd71bb2fadcd3", null ],
    [ "mp3splt_freedb_get_id", "group__splt__import__.html#ga405ccb57ccc15b837163f5c5d3f19cea", null ],
    [ "mp3splt_freedb_get_name", "group__splt__import__.html#gaa26df39e9220edfdb66da2d6f485f934", null ],
    [ "mp3splt_freedb_get_number_of_revisions", "group__splt__import__.html#ga1337c31920867778aa6d0455d1b9d41b", null ],
    [ "mp3splt_write_freedb_file_result", "group__splt__import__.html#ga3657141277887618ca0e032aeb34357d", null ]
];