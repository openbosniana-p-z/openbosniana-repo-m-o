var dir_f1bd7e83765e23cd342f57628576642f =
[
    [ "mp3splt.h", "mp3splt_8h.html", "mp3splt_8h" ],
    [ "version.h", "version_8h_source.html", null ]
];