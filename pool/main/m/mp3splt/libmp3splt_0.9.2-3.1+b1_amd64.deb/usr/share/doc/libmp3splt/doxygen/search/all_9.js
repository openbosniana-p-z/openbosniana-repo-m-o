var searchData=
[
  ['tags_20handling_0',['Tags handling',['../group__splt__tags__.html',1,'']]]
];
