__all__ = [
    'java_defaults',
]

import sys

def java_defaults(**args):
    print("Warning: java_defaults not yet implemented", file=sys.stderr)
    pass
