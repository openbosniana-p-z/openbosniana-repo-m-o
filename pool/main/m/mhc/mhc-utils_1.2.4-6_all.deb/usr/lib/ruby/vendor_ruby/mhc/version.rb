module Mhc
  VERSION = "1.2.4"
  PRODID = "-//Quickhack.net//MHC #{Mhc::VERSION}//EN"
end
