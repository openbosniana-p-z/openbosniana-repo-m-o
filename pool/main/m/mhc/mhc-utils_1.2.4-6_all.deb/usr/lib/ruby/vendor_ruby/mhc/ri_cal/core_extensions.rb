#- ©2009 Rick DeNatale
#- All rights reserved. Refer to the file README.txt for the license
#

require "ri_cal/core_extensions/array.rb"
require "ri_cal/core_extensions/date.rb"
require "ri_cal/core_extensions/date_time.rb"
require "ri_cal/core_extensions/object.rb"
require "ri_cal/core_extensions/string.rb"
require "ri_cal/core_extensions/time.rb"

