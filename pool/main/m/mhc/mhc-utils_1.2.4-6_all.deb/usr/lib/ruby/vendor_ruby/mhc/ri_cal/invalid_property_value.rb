module RiCal
  #- ©2009 Rick DeNatale
  #- All rights reserved. Refer to the file README.txt for the license
  #
  # An InvalidPropertyValue error is raised when an improper value is assigned to a property
  class InvalidPropertyValue < StandardError
  end
end
