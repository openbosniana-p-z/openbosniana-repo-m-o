#ifndef magics_config_h
#define magics_config_h

/*#include "eckit_config.h"*/

/* Define to 1 if you have the <dlfcn.h> header file. */
#define magics_HAVE_DLFCN_H

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H

/* Define to 1 if you have the `expat' library (-lexpat). */
#define HAVE_LIBEXPAT

/* Define to 1 if you have the `gd' library (-lgd). */
/* #undef HAVE_LIBGD */

/* Define to 1 if you have the `proj' library (-lproj). */
#define HAVE_LIBPROJ

/* Define to 1 if you have the `pthread' library (-lpthread). */
#define HAVE_LIBPTHREAD

/* Define to 1 if you have the `spot_database' library (-lspot_database). */
/* #undef HAVE_LIBSPOT_DATABASE */

/* Define to 1 if you have the `z' library (-lz). */
#define HAVE_LIBZ

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H

/* If available, contains the Python version number currently in use. */
/* #undef HAVE_PYTHON */

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
/* #undef LT_OBJDIR */

/* Install all header files. */
#define MAGICS_ALLHEADERS

/* Turn off the BUFR support */
#define HAVE_BUFR

/* Turn on the Cairo output support */
#define HAVE_CAIRO

/* Period of Copyright. */
/* #undef MAGICS_COPYRIGHT_PERIOD */

/* Turn on the GeoTIFF output support */
#ifndef HAVE_GEOTIFF
#define HAVE_GEOTIFF
#endif

/* Defines GIF output is supported. */
#define MAGICS_GIF

/* Defines animated GIF output is supported. */
#define MAGICS_GIF_ANIMATED

/* Install path. */
#define MAGICS_INSTALL_PATH "/usr"

/* Turn on the JSON support */
#define MAGICS_JSON

/* LIB_AGE of Magics. */
/* #undef MAGICS_LIBRARY_AGE */

/* LIB_CURRENT of Magics. */
/* #undef MAGICS_LIBRARY_CURRENT */

/* LIB_REVISION of Magics. */
/* #undef MAGICS_LIBRARY_REVISION */

/* Indicate if Mac is used. */
/* #undef MAGICS_MAC */

/* Turn on metgram script support */
/* #undef MAGICS_METGRAM */

/* Installation used by metview */
#define HAVE_METVIEW

/* Name of this package. */
#define MAGICS_NAME "Magics"

/* Turn off the netCDF support */
#define HAVE_NETCDF

/* Turn off the ODB support */
#define HAVE_ODB

/* Gives the list of output formats */
/* #undef MAGICS_OUTPUTS */

/* Enable Python interface (based on SWIG). */
/* #undef HAVE_PYTHON */

/* Turn on Qt related modules. */
#define MAGICS_QT

/* Turn on raster file format support (GIF&PNG) */
/* #undef MAGICS_RASTER */

/* Release date of this version. */
/* #undef MAGICS_RELEASE_DATE */

/* Name of installation site. */
#define MAGICS_SITE "debian"

/* Turn off the SPOT support */
/* #undef HAVE_SPOT */

/* Turn on/off thread support. */
#define MAGICS_THREADS

/* Turn on TIFF file format support */
#define MAGICS_TIFF

/* Version of Magics. */
#define MAGICS_VERSION "4.13.0"

/* Full Version Name of Magics. */
#define MAGICS_VERSION_STR "4.13.0"

/* Sets visibility flags. */
/* #undef MAGICS_VISIBILITY */

/* Define to the address where bug reports for this package should be sent. */
/* #undef PACKAGE_BUGREPORT */

/* Define to the full name of this package. */
/* #undef PACKAGE_NAME */

/* Define to the full name and version of this package. */
/* #undef PACKAGE_STRING */

/* Define to the one symbol short name of this package. */
/* #undef PACKAGE_TARNAME */

/* Define to the home page for this package. */
/* #undef PACKAGE_URL */

/* Define to the version of this package. */
/* #undef PACKAGE_VERSION */

/* Paths to PS fonts. */
/* #undef POSTSCRIPT_FONT_PATH */

#endif
