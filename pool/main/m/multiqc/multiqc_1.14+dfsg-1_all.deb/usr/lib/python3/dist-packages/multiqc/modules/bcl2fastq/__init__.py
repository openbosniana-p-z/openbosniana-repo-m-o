from .bcl2fastq import MultiqcModule
