from .rseqc import MultiqcModule
