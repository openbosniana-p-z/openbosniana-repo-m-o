from .qualimap import MultiqcModule
