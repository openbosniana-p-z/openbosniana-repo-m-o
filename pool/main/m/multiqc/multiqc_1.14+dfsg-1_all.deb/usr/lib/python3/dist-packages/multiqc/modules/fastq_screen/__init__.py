from .fastq_screen import MultiqcModule
