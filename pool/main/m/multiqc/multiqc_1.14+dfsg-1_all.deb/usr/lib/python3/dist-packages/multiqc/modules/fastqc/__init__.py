from .fastqc import MultiqcModule
