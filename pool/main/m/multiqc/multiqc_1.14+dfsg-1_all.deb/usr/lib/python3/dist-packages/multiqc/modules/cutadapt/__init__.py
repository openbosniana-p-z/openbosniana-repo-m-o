from .cutadapt import MultiqcModule
