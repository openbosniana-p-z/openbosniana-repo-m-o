from .bclconvert import MultiqcModule
