from .kaiju import MultiqcModule
