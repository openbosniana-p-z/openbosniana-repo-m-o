from .somalier import MultiqcModule
