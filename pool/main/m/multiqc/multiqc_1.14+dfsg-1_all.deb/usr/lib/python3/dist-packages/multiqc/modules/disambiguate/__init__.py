from .disambiguate import MultiqcModule
