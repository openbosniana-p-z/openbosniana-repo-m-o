from .kallisto import MultiqcModule
