from .mosdepth import MultiqcModule
