from .snpeff import MultiqcModule
