from .ngsderive import MultiqcModule
