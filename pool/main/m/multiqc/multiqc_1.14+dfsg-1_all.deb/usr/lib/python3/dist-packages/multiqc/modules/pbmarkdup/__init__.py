from .pbmarkdup import MultiqcModule
