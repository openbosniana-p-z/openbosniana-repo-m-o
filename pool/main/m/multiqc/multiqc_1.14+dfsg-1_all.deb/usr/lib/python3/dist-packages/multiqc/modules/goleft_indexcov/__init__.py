from .goleft_indexcov import MultiqcModule
