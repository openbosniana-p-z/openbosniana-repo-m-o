from .feature_counts import MultiqcModule
