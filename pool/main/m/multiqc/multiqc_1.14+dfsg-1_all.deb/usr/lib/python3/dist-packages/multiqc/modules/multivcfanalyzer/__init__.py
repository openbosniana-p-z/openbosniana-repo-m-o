from .multivcfanalyzer import MultiqcModule
