from .flexbar import MultiqcModule
