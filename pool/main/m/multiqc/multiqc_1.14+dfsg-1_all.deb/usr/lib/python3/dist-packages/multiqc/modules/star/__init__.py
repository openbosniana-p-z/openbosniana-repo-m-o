from .star import MultiqcModule
