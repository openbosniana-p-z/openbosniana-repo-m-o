from .snpsplit import MultiqcModule
