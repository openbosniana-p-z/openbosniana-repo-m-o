from .bowtie1 import MultiqcModule
