from .seqyclean import MultiqcModule
