from .gffcompare import MultiqcModule
