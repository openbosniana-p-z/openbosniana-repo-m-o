from .slamdunk import MultiqcModule
