from .sambamba import MultiqcModule
