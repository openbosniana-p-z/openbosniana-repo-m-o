from .peddy import MultiqcModule
