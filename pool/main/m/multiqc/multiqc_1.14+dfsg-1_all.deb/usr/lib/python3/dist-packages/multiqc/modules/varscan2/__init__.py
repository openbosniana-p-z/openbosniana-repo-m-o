from .varscan2 import MultiqcModule
