from .rockhopper import MultiqcModule
