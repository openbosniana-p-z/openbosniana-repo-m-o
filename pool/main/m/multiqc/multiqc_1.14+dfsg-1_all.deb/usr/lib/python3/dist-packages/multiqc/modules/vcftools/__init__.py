from .vcftools import MultiqcModule
