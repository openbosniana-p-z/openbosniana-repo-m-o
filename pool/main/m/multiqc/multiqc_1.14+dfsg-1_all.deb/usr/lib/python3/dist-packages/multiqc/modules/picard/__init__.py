from .picard import MultiqcModule
