from .jellyfish import MultiqcModule
