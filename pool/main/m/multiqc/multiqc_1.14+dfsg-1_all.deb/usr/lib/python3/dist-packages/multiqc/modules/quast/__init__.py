from .quast import MultiqcModule
