from .samtools import MultiqcModule
