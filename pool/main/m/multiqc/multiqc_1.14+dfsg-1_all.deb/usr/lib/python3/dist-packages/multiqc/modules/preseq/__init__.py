from .preseq import MultiqcModule
