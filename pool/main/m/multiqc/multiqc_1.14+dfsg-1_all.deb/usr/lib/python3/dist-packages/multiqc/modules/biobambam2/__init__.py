from .biobambam2 import MultiqcModule
