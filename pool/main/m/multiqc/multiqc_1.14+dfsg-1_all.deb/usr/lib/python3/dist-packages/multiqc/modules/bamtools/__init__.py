from .bamtools import MultiqcModule
