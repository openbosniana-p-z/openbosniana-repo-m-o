from .samblaster import MultiqcModule
