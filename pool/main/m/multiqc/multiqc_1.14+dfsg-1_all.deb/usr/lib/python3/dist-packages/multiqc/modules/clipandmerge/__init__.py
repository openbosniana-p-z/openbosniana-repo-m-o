from .clipandmerge import MultiqcModule
