from .bismark import MultiqcModule
