from .fastp import MultiqcModule
