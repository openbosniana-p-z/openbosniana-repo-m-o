from .qc3C import MultiqcModule
