from .jcvi import MultiqcModule
