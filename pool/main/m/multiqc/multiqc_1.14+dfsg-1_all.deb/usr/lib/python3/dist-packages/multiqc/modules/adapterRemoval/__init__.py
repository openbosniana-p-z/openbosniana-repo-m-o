from .adapterRemoval import MultiqcModule
