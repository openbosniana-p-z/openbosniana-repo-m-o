from .lima import MultiqcModule
