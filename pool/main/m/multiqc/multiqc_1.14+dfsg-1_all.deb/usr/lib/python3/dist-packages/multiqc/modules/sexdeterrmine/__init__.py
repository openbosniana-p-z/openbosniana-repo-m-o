from .sexdeterrmine import MultiqcModule
