from .nanostat import MultiqcModule
