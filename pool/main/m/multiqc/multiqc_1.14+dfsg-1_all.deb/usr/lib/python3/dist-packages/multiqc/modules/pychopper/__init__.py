from .pychopper import MultiqcModule
