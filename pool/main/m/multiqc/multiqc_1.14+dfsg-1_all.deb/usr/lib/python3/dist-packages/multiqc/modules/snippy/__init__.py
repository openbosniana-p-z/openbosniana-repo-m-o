from .snippy import MultiqcModule
