from .happy import MultiqcModule
