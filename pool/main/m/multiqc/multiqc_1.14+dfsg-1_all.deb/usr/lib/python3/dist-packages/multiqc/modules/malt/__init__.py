from .malt import MultiqcModule
