from .fgbio import MultiqcModule
