from .pycoqc import MultiqcModule
