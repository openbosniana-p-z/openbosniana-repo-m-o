from .mtnucratio import MultiqcModule
