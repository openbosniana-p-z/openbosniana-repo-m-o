from .htseq import MultiqcModule
