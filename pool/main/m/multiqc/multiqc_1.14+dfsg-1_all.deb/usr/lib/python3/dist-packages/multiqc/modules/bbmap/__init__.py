from .bbmap import MultiqcModule
