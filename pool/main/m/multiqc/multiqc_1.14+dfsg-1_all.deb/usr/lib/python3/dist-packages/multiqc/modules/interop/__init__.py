from .interop import MultiqcModule
