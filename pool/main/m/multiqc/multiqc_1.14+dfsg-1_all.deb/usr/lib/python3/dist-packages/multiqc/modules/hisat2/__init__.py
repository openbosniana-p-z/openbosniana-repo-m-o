from .hisat2 import MultiqcModule
