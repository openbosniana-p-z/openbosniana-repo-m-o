from .hicpro import MultiqcModule
