from .trimmomatic import MultiqcModule
