from .theta2 import MultiqcModule
