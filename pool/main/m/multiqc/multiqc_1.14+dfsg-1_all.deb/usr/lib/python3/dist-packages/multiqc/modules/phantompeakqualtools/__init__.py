from .phantompeakqualtools import MultiqcModule
