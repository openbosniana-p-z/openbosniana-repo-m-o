from .conpair import MultiqcModule
