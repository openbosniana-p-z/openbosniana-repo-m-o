from .longranger import MultiqcModule
