from .rna_seqc import MultiqcModule
