from .supernova import MultiqcModule
