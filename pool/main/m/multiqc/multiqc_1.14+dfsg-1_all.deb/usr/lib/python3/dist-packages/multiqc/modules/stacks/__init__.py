from .stacks import MultiqcModule
