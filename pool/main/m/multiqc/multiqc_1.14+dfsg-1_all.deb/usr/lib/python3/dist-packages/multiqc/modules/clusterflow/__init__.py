from .clusterflow import MultiqcModule
