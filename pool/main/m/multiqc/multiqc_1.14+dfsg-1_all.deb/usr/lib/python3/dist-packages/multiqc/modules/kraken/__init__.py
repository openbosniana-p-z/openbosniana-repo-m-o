from .kraken import MultiqcModule
