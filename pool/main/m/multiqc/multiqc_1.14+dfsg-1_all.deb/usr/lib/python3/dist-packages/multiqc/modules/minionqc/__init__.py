from .minionqc import MultiqcModule
