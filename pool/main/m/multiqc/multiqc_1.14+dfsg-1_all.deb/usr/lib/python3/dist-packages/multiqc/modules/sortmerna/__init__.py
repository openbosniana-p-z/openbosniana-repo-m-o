from .sortmerna import MultiqcModule
