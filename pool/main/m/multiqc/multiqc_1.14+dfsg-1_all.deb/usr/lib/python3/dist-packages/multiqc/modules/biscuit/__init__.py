from .biscuit import MultiqcModule
