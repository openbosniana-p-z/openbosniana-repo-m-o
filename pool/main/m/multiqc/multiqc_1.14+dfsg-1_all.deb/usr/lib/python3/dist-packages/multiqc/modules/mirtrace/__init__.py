from .mirtrace import MultiqcModule
