from .flash import MultiqcModule
