from .prokka import MultiqcModule
