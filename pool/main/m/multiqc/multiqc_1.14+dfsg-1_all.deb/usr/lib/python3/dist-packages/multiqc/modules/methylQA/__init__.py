from .methylQA import MultiqcModule
