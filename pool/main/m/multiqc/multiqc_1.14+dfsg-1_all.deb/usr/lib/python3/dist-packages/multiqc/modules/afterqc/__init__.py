from .afterqc import MultiqcModule
