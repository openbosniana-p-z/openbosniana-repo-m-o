from .hicup import MultiqcModule
