from .ccs import MultiqcModule
