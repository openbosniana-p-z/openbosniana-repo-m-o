from .purple import MultiqcModule
