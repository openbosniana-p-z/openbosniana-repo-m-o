# -*- coding: utf-8 -*-


from .gatk import MultiqcModule
