from .whatshap import MultiqcModule
