from .bcftools import MultiqcModule
