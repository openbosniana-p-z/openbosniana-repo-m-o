from .hicexplorer import MultiqcModule
