from .bowtie2 import MultiqcModule
