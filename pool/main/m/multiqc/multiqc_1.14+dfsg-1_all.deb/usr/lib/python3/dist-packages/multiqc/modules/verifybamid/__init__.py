from .verifybamid import MultiqcModule
