from .hops import MultiqcModule
