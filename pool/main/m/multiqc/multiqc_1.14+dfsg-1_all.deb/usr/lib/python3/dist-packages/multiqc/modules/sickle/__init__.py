from .sickle import MultiqcModule
