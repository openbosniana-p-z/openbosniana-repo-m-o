from .dedup import MultiqcModule
