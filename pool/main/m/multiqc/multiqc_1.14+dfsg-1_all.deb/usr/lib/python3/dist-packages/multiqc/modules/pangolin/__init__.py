from .pangolin import MultiqcModule
