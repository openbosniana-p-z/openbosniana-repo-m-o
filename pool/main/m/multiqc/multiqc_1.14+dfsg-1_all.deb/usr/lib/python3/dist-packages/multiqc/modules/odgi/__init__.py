from .odgi import MultiqcModule
