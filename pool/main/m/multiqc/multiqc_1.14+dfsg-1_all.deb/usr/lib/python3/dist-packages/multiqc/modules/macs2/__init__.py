from .macs2 import MultiqcModule
