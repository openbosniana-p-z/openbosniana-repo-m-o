from .biobloomtools import MultiqcModule
