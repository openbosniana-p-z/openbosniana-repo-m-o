from .optitype import MultiqcModule
