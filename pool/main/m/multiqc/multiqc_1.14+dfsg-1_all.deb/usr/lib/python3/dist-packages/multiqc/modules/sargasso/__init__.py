from .sargasso import MultiqcModule
