from .salmon import MultiqcModule
