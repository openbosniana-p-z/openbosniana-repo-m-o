void MVM_spesh_eliminate_dead_ins(MVMThreadContext *tc, MVMSpeshGraph *g);
