
char * MVM_bytecode_dump(MVMThreadContext *tc, MVMCompUnit *cu);
