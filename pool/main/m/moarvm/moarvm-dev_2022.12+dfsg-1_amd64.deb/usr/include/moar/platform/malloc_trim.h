int MVM_malloc_trim(void);
