# mutt-alias.el
Lookup/insert mutt mail aliases.

To build the info file:
  makeinfo mutt-alias.texi
