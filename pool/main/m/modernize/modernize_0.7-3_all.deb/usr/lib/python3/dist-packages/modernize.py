from __future__ import absolute_import

import sys

from libmodernize.main import main

sys.exit(main())
