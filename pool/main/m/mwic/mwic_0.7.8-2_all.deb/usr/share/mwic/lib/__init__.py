'''
mwic's private modules
'''

type(lambda: (yield from []))  # Python >= 3.3 is required
