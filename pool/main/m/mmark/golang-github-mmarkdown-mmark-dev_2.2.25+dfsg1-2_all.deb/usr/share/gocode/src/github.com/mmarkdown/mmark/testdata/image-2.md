Just take a look at

!---
![alt](context.svg "context")
!---

this image
