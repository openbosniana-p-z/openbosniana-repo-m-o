package mast

import (
	"github.com/gomarkdown/markdown/ast"
)

// Authors represents markdown authors section node.
type Authors struct {
	ast.Container
}
