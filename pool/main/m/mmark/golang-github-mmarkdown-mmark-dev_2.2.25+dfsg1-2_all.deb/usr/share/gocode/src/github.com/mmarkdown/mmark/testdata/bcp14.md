**this is strong**

**MUST NOT** **MUST REALLY NOT**
