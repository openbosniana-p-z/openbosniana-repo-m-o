[@RFC2535, zie, sectie 5; @RFC2523]
