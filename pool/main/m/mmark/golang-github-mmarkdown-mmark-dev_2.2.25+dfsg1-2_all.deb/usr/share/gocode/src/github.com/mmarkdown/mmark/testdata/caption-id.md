Name    | Age
--------|------
Bob     | 27
Alice   | 23
Table: This is a proper table caption. {#data_types}
