package main

// Version of mmark.
var Version = "2.2.25"
