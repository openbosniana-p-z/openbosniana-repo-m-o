[@RFC2535, section 5]
