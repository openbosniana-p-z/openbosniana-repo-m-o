!---
![svg](array-vs-slice.svg "Image1")
![ascii-art](array-vs-slice.ascii-art "Image2")
!---
