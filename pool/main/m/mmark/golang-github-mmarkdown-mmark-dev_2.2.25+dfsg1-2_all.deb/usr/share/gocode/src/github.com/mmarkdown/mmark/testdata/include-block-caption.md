<{{includes.c}}
Figure: A sample function.

And some other text.
