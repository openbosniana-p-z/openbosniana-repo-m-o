~~~ txt
cluster.local:53 {
	kubernetes cluster.local {
	upstream
    }
}
~~~
