Name    | Age
--------|------
Bob     | 27
Table: This is a proper table caption

~~~ sh
% cat /dev/zero
~~~
