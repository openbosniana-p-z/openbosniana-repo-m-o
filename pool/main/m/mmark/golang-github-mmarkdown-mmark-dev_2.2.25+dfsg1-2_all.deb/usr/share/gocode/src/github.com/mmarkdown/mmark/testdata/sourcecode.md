~~~ go
println("hello")
~~~
