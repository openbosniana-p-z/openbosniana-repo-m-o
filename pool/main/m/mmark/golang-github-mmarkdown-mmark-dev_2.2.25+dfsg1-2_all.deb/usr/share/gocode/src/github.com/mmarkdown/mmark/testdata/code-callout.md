~~~ go
for _, days := range monthdays //<<1>>
~~~

At <<1>> we use the underscore.
