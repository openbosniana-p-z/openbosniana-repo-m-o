See [external reference](https://example.org).
