[@RFC2535, sectie 5]
