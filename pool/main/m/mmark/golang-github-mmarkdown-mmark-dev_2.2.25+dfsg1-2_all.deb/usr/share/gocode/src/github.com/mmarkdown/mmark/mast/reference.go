package mast

import "github.com/gomarkdown/markdown/ast"

// ReferenceBlock represents markdown reference node.
type ReferenceBlock struct {
	ast.Leaf
}
