Name    | Age
--------|------
Bob     | 27
Alice   ||
Table: This is a proper table caption
