<{{includes.c}}

And some other text.
