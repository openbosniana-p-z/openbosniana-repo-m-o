packets return within <10 s
