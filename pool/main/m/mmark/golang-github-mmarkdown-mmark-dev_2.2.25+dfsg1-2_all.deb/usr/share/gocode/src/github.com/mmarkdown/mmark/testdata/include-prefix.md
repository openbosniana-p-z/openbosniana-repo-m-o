{{includes}}[prefix="C: "]

not included text
