~~~
println("GO")
~~~
Figure: This is a proper caption. {#golang}
