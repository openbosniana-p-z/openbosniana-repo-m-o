module Mkalias
  VERSION = '1.0.10'.freeze
end
