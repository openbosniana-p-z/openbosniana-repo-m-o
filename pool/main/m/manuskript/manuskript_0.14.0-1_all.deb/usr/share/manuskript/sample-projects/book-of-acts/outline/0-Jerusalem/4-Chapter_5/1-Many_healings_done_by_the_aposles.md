title:          Many healings done by the aposles
ID:             20
type:           md
compile:        2


 12 By the hands of the apostles many signs and wonders were done among the people. They were all with one accord in Solomon’s porch. 13 None of the rest dared to join them, however the people honored them. 14 More believers were added to the Lord, multitudes of both men and women. 15 They even carried out the sick into the streets, and laid them on cots and mattresses, so that as Peter came by, at the least his shadow might overshadow some of them. 16 The multitude also came together from the cities around Jerusalem, bringing sick people and those who were tormented by unclean spirits: and they were all healed. 