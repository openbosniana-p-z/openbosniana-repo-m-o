title:          Introduction
ID:             1
type:           md
compile:        2


1 The first book I wrote, Theophilus, concerned all that Jesus began both to do and to teach, 2 until the day in which he was received up, after he had given commandment through the Holy Spirit to the apostles whom he had chosen. 3 To these he also showed himself alive after he suffered, by many proofs, appearing to them over a period of forty days, and speaking about God’s Kingdom. 