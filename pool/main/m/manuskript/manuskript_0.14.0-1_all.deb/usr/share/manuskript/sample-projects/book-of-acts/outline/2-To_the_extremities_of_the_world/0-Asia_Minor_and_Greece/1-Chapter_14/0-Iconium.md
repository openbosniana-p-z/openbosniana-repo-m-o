title:          Iconium
ID:             54
type:           md
compile:        2


1 In Iconium, they entered together into the synagogue of the Jews, and so spoke that a great multitude both of Jews and of Greeks believed. 2 But the disbelieving* Jews stirred up and embittered the souls of the Gentiles against the brothers. 3 Therefore they stayed there a long time, speaking boldly in the Lord, who testified to the word of his grace, granting signs and wonders to be done by their hands. 4 But the multitude of the city was divided. Part sided with the Jews, and part with the apostles. 5 When some of both the Gentiles and the Jews, with their rulers, made a violent attempt to mistreat and stone them, 6 they became aware of it and fled to the cities of Lycaonia, Lystra, Derbe, and the surrounding region. 7 There they preached the Good News. 