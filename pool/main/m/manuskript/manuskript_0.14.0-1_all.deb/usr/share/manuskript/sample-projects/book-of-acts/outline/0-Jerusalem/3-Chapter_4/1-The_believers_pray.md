title:          The believers pray
ID:             17
type:           md
notes:          Mention: {C:4:Herod}
compile:        2


 23 Being let go, they came to their own company and reported all that the chief priests and the elders had said to them. 24 When they heard it, they lifted up their voice to God with one accord, and said, “O Lord, you are God, who made the heaven, the earth, the sea, and all that is in them; 25 who by the mouth of your servant, David, said,
‘Why do the nations rage,
and the peoples plot a vain thing?
26 The kings of the earth take a stand,
and the rulers take council together,
against the Lord, and against his Christ.’*✡
27 “For truly, in this city against your holy servant, Jesus, whom you anointed, both Herod and Pontius Pilate, with the Gentiles and the people of Israel, were gathered together 28 to do whatever your hand and your council foreordained to happen. 29 Now, Lord, look at their threats, and grant to your servants to speak your word with all boldness, 30 while you stretch out your hand to heal; and that signs and wonders may be done through the name of your holy Servant Jesus.”
31 When they had prayed, the place was shaken where they were gathered together. They were all filled with the Holy Spirit, and they spoke the word of God with boldness. 