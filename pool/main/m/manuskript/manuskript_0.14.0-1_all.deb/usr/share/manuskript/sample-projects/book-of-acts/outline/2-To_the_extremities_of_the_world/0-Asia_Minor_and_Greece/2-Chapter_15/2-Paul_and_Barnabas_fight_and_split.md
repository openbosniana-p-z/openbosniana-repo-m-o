title:          Paul and Barnabas fight and split
ID:             59
type:           md
notes:          {P:2:Paul and Barnabas fight}
                {C:5:Barnabas}
compile:        2


36 After some days Paul said to Barnabas, “Let’s return now and visit our brothers in every city in which we proclaimed the word of the Lord, to see how they are doing.” 37 Barnabas planned to take John, who was called Mark, with them also. 38 But Paul didn’t think that it was a good idea to take with them someone who had withdrawn from them in Pamphylia, and didn’t go with them to do the work. 39 Then the contention grew so sharp that they separated from each other. Barnabas took Mark with him and sailed away to Cyprus, 40 but Paul chose Silas and went out, being commended by the brothers to the grace of God. 41 He went through Syria and Cilicia, strengthening the assemblies. 