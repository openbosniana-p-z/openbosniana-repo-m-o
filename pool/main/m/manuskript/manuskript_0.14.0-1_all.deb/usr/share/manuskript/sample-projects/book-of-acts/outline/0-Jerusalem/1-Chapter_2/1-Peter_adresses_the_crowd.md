title:          Peter adresses the crowd
ID:             15
type:           md
POV:            0
notes:          {P:0:The good news spreads from Jerusalem to Rome}
compile:        2


14 But Peter, standing up with the eleven, lifted up his voice, and spoke out to them, “You men of Judea, and all you who dwell at Jerusalem, let this be known to you, and listen to my words. 15 For these aren’t drunken, as you suppose, seeing it is only the third hour of the day. 16 But this is what has been spoken through the prophet Joel:
17 ‘It will be in the last days, says God,
that I will pour out my Spirit on all flesh.
Your sons and your daughters will prophesy.
Your young men will see visions.
Your old men will dream dreams.
18 Yes, and on my servants and on my handmaidens in those days,
I will pour out my Spirit, and they will prophesy.
19 I will show wonders in the sky above,
and signs on the earth beneath;
blood, and fire, and billows of smoke.
20 The sun will be turned into darkness,
and the moon into blood,
before the great and glorious day of the Lord comes.
21 It will be that whoever will call on the name of the Lord will be saved.’
22 “Men of Israel, hear these words! Jesus of Nazareth, a man approved by God to you by mighty works and wonders and signs which God did by him among you, even as you yourselves know, 23 him, being delivered up by the determined counsel and foreknowledge of God, you have taken by the hand of lawless men, crucified and killed; 24 whom God raised up, having freed him from the agony of death, because it was not possible that he should be held by it. 25 For David says concerning him,
‘I saw the Lord always before my face,
for he is on my right hand, that I should not be moved.
26 Therefore my heart was glad, and my tongue rejoiced.
Moreover my flesh also will dwell in hope;
27 because you will not leave my soul in Hades,†
neither will you allow your Holy One to see decay.
28 You made known to me the ways of life.
You will make me full of gladness with your presence.’
29 “Brothers, I may tell you freely of the patriarch David, that he both died and was buried, and his tomb is with us to this day. 30 Therefore, being a prophet, and knowing that God had sworn with an oath to him that of the fruit of his body, according to the flesh, he would raise up the Christ to sit on his throne, 31 he foreseeing this spoke about the resurrection of the Christ, that his soul wasn’t left in Hades,‡ and his flesh didn’t see decay. 32 This Jesus God raised up, to which we all are witnesses. 33 Being therefore exalted by the right hand of God, and having received from the Father the promise of the Holy Spirit, he has poured out this, which you now see and hear. 34 For David didn’t ascend into the heavens, but he says himself,
‘The Lord said to my Lord, “Sit by my right hand
35 until I make your enemies a footstool for your feet.” ’
36 “Let all the house of Israel therefore know certainly that God has made him both Lord and Christ, this Jesus whom you crucified.”
37 Now when they heard this, they were cut to the heart, and said to Peter and the rest of the apostles, “Brothers, what shall we do?”
38 Peter said to them, “Repent, and be baptized, every one of you, in the name of Jesus Christ for the forgiveness of sins, and you will receive the gift of the Holy Spirit. 39 For the promise is to you, and to your children, and to all who are far off, even as many as the Lord our God will call to himself.” 40 With many other words he testified, and exhorted them, saying, “Save yourselves from this crooked generation!”
41 Then those who gladly received his word were baptized. There were added that day about three thousand souls. 