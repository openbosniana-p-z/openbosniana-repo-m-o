title:          The church scattered
ID:             26
type:           md
notes:          {P:0:The good news spreads from Jerusalem to Rome}
compile:        2


1 Saul was consenting to his death. A great persecution arose against the assembly which was in Jerusalem in that day. They were all scattered abroad throughout the regions of Judea and Samaria, except for the apostles. 2 Devout men buried Stephen and lamented greatly over him. 3 But Saul ravaged the assembly, entering into every house and dragged both men and women off to prison. 4 Therefore those who were scattered abroad went around preaching the word.