title:          Jesus taken up into heaven
ID:             2
type:           md
notes:          {P:0:The good news spreads from Jerusalem to Rome}
compile:        2


4 Being assembled together with them, he commanded them, “Don’t depart from Jerusalem, but wait for the promise of the Father, which you heard from me. 5  For John indeed baptized in water, but you will be baptized in the Holy Spirit not many days from now.”
6 Therefore when they had come together, they asked him, “Lord, are you now restoring the kingdom to Israel?”
7 He said to them, “It isn’t for you to know times or seasons which the Father has set within his own authority. 8  But you will receive power when the Holy Spirit has come upon you. You will be witnesses to me in Jerusalem, in all Judea and Samaria, and to the uttermost parts of the earth.”
9 When he had said these things, as they were looking, he was taken up, and a cloud received him out of their sight. 10 While they were looking steadfastly into the sky as he went, behold,* two men stood by them in white clothing, 11 who also said, “You men of Galilee, why do you stand looking into the sky? This Jesus, who was received up from you into the sky, will come back in the same way as you saw him going into the sky.”