title:          Stephen is killed
ID:             25
type:           md
POV:            3
compile:        2


 54 Now when they heard these things, they were cut to the heart, and they gnashed at him with their teeth. 55 But he, being full of the Holy Spirit, looked up steadfastly into heaven and saw the glory of God, and Jesus standing on the right hand of God, 56 and said, “Behold, I see the heavens opened, and the Son of Man standing at the right hand of God!”
57 But they cried out with a loud voice and stopped their ears, then rushed at him with one accord. 58 They threw him out of the city and stoned him. The witnesses placed their garments at the feet of a young man named Saul. 59 They stoned Stephen as he called out, saying, “Lord Jesus, receive my spirit!” 60 He kneeled down, and cried with a loud voice, “Lord, don’t hold this sin against them!” When he had said this, he fell asleep. 