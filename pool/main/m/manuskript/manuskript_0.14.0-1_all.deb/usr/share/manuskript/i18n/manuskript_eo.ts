<?xml version='1.0' encoding='UTF-8'?>
<!DOCTYPE TS>
<TS version="2.0" language="eo" sourcelanguage="">
<context>
    <name>Export</name>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="18"/>
        <source>Basic HTML output using the Python module 'markdown'.</source>
        <translation>Simpla HTML-eligo per la Python-modulo «markdown».</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="19"/>
        <source>Python module 'markdown'.</source>
        <translation>Python-modulo «markdown».</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="54"/>
        <source>Markdown source</source>
        <translation>Markdown-fonto</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="55"/>
        <source>HTML Source</source>
        <translation>HTML-fonto</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="59"/>
        <source>HTML Output</source>
        <translation>HTML-eligo</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/__init__.py" line="15"/>
        <source>Default exporter, provides basic formats used by other exporters.</source>
        <translation>Implicita elportilo, provizanta bazajn dosierformojn uzatajn de aliaj elportiloj.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/markdown.py" line="60"/>
        <source>Preview with highlighter.</source>
        <translation>Antaŭrigardi kun sintaksreliefigo.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="14"/>
        <source>Plain text</source>
        <translation>Simpla teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/HTML.py" line="13"/>
        <source>A little known format modestly used. You know, web sites for example.</source>
        <translation>Senfama dosierformo iomete uzata. Eble vi konas ĝin — en la Tut-Tera Teksaĵo interalie?</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/PDF.py" line="18"/>
        <source>Needs LaTeX to be installed.</source>
        <translation>Postulas instalon de LaTeX.</translation>
    </message>
    <message>
        <location filename="../manuskript/converters/pandocConverter.py" line="75"/>
        <source>Error</source>
        <translation>Eraro</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="97"/>
        <source>Standalone document (not just a fragment)</source>
        <translation>Memstara dokumento (ne nura fragmento)</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="100"/>
        <source>Include a table of contents.</source>
        <translation>Enmeti enhavtabelon.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="103"/>
        <source>Number of sections level to include in TOC: </source>
        <translation>Nombro de sekciaj niveloj inkluzivotaj en la enhavtabelo: </translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="107"/>
        <source>Typographically correct output</source>
        <translation>Tipografie ĝusta eligo</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="110"/>
        <source>Normalize the document (cleaner)</source>
        <translation>Laŭnormigi la dokumenton</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="112"/>
        <source>Specify the base level for headers: </source>
        <translation>Specifi la baznivelon de sekcititoloj: </translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="119"/>
        <source>Use reference-style links instead of inline links</source>
        <translation>Uzi referencajn ligojn anstataŭ entekstaj ligoj</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="121"/>
        <source>Use ATX-style headers</source>
        <translation>Uzi sekcititolojn de stilo atx</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="123"/>
        <source>Self-contained HTML files, with no dependencies</source>
        <translation>Memstaraj HTML-dosieroj, sen dependaĵoj</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="125"/>
        <source>Use &lt;q&gt; tags for quotes in HTML</source>
        <translation>Uzi elementojn &lt;q&gt; por citiloj en HTML</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="132"/>
        <source>LaTeX engine used to produce the PDF.</source>
        <translation>LaTeX-modulo por fari PDF.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="142"/>
        <source>Paper size:</source>
        <translation>Formato:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="145"/>
        <source>Font size:</source>
        <translation>Tipargrando:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="148"/>
        <source>Class:</source>
        <translation>Klaso:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="151"/>
        <source>Line spacing:</source>
        <translation>Spaco inter linioj:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/outputFormats.py" line="10"/>
        <source>Books that don't kill trees.</source>
        <translation>Libroj, kiuj ne mortigas arbojn.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/outputFormats.py" line="21"/>
        <source>OpenDocument format. Used by LibreOffice for example.</source>
        <translation>Dosierformo OpenDocument. Uzata de LibreOffice, ekzemple.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/outputFormats.py" line="32"/>
        <source>Microsoft Office (.docx) document.</source>
        <translation>Dokumento de Microsoft Office (.docx).</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="22"/>
        <source>reStructuredText is a lightweight markup language.</source>
        <translation>reStructuredText estas simpla marklingvo.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/markdown.py" line="14"/>
        <source>Just like plain text, excepts adds markdown titles.
                          Presupposes that texts are formatted in markdown.</source>
        <translation>Same kiel simpla teksto, krom aldono de Markdown-sekcititoloj.
                          Tio supozas, ke la tekstoj estas Markdown-dokumentoj.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="15"/>
        <source>Simplest export to plain text. Allows you to use your own markup not understood
                  by Manuskript, for example &lt;a href='www.fountain.io'&gt;Fountain&lt;/a&gt;.</source>
        <translation>Plej simpla elporto al simpla teksto. Permesas al vi uzi vian propran marklingvon ne komprenatan
                  de Manuskript, ekzemple &lt;a href='www.fountain.io'&gt;Fountain&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/__init__.py" line="20"/>
        <source>&lt;p&gt;A universal document converter. Can be used to convert Markdown to a wide range of other
    formats.&lt;/p&gt;
    &lt;p&gt;Website: &lt;a href="http://www.pandoc.org"&gt;http://pandoc.org/&lt;/a&gt;&lt;/p&gt;
    </source>
        <translation>&lt;p&gt;Universala dokumentkonvertilo. Povas konverti Markdown al diversaj aliaj
    dosierformoj. &lt;/p&gt;
    &lt;p&gt;Retejo: &lt;a href="http://www.pandoc.org"&gt;http://pandoc.org/&lt;/a&gt; &lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/PDF.py" line="19"/>
        <source>a valid LaTeX installation. Pandoc recommendations can be found on:
                     &lt;a href="https://pandoc.org/installing.html"&gt;pandoc.org/installing.html&lt;/a&gt;. If you want Unicode support, you need XeLaTeX.</source>
        <translation>valida instalo de LaTeX. Rekomendoj pri Pandoc troveblas ĉe
                     &lt;a href="https://pandoc.org/installing.html"&gt;pandoc.org/installing.html&lt;/a&gt;. Se vi volas uzi Unikodon, vi bezonas XeLaTeX.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="10"/>
        <source>Export to markdown, using pandoc. Allows more formatting options
    than the basic manuskript exporter.</source>
        <translation>Elporti al Markdown per Pandoc. Permesas pli da opcioj
    ol la baza elportilo de Manuskript.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="33"/>
        <source>LaTeX is a word processor and document markup language used to create
                                              beautiful documents.</source>
        <translation>LaTeX estas tekstoprilaborilo kaj dokumenta marklingvo por krei
                                              belajn dokumentojn.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="45"/>
        <source>The purpose of this format is to provide a way to exchange information
                                              between outliners and Internet services that can be browsed or controlled
                                              through an outliner.</source>
        <translation>Ĉi tiu dosierformo celas provizi manieron interŝanĝi informojn
                                              inter skiziloj kaj Interretaj servoj, kiujn oni povas legi aŭ modifi
                                              per skizilo.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="115"/>
        <source>Disable YAML metadata block.
Use that if you get YAML related error.</source>
        <translation>Malŝalti YAML-metadatenblokon.
Uzu ĉi tion se okazas YAML-rilata eraro.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="135"/>
        <source>Convert to ePUB3</source>
        <translation>Konverti al EPUB3</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="48"/>
        <source>Could not process regular expression: 
{}</source>
        <translation>Ne eblis uzi la regulan esprimon:
{}</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="70"/>
        <source>Choose output fileâ¦</source>
        <translation>Elekti eligan dosieron…</translation>
    </message>
</context>
<context>
    <name>ExportersManager</name>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="14"/>
        <source>Manage Exporters</source>
        <translation>Administri elportilojn</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="21"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="66"/>
        <source>Description</source>
        <translation>Priskribo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="100"/>
        <source>Offers export to</source>
        <translation>Kapabla elporti al</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="184"/>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="190"/>
        <source>Status:</source>
        <translation>Stato:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="210"/>
        <source>Version:</source>
        <translation>Versio:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="233"/>
        <source>Path:</source>
        <translation>Dosierindiko:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="258"/>
        <source>...</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="273"/>
        <source>{HelpText}</source>
        <translation>{HelpText}</translation>
    </message>
</context>
<context>
    <name>FrequencyAnalyzer</name>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="14"/>
        <source>Frequency Analyzer</source>
        <translation>Oftecanalizilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="24"/>
        <source>Word frequency</source>
        <translation>Vortofteco</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="37"/>
        <source>Settings</source>
        <translation>Agordoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="49"/>
        <source>Minimum size:</source>
        <translation>Minimuma grando:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="63"/>
        <source>Exclude words (comma separated):</source>
        <translation>Ekskluzivi la jenajn vortojn (kome disigitajn):</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="156"/>
        <source>Analyze</source>
        <translation>Analizi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="107"/>
        <source>Phrase frequency</source>
        <translation>Ofteco de frazelemento</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="115"/>
        <source>Number of words: from</source>
        <translation>Nombro de vortoj: inter</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="129"/>
        <source>to</source>
        <translation>kaj</translation>
    </message>
</context>
<context>
    <name>Import</name>
    <message>
        <location filename="../manuskript/importer/markdownImporter.py" line="178"/>
        <source>Markdown import</source>
        <translation>Enporti Markdown</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/markdownImporter.py" line="182"/>
        <source>&lt;b&gt;Info:&lt;/b&gt; A very simple
                        parser that will go through a markdown document and
                        create items for each titles.&lt;br/&gt;&amp;nbsp;</source>
        <translation>&lt;b&gt;Informoj:&lt;/b&gt; Tre simpla
                        sintaksanalizilo, kiu trairos Markdown-dokumenton kaj
                        kreos erojn po unu por ĉiu sekcititolo.&lt;br/&gt;&amp;nbsp;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="97"/>
        <source>Folder import</source>
        <translation>Enporti dosierujon</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="101"/>
        <source>&lt;p&gt;&lt;b&gt;Info:&lt;/b&gt; Imports a whole
                        directory structure. Folders are added as folders, and
                        plaintext documents within (you chose which ones by extension)
                        are added as scene.&lt;/p&gt;
                        &lt;p&gt;Only text files are supported (not images, binary or others).&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Informoj:&lt;/b&gt;Enporti tutan
                        dosierujon. Aldoni dosierujojn kiel dosierujojn, kaj
                        simplajn tekstajn dokumentojn en ili (elektitajn laŭ dosiersufikso)
                        kiel scenojn.&lt;/p&gt;
                        &lt;p&gt; Nur tekstaj dosieroj estas subtenataj (ne bildoj, duumaĵoj ktp).&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="108"/>
        <source>Include only those extensions:</source>
        <translation>Inkluzivi nur la jenajn dosiersufiksojn:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="108"/>
        <source>Comma separated values</source>
        <translation>Kome disigitaj valoroj</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="113"/>
        <source>Sort items by name</source>
        <translation>Ordigi laŭ nomo</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="117"/>
        <source>Import folder then files</source>
        <translation>Enporti dosierujon, poste dosierojn</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/opmlImporter.py" line="65"/>
        <source>OPML Import</source>
        <translation>Enporti OPML</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/opmlImporter.py" line="37"/>
        <source>File open failed.</source>
        <translation>Malsukcesis malfermi dosieron.</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/opmlImporter.py" line="65"/>
        <source>This does not appear to be a valid OPML file.</source>
        <translation>Tiu ŝajne ne estas valida OPML-dosiero.</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="58"/>
        <source>Pandoc import</source>
        <translation>Enporti Pandoc</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="61"/>
        <source>&lt;b&gt;Info:&lt;/b&gt; Manuskript can
                        import from &lt;b&gt;markdown&lt;/b&gt; or &lt;b&gt;OPML&lt;/b&gt;. Pandoc will
                        convert your document to either (see option below), and
                        then it will be imported in manuskript. One or the other
                        might give better result depending on your document.
                        &lt;br/&gt;&amp;nbsp;</source>
        <translation>&lt;b&gt;Informoj:&lt;/b&gt; Manuskript povas
                        enporti dokumentojn de &lt;b&gt;Markdown&lt;/b&gt; aŭ &lt;b&gt;OPML&lt;/b&gt;. Pandoc
                        povas konverti vian dokumenton al unu ajn el la du (vidu la opcion ĉi-sube),
                        kaj poste Manuskript enportos ĝin. Unu aŭ la alia eble donos pli bonan
                        rezulton, depende de via dokumento.
                        &lt;br/&gt;&amp;nbsp;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="69"/>
        <source>Import using:</source>
        <translation>Enporti per:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="73"/>
        <source>Wrap lines:</source>
        <translation>Faldi liniojn:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="73"/>
        <source>&lt;p&gt;Should pandoc create
                        cosmetic / non-semantic line-breaks?&lt;/p&gt;&lt;p&gt;
                        &lt;b&gt;auto&lt;/b&gt;: wraps at 72 characters.&lt;br&gt;
                        &lt;b&gt;none&lt;/b&gt;: no line wrap.&lt;br&gt;
                        &lt;b&gt;preserve&lt;/b&gt;: tries to preserves line wrap from the
                        original document.&lt;/p&gt;</source>
        <translation>&lt;p&gt; Ĉu Pandoc enmetu
                        ornamajn / sensignifajn linifinojn?&lt;/p&gt;&lt;p&gt;
                        &lt;b&gt;auto&lt;/b&gt;: faldi liniojn ĉe 72 skribsignoj.&lt;br&gt;
                        &lt;b&gt;none&lt;/b&gt;: ne faldi liniojn.&lt;br&gt;
                        &lt;b&gt;preserve&lt;/b&gt;: provi konservi linifinojn de la
                        originala dokumento.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="56"/>
        <source>Mind Map Import</source>
        <translation>Enporti mensmapon</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="56"/>
        <source>This does not appear to be a valid Mind Map file.</source>
        <translation>Ĉi tio ŝajne ne estas valida mensmapa dosiero.</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="71"/>
        <source>Mind Map import</source>
        <translation>Enporti mensmapon</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="74"/>
        <source>Import tip as:</source>
        <translation>Enporti konsileton kiel:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="90"/>
        <source>Untitled</source>
        <translation>Sentitola</translation>
    </message>
</context>
<context>
    <name>MDEditCompleter</name>
    <message>
        <location filename="../manuskript/ui/views/MDEditCompleter.py" line="73"/>
        <source>Insert reference</source>
        <translation>Enmeti referencon</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1627"/>
        <source>General</source>
        <translation>Ĝenerala</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="169"/>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="179"/>
        <source>Subtitle</source>
        <translation>Subtitolo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="189"/>
        <source>Series</source>
        <translation>Serio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="199"/>
        <source>Volume</source>
        <translation>Volumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="226"/>
        <source>Genre</source>
        <translation>Ĝenro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="236"/>
        <source>License</source>
        <translation>Permesilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="249"/>
        <source>Author</source>
        <translation>Aŭtoro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1636"/>
        <source>Name</source>
        <translation>Nomo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="277"/>
        <source>Email</source>
        <translation>Retpoŝta adreso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1422"/>
        <source>Summary</source>
        <translation>Resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="322"/>
        <source>Situation:</source>
        <translation>Situacio:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1337"/>
        <source>Summary:</source>
        <translation>Resumo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="345"/>
        <source>One sentence</source>
        <translation>Unufraze</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1435"/>
        <source>One paragraph</source>
        <translation>Unualinee</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1440"/>
        <source>One page</source>
        <translation>Unupaĝe</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1445"/>
        <source>Full</source>
        <translation>Plene</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="420"/>
        <source>One sentence summary</source>
        <translation>Unufraza resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="502"/>
        <source>One paragraph summary</source>
        <translation>Unualinea resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="540"/>
        <source>Expand each sentence of your one paragraph summary to a paragraph</source>
        <translation>Plilongigu ĉiun frazon de via unualinea resumo al alineo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="565"/>
        <source>One page summary</source>
        <translation>Unupaĝa resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="590"/>
        <source>Full summary</source>
        <translation>Plena resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1074"/>
        <source>Next</source>
        <translation>Sekva</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="676"/>
        <source>What if...?</source>
        <translation>Kio se…?</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="688"/>
        <source>Characters</source>
        <translation>Roluloj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="713"/>
        <source>Names</source>
        <translation>Nomoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1587"/>
        <source>Filter</source>
        <translation>Filtri</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1183"/>
        <source>Basic info</source>
        <translation>Bazaj informoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1202"/>
        <source>Importance</source>
        <translation>Graveco</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="829"/>
        <source>Motivation</source>
        <translation>Instigo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="839"/>
        <source>Goal</source>
        <translation>Celo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="849"/>
        <source>Conflict</source>
        <translation>Konflikto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="859"/>
        <source>Epiphany</source>
        <translation>Ekscio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="869"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align="right"&gt;One sentence&lt;br/&gt;summary&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align="right"&gt;Unufraza&lt;br/&gt;resumo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="879"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align="right"&gt;One paragraph&lt;br/&gt;summary&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align="right"&gt;Unualinea&lt;br/&gt;resumo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1001"/>
        <source>Notes</source>
        <translation>Notoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1011"/>
        <source>Detailed info</source>
        <translation>Detaloj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2021"/>
        <source>Plots</source>
        <translation>Intrigoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1192"/>
        <source>Plot</source>
        <translation>Intrigo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1209"/>
        <source>Character(s)</source>
        <translation>Rolulo(j)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1646"/>
        <source>Description</source>
        <translation>Priskribo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1223"/>
        <source>Result</source>
        <translation>Rezulto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1315"/>
        <source>Resolution steps</source>
        <translation>Solvopaŝoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2045"/>
        <source>World</source>
        <translation>Mondo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1600"/>
        <source>Populates with empty data</source>
        <translation>Plenigi per malplenaj datenoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1657"/>
        <source>More</source>
        <translation>Pli</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1666"/>
        <source>Source of passion</source>
        <translation>Fonto de pasio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1676"/>
        <source>Source of conflict</source>
        <translation>Fonto de konflikto</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1477"/>
        <source>Outline</source>
        <translation>Skizo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1854"/>
        <source>Editor</source>
        <translation>Redaktilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1985"/>
        <source>Debug</source>
        <translation>Sencimigi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1998"/>
        <source>FlatData</source>
        <translation>FlatData</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2008"/>
        <source>Persos</source>
        <translation>Roluloj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2069"/>
        <source>Labels</source>
        <translation>Etikedoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2103"/>
        <source>&amp;File</source>
        <translation>&amp;Dosiero</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2107"/>
        <source>&amp;Recent</source>
        <translation>&amp;Lastatempaj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2127"/>
        <source>&amp;Help</source>
        <translation>&amp;Helpo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2134"/>
        <source>&amp;Tools</source>
        <translation>&amp;Iloj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2141"/>
        <source>&amp;Edit</source>
        <translation>R&amp;edakti</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2196"/>
        <source>&amp;View</source>
        <translation>&amp;Vidi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2200"/>
        <source>&amp;Mode</source>
        <translation>Reĝi&amp;mo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2229"/>
        <source>&amp;Cheat sheet</source>
        <translation>&amp;Gvidfolio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2263"/>
        <source>Sea&amp;rch</source>
        <translation>Se&amp;rĉi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2300"/>
        <source>&amp;Navigation</source>
        <translation>&amp;Navigi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2335"/>
        <source>&amp;Open</source>
        <translation>&amp;Malfermi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2338"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2347"/>
        <source>&amp;Save</source>
        <translation>Kon&amp;servi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2350"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2359"/>
        <source>Sa&amp;ve as...</source>
        <translation>Konser&amp;vi kiel…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2362"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2371"/>
        <source>&amp;Quit</source>
        <translation>&amp;Forlasi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2374"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2389"/>
        <source>&amp;Show help texts</source>
        <translation>Montri helpotek&amp;ston</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2392"/>
        <source>Ctrl+Shift+B</source>
        <translation>Ctrl+Shift+B</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2407"/>
        <source>&amp;Spellcheck</source>
        <translation>&amp;Literumilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2410"/>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2419"/>
        <source>&amp;Labels...</source>
        <translation>&amp;Etikedoj…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2428"/>
        <source>&amp;Status...</source>
        <translation>&amp;Stato…</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1475"/>
        <source>Tree</source>
        <translation>Arbo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2444"/>
        <source>&amp;Simple</source>
        <translation>&amp;Simpla</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2452"/>
        <source>&amp;Fiction</source>
        <translation>&amp;Fikcio</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1476"/>
        <source>Index cards</source>
        <translation>Indekskartoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2471"/>
        <source>S&amp;ettings</source>
        <translation>&amp;Agordoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2474"/>
        <source>F8</source>
        <translation>F8</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2483"/>
        <source>&amp;Close project</source>
        <translation>&amp;Malfermi projekton</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2492"/>
        <source>Co&amp;mpile</source>
        <translation>&amp;Elporti</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2495"/>
        <source>F6</source>
        <translation>F6</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2500"/>
        <source>&amp;Frequency Analyzer</source>
        <translation>O&amp;ftecanalizilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="154"/>
        <source>Book information</source>
        <translation>Informoj pri libro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2509"/>
        <source>&amp;About</source>
        <translation>&amp;Pri</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2512"/>
        <source>About Manuskript</source>
        <translation>Pri Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="717"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="840"/>
        <source>Project {} saved.</source>
        <translation>Projekto {} konserviĝis.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="843"/>
        <source>WARNING: Project {} not saved.</source>
        <translation>AVERTO: Projekto {} ne konservita.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="867"/>
        <source>Project {} loaded.</source>
        <translation>Projekto {} ŝargiĝis.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="870"/>
        <source>Project {} loaded with some errors:</source>
        <translation>Projekto {} ŝargiĝis malgraŭ eraroj:</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="872"/>
        <source> * {} wasn't found in project file.</source>
        <translation> * {} ne troviĝis en la projekta dosiero.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="873"/>
        <source>Project {} loaded with some errors.</source>
        <translation>Ŝargiĝis projekto {} malgraŭ eraroj.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1202"/>
        <source> (~{} pages)</source>
        <translation> (~{} paĝoj)</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1206"/>
        <source>Words: {}{}</source>
        <translation>Vortoj: {}{}</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1214"/>
        <source>Book summary</source>
        <translation>Resumo de libro</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1215"/>
        <source>Project tree</source>
        <translation>Projektarbo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1216"/>
        <source>Metadata</source>
        <translation>Metadatenoj</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1217"/>
        <source>Story line</source>
        <translation>Intrigo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1282"/>
        <source>Enter information about your book, and yourself.</source>
        <translation>Tajpu informojn pri via libro kaj vi mem.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1285"/>
        <source>The basic situation, in the form of a 'What if...?' question. Ex: 'What if the most dangerous
                     evil wizard wasn't able to kill a baby?' (Harry Potter)</source>
        <translation>La baza situacio, en la formo de demando «Kio se…?». Ekz.: «Kio se la plej danĝera
                     malbona sorĉisto ne povis mortigi bebon?» (Harry Potter)</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1290"/>
        <source>Take time to think about a one sentence (~50 words) summary of your book. Then expand it to
                     a paragraph, then to a page, then to a full summary.</source>
        <translation>Pripensu unufrazan (proksimume 50-vortan) resumon de via libro. Poste plilongigu ĝin al
                     alineo, poste al paĝo, poste al plena resumo.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1295"/>
        <source>Create your characters.</source>
        <translation>Kreu viajn rolulojn.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1298"/>
        <source>Develop plots.</source>
        <translation>Disvolvu intrigojn.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1301"/>
        <source>Build worlds.  Create hierarchy of broad categories down to specific details.</source>
        <translation>Konstruu mondojn.  Kreu hierarkion de larĝaj kategorioj ĝis specifaj detaloj.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1304"/>
        <source>Create the outline of your masterpiece.</source>
        <translation>Kreu la skizon de via ĉefverko.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1307"/>
        <source>Write.</source>
        <translation>Verku.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1310"/>
        <source>Debug info. Sometimes useful.</source>
        <translation>Informoj por cimtrovado. Kelkfoje utilaj.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1324"/>
        <source>Dictionary</source>
        <translation>Vortaro</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1467"/>
        <source>Nothing</source>
        <translation>Nenio</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1468"/>
        <source>POV</source>
        <translation>Perspektivo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1469"/>
        <source>Label</source>
        <translation>Etikedo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1470"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1471"/>
        <source>Compile</source>
        <translation>Elporti</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1494"/>
        <source>Icon color</source>
        <translation>Koloro de piktogramo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1495"/>
        <source>Text color</source>
        <translation>Koloro de teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1496"/>
        <source>Background color</source>
        <translation>Fonkoloro</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1487"/>
        <source>Icon</source>
        <translation>Piktogramo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1488"/>
        <source>Text</source>
        <translation>Teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1489"/>
        <source>Background</source>
        <translation>Fono</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1490"/>
        <source>Border</source>
        <translation>Rando</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1491"/>
        <source>Corner</source>
        <translation>Angulo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1351"/>
        <source>Add plot step</source>
        <translation>Enmeti paŝon de intrigo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2521"/>
        <source>&amp;Importâ¦</source>
        <translation>&amp;Enporti…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2524"/>
        <source>F7</source>
        <translation>F7</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2533"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopii</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2536"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2545"/>
        <source>C&amp;ut</source>
        <translation>&amp;Eltondi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2548"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2557"/>
        <source>&amp;Paste</source>
        <translation>&amp;Alglui</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2560"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2569"/>
        <source>&amp;Splitâ¦</source>
        <translation>&amp;Dividi…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2572"/>
        <source>Ctrl+Shift+K</source>
        <translation>Ctrl+Shift+K</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2581"/>
        <source>Sp&amp;lit at cursor</source>
        <translation>&amp;Dividi ĉe kursoro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2584"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2596"/>
        <source>Ctrl+M</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2799"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2617"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2626"/>
        <source>&amp;Move Up</source>
        <translation>&amp;Movi supren</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2629"/>
        <source>Ctrl+Shift+Up</source>
        <translation>Ctrl+Shift+Up</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2638"/>
        <source>M&amp;ove Down</source>
        <translation>M&amp;ovi malsupren</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2641"/>
        <source>Ctrl+Shift+Down</source>
        <translation>Ctrl+Shift+Down</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2605"/>
        <source>Dupl&amp;icate</source>
        <translation>Duobl&amp;igi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2614"/>
        <source>&amp;Delete</source>
        <translation>&amp;Forigi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2650"/>
        <source>&amp;Rename</source>
        <translation>Ŝanĝi &amp;nomon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2653"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2210"/>
        <source>Organi&amp;ze</source>
        <translation>Organi&amp;zi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2593"/>
        <source>M&amp;erge</source>
        <translation>&amp;Kunfandi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2145"/>
        <source>&amp;Format</source>
        <translation>&amp;Aranĝi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2153"/>
        <source>&amp;Header</source>
        <translation>Sekci&amp;titolo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2658"/>
        <source>&amp;Level 1 (setext)</source>
        <translation>Nive&amp;lo 1 (setext)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2661"/>
        <source>Ctrl+Alt+1</source>
        <translation>Ctrl+Alt+1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2666"/>
        <source>Level &amp;2</source>
        <translation>Nivelo &amp;2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2669"/>
        <source>Ctrl+Alt+2</source>
        <translation>Ctrl+Alt+2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2674"/>
        <source>Level &amp;1 (atx)</source>
        <translation>Nivelo &amp;1 (atx)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2677"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2682"/>
        <source>L&amp;evel 2</source>
        <translation>Niv&amp;elo 2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2685"/>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2690"/>
        <source>Level &amp;3</source>
        <translation>Nivelo &amp;3</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2693"/>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2698"/>
        <source>Level &amp;4</source>
        <translation>Nivelo &amp;4</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2701"/>
        <source>Ctrl+4</source>
        <translation>Ctrl+4</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2706"/>
        <source>Level &amp;5</source>
        <translation>Nivelo &amp;5</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2709"/>
        <source>Ctrl+5</source>
        <translation>Ctrl+5</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2714"/>
        <source>Level &amp;6</source>
        <translation>Nivelo &amp;6</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2717"/>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2726"/>
        <source>&amp;Bold</source>
        <translation>&amp;Grasa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2729"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2738"/>
        <source>&amp;Italic</source>
        <translation>Obl&amp;ikva</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2741"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2750"/>
        <source>&amp;Strike</source>
        <translation>Tra&amp;strekita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2755"/>
        <source>&amp;Verbatim</source>
        <translation>&amp;Laŭliteraĵo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2760"/>
        <source>Su&amp;perscript</source>
        <translation>Su&amp;pra indico</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2763"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2768"/>
        <source>Subsc&amp;ript</source>
        <translation>Malsup&amp;ra indico</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2771"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2776"/>
        <source>Co&amp;mment block</source>
        <translation>Ko&amp;mentigi blokon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2779"/>
        <source>Ctrl+Shift+C</source>
        <translation>Ctrl+Shift+C</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2788"/>
        <source>Clear &amp;formats</source>
        <translation>&amp;Senigi tekstan aranĝon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2791"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2796"/>
        <source>&amp;Comment line(s)</source>
        <translation>&amp;Komentigi linio(j)n</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2804"/>
        <source>&amp;Ordered list</source>
        <translation>&amp;Ordita listo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2813"/>
        <source>&amp;Unordered list</source>
        <translation>&amp;Neordita listo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2818"/>
        <source>B&amp;lockquote</source>
        <translation>Citob&amp;loko</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1368"/>
        <source>Remove selected plot step(s)</source>
        <translation>Forigi elektita(j)n paŝo(j)n de intrigo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="561"/>
        <source>The file {} does not exist. Has it been moved or deleted?</source>
        <translation>La dosiero {} ne ekzistas. Ĉu ĝi estas movita aŭ forigita?</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1338"/>
        <source>Install {}{} to use spellcheck</source>
        <translation>Instalu {}{} por literumilo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1380"/>
        <source>{} has no installed dictionaries</source>
        <translation>Instalitaj vortaroj mankas al {}</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1401"/>
        <source>{}{} is not installed</source>
        <translation>{}{} ne estas instalita</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="660"/>
        <source>Save project?</source>
        <translation>Ĉu konservi projekton?</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="660"/>
        <source>Save changes to project "{}" before closing?</source>
        <translation>Ĉu konservi ŝanĝojn al projekto «{}» antaŭ ol fermi?</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="660"/>
        <source>Your changes will be lost if you don't save them.</source>
        <translation>Viaj ŝanĝoj perdiĝos se vi ne konservos ilin.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1594"/>
        <source>PyQt / Qt versions 5.11 and 5.12 are known to cause a crash which might result in a loss of data.</source>
        <translation>Versioj 5.11 kaj 5.22 de PyQt / Qt kaŭzas kolapson kaj eblan perdon de datenoj.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1595"/>
        <source>PyQt {} and Qt {} are in use.</source>
        <translation>PyQt {} kaj Qt {} estas uzataj.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1600"/>
        <source>Proceed with import at your own risk</source>
        <translation>Enportu je via propra risko</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="14"/>
        <source>Settings</source>
        <translation>Agordoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="24"/>
        <source>General</source>
        <translation>Ĝenerala</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="480"/>
        <source>Revisions</source>
        <translation>Revizioj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="34"/>
        <source>Views</source>
        <translation>Vidoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2761"/>
        <source>Labels</source>
        <translation>Etikedoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2893"/>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2967"/>
        <source>Fullscreen</source>
        <translation>Plenekrane</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="82"/>
        <source>General settings</source>
        <translation>Ĝeneralaj agordoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="98"/>
        <source>Application settings</source>
        <translation>Agordoj pri la progamo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="201"/>
        <source>Loading</source>
        <translation>Ŝargante</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="213"/>
        <source>Automatically load last project on startup</source>
        <translation>Aŭtomate ŝargi la lastan projekton dum lanĉo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="232"/>
        <source>Saving</source>
        <translation>Konservante</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="246"/>
        <source>Automatically save every</source>
        <translation>Aŭtomate konservi po unu fojo en</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="293"/>
        <source>minutes.</source>
        <translation>minutoj.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="329"/>
        <source>If no changes during</source>
        <translation>Se ŝanĝoj ne okazas dum</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="376"/>
        <source>seconds.</source>
        <translation>sekundoj.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="410"/>
        <source>Save on project close</source>
        <translation>Konservi dum fermo de projekto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="426"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If you check this option, your project will be saved as one single file. Easier to copy or backup, but does not allow collaborative editing, or versioning.&lt;br/&gt;If this is unchecked, your project will be saved as a folder containing many small files.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Se vi elektus ĉi tiun opcion, via projekto estus konservita kiel unu sola dosiero, pli facile (sav)kopiebla; sed tio ne permesus kunlaboran redaktadon aŭ versikontroladon.&lt;br/&gt;Se vi ne elektus ĉi tiun opcion, via projekto estus konservita kiel dosierujo enhavanta multajn malgrandajn dosierojn.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="432"/>
        <source>Save to one single file</source>
        <translation>Konservi sur unu solan dosieron</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="490"/>
        <source>Revisions are a way to keep track of modifications. For each text item, it stores any changes you make to the main text, allowing you to see and restoring previous versions.</source>
        <translation>Revizioj estas metodo spuri modifojn. Por ĉiu teksta ero, ĝi konservas iujn ajn ŝanĝojn faritajn al la ĉefteksto, permesante al vi vidi kaj restaŭri antaŭajn versiojn.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="500"/>
        <source>Keep revisions</source>
        <translation>Konservi reviziojn</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="516"/>
        <source>S&amp;mart remove</source>
        <translation>Saĝe &amp;forigi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="531"/>
        <source>Keep:</source>
        <translation>Konservi:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="544"/>
        <source>Smart remove allows you to keep only a certain number of revisions. It is strongly recommended to use it, lest you file will becomes full of thousands of insignificant changes.</source>
        <translation>Saĝa forigado permesas konservi nur kelke da revizioj. Estas rekomendegite uzi ĝin, por ke vi ne konservadu milojn da sensignifaj ŝanĝoj.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="560"/>
        <source>revisions per day for the last month</source>
        <translation>reviziojn por ĉiu tago en la lasta monato</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="601"/>
        <source>revisions per minute for the last 10 minutes</source>
        <translation>reviziojn por ĉiu minuto el la lastaj 10 minutoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="614"/>
        <source>revisions per hour for the last day</source>
        <translation>reviziojn por ĉiu horo en la lasta tago</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="627"/>
        <source>revisions per 10 minutes for the last hour</source>
        <translation>reviziojn por ĉiu minutdeko en la lasta horo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="752"/>
        <source>revisions per week till the end of time</source>
        <translation>reviziojn por ĉiu semajno</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="810"/>
        <source>Views settings</source>
        <translation>Agordoj pri vido</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="828"/>
        <source>Tree</source>
        <translation>Arbo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2015"/>
        <source>Colors</source>
        <translation>Koloroj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1759"/>
        <source>Icon color:</source>
        <translation>Koloro de piktogramo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1965"/>
        <source>Nothing</source>
        <translation>Nenio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1970"/>
        <source>POV</source>
        <translation>Perspektivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1975"/>
        <source>Label</source>
        <translation>Etikedo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1980"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1985"/>
        <source>Compile</source>
        <translation>Elporti</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1807"/>
        <source>Text color:</source>
        <translation>Tekstkoloro:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1855"/>
        <source>Background color:</source>
        <translation>Fonkoloro:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1069"/>
        <source>Folders</source>
        <translation>Dosierujoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1081"/>
        <source>Show ite&amp;m count</source>
        <translation>&amp;Montri nombron de eroj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1190"/>
        <source>Show summary</source>
        <translation>Montri resumon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1133"/>
        <source>&amp;Nothing</source>
        <translation>&amp;Nenio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1152"/>
        <source>Text</source>
        <translation>Teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1252"/>
        <source>Outline</source>
        <translation>Skizo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1444"/>
        <source>Visible columns</source>
        <translation>Videblaj kolumnoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1456"/>
        <source>Goal</source>
        <translation>Celo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1472"/>
        <source>Word count</source>
        <translation>Nombro de vortoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1488"/>
        <source>Percentage</source>
        <translation>Procento</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1568"/>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1599"/>
        <source>Index cards</source>
        <translation>Indekskartoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1744"/>
        <source>Item colors</source>
        <translation>Koloroj de eroj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1903"/>
        <source>Border color:</source>
        <translation>Koloro de rando:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1951"/>
        <source>Corner color:</source>
        <translation>Koloro de angulo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1611"/>
        <source>Background</source>
        <translation>Fono</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3446"/>
        <source>Color:</source>
        <translation>Koloro:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2808"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3188"/>
        <source>Image:</source>
        <translation>Bildo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2001"/>
        <source>Text editor</source>
        <translation>Tekstredaktilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2120"/>
        <source>Font</source>
        <translation>Tiparo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2132"/>
        <source>Family:</source>
        <translation>Familio:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3489"/>
        <source>Size:</source>
        <translation>Grando:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3503"/>
        <source>Misspelled:</source>
        <translation>Ortografia misaĵo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2027"/>
        <source>Background:</source>
        <translation>Fono:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2343"/>
        <source>Paragraphs</source>
        <translation>Alineoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3530"/>
        <source>Line spacing:</source>
        <translation>Spaco inter linioj:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3538"/>
        <source>Single</source>
        <translation>Unuobla</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3543"/>
        <source>1.5 lines</source>
        <translation>1,5-obla</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3548"/>
        <source>Double</source>
        <translation>Duobla</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3553"/>
        <source>Proportional</source>
        <translation>Proporcia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3570"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3586"/>
        <source>Tab width:</source>
        <translation>Tabeliga larĝo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3650"/>
        <source> px</source>
        <translation> bildero(j)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3672"/>
        <source>Indent 1st line</source>
        <translation>Deŝovi la unuan linion</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3615"/>
        <source>Spacing:</source>
        <translation>Spaco:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3014"/>
        <source>New</source>
        <translation>Nova</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3028"/>
        <source>Edit</source>
        <translation>Redakti</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3038"/>
        <source>Delete</source>
        <translation>Forigi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3082"/>
        <source>Theme name:</source>
        <translation>Nomo de etoso:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3098"/>
        <source>Apply</source>
        <translation>Efektivigi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3111"/>
        <source>Cancel</source>
        <translation>Nuligi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3141"/>
        <source>Window Background</source>
        <translation>Fenestra fono</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3146"/>
        <source>Text Background</source>
        <translation>Teksta fono</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3151"/>
        <source>Text Options</source>
        <translation>Opcioj pri teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3156"/>
        <source>Paragraph Options</source>
        <translation>Opcioj pri alineo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3198"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3206"/>
        <source>No Image</source>
        <translation>Sen bildo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3211"/>
        <source>Tiled</source>
        <translation>Kahelita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3216"/>
        <source>Centered</source>
        <translation>Centrita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3315"/>
        <source>Stretched</source>
        <translation>Streĉita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3226"/>
        <source>Scaled</source>
        <translation>Skale aligrandigita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3231"/>
        <source>Zoomed</source>
        <translation>Zomita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3266"/>
        <source>Opacity:</source>
        <translation>Opakeco:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3292"/>
        <source>Position:</source>
        <translation>Pozicio:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3680"/>
        <source>Left</source>
        <translation>Maldekstra</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3689"/>
        <source>Center</source>
        <translation>Centra</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3698"/>
        <source>Right</source>
        <translation>Dekstra</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3323"/>
        <source>Width:</source>
        <translation>Larĝo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3374"/>
        <source>Corner radius:</source>
        <translation>Angulradiuso:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3381"/>
        <source>Margins:</source>
        <translation>Marĝenoj:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3410"/>
        <source>Padding:</source>
        <translation>Ena marĝeno:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3466"/>
        <source>Font:</source>
        <translation>Tiparo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1703"/>
        <source>Style</source>
        <translation>Stilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2620"/>
        <source>Cursor</source>
        <translation>Kursoro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2632"/>
        <source>Use block insertion of</source>
        <translation>Bloka kursoro de</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2355"/>
        <source>Alignment:</source>
        <translation>Rektigi:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3707"/>
        <source>Justify</source>
        <translation>Ambaŭrande</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3719"/>
        <source>Alignment</source>
        <translation>Rektigo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1020"/>
        <source>Icon Size</source>
        <translation>Grando de piktogramo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1032"/>
        <source>TextLabel</source>
        <translation>Teksta etikedo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2667"/>
        <source>Disable blinking</source>
        <translation>Malŝalti blinkadon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2234"/>
        <source>Text area</source>
        <translation>Tekstareo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2246"/>
        <source>Max width</source>
        <translation>Maksimuma larĝo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2278"/>
        <source>Left/Right margins:</source>
        <translation>Maldekstra/dekstra marĝenoj:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2307"/>
        <source>Top/Bottom margins:</source>
        <translation>Supra/malsupra marĝenoj:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1107"/>
        <source>S&amp;how progress</source>
        <translation>Montri &amp;progreson</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1120"/>
        <source>Show summar&amp;y</source>
        <translation>Montri r&amp;esumon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1177"/>
        <source>Show p&amp;rogress</source>
        <translation>Montri p&amp;rogreson</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1715"/>
        <source>Old st&amp;yle</source>
        <translation>Malnovst&amp;ila</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2059"/>
        <source>Transparent</source>
        <translation>Travidebla</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2104"/>
        <source>Restore defaults</source>
        <translation>Ŝanĝi al la implicitaj valoroj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="113"/>
        <source>Style:</source>
        <translation>Stilo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="136"/>
        <source>Language:</source>
        <translation>Lingvo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="159"/>
        <source>Font size:</source>
        <translation>Tipargrando:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="182"/>
        <source>Restarting Manuskript ensures all settings take effect.</source>
        <translation>Relanĉado de Manuskript certigos, ke ĉiuj agordoj estos efektivaj.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1094"/>
        <source>Show &amp;word count</source>
        <translation>&amp;Montri la nombron de vortoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1164"/>
        <source>&amp;Show word count</source>
        <translation>&amp;Montri la nombron de vortoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1728"/>
        <source>&amp;New style</source>
        <translation>&amp;Nova stilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2680"/>
        <source>Typewriter mode</source>
        <translation>Skribmaŝina reĝimo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2693"/>
        <source>Focus mode</source>
        <translation>Fokusiga reĝimo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2707"/>
        <source>None</source>
        <translation>Nenio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2712"/>
        <source>Sentence</source>
        <translation>Frazo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2717"/>
        <source>Line</source>
        <translation>Linio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2722"/>
        <source>Paragraph</source>
        <translation>Alineo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="775"/>
        <source>&lt;p&gt;&lt;b&gt;The Revisions feature has been at the source of many reported issues. In this version of Manuskript it has been turned off by default for new projects in order to provide the best experience.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Why aren't these issues fixed already? &lt;a href="https://www.theologeek.ch/manuskript/contribute/"&gt;We need your help to make Manuskript better!&lt;/a&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;La funkcio Revizioj estas la kaŭzo de multaj raportitaj cimoj. En ĉi tiu versio de Manuskript, ĝi estis malŝaltita implicite por novaj projektoj por la plej bona sperto.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Kial ĉi tiuj problemoj ne estas jam riparitaj? &lt;a href="https://www.theologeek.ch/manuskript/contribute/"&gt;Ni bezonas vian helpon por plibonigi Manuskript!&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>SpellAction</name>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="458"/>
        <source>Spelling Suggestions</source>
        <translation>Literumilaj sugestoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="466"/>
        <source>&amp;Add to dictionary</source>
        <translation>Enmeti en vort&amp;aron</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="482"/>
        <source>&amp;Remove from custom dictionary</source>
        <translation>&amp; Forigi el propra vortaro</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../manuskript/ui/about_ui.ui" line="17"/>
        <source>About Manuskript</source>
        <translation>Pri Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/about_ui.ui" line="50"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
</context>
<context>
    <name>aboutDialog</name>
    <message>
        <location filename="../manuskript/ui/about.py" line="28"/>
        <source>Version</source>
        <translation>Versio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/about.py" line="41"/>
        <source>Software Versions in Use:</source>
        <translation>Uzataj versioj de programoj:</translation>
    </message>
</context>
<context>
    <name>abstractModel</name>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="185"/>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="187"/>
        <source>POV</source>
        <translation>Perspektivo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="189"/>
        <source>Label</source>
        <translation>Etikedo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="191"/>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="193"/>
        <source>Compile</source>
        <translation>Elporti</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="195"/>
        <source>Word count</source>
        <translation>Nombro de vortoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="197"/>
        <source>Goal</source>
        <translation>Celo</translation>
    </message>
</context>
<context>
    <name>basicItemView</name>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="38"/>
        <source>POV:</source>
        <translation>Perspektivo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="55"/>
        <source>Goal:</source>
        <translation>Celo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="80"/>
        <source>Word count</source>
        <translation>Nombro de vortoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="92"/>
        <source>One line summary</source>
        <translation>Unulinia resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="99"/>
        <source>Few sentences summary:</source>
        <translation>Kelkfraza resumo:</translation>
    </message>
</context>
<context>
    <name>characterModel</name>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="168"/>
        <source>New character</source>
        <translation>Nova rolulo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="192"/>
        <source>Name</source>
        <translation>Nomo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="194"/>
        <source>Value</source>
        <translation>Valoro</translation>
    </message>
</context>
<context>
    <name>characterTreeView</name>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="90"/>
        <source>Main</source>
        <translation>Ĉefa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="90"/>
        <source>Secondary</source>
        <translation>Malpli grava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="90"/>
        <source>Minor</source>
        <translation>Malgrava</translation>
    </message>
</context>
<context>
    <name>cheatSheet</name>
    <message>
        <location filename="../manuskript/ui/cheatSheet_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet_ui.ui" line="46"/>
        <source>Filter (type the name of anything in your project)</source>
        <translation>Filtri (tajpu la nomon de io ajn en via projekto)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Minor</source>
        <translation>Malgrava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Secondary</source>
        <translation>Malpli grava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Main</source>
        <translation>Ĉefa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="91"/>
        <source>Characters</source>
        <translation>Roluloj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="104"/>
        <source>Texts</source>
        <translation>Tekstoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="116"/>
        <source>Plots</source>
        <translation>Intrigoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="120"/>
        <source>World</source>
        <translation>Mondo</translation>
    </message>
</context>
<context>
    <name>cmbOutlineCharacterChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="34"/>
        <source>None</source>
        <translation>Nenio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Main</source>
        <translation>Ĉefa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Secondary</source>
        <translation>Malpli grava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Minor</source>
        <translation>Malgrava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="136"/>
        <source>Various</source>
        <translation>Diversaj</translation>
    </message>
</context>
<context>
    <name>cmbOutlineLabelChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineLabelChoser.py" line="113"/>
        <source>Various</source>
        <translation>Diversaj</translation>
    </message>
</context>
<context>
    <name>cmbOutlineStatusChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineStatusChoser.py" line="112"/>
        <source>Various</source>
        <translation>Diversaj</translation>
    </message>
</context>
<context>
    <name>collapsibleDockWidgets</name>
    <message>
        <location filename="../manuskript/ui/collapsibleDockWidgets.py" line="26"/>
        <source>Dock Widgets Toolbar</source>
        <translation>Ilobreto de endokigeblaĵoj</translation>
    </message>
</context>
<context>
    <name>completer</name>
    <message>
        <location filename="../manuskript/ui/editors/completer_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
</context>
<context>
    <name>corkDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/corkDelegate.py" line="62"/>
        <source>One line summary</source>
        <translation>Unulinia resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/corkDelegate.py" line="92"/>
        <source>Full summary</source>
        <translation>Plena resumo</translation>
    </message>
</context>
<context>
    <name>editorWidget_ui</name>
    <message>
        <location filename="../manuskript/ui/editors/editorWidget_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
</context>
<context>
    <name>exporter</name>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="65"/>
        <source>Export</source>
        <translation>Elporti</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="22"/>
        <source>Export to:</source>
        <translation>Elporti al:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="32"/>
        <source>Manage exporters</source>
        <translation>Administri elportilojn</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="103"/>
        <source>Preview</source>
        <translation>Antaŭrigardi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="81"/>
        <source>Settings</source>
        <translation>Agordoj</translation>
    </message>
</context>
<context>
    <name>exporterDialog</name>
    <message>
        <location filename="../manuskript/ui/exporters/exporter.py" line="64"/>
        <source>{} (not implemented yet)</source>
        <translation>{} (ankoraŭ ne efektiva)</translation>
    </message>
</context>
<context>
    <name>exporterSettings</name>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="50"/>
        <source>Content</source>
        <translation>Enhavo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="56"/>
        <source>Decide here what will be included in the final export.</source>
        <translation>Ĉi tie decidu tion, kio inkluziviĝos en la neta elportaĵo.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="85"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="90"/>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="326"/>
        <source>Text</source>
        <translation>Teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="118"/>
        <source>I need more granularity</source>
        <translation>Mi bezonas pli da opcioj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="127"/>
        <source>Fi&amp;lters</source>
        <translation>Fi&amp;ltriloj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="142"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filters what items will be included in the final export.&lt;br/&gt;&lt;span style=" color:#773333;"&gt;(Not fully implemented yet.)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtras la erojn inkluzivotaj en la neta elportaĵo.&lt;br/&gt;&lt;span style=" color:#773333;"&gt;(Ankoraŭ ne plene efektivigita.)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="149"/>
        <source>Ignore compile status (include all items)</source>
        <translation>Ignori elportitecon (inkluzivi ĉion)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="156"/>
        <source>Subitems of:</source>
        <translation>Suberoj de:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="170"/>
        <source>Labels</source>
        <translation>Etikedoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="177"/>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="229"/>
        <source>Separations</source>
        <translation>Apartigiloj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="241"/>
        <source>Between folders:</source>
        <translation>Inter dosierujoj:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="86"/>
        <source>Empty line</source>
        <translation>Malplena linio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="105"/>
        <source>Custom</source>
        <translation>Propra</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="367"/>
        <source>Between texts:</source>
        <translation>Inter tekstoj:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="493"/>
        <source>Between folder and text:</source>
        <translation>Inter dosierujo kaj teksto:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="619"/>
        <source>Between text and folder:</source>
        <translation>Inter teksto kaj dosierujo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="764"/>
        <source>Transformations</source>
        <translation>Transformado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="773"/>
        <source>Typographic replacements:</source>
        <translation>Tipografiaj anstataŭigoj:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="802"/>
        <source>Replace double quotes (") with:</source>
        <translation>Anstataŭigi Askiajn duoblajn citilojn (") per:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="911"/>
        <source>Replace single quotes (') with:</source>
        <translation>Anstataŭigi Askiajn unuoblajn citilojn (') per:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1020"/>
        <source>Remove multiple spaces</source>
        <translation>Forigi pluroblajn spacetojn</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1030"/>
        <source>Custom replacements:</source>
        <translation>Propraj anstataŭigoj:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1049"/>
        <source>Enabled</source>
        <translation>Ŝaltita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1054"/>
        <source>Replace</source>
        <translation>Anstataŭigi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1059"/>
        <source>With</source>
        <translation>per</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1064"/>
        <source>RegExp</source>
        <translation>Regula esprimo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1067"/>
        <source>If checked, uses regular expression for replacement. If unchecked, replaced as plain text.</source>
        <translation>Se markita, uzi regulan esprimon por anstataŭigo. Se ne, anstataŭigi kiel simplan tekston.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1151"/>
        <source>Preview</source>
        <translation>Antaŭrigardo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1157"/>
        <source>Font</source>
        <translation>Tiparo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1163"/>
        <source>Font:</source>
        <translation>Tiparo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1173"/>
        <source>Font size:</source>
        <translation>Tipargrando:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="320"/>
        <source>Folder</source>
        <translation>Dosierujo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="343"/>
        <source>{}Level {} folder</source>
        <translation>{}Dosierujo de nivelo {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="346"/>
        <source>{}Level {} text</source>
        <translation>{}Teksto de nivelo {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="788"/>
        <source>Replace ... with â¦</source>
        <translation>Anstataŭigi tri punktojn (...) per tripunkto (…)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="795"/>
        <source>Replace --- with â</source>
        <translation>Anstataŭigi tri dividstrekojn (---) per haltostreko (—)</translation>
    </message>
</context>
<context>
    <name>exportersManager</name>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="81"/>
        <source>Installed</source>
        <translation>Instalita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="87"/>
        <source>Custom</source>
        <translation>Propra</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="93"/>
        <source>Not found</source>
        <translation>Ne trovita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="96"/>
        <source>{} not found. Install it, or set path manually.</source>
        <translation>{} ne troviĝis. Instalu ĝin aŭ agordu dosierindikon permane.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="124"/>
        <source>&lt;b&gt;Status:&lt;/b&gt; uninstalled.</source>
        <translation>&lt;b&gt;Stato:&lt;/b&gt; malinstalita.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="126"/>
        <source>&lt;b&gt;Requires:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Postulas:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="133"/>
        <source>Set {} executable path.</source>
        <translation>Agordi lokon de la ruleblaĵo «{}».</translation>
    </message>
</context>
<context>
    <name>frequencyAnalyzer</name>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="70"/>
        <source>Phrases</source>
        <translation>Frazelementoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="108"/>
        <source>Frequency</source>
        <translation>Ofteco</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="108"/>
        <source>Word</source>
        <translation>Vorto</translation>
    </message>
</context>
<context>
    <name>fullScreenEditor</name>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="129"/>
        <source>Theme:</source>
        <translation>Etoso:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="356"/>
        <source>{} words / {}</source>
        <translation>{} vortoj / {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="360"/>
        <source>{} words</source>
        <translation>{} vortoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="149"/>
        <source>Spellcheck</source>
        <translation>Literumilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="150"/>
        <source>Navigation</source>
        <translation>Navigado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="151"/>
        <source>New Text</source>
        <translation>Nova teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="152"/>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="153"/>
        <source>Title: Show Full Path</source>
        <translation>Titolo: montri plenan dosierindikon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="155"/>
        <source>Theme selector</source>
        <translation>Elektilo de etoso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="156"/>
        <source>Word count</source>
        <translation>Nombro de vortoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="157"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="158"/>
        <source>Progress: Auto Show/Hide</source>
        <translation>Progreso: aŭtomate (mal)kaŝi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="159"/>
        <source>Clock</source>
        <translation>Horloĝo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="160"/>
        <source>Clock: Show Seconds</source>
        <translation>Horloĝo: montri sekundojn</translation>
    </message>
</context>
<context>
    <name>generalSettings</name>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="41"/>
        <source>General</source>
        <translation>Ĝenerala</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="55"/>
        <source>Split scenes at:</source>
        <translation>Dividi scenojn ĉe:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="65"/>
        <source>\n---\n</source>
        <translation>\n---\n</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="72"/>
        <source>Trim long titles (&gt; 32 chars)</source>
        <translation>Mallongigi longajn titolojn (pli longajn ol 32 skribsignojn)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="86"/>
        <source>Import under:</source>
        <translation>Enporti sub:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="93"/>
        <source>Import in a top-level folder</source>
        <translation>Enporti en supranivelan dosierujon</translation>
    </message>
</context>
<context>
    <name>helpLabel</name>
    <message>
        <location filename="../manuskript/ui/helpLabel.py" line="12"/>
        <source>If you don't wanna see me, you can hide me in Help menu.</source>
        <translation>Se vi ne volas vidi min, vi povas kaŝi min per la menuo «Helpo».</translation>
    </message>
</context>
<context>
    <name>importer</name>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="119"/>
        <source>Import</source>
        <translation>Enporti</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="22"/>
        <source>Format:</source>
        <translation>Dosierformo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="45"/>
        <source>Choose file</source>
        <translation>Elekti dosieron</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="75"/>
        <source>Clear file</source>
        <translation>Malelekti dosieron</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="160"/>
        <source>Preview</source>
        <translation>Antaŭrigardi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="138"/>
        <source>Settings</source>
        <translation>Agordoj</translation>
    </message>
</context>
<context>
    <name>lastAccessedDirectoryInfo</name>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="60"/>
        <source>Last accessed directory "{}" loaded.</source>
        <translation>Ŝargiĝis la laste uzita dosierujo «{}».</translation>
    </message>
</context>
<context>
    <name>lineEditView</name>
    <message>
        <location filename="../manuskript/ui/views/lineEditView.py" line="114"/>
        <source>Various</source>
        <translation>Diversaj</translation>
    </message>
</context>
<context>
    <name>locker</name>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="26"/>
        <source>Lock screen:</source>
        <translation>Ŝlosekrano:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="33"/>
        <source>Word target</source>
        <translation>Celata nombro de vortoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="40"/>
        <source>Time target</source>
        <translation>Celata daŭro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="47"/>
        <source> words</source>
        <translation> vortoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="63"/>
        <source> minutes</source>
        <translation> minutoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="79"/>
        <source>Lock !</source>
        <translation>Ŝlosi!</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="94"/>
        <source>~{} h.</source>
        <translation>~{} h</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="96"/>
        <source>~{} mn.</source>
        <translation>~{} min</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="100"/>
        <source>{}:{}</source>
        <translation>{}:{}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="102"/>
        <source>{} s.</source>
        <translation>{} s</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="104"/>
        <source>{} remaining</source>
        <translation>{} restas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="109"/>
        <source>{} words remaining</source>
        <translation>{} vortoj restas</translation>
    </message>
</context>
<context>
    <name>mainEditor</name>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="67"/>
        <source>Text</source>
        <translation>Teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="83"/>
        <source>Index cards</source>
        <translation>Indekskartoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="102"/>
        <source>Outline</source>
        <translation>Skizo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="198"/>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="47"/>
        <source>Go to parent item</source>
        <translation>Iri al patra ero</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="57"/>
        <source>Alt+Up</source>
        <translation>Alt+Up</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="243"/>
        <source>Root</source>
        <translation>Radiko</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="322"/>
        <source>{} words / {} </source>
        <translation>{} vortoj / {} </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="327"/>
        <source>{} words </source>
        <translation>{} vortoj </translation>
    </message>
</context>
<context>
    <name>markdownSettings</name>
    <message>
        <location filename="../manuskript/exporter/manuskript/markdown.py" line="58"/>
        <source>Markdown</source>
        <translation>Markdown</translation>
    </message>
</context>
<context>
    <name>metadataView</name>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="41"/>
        <source>Properties</source>
        <translation>Atributoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="81"/>
        <source>Summary</source>
        <translation>Resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="114"/>
        <source>One line summary</source>
        <translation>Unulinia resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="140"/>
        <source>Full summary</source>
        <translation>Plena resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="180"/>
        <source>Notes / References</source>
        <translation>Notoj / referencoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="190"/>
        <source>Revisions</source>
        <translation>Revizioj</translation>
    </message>
</context>
<context>
    <name>myPanel</name>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="591"/>
        <source>Auto-hide</source>
        <translation>Aŭtomate kaŝi</translation>
    </message>
</context>
<context>
    <name>outlineBasics</name>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="134"/>
        <source>Set POV</source>
        <translation>Agordi perspektivon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="136"/>
        <source>None</source>
        <translation>Nenio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="163"/>
        <source>Set Status</source>
        <translation>Agordi staton</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="179"/>
        <source>Set Label</source>
        <translation>Fiksi etikedon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="283"/>
        <source>New</source>
        <translation>Nova</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="142"/>
        <source>Main</source>
        <translation>Ĉefa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="143"/>
        <source>Secondary</source>
        <translation>Malpli grava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="144"/>
        <source>Minor</source>
        <translation>Malgrava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="197"/>
        <source>Set Custom Icon</source>
        <translation>Agordi propran piktogramon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="198"/>
        <source>Restore to default</source>
        <translation>Ŝanĝi al la implicita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="61"/>
        <source>Root</source>
        <translation>Radiko</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="75"/>
        <source>Open {} items in new tabs</source>
        <translation>Malfermi {} erojn en novaj langetoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="78"/>
        <source>Open {} in a new tab</source>
        <translation>Malfermi {} en nova langeto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="313"/>
        <source>About to remove</source>
        <translation>Forigonta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="313"/>
        <source>&lt;p&gt;&lt;b&gt;You're about to delete {} item(s).&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Are you sure?&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Vi estas forigonta {} ero(j)n.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Ĉu vi certas?&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="421"/>
        <source>Select at least two items. Folders are ignored.</source>
        <translation>Elektu almenaŭ du erojn. Dosierujoj estas ignorataj.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="430"/>
        <source>All items must be on the same level (share the same parent).</source>
        <translation>Ĉiuj eroj devas esti samnivelaj (idoj de unu patro).</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="88"/>
        <source>New &amp;Folder</source>
        <translation>Nova &amp;dosierujo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="94"/>
        <source>New &amp;Text</source>
        <translation>Nova &amp;teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="108"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopii</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="103"/>
        <source>C&amp;ut</source>
        <translation>&amp;Eltondi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="113"/>
        <source>&amp;Paste</source>
        <translation>&amp;Alglui</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="125"/>
        <source>&amp;Rename</source>
        <translation>Ŝanĝi &amp;nomon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="119"/>
        <source>&amp;Delete</source>
        <translation>&amp;Forigi</translation>
    </message>
</context>
<context>
    <name>outlineCharacterDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="141"/>
        <source>None</source>
        <translation>Nenio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Main</source>
        <translation>Ĉefa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Secondary</source>
        <translation>Malpli grava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Minor</source>
        <translation>Malgrava</translation>
    </message>
</context>
<context>
    <name>outlineItem</name>
    <message>
        <location filename="../manuskript/models/outlineItem.py" line="234"/>
        <source>{} words / {} ({})</source>
        <translation>{} vortoj / {} ({})</translation>
    </message>
    <message>
        <location filename="../manuskript/models/outlineItem.py" line="239"/>
        <source>{} words</source>
        <translation>{} vortoj</translation>
    </message>
</context>
<context>
    <name>pandocSettings</name>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="167"/>
        <source>General</source>
        <translation>Ĝenerala</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="181"/>
        <source>Table of Content</source>
        <translation>Enhavtabelo</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="186"/>
        <source>Custom settings for {}</source>
        <translation>Propraj agordoj pri {}</translation>
    </message>
</context>
<context>
    <name>persosProxyModel</name>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="16"/>
        <source>Main</source>
        <translation>Ĉefa</translation>
    </message>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="17"/>
        <source>Secondary</source>
        <translation>Malpli grava</translation>
    </message>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="18"/>
        <source>Minors</source>
        <translation>Malgravaj</translation>
    </message>
</context>
<context>
    <name>plotDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>General</source>
        <translation>Ĝenerala</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Promise</source>
        <translation>Promeso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Problem</source>
        <translation>Problemo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Resolution</source>
        <translation>Solvo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Try / Fail</source>
        <translation>Provi / malsukcesi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>No and</source>
        <translation>Ne, kaj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Yes but</source>
        <translation>Jes, sed</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Freytag's pyramid</source>
        <translation>Piramido de Freytag</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Exposition</source>
        <translation>Klarigo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Rising action</source>
        <translation>Kreskanta agado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Climax</source>
        <translation>Klimakso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Falling action</source>
        <translation>Malkreskanta agado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Three acts</source>
        <translation>Tri aktoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Setup</source>
        <translation>1. Komenco</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Inciting event</source>
        <translation>1. Transpaŝo de la sojlo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Turning point</source>
        <translation>1. Turnopunkto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Choice</source>
        <translation>2. Elekto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Reversal</source>
        <translation>2. Renverso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Disaster</source>
        <translation>2. Katastrofo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Stand up</source>
        <translation>3. Restariĝo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Climax</source>
        <translation>3. Klimakso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Ending</source>
        <translation>3. Fino</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Hero's journey</source>
        <translation>Vojaĝo de la heroo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Ordinary world</source>
        <translation>Ordinara mondo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Call to adventure</source>
        <translation>Voko al aventuro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Refusal of the call</source>
        <translation>Rifuzo de la alvoko</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Meeting with mentor</source>
        <translation>Renkontiĝo kun mentoro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Tests</source>
        <translation>Ekzamenoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Approach</source>
        <translation>Alproksimiĝo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Abyss</source>
        <translation>Abismo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Reward / Revelation</source>
        <translation>Rekompenco / rivelo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Transformation</source>
        <translation>Transformiĝo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Atonement</source>
        <translation>Rebonigo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Return</source>
        <translation>Reveno</translation>
    </message>
</context>
<context>
    <name>plotModel</name>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="108"/>
        <source>New plot</source>
        <translation>Nova intrigo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="140"/>
        <source>Name</source>
        <translation>Nomo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="142"/>
        <source>Meta</source>
        <translation>Metainformoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="177"/>
        <source>New step</source>
        <translation>Nova paŝo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="246"/>
        <source>Main</source>
        <translation>Ĉefa</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="246"/>
        <source>Secondary</source>
        <translation>Malpli grava</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="246"/>
        <source>Minor</source>
        <translation>Malgrava</translation>
    </message>
</context>
<context>
    <name>plotTreeView</name>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="128"/>
        <source>Main</source>
        <translation>Ĉefa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="128"/>
        <source>Secondary</source>
        <translation>Malpli grava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="128"/>
        <source>Minor</source>
        <translation>Malgrava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="189"/>
        <source>**Plot:** {}</source>
        <translation>**Intrigo:** {}</translation>
    </message>
</context>
<context>
    <name>plotsProxyModel</name>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="22"/>
        <source>Main</source>
        <translation>Ĉefa</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="23"/>
        <source>Secondary</source>
        <translation>Malpli grava</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="24"/>
        <source>Minors</source>
        <translation>Malgravaj</translation>
    </message>
</context>
<context>
    <name>propertiesView</name>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="195"/>
        <source>POV</source>
        <translation>Perspektivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="215"/>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="235"/>
        <source>Label</source>
        <translation>Etikedo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="255"/>
        <source>Compile</source>
        <translation>Elporti</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="269"/>
        <source>Goal</source>
        <translation>Celo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="291"/>
        <source>Word count</source>
        <translation>Nombro de vortoj</translation>
    </message>
</context>
<context>
    <name>references</name>
    <message>
        <location filename="../manuskript/models/references.py" line="504"/>
        <source>Not a reference: {}.</source>
        <translation>Ne estas referenco: {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="402"/>
        <source>Unknown reference: {}.</source>
        <translation>Nekonata referenco: {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="103"/>
        <source>Path:</source>
        <translation>Dosierindiko:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="104"/>
        <source>Stats:</source>
        <translation>Statistikoj:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="105"/>
        <source>POV:</source>
        <translation>Perspektivo:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="106"/>
        <source>Status:</source>
        <translation>Stato:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="107"/>
        <source>Label:</source>
        <translation>Etikedo:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="108"/>
        <source>Short summary:</source>
        <translation>Mallonga resumo:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="109"/>
        <source>Long summary:</source>
        <translation>Longa resumo:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="110"/>
        <source>Notes:</source>
        <translation>Notoj:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="201"/>
        <source>Basic info</source>
        <translation>Bazaj informoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="202"/>
        <source>Detailed info</source>
        <translation>Detaloj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="203"/>
        <source>POV of:</source>
        <translation>Perspektivo de:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="367"/>
        <source>Go to {}.</source>
        <translation>Iri al {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="362"/>
        <source>Description</source>
        <translation>Priskribo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="282"/>
        <source>Result</source>
        <translation>Rezulto</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="283"/>
        <source>Characters</source>
        <translation>Roluloj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="284"/>
        <source>Resolution steps</source>
        <translation>Solvopaŝoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="363"/>
        <source>Passion</source>
        <translation>Pasio</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="364"/>
        <source>Conflict</source>
        <translation>Konflikto</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="501"/>
        <source>&lt;b&gt;Unknown reference:&lt;/b&gt; {}.</source>
        <translation>&lt;b&gt;Nekonata referenco:&lt;/b&gt; {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="509"/>
        <source>Folder: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Dosierujo: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="511"/>
        <source>Text: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Teksto: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="516"/>
        <source>Character: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Rolulo: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="519"/>
        <source>Plot: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Intrigo: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="522"/>
        <source>World: &lt;b&gt;{name}&lt;/b&gt;{path}</source>
        <translation>Monto: &lt;b&gt;{name}&lt;/b&gt;{path}</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="596"/>
        <source>Referenced in:</source>
        <translation>Referencita en:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="212"/>
        <source>Motivation</source>
        <translation>Instigo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="213"/>
        <source>Goal</source>
        <translation>Celo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="215"/>
        <source>Epiphany</source>
        <translation>Ekscio</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="216"/>
        <source>Short summary</source>
        <translation>Mallonga resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="217"/>
        <source>Longer summary</source>
        <translation>Longa resumo</translation>
    </message>
</context>
<context>
    <name>revisions</name>
    <message>
        <location filename="../manuskript/ui/revisions_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions_ui.ui" line="107"/>
        <source>Options</source>
        <translation>Opcioj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="259"/>
        <source>Restore</source>
        <translation>Restaŭri</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="260"/>
        <source>Delete</source>
        <translation>Forigi</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="45"/>
        <source>Show modifications</source>
        <translation>Montri modifojn</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="52"/>
        <source>Show ancient version</source>
        <translation>Montri malnovegan version</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="60"/>
        <source>Show spaces</source>
        <translation>Montri spacetojn</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="66"/>
        <source>Show modifications only</source>
        <translation>Montri nur modifojn</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="110"/>
        <source>{} years ago</source>
        <translation>antaŭ {} jaroj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="112"/>
        <source>{} months ago</source>
        <translation>antaŭ {} monatoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="114"/>
        <source>{} days ago</source>
        <translation>antaŭ {} tagoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="116"/>
        <source>1 day ago</source>
        <translation>antaŭ 1 tago</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="118"/>
        <source>{} hours ago</source>
        <translation>antaŭ {} horoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="120"/>
        <source>{} minutes ago</source>
        <translation>antaŭ {} minutoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="122"/>
        <source>{} seconds ago</source>
        <translation>antaŭ {} sekundoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="183"/>
        <source>Line {}:</source>
        <translation>Linio {}:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="263"/>
        <source>Clear all</source>
        <translation>Forviŝi ĉion</translation>
    </message>
</context>
<context>
    <name>search</name>
    <message>
        <location filename="../manuskript/ui/search_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search_ui.ui" line="46"/>
        <source>Search for...</source>
        <translation>Serĉi…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="43"/>
        <source>Search in:</source>
        <translation>Serĉi en:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="47"/>
        <source>All</source>
        <translation>Ĉio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="48"/>
        <source>Title</source>
        <translation>Titolo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="49"/>
        <source>Text</source>
        <translation>Teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="50"/>
        <source>Summary</source>
        <translation>Resumo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="51"/>
        <source>Notes</source>
        <translation>Notoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="52"/>
        <source>POV</source>
        <translation>Perspektivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="53"/>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="54"/>
        <source>Label</source>
        <translation>Etikedo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="64"/>
        <source>Options:</source>
        <translation>Opcioj:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="68"/>
        <source>Case sensitive</source>
        <translation>Usklecdistinga</translation>
    </message>
</context>
<context>
    <name>settingsWindow</name>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="649"/>
        <source>New status</source>
        <translation>Nova stato</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="670"/>
        <source>New label</source>
        <translation>Nova etikedo</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="706"/>
        <source>newtheme</source>
        <translation>nova etoso</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="716"/>
        <source>New theme</source>
        <translation>Nova etoso</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="748"/>
        <source> (read-only)</source>
        <translation> (nurlega)</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="509"/>
        <source>Open Image</source>
        <translation>Malfermi bildon</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="509"/>
        <source>Image files (*.jpg; *.jpeg; *.png)</source>
        <translation>Bildodosieroj (*.jpg; *.jpeg; *.png)</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="525"/>
        <source>Error</source>
        <translation>Eraro</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="522"/>
        <source>Unable to load selected file</source>
        <translation>Ne eblas ŝargi elektitan dosieron</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="525"/>
        <source>Unable to add selected image:
{}</source>
        <translation>Ne eblas enmeti elektitan bildon:
{}</translation>
    </message>
</context>
<context>
    <name>sldImportance</name>
    <message>
        <location filename="../manuskript/ui/views/sldImportance_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance_ui.ui" line="39"/>
        <source>TextLabel</source>
        <translation>Teksta etikedo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="29"/>
        <source>Minor</source>
        <translation>Malgrava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="30"/>
        <source>Secondary</source>
        <translation>Malpli grava</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="31"/>
        <source>Main</source>
        <translation>Ĉefa</translation>
    </message>
</context>
<context>
    <name>splitDialog</name>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="19"/>
        <source>
            &lt;p&gt;Split selected item(s) at the given mark.&lt;/p&gt;

            &lt;p&gt;If one of the selected item is a folder, it will be applied
            recursively to &lt;i&gt;all&lt;/i&gt; of it's children items.&lt;/p&gt;

            &lt;p&gt;The split mark can contain following escape sequences:
                &lt;ul&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\n&lt;/code&gt;&lt;/b&gt;: line break&lt;/li&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\t&lt;/code&gt;&lt;/b&gt;: tab&lt;/li&gt;
                &lt;/ul&gt;
            &lt;/p&gt;

            &lt;p&gt;&lt;b&gt;Mark:&lt;/b&gt;&lt;/p&gt;
            </source>
        <translation>
            &lt;p&gt;Dividi elektitajn erojn ĉe la specifita marko.&lt;/p&gt;

            &lt;p&gt;Se unu el la elektitaj eroj estas dosierujo, la divido okazos
            rikure en &lt;i&gt;ĉiuj&lt;/i&gt; idoj.&lt;/p&gt;

            &lt;p&gt;La dividmarko povas enhavi la jenajn fuĝsekvencojn:
                &lt;ul&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\n&lt;/code&gt;&lt;/b&gt;: linifino&lt;/li&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\t&lt;/code&gt;&lt;/b&gt;: tabeligo&lt;/li&gt;
                &lt;/ul&gt;
            &lt;/p&gt;

            &lt;p&gt;&lt;b&gt;Marko:&lt;/b&gt;&lt;/p&gt;
            </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="47"/>
        <source>Split '{}'</source>
        <translation>Dividi «{}»</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="51"/>
        <source>Split items</source>
        <translation>Dividi erojn</translation>
    </message>
</context>
<context>
    <name>storylineView</name>
    <message>
        <location filename="../manuskript/ui/views/storylineView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/storylineView.py" line="36"/>
        <source>Show Plots</source>
        <translation>Montri intrigojn</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/storylineView.py" line="43"/>
        <source>Show Characters</source>
        <translation>Montri rolulojn</translation>
    </message>
</context>
<context>
    <name>tabSplitter</name>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="65"/>
        <source>Open selected items in that view.</source>
        <translation>Malfermi elektitajn erojn en tiu vido.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="156"/>
        <source>Split horizontally</source>
        <translation>Dividi horizontale</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="166"/>
        <source>Close split</source>
        <translation>Fermi dividaĵon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="202"/>
        <source>Split vertically</source>
        <translation>Dividi vertikale</translation>
    </message>
</context>
<context>
    <name>textEditView</name>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="306"/>
        <source>Various</source>
        <translation>Diversaj</translation>
    </message>
</context>
<context>
    <name>textFormat</name>
    <message>
        <location filename="../manuskript/ui/editors/textFormat_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="18"/>
        <source>CTRL+B</source>
        <translation>CTRL+B</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="19"/>
        <source>CTRL+I</source>
        <translation>CTRL+I</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="20"/>
        <source>CTRL+U</source>
        <translation>CTRL+U</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="21"/>
        <source>CTRL+P</source>
        <translation>CTRL+P</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="22"/>
        <source>CTRL+L</source>
        <translation>CTRL+L</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="23"/>
        <source>CTRL+E</source>
        <translation>CTRL+E</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="24"/>
        <source>CTRL+R</source>
        <translation>CTRL+R</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="25"/>
        <source>CTRL+J</source>
        <translation>CTRL+J</translation>
    </message>
</context>
<context>
    <name>treeView</name>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="48"/>
        <source>Expand {}</source>
        <translation>Malkaŝi {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="52"/>
        <source>Collapse {}</source>
        <translation>Kaŝi {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="59"/>
        <source>Expand All</source>
        <translation>Malkaŝi ĉion</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="63"/>
        <source>Collapse All</source>
        <translation>Kaŝi ĉion</translation>
    </message>
</context>
<context>
    <name>welcome</name>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formularo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="50"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="55"/>
        <source>Templates</source>
        <translation>Ŝablonoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="86"/>
        <source>Empty</source>
        <translation>Malplena</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="224"/>
        <source>Novel</source>
        <translation>Romano</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="229"/>
        <source>Novella</source>
        <translation>Romaneto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="234"/>
        <source>Short Story</source>
        <translation>Novelo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="246"/>
        <source>Research paper</source>
        <translation>Scienca artikolo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="417"/>
        <source>Demo projects</source>
        <translation>Ekzemplaj projektoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="177"/>
        <source>Add level</source>
        <translation>Aldoni nivelon</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="190"/>
        <source>Add word count</source>
        <translation>Enmeti nombron de vortoj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="213"/>
        <source>Next time, automatically open last project</source>
        <translation>Poste, aŭtomate malfermi la lastan projekton</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="238"/>
        <source>Open...</source>
        <translation>Malfermi…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="248"/>
        <source>Recent</source>
        <translation>Lastatempaj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="258"/>
        <source>Create</source>
        <translation>Krei</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="157"/>
        <source>Open project</source>
        <translation>Malfermi projekton</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="157"/>
        <source>Manuskript project (*.msk);;All files (*)</source>
        <translation>Manuskript-projekto (*.msk);;Ĉiuj dosieroj (*)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="171"/>
        <source>Save project as...</source>
        <translation>Konservi projekton kiel…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="195"/>
        <source>Manuskript project (*.msk)</source>
        <translation>Manuskript-projekto (*.msk)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="187"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="195"/>
        <source>Create New Project</source>
        <translation>Krei novan projekton</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="207"/>
        <source>Warning</source>
        <translation>Averto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="207"/>
        <source>Overwrite existing project {} ?</source>
        <translation>Ĉu superskribi super ekzistantan projekton {}?</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="223"/>
        <source>Empty fiction</source>
        <translation>Malplena fikcio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="455"/>
        <source>Chapter</source>
        <translation>Ĉapitro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="456"/>
        <source>Scene</source>
        <translation>Sceno</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="238"/>
        <source>Trilogy</source>
        <translation>Trilogio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="238"/>
        <source>Book</source>
        <translation>Libro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="246"/>
        <source>Section</source>
        <translation>Sekcio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="245"/>
        <source>Empty non-fiction</source>
        <translation>Malplena nefikcio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="307"/>
        <source>words each.</source>
        <translation>vortoj.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="310"/>
        <source>of</source>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="334"/>
        <source>Text</source>
        <translation>Teksto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="337"/>
        <source>Something</source>
        <translation>Io</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="383"/>
        <source>&lt;b&gt;Total:&lt;/b&gt; {} words (~ {} pages)</source>
        <translation>&lt;b&gt;Entute:&lt;/b&gt; {} vortoj (~ {} paĝoj)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="404"/>
        <source>Fiction</source>
        <translation>Fikcio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="410"/>
        <source>Non-fiction</source>
        <translation>Nefikcio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="453"/>
        <source>Idea</source>
        <translation>Ideo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="454"/>
        <source>Note</source>
        <translation>Noto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="457"/>
        <source>Research</source>
        <translation>Informokolektado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="465"/>
        <source>TODO</source>
        <translation>FARENDA</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="466"/>
        <source>First draft</source>
        <translation>Unua malneto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="467"/>
        <source>Second draft</source>
        <translation>Dua malneto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="468"/>
        <source>Final</source>
        <translation>Neto</translation>
    </message>
</context>
<context>
    <name>worldModel</name>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="134"/>
        <source>New item</source>
        <translation>Nova ero</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>Fantasy world building</source>
        <translation>Konstruado de fantasta mondo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>Physical</source>
        <translation>Fizika</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>Climate</source>
        <translation>Klimato</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>Topography</source>
        <translation>Topografio</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>Astronomy</source>
        <translation>Astronomio</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>Wild life</source>
        <translation>Faŭno</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>Flora</source>
        <translation>Flaŭro</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>History</source>
        <translation>Historio</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>Races</source>
        <translation>Rasoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>Diseases</source>
        <translation>Malsanoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Cultural</source>
        <translation>Kultura</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Customs</source>
        <translation>Kutimoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Food</source>
        <translation>Manĝo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Languages</source>
        <translation>Lingvoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Education</source>
        <translation>Eduko</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Dresses</source>
        <translation>Vesto</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Science</source>
        <translation>Scienco</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Calendar</source>
        <translation>Kalendaro</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Bodily language</source>
        <translation>Korpolingvo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Ethics</source>
        <translation>Etiko</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Religion</source>
        <translation>Religio</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Government</source>
        <translation>Registaro</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Politics</source>
        <translation>Politiko</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Gender roles</source>
        <translation>Seksroloj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Music and arts</source>
        <translation>Muziko kaj artoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Architecture</source>
        <translation>Arkitekturo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Military</source>
        <translation>Milito</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Technology</source>
        <translation>Tekniko</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Courtship</source>
        <translation>Amindumado</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Demography</source>
        <translation>Demografio</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Transportation</source>
        <translation>Transporto</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="257"/>
        <source>Medicine</source>
        <translation>Medicino</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="280"/>
        <source>Magic system</source>
        <translation>Magisistemo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="280"/>
        <source>Rules</source>
        <translation>Reguloj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="280"/>
        <source>Organization</source>
        <translation>Organizo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="280"/>
        <source>Magical objects</source>
        <translation>Magiaĵoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="280"/>
        <source>Magical places</source>
        <translation>Magiejoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="280"/>
        <source>Magical races</source>
        <translation>Magiuloj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="287"/>
        <source>Important places</source>
        <translation>Gravaj lokoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="288"/>
        <source>Important objects</source>
        <translation>Gravaj objektoj</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="246"/>
        <source>Natural resources</source>
        <translation>Resursoj</translation>
    </message>
</context>
</TS>
