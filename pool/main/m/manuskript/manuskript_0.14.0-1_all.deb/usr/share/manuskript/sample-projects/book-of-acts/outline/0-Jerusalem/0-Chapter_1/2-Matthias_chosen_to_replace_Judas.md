title:          Matthias chosen to replace Judas
ID:             3
type:           md
notes:          {C:2:Philip}
compile:        2


12 Then they returned to Jerusalem from the mountain called Olivet, which is near Jerusalem, a Sabbath day’s journey away. 13 When they had come in, they went up into the upper room where they were staying; that is Peter, John, James, Andrew, Philip, Thomas, Bartholomew, Matthew, James the son of Alphaeus, Simon the Zealot, and Judas the son of James. 14 All these with one accord continued steadfastly in prayer and supplication, along with the women, and Mary the mother of Jesus, and with his brothers.
15 In these days, Peter stood up in the middle of the disciples (and the number of names was about one hundred twenty), and said, 16 “Brothers, it was necessary that this Scripture should be fulfilled, which the Holy Spirit spoke before by the mouth of David concerning Judas, who was guide to those who took Jesus. 17 For he was counted with us, and received his portion in this ministry. 18 Now this man obtained a field with the reward for his wickedness, and falling headlong, his body burst open, and all his intestines gushed out. 19 It became known to everyone who lived in Jerusalem that in their language that field was called ‘Akeldama,’ that is, ‘The field of blood.’ 20 For it is written in the book of Psalms,
‘Let his habitation be made desolate.
Let no one dwell in it;’
and,
‘Let another take his office.’
21 “Of the men therefore who have accompanied us all the time that the Lord Jesus went in and out among us, 22 beginning from the baptism of John, to the day that he was received up from us, of these one must become a witness with us of his resurrection.”
23 They put forward two, Joseph called Barsabbas, who was also called Justus, and Matthias. 24 They prayed and said, “You, Lord, who know the hearts of all men, show which one of these two you have chosen 25 to take part in this ministry and apostleship from which Judas fell away, that he might go to his own place.” 26 They drew lots for them, and the lot fell on Matthias, and he was counted with the eleven apostles. 