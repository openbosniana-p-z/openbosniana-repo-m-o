title:          Philip and the Ethiopian
ID:             36
type:           md
POV:            2
compile:        2


6 But an angel of the Lord spoke to Philip, saying, “Arise, and go toward the south to the way that goes down from Jerusalem to Gaza. This is a desert.”
27 He arose and went; and behold, there was a man of Ethiopia, a eunuch of great authority under Candace, queen of the Ethiopians, who was over all her treasure, who had come to Jerusalem to worship. 28 He was returning and sitting in his chariot, and was reading the prophet Isaiah.
29 The Spirit said to Philip, “Go near, and join yourself to this chariot.”
30 Philip ran to him, and heard him reading Isaiah the prophet, and said, “Do you understand what you are reading?”
31 He said, “How can I, unless someone explains it to me?” He begged Philip to come up and sit with him. 32 Now the passage of the Scripture which he was reading was this,
“He was led as a sheep to the slaughter.
As a lamb before his shearer is silent,
so he doesn’t open his mouth.
33 In his humiliation, his judgment was taken away.
Who will declare His generation?
For his life is taken from the earth.”✡
34 The eunuch answered Philip, “Who is the prophet talking about? About himself, or about someone else?”
35 Philip opened his mouth, and beginning from this Scripture, preached to him about Jesus. 36 As they went on the way, they came to some water, and the eunuch said, “Behold, here is water. What is keeping me from being baptized?”
37  * 38 He commanded the chariot to stand still, and they both went down into the water, both Philip and the eunuch, and he baptized him.
39 When they came up out of the water, the Spirit of the Lord caught Philip away, and the eunuch didn’t see him any more, for he went on his way rejoicing. 40 But Philip was found at Azotus. Passing through, he preached the Good News to all the cities, until he came to Caesarea. 