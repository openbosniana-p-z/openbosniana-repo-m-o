title:          The choosing of seven
ID:             22
type:           md
notes:          {C:2:Philip}
compile:        2


 1 Now in those days, when the number of the disciples was multiplying, a complaint arose from the Hellenists* against the Hebrews, because their widows were neglected in the daily service. 2 The twelve summoned the multitude of the disciples and said, “It is not appropriate for us to forsake the word of God and serve tables. 3 Therefore select from among you, brothers, seven men of good report, full of the Holy Spirit and of wisdom, whom we may appoint over this business. 4 But we will continue steadfastly in prayer and in the ministry of the word.”
5 These words pleased the whole multitude. They chose Stephen, a man full of faith and of the Holy Spirit, Philip, Prochorus, Nicanor, Timon, Parmenas, and Nicolaus, a proselyte of Antioch; 6 whom they set before the apostles. When they had prayed, they laid their hands on them. 7 The word of God increased and the number of the disciples multiplied in Jerusalem exceedingly. A great company of the priests were obedient to the faith. 