<?xml version='1.0' encoding='UTF-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>Export</name>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="18"/>
        <source>Basic HTML output using the Python module 'markdown'.</source>
        <translation>Saída HTML básica usando o módulo Python 'markdown'.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="19"/>
        <source>Python module 'markdown'.</source>
        <translation>Módulo Python 'markdown'.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="54"/>
        <source>Markdown source</source>
        <translation>Fonte em Markdown</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="55"/>
        <source>HTML Source</source>
        <translation>Fonte HTML</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="59"/>
        <source>HTML Output</source>
        <translation>Destino HTML</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/__init__.py" line="15"/>
        <source>Default exporter, provides basic formats used by other exporters.</source>
        <translation>Exportador padrão, fornece formatos básicos usados por outros exportadores.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/markdown.py" line="60"/>
        <source>Preview with highlighter.</source>
        <translation>Visualizar com marcador.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="17"/>
        <source>Plain text</source>
        <translation>Texto simples</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/HTML.py" line="13"/>
        <source>A little known format modestly used. You know, web sites for example.</source>
        <translation>Um formato pouco conhecido usado modestamente. Você sabe, sites, por exemplo.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/PDF.py" line="18"/>
        <source>Needs LaTeX to be installed.</source>
        <translation>Precisa de LaTeX para ser instalado.</translation>
    </message>
    <message>
        <location filename="../manuskript/converters/pandocConverter.py" line="76"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="96"/>
        <source>Standalone document (not just a fragment)</source>
        <translation>Documento autônomo (não apenas um fragmento)</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="99"/>
        <source>Include a table of contents.</source>
        <translation>Incluir um índice.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="102"/>
        <source>Number of sections level to include in TOC: </source>
        <translation>Número de nível de seções a serem incluídas no índice: </translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="106"/>
        <source>Typographically correct output</source>
        <translation>Saída tipograficamente correta</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="109"/>
        <source>Normalize the document (cleaner)</source>
        <translation>Normalizar o documento (mais limpo)</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="111"/>
        <source>Specify the base level for headers: </source>
        <translation>Especificar o nível base para os cabeçalhos: </translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="118"/>
        <source>Use reference-style links instead of inline links</source>
        <translation>Usar links com estilo de referência em vez de links in-line</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="120"/>
        <source>Use ATX-style headers</source>
        <translation>Usar cabeçalhos no estilo ATX</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="122"/>
        <source>Self-contained HTML files, with no dependencies</source>
        <translation>Arquivos HTML independentes, sem dependências</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="124"/>
        <source>Use &lt;q&gt; tags for quotes in HTML</source>
        <translation>Use as tags &lt;q&gt; para marcações em HTML</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="131"/>
        <source>LaTeX engine used to produce the PDF.</source>
        <translation>Mecanismo LaTeX usado para produzir o PDF.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="141"/>
        <source>Paper size:</source>
        <translation>Tamanho do papel:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="144"/>
        <source>Font size:</source>
        <translation>Tamanho da Fonte:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="147"/>
        <source>Class:</source>
        <translation>Classe:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="150"/>
        <source>Line spacing:</source>
        <translation>Espaçamento entre linhas:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/outputFormats.py" line="10"/>
        <source>Books that don't kill trees.</source>
        <translation>Livros que não matam árvores.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/outputFormats.py" line="21"/>
        <source>OpenDocument format. Used by LibreOffice for example.</source>
        <translation>Formato OpenDocument. Usado pelo LibreOffice por exemplo.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/outputFormats.py" line="32"/>
        <source>Microsoft Office (.docx) document.</source>
        <translation>Documento do Microsoft Office (.docx).</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="22"/>
        <source>reStructuredText is a lightweight markup language.</source>
        <translation>reStructuredText é uma linguagem de marcação.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/markdown.py" line="14"/>
        <source>Just like plain text, excepts adds markdown titles.
                          Presupposes that texts are formatted in markdown.</source>
        <translation>Assim como o texto simples, as exceções adicionam títulos de marcação.
                          Pressupõe que os textos são formatados em markdown.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="18"/>
        <source>Simplest export to plain text. Allows you to use your own markup not understood
                  by Manuskript, for example &lt;a href='www.fountain.io'&gt;Fountain&lt;/a&gt;.</source>
        <translation>Exportação simples para texto simples. Permite que você use sua própria marcação não entendida
                  pelo manuskript, por exemplo &lt;a href='www.fountain.io'&gt;Fountain&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/__init__.py" line="22"/>
        <source>&lt;p&gt;A universal document converter. Can be used to convert Markdown to a wide range of other
    formats.&lt;/p&gt;
    &lt;p&gt;Website: &lt;a href="http://www.pandoc.org"&gt;http://pandoc.org/&lt;/a&gt;&lt;/p&gt;
    </source>
        <translation>&lt;p&gt;Um conversor de documentos universal. Pode ser usado para converter Markdown em uma gama de outros formatos.&lt;/p&gt;
    &lt;p&gt;Site: &lt;a href="http://www.pandoc.org"&gt;http://pandoc.org/&lt;/a&gt;&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/PDF.py" line="19"/>
        <source>a valid LaTeX installation. Pandoc recommendations can be found on:
                     &lt;a href="https://pandoc.org/installing.html"&gt;pandoc.org/installing.html&lt;/a&gt;. If you want Unicode support, you need XeLaTeX.</source>
        <translation>uma instalação LaTeX válida. Veja as recomendações sobre pandoc em:
                     &lt;a href="http://pandoc.org/installing.html"&gt;http://pandoc.org/installing.html&lt;/a&gt;. Se você quiser suporte unicode, você precisa do XeLaTeX.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="10"/>
        <source>Export to markdown, using pandoc. Allows more formatting options
    than the basic manuskript exporter.</source>
        <translation>Exportar para markdown, usando pandoc. Permite mais opções de formatação
    do que o exportador básico do manuskript.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="33"/>
        <source>LaTeX is a word processor and document markup language used to create
                                              beautiful documents.</source>
        <translation>O LaTeX é um processador de texto e uma linguagem de marcação de documentos usada para criar documentos.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="45"/>
        <source>The purpose of this format is to provide a way to exchange information
                                              between outliners and Internet services that can be browsed or controlled
                                              through an outliner.</source>
        <translation>O objetivo deste formato é fornecer uma maneira de trocar informações 
entre delineadores e serviços da Internet que podem ser pesquisados 
ou controlados através de um delineador.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="114"/>
        <source>Disable YAML metadata block.
Use that if you get YAML related error.</source>
        <translation>Desativar o bloco de metadados YAML.
Use isso se você receber um erro relacionado ao YAML.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="134"/>
        <source>Convert to ePUB3</source>
        <translation>Converte para ePUB3</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="51"/>
        <source>Could not process regular expression: 
{}</source>
        <translation>Não pode processar expressões regulares: 
{}</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="71"/>
        <source>Choose output fileâ¦</source>
        <translation type="unfinished">Escolha o arquivo de saída</translation>
    </message>
</context>
<context>
    <name>ExportersManager</name>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="14"/>
        <source>Manage Exporters</source>
        <translation>Gerenciar exportadores</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="21"/>
        <source>Manuskript</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="66"/>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="100"/>
        <source>Offers export to</source>
        <translation>Oferece exportação para</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="184"/>
        <source>Status</source>
        <translation>Situação</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="190"/>
        <source>Status:</source>
        <translation>Situação:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="210"/>
        <source>Version:</source>
        <translation>Versão:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="233"/>
        <source>Path:</source>
        <translation>Caminho:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="258"/>
        <source>...</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="273"/>
        <source>{HelpText}</source>
        <translation/>
    </message>
</context>
<context>
    <name>FrequencyAnalyzer</name>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="14"/>
        <source>Frequency Analyzer</source>
        <translation>Analisador de Freqüência</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="24"/>
        <source>Word frequency</source>
        <translation>Freqüência de palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="37"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="49"/>
        <source>Minimum size:</source>
        <translation>Tamanho mínimo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="63"/>
        <source>Exclude words (comma separated):</source>
        <translation>Excluir palavras (separadas por vírgula):</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="156"/>
        <source>Analyze</source>
        <translation>Analisar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="107"/>
        <source>Phrase frequency</source>
        <translation>Frequência de frase</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="115"/>
        <source>Number of words: from</source>
        <translation>Número de palavras: de</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="129"/>
        <source>to</source>
        <translation>para</translation>
    </message>
</context>
<context>
    <name>Import</name>
    <message>
        <location filename="../manuskript/importer/markdownImporter.py" line="175"/>
        <source>Markdown import</source>
        <translation>Importação de Markdown</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/markdownImporter.py" line="179"/>
        <source>&lt;b&gt;Info:&lt;/b&gt; A very simple
                        parser that will go through a markdown document and
                        create items for each titles.&lt;br/&gt;&amp;nbsp;</source>
        <translation>&amp;lt;b&amp;gt;Info:&amp;lt;/b&amp;gt; Um analisador muito simples
                        que irá processa o documento markdown e
                        criar itens para cada título&amp;lt;br/&amp;gt;&amp;nbsp;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="96"/>
        <source>Folder import</source>
        <translation>Importação de pasta</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="100"/>
        <source>&lt;p&gt;&lt;b&gt;Info:&lt;/b&gt; Imports a whole
                        directory structure. Folders are added as folders, and
                        plaintext documents within (you chose which ones by extension)
                        are added as scene.&lt;/p&gt;
                        &lt;p&gt;Only text files are supported (not images, binary or others).&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Info:&lt;/b&gt; Importa toda
                        estrutura do diretório. Pastas são adicionadas as pastas, e
                        e os documentos de textos dentro (você escolhe quais, por extensão)
                        são adicionados como cenas.&lt;/p&gt;
                        &lt;p&gt;Somente arquivos de texto são suportados (imagens, arquivos binários e outros não).&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="107"/>
        <source>Include only those extensions:</source>
        <translation>Inclua apenas essas extensões:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="107"/>
        <source>Comma separated values</source>
        <translation>Valores separados por vírgula</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="112"/>
        <source>Sort items by name</source>
        <translation>Ordenar itens por nome</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="116"/>
        <source>Import folder then files</source>
        <translation>Importar pastas depois arquivos</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/opmlImporter.py" line="64"/>
        <source>OPML Import</source>
        <translation>Importa OPML</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/opmlImporter.py" line="36"/>
        <source>File open failed.</source>
        <translation>Falha na abertura do arquivo.</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/opmlImporter.py" line="64"/>
        <source>This does not appear to be a valid OPML file.</source>
        <translation>Este não parece ser um arquivo OPML válido.</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="57"/>
        <source>Pandoc import</source>
        <translation>Importação Pandoc</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="60"/>
        <source>&lt;b&gt;Info:&lt;/b&gt; Manuskript can
                        import from &lt;b&gt;markdown&lt;/b&gt; or &lt;b&gt;OPML&lt;/b&gt;. Pandoc will
                        convert your document to either (see option below), and
                        then it will be imported in manuskript. One or the other
                        might give better result depending on your document.
                        &lt;br/&gt;&amp;nbsp;</source>
        <translation>&amp;lt;b&amp;gt;Info:&amp;lt;/b&amp;gt; Manuskript pode
                        importar de &amp;lt;b&amp;gt;markdown&amp;lt;/b&amp;gt; ou &amp;lt;b&amp;gt;OPML&amp;lt;/b&amp;gt;. Pandoc pode
                        converter seu documento para qualquer (veja opções abaixo), e
                        então pode ser importado no manuskript. Um ou o outro
                        pode-se trazer melhores resultados dependendo do seu documento.
                        &amp;lt;br/&amp;gt;&amp;nbsp;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="68"/>
        <source>Import using:</source>
        <translation>Importação usando:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="72"/>
        <source>Wrap lines:</source>
        <translation>Linhas cobertas:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="72"/>
        <source>&lt;p&gt;Should pandoc create
                        cosmetic / non-semantic line-breaks?&lt;/p&gt;&lt;p&gt;
                        &lt;b&gt;auto&lt;/b&gt;: wraps at 72 characters.&lt;br&gt;
                        &lt;b&gt;none&lt;/b&gt;: no line wrap.&lt;br&gt;
                        &lt;b&gt;preserve&lt;/b&gt;: tries to preserves line wrap from the
                        original document.&lt;/p&gt;</source>
        <translation>&lt;p&gt;O pandoc pode criar
                        cosmética/ linhas de quebra não semântica?&lt;/p&gt;&lt;p&gt;
                        &lt;b&gt;auto&lt;/b&gt;: quebra de 72 caracteres.&lt;br&gt;
                        &lt;b&gt;nenhum&lt;/b&gt;: sem quebra de linha&lt;br&gt;
                        &lt;b&gt;preservar&lt;/b&gt;: tenta preservar a quebra de linha do
                        documento original.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="55"/>
        <source>Mind Map Import</source>
        <translation>Importação do Mapa Mental</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="55"/>
        <source>This does not appear to be a valid Mind Map file.</source>
        <translation>Isso não parece ser um arquivo de Mapa Mental válido.</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="70"/>
        <source>Mind Map import</source>
        <translation>Importar Mapa Mental</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="73"/>
        <source>Import tip as:</source>
        <translation>Dica de importação como:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="89"/>
        <source>Untitled</source>
        <translation>Sem título</translation>
    </message>
</context>
<context>
    <name>MDEditCompleter</name>
    <message>
        <location filename="../manuskript/ui/views/MDEditCompleter.py" line="73"/>
        <source>Insert reference</source>
        <translation>Inserir referência</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1647"/>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="169"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="179"/>
        <source>Subtitle</source>
        <translation>Legenda</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="189"/>
        <source>Series</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="199"/>
        <source>Volume</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="226"/>
        <source>Genre</source>
        <translation>Gênero</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="236"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="249"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1656"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="277"/>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1442"/>
        <source>Summary</source>
        <translation>Sumário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="322"/>
        <source>Situation:</source>
        <translation>Situação:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1357"/>
        <source>Summary:</source>
        <translation>Sumário:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="345"/>
        <source>One sentence</source>
        <translation>Uma frase</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1455"/>
        <source>One paragraph</source>
        <translation>Um parágrafo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1460"/>
        <source>One page</source>
        <translation>Uma página</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1465"/>
        <source>Full</source>
        <translation>Cheio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="420"/>
        <source>One sentence summary</source>
        <translation>Sumário de uma frase</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="502"/>
        <source>One paragraph summary</source>
        <translation>Sumário de um parágrafo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="540"/>
        <source>Expand each sentence of your one paragraph summary to a paragraph</source>
        <translation>Expandir cada frase do sumário de um parágrafo para um parágrafo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="565"/>
        <source>One page summary</source>
        <translation>Sumário de uma página</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="590"/>
        <source>Full summary</source>
        <translation>Sumário completo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1094"/>
        <source>Next</source>
        <translation>Próximo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="676"/>
        <source>What if...?</source>
        <translation>E se...?</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="688"/>
        <source>Characters</source>
        <translation>Personagens</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="713"/>
        <source>Names</source>
        <translation>Nomes</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1607"/>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1203"/>
        <source>Basic info</source>
        <translation>Informação basica</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1222"/>
        <source>Importance</source>
        <translation>Importância</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="880"/>
        <source>Motivation</source>
        <translation>Motivação</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="890"/>
        <source>Goal</source>
        <translation>Objetivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="900"/>
        <source>Conflict</source>
        <translation>Conflito</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="910"/>
        <source>Epiphany</source>
        <translation>Epifania</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="920"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align="right"&gt;One sentence&lt;br/&gt;summary&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align="right"&gt;Uma sentença&lt;br/&gt;sumário&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="930"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align="right"&gt;One paragraph&lt;br/&gt;summary&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align="right"&gt;Um parágrafo&lt;br/&gt;sumário&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1021"/>
        <source>Notes</source>
        <translation>Notas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1031"/>
        <source>Detailed info</source>
        <translation>Info Detalhada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2041"/>
        <source>Plots</source>
        <translation>Enredos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1212"/>
        <source>Plot</source>
        <translation>Enredo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1229"/>
        <source>Character(s)</source>
        <translation>Personagens</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1666"/>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1243"/>
        <source>Result</source>
        <translation>Resultado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1335"/>
        <source>Resolution steps</source>
        <translation>Etapas de resolução</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2065"/>
        <source>World</source>
        <translation>Mundo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1620"/>
        <source>Populates with empty data</source>
        <translation>Preenche com dados vazios</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1677"/>
        <source>More</source>
        <translation>Mais</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1686"/>
        <source>Source of passion</source>
        <translation>Fonte de paixão</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1696"/>
        <source>Source of conflict</source>
        <translation>Fonte do conflito</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1554"/>
        <source>Outline</source>
        <translation>Esboço</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1874"/>
        <source>Editor</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2005"/>
        <source>Debug</source>
        <translation>Depurar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2018"/>
        <source>FlatData</source>
        <translation>Dados simples</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2028"/>
        <source>Persos</source>
        <translation>Personas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2089"/>
        <source>Labels</source>
        <translation>Rótulos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2123"/>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2127"/>
        <source>&amp;Recent</source>
        <translation>&amp;Recente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2147"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2158"/>
        <source>&amp;Tools</source>
        <translation>&amp;Ferramentas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2165"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2221"/>
        <source>&amp;View</source>
        <translation>&amp;Vizualizar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2225"/>
        <source>&amp;Mode</source>
        <translation>&amp;Modo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2254"/>
        <source>&amp;Cheat sheet</source>
        <translation>&amp;Folha de notas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2288"/>
        <source>Sea&amp;rch</source>
        <translation>P&amp;rocurar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2325"/>
        <source>&amp;Navigation</source>
        <translation>&amp;Navegação</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2360"/>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2363"/>
        <source>Ctrl+O</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2372"/>
        <source>&amp;Save</source>
        <translation>&amp;Salvar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2375"/>
        <source>Ctrl+S</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2384"/>
        <source>Sa&amp;ve as...</source>
        <translation>Sa&amp;lvar como...</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2387"/>
        <source>Ctrl+Shift+S</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2396"/>
        <source>&amp;Quit</source>
        <translation>&amp;Sair</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2399"/>
        <source>Ctrl+Q</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2414"/>
        <source>&amp;Show help texts</source>
        <translation>&amp;Mostrar textos de ajuda</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2417"/>
        <source>Ctrl+Shift+B</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2432"/>
        <source>&amp;Spellcheck</source>
        <translation>&amp;Verificação ortográfica</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2435"/>
        <source>F9</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2444"/>
        <source>&amp;Labels...</source>
        <translation>&amp;Rótulos...</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2453"/>
        <source>&amp;Status...</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1552"/>
        <source>Tree</source>
        <translation>Árvore</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2469"/>
        <source>&amp;Simple</source>
        <translation>&amp;Simples</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2477"/>
        <source>&amp;Fiction</source>
        <translation>&amp;Ficção</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1553"/>
        <source>Index cards</source>
        <translation>Cartões de índice</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2496"/>
        <source>S&amp;ettings</source>
        <translation>Configuraçõ&amp;es</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2499"/>
        <source>F8</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2508"/>
        <source>&amp;Close project</source>
        <translation>Fe&amp;char o projeto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2517"/>
        <source>Co&amp;mpile</source>
        <translation>Co&amp;mpilar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2520"/>
        <source>F6</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2525"/>
        <source>&amp;Frequency Analyzer</source>
        <translation>Analizador de &amp;Frequencia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="154"/>
        <source>Book information</source>
        <translation>Informações do livro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2534"/>
        <source>&amp;About</source>
        <translation>S&amp;obre</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2537"/>
        <source>About Manuskript</source>
        <translation>Sobre o Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="746"/>
        <source>Manuskript</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="872"/>
        <source>Project {} saved.</source>
        <translation type="unfinished"> * {} não foi encontrado o arquivo do projeto.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="876"/>
        <source>WARNING: Project {} not saved.</source>
        <translation>Atenção: Projeto {} não foi salvo.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="896"/>
        <source>Project {} loaded.</source>
        <translation>Projeto {} carregado.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="902"/>
        <source>Project {} loaded with some errors.</source>
        <translation>Projeto {} carregado com alguns erros.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1280"/>
        <source> (~{} pages)</source>
        <translation> (~{} páginas)</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1283"/>
        <source>Words: {}{}</source>
        <translation>Palavras: {}{}</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1291"/>
        <source>Book summary</source>
        <translation>Sumário do livro</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1292"/>
        <source>Project tree</source>
        <translation>Árvore do projeto</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1293"/>
        <source>Metadata</source>
        <translation>Meta dados</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1294"/>
        <source>Story line</source>
        <translation>Linhas históricas</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1359"/>
        <source>Enter information about your book, and yourself.</source>
        <translation>Insira informações sobre seu livro e você mesmo.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1362"/>
        <source>The basic situation, in the form of a 'What if...?' question. Ex: 'What if the most dangerous
                     evil wizard wasn't able to kill a baby?' (Harry Potter)</source>
        <translation>A situação básica, na forma de um questionamento tipo 'e se ...'. Ex: 
'E se o mais perigoso malvado feiticeiro não foi capaz de matar um bebê?' (Harry Potter)</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1367"/>
        <source>Take time to think about a one sentence (~50 words) summary of your book. Then expand it to
                     a paragraph, then to a page, then to a full summary.</source>
        <translation>Tire um tempo para pensar em uma frase (~50 palavras) sumário do seu livro. 
Então expanda isso para um parágrafo, depois para uma página e, em seguida, para um sumário completo.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1372"/>
        <source>Create your characters.</source>
        <translation>Crie seus personagens.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1375"/>
        <source>Develop plots.</source>
        <translation>Desenvolva enredos.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1378"/>
        <source>Build worlds.  Create hierarchy of broad categories down to specific details.</source>
        <translation>Construa mundos. Crie hierarquia de categorias mais amplas até os detalhes específicos.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1381"/>
        <source>Create the outline of your masterpiece.</source>
        <translation>Crie o esboço da sua obra-prima.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1384"/>
        <source>Write.</source>
        <translation>Escreva.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1387"/>
        <source>Debug info. Sometimes useful.</source>
        <translation>Informações de depuração. Às vezes é útil.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1401"/>
        <source>Dictionary</source>
        <translation>Dicionário</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1544"/>
        <source>Nothing</source>
        <translation>Nada</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1545"/>
        <source>POV</source>
        <translation>Ponto de Vista</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1546"/>
        <source>Label</source>
        <translation>Rótulo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1547"/>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1548"/>
        <source>Compile</source>
        <translation>Compilar</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1571"/>
        <source>Icon color</source>
        <translation>Cor do ícone</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1572"/>
        <source>Text color</source>
        <translation>Cor do texto</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1573"/>
        <source>Background color</source>
        <translation>Cor do fundo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1564"/>
        <source>Icon</source>
        <translation>Ícone</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1565"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1566"/>
        <source>Background</source>
        <translation>Fundo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1567"/>
        <source>Border</source>
        <translation>Borda</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1568"/>
        <source>Corner</source>
        <translation>Canto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1371"/>
        <source>Add plot step</source>
        <translation>Adicionar etapa de enredo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2546"/>
        <source>&amp;Import…</source>
        <translation>&amp;Importar…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2549"/>
        <source>F7</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2558"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2561"/>
        <source>Ctrl+C</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2570"/>
        <source>C&amp;ut</source>
        <translation>C&amp;ortar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2573"/>
        <source>Ctrl+X</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2582"/>
        <source>&amp;Paste</source>
        <translation>Co&amp;lar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2585"/>
        <source>Ctrl+V</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2594"/>
        <source>&amp;Split…</source>
        <translation>&amp;Separar…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2597"/>
        <source>Ctrl+Shift+K</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2606"/>
        <source>Sp&amp;lit at cursor</source>
        <translation>Sep&amp;arar no cursor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2609"/>
        <source>Ctrl+K</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2621"/>
        <source>Ctrl+M</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2824"/>
        <source>Ctrl+D</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2642"/>
        <source>Del</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2651"/>
        <source>&amp;Move Up</source>
        <translation>&amp;Mover para cima</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2654"/>
        <source>Ctrl+Shift+Up</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2663"/>
        <source>M&amp;ove Down</source>
        <translation>M&amp;over pra baixo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2666"/>
        <source>Ctrl+Shift+Down</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2630"/>
        <source>Dupl&amp;icate</source>
        <translation>Dupl&amp;icar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2639"/>
        <source>&amp;Delete</source>
        <translation>&amp;Deletar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2675"/>
        <source>&amp;Rename</source>
        <translation>&amp;Renomear</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2678"/>
        <source>F2</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2235"/>
        <source>Organi&amp;ze</source>
        <translation>Organi&amp;zar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2618"/>
        <source>M&amp;erge</source>
        <translation>Ju&amp;ntar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2169"/>
        <source>&amp;Format</source>
        <translation>&amp;Formatar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2177"/>
        <source>&amp;Header</source>
        <translation>&amp;Cabeçalho</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2683"/>
        <source>&amp;Level 1 (setext)</source>
        <translation>&amp;Nível 1 (setext)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2686"/>
        <source>Ctrl+Alt+1</source>
        <translation>Ctrl+Alt+1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2691"/>
        <source>Level &amp;2</source>
        <translation>Nível &amp;2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2694"/>
        <source>Ctrl+Alt+2</source>
        <translation>Ctrl+Alt+2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2699"/>
        <source>Level &amp;1 (atx)</source>
        <translation>Nível &amp;1 (atx)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2702"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2707"/>
        <source>L&amp;evel 2</source>
        <translation>N&amp;ível 2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2710"/>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2715"/>
        <source>Level &amp;3</source>
        <translation>Nível &amp;3</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2718"/>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2723"/>
        <source>Level &amp;4</source>
        <translation>Nível &amp;4</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2726"/>
        <source>Ctrl+4</source>
        <translation>Ctrl+4</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2731"/>
        <source>Level &amp;5</source>
        <translation>Nível &amp;5</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2734"/>
        <source>Ctrl+5</source>
        <translation>Ctrl+5</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2739"/>
        <source>Level &amp;6</source>
        <translation>Nível &amp;6</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2742"/>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2751"/>
        <source>&amp;Bold</source>
        <translation>&amp;Negrito</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2754"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2763"/>
        <source>&amp;Italic</source>
        <translation>&amp;Italico</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2766"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2775"/>
        <source>&amp;Strike</source>
        <translation>&amp;Sucesso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2780"/>
        <source>&amp;Verbatim</source>
        <translation>&amp;Textual</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2785"/>
        <source>Su&amp;perscript</source>
        <translation>So&amp;brescrito</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2788"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2793"/>
        <source>Subsc&amp;ript</source>
        <translation>Subsc&amp;rito</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2796"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2801"/>
        <source>Co&amp;mment block</source>
        <translation>Bloco de Co&amp;mentário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2804"/>
        <source>Ctrl+Shift+C</source>
        <translation>Ctrl+Shift+C</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2813"/>
        <source>Clear &amp;formats</source>
        <translation>Limpar &amp;formatação</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2816"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2821"/>
        <source>&amp;Comment line(s)</source>
        <translation>&amp;Comentar linha(s)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2829"/>
        <source>&amp;Ordered list</source>
        <translation>Lista &amp;Ordenada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2838"/>
        <source>&amp;Unordered list</source>
        <translation>Lista não o&amp;rdenada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2843"/>
        <source>B&amp;lockquote</source>
        <translation>B&amp;loco de citação</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1388"/>
        <source>Remove selected plot step(s)</source>
        <translation>Remover etapas de plotagem selecionada(s)</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="594"/>
        <source>The file {} does not exist. Has it been moved or deleted?</source>
        <translation>O arquivo {} não existe. Ele foi movido ou deletado?</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1415"/>
        <source>Install {}{} to use spellcheck</source>
        <translation>Instale {}{} para usar a verificação ortográfica</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1457"/>
        <source>{} has no installed dictionaries</source>
        <translation>{} não possui dicionários instalados</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1478"/>
        <source>{}{} is not installed</source>
        <translation>{}{} não está instalado</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="689"/>
        <source>Save project?</source>
        <translation>Salvar o projeto?</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="689"/>
        <source>Save changes to project "{}" before closing?</source>
        <translation>Salvar mudanças no projeto "{}" antes de fechar?</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="689"/>
        <source>Your changes will be lost if you don't save them.</source>
        <translation>Suas mudanças vão perder se você não salvá-las.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1671"/>
        <source>PyQt / Qt versions 5.11 and 5.12 are known to cause a crash which might result in a loss of data.</source>
        <translation>PyQt / Qt versão 5.11 e 5.12 são conhecidas para causar travamentos e podem resultar em perda de dados.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1672"/>
        <source>PyQt {} and Qt {} are in use.</source>
        <translation>PyQt {} e Qt {} estão em uso.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1678"/>
        <source>Proceed with import at your own risk</source>
        <translation>Proceder com a importação por sua conta e risco</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="862"/>
        <source>Allow POV</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2852"/>
        <source>Search</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2855"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2860"/>
        <source>&amp;Technical Support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2863"/>
        <source>How to obtain technical support for Manuskript.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2866"/>
        <source>F1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2871"/>
        <source>&amp;Locate log file...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2874"/>
        <source>Locate log file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2877"/>
        <source>Locate the diagnostic log file used for this session.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2880"/>
        <source>Shift+F1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1193"/>
        <source>Sorry!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1193"/>
        <source>This session is not being logged.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1202"/>
        <source>A log file is a Work in Progress!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1202"/>
        <source>The log file "{}" will continue to be written to until Manuskript is closed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1202"/>
        <source>It will now be displayed in your file manager, but is of limited use until you close Manuskript.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1218"/>
        <source>Error!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1218"/>
        <source>An error was encountered while trying to show the log file below in your file manager.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="45"/>
        <source>F3</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="46"/>
        <source>Shift+F3</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="50"/>
        <source>Situation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="51"/>
        <source>Status</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Search</name>
    <message>
        <location filename="../manuskript/ui/search.py" line="40"/>
        <source>No results found</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="14"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="24"/>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="526"/>
        <source>Revisions</source>
        <translation>Revisões</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="34"/>
        <source>Views</source>
        <translation>Pontos de Vistas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2891"/>
        <source>Labels</source>
        <translation>Rótulos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3023"/>
        <source>Status</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3097"/>
        <source>Fullscreen</source>
        <translation>Tela cheia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="82"/>
        <source>General settings</source>
        <translation>Configurações gerais</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="98"/>
        <source>Application settings</source>
        <translation>Configurações do aplicativo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="247"/>
        <source>Loading</source>
        <translation>Carregando</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="259"/>
        <source>Automatically load last project on startup</source>
        <translation>Carregar automaticamente o último projeto na inicialização</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="278"/>
        <source>Saving</source>
        <translation>Salvando</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="292"/>
        <source>Automatically save every</source>
        <translation>Salvar automaticamente todos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="339"/>
        <source>minutes.</source>
        <translation>minutos.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="375"/>
        <source>If no changes during</source>
        <translation>Se não houver alterações durante</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="422"/>
        <source>seconds.</source>
        <translation>segundos.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="456"/>
        <source>Save on project close</source>
        <translation>Salvar ao sair</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="472"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If you check this option, your project will be saved as one single file. Easier to copy or backup, but does not allow collaborative editing, or versioning.&lt;br/&gt;If this is unchecked, your project will be saved as a folder containing many small files.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Se você marcar essa opção, seu projeto será salvo como um único arquivo. Mais fácil de copiar ou fazer backup, mas não permite edição colaborativa ou controle de versão.&lt;br/&gt;Se não for marcado aqui, o seu projeto será salvo como uma pasta contendo muitos arquivos pequenos.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="478"/>
        <source>Save to one single file</source>
        <translation>Salvar em um único arquivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="536"/>
        <source>Revisions are a way to keep track of modifications. For each text item, it stores any changes you make to the main text, allowing you to see and restoring previous versions.</source>
        <translation>As revisões são uma maneira de acompanhar as modificações. Para cada item de texto, ele armazena todas as alterações feitas no texto principal, permitindo que você veja e restaure versões anteriores.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="546"/>
        <source>Keep revisions</source>
        <translation>Mantenha as revisões</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="562"/>
        <source>S&amp;mart remove</source>
        <translation>&amp;Remoção inteligente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="577"/>
        <source>Keep:</source>
        <translation>Manter:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="590"/>
        <source>Smart remove allows you to keep only a certain number of revisions. It is strongly recommended to use it, lest you file will becomes full of thousands of insignificant changes.</source>
        <translation>Remoção inteligente permite que você mantenha apenas um certo número de revisões. Recomenda-se expressamente usá-lo, para que o seu arquivo não fique cheio de milhares de alterações insignificantes.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="606"/>
        <source>revisions per day for the last month</source>
        <translation>revisões por dia durante o último mês</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="647"/>
        <source>revisions per minute for the last 10 minutes</source>
        <translation>revisões por minuto nos últimos 10 minutos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="660"/>
        <source>revisions per hour for the last day</source>
        <translation>revisões por hora para o último dia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="673"/>
        <source>revisions per 10 minutes for the last hour</source>
        <translation>revisões por 10 minutos para a última hora</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="798"/>
        <source>revisions per week till the end of time</source>
        <translation>revisões por semana até o final do tempo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="856"/>
        <source>Views settings</source>
        <translation>Configurações de visual</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="874"/>
        <source>Tree</source>
        <translation>Árvore</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2145"/>
        <source>Colors</source>
        <translation>Cores</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1889"/>
        <source>Icon color:</source>
        <translation>Cor do ícone:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2095"/>
        <source>Nothing</source>
        <translation>Nada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2100"/>
        <source>POV</source>
        <translation>Ponto de Vista</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2105"/>
        <source>Label</source>
        <translation>Rótulo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2110"/>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2115"/>
        <source>Compile</source>
        <translation>Compilar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1937"/>
        <source>Text color:</source>
        <translation>Cor do Texto:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1985"/>
        <source>Background color:</source>
        <translation>Cor de fundo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1168"/>
        <source>Folders</source>
        <translation>Pastas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1180"/>
        <source>Show ite&amp;m count</source>
        <translation>&amp;Mostra contagem de itens</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1315"/>
        <source>Show summary</source>
        <translation>Mostrar sumário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1245"/>
        <source>&amp;Nothing</source>
        <translation>&amp;Nada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1264"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1382"/>
        <source>Outline</source>
        <translation>Esboço</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1574"/>
        <source>Visible columns</source>
        <translation>Colunas visíveis</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1586"/>
        <source>Goal</source>
        <translation>Objetivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1602"/>
        <source>Word count</source>
        <translation>Contagem de palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1618"/>
        <source>Percentage</source>
        <translation>Porcentagem</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1698"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1729"/>
        <source>Index cards</source>
        <translation>Índice dos cartões</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1874"/>
        <source>Item colors</source>
        <translation>Cores dos Itens</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2033"/>
        <source>Border color:</source>
        <translation>Cor da borda:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2081"/>
        <source>Corner color:</source>
        <translation>Cor do canto:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1741"/>
        <source>Background</source>
        <translation>Fundo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3576"/>
        <source>Color:</source>
        <translation>Cor:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2938"/>
        <source>Ctrl+S</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3318"/>
        <source>Image:</source>
        <translation>Imagem:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2131"/>
        <source>Text editor</source>
        <translation>Editor de texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2250"/>
        <source>Font</source>
        <translation>Fonte</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2262"/>
        <source>Family:</source>
        <translation>Familia:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3619"/>
        <source>Size:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3633"/>
        <source>Misspelled:</source>
        <translation>Com erros ortográficos:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2157"/>
        <source>Background:</source>
        <translation>Fundo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2473"/>
        <source>Paragraphs</source>
        <translation>Parágrafos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3660"/>
        <source>Line spacing:</source>
        <translation>Espaçamento entre linhas:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3668"/>
        <source>Single</source>
        <translation>Simples</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3673"/>
        <source>1.5 lines</source>
        <translation>1.5 entre linhas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3678"/>
        <source>Double</source>
        <translation>Duplo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3683"/>
        <source>Proportional</source>
        <translation>Proporcional</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3700"/>
        <source>%</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3716"/>
        <source>Tab width:</source>
        <translation>Largura da guia:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3780"/>
        <source> px</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3802"/>
        <source>Indent 1st line</source>
        <translation>Recuo da primeira linha</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3745"/>
        <source>Spacing:</source>
        <translation>Espaçamento:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3144"/>
        <source>New</source>
        <translation>Novo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3158"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3168"/>
        <source>Delete</source>
        <translation>Deletar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3212"/>
        <source>Theme name:</source>
        <translation>Nome do tema:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3228"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3241"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3271"/>
        <source>Window Background</source>
        <translation>Fundo da janela</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3276"/>
        <source>Text Background</source>
        <translation>Fundo do texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3281"/>
        <source>Text Options</source>
        <translation>Opções do texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3286"/>
        <source>Paragraph Options</source>
        <translation>Opções do parágrafo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3328"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3336"/>
        <source>No Image</source>
        <translation>Sem imagem</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3341"/>
        <source>Tiled</source>
        <translation>Lado a lado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3346"/>
        <source>Centered</source>
        <translation>Centralizado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3445"/>
        <source>Stretched</source>
        <translation>Esticado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3356"/>
        <source>Scaled</source>
        <translation>Dividido</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3361"/>
        <source>Zoomed</source>
        <translation>Com zoom</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3396"/>
        <source>Opacity:</source>
        <translation>Opacidade:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3422"/>
        <source>Position:</source>
        <translation>Posição:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3810"/>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3819"/>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3828"/>
        <source>Right</source>
        <translation>Direita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3453"/>
        <source>Width:</source>
        <translation>Largura:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3504"/>
        <source>Corner radius:</source>
        <translation>Raio do canto:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3511"/>
        <source>Margins:</source>
        <translation>Margem:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3540"/>
        <source>Padding:</source>
        <translation>Preenchimento:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3596"/>
        <source>Font:</source>
        <translation>Fonte:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1833"/>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2750"/>
        <source>Cursor</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2762"/>
        <source>Use block insertion of</source>
        <translation>Use a inserção de blocos de</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2485"/>
        <source>Alignment:</source>
        <translation>Alinhamento:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3837"/>
        <source>Justify</source>
        <translation>Justificado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3849"/>
        <source>Alignment</source>
        <translation>Alinhamento</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1066"/>
        <source>Icon Size</source>
        <translation>Tamanho do Ícone</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1078"/>
        <source>TextLabel</source>
        <translation>Rótulo do Texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2797"/>
        <source>Disable blinking</source>
        <translation>Parar de piscar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2364"/>
        <source>Text area</source>
        <translation>Área de texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2376"/>
        <source>Max width</source>
        <translation>Largura máxima</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2408"/>
        <source>Left/Right margins:</source>
        <translation>Margens Esquerda/Direita:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2437"/>
        <source>Top/Bottom margins:</source>
        <translation>Margens Cima/Baixo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1219"/>
        <source>S&amp;how progress</source>
        <translation>Mostrar o pr&amp;ogresso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1232"/>
        <source>Show summar&amp;y</source>
        <translation>Mostrar o sumár&amp;io</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1302"/>
        <source>Show p&amp;rogress</source>
        <translation>Mostrar o p&amp;rogresso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1845"/>
        <source>Old st&amp;yle</source>
        <translation>Es&amp;tilo antigo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2189"/>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2234"/>
        <source>Restore defaults</source>
        <translation>Restaurar o padrão</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="138"/>
        <source>Style:</source>
        <translation>Estilo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="161"/>
        <source>Language:</source>
        <translation>Idioma:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="184"/>
        <source>Font size:</source>
        <translation>Tamanho da fonte:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="112"/>
        <source>Restarting Manuskript ensures all settings take effect.</source>
        <translation>Reiniciar o Manuskript para garantir que as configurações façam efeitos.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1193"/>
        <source>Show &amp;word count</source>
        <translation>Mostrar a contagem de &amp;palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1276"/>
        <source>&amp;Show word count</source>
        <translation>&amp;Mostrar a contagem de palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1858"/>
        <source>&amp;New style</source>
        <translation>&amp;Novo estilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2810"/>
        <source>Typewriter mode</source>
        <translation>Modo máquina de escrever</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2823"/>
        <source>Focus mode</source>
        <translation>Modo de foco</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2837"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2842"/>
        <source>Sentence</source>
        <translation>Sentença</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2847"/>
        <source>Line</source>
        <translation>Linha</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2852"/>
        <source>Paragraph</source>
        <translation>Parágrafo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="821"/>
        <source>&lt;p&gt;&lt;b&gt;The Revisions feature has been at the source of many reported issues. In this version of Manuskript it has been turned off by default for new projects in order to provide the best experience.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Why aren't these issues fixed already? &lt;a href="https://www.theologeek.ch/manuskript/contribute/"&gt;We need your help to make Manuskript better!&lt;/a&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;As ferramentas de revisões são fontes de muitos problemas reportadas. Nesta versão do Manuskript, ele foi desativado por padrão para novos projetos, a fim de fornecer a melhor experiência.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Por que esses problemas já não foram corrigidos? &lt;a href="https://www.theologeek.ch/manuskript/contribute/"&gt;Nós precisamos de sua ajuda para fazer o Manuskript melhor!&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="211"/>
        <source>Show progress in chars next
 to words</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1113"/>
        <source>Char/Word Counter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1137"/>
        <source>Count spaces as chars</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1206"/>
        <source>Show char c&amp;ount</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1289"/>
        <source>Sho&amp;w char count</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SpellAction</name>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="611"/>
        <source>Spelling Suggestions</source>
        <translation>Sugestões de correção ortográfica</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="629"/>
        <source>&amp;Add to dictionary</source>
        <translation>&amp;Adicionar ao dicionário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="682"/>
        <source>&amp;Remove from custom dictionary</source>
        <translation>&amp;Remover do dicionário customizado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="538"/>
        <source>&amp;New Character</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="545"/>
        <source>&amp;New Plot Item</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="552"/>
        <source>&amp;New World Item</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="653"/>
        <source>&amp;Correction Suggestions</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="662"/>
        <source>&amp;Correction Suggestion</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../manuskript/ui/about_ui.ui" line="17"/>
        <source>About Manuskript</source>
        <translation>Sobre o Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/about_ui.ui" line="50"/>
        <source>Manuskript</source>
        <translation/>
    </message>
</context>
<context>
    <name>aboutDialog</name>
    <message>
        <location filename="../manuskript/ui/about.py" line="28"/>
        <source>Version</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/about.py" line="41"/>
        <source>Software Versions in Use:</source>
        <translation>Versões de software em uso:</translation>
    </message>
</context>
<context>
    <name>abstractModel</name>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="199"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="201"/>
        <source>POV</source>
        <translation>Ponto de vista</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="203"/>
        <source>Label</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="205"/>
        <source>Status</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="207"/>
        <source>Compile</source>
        <translation>Compilar</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="209"/>
        <source>Word count</source>
        <translation>Contagem de palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="211"/>
        <source>Goal</source>
        <translation>Objetivo</translation>
    </message>
</context>
<context>
    <name>basicItemView</name>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="38"/>
        <source>POV:</source>
        <translation>Ponto de vista:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="55"/>
        <source>Goal:</source>
        <translation>Objetivo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="80"/>
        <source>Word count</source>
        <translation>Contagem de palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="92"/>
        <source>One line summary</source>
        <translation>Sumário de uma linha</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="99"/>
        <source>Few sentences summary:</source>
        <translation>Sumário de poucas frases:</translation>
    </message>
</context>
<context>
    <name>characterModel</name>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="205"/>
        <source>Name</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="207"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
</context>
<context>
    <name>characterTreeView</name>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="32"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="32"/>
        <source>Secondary</source>
        <translation>Secundário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="32"/>
        <source>Minor</source>
        <translation/>
    </message>
</context>
<context>
    <name>cheatSheet</name>
    <message>
        <location filename="../manuskript/ui/cheatSheet_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet_ui.ui" line="46"/>
        <source>Filter (type the name of anything in your project)</source>
        <translation>Filtro (digite a palavra de qualquer coisa no seu projeto)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Minor</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Secondary</source>
        <translation>Secundário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="91"/>
        <source>Characters</source>
        <translation>Personagens</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="104"/>
        <source>Texts</source>
        <translation>Textos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="116"/>
        <source>Plots</source>
        <translation>Enredos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="120"/>
        <source>World</source>
        <translation/>
    </message>
</context>
<context>
    <name>cmbOutlineCharacterChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="34"/>
        <source>None</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Secondary</source>
        <translation>Secundário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Minor</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="136"/>
        <source>Various</source>
        <translation>Vários</translation>
    </message>
</context>
<context>
    <name>cmbOutlineLabelChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineLabelChoser.py" line="113"/>
        <source>Various</source>
        <translation>Varios</translation>
    </message>
</context>
<context>
    <name>cmbOutlineStatusChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineStatusChoser.py" line="112"/>
        <source>Various</source>
        <translation>Vários</translation>
    </message>
</context>
<context>
    <name>collapsibleDockWidgets</name>
    <message>
        <location filename="../manuskript/ui/collapsibleDockWidgets.py" line="26"/>
        <source>Dock Widgets Toolbar</source>
        <translation>Barra de ferramentas de widgets</translation>
    </message>
</context>
<context>
    <name>completer</name>
    <message>
        <location filename="../manuskript/ui/editors/completer_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
</context>
<context>
    <name>corkDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/corkDelegate.py" line="70"/>
        <source>One line summary</source>
        <translation>Sumário de uma linha</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/corkDelegate.py" line="100"/>
        <source>Full summary</source>
        <translation>Sumário completo</translation>
    </message>
</context>
<context>
    <name>editorWidget_ui</name>
    <message>
        <location filename="../manuskript/ui/editors/editorWidget_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
</context>
<context>
    <name>exporter</name>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="65"/>
        <source>Export</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="22"/>
        <source>Export to:</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="32"/>
        <source>Manage exporters</source>
        <translation>Gerenciar exportadores</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="103"/>
        <source>Preview</source>
        <translation>Visualizar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="81"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
</context>
<context>
    <name>exporterDialog</name>
    <message>
        <location filename="../manuskript/ui/exporters/exporter.py" line="64"/>
        <source>{} (not implemented yet)</source>
        <translation>{} (não implementado ainda)</translation>
    </message>
</context>
<context>
    <name>exporterSettings</name>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="50"/>
        <source>Content</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="56"/>
        <source>Decide here what will be included in the final export.</source>
        <translation>Decida aqui o que será incluído na exportação final.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="85"/>
        <source>Type</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="90"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="326"/>
        <source>Text</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="118"/>
        <source>I need more granularity</source>
        <translation>Eu preciso de mais granularidade</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="127"/>
        <source>Fi&amp;lters</source>
        <translation>Fi&amp;ltros</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="142"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filters what items will be included in the final export.&lt;br/&gt;&lt;span style=" color:#773333;"&gt;(Not fully implemented yet.)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtra quais itens serão incluídos na exportação final.&lt;br/&gt;&lt;span style=" color:#773333;"&gt;(Não está completamente implementado.)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="149"/>
        <source>Ignore compile status (include all items)</source>
        <translation>Ignore o status de compilação (inclua todos os itens)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="156"/>
        <source>Subitems of:</source>
        <translation>Subitens de:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="170"/>
        <source>Labels</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="177"/>
        <source>Status</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="229"/>
        <source>Separations</source>
        <translation>Separações</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="241"/>
        <source>Between folders:</source>
        <translation>Entre pastas:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="86"/>
        <source>Empty line</source>
        <translation>Linha vazia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="105"/>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="367"/>
        <source>Between texts:</source>
        <translation>Entre textos:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="493"/>
        <source>Between folder and text:</source>
        <translation>Entre pastas e texto:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="619"/>
        <source>Between text and folder:</source>
        <translation>Entre texto e pasta:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="764"/>
        <source>Transformations</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="773"/>
        <source>Typographic replacements:</source>
        <translation>Substitições tipográficas:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="802"/>
        <source>Replace double quotes (") with:</source>
        <translation>Substitua aspas duplas (") por:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="911"/>
        <source>Replace single quotes (') with:</source>
        <translation>Substitua as aspas simples(') por:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1020"/>
        <source>Remove multiple spaces</source>
        <translation>Remover vários espaços</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1030"/>
        <source>Custom replacements:</source>
        <translation>Substituições personalizadas:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1049"/>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1054"/>
        <source>Replace</source>
        <translation>Substituir</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1059"/>
        <source>With</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1064"/>
        <source>RegExp</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1067"/>
        <source>If checked, uses regular expression for replacement. If unchecked, replaced as plain text.</source>
        <translation>Se marcado, usa a expressão regular para substituição. Se desmarcado, substituído como texto simples.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1151"/>
        <source>Preview</source>
        <translation>Pré-visualizar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1157"/>
        <source>Font</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1163"/>
        <source>Font:</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1173"/>
        <source>Font size:</source>
        <translation>Tamanho da fonte:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="320"/>
        <source>Folder</source>
        <translation>Pasta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="343"/>
        <source>{}Level {} folder</source>
        <translation>{}Nível{} pasta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="346"/>
        <source>{}Level {} text</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="788"/>
        <source>Replace ... with …</source>
        <translation>Substituir... com …</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="795"/>
        <source>Replace --- with —</source>
        <translation>Substituir--- com —</translation>
    </message>
</context>
<context>
    <name>exportersManager</name>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="81"/>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="87"/>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="93"/>
        <source>Not found</source>
        <translation>Não encontrado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="96"/>
        <source>{} not found. Install it, or set path manually.</source>
        <translation>{} não encontrado. Instale-o ou configure o caminho manualmente.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="124"/>
        <source>&lt;b&gt;Status:&lt;/b&gt; uninstalled.</source>
        <translation>&lt;b&gt;Situação:&lt;/b&gt; desinstalado.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="126"/>
        <source>&lt;b&gt;Requires:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Requer:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="133"/>
        <source>Set {} executable path.</source>
        <translation>Defina {} caminho executável.</translation>
    </message>
</context>
<context>
    <name>frequencyAnalyzer</name>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="70"/>
        <source>Phrases</source>
        <translation>Frases</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="108"/>
        <source>Frequency</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="108"/>
        <source>Word</source>
        <translation/>
    </message>
</context>
<context>
    <name>fullScreenEditor</name>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="133"/>
        <source>Theme:</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="364"/>
        <source>{} words / {}</source>
        <translation>{} palavras / {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="368"/>
        <source>{} words</source>
        <translation>{} palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="153"/>
        <source>Spellcheck</source>
        <translation>Verificador ortográfico</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="154"/>
        <source>Navigation</source>
        <translation>Navegação</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="155"/>
        <source>New Text</source>
        <translation>Novo texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="156"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="157"/>
        <source>Title: Show Full Path</source>
        <translation>Título: Mostrar o caminho completo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="159"/>
        <source>Theme selector</source>
        <translation>Seletor de tema</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="160"/>
        <source>Word count</source>
        <translation>Contagem de palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="161"/>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="162"/>
        <source>Progress: Auto Show/Hide</source>
        <translation>Progresso: Auto Mostrar/Esconder</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="163"/>
        <source>Clock</source>
        <translation>Relógio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="164"/>
        <source>Clock: Show Seconds</source>
        <translation>Relógio: Mostrar Segundos</translation>
    </message>
</context>
<context>
    <name>generalSettings</name>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="41"/>
        <source>General</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="55"/>
        <source>Split scenes at:</source>
        <translation>Cenas divididas em:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="65"/>
        <source>\n---\n</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="72"/>
        <source>Trim long titles (&gt; 32 chars)</source>
        <translation>Apare títulos longos (&gt; 32 letras)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="86"/>
        <source>Import under:</source>
        <translation>Importar sob:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="93"/>
        <source>Import in a top-level folder</source>
        <translation>Importar em uma pasta de nível superior</translation>
    </message>
</context>
<context>
    <name>helpLabel</name>
    <message>
        <location filename="../manuskript/ui/helpLabel.py" line="12"/>
        <source>If you don't wanna see me, you can hide me in Help menu.</source>
        <translation>Se você não quiser me ver, pode me esconder no menu Ajuda.</translation>
    </message>
</context>
<context>
    <name>importer</name>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="119"/>
        <source>Import</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="22"/>
        <source>Format:</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="45"/>
        <source>Choose file</source>
        <translation>Escolha o arquivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="75"/>
        <source>Clear file</source>
        <translation>Limpar o arquivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="160"/>
        <source>Preview</source>
        <translation>Pré-visualizar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="138"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
</context>
<context>
    <name>lineEditView</name>
    <message>
        <location filename="../manuskript/ui/views/lineEditView.py" line="114"/>
        <source>Various</source>
        <translation>Vários</translation>
    </message>
</context>
<context>
    <name>locker</name>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="26"/>
        <source>Lock screen:</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="33"/>
        <source>Word target</source>
        <translation>Meta de palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="40"/>
        <source>Time target</source>
        <translation>Meta de tempo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="47"/>
        <source> words</source>
        <translation> palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="63"/>
        <source> minutes</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="79"/>
        <source>Lock !</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="94"/>
        <source>~{} h.</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="96"/>
        <source>~{} mn.</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="100"/>
        <source>{}:{}</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="102"/>
        <source>{} s.</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="104"/>
        <source>{} remaining</source>
        <translation>{} falatando</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="109"/>
        <source>{} words remaining</source>
        <translation>{} palavras restando</translation>
    </message>
</context>
<context>
    <name>mainEditor</name>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="67"/>
        <source>Text</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="83"/>
        <source>Index cards</source>
        <translation>Cartões de índece</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="102"/>
        <source>Outline</source>
        <translation>Esboço</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="198"/>
        <source>F11</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="47"/>
        <source>Go to parent item</source>
        <translation>Ir para item pai</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="57"/>
        <source>Alt+Up</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="251"/>
        <source>Root</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="358"/>
        <source>{} words </source>
        <translation>{} palavras </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="339"/>
        <source>({} chars) {}  words / {} </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="345"/>
        <source>{}  words / {} </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="360"/>
        <source>{} chars</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="354"/>
        <source>{} chars </source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>markdownSettings</name>
    <message>
        <location filename="../manuskript/exporter/manuskript/markdown.py" line="58"/>
        <source>Markdown</source>
        <translation/>
    </message>
</context>
<context>
    <name>metadataView</name>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="41"/>
        <source>Properties</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="81"/>
        <source>Summary</source>
        <translation>Sumário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="114"/>
        <source>One line summary</source>
        <translation>Sumário de uma linha</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="140"/>
        <source>Full summary</source>
        <translation>Sumário completo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="180"/>
        <source>Notes / References</source>
        <translation>Notas / Referências</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="190"/>
        <source>Revisions</source>
        <translation>Revisões</translation>
    </message>
</context>
<context>
    <name>myPanel</name>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="599"/>
        <source>Auto-hide</source>
        <translation>Ocultar automaticamente</translation>
    </message>
</context>
<context>
    <name>outlineBasics</name>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="134"/>
        <source>Set POV</source>
        <translation>Setar o ponto de vista</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="136"/>
        <source>None</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="163"/>
        <source>Set Status</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="179"/>
        <source>Set Label</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="283"/>
        <source>New</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="142"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="143"/>
        <source>Secondary</source>
        <translation>Secundário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="144"/>
        <source>Minor</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="197"/>
        <source>Set Custom Icon</source>
        <translation>Definir ícone personalizado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="198"/>
        <source>Restore to default</source>
        <translation>Restaurar para o padrão</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="61"/>
        <source>Root</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="75"/>
        <source>Open {} items in new tabs</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="78"/>
        <source>Open {} in a new tab</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="328"/>
        <source>About to remove</source>
        <translation>Prestes a remover</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="434"/>
        <source>Select at least two items. Folders are ignored.</source>
        <translation>Selecione pelo menos dois itens. Pastas são ignoradas.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="443"/>
        <source>All items must be on the same level (share the same parent).</source>
        <translation>Todos os itens devem estar no mesmo nível (estar no mesmo local).</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="88"/>
        <source>New &amp;Folder</source>
        <translation>Nova &amp;Pasta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="94"/>
        <source>New &amp;Text</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="108"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="103"/>
        <source>C&amp;ut</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="113"/>
        <source>&amp;Paste</source>
        <translation>&amp;Colar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="125"/>
        <source>&amp;Rename</source>
        <translation>&amp;Renomear</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="119"/>
        <source>&amp;Delete</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="315"/>
        <source>You're about to delete {} item(s).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="325"/>
        <source>Are you sure?</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>outlineCharacterDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="141"/>
        <source>None</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Secondary</source>
        <translation>Secundário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Minor</source>
        <translation/>
    </message>
</context>
<context>
    <name>outlineItem</name>
    <message>
        <location filename="../manuskript/models/outlineItem.py" line="256"/>
        <source>{} words / {} ({})</source>
        <translation>{} palavras / {} ({})</translation>
    </message>
    <message>
        <location filename="../manuskript/models/outlineItem.py" line="261"/>
        <source>{} words</source>
        <translation>{} palavras</translation>
    </message>
</context>
<context>
    <name>pandocSettings</name>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="166"/>
        <source>General</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="180"/>
        <source>Table of Content</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="185"/>
        <source>Custom settings for {}</source>
        <translation>Configurações personalizadas para {}</translation>
    </message>
</context>
<context>
    <name>persosProxyModel</name>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="16"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="17"/>
        <source>Secondary</source>
        <translation>Secundário</translation>
    </message>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="18"/>
        <source>Minors</source>
        <translation>Menores</translation>
    </message>
</context>
<context>
    <name>plotDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>General</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Promise</source>
        <translation>Promessa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Problem</source>
        <translation>Problema</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Try / Fail</source>
        <translation>Tentativa / Falha</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>No and</source>
        <translation>Não e</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Yes but</source>
        <translation>Sim mas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Freytag's pyramid</source>
        <translation>Pirâmide de Freytag</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Exposition</source>
        <translation>Exposição</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Rising action</source>
        <translation>Ação crescente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Climax</source>
        <translation>Climáx</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Falling action</source>
        <translation>Desfecho</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Three acts</source>
        <translation>Três atos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Setup</source>
        <translation>1. Configuração</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Inciting event</source>
        <translation>1. Evento inical</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Turning point</source>
        <translation>1. Ponto de virada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Choice</source>
        <translation>2. Escolha</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Reversal</source>
        <translation>2. Reversão</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Disaster</source>
        <translation>2. Disastre</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Stand up</source>
        <translation>3. Levante</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Climax</source>
        <translation>3. Clímax</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Ending</source>
        <translation>3. Finalizando</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Hero's journey</source>
        <translation>Jornada do herói</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Ordinary world</source>
        <translation>Mundo normal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Call to adventure</source>
        <translation>Chamada para a aventura</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Refusal of the call</source>
        <translation>Recusa da chamada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Meeting with mentor</source>
        <translation>Encontro com o mentor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Tests</source>
        <translation>Testes</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Approach</source>
        <translation>Abordagem</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Abyss</source>
        <translation>Abismo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Reward / Revelation</source>
        <translation>Recompensa / Revelação</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Transformation</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Atonement</source>
        <translation>Expiação</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Return</source>
        <translation/>
    </message>
</context>
<context>
    <name>plotModel</name>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="144"/>
        <source>Name</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="146"/>
        <source>Meta</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="179"/>
        <source>New step</source>
        <translation>Novo passo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="249"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="249"/>
        <source>Secondary</source>
        <translation>Secundário</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="249"/>
        <source>Minor</source>
        <translation/>
    </message>
</context>
<context>
    <name>plotTreeView</name>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="127"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="127"/>
        <source>Secondary</source>
        <translation>Secundário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="127"/>
        <source>Minor</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="187"/>
        <source>**Plot:** {}</source>
        <translation>**Enredo:** {}</translation>
    </message>
</context>
<context>
    <name>plotsProxyModel</name>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="22"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="23"/>
        <source>Secondary</source>
        <translation>Secundário</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="24"/>
        <source>Minors</source>
        <translation>Menores</translation>
    </message>
</context>
<context>
    <name>propertiesView</name>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="195"/>
        <source>POV</source>
        <translation>Ponto de Vista</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="215"/>
        <source>Status</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="235"/>
        <source>Label</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="255"/>
        <source>Compile</source>
        <translation>Compilar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="269"/>
        <source>Goal</source>
        <translation>Objetivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="291"/>
        <source>Word count</source>
        <translation>Contagem de palavras</translation>
    </message>
</context>
<context>
    <name>references</name>
    <message>
        <location filename="../manuskript/models/references.py" line="501"/>
        <source>Not a reference: {}.</source>
        <translation>Não é um a referência: {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="399"/>
        <source>Unknown reference: {}.</source>
        <translation>Referência desconhecida: {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="106"/>
        <source>Path:</source>
        <translation>Caminho:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="107"/>
        <source>Stats:</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="108"/>
        <source>POV:</source>
        <translation>Ponto de Vista:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="109"/>
        <source>Status:</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="110"/>
        <source>Label:</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="111"/>
        <source>Short summary:</source>
        <translation>Sumário curto:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="112"/>
        <source>Long summary:</source>
        <translation>Sumário longo:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="113"/>
        <source>Notes:</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="201"/>
        <source>Basic info</source>
        <translation>Informação básica</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="202"/>
        <source>Detailed info</source>
        <translation>Informação detalhada</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="203"/>
        <source>POV of:</source>
        <translation>Ponto de vista de:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="364"/>
        <source>Go to {}.</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="359"/>
        <source>Description</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="281"/>
        <source>Result</source>
        <translation>Resultado</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="282"/>
        <source>Characters</source>
        <translation>Personagens</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="283"/>
        <source>Resolution steps</source>
        <translation>Etapas de resolução</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="360"/>
        <source>Passion</source>
        <translation>Paixão</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="361"/>
        <source>Conflict</source>
        <translation>Conflito</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="498"/>
        <source>&lt;b&gt;Unknown reference:&lt;/b&gt; {}.</source>
        <translation>&lt;b&gt;Referência Desconhecida:&lt;/b&gt; {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="506"/>
        <source>Folder: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Pasta: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="508"/>
        <source>Text: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="513"/>
        <source>Character: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Personagem: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="516"/>
        <source>Plot: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Enredo: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="519"/>
        <source>World: &lt;b&gt;{name}&lt;/b&gt;{path}</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="592"/>
        <source>Referenced in:</source>
        <translation>Referenciado em:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="212"/>
        <source>Motivation</source>
        <translation>Motivação</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="213"/>
        <source>Goal</source>
        <translation>Objetivo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="215"/>
        <source>Epiphany</source>
        <translation>Epifania</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="216"/>
        <source>Short summary</source>
        <translation>Sumário curto</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="217"/>
        <source>Longer summary</source>
        <translation>Sumário longo</translation>
    </message>
</context>
<context>
    <name>revisions</name>
    <message>
        <location filename="../manuskript/ui/revisions_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions_ui.ui" line="107"/>
        <source>Options</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="257"/>
        <source>Restore</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="258"/>
        <source>Delete</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="45"/>
        <source>Show modifications</source>
        <translation>Mostrar modificações</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="52"/>
        <source>Show ancient version</source>
        <translation>Mostrar versão antiga</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="60"/>
        <source>Show spaces</source>
        <translation>Mostrar espaços</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="66"/>
        <source>Show modifications only</source>
        <translation>Mostrar somente modificações</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="110"/>
        <source>{} years ago</source>
        <translation>{} anos atrás</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="112"/>
        <source>{} months ago</source>
        <translation>{} meses atrás</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="114"/>
        <source>{} days ago</source>
        <translation>{} dias atrás</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="116"/>
        <source>1 day ago</source>
        <translation>1 dia atrás</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="118"/>
        <source>{} hours ago</source>
        <translation>{} horas atrás</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="120"/>
        <source>{} minutes ago</source>
        <translation>{} minutos atrás</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="122"/>
        <source>{} seconds ago</source>
        <translation>{} segundos atrás</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="182"/>
        <source>Line {}:</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="261"/>
        <source>Clear all</source>
        <translation>Limpar tudo</translation>
    </message>
</context>
<context>
    <name>search</name>
    <message>
        <location filename="../manuskript/ui/search_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search_ui.ui" line="46"/>
        <source>Search for...</source>
        <translation>Procurar por...</translation>
    </message>
</context>
<context>
    <name>settingsWindow</name>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="674"/>
        <source>New status</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="695"/>
        <source>New label</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="731"/>
        <source>newtheme</source>
        <translation>novo tema</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="741"/>
        <source>New theme</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="773"/>
        <source> (read-only)</source>
        <translation> (ler somente)</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="534"/>
        <source>Open Image</source>
        <translation>Abrir Imagem</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="534"/>
        <source>Image files (*.jpg; *.jpeg; *.png)</source>
        <translation>Arquivos de imagem (*.jpg; *.jpeg; *.png)</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="550"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="547"/>
        <source>Unable to load selected file</source>
        <translation>Incapaz de carregar o arquivo selecionado</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="550"/>
        <source>Unable to add selected image:
{}</source>
        <translation>Incapaz de adicionar a imagem selecionada:
{}</translation>
    </message>
</context>
<context>
    <name>sldImportance</name>
    <message>
        <location filename="../manuskript/ui/views/sldImportance_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance_ui.ui" line="39"/>
        <source>TextLabel</source>
        <translation>Rótulo do texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="29"/>
        <source>Minor</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="30"/>
        <source>Secondary</source>
        <translation>Secundário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="31"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
</context>
<context>
    <name>splitDialog</name>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="19"/>
        <source>
            &lt;p&gt;Split selected item(s) at the given mark.&lt;/p&gt;

            &lt;p&gt;If one of the selected item is a folder, it will be applied
            recursively to &lt;i&gt;all&lt;/i&gt; of it's children items.&lt;/p&gt;

            &lt;p&gt;The split mark can contain following escape sequences:
                &lt;ul&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\n&lt;/code&gt;&lt;/b&gt;: line break&lt;/li&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\t&lt;/code&gt;&lt;/b&gt;: tab&lt;/li&gt;
                &lt;/ul&gt;
            &lt;/p&gt;

            &lt;p&gt;&lt;b&gt;Mark:&lt;/b&gt;&lt;/p&gt;
            </source>
        <translation>
            &lt;p&gt;Dividir o(s) item(ns) selecionado(s) na marca indicada.&lt;/p&gt;

            &lt;p&gt;Se um dos itens selecionados for uma pasta, ele será aplicado recursivamente para &lt;i&gt;todos&lt;/i&gt; seus itens filhos.&lt;/p&gt;

            &lt;p&gt;A marca de divisão pode conter as seguintes sequências de escape:
                &lt;ul&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\n&lt;/code&gt;&lt;/b&gt;: quebra de linha&lt;/li&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\t&lt;/code&gt;&lt;/b&gt;: tabulação&lt;/li&gt;
                &lt;/ul&gt;
            &lt;/p&gt;

            &lt;p&gt;&lt;b&gt;Marcador:&lt;/b&gt;&lt;/p&gt;
            </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="47"/>
        <source>Split '{}'</source>
        <translation>Separar '{}'</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="51"/>
        <source>Split items</source>
        <translation>Separar itens</translation>
    </message>
</context>
<context>
    <name>storylineView</name>
    <message>
        <location filename="../manuskript/ui/views/storylineView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/storylineView.py" line="36"/>
        <source>Show Plots</source>
        <translation>Mostrar Enredos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/storylineView.py" line="43"/>
        <source>Show Characters</source>
        <translation>Mostrar Personagens</translation>
    </message>
</context>
<context>
    <name>tabSplitter</name>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="67"/>
        <source>Open selected items in that view.</source>
        <translation>Abra itens selecionados nessa vista.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="158"/>
        <source>Split horizontally</source>
        <translation>Dividir horizontalmente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="168"/>
        <source>Close split</source>
        <translation>Fechar a divisão</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="204"/>
        <source>Split vertically</source>
        <translation>Dividir verticalmente</translation>
    </message>
</context>
<context>
    <name>textEditView</name>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="324"/>
        <source>Various</source>
        <translation>Vários</translation>
    </message>
</context>
<context>
    <name>textFormat</name>
    <message>
        <location filename="../manuskript/ui/editors/textFormat_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="18"/>
        <source>CTRL+B</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="19"/>
        <source>CTRL+I</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="20"/>
        <source>CTRL+U</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="21"/>
        <source>CTRL+P</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="22"/>
        <source>CTRL+L</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="23"/>
        <source>CTRL+E</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="24"/>
        <source>CTRL+R</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="25"/>
        <source>CTRL+J</source>
        <translation/>
    </message>
</context>
<context>
    <name>treeView</name>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="48"/>
        <source>Expand {}</source>
        <translation>Expandir {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="52"/>
        <source>Collapse {}</source>
        <translation>Recolher {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="59"/>
        <source>Expand All</source>
        <translation>Expandir Tudo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="63"/>
        <source>Collapse All</source>
        <translation>Recolher Tudo</translation>
    </message>
</context>
<context>
    <name>welcome</name>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="50"/>
        <source>1</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="55"/>
        <source>Templates</source>
        <translation>Modelos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="86"/>
        <source>Empty</source>
        <translation>Vazio</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="225"/>
        <source>Novel</source>
        <translation>Romance</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="230"/>
        <source>Novella</source>
        <translation>Novela</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="235"/>
        <source>Short Story</source>
        <translation>História curta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="247"/>
        <source>Research paper</source>
        <translation>Artigo de pesquisa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="418"/>
        <source>Demo projects</source>
        <translation>Projetos de demonstração</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="177"/>
        <source>Add level</source>
        <translation>Adicionar nível</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="190"/>
        <source>Add word count</source>
        <translation>Adicionar contagem de palavras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="213"/>
        <source>Next time, automatically open last project</source>
        <translation>Na próxima vez, abra automaticamente o último projeto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="238"/>
        <source>Open...</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="248"/>
        <source>Recent</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="258"/>
        <source>Create</source>
        <translation>Criar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="158"/>
        <source>Open project</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="158"/>
        <source>Manuskript project (*.msk);;All files (*)</source>
        <translation>Projeto do Manuskript (*.msk);;Todos arquivos (*)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="172"/>
        <source>Save project as...</source>
        <translation>Salvar o projeto como...</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="196"/>
        <source>Manuskript project (*.msk)</source>
        <translation>Projeto do Manuskript (*.msk)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="188"/>
        <source>Manuskript</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="196"/>
        <source>Create New Project</source>
        <translation>Criar um Novo Projeto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="208"/>
        <source>Warning</source>
        <translation>Alerta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="208"/>
        <source>Overwrite existing project {} ?</source>
        <translation>Substituir projeto existente {} ?</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="224"/>
        <source>Empty fiction</source>
        <translation>Ficção vazia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="448"/>
        <source>Chapter</source>
        <translation>Capítulo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="449"/>
        <source>Scene</source>
        <translation>Cena</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="239"/>
        <source>Trilogy</source>
        <translation>Trilogia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="239"/>
        <source>Book</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="247"/>
        <source>Section</source>
        <translation>Seção</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="246"/>
        <source>Empty non-fiction</source>
        <translation>Não ficção vazia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="308"/>
        <source>words each.</source>
        <translation>palavras cada.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="311"/>
        <source>of</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="335"/>
        <source>Text</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="338"/>
        <source>Something</source>
        <translation>Alguma coisa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="384"/>
        <source>&lt;b&gt;Total:&lt;/b&gt; {} words (~ {} pages)</source>
        <translation>&lt;b&gt;Total:&lt;/b&gt; {} palavras (~ {} páginas)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="405"/>
        <source>Fiction</source>
        <translation>Ficção</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="411"/>
        <source>Non-fiction</source>
        <translation>Não ficção</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="446"/>
        <source>Idea</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="447"/>
        <source>Note</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="450"/>
        <source>Research</source>
        <translation>Pesquisa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="457"/>
        <source>TODO</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="458"/>
        <source>First draft</source>
        <translation>Primeiro rascunho</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="459"/>
        <source>Second draft</source>
        <translation>Segundo rascunho</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="460"/>
        <source>Final</source>
        <translation/>
    </message>
</context>
<context>
    <name>worldModel</name>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="136"/>
        <source>New item</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Fantasy world building</source>
        <translation>Construção do mundo de fantasia</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Physical</source>
        <translation>Físico</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Climate</source>
        <translation>Clima</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Topography</source>
        <translation>Topografia</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Astronomy</source>
        <translation>Astronomia</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Wild life</source>
        <translation>Vida selvagem</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Flora</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>History</source>
        <translation>História</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Races</source>
        <translation>Corridas</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Diseases</source>
        <translation>Doenças</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Cultural</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Customs</source>
        <translation>Costumes</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Food</source>
        <translation>Comida</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Languages</source>
        <translation>Idiomas</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Education</source>
        <translation>Educação</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Dresses</source>
        <translation>Vestidos</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Science</source>
        <translation>Ciência</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Calendar</source>
        <translation>Calendário</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Bodily language</source>
        <translation>Linguagem corporal</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Ethics</source>
        <translation>Ética</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Religion</source>
        <translation>Religião</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Government</source>
        <translation>Governo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Politics</source>
        <translation>Política</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Gender roles</source>
        <translation>Papéis de gênero</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Music and arts</source>
        <translation>Música e artes</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Architecture</source>
        <translation>Arquitetura</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Military</source>
        <translation>Militares</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Technology</source>
        <translation/>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Courtship</source>
        <translation>Namoro</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Demography</source>
        <translation>Demografia</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Transportation</source>
        <translation>Transporte</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Medicine</source>
        <translation>Medicina</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magic system</source>
        <translation>Sistema mágico</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Rules</source>
        <translation>Regras</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Organization</source>
        <translation>Organização</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magical objects</source>
        <translation>Objetos mágicos</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magical places</source>
        <translation>Lugares mágicos</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magical races</source>
        <translation>Corridas Mágicas</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="292"/>
        <source>Important places</source>
        <translation>Lugares importantes</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="293"/>
        <source>Important objects</source>
        <translation>Objetos importantes</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Natural resources</source>
        <translation>Recursos naturais</translation>
    </message>
</context>
</TS>
