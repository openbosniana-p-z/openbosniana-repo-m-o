title:          Philip in Samaria
ID:             32
type:           md
POV:            2
notes:          {P:0:The good news spreads from Jerusalem to Rome}
compile:        2


 5 Philip went down to the city of Samaria, and proclaimed to them the Christ. 6 The multitudes listened with one accord to the things that were spoken by Philip when they heard and saw the signs which he did. 7 For unclean spirits came out of many of those who had them. They came out, crying with a loud voice. Many who had been paralyzed and lame were healed. 8 There was great joy in that city. 