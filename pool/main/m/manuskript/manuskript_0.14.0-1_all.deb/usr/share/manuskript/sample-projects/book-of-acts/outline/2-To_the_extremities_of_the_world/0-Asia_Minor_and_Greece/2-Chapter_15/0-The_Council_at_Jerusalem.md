title:          The Council at Jerusalem
ID:             57
type:           md
notes:          {P:1:Peter needs to broaden his understanding of the Gospel}
                {C:5:Barnabas}
compile:        2


 1 Some men came down from Judea and taught the brothers,* “Unless you are circumcised after the custom of Moses, you can’t be saved.” 2 Therefore when Paul and Barnabas had no small discord and discussion with them, they appointed Paul and Barnabas, and some others of them, to go up to Jerusalem to the apostles and elders about this question. 3 They, being sent on their way by the assembly, passed through both Phoenicia and Samaria, declaring the conversion of the Gentiles. They caused great joy to all the brothers. 4 When they had come to Jerusalem, they were received by the assembly and the apostles and the elders, and they reported everything that God had done with them.
5 But some of the sect of the Pharisees who believed rose up, saying, “It is necessary to circumcise them, and to command them to keep the law of Moses.”
6 The apostles and the elders were gathered together to see about this matter. 7 When there had been much discussion, Peter rose up and said to them, “Brothers, you know that a good while ago God made a choice among you that by my mouth the nations should hear the word of the Good News and believe. 8 God, who knows the heart, testified about them, giving them the Holy Spirit, just like he did to us. 9 He made no distinction between us and them, cleansing their hearts by faith. 10 Now therefore why do you tempt God, that you should put a yoke on the neck of the disciples which neither our fathers nor we were able to bear? 11 But we believe that we are saved through the grace of the Lord Jesus, † just as they are.”
12 All the multitude kept silence, and they listened to Barnabas and Paul reporting what signs and wonders God had done among the nations through them. 13 After they were silent, James answered, “Brothers, listen to me. 14 Simeon has reported how God first visited the nations to take out of them a people for his name. 15 This agrees with the words of the prophets. As it is written,
16 ‘After these things I will return.
I will again build the tabernacle of David, which has fallen.
I will again build its ruins.
I will set it up 17 that the rest of men may seek after the Lord;
all the Gentiles who are called by my name,
says the Lord, who does all these things.’✡
18 “All of God’s works are known to him from eternity. 19 Therefore my judgment is that we don’t trouble those from among the Gentiles who turn to God, 20 but that we write to them that they abstain from the pollution of idols, from sexual immorality, from what is strangled, and from blood. 21 For Moses from generations of old has in every city those who preach him, being read in the synagogues every Sabbath.” 