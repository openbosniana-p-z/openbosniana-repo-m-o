title:          Ananias and Sapphira
ID:             19
type:           md
compile:        2


 1 But a certain man named Ananias, with Sapphira, his wife, sold a possession, 2 and kept back part of the price, his wife also being aware of it, then brought a certain part and laid it at the apostles’ feet. 3 But Peter said, “Ananias, why has Satan filled your heart to lie to the Holy Spirit and to keep back part of the price of the land? 4 While you kept it, didn’t it remain your own? After it was sold, wasn’t it in your power? How is it that you have conceived this thing in your heart? You haven’t lied to men, but to God.”
5 Ananias, hearing these words, fell down and died. Great fear came on all who heard these things. 6 The young men arose and wrapped him up, and they carried him out and buried him. 7 About three hours later, his wife, not knowing what had happened, came in. 8 Peter answered her, “Tell me whether you sold the land for so much.”
She said, “Yes, for so much.”
9 But Peter asked her, “How is it that you have agreed together to tempt the Spirit of the Lord? Behold, the feet of those who have buried your husband are at the door, and they will carry you out.”
10 She fell down immediately at his feet and died. The young men came in and found her dead, and they carried her out and buried her by her husband. 11 Great fear came on the whole assembly, and on all who heard these things. 