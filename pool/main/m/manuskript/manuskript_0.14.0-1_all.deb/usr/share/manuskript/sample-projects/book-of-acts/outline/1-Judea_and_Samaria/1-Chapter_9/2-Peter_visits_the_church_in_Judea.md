title:          Peter visits the church in Judea
ID:             39
type:           md
POV:            0
compile:        2


 32 As Peter went throughout all those parts, he came down also to the saints who lived at Lydda. 33 There he found a certain man named Aeneas, who had been bedridden for eight years, because he was paralyzed. 34 Peter said to him, “Aeneas, Jesus Christ heals you. Get up and make your bed!” Immediately he arose. 35 All who lived at Lydda and in Sharon saw him, and they turned to the Lord.
36 Now there was at Joppa a certain disciple named Tabitha, which when translated, means Dorcas.§ This woman was full of good works and acts of mercy which she did. 37 In those days, she became sick, and died. When they had washed her, they laid her in an upper room. 38 As Lydda was near Joppa, the disciples, hearing that Peter was there, sent two men* to him, imploring him not to delay in coming to them. 39 Peter got up and went with them. When he had come, they brought him into the upper room. All the widows stood by him weeping, and showing the coats and garments which Dorcas had made while she was with them. 40 Peter sent them all out, and knelt down and prayed. Turning to the body, he said, “Tabitha, get up!” She opened her eyes, and when she saw Peter, she sat up. 41 He gave her his hand, and raised her up. Calling the saints and widows, he presented her alive. 42 This became known throughout all Joppa, and many believed in the Lord. 43 He stayed many days in Joppa with a tanner named Simon. 