title:          The Church in Antioch
ID:             44
type:           md
notes:          {P:2:Paul and Barnabas fight}
                {C:5:Barnabas}
compile:        2


 19 They therefore who were scattered abroad by the oppression that arose about Stephen traveled as far as Phoenicia, Cyprus, and Antioch, speaking the word to no one except to Jews only. 20 But there were some of them, men of Cyprus and Cyrene, who, when they had come to Antioch, spoke to the Hellenists,† preaching the Lord Jesus. 21 The hand of the Lord was with them, and a great number believed and turned to the Lord. 22 The report concerning them came to the ears of the assembly which was in Jerusalem. They sent out Barnabas to go as far as Antioch, 23 who, when he had come, and had seen the grace of God, was glad. He exhorted them all, that with purpose of heart they should remain near to the Lord. 24 For he was a good man, and full of the Holy Spirit and of faith, and many people were added to the Lord.
25 Barnabas went out to Tarsus to look for Saul. 26 When he had found him, he brought him to Antioch. For a whole year they were gathered together with the assembly, and taught many people. The disciples were first called Christians in Antioch.
27 Now in these days, prophets came down from Jerusalem to Antioch. 28 One of them named Agabus stood up, and indicated by the Spirit that there should be a great famine all over the world, which also happened in the days of Claudius. 29 As any of the disciples had plenty, each determined to send relief to the brothers who lived in Judea; 30 which they also did, sending it to the elders by the hands of Barnabas and Saul. 