title:          Herod dies
ID:             46
type:           md
POV:            4
notes:          Present:
                - {C:1:Paul}
                - {C:5:Barnabas}
compile:        2


19 When Herod had sought for him, and didn’t find him, he examined the guards, then commanded that they should be put to death. He went down from Judea to Caesarea, and stayed there. 20 Now Herod was very angry with the people of Tyre and Sidon. They came with one accord to him, and, having made Blastus, the king’s personal aide, their friend, they asked for peace, because their country depended on the king’s country for food. 21 On an appointed day, Herod dressed himself in royal clothing, sat on the throne, and gave a speech to them. 22 The people shouted, “The voice of a god, and not of a man!” 23 Immediately an angel of the Lord struck him, because he didn’t give God the glory. Then he was eaten by worms and died.
24 But the word of God grew and multiplied. 25 Barnabas and Saul returned to* Jerusalem when they had fulfilled their service, also taking with them John who was called Mark. 