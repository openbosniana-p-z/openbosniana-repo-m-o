title:          Cornelius calls for Peter
ID:             40
type:           md
POV:            0
notes:          {P:1}
compile:        2


 1 Now there was a certain man in Caesarea, Cornelius by name, a centurion of what was called the Italian Regiment, 2 a devout man, and one who feared God with all his house, who gave gifts for the needy generously to the people, and always prayed to God. 3 At about the ninth hour of the day,* he clearly saw in a vision an angel of God coming to him, and saying to him, “Cornelius!”
4 He, fastening his eyes on him, and being frightened, said, “What is it, Lord?”
He said to him, “Your prayers and your gifts to the needy have gone up for a memorial before God. 5 Now send men to Joppa, and get Simon, who is also called Peter. 6 He is staying with a tanner named Simon, whose house is by the seaside. †
7 When the angel who spoke to him had departed, Cornelius called two of his household servants and a devout soldier of those who waited on him continually. 8 Having explained everything to them, he sent them to Joppa.