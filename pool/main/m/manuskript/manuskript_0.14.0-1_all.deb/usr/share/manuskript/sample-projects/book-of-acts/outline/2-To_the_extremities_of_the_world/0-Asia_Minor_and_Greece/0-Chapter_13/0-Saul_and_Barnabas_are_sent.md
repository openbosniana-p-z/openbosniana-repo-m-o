title:          Saul and Barnabas are sent
ID:             51
type:           md
notes:          {P:2:Paul and Barnabas fight}
                {C:5:Barnabas}
                
                Mention: {C:4:Herod}
compile:        2


 1 Now in the assembly that was at Antioch there were some prophets and teachers: Barnabas, Simeon who was called Niger, Lucius of Cyrene, Manaen the foster brother of Herod the tetrarch, and Saul. 2 As they served the Lord and fasted, the Holy Spirit said, “Separate Barnabas and Saul for me, for the work to which I have called them.”
3 Then, when they had fasted and prayed and laid their hands on them, they sent them away.