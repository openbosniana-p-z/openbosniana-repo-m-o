# --!-- coding: utf8 --!--

# Single source the package version
# https://packaging.python.org/guides/single-sourcing-package-version/

__version__ = "0.14.0"

def getVersion():
    return __version__
