title:          Peter heals a beggar
ID:             13
type:           md
POV:            0
compile:        2


1 Peter and John were going up into the temple at the hour of prayer, the ninth hour.* 2 A certain man who was lame from his mother’s womb was being carried, whom they laid daily at the door of the temple which is called Beautiful, to ask gifts for the needy of those who entered into the temple. 3 Seeing Peter and John about to go into the temple, he asked to receive gifts for the needy. 4 Peter, fastening his eyes on him, with John, said, “Look at us.” 5 He listened to them, expecting to receive something from them. 6 But Peter said, “I have no silver or gold, but what I have, that I give you. In the name of Jesus Christ of Nazareth, get up and walk!” 7 He took him by the right hand and raised him up. Immediately his feet and his ankle bones received strength. 8 Leaping up, he stood and began to walk. He entered with them into the temple, walking, leaping, and praising God. 9 All the people saw him walking and praising God. 10 They recognized him, that it was he who used to sit begging for gifts for the needy at the Beautiful Gate of the temple. They were filled with wonder and amazement at what had happened to him. 