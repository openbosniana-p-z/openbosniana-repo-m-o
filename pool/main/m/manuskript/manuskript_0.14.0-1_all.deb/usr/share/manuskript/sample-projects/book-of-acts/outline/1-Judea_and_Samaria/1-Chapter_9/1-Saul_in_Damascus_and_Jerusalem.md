title:          Saul in Damascus and Jerusalem
ID:             38
type:           md
POV:            1
notes:          {P:2:Paul and Barnabas fight}
                {C:5:Barnabas}
compile:        2


Saul stayed several days with the disciples who were at Damascus. 20 Immediately in the synagogues he proclaimed the Christ, that he is the Son of God. 21 All who heard him were amazed, and said, “Isn’t this he who in Jerusalem made havoc of those who called on this name? And he had come here intending to bring them bound before the chief priests!”
22 But Saul increased more in strength, and confounded the Jews who lived at Damascus, proving that this is the Christ. 23 When many days were fulfilled, the Jews conspired together to kill him, 24 but their plot became known to Saul. They watched the gates both day and night that they might kill him, 25 but his disciples took him by night and let him down through the wall, lowering him in a basket. 26 When Saul had come to Jerusalem, he tried to join himself to the disciples; but they were all afraid of him, not believing that he was a disciple. 27 But Barnabas took him and brought him to the apostles, and declared to them how he had seen the Lord on the way, and that he had spoken to him, and how at Damascus he had preached boldly in the name of Jesus. 28 He was with them entering into§ Jerusalem, 29 preaching boldly in the name of the Lord Jesus.* He spoke and disputed against the Hellenists,† but they were seeking to kill him. 30 When the brothers‡ knew it, they brought him down to Caesarea, and sent him off to Tarsus. 31 So the assemblies throughout all Judea, Galilee, and Samaria had peace, and were built up. They were multiplied, walking in the fear of the Lord and in the comfort of the Holy Spirit. 