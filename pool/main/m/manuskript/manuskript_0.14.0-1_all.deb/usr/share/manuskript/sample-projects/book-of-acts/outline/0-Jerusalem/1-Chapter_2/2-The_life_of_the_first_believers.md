title:          The life of the first believers
ID:             14
type:           md
compile:        2


42 They continued steadfastly in the apostles’ teaching and fellowship, in the breaking of bread, and prayer. 43 Fear came on every soul, and many wonders and signs were done through the apostles. 44 All who believed were together, and had all things in common. 45 They sold their possessions and goods, and distributed them to all, according as anyone had need. 46 Day by day, continuing steadfastly with one accord in the temple, and breaking bread at home, they took their food with gladness and singleness of heart, 47 praising God, and having favor with all the people. The Lord added to the assembly day by day those who were being saved. 