title:          Cyprus
ID:             52
type:           md
notes:          {P:0:The good news spreads from Jerusalem to Rome}
                {C:5:Barnabas}
compile:        2


 4 So, being sent out by the Holy Spirit, they went down to Seleucia. From there they sailed to Cyprus. 5 When they were at Salamis, they proclaimed God’s word in the Jewish synagogues. They also had John as their attendant. 6 When they had gone through the island to Paphos, they found a certain sorcerer, a false prophet, a Jew, whose name was Bar Jesus, 7 who was with the proconsul, Sergius Paulus, a man of understanding. This man summoned Barnabas and Saul, and sought to hear the word of God. 8 But Elymas the sorcerer (for so is his name by interpretation) withstood them, seeking to turn the proconsul away from the faith. 9 But Saul, who is also called Paul, filled with the Holy Spirit, fastened his eyes on him, 10 and said, “You son of the devil, full of all deceit and all cunning, you enemy of all righteousness, will you not cease to pervert the right ways of the Lord? 11 Now, behold, the hand of the Lord is on you, and you will be blind, not seeing the sun for a season!”
Immediately a mist and darkness fell on him. He went around seeking someone to lead him by the hand. 12 Then the proconsul, when he saw what was done, believed, being astonished at the teaching of the Lord. 