title:          The believers share
ID:             18
type:           md
notes:          {C:5:Barnabas}
compile:        2


32 The multitude of those who believed were of one heart and soul. Not one of them claimed that anything of the things which he possessed was his own, but they had all things in common. 33 With great power, the apostles gave their testimony of the resurrection of the Lord Jesus. Great grace was on them all. 34 For neither was there among them any who lacked, for as many as were owners of lands or houses sold them, and brought the proceeds of the things that were sold, 35 and laid them at the apostles’ feet, and distribution was made to each, according as anyone had need. 36 Joses, who by the apostles was also called Barnabas (which is, being interpreted, Son of Encouragement), a Levite, a man of Cyprus by race, 37 having a field, sold it and brought the money and laid it at the apostles’ feet. 