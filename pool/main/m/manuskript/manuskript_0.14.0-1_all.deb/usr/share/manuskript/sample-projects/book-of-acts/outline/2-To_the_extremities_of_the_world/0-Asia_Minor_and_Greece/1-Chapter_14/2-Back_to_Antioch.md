title:          Back to Antioch
ID:             56
type:           md
compile:        2


21 When they had preached the Good News to that city, and had made many disciples, they returned to Lystra, Iconium, and Antioch, 22 strengthening the souls of the disciples, exhorting them to continue in the faith, and that through many afflictions we must enter into God’s Kingdom. 23 When they had appointed elders for them in every assembly, and had prayed with fasting, they commended them to the Lord, on whom they had believed.
24 They passed through Pisidia, and came to Pamphylia. 25 When they had spoken the word in Perga, they went down to Attalia. 26 From there they sailed to Antioch, from where they had been committed to the grace of God for the work which they had fulfilled. 27 When they had arrived, and had gathered the assembly together, they reported all the things that God had done with them, and that he had opened a door of faith to the nations. 28 They stayed there with the disciples for a long time. 