title:          Saul's conversion
ID:             37
type:           md
POV:            1
compile:        2


 1 But Saul, still breathing threats and slaughter against the disciples of the Lord, went to the high priest 2 and asked for letters from him to the synagogues of Damascus, that if he found any who were of the Way, whether men or women, he might bring them bound to Jerusalem. 3 As he traveled, he got close to Damascus, and suddenly a light from the sky shone around him. 4 He fell on the earth, and heard a voice saying to him, “Saul, Saul, why do you persecute me?”
5 He said, “Who are you, Lord?”
The Lord said, “I am Jesus, whom you are persecuting.* 6  But† rise up and enter into the city, then you will be told what you must do.”
7 The men who traveled with him stood speechless, hearing the sound, but seeing no one. 8 Saul arose from the ground, and when his eyes were opened, he saw no one. They led him by the hand, and brought him into Damascus. 9 He was without sight for three days, and neither ate nor drank.
10 Now there was a certain disciple at Damascus named Ananias. The Lord said to him in a vision, “Ananias!”
He said, “Behold, it’s me, Lord.”
11 The Lord said to him, “Arise, and go to the street which is called Straight, and inquire in the house of Judah‡ for one named Saul, a man of Tarsus. For behold, he is praying, 12  and in a vision he has seen a man named Ananias coming in and laying his hands on him, that he might receive his sight.”
13 But Ananias answered, “Lord, I have heard from many about this man, how much evil he did to your saints at Jerusalem. 14 Here he has authority from the chief priests to bind all who call on your name.”
15 But the Lord said to him, “Go your way, for he is my chosen vessel to bear my name before the nations and kings, and the children of Israel. 16  For I will show him how many things he must suffer for my name’s sake.”
17 Ananias departed and entered into the house. Laying his hands on him, he said, “Brother Saul, the Lord, who appeared to you on the road by which you came, has sent me that you may receive your sight and be filled with the Holy Spirit.” 18 Immediately something like scales fell from his eyes, and he received his sight. He arose and was baptized. 19 He took food and was strengthened.