<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>Export</name>
    <message>
        <location filename="../manuskript/exporter/manuskript/__init__.py" line="15"/>
        <source>Default exporter, provides basic formats used by other exporters.</source>
        <translation>Exportador por defecto, proporciona los formatos básicos que utilizan otros exportadores.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="18"/>
        <source>Basic HTML output using the Python module &apos;markdown&apos;.</source>
        <translation>Salida en HTML básico que utiliza el módulo de Python &apos;markdown&apos;.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="19"/>
        <source>Python module &apos;markdown&apos;.</source>
        <translation>Módulo de Python &apos;markdown&apos;.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/HTML.py" line="13"/>
        <source>A little known format modestly used. You know, web sites for example.</source>
        <translation>Un formato poco conocido utilizado modestamente. Ya sabes, páginas web, por ejemplo.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/__init__.py" line="22"/>
        <source>&lt;p&gt;A universal document converter. Can be used to convert Markdown to a wide range of other
    formats.&lt;/p&gt;
    &lt;p&gt;Website: &lt;a href=&quot;http://www.pandoc.org&quot;&gt;http://pandoc.org/&lt;/a&gt;&lt;/p&gt;
    </source>
        <translation>&lt;p&gt;Convertidor de documentos universal. Se puede utilizar para convertir markdown a un amplio
     conjunto de otros formatos.&lt;/p&gt;
    &lt;p&gt;Página web: &lt;a href=&quot;http://www.pandoc.org&quot;&gt;http://pandoc.org/&lt;/a&gt;&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/markdown.py" line="14"/>
        <source>Just like plain text, excepts adds markdown titles.
                          Presupposes that texts are formatted in markdown.</source>
        <translation>Es como el texto plano, excepto que añade títulos de markdown.
                          Presupone que el texto está formateado en markdown.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/markdown.py" line="60"/>
        <source>Preview with highlighter.</source>
        <translation>Previsualización con Markdown Highlighter.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="17"/>
        <source>Plain text</source>
        <translation>Texto plano</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="18"/>
        <source>Simplest export to plain text. Allows you to use your own markup not understood
                  by Manuskript, for example &lt;a href=&apos;www.fountain.io&apos;&gt;Fountain&lt;/a&gt;.</source>
        <translation>La exportación más simple a texto plano. Permite utilizar un formato de marcado propio,
                   no conocido por Manuskript. Por ejemplo, &lt;a href=&apos;www.fountain.io&apos;&gt;Fountain&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="54"/>
        <source>Markdown source</source>
        <translation>Fuente Markdown</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="55"/>
        <source>HTML Source</source>
        <translation>Fuente HTML</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/HTML.py" line="59"/>
        <source>HTML Output</source>
        <translation>Salida HTML</translation>
    </message>
    <message>
        <location filename="../manuskript/converters/pandocConverter.py" line="76"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/outputFormats.py" line="10"/>
        <source>Books that don&apos;t kill trees.</source>
        <translation>Libros que no matan árboles.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/outputFormats.py" line="21"/>
        <source>OpenDocument format. Used by LibreOffice for example.</source>
        <translation>Formato OpenDocument. Utilizado por LibreOffice, por ejemplo.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/outputFormats.py" line="32"/>
        <source>Microsoft Office (.docx) document.</source>
        <translation>Documento en formato de Microsoft Office (.docx).</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/PDF.py" line="18"/>
        <source>Needs LaTeX to be installed.</source>
        <translation>Necesita que LaTeX esté instalado.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="10"/>
        <source>Export to markdown, using pandoc. Allows more formatting options
    than the basic manuskript exporter.</source>
        <translation>Exportar a markdown utilizando pandoc. Permite más opciones de formateo
    que el exportador básico de manuskript.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="22"/>
        <source>reStructuredText is a lightweight markup language.</source>
        <translation>reStructuredText es un lenguaje de marcado ligero.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="33"/>
        <source>LaTeX is a word processor and document markup language used to create
                                              beautiful documents.</source>
        <translation>LaTeX es un procesador de texto y lenguaje de marcado de documentos utilizado
                                              para crear documentos de gran calidad.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="96"/>
        <source>Standalone document (not just a fragment)</source>
        <translation>Documento autónomo (no solo un fragmento)</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="99"/>
        <source>Include a table of contents.</source>
        <translation>Incluye una tabla de contenido.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="102"/>
        <source>Number of sections level to include in TOC: </source>
        <translation>Número de niveles de sección a incluir en la tabla de contenido: </translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="106"/>
        <source>Typographically correct output</source>
        <translation>Salida tipográficamente correcta</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="109"/>
        <source>Normalize the document (cleaner)</source>
        <translation>Normalizar el documento (más claro)</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="111"/>
        <source>Specify the base level for headers: </source>
        <translation>Especificar el nivel de inicio de las cabeceras: </translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="118"/>
        <source>Use reference-style links instead of inline links</source>
        <translation>Usar referencias para los enlaces en lugar de integrados en el texto</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="120"/>
        <source>Use ATX-style headers</source>
        <translation>Utiliza cabeceras tipo ATX</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="122"/>
        <source>Self-contained HTML files, with no dependencies</source>
        <translation>Archivos HTML autocontenidos, sin dependencias externas</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="124"/>
        <source>Use &lt;q&gt; tags for quotes in HTML</source>
        <translation>Utiliza etiquetas &lt;q&gt; para las citas en HTML</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="131"/>
        <source>LaTeX engine used to produce the PDF.</source>
        <translation>Motor LaTeX utilizado para producir el PDF.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="141"/>
        <source>Paper size:</source>
        <translation>Tamaño del papel:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="144"/>
        <source>Font size:</source>
        <translation>Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="147"/>
        <source>Class:</source>
        <translation>Clase:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="150"/>
        <source>Line spacing:</source>
        <translation>Espaciado de línea:</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/PDF.py" line="19"/>
        <source>a valid LaTeX installation. Pandoc recommendations can be found on:
                     &lt;a href=&quot;https://pandoc.org/installing.html&quot;&gt;pandoc.org/installing.html&lt;/a&gt;. If you want Unicode support, you need XeLaTeX.</source>
        <translation>una instalación de LaTeX válida. Vea las recomendaciones de pandoc en:
                     &lt;a href=&quot;http://pandoc.org/installing.html&quot;&gt;http://pandoc.org/installing.html&lt;/a&gt;. Si desea soporte Unicode, necesitará XeLaTeX.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/plainText.py" line="45"/>
        <source>The purpose of this format is to provide a way to exchange information
                                              between outliners and Internet services that can be browsed or controlled
                                              through an outliner.</source>
        <translation>El propósito de este formato es proporcionar una manera de intercambiar información
                                              entre outliners y servicios de Internet que puedan ser explorados
                                              o controlados a través de un outliner.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="114"/>
        <source>Disable YAML metadata block.
Use that if you get YAML related error.</source>
        <translation>Deshabilita el bloque de metadatos YAML.
Úselo si recibe errores de YAML.</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="134"/>
        <source>Convert to ePUB3</source>
        <translation>Convierte a ePUB3</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="51"/>
        <source>Could not process regular expression: 
{}</source>
        <translation>No se ha podido procesar la expresión regular:
{}</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/manuskript/plainText.py" line="71"/>
        <source>Choose output fileâ¦</source>
        <translation>Elija el archivo de salidaâ¦</translation>
    </message>
</context>
<context>
    <name>ExportersManager</name>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="14"/>
        <source>Manage Exporters</source>
        <translation>Configura módulos de exportación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="21"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="66"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="100"/>
        <source>Offers export to</source>
        <translation>Ofrece exportar a</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="184"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="190"/>
        <source>Status:</source>
        <translation>Estado:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="210"/>
        <source>Version:</source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="233"/>
        <source>Path:</source>
        <translation>Ruta:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="258"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager_ui.ui" line="273"/>
        <source>{HelpText}</source>
        <translation>{TextoDeAyuda}</translation>
    </message>
</context>
<context>
    <name>FrequencyAnalyzer</name>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="14"/>
        <source>Frequency Analyzer</source>
        <translation>Analizador de frecuencias</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="24"/>
        <source>Word frequency</source>
        <translation>Frecuencia de palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="37"/>
        <source>Settings</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="49"/>
        <source>Minimum size:</source>
        <translation>Tamaño mínimo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="63"/>
        <source>Exclude words (comma separated):</source>
        <translation>Palabras a excluir (separadas por comas):</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="156"/>
        <source>Analyze</source>
        <translation>Analizar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="107"/>
        <source>Phrase frequency</source>
        <translation>Frecuencia de frases</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="115"/>
        <source>Number of words: from</source>
        <translation>Número de palabras: desde</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequency_ui.ui" line="129"/>
        <source>to</source>
        <translation>hasta</translation>
    </message>
</context>
<context>
    <name>Import</name>
    <message>
        <location filename="../manuskript/importer/markdownImporter.py" line="175"/>
        <source>Markdown import</source>
        <translation>Importar markdown</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/markdownImporter.py" line="179"/>
        <source>&lt;b&gt;Info:&lt;/b&gt; A very simple
                        parser that will go through a markdown document and
                        create items for each titles.&lt;br/&gt;&amp;nbsp;</source>
        <translation>&lt;b&gt;Info:&lt;/b&gt; Un analizador muy sencillo
                        que recorre un documento markdown y crea
                        elementos para cada título.&lt;br/&gt;&amp;nbsp;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="96"/>
        <source>Folder import</source>
        <translation>Importar carpeta</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="100"/>
        <source>&lt;p&gt;&lt;b&gt;Info:&lt;/b&gt; Imports a whole
                        directory structure. Folders are added as folders, and
                        plaintext documents within (you chose which ones by extension)
                        are added as scene.&lt;/p&gt;
                        &lt;p&gt;Only text files are supported (not images, binary or others).&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Info:&lt;/b&gt; Importa la estructura
                        completa de un directorio. Las carpetas se añaden como carpetas, y
                        los archivos de texto plano contenidos (elija cuáles por su extensión)
                        se añaden como escenas.&lt;/p&gt;
                        &lt;p&gt;Sólo se soportan archivos de texto (no imágenes, binarios ni otros).&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="107"/>
        <source>Include only those extensions:</source>
        <translation>Incluir sólo estas extensiones:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="107"/>
        <source>Comma separated values</source>
        <translation>Valores separados por comas</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="112"/>
        <source>Sort items by name</source>
        <translation>Ordenar elementos por nombre</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/folderImporter.py" line="116"/>
        <source>Import folder then files</source>
        <translation>Importar carpeta con sus archivos</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/opmlImporter.py" line="64"/>
        <source>OPML Import</source>
        <translation>Importar OPML</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/opmlImporter.py" line="36"/>
        <source>File open failed.</source>
        <translation>Ha habido un fallo al abrir el archivo.</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/opmlImporter.py" line="64"/>
        <source>This does not appear to be a valid OPML file.</source>
        <translation>No parece ser un archivo OPML válido.</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="57"/>
        <source>Pandoc import</source>
        <translation>Importar Pandoc</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="60"/>
        <source>&lt;b&gt;Info:&lt;/b&gt; Manuskript can
                        import from &lt;b&gt;markdown&lt;/b&gt; or &lt;b&gt;OPML&lt;/b&gt;. Pandoc will
                        convert your document to either (see option below), and
                        then it will be imported in manuskript. One or the other
                        might give better result depending on your document.
                        &lt;br/&gt;&amp;nbsp;</source>
        <translation>&lt;b&gt;Info:&lt;/b&gt; Manuskript puede
                        importar desde &lt;b&gt;;markdown&lt;/b&gt; u &lt;b&gt;OPML&lt;/b&gt;. Pandoc convertirá
                        su documento a uno de ellos (vea la opción de debajo), y
                        después se importará en Manuskript. Dependiendo de su documento
                        podríaa obtener mejores resultados con uno u otro.
                        &lt;br/&gt;&amp;nbsp;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="68"/>
        <source>Import using:</source>
        <translation>Importar usando:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="72"/>
        <source>Wrap lines:</source>
        <translation>Ajustar líneas:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/pandocImporters.py" line="72"/>
        <source>&lt;p&gt;Should pandoc create
                        cosmetic / non-semantic line-breaks?&lt;/p&gt;&lt;p&gt;
                        &lt;b&gt;auto&lt;/b&gt;: wraps at 72 characters.&lt;br&gt;
                        &lt;b&gt;none&lt;/b&gt;: no line wrap.&lt;br&gt;
                        &lt;b&gt;preserve&lt;/b&gt;: tries to preserves line wrap from the
                        original document.&lt;/p&gt;</source>
        <translation>&lt;p&gt;¿Debería insertar pandoc
                        saltos de línea cosméticos / no-semánticos?&lt;/p&gt;&lt;p&gt;
                        &lt;b&gt;auto&lt;/b&gt;: salto a los 72 caracteres.&lt;br&gt;
                        &lt;b&gt;nada&lt;/b&gt;: sin ajuste de línea.&lt;br&gt;
                        &lt;b&gt;preservar&lt;/b&gt;: intenta conservar los ajustes de línea del
                        documento original.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="55"/>
        <source>Mind Map Import</source>
        <translation>Importar Mind Map</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="55"/>
        <source>This does not appear to be a valid Mind Map file.</source>
        <translation>No parece ser un archivo de Mind Map válido.</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="70"/>
        <source>Mind Map import</source>
        <translation>Importar Mind Map</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="73"/>
        <source>Import tip as:</source>
        <translation>Importar sugerencias como:</translation>
    </message>
    <message>
        <location filename="../manuskript/importer/mindMapImporter.py" line="89"/>
        <source>Untitled</source>
        <translation>Sin título</translation>
    </message>
</context>
<context>
    <name>MDEditCompleter</name>
    <message>
        <location filename="../manuskript/ui/views/MDEditCompleter.py" line="73"/>
        <source>Insert reference</source>
        <translation>Insertar referencia</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1647"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="169"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="179"/>
        <source>Subtitle</source>
        <translation>Subtítulo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="189"/>
        <source>Series</source>
        <translation>Serie</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="199"/>
        <source>Volume</source>
        <translation>Volumen</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="226"/>
        <source>Genre</source>
        <translation>Género</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="236"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="249"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1656"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="277"/>
        <source>Email</source>
        <translation>Correo electrónico</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1442"/>
        <source>Summary</source>
        <translation>Resumen</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="322"/>
        <source>Situation:</source>
        <translation>Situación:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1357"/>
        <source>Summary:</source>
        <translation>Resumen:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="345"/>
        <source>One sentence</source>
        <translation>Una frase</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1455"/>
        <source>One paragraph</source>
        <translation>Un párrafo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1460"/>
        <source>One page</source>
        <translation>Una página</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1465"/>
        <source>Full</source>
        <translation>Completo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="420"/>
        <source>One sentence summary</source>
        <translation>Resumen de una frase</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="502"/>
        <source>One paragraph summary</source>
        <translation>Resumen de un párrafo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="540"/>
        <source>Expand each sentence of your one paragraph summary to a paragraph</source>
        <translation>En su resumen de un párrafo, expanda cada frase en un párrafo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="565"/>
        <source>One page summary</source>
        <translation>Resumen de una página</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="590"/>
        <source>Full summary</source>
        <translation>Resumen completo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1094"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="676"/>
        <source>What if...?</source>
        <translation>¿Qué pasaría si...?</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="688"/>
        <source>Characters</source>
        <translation>Personajes</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="713"/>
        <source>Names</source>
        <translation>Nombres</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1607"/>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1203"/>
        <source>Basic info</source>
        <translation>Información básica</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1222"/>
        <source>Importance</source>
        <translation>Importancia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="880"/>
        <source>Motivation</source>
        <translation>Motivación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="890"/>
        <source>Goal</source>
        <translation>Objetivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="900"/>
        <source>Conflict</source>
        <translation>Conflicto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="910"/>
        <source>Epiphany</source>
        <translation>Epifanía</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="920"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;One sentence&lt;br/&gt;summary&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;Resumen de&lt;br/&gt;una frase&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="930"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;One paragraph&lt;br/&gt;summary&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;Resumen de&lt;br/&gt;un párrafo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1021"/>
        <source>Notes</source>
        <translation>Notas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1031"/>
        <source>Detailed info</source>
        <translation>Información detallada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2041"/>
        <source>Plots</source>
        <translation>Tramas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1212"/>
        <source>Plot</source>
        <translation>Trama</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1229"/>
        <source>Character(s)</source>
        <translation>Personaje(s)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1666"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1243"/>
        <source>Result</source>
        <translation>Resultado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1335"/>
        <source>Resolution steps</source>
        <translation>Pasos para la resolución</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2065"/>
        <source>World</source>
        <translation>Mundo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1620"/>
        <source>Populates with empty data</source>
        <translation>Rellena con datos vacíos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1677"/>
        <source>More</source>
        <translation>Más</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1686"/>
        <source>Source of passion</source>
        <translation>Fuente de pasión</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1696"/>
        <source>Source of conflict</source>
        <translation>Causa de conflicto</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1554"/>
        <source>Outline</source>
        <translation>Esquema</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1874"/>
        <source>Editor</source>
        <translation>Redacción</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2005"/>
        <source>Debug</source>
        <translation>Depurar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2018"/>
        <source>FlatData</source>
        <translation>Datos Planos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2028"/>
        <source>Persos</source>
        <translation>Persos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2089"/>
        <source>Labels</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2123"/>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2127"/>
        <source>&amp;Recent</source>
        <translation>&amp;Recientes</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2225"/>
        <source>&amp;Mode</source>
        <translation>&amp;Modo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2147"/>
        <source>&amp;Help</source>
        <translation>A&amp;yuda</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2158"/>
        <source>&amp;Tools</source>
        <translation>&amp;Herramientas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2221"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2254"/>
        <source>&amp;Cheat sheet</source>
        <translation>&amp;Guía rápida</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2288"/>
        <source>Sea&amp;rch</source>
        <translation>&amp;Buscar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2325"/>
        <source>&amp;Navigation</source>
        <translation>&amp;Navegación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2360"/>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2363"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2372"/>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2375"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2384"/>
        <source>Sa&amp;ve as...</source>
        <translation>G&amp;uardar como...</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2387"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Mayús+S</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2396"/>
        <source>&amp;Quit</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2399"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2414"/>
        <source>&amp;Show help texts</source>
        <translation>&amp;Mostrar textos de ayuda</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2417"/>
        <source>Ctrl+Shift+B</source>
        <translation>Ctrl+Mayús+B</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2432"/>
        <source>&amp;Spellcheck</source>
        <translation>&amp;Corrector ortográfico</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2435"/>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2444"/>
        <source>&amp;Labels...</source>
        <translation>&amp;Etiquetas...</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2453"/>
        <source>&amp;Status...</source>
        <translation>E&amp;stado...</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1552"/>
        <source>Tree</source>
        <translation>Árbol</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2469"/>
        <source>&amp;Simple</source>
        <translation>&amp;Sencillo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1553"/>
        <source>Index cards</source>
        <translation>Fichas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2496"/>
        <source>S&amp;ettings</source>
        <translation>&amp;Preferencias</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2499"/>
        <source>F8</source>
        <translation>F8</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2508"/>
        <source>&amp;Close project</source>
        <translation>&amp;Cerrar proyecto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2517"/>
        <source>Co&amp;mpile</source>
        <translation>C&amp;ompilar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2520"/>
        <source>F6</source>
        <translation>F6</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2525"/>
        <source>&amp;Frequency Analyzer</source>
        <translation>A&amp;nalizador de frecuencias</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2477"/>
        <source>&amp;Fiction</source>
        <translation>&amp;Ficción</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="872"/>
        <source>Project {} saved.</source>
        <translation>Proyecto {} guardado.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="896"/>
        <source>Project {} loaded.</source>
        <translation>Proyecto {} cargado.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="902"/>
        <source>Project {} loaded with some errors.</source>
        <translation>Proyecto {} cargado con algunos errores.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1280"/>
        <source> (~{} pages)</source>
        <translation> (~{} páginas)</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1283"/>
        <source>Words: {}{}</source>
        <translation>Palabras: {}{}</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1291"/>
        <source>Book summary</source>
        <translation>Resumen del libro</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1292"/>
        <source>Project tree</source>
        <translation>Árbol del proyecto</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1293"/>
        <source>Metadata</source>
        <translation>Metadata</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1294"/>
        <source>Story line</source>
        <translation>Historia</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1359"/>
        <source>Enter information about your book, and yourself.</source>
        <translation>Introduzca información acerca de su libro y sobre sí mismo.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1362"/>
        <source>The basic situation, in the form of a &apos;What if...?&apos; question. Ex: &apos;What if the most dangerous
                     evil wizard wasn&apos;t able to kill a baby?&apos; (Harry Potter)</source>
        <translation>La situación básica en la forma de una pregunta tipo &quot;¿Que pasaría sí...?&quot;. Ej:&quot;¿Que pasaría si el más peligroso
                     hechicero malvado no pudiera ser capaz de matar un bebé?&quot; (Harry Potter)</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1367"/>
        <source>Take time to think about a one sentence (~50 words) summary of your book. Then expand it to
                     a paragraph, then to a page, then to a full summary.</source>
        <translation>Tómese su tiempo para pensar en resumen de una línea (aproximadamente 50 palabras) de su libro. Después, expándalo hasta
                     un párrafo, después hasta una página y, por último, hasta un resumen completo.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1372"/>
        <source>Create your characters.</source>
        <translation>Cree sus personajes.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1375"/>
        <source>Develop plots.</source>
        <translation>Desarrolle las tramas.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1381"/>
        <source>Create the outline of your masterpiece.</source>
        <translation>Cree el esquema de su obra maestra.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1384"/>
        <source>Write.</source>
        <translation>Escriba.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1387"/>
        <source>Debug info. Sometimes useful.</source>
        <translation>Información de depuración. A veces es útil.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1401"/>
        <source>Dictionary</source>
        <translation>Diccionario</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1544"/>
        <source>Nothing</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1545"/>
        <source>POV</source>
        <translation>Punto de vista</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1546"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1547"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1548"/>
        <source>Compile</source>
        <translation>Compilar</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1571"/>
        <source>Icon color</source>
        <translation>Color del icono</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1572"/>
        <source>Text color</source>
        <translation>Color del texto</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1573"/>
        <source>Background color</source>
        <translation>Color del fondo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1564"/>
        <source>Icon</source>
        <translation>Icono</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1565"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1566"/>
        <source>Background</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1567"/>
        <source>Border</source>
        <translation>Borde</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1568"/>
        <source>Corner</source>
        <translation>Esquina</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2165"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="154"/>
        <source>Book information</source>
        <translation>Información del libro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2534"/>
        <source>&amp;About</source>
        <translation>&amp;Acerca de</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2537"/>
        <source>About Manuskript</source>
        <translation>Acerca de Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="746"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="876"/>
        <source>WARNING: Project {} not saved.</source>
        <translation>ADVERTENCIA: Proyecto {} no guardado.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1378"/>
        <source>Build worlds.  Create hierarchy of broad categories down to specific details.</source>
        <translation>Construir mundos.  Crear una jerarquía desde categorías amplias hasta detalles específicos.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1371"/>
        <source>Add plot step</source>
        <translation>Añadir un paso a la trama (CTRL+Intro)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2546"/>
        <source>&amp;Import…</source>
        <translation>&amp;Importar…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2549"/>
        <source>F7</source>
        <translation>F7</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2558"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2561"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2570"/>
        <source>C&amp;ut</source>
        <translation>C&amp;ortar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2573"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2582"/>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2585"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2594"/>
        <source>&amp;Split…</source>
        <translation>&amp;Dividir…</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2597"/>
        <source>Ctrl+Shift+K</source>
        <translation>Ctrl+Mayús+K</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2606"/>
        <source>Sp&amp;lit at cursor</source>
        <translation>Di&amp;vidir en el cursor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2609"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2621"/>
        <source>Ctrl+M</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2824"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2642"/>
        <source>Del</source>
        <translation>Supr</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2651"/>
        <source>&amp;Move Up</source>
        <translation>&amp;Subir</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2654"/>
        <source>Ctrl+Shift+Up</source>
        <translation>Ctrl+Mayús+Arriba</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2663"/>
        <source>M&amp;ove Down</source>
        <translation>&amp;Bajar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2666"/>
        <source>Ctrl+Shift+Down</source>
        <translation>Ctrl+Mayús+Abajo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2630"/>
        <source>Dupl&amp;icate</source>
        <translation>Dupl&amp;icar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2639"/>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2675"/>
        <source>&amp;Rename</source>
        <translation>&amp;Renombrar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2678"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2235"/>
        <source>Organi&amp;ze</source>
        <translation>Organi&amp;zar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2618"/>
        <source>M&amp;erge</source>
        <translation>&amp;Combinar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2169"/>
        <source>&amp;Format</source>
        <translation>&amp;Formato</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2177"/>
        <source>&amp;Header</source>
        <translation>&amp;Encabezado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2683"/>
        <source>&amp;Level 1 (setext)</source>
        <translation>&amp;Nivel 1 (setext)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2686"/>
        <source>Ctrl+Alt+1</source>
        <translation>Ctrl+Alt+1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2691"/>
        <source>Level &amp;2</source>
        <translation>Nivel &amp;2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2694"/>
        <source>Ctrl+Alt+2</source>
        <translation>Ctrl+Alt+2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2699"/>
        <source>Level &amp;1 (atx)</source>
        <translation>Nivel &amp;1 (atx)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2702"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2707"/>
        <source>L&amp;evel 2</source>
        <translation>N&amp;ivel 2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2710"/>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2715"/>
        <source>Level &amp;3</source>
        <translation>Nivel &amp;3</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2718"/>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2723"/>
        <source>Level &amp;4</source>
        <translation>Nivel &amp;4</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2726"/>
        <source>Ctrl+4</source>
        <translation>Ctrl+4</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2731"/>
        <source>Level &amp;5</source>
        <translation>Nivel &amp;5</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2734"/>
        <source>Ctrl+5</source>
        <translation>Ctrl+5</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2739"/>
        <source>Level &amp;6</source>
        <translation>Nivel &amp;6</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2742"/>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2751"/>
        <source>&amp;Bold</source>
        <translation>&amp;Negrita</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2754"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2763"/>
        <source>&amp;Italic</source>
        <translation>&amp;Cursiva</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2766"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2775"/>
        <source>&amp;Strike</source>
        <translation>&amp;Tachado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2780"/>
        <source>&amp;Verbatim</source>
        <translation>&amp;Literal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2785"/>
        <source>Su&amp;perscript</source>
        <translation>Su&amp;períndice</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2788"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2793"/>
        <source>Subsc&amp;ript</source>
        <translation>Subín&amp;dice</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2796"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2801"/>
        <source>Co&amp;mment block</source>
        <translation>Co&amp;mentario en bloque</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2804"/>
        <source>Ctrl+Shift+C</source>
        <translation>Ctrl+Mayús+C</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2813"/>
        <source>Clear &amp;formats</source>
        <translation>Eliminar &amp;formatos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2816"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2821"/>
        <source>&amp;Comment line(s)</source>
        <translation>&amp;Línea(s) de comentario(s)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2829"/>
        <source>&amp;Ordered list</source>
        <translation>&amp;Lista ordenada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2838"/>
        <source>&amp;Unordered list</source>
        <translation>&amp;Lista no ordenada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2843"/>
        <source>B&amp;lockquote</source>
        <translation>C&amp;ita en bloque</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="1388"/>
        <source>Remove selected plot step(s)</source>
        <translation>Eliminar paso(s) seleccionado(s) de la trama</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="594"/>
        <source>The file {} does not exist. Has it been moved or deleted?</source>
        <translation>El archivo {} no existe. ¿Ha sido movido o eliminado?</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1415"/>
        <source>Install {}{} to use spellcheck</source>
        <translation>Instale {}{} para usar el corrector ortográfico</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1457"/>
        <source>{} has no installed dictionaries</source>
        <translation>{} no tiene diccionarios instalados</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1478"/>
        <source>{}{} is not installed</source>
        <translation>{}{} no está instalado</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="689"/>
        <source>Save project?</source>
        <translation>¿Guardar el proyecto?</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="689"/>
        <source>Save changes to project &quot;{}&quot; before closing?</source>
        <translation>¿Guardar cambios en el proyecto «{}» antes de salir?</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="689"/>
        <source>Your changes will be lost if you don&apos;t save them.</source>
        <translation>Sus cambios se perderán si no los guarda.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1671"/>
        <source>PyQt / Qt versions 5.11 and 5.12 are known to cause a crash which might result in a loss of data.</source>
        <translation>Se conoce que las versiones PyQt / Qt 5.11 y 5.12 pueden causar errores que resulten en pérdida de datos.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1672"/>
        <source>PyQt {} and Qt {} are in use.</source>
        <translation>PyQt {} y Qt {} están en uso.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1678"/>
        <source>Proceed with import at your own risk</source>
        <translation>Proceda con la importación bajo su propio riesgo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="862"/>
        <source>Allow POV</source>
        <translation>Permitir POV</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2852"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2855"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2860"/>
        <source>&amp;Technical Support</source>
        <translation>&amp;Soporte técnico</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2863"/>
        <source>How to obtain technical support for Manuskript.</source>
        <translation>Cómo obtener soporte técnico para Manuskript.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2866"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2871"/>
        <source>&amp;Locate log file...</source>
        <translation>&amp;Abrir archivo de registro...</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2874"/>
        <source>Locate log file</source>
        <translation>Localizar archivo de registro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2877"/>
        <source>Locate the diagnostic log file used for this session.</source>
        <translation>Abrir archivo de registro usado para este sesión.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/mainWindow.ui" line="2880"/>
        <source>Shift+F1</source>
        <translation>Mayús+F1</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1193"/>
        <source>Sorry!</source>
        <translation>¡Lo siento!</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1193"/>
        <source>This session is not being logged.</source>
        <translation>Esta sesión no está registrándose.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1202"/>
        <source>A log file is a Work in Progress!</source>
        <translation>¡Archivo de registro en progreso!</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1202"/>
        <source>The log file &quot;{}&quot; will continue to be written to until Manuskript is closed.</source>
        <translation>El archivo de registro &quot;{}&quot; continuará siendo escrito hasta que Manuskript se cierre.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1202"/>
        <source>It will now be displayed in your file manager, but is of limited use until you close Manuskript.</source>
        <translation>Ahora se mostrará en su gestor de archivos, pero es de uso limitado hasta que usted cierre Manuskript.</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1218"/>
        <source>Error!</source>
        <translation>¡Error!</translation>
    </message>
    <message>
        <location filename="../manuskript/mainWindow.py" line="1218"/>
        <source>An error was encountered while trying to show the log file below in your file manager.</source>
        <translation>Ha habido un error al intentar mostrar el archivo de registro inferior en su gestor de archivos.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="45"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="46"/>
        <source>Shift+F3</source>
        <translation>Mayús+F3</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="50"/>
        <source>Situation</source>
        <translation>Situación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search.py" line="51"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
</context>
<context>
    <name>Search</name>
    <message>
        <location filename="../manuskript/ui/search.py" line="40"/>
        <source>No results found</source>
        <translation>No se han encontrado resultados</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="14"/>
        <source>Settings</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="24"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="526"/>
        <source>Revisions</source>
        <translation>Revisiones</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="34"/>
        <source>Views</source>
        <translation>Vistas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2891"/>
        <source>Labels</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3023"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3097"/>
        <source>Fullscreen</source>
        <translation>Pantalla completa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="82"/>
        <source>General settings</source>
        <translation>Preferencias generales</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="98"/>
        <source>Application settings</source>
        <translation>Preferencias de la aplicación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="247"/>
        <source>Loading</source>
        <translation>Cargando</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="259"/>
        <source>Automatically load last project on startup</source>
        <translation>Cargar automáticamente el último proyecto al iniciar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="278"/>
        <source>Saving</source>
        <translation>Guardando</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="292"/>
        <source>Automatically save every</source>
        <translation>Guardar automáticamente cada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="339"/>
        <source>minutes.</source>
        <translation>minutos.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="375"/>
        <source>If no changes during</source>
        <translation>Si no hay cambios durante</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="422"/>
        <source>seconds.</source>
        <translation>segundos.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="456"/>
        <source>Save on project close</source>
        <translation>Guardar al salir</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="536"/>
        <source>Revisions are a way to keep track of modifications. For each text item, it stores any changes you make to the main text, allowing you to see and restoring previous versions.</source>
        <translation>Las revisiones son una manera de realizar un seguimiento de las modificaciones. Para cada elemento de texto, almacena cualquier cambio que haga en el texto principal, permitiéndole ver y restaurar versiones anteriores.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="546"/>
        <source>Keep revisions</source>
        <translation>Almacenar revisiones</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="562"/>
        <source>S&amp;mart remove</source>
        <translation>B&amp;orrado inteligente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="577"/>
        <source>Keep:</source>
        <translation>Almacenar:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="590"/>
        <source>Smart remove allows you to keep only a certain number of revisions. It is strongly recommended to use it, lest you file will becomes full of thousands of insignificant changes.</source>
        <translation>El borrado inteligente le permite almacenar solo un cierto número de revisiones. Se recomienda encarecidamente que lo use para que su archivo no se llene de miles de cambios insignificantes.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="606"/>
        <source>revisions per day for the last month</source>
        <translation>revisiones por día durante el último mes</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="647"/>
        <source>revisions per minute for the last 10 minutes</source>
        <translation>revisiones por minuto durante los últimos 10 minutos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="660"/>
        <source>revisions per hour for the last day</source>
        <translation>revisiones por hora durante el último día</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="673"/>
        <source>revisions per 10 minutes for the last hour</source>
        <translation>revisiones cada 10 minutos durante la última hora</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="798"/>
        <source>revisions per week till the end of time</source>
        <translation>revisiones por semana hasta el fin de los tiempos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="856"/>
        <source>Views settings</source>
        <translation>Preferencias de visualización</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="874"/>
        <source>Tree</source>
        <translation>Árbol</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2145"/>
        <source>Colors</source>
        <translation>Colores</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1889"/>
        <source>Icon color:</source>
        <translation>Color del icono:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2095"/>
        <source>Nothing</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2100"/>
        <source>POV</source>
        <translation>Punto de vista</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2105"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2110"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2115"/>
        <source>Compile</source>
        <translation>Compilar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1937"/>
        <source>Text color:</source>
        <translation>Color del texto:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1985"/>
        <source>Background color:</source>
        <translation>Color del fondo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1168"/>
        <source>Folders</source>
        <translation>Carpetas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1180"/>
        <source>Show ite&amp;m count</source>
        <translation>Mostrar número de ele&amp;mentos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1315"/>
        <source>Show summary</source>
        <translation>Mostrar resumen</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1264"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1382"/>
        <source>Outline</source>
        <translation>Esquema</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1574"/>
        <source>Visible columns</source>
        <translation>Columnas visibles</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1586"/>
        <source>Goal</source>
        <translation>Objetivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1602"/>
        <source>Word count</source>
        <translation>Número de palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1618"/>
        <source>Percentage</source>
        <translation>Porcentaje</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1698"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1729"/>
        <source>Index cards</source>
        <translation>Fichas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1874"/>
        <source>Item colors</source>
        <translation>Color de los elementos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2033"/>
        <source>Border color:</source>
        <translation>Color del borde:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2081"/>
        <source>Corner color:</source>
        <translation>Color de la esquina:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1741"/>
        <source>Background</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3576"/>
        <source>Color:</source>
        <translation>Color:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2938"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3318"/>
        <source>Image:</source>
        <translation>Imagen:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2131"/>
        <source>Text editor</source>
        <translation>Editor de texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2250"/>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2262"/>
        <source>Family:</source>
        <translation>Familia:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3619"/>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3633"/>
        <source>Misspelled:</source>
        <translation>Errata:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2157"/>
        <source>Background:</source>
        <translation>Fondo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2473"/>
        <source>Paragraphs</source>
        <translation>Párrafos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3660"/>
        <source>Line spacing:</source>
        <translation>Espaciado de linea:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3668"/>
        <source>Single</source>
        <translation>Sencilla</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3673"/>
        <source>1.5 lines</source>
        <translation>1,5 líneas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3678"/>
        <source>Double</source>
        <translation>Doble</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3683"/>
        <source>Proportional</source>
        <translation>Proporcional</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3700"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3716"/>
        <source>Tab width:</source>
        <translation>Anchura del tabulador:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3780"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3802"/>
        <source>Indent 1st line</source>
        <translation>Sangrar la 1ª linea</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3745"/>
        <source>Spacing:</source>
        <translation>Espaciado:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3144"/>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3158"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3168"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3212"/>
        <source>Theme name:</source>
        <translation>Nombre del tema:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3228"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3241"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3271"/>
        <source>Window Background</source>
        <translation>Fondo de la ventana</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3276"/>
        <source>Text Background</source>
        <translation>Fondo del texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3281"/>
        <source>Text Options</source>
        <translation>Opciones de texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3286"/>
        <source>Paragraph Options</source>
        <translation>Opciones de párrafo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3328"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3336"/>
        <source>No Image</source>
        <translation>Sin imagen</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3341"/>
        <source>Tiled</source>
        <translation>En mosaico</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3346"/>
        <source>Centered</source>
        <translation>Centrado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3445"/>
        <source>Stretched</source>
        <translation>Ajustado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3356"/>
        <source>Scaled</source>
        <translation>Escalado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3361"/>
        <source>Zoomed</source>
        <translation>Agrandado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3396"/>
        <source>Opacity:</source>
        <translation>Opacidad:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3422"/>
        <source>Position:</source>
        <translation>Posición:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3810"/>
        <source>Left</source>
        <translation>Izquierda</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3819"/>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3828"/>
        <source>Right</source>
        <translation>Derecha</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3453"/>
        <source>Width:</source>
        <translation>Anchura:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3504"/>
        <source>Corner radius:</source>
        <translation>Radio de la esquina:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3511"/>
        <source>Margins:</source>
        <translation>Márgenes:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3540"/>
        <source>Padding:</source>
        <translation>Relleno:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3596"/>
        <source>Font:</source>
        <translation>Fuente:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="472"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If you check this option, your project will be saved as one single file. Easier to copy or backup, but does not allow collaborative editing, or versioning.&lt;br/&gt;If this is unchecked, your project will be saved as a folder containing many small files.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Si marca esta opción, su proyecto se guardará en un único archivo. Es más fácil de copiar o de guardar, pero no permitirá una edición colaborativa o distintas versiones.&lt;br/&gt;Si está desmarcada, su proyecto se guardará como una carpeta que contendrá múltiples archivos pequeños.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="478"/>
        <source>Save to one single file</source>
        <translation>Guardar en un único archivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1245"/>
        <source>&amp;Nothing</source>
        <translation>&amp;Ninguno</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1833"/>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2750"/>
        <source>Cursor</source>
        <translation>Cursor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2762"/>
        <source>Use block insertion of</source>
        <translation>Usar bloque de inserción de</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2485"/>
        <source>Alignment:</source>
        <translation>Alineación:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3837"/>
        <source>Justify</source>
        <translation>Justificar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="3849"/>
        <source>Alignment</source>
        <translation>Alineación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1066"/>
        <source>Icon Size</source>
        <translation>Tamaño de icono</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1078"/>
        <source>TextLabel</source>
        <translation>EtiquetadeTexto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2797"/>
        <source>Disable blinking</source>
        <translation>Deshabilitar parpadeo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2364"/>
        <source>Text area</source>
        <translation>Área de texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2376"/>
        <source>Max width</source>
        <translation>Anchura máxima</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2408"/>
        <source>Left/Right margins:</source>
        <translation>Márgenes izqdo./derecho:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2437"/>
        <source>Top/Bottom margins:</source>
        <translation>Márgenes superior/inferior:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1219"/>
        <source>S&amp;how progress</source>
        <translation>&amp;Mostrar progreso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1232"/>
        <source>Show summar&amp;y</source>
        <translation>&amp;Mostrar resumen</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1302"/>
        <source>Show p&amp;rogress</source>
        <translation>Mostrar p&amp;rogreso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1845"/>
        <source>Old st&amp;yle</source>
        <translation>Estilo antiguo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2189"/>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2234"/>
        <source>Restore defaults</source>
        <translation>Restaurar valores por defecto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="138"/>
        <source>Style:</source>
        <translation>Estilo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="161"/>
        <source>Language:</source>
        <translation>Idioma:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="184"/>
        <source>Font size:</source>
        <translation>Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="112"/>
        <source>Restarting Manuskript ensures all settings take effect.</source>
        <translation>Reiniciar Manuskript asegura que todos los ajustes surtan efecto.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1193"/>
        <source>Show &amp;word count</source>
        <translation>Mostrar &amp;recuento de palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1276"/>
        <source>&amp;Show word count</source>
        <translation>&amp;Mostrar recuento de palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1858"/>
        <source>&amp;New style</source>
        <translation>&amp;Nuevo estilo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2810"/>
        <source>Typewriter mode</source>
        <translation>Modo máquina de escribir</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2823"/>
        <source>Focus mode</source>
        <translation>Modo concentrado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2837"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2842"/>
        <source>Sentence</source>
        <translation>Frase</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2847"/>
        <source>Line</source>
        <translation>Línea</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="2852"/>
        <source>Paragraph</source>
        <translation>Párrafo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="821"/>
        <source>&lt;p&gt;&lt;b&gt;The Revisions feature has been at the source of many reported issues. In this version of Manuskript it has been turned off by default for new projects in order to provide the best experience.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Why aren&apos;t these issues fixed already? &lt;a href=&quot;https://www.theologeek.ch/manuskript/contribute/&quot;&gt;We need your help to make Manuskript better!&lt;/a&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;La función de Revisiones ha sido la fuente de muchos problemas reportados. En esta versión de Manuskript se ha desactivado para proyectos nuevos para proveer la mejor experiencia posible.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;¿Por qué estos problemas no se han solucionado? &lt;a href=&quot;https://www.theologeek.ch/manuskript/contribute/&quot;&gt;¡Necesitamos su ayuda para mejorar Manuskript!&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="211"/>
        <source>Show progress in chars next
 to words</source>
        <translation>Mostrar progreso en caracteres junto
 a las palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1113"/>
        <source>Char/Word Counter</source>
        <translation>Contador de caracteres/palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1137"/>
        <source>Count spaces as chars</source>
        <translation>Contar espacios como caracteres</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1206"/>
        <source>Show char c&amp;ount</source>
        <translation>Mostrar c&amp;uenta de caracteres</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/settings_ui.ui" line="1289"/>
        <source>Sho&amp;w char count</source>
        <translation>Mos&amp;trar conteo de caracteres</translation>
    </message>
</context>
<context>
    <name>SpellAction</name>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="611"/>
        <source>Spelling Suggestions</source>
        <translation>Sugerencias de ortografía</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="629"/>
        <source>&amp;Add to dictionary</source>
        <translation>&amp;Añadir al diccionario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="682"/>
        <source>&amp;Remove from custom dictionary</source>
        <translation>&amp;Eliminar del diccionario personal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="538"/>
        <source>&amp;New Character</source>
        <translation>&amp;Nuevo personaje</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="545"/>
        <source>&amp;New Plot Item</source>
        <translation>&amp;Nuevo elemento de la trama</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="552"/>
        <source>&amp;New World Item</source>
        <translation>&amp;Nuevo elemento del mundo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="653"/>
        <source>&amp;Correction Suggestions</source>
        <translation>&amp;Sugerencias de corrección</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="662"/>
        <source>&amp;Correction Suggestion</source>
        <translation>&amp;Sugerencia de corrección</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../manuskript/ui/about_ui.ui" line="17"/>
        <source>About Manuskript</source>
        <translation>Acerca de Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/about_ui.ui" line="50"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
</context>
<context>
    <name>aboutDialog</name>
    <message>
        <location filename="../manuskript/ui/about.py" line="28"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/about.py" line="41"/>
        <source>Software Versions in Use:</source>
        <translation>Versiones de software usadas:</translation>
    </message>
</context>
<context>
    <name>abstractModel</name>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="199"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="201"/>
        <source>POV</source>
        <translation>Punto de vista</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="203"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="205"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="207"/>
        <source>Compile</source>
        <translation>Compilar</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="209"/>
        <source>Word count</source>
        <translation>Número de palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/models/abstractModel.py" line="211"/>
        <source>Goal</source>
        <translation>Objetivo</translation>
    </message>
</context>
<context>
    <name>basicItemView</name>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="38"/>
        <source>POV:</source>
        <translation>Punto de vista:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="55"/>
        <source>Goal:</source>
        <translation>Meta:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="80"/>
        <source>Word count</source>
        <translation>Número de palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="92"/>
        <source>One line summary</source>
        <translation>Resumen de una línea</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/basicItemView_ui.ui" line="99"/>
        <source>Few sentences summary:</source>
        <translation>Resumen de unas pocas frases:</translation>
    </message>
</context>
<context>
    <name>characterModel</name>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="205"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../manuskript/models/characterModel.py" line="207"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
</context>
<context>
    <name>characterTreeView</name>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="32"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="32"/>
        <source>Secondary</source>
        <translation>Secundario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/characterTreeView.py" line="32"/>
        <source>Minor</source>
        <translation>Menor</translation>
    </message>
</context>
<context>
    <name>cheatSheet</name>
    <message>
        <location filename="../manuskript/ui/cheatSheet_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet_ui.ui" line="46"/>
        <source>Filter (type the name of anything in your project)</source>
        <translation>Filtro (escriba el nombre de cualquier elemento de su proyecto)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Minor</source>
        <translation>Menor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Secondary</source>
        <translation>Secundario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="113"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="91"/>
        <source>Characters</source>
        <translation>Personajes</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="104"/>
        <source>Texts</source>
        <translation>Textos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="116"/>
        <source>Plots</source>
        <translation>Tramas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/cheatSheet.py" line="120"/>
        <source>World</source>
        <translation>Mundo</translation>
    </message>
</context>
<context>
    <name>cmbOutlineCharacterChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="34"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Secondary</source>
        <translation>Secundario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="36"/>
        <source>Minor</source>
        <translation>Menor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineCharacterChoser.py" line="136"/>
        <source>Various</source>
        <translation>Varios</translation>
    </message>
</context>
<context>
    <name>cmbOutlineLabelChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineLabelChoser.py" line="113"/>
        <source>Various</source>
        <translation>Varios</translation>
    </message>
</context>
<context>
    <name>cmbOutlineStatusChoser</name>
    <message>
        <location filename="../manuskript/ui/views/cmbOutlineStatusChoser.py" line="112"/>
        <source>Various</source>
        <translation>Varios</translation>
    </message>
</context>
<context>
    <name>collapsibleDockWidgets</name>
    <message>
        <location filename="../manuskript/ui/collapsibleDockWidgets.py" line="26"/>
        <source>Dock Widgets Toolbar</source>
        <translation>Anclar barra de herramientas</translation>
    </message>
</context>
<context>
    <name>completer</name>
    <message>
        <location filename="../manuskript/ui/editors/completer_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
</context>
<context>
    <name>corkDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/corkDelegate.py" line="70"/>
        <source>One line summary</source>
        <translation>Resumen de una línea</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/corkDelegate.py" line="100"/>
        <source>Full summary</source>
        <translation>Resumen completo</translation>
    </message>
</context>
<context>
    <name>editorWidget_ui</name>
    <message>
        <location filename="../manuskript/ui/editors/editorWidget_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
</context>
<context>
    <name>exporter</name>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="65"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="22"/>
        <source>Export to:</source>
        <translation>Exportar a:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="32"/>
        <source>Manage exporters</source>
        <translation>Gestionar módulos de exportación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="103"/>
        <source>Preview</source>
        <translation>Previsualizar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exporter_ui.ui" line="81"/>
        <source>Settings</source>
        <translation>Preferencias</translation>
    </message>
</context>
<context>
    <name>exporterDialog</name>
    <message>
        <location filename="../manuskript/ui/exporters/exporter.py" line="64"/>
        <source>{} (not implemented yet)</source>
        <translation>{} (sin implementar aún)</translation>
    </message>
</context>
<context>
    <name>exporterSettings</name>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="50"/>
        <source>Content</source>
        <translation>Contenido</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="56"/>
        <source>Decide here what will be included in the final export.</source>
        <translation>Decida aquí lo que se incluirá en la exportación final.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="85"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="90"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="326"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="118"/>
        <source>I need more granularity</source>
        <translation>Necesito más granularidad</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="127"/>
        <source>Fi&amp;lters</source>
        <translation>Fi&amp;ltros</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="142"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filters what items will be included in the final export.&lt;br/&gt;&lt;span style=&quot; color:#773333;&quot;&gt;(Not fully implemented yet.)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtra los elementos que se incluirán en la exportación final.&lt;br/&gt;&lt;span style=&quot;color:#773333;&quot;&gt;(Aún no está completamente desarrollado)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="149"/>
        <source>Ignore compile status (include all items)</source>
        <translation>Ignorar el estado de compilación (incluye todos los elementos)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="156"/>
        <source>Subitems of:</source>
        <translation>Subelementos de:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="170"/>
        <source>Labels</source>
        <translation>Etiquetas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="177"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="229"/>
        <source>Separations</source>
        <translation>Separadores</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="241"/>
        <source>Between folders:</source>
        <translation>Entre carpetas:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="86"/>
        <source>Empty line</source>
        <translation>Línea vacía</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="105"/>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="367"/>
        <source>Between texts:</source>
        <translation>Entre textos:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="493"/>
        <source>Between folder and text:</source>
        <translation>Entre carpeta y texto:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="619"/>
        <source>Between text and folder:</source>
        <translation>Entre texto y carpeta:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="764"/>
        <source>Transformations</source>
        <translation>Transformaciones</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="773"/>
        <source>Typographic replacements:</source>
        <translation>Reemplazos tipográficos:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="802"/>
        <source>Replace double quotes (&quot;) with:</source>
        <translation>Reemplazar comillas dobles (&quot;) con:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="911"/>
        <source>Replace single quotes (&apos;) with:</source>
        <translation>Reemplazar comillas simples (&apos;) con:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1020"/>
        <source>Remove multiple spaces</source>
        <translation>Eliminar espaciado múltiple</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1030"/>
        <source>Custom replacements:</source>
        <translation>Reemplazos personalizados:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1049"/>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1054"/>
        <source>Replace</source>
        <translation>Reemplazar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1059"/>
        <source>With</source>
        <translation>Con</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1064"/>
        <source>RegExp</source>
        <translation>Expresión Regular</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1067"/>
        <source>If checked, uses regular expression for replacement. If unchecked, replaced as plain text.</source>
        <translation>Si está marcado, usa una expresión regular para el reemplazo, si no, reemplaza como texto plano.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1151"/>
        <source>Preview</source>
        <translation>Previsualizar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1157"/>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1163"/>
        <source>Font:</source>
        <translation>Fuente:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="1173"/>
        <source>Font size:</source>
        <translation>Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="320"/>
        <source>Folder</source>
        <translation>Carpeta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="343"/>
        <source>{}Level {} folder</source>
        <translation>{}Nivel {} carpeta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings.py" line="346"/>
        <source>{}Level {} text</source>
        <translation>{}Nivel {} texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="788"/>
        <source>Replace ... with â¦</source>
        <translation>Reemplazar ... por â¦</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/manuskript/plainTextSettings_ui.ui" line="795"/>
        <source>Replace --- with â</source>
        <translation>Reemplazar --- con â</translation>
    </message>
</context>
<context>
    <name>exportersManager</name>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="81"/>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="87"/>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="93"/>
        <source>Not found</source>
        <translation>No encontrado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="96"/>
        <source>{} not found. Install it, or set path manually.</source>
        <translation>{} no encontrado. Instálelo o establezca la ruta manualmente.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="124"/>
        <source>&lt;b&gt;Status:&lt;/b&gt; uninstalled.</source>
        <translation>&lt;b&gt;Estado: &lt;/b&gt; sin instalar.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="126"/>
        <source>&lt;b&gt;Requires:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Requiere: &lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/exporters/exportersManager.py" line="133"/>
        <source>Set {} executable path.</source>
        <translation>Establecer {} ruta del ejecutable.</translation>
    </message>
</context>
<context>
    <name>frequencyAnalyzer</name>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="70"/>
        <source>Phrases</source>
        <translation>Frases</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="108"/>
        <source>Frequency</source>
        <translation>Frecuencia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/frequencyAnalyzer.py" line="108"/>
        <source>Word</source>
        <translation>Palabra</translation>
    </message>
</context>
<context>
    <name>fullScreenEditor</name>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="133"/>
        <source>Theme:</source>
        <translation>Tema:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="364"/>
        <source>{} words / {}</source>
        <translation>{} palabras / {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="368"/>
        <source>{} words</source>
        <translation>{} palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="153"/>
        <source>Spellcheck</source>
        <translation>Correción ortográfica</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="154"/>
        <source>Navigation</source>
        <translation>Navegación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="155"/>
        <source>New Text</source>
        <translation>Texto nuevo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="156"/>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="157"/>
        <source>Title: Show Full Path</source>
        <translation>Título: Mostrar ruta completa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="159"/>
        <source>Theme selector</source>
        <translation>Selector de temas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="160"/>
        <source>Word count</source>
        <translation>Número de palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="161"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="162"/>
        <source>Progress: Auto Show/Hide</source>
        <translation>Progreso: Mostrar/Ocultar automáticamente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="163"/>
        <source>Clock</source>
        <translation>Reloj</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="164"/>
        <source>Clock: Show Seconds</source>
        <translation>Reloj: Mostrar segundos</translation>
    </message>
</context>
<context>
    <name>generalSettings</name>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="41"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="55"/>
        <source>Split scenes at:</source>
        <translation>Dividir escenas en:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="65"/>
        <source>\n---\n</source>
        <translation>\n---\n</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="72"/>
        <source>Trim long titles (&gt; 32 chars)</source>
        <translation>Recortar títulos largos (&gt; 32 caracteres)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="86"/>
        <source>Import under:</source>
        <translation>Importar bajo:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/generalSettings_ui.ui" line="93"/>
        <source>Import in a top-level folder</source>
        <translation>Importar en una carpeta de nivel superior</translation>
    </message>
</context>
<context>
    <name>helpLabel</name>
    <message>
        <location filename="../manuskript/ui/helpLabel.py" line="12"/>
        <source>If you don&apos;t wanna see me, you can hide me in Help menu.</source>
        <translation>Si no quiere verme, puede ocultarme en el menú Ayuda.</translation>
    </message>
</context>
<context>
    <name>importer</name>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="119"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="22"/>
        <source>Format:</source>
        <translation>Formato:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="45"/>
        <source>Choose file</source>
        <translation>Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="75"/>
        <source>Clear file</source>
        <translation>Eliminar archivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="160"/>
        <source>Preview</source>
        <translation>Previsualizar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/importers/importer_ui.ui" line="138"/>
        <source>Settings</source>
        <translation>Preferencias</translation>
    </message>
</context>
<context>
    <name>lineEditView</name>
    <message>
        <location filename="../manuskript/ui/views/lineEditView.py" line="114"/>
        <source>Various</source>
        <translation>Varios</translation>
    </message>
</context>
<context>
    <name>locker</name>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="26"/>
        <source>Lock screen:</source>
        <translation>Bloquear pantalla:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="33"/>
        <source>Word target</source>
        <translation>Objetivo de palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="40"/>
        <source>Time target</source>
        <translation>Objetivo de tiempo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="47"/>
        <source> words</source>
        <translation> palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="63"/>
        <source> minutes</source>
        <translation> minutos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker_ui.ui" line="79"/>
        <source>Lock !</source>
        <translation>¡Bloquear!</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="94"/>
        <source>~{} h.</source>
        <translation>~{} h.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="96"/>
        <source>~{} mn.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="100"/>
        <source>{}:{}</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="102"/>
        <source>{} s.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="104"/>
        <source>{} remaining</source>
        <translation>{} restantes</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/locker.py" line="109"/>
        <source>{} words remaining</source>
        <translation>{} palabras restantes</translation>
    </message>
</context>
<context>
    <name>mainEditor</name>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="67"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="83"/>
        <source>Index cards</source>
        <translation>Fichas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="102"/>
        <source>Outline</source>
        <translation>Esquema</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="198"/>
        <source>F11</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="251"/>
        <source>Root</source>
        <translation>Raíz</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="47"/>
        <source>Go to parent item</source>
        <translation>Ir al elemento padre</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor_ui.ui" line="57"/>
        <source>Alt+Up</source>
        <translation>Alt+Arriba</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="358"/>
        <source>{} words </source>
        <translation>{} palabras </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="339"/>
        <source>({} chars) {}  words / {} </source>
        <translation>({} caracteres) {}  palabras / {} </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="345"/>
        <source>{}  words / {} </source>
        <translation>{}  palabras / {} </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="360"/>
        <source>{} chars</source>
        <translation>{} caracteres</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/mainEditor.py" line="354"/>
        <source>{} chars </source>
        <translation>{} caracteres </translation>
    </message>
</context>
<context>
    <name>markdownSettings</name>
    <message>
        <location filename="../manuskript/exporter/manuskript/markdown.py" line="58"/>
        <source>Markdown</source>
        <translation>Markdown</translation>
    </message>
</context>
<context>
    <name>metadataView</name>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="41"/>
        <source>Properties</source>
        <translation>Propiedades</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="81"/>
        <source>Summary</source>
        <translation>Resumen</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="114"/>
        <source>One line summary</source>
        <translation>Resumen de una línea</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="140"/>
        <source>Full summary</source>
        <translation>Resumen completo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="180"/>
        <source>Notes / References</source>
        <translation>Notas / Referencias</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/metadataView_ui.ui" line="190"/>
        <source>Revisions</source>
        <translation>Revisiones</translation>
    </message>
</context>
<context>
    <name>myPanel</name>
    <message>
        <location filename="../manuskript/ui/editors/fullScreenEditor.py" line="599"/>
        <source>Auto-hide</source>
        <translation>Autoocultar</translation>
    </message>
</context>
<context>
    <name>outlineBasics</name>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="134"/>
        <source>Set POV</source>
        <translation>Establecer PDV</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="136"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="163"/>
        <source>Set Status</source>
        <translation>Establecer Estado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="179"/>
        <source>Set Label</source>
        <translation>Establecer Etiqueta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="283"/>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="142"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="143"/>
        <source>Secondary</source>
        <translation>Secundario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="144"/>
        <source>Minor</source>
        <translation>Menor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="197"/>
        <source>Set Custom Icon</source>
        <translation>Establecer icono personalizado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="198"/>
        <source>Restore to default</source>
        <translation>Restaurar valores por defecto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="61"/>
        <source>Root</source>
        <translation>Raíz</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="75"/>
        <source>Open {} items in new tabs</source>
        <translation>Abrir {} elementos en pestañas nuevas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="78"/>
        <source>Open {} in a new tab</source>
        <translation>Abrir {} en una nueva pestaña</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="328"/>
        <source>About to remove</source>
        <translation>A punto de borrar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="434"/>
        <source>Select at least two items. Folders are ignored.</source>
        <translation>Seleccione al menos dos elementos. Las carpetas no se tienen en cuenta.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="443"/>
        <source>All items must be on the same level (share the same parent).</source>
        <translation>Todos los elementos deben estar en el mismo nivel (tener el mismo padre).</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="88"/>
        <source>New &amp;Folder</source>
        <translation>Nueva &amp;carpeta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="94"/>
        <source>New &amp;Text</source>
        <translation>Nuevo &amp;texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="108"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="103"/>
        <source>C&amp;ut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="113"/>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="125"/>
        <source>&amp;Rename</source>
        <translation>&amp;Renombrar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="119"/>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="315"/>
        <source>You&apos;re about to delete {} item(s).</source>
        <translation>Va a eliminar {} elemento(s).</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineBasics.py" line="325"/>
        <source>Are you sure?</source>
        <translation>¿Está seguro/a?</translation>
    </message>
</context>
<context>
    <name>outlineCharacterDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="141"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Secondary</source>
        <translation>Secundario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/outlineDelegates.py" line="143"/>
        <source>Minor</source>
        <translation>Menor</translation>
    </message>
</context>
<context>
    <name>outlineItem</name>
    <message>
        <location filename="../manuskript/models/outlineItem.py" line="256"/>
        <source>{} words / {} ({})</source>
        <translation>{} palabras / {} ({})</translation>
    </message>
    <message>
        <location filename="../manuskript/models/outlineItem.py" line="261"/>
        <source>{} words</source>
        <translation>{} palabras</translation>
    </message>
</context>
<context>
    <name>pandocSettings</name>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="166"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="180"/>
        <source>Table of Content</source>
        <translation>Tabla de contenido</translation>
    </message>
    <message>
        <location filename="../manuskript/exporter/pandoc/abstractPlainText.py" line="185"/>
        <source>Custom settings for {}</source>
        <translation>Preferencias personalizadas para {}</translation>
    </message>
</context>
<context>
    <name>persosProxyModel</name>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="16"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="17"/>
        <source>Secondary</source>
        <translation>Secundario</translation>
    </message>
    <message>
        <location filename="../manuskript/models/persosProxyModel.py" line="18"/>
        <source>Minors</source>
        <translation>Menor</translation>
    </message>
</context>
<context>
    <name>plotDelegate</name>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Promise</source>
        <translation>Promesa</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Problem</source>
        <translation>Problema</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Resolution</source>
        <translation>Resolución</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Try / Fail</source>
        <translation>Intento / Fallo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>No and</source>
        <translation>No y</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Yes but</source>
        <translation>Sí, pero</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Freytag&apos;s pyramid</source>
        <translation>Pirámide de Freytag</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Exposition</source>
        <translation>Exposición</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Rising action</source>
        <translation>Aumento de la acción</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Climax</source>
        <translation>Clímax</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Falling action</source>
        <translation>Caída de la acción</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Three acts</source>
        <translation>Tres actos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Setup</source>
        <translation>1. Planteamiento</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Inciting event</source>
        <translation>1. Cruce del primer umbral</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>1. Turning point</source>
        <translation>1. Punto crítico</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Choice</source>
        <translation>2. Elección</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Reversal</source>
        <translation>2. Cambio de rumbo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>2. Disaster</source>
        <translation>2. Desastre</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Stand up</source>
        <translation>3. Recuperación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Climax</source>
        <translation>3. Clímax</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>3. Ending</source>
        <translation>3. Resolución</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Hero&apos;s journey</source>
        <translation>El viaje del héroe</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Ordinary world</source>
        <translation>Mundo ordinario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Call to adventure</source>
        <translation>Llamada de la aventura</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Refusal of the call</source>
        <translation>Rechazo de la llamada</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Meeting with mentor</source>
        <translation>Encuentro con el mentor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Tests</source>
        <translation>Pruebas, aliados y enemigos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Approach</source>
        <translation>Acercamiento</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Abyss</source>
        <translation>Prueba difícil o traumática</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Reward / Revelation</source>
        <translation>Recompensa / Revelación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Transformation</source>
        <translation>Transformación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Atonement</source>
        <translation>Expiación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotDelegate.py" line="33"/>
        <source>Return</source>
        <translation>Regreso</translation>
    </message>
</context>
<context>
    <name>plotModel</name>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="144"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="146"/>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="179"/>
        <source>New step</source>
        <translation>Siguiente paso</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="249"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="249"/>
        <source>Secondary</source>
        <translation>Secundario</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotModel.py" line="249"/>
        <source>Minor</source>
        <translation>Menor</translation>
    </message>
</context>
<context>
    <name>plotTreeView</name>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="127"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="127"/>
        <source>Secondary</source>
        <translation>Secundario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="127"/>
        <source>Minor</source>
        <translation>Menor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/plotTreeView.py" line="187"/>
        <source>**Plot:** {}</source>
        <translation>**Trama:** {}</translation>
    </message>
</context>
<context>
    <name>plotsProxyModel</name>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="22"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="23"/>
        <source>Secondary</source>
        <translation>Secundario</translation>
    </message>
    <message>
        <location filename="../manuskript/models/plotsProxyModel.py" line="24"/>
        <source>Minors</source>
        <translation>Menor</translation>
    </message>
</context>
<context>
    <name>propertiesView</name>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="195"/>
        <source>POV</source>
        <translation>Punto de vista</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="215"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="235"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="255"/>
        <source>Compile</source>
        <translation>Compilar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="269"/>
        <source>Goal</source>
        <translation>Objetivo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/propertiesView_ui.ui" line="291"/>
        <source>Word count</source>
        <translation>Número de palabras</translation>
    </message>
</context>
<context>
    <name>references</name>
    <message>
        <location filename="../manuskript/models/references.py" line="501"/>
        <source>Not a reference: {}.</source>
        <translation>No es una referencia: {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="399"/>
        <source>Unknown reference: {}.</source>
        <translation>Referencia desconocida: {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="106"/>
        <source>Path:</source>
        <translation>Ruta:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="107"/>
        <source>Stats:</source>
        <translation>Estadísticas:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="108"/>
        <source>POV:</source>
        <translation>Punto de vista:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="109"/>
        <source>Status:</source>
        <translation>Estado:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="110"/>
        <source>Label:</source>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="111"/>
        <source>Short summary:</source>
        <translation>Resumen corto:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="112"/>
        <source>Long summary:</source>
        <translation>Resumen largo:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="113"/>
        <source>Notes:</source>
        <translation>Notas:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="201"/>
        <source>Basic info</source>
        <translation>Información básica</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="202"/>
        <source>Detailed info</source>
        <translation>Información detallada</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="203"/>
        <source>POV of:</source>
        <translation>PDV de:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="364"/>
        <source>Go to {}.</source>
        <translation>Ir a {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="359"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="281"/>
        <source>Result</source>
        <translation>Resultado</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="282"/>
        <source>Characters</source>
        <translation>Personajes</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="283"/>
        <source>Resolution steps</source>
        <translation>Pasos para la resolución</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="360"/>
        <source>Passion</source>
        <translation>Pasión</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="361"/>
        <source>Conflict</source>
        <translation>Conflicto</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="506"/>
        <source>Folder: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Carpeta: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="508"/>
        <source>Text: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Texto: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="513"/>
        <source>Character: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Personaje: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="516"/>
        <source>Plot: &lt;b&gt;{}&lt;/b&gt;</source>
        <translation>Trama: &lt;b&gt;{}&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="519"/>
        <source>World: &lt;b&gt;{name}&lt;/b&gt;{path}</source>
        <translation>Mundo: &lt;b&gt;{name}&lt;/b&gt;{path}</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="498"/>
        <source>&lt;b&gt;Unknown reference:&lt;/b&gt; {}.</source>
        <translation>&lt;b&gt;Referencia desconocida:&lt;/b&gt; {}.</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="592"/>
        <source>Referenced in:</source>
        <translation>Referenciado en:</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="212"/>
        <source>Motivation</source>
        <translation>Motivación</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="213"/>
        <source>Goal</source>
        <translation>Objetivo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="215"/>
        <source>Epiphany</source>
        <translation>Epifanía</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="216"/>
        <source>Short summary</source>
        <translation>Resumen corto</translation>
    </message>
    <message>
        <location filename="../manuskript/models/references.py" line="217"/>
        <source>Longer summary</source>
        <translation>Resumen largo</translation>
    </message>
</context>
<context>
    <name>revisions</name>
    <message>
        <location filename="../manuskript/ui/revisions_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions_ui.ui" line="107"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="257"/>
        <source>Restore</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="258"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="45"/>
        <source>Show modifications</source>
        <translation>Mostrar modificaciones</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="52"/>
        <source>Show ancient version</source>
        <translation>Mostrar versión antigua</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="60"/>
        <source>Show spaces</source>
        <translation>Mostrar espacios</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="66"/>
        <source>Show modifications only</source>
        <translation>Mostrar sólo modificaciones</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="110"/>
        <source>{} years ago</source>
        <translation>Hace {} años</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="112"/>
        <source>{} months ago</source>
        <translation>Hace {} meses</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="114"/>
        <source>{} days ago</source>
        <translation>Hace {} días</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="116"/>
        <source>1 day ago</source>
        <translation>Hace 1 día</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="118"/>
        <source>{} hours ago</source>
        <translation>Hace {} horas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="120"/>
        <source>{} minutes ago</source>
        <translation>Hace {} minutos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="122"/>
        <source>{} seconds ago</source>
        <translation>Hace {} segundos</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="182"/>
        <source>Line {}:</source>
        <translation>Linea {}:</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/revisions.py" line="261"/>
        <source>Clear all</source>
        <translation>Limpiar todo</translation>
    </message>
</context>
<context>
    <name>search</name>
    <message>
        <location filename="../manuskript/ui/search_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/search_ui.ui" line="46"/>
        <source>Search for...</source>
        <translation>Buscar...</translation>
    </message>
</context>
<context>
    <name>settingsWindow</name>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="674"/>
        <source>New status</source>
        <translation>Nuevo estado</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="695"/>
        <source>New label</source>
        <translation>Nueva etiqueta</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="731"/>
        <source>newtheme</source>
        <translation>nuevotema</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="741"/>
        <source>New theme</source>
        <translation>Nuevo tema</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="773"/>
        <source> (read-only)</source>
        <translation> (sólo lectura)</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="534"/>
        <source>Open Image</source>
        <translation>Abrir imagen</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="534"/>
        <source>Image files (*.jpg; *.jpeg; *.png)</source>
        <translation>Archivos de imágenes (*.jpg; *.jpeg; *.png)</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="550"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="547"/>
        <source>Unable to load selected file</source>
        <translation>Ha sido imposible cargar el archivo seleccionado</translation>
    </message>
    <message>
        <location filename="../manuskript/settingsWindow.py" line="550"/>
        <source>Unable to add selected image:
{}</source>
        <translation>Ha sido imposible añadir la imagen seleccionada:
{}</translation>
    </message>
</context>
<context>
    <name>sldImportance</name>
    <message>
        <location filename="../manuskript/ui/views/sldImportance_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance_ui.ui" line="39"/>
        <source>TextLabel</source>
        <translation>EtiquetadeTexto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="29"/>
        <source>Minor</source>
        <translation>Menor</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="30"/>
        <source>Secondary</source>
        <translation>Secundario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/sldImportance.py" line="31"/>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
</context>
<context>
    <name>splitDialog</name>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="19"/>
        <source>
            &lt;p&gt;Split selected item(s) at the given mark.&lt;/p&gt;

            &lt;p&gt;If one of the selected item is a folder, it will be applied
            recursively to &lt;i&gt;all&lt;/i&gt; of it&apos;s children items.&lt;/p&gt;

            &lt;p&gt;The split mark can contain following escape sequences:
                &lt;ul&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\n&lt;/code&gt;&lt;/b&gt;: line break&lt;/li&gt;
                    &lt;li&gt;&lt;b&gt;&lt;code&gt;\t&lt;/code&gt;&lt;/b&gt;: tab&lt;/li&gt;
                &lt;/ul&gt;
            &lt;/p&gt;

            &lt;p&gt;&lt;b&gt;Mark:&lt;/b&gt;&lt;/p&gt;
            </source>
        <translation>
            &lt;p&gt;Divide los elemento(s) seleccionado(s) en la marca indicada.&lt;/p&gt;

 &lt;p&gt;Si uno de los elementos seleccionados es una carpeta, se aplicará
 recursivamente a &lt;i&gt;todos&lt;/i&gt; sus elementos hijos.&lt;/p&gt;

 &lt;p&gt;La marca de división puede contener las siguientes secuencias de escape:
 &lt;ul&gt;
 &lt;li&gt;&lt;b&gt;&lt;code&gt;\n&lt;/code&gt;&lt;/b&gt;: salto de línea&lt;/li&gt;
 &lt;li&gt;&lt;b&gt;&lt;code&gt;\t&lt;/code&gt;&lt;/b&gt;: tabulador&lt;/li&gt;
 &lt;/ul&gt;
 &lt;/p&gt;

 &lt;p&gt;&lt;b&gt;Marca:&lt;/b&gt;&lt;/p&gt;
            </translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="47"/>
        <source>Split &apos;{}&apos;</source>
        <translation>Dividir &apos;{}&apos;</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/tools/splitDialog.py" line="51"/>
        <source>Split items</source>
        <translation>Dividir elementos</translation>
    </message>
</context>
<context>
    <name>storylineView</name>
    <message>
        <location filename="../manuskript/ui/views/storylineView_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/storylineView.py" line="36"/>
        <source>Show Plots</source>
        <translation>Mostrar tramas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/storylineView.py" line="43"/>
        <source>Show Characters</source>
        <translation>Mostrar personajes</translation>
    </message>
</context>
<context>
    <name>tabSplitter</name>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="67"/>
        <source>Open selected items in that view.</source>
        <translation>Abrir los elementos seleccionados en esta vista.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="158"/>
        <source>Split horizontally</source>
        <translation>Dividir horizontalmente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="168"/>
        <source>Close split</source>
        <translation>Cerrar división</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/tabSplitter.py" line="204"/>
        <source>Split vertically</source>
        <translation>Dividir verticalmente</translation>
    </message>
</context>
<context>
    <name>textEditView</name>
    <message>
        <location filename="../manuskript/ui/views/textEditView.py" line="324"/>
        <source>Various</source>
        <translation>Varios</translation>
    </message>
</context>
<context>
    <name>textFormat</name>
    <message>
        <location filename="../manuskript/ui/editors/textFormat_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="18"/>
        <source>CTRL+B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="19"/>
        <source>CTRL+I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="20"/>
        <source>CTRL+U</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="21"/>
        <source>CTRL+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="22"/>
        <source>CTRL+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="23"/>
        <source>CTRL+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="24"/>
        <source>CTRL+R</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/editors/textFormat.py" line="25"/>
        <source>CTRL+J</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>treeView</name>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="48"/>
        <source>Expand {}</source>
        <translation>Expandir {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="52"/>
        <source>Collapse {}</source>
        <translation>Contraer {}</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="59"/>
        <source>Expand All</source>
        <translation>Expandir todo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/views/treeView.py" line="63"/>
        <source>Collapse All</source>
        <translation>Contraer todo</translation>
    </message>
</context>
<context>
    <name>welcome</name>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="50"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="55"/>
        <source>Templates</source>
        <translation>Plantillas</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="86"/>
        <source>Empty</source>
        <translation>Vacía</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="225"/>
        <source>Novel</source>
        <translation>Novela</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="230"/>
        <source>Novella</source>
        <translation>Novela corta</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="235"/>
        <source>Short Story</source>
        <translation>Cuento</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="247"/>
        <source>Research paper</source>
        <translation>Artículo de investigación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="418"/>
        <source>Demo projects</source>
        <translation>Proyectos de ejemplo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="177"/>
        <source>Add level</source>
        <translation>Añadir nivel</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="190"/>
        <source>Add word count</source>
        <translation>Añadir recuento de palabras</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="213"/>
        <source>Next time, automatically open last project</source>
        <translation>La próxima vez, abrir el último proyecto automáticamente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="238"/>
        <source>Open...</source>
        <translation>Abrir...</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="248"/>
        <source>Recent</source>
        <translation>Reciente</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome_ui.ui" line="258"/>
        <source>Create</source>
        <translation>Crear</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="158"/>
        <source>Open project</source>
        <translation>Abrir proyecto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="158"/>
        <source>Manuskript project (*.msk);;All files (*)</source>
        <translation>Proyecto de Manuskript (*.msk);;Todos los archivos (*)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="172"/>
        <source>Save project as...</source>
        <translation>Guardar proyecto como...</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="196"/>
        <source>Manuskript project (*.msk)</source>
        <translation>Proyecto de Manuskript (*.msk)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="196"/>
        <source>Create New Project</source>
        <translation>Crear un proyecto nuevo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="224"/>
        <source>Empty fiction</source>
        <translation>Ficción vacía</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="448"/>
        <source>Chapter</source>
        <translation>Capítulo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="449"/>
        <source>Scene</source>
        <translation>Escena</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="239"/>
        <source>Trilogy</source>
        <translation>Trilogía</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="239"/>
        <source>Book</source>
        <translation>Libro</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="247"/>
        <source>Section</source>
        <translation>Sección</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="246"/>
        <source>Empty non-fiction</source>
        <translation>No-Ficción vacía</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="308"/>
        <source>words each.</source>
        <translation>palabras cada una.</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="311"/>
        <source>of</source>
        <translation>de</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="335"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="338"/>
        <source>Something</source>
        <translation>Algo</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="384"/>
        <source>&lt;b&gt;Total:&lt;/b&gt; {} words (~ {} pages)</source>
        <translation>&lt;b&gt;Total:&lt;/b&gt; {} palabras (~ {} páginas)</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="405"/>
        <source>Fiction</source>
        <translation>Ficción</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="411"/>
        <source>Non-fiction</source>
        <translation>No-ficción</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="446"/>
        <source>Idea</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="447"/>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="450"/>
        <source>Research</source>
        <translation>Investigación</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="457"/>
        <source>TODO</source>
        <translation>POR HACER</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="458"/>
        <source>First draft</source>
        <translation>Primer borrador</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="459"/>
        <source>Second draft</source>
        <translation>Segundo borrador</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="460"/>
        <source>Final</source>
        <translation>Final</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="188"/>
        <source>Manuskript</source>
        <translation>Manuskript</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="208"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../manuskript/ui/welcome.py" line="208"/>
        <source>Overwrite existing project {} ?</source>
        <translation>¿Sobreescribir el proyecto existente {}?</translation>
    </message>
</context>
<context>
    <name>worldModel</name>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="136"/>
        <source>New item</source>
        <translation>Nuevo elemento</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Fantasy world building</source>
        <translation>Construcción de un mundo de fantasía</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Physical</source>
        <translation>Entorno físico</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Climate</source>
        <translation>Clima</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Topography</source>
        <translation>Topografía</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Astronomy</source>
        <translation>Astronomía</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Wild life</source>
        <translation>Vida salvaje</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Flora</source>
        <translation>Flora</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>History</source>
        <translation>Historia</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Races</source>
        <translation>Razas</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Diseases</source>
        <translation>Enfermedades</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Cultural</source>
        <translation>Cultura</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Customs</source>
        <translation>Aduanas</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Food</source>
        <translation>Comida</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Languages</source>
        <translation>Idiomas</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Education</source>
        <translation>Educación</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Dresses</source>
        <translation>Vestidos</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Science</source>
        <translation>Ciencia</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Calendar</source>
        <translation>Calendario</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Bodily language</source>
        <translation>Lenguaje corporal</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Ethics</source>
        <translation>Ética</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Religion</source>
        <translation>Religión</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Government</source>
        <translation>Gobierno</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Politics</source>
        <translation>Política</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Gender roles</source>
        <translation>Roles de género</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Music and arts</source>
        <translation>Música y artes</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Architecture</source>
        <translation>Arquitectura</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Military</source>
        <translation>Ejércitos</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Technology</source>
        <translation>Tecnología</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Courtship</source>
        <translation>Cortejo</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Demography</source>
        <translation>Demografía</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Transportation</source>
        <translation>Medios de transporte</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="262"/>
        <source>Medicine</source>
        <translation>Medicina</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magic system</source>
        <translation>Sistema de magia</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Rules</source>
        <translation>Reglas</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Organization</source>
        <translation>Organización</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magical objects</source>
        <translation>Objetos mágicos</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magical places</source>
        <translation>Lugares mágicos</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="285"/>
        <source>Magical races</source>
        <translation>Razas mágicas</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="292"/>
        <source>Important places</source>
        <translation>Lugares importantes</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="293"/>
        <source>Important objects</source>
        <translation>Objetos importantes</translation>
    </message>
    <message>
        <location filename="../manuskript/models/worldModel.py" line="251"/>
        <source>Natural resources</source>
        <translation>Recursos naturales</translation>
    </message>
</context>
</TS>
