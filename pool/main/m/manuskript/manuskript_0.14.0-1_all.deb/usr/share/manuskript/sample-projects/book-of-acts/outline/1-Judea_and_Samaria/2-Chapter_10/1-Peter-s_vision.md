title:          Peter's vision
ID:             41
type:           md
POV:            0
compile:        2


9 Now on the next day as they were on their journey, and got close to the city, Peter went up on the housetop to pray at about noon. 10 He became hungry and desired to eat, but while they were preparing, he fell into a trance. 11 He saw heaven opened and a certain container descending to him, like a great sheet let down by four corners on the earth, 12 in which were all kinds of four-footed animals of the earth, wild animals, reptiles, and birds of the sky. 13 A voice came to him, “Rise, Peter, kill and eat!”
14 But Peter said, “Not so, Lord; for I have never eaten anything that is common or unclean.”
15 A voice came to him again the second time, “What God has cleansed, you must not call unclean.” 16 This was done three times, and immediately the vessel was received up into heaven. 17 Now while Peter was very perplexed in himself what the vision which he had seen might mean, behold, the men who were sent by Cornelius, having made inquiry for Simon’s house, stood before the gate, 18 and called and asked whether Simon, who was also called Peter, was lodging there. 19 While Peter was pondering the vision, the Spirit said to him, “Behold, three ‡ men seek you. 20 But arise, get down, and go with them, doubting nothing; for I have sent them.”
21 Peter went down to the men, and said, “Behold, I am he whom you seek. Why have you come?”
22 They said, “Cornelius, a centurion, a righteous man and one who fears God, and well spoken of by all the nation of the Jews, was directed by a holy angel to invite you to his house, and to listen to what you say.” 23 So he called them in and provided a place to stay.