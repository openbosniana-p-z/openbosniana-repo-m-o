title:          Stephen is taken
ID:             23
type:           md
POV:            3
compile:        2


8 Stephen, full of faith and power, performed great wonders and signs among the people. 9 But some of those who were of the synagogue called “The Libertines”, and of the Cyrenians, of the Alexandrians, and of those of Cilicia and Asia arose, disputing with Stephen. 10 They weren’t able to withstand the wisdom and the Spirit by which he spoke. 11 Then they secretly induced men to say, “We have heard him speak blasphemous words against Moses and God.” 12 They stirred up the people, the elders, and the scribes, and came against him and seized him, then brought him in to the council, 13 and set up false witnesses who said, “This man never stops speaking blasphemous words against this holy place and the law. 14 For we have heard him say that this Jesus of Nazareth will destroy this place, and will change the customs which Moses delivered to us.” 15 All who sat in the council, fastening their eyes on him, saw his face like it was the face of an angel. 