// Microprofile implementation _requires_ c++.

#define MICROPROFILE_IMPL
#include "microprofile.h"

