# Borgs

Frob has two kinds of borgs: [foo](foo.md) and [bar](bar.md). The latter is reserved for more advanced usages.

## Heading

### Subheading
