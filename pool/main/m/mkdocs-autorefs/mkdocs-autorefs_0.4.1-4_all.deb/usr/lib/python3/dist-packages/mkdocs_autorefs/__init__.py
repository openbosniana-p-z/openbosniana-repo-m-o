"""mkdocs-autorefs package.

Automatically link across pages in MkDocs.
"""
