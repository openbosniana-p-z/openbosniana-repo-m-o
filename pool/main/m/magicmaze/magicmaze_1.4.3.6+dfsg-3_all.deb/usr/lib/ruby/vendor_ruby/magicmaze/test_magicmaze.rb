require 'test/unit'

require 'magicmaze/test_tile'
require 'magicmaze/test_filemap'
require 'magicmaze/test_map'
require 'magicmaze/test_movement'
require 'magicmaze/test_player'
require 'magicmaze/test_game'
require 'magicmaze/test_graphics'
require 'magicmaze/test_images'
require 'magicmaze/test_sound'

