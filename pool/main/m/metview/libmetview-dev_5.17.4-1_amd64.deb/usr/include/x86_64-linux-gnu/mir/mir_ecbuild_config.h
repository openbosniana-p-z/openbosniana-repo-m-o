/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef MIR_ecbuild_config_h
#define MIR_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.7.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.7.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/build/metview-UR32Oh/metview-5.17.4/cmake"
#endif

/* config info */

#define MIR_OS_NAME          "Linux-5.10.0-19-amd64"
#define MIR_OS_BITS          64
#define MIR_OS_BITS_STR      "64"
#define MIR_OS_STR           "linux.64"
#define MIR_OS_VERSION       "5.10.0-19-amd64"
#define MIR_SYS_PROCESSOR    "x86_64"

#define MIR_BUILD_TIMESTAMP  "20221205150932"
#define MIR_BUILD_TYPE       "Release"

#define MIR_C_COMPILER_ID      "GNU"
#define MIR_C_COMPILER_VERSION "12.2.0"

#define MIR_CXX_COMPILER_ID      "GNU"
#define MIR_CXX_COMPILER_VERSION "12.2.0"

#define MIR_C_COMPILER       "/usr/bin/cc"
#define MIR_C_FLAGS          "-g -O2 -ffile-prefix-map=/build/metview-UR32Oh/metview-5.17.4=. -fstack-protector-strong -Wall -pedantic -fPIC -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -O3 -DNDEBUG"

#define MIR_CXX_COMPILER     "/usr/bin/c++"
#define MIR_CXX_FLAGS        "-g -O2 -ffile-prefix-map=/build/metview-UR32Oh/metview-5.17.4=. -fstack-protector-strong -std=gnu++17 -I /usr/include/eigen3 -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable -Wno-sign-compare -O3 -DNDEBUG"

/* Needed for finding per package config files */

#define MIR_INSTALL_DIR       "/usr"
#define MIR_INSTALL_BIN_DIR   "/usr/bin"
#define MIR_INSTALL_LIB_DIR   "/usr/lib/x86_64-linux-gnu"
#define MIR_INSTALL_DATA_DIR  "/usr/share/mir"

#define MIR_DEVELOPER_SRC_DIR "/build/metview-UR32Oh/metview-5.17.4"
#define MIR_DEVELOPER_BIN_DIR "/build/metview-UR32Oh/metview-5.17.4/debian/build"

/* Fortran support */

#if 0

#define MIR_Fortran_COMPILER_ID      ""
#define MIR_Fortran_COMPILER_VERSION ""

#define MIR_Fortran_COMPILER ""
#define MIR_Fortran_FLAGS    ""

#endif

#endif /* MIR_ecbuild_config_h */
