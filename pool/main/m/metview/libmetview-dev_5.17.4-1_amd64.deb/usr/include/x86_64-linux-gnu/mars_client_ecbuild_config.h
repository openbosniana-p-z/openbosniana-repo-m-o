/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef MARS_CLIENT_ecbuild_config_h
#define MARS_CLIENT_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.7.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.7.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/build/metview-UR32Oh/metview-5.17.4/cmake"
#endif

/* config info */

#define MARS_CLIENT_OS_NAME          "Linux-5.10.0-19-amd64"
#define MARS_CLIENT_OS_BITS          64
#define MARS_CLIENT_OS_BITS_STR      "64"
#define MARS_CLIENT_OS_STR           "linux.64"
#define MARS_CLIENT_OS_VERSION       "5.10.0-19-amd64"
#define MARS_CLIENT_SYS_PROCESSOR    "x86_64"

#define MARS_CLIENT_BUILD_TIMESTAMP  "20221205150932"
#define MARS_CLIENT_BUILD_TYPE       "Release"

#define MARS_CLIENT_C_COMPILER_ID      "GNU"
#define MARS_CLIENT_C_COMPILER_VERSION "12.2.0"

#define MARS_CLIENT_CXX_COMPILER_ID      "GNU"
#define MARS_CLIENT_CXX_COMPILER_VERSION "12.2.0"

#define MARS_CLIENT_C_COMPILER       "/usr/bin/cc"
#define MARS_CLIENT_C_FLAGS          "-g -O2 -ffile-prefix-map=/build/metview-UR32Oh/metview-5.17.4=. -fstack-protector-strong -Wall -pedantic -fPIC -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -O3 -DNDEBUG"

#define MARS_CLIENT_CXX_COMPILER     "/usr/bin/c++"
#define MARS_CLIENT_CXX_FLAGS        "-g -O2 -ffile-prefix-map=/build/metview-UR32Oh/metview-5.17.4=. -fstack-protector-strong -std=gnu++17 -I /usr/include/eigen3 -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -O3 -DNDEBUG"

/* Needed for finding per package config files */

#define MARS_CLIENT_INSTALL_DIR       "/usr"
#define MARS_CLIENT_INSTALL_BIN_DIR   "/usr/bin"
#define MARS_CLIENT_INSTALL_LIB_DIR   "/usr/lib/x86_64-linux-gnu"
#define MARS_CLIENT_INSTALL_DATA_DIR  "/usr/share/mars_client"

#define MARS_CLIENT_DEVELOPER_SRC_DIR "/build/metview-UR32Oh/metview-5.17.4"
#define MARS_CLIENT_DEVELOPER_BIN_DIR "/build/metview-UR32Oh/metview-5.17.4/debian/build"

/* Fortran support */

#if 0

#define MARS_CLIENT_Fortran_COMPILER_ID      ""
#define MARS_CLIENT_Fortran_COMPILER_VERSION ""

#define MARS_CLIENT_Fortran_COMPILER ""
#define MARS_CLIENT_Fortran_FLAGS    ""

#endif

#endif /* MARS_CLIENT_ecbuild_config_h */
