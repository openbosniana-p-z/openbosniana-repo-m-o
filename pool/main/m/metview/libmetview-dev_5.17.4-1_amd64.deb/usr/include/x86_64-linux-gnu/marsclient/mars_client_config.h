#ifndef mars_client_config_h
#define mars_client_config_h

#define mars_client_HAVE_ODB              0
#define mars_client_HAVE_FDB5             1
#define mars_client_HAVE_PPROC_EMOS       1
#define mars_client_HAVE_PPROC_MIR        1
#define mars_client_HAVE_RPC              1

#define mars_client_HAVE_UDP_STATS        0
#define mars_client_HAVE_NETCDF           1

#define mars_client_HAVE_MARS_USER_ENVIRONMENT 0

#endif // mars_client_config_h
