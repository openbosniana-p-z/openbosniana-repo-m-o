#pragma once

#include "mir/mir_ecbuild_config.h"

#include "mir/api/mir_version.h"

#define mir_HAVE_ATLAS 1
#define mir_HAVE_NETCDF 1
#define mir_HAVE_PNG 1
#define mir_HAVE_OMP 0

