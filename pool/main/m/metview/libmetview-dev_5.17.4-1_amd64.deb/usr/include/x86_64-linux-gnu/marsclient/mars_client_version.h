#ifndef mars_client_version_h
#define mars_client_version_h

const char * mars_client_version();

unsigned int mars_client_version_int();

const char * mars_client_version_str();

const char * mars_client_buildstamp();

const char * mars_client_git_sha1();

const char * mars_client_bundle_version_str();

#endif
