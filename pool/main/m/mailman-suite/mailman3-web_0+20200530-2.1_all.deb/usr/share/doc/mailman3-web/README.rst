=========================
Mailman Suite setup files
=========================

This package contains setup files designed for people who want to use Mailman
Core integrated with Hyperkitty and Postorius.


=======
License
=======

Mailman suite is licensed under the
`GPL v3.0 <http://www.gnu.org/licenses/gpl-3.0.html>`_

Copyright (C) 2017 by the Free Software Foundation, Inc.
