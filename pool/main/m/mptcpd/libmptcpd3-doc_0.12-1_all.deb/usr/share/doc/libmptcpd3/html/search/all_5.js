var searchData=
[
  ['data_0',['data',['../structget__addr__user__callback.html#a78e4bf78a528f3ef37278816319a5274',1,'get_addr_user_callback::data()'],['../structget__limits__user__callback.html#afa4c7483f77f40896ef8c5dfc72e81ba',1,'get_limits_user_callback::data()']]],
  ['default_5fplugin_1',['default_plugin',['../structmptcpd__config.html#a569694404224847da20eb142bd9b5d65',1,'mptcpd_config']]],
  ['delete_5faddress_2',['delete_address',['../structmptcpd__nm__ops.html#af22665c0c7d0ea63360ae7a71cf8ed77',1,'mptcpd_nm_ops']]],
  ['delete_5finterface_3',['delete_interface',['../structmptcpd__nm__ops.html#a55ec47a2e530924d3c6b7131b1f36af5',1,'mptcpd_nm_ops::delete_interface()'],['../structmptcpd__plugin__ops.html#a674fa20a9e74754448de753772ef7c2e',1,'mptcpd_plugin_ops::delete_interface()']]],
  ['delete_5flocal_5faddress_4',['delete_local_address',['../structmptcpd__plugin__ops.html#a92a9d88e591544e9f9288afc02c4213e',1,'mptcpd_plugin_ops']]],
  ['desc_5',['desc',['../structplugin__info.html#af586ae78067d9edfe0a7041c8dde57f6',1,'plugin_info']]],
  ['description_6',['description',['../structmptcpd__plugin__desc.html#aa9a77ebf1f7f7784d857279e29a79904',1,'mptcpd_plugin_desc']]],
  ['dump_7',['dump',['../structget__addr__user__callback.html#acdd51ba3b4fc6cec4ad392411416f44a',1,'get_addr_user_callback']]],
  ['dump_5faddrs_8',['dump_addrs',['../structmptcpd__kpm__cmd__ops.html#a4239c9ae5089d2e63c742d2cc4d3f424',1,'mptcpd_kpm_cmd_ops']]]
];
