var searchData=
[
  ['version_0',['version',['../structmptcpd__plugin__desc.html#a705b6dc7abf36029f66a14d0be797da2',1,'mptcpd_plugin_desc']]]
];
