var searchData=
[
  ['plugin_5faddress_5finfo_0',['plugin_address_info',['../structplugin__address__info.html',1,'']]],
  ['plugin_5finfo_1',['plugin_info',['../structplugin__info.html',1,'']]],
  ['plugin_5finterface_5finfo_2',['plugin_interface_info',['../structplugin__interface__info.html',1,'']]],
  ['pm_5fevent_5fattrs_3',['pm_event_attrs',['../structpm__event__attrs.html',1,'']]],
  ['pm_5fops_5finfo_4',['pm_ops_info',['../structpm__ops__info.html',1,'']]]
];
