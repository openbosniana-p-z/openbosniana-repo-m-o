var searchData=
[
  ['get_5faddr_5fuser_5fcallback_0',['get_addr_user_callback',['../structget__addr__user__callback.html',1,'']]],
  ['get_5flimits_5fuser_5fcallback_1',['get_limits_user_callback',['../structget__limits__user__callback.html',1,'']]]
];
