var searchData=
[
  ['raddr4_0',['raddr4',['../structpm__event__attrs.html#a9468d5937f677b033a4440505f90dcf8',1,'pm_event_attrs']]],
  ['raddr6_1',['raddr6',['../structpm__event__attrs.html#a3edc04bfa0606c60627b3cfcf25ddc83',1,'pm_event_attrs']]],
  ['raddr_5fid_2',['raddr_id',['../structpm__event__attrs.html#a5cae975cd96bb15cad178d76cadf4e25',1,'pm_event_attrs']]],
  ['ready_3',['ready',['../structmptcpd__pm__ops.html#ae301539328a6d57d8c5673dec5cf538b',1,'mptcpd_pm_ops']]],
  ['refcnt_4',['refcnt',['../structlm__value.html#a055751a8be09c45cde5c3ae5539c27f1',1,'lm_value']]],
  ['remote_5fport_5',['remote_port',['../structpm__event__attrs.html#a13b5bf3cc4459b37e7387e86571e91da',1,'pm_event_attrs']]],
  ['remove_5faddr_6',['remove_addr',['../structmptcpd__pm__cmd__ops.html#a111c003a05791d45c28ab1461b6dad24',1,'mptcpd_pm_cmd_ops::remove_addr()'],['../structmptcpd__kpm__cmd__ops.html#afbadef04eb1f01f3458f6832f5df282c',1,'mptcpd_kpm_cmd_ops::remove_addr()']]],
  ['remove_5finfo_7',['remove_info',['../structremove__info.html',1,'']]],
  ['remove_5fsubflow_8',['remove_subflow',['../structmptcpd__pm__cmd__ops.html#a10c479a23f0fef4d871fc9b5533e1262',1,'mptcpd_pm_cmd_ops']]],
  ['rtnl_9',['rtnl',['../structmptcpd__nm.html#a622566cca3a16bcc7e19cedd563b1f2e',1,'mptcpd_nm']]]
];
