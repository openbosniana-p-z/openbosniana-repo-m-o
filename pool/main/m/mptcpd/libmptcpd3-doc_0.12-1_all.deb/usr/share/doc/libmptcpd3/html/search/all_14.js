var searchData=
[
  ['update_5finterface_0',['update_interface',['../structmptcpd__nm__ops.html#a1ae6e3a56c613efc3e8ac1480cf165df',1,'mptcpd_nm_ops::update_interface()'],['../structmptcpd__plugin__ops.html#a35f9fcf0a2b6f7b982ccfe3f2d939866',1,'mptcpd_plugin_ops::update_interface()']]],
  ['user_5fdata_1',['user_data',['../structpm__ops__info.html#ad289c430bca413cae9e685b997989844',1,'pm_ops_info::user_data()'],['../structnm__ops__info.html#a6105012cbdac7563351e15d307bde1af',1,'nm_ops_info::user_data()'],['../structmptcpd__interface__callback__data.html#a118adf73495a80447bd2a492bbfb8110',1,'mptcpd_interface_callback_data::user_data()']]]
];
