var searchData=
[
  ['nm_5faddr_5finfo_0',['nm_addr_info',['../structnm__addr__info.html',1,'']]],
  ['nm_5fops_5finfo_1',['nm_ops_info',['../structnm__ops__info.html',1,'']]]
];
