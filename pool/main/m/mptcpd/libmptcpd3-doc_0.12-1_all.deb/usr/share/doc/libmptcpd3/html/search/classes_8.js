var searchData=
[
  ['remove_5finfo_0',['remove_info',['../structremove__info.html',1,'']]]
];
