var searchData=
[
  ['addr_5finfo_0',['addr_info',['../structaddr__info.html',1,'']]]
];
