var searchData=
[
  ['sspi_5finterface_5finfo_0',['sspi_interface_info',['../structsspi__interface__info.html',1,'']]],
  ['sspi_5fnew_5fconnection_5finfo_1',['sspi_new_connection_info',['../structsspi__new__connection__info.html',1,'']]],
  ['sspi_5fnm_5fcallback_5fdata_2',['sspi_nm_callback_data',['../structsspi__nm__callback__data.html',1,'']]]
];
