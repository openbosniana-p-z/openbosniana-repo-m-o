var searchData=
[
  ['sa_0',['sa',['../structmptcpd__hash__sockaddr__key.html#a4fdc5e614454648a47c00858241a0692',1,'mptcpd_hash_sockaddr_key']]],
  ['seed_1',['seed',['../structmptcpd__hash__sockaddr__key.html#a4239317809a0ce637e9f5f8282b6638e',1,'mptcpd_hash_sockaddr_key::seed()'],['../structmptcpd__idm.html#a7f688959bd454da90819267fe8fa54e5',1,'mptcpd_idm::seed()'],['../structmptcpd__lm.html#af7a1999c0e9cb27ad1b71f3237adc86e',1,'mptcpd_lm::seed()']]],
  ['server_5fside_2',['server_side',['../structpm__event__attrs.html#ab7ccb8523fc6f650a9370046cb8e3d49',1,'pm_event_attrs']]],
  ['set_5fbackup_3',['set_backup',['../structmptcpd__pm__cmd__ops.html#a8e2566b8fd1cf89171b17ec9b0f4c037',1,'mptcpd_pm_cmd_ops']]],
  ['set_5fflags_4',['set_flags',['../structmptcpd__kpm__cmd__ops.html#a9c98cb846edd0b07e7581eeb31c94f31',1,'mptcpd_kpm_cmd_ops']]],
  ['set_5flimits_5',['set_limits',['../structmptcpd__kpm__cmd__ops.html#a5cdaade10f1cffc11be3f6a31f67514b',1,'mptcpd_kpm_cmd_ops']]],
  ['sockaddr_2ec_6',['sockaddr.c',['../sockaddr_8c.html',1,'']]],
  ['sockaddr_2eh_7',['sockaddr.h',['../sockaddr_8h.html',1,'']]],
  ['sspi_2ec_8',['sspi.c',['../sspi_8c.html',1,'']]],
  ['sspi_5fbad_5findex_9',['SSPI_BAD_INDEX',['../sspi_8c.html#adcc8d9d463914b9ad320bfc13cf476ec',1,'sspi.c']]],
  ['sspi_5finterface_5finfo_10',['sspi_interface_info',['../structsspi__interface__info.html',1,'']]],
  ['sspi_5fnew_5fconnection_5finfo_11',['sspi_new_connection_info',['../structsspi__new__connection__info.html',1,'']]],
  ['sspi_5fnm_5fcallback_5fdata_12',['sspi_nm_callback_data',['../structsspi__nm__callback__data.html',1,'']]],
  ['subflow_5fclosed_13',['subflow_closed',['../structmptcpd__plugin__ops.html#a559d6df5e5594dbc6fcb51a1ea00b82c',1,'mptcpd_plugin_ops']]],
  ['subflow_5fpriority_14',['subflow_priority',['../structmptcpd__plugin__ops.html#a549aaf29f771882e90e61b8f41474429',1,'mptcpd_plugin_ops']]]
];
