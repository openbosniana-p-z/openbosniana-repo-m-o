var searchData=
[
  ['sockaddr_2ec_0',['sockaddr.c',['../sockaddr_8c.html',1,'']]],
  ['sockaddr_2eh_1',['sockaddr.h',['../sockaddr_8h.html',1,'']]],
  ['sspi_2ec_2',['sspi.c',['../sspi_8c.html',1,'']]]
];
