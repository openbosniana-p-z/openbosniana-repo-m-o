var searchData=
[
  ['id_5fmanager_2ec_0',['id_manager.c',['../id__manager_8c.html',1,'']]],
  ['id_5fmanager_2eh_1',['id_manager.h',['../id__manager_8h.html',1,'(Global Namespace)'],['../private_2id__manager_8h.html',1,'(Global Namespace)']]]
];
