#!/usr/bin/env python3
try:
    from mapdamage._version import __version__
except ImportError:
    __version__ = "2.2.1"
