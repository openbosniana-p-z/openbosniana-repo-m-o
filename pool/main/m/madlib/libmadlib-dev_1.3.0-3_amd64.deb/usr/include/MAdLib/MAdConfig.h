/* MAdConfig.h.  Generated from MAdConfig.h.in by configure.  */
/* MAdConfig.h.in.  Generated from configure.ac by autoheader.  */

/* Whether we run the compilation on a 64 bits architecture or not */
#define HAVE_64BIT_SIZE_T 1

/* Whether we use BLAS or not */
#define HAVE_BLAS 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Whether we use Lapack or not */
#define HAVE_LAPACK 1

/* Define to 1 if you have the `m' library (-lm). */
#define HAVE_LIBM 1

/* Define to 1 if you have the <mpi.h> header file. */
/* #undef HAVE_MPI_H */

/* Whether we use DLLs or not */
#define HAVE_NO_DLL /**/

/* Whether we use socklens or not */
#define HAVE_NO_SOCKLEN_T /**/

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "madlib"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "contrib@madlib.be"

/* Define to the full name of this package. */
#define PACKAGE_NAME "MAdLib"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "MAdLib 1.3.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "madlib"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.3.0"

/* Whether we compile for parallel utilization or not */
#define PARALLEL /**/

/* The size of `size_t', as computed by sizeof. */
#define SIZEOF_SIZE_T 8

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "1.3.0"

/* Whether we use the ANN library or not */
#define _HAVE_ANN_ 1

/* Whether we use BLAS or not */
#define _HAVE_BLAS_ /**/

/* Whether we use GMM or not */
#define _HAVE_GMM_ /**/

/* Whether we use Gmsh or not */
#define _HAVE_GMSH_ /**/

/* Whether we use Mathex or not */
#define _HAVE_MATHEX_ 1

/* Whether we use Metis or not */
#define _HAVE_METIS_ /**/

/* Whether we use MPI or not */
#define _HAVE_MPI_ /**/

/* Whether we use OpenCascade or not */
#define _HAVE_OCC_ /**/

/* Whether we use ParMetis or not */
#define _HAVE_PARMETIS_ /**/

/* Whether we use the Cenaero parser or not */
#define _HAVE_PARSER_ /**/

/* Whether we use PETSc or not */
#define _HAVE_PETSC_ /**/
