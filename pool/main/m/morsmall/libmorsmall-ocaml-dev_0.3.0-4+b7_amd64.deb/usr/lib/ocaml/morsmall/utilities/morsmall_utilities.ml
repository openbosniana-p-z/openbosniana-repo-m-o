(** @canonical Morsmall_utilities.TestParser *)
module TestParser = Morsmall_utilities__TestParser
