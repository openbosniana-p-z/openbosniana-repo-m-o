(** @canonical Morsmall.AST *)
module AST = Morsmall__AST


(** @canonical Morsmall.CST_to_AST *)
module CST_to_AST = Morsmall__CST_to_AST


(** @canonical Morsmall.Location *)
module Location = Morsmall__Location


(** @canonical Morsmall.SafePrinter *)
module SafePrinter = Morsmall__SafePrinter
