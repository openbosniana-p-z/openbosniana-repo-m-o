#! /usr/bin/python3
# -*- coding: utf-8 -*-

# Copyright: (2013-2017) Michael Till Beck <Debianguru@gmx.de>
# License: GPL-2.0+


import http.server
import socketserver
import importlib
import sys
import getopt


bind = 'localhost'
port = 8000
configMod = '/etc/mwc/mwc-config'


try:
    opts, args = getopt.getopt(sys.argv[1:], 'hc:b:p:', ['help', 'config=', 'bind=', 'port='])
except getopt.GetoptError:
    print('Usage: FeedServer.py --config=config --port=8000 --bind=localhost')
    sys.exit(1)

for opt, arg in opts:
    if opt == '-h':
        print('Usage: FeedServer.py --config=config --bind=localhost --port=8000')
        exit()
    elif opt in ('-c', '--config'):
        configMod = arg
    elif opt in ('-b', '--bind'):
        bind = arg
    elif opt in ('-p', '--port'):
        port = int(arg)

    #
    # add code to load config from nonsystem path
    # and change to datadir
    #
    try:
        path = os.path.dirname(configMod)
        fullname = os.path.basename(configMod)
        sys.path.append(path)
        config = importlib.import_module(fullname)
    except: 
        print('Error: loading config')
        sys.exit(2)
    try:
        os.chdir(config.datadir)
    except: 
        print('Error: datadir not found')
        sys.exit(3)


handler = http.server.SimpleHTTPRequestHandler

httpd = socketserver.TCPServer((bind, port), handler)

print('Bond to ' + bind + ', listening on port ' + str(port))
httpd.serve_forever()

