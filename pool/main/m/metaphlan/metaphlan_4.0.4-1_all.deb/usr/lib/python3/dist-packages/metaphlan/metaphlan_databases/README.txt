This folder will contain the MetaPhlAn databases.
