MAZE OF GALIOUS REMAKE v0.62
Santi Onta��n Villar (2002)

KEYS:

Q - UP/JUMP
A - DOWN
O - LEFT
P - RIGHT
SPACE - SWORD
M - FIRE SECONDARY WEAPON
F1 - ITEM SCREEN
F2 - PAUSE

ESC - Returns to the tittle screen (NOT REDEFINIBLE)
F10 - Changes the Graphic set (NOT REDEFINIBLE)
F11 - Changes the Sound set (NOT REDEFINIBLE)
F12 - Quits the game (NOT REDEFINIBLE)
PGUP/PGDOWN - Zoom (NOT REDEFINIBLE)
L - Pressed in the tittle screen, allows us to enter passwords. (NOT REDEFINIBLE)
ALT + ENTER - Toogles fullscreen/windowed mode


Notes:

This game has only been tested under windows 98/Me and Mac OSX, if there are any
problems with windows 2000/XP or LINUX please let me know at:

santi.ontanon@terra.es

and I will try to fix it.


Acknowledgements:

Thanks to (chronological order of collaboration):
- KOIOTE from Spain, for the SFX samples and beta testing.
- BOLTIAN from Spain, for his excelent graphic set.
- JASON EAMES from Spain, for hosting the web, helping me to promote it and for beta testing.
- CHRISTIAN JAVIER D'ORAZIO from Argentina, for his help with the password decoding.
- JOOST YERVANTE fron Netherland, for the help with SDL and the LINUX port.
- HINOX from Spain, for his great grahpic set and his motivation!
- HENK BOSMAN from Netherland, from beta testing.
- LARS THE 18TH from Netherland, for his error reports about the PASSWORD DECODING section,
  and his excelent PASSWORD generator.
- WISAM AL-RAWI from IRAQ, for beta testing and for the original SFX.
- MAX ATTAR FEINGOLD from US, for beta testing and for his help in fixing compatibility
  problems with Windows XP.
- SERGI GARC�A BESORA from CATALONIA (SPAIN), for beta testing.
- JORRITH SCHAAP from NETHERLAND, for his excelent music files.
- BART ROYMANS from NETHERLAND, for his excelent music files.
- ZITA MIRANDA MARTINEZ from SPAIN, for beta testing.
- MENNO HAECK from NETHERLAND, for beta testing.
- JANNE VIERI from FINLAND, for beta testing.
- ROB POUWELSE from NETHERLAND, for beta testing and a new sound-track.
- J-LUNARTIC from GERMANY, for the translation of this file to german.
- WOLF from NETHERLAND, for his great sound files!
- TEMPLAU from SPAIN, for his neat trance version of the castle them!
- CHRISTOPHE HUET from FRANCE, for his effort on his own and great MoG remake!!!
- RANDY WINTJES from NETHERLAND, for the original MIDI files from where the alternate sound
  set was built.