/* include/config.h.  Generated from config.h.in by configure.  */
#ifndef __MCABBER_CONFIG_H__
#define __MCABBER_CONFIG_H__ 1

/* Are modules enabled or no */
#define MODULES_ENABLE 1

/* ... */
#define HAVE_LIBOTR 1

/* ... */
#define HAVE_GPGME 1

/* ... */
#define HAVE_NCURSESW_NCURSES_H 1

/* ... */
/* #undef HAVE_NCURSES_NCURSES_H */

/* ... */
/* #undef WITH_ENCHANT */

/* ... */
#define WITH_ASPELL 1

/* ... */
/* #undef XEP0022 */

/* ... */
#define HAVE_UNICODE /**/

/* ... */
#define HAVE_WCHAR_H 1

/* ... */
#define HAVE_WCTYPE_H 1

/* ... */
#define HAVE_WCHAR_H 1

/* ... */
#define HAVE_ISWBLANK 1

/* ... */
#define HAVE_STRCASESTR 1

/* Default data files prefix */
#define DATA_DIR "/usr/share"

/* Default modules location */
#define PKGLIB_DIR "/usr/lib/x86_64-linux-gnu/mcabber"

/* To satisfy gnutls */
/* #undef _FILE_OFFSET_BITS */

/* Mcabber branch name (string) */
#define MCABBER_BRANCH "1.1.2"

/* Mcabber version (string) */
#define MCABBER_VERSION "1.1.2"

#endif
