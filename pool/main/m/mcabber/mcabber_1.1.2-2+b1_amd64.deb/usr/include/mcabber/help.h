#ifndef __MCABBER_HELP_H__
#define __MCABBER_HELP_H__ 1

void free_help_dirs(void);
void init_help_dirs(void);
void help_process(char *string);
void help_init(void);

#endif /* __MCABBER_HELP_H__ */

/* vim: set expandtab cindent cinoptions=>2\:2(0 sw=2 ts=2:  For Vim users... */
