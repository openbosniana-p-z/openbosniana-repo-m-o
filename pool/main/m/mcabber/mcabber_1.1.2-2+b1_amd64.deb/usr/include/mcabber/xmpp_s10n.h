#ifndef __MCABBER_XMPP_S10N_H__
#define __MCABBER_XMPP_S10N_H__ 1

#include <mcabber/events.h>

gboolean evscallback_subscription(guint evcontext, const char *arg, gpointer userdata);

#endif /* __MCABBER_XMPP_S10N_H__ */

/* vim: set et cindent cinoptions=>2\:2(0 ts=2 sw=2:  For Vim users... */
