#ifndef __MCABBER_MAIN_H__
#define __MCABBER_MAIN_H__ 1

extern GMainContext *main_context;

void mcabber_set_terminate_ui(void);
char *mcabber_version(void);

#endif

/* vim: set expandtab cindent cinoptions=>2\:2(0 sw=2 ts=2:  For Vim users... */
