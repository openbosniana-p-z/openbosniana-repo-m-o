#ifndef __MCABBER_FIFO_H__
#define __MCABBER_FIFO_H__ 1

int  fifo_init(void);
void fifo_deinit(void);

#endif /* __MCABBER_FIFO_H__ */

/* vim: set expandtab cindent cinoptions=>2\:2(0 sw=2 ts=2:  For Vim users... */
