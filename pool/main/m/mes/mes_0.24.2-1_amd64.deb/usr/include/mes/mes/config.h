#undef SYSTEM_LIBC

#define MES_VERSION "0.24.2"
