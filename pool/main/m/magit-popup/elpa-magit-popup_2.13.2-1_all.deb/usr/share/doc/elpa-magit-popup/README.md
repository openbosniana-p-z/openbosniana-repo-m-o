# Magit-Popup

This package implements a generic interface for toggling switches
and setting options and then invoking an Emacs command that does
something with these arguments.  Usually the command calls an
external process with the specified arguments.

This package has been superseded by [Transient].  No new features
will be added but bugs will be fixes.

[Transient]: https://github.com/magit/transient
