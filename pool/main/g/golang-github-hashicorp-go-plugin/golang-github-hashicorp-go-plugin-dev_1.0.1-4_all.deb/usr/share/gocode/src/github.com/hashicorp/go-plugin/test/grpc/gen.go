package grpctest

//go:generate protoc -I ./ ./test.proto --go_out=plugins=grpc:.
