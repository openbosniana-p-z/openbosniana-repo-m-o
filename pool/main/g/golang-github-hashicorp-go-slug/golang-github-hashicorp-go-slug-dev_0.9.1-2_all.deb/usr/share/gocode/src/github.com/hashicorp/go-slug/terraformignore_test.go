package slug

import (
	"testing"
)

func TestTerraformIgnore(t *testing.T) {
	// path to directory without .terraformignore
	p := parseIgnoreFile("testdata")
	if len(p) != 4 {
		t.Fatal("A directory without .terraformignore should get the default patterns")
	}

}
