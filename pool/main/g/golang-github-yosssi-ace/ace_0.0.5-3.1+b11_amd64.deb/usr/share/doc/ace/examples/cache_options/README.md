# Cache Options

This example shows how to cache the options for Ace template engine so that you don't have to specify them every time calling the Ace APIs.
