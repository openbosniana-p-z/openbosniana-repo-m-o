# Pass a Pipeline (Parameter) to the Included Template

This example shows how to pass a pipeline (parameter) to the included template.
