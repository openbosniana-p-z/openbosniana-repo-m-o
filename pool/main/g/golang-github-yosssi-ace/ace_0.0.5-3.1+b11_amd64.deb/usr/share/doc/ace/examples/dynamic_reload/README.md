# Dynamic Reload

This example shows how to reload templates dynamically. Ace caches the parsed templates by default but you can have Ace reload templates dynamically by setting the "DynamicReload" option to the Ace template enginge. This option should be used in development.
