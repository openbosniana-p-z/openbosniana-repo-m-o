# Plain Texts

This example shows how to generate plain texts.
