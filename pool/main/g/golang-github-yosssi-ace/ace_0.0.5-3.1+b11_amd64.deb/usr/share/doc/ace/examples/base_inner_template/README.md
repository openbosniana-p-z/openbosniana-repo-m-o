# Base and Inner Template

This example shows how to use a base and inner Ace template file.
