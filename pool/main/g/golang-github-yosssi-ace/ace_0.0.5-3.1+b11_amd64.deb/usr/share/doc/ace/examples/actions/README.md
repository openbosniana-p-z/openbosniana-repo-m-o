# Actions

This example shows how to embed actions in Ace templates.
