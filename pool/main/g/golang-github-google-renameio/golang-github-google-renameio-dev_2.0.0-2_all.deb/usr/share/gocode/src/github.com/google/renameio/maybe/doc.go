// Package maybe provides a way to atomically create or replace a file, if
// technically possible.
package maybe
