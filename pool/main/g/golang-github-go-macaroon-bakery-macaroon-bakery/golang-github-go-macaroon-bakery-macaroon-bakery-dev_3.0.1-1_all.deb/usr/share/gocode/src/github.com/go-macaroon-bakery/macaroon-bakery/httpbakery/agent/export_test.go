package agent

type AgentLogin agentLogin

const CookieName = cookieName
