package mgorootkeystore

var (
	Clock               = &clock
	MgoCollectionFindId = &mgoCollectionFindId
)
