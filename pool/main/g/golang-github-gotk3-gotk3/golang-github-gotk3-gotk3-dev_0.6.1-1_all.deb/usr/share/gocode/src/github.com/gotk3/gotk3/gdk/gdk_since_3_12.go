// +build !gtk_3_6,!gtk_3_8,!gtk_3_10
// Supports building with gtk 3.12+

package gdk

// TODO:
// gdk_device_get_last_event_window().
