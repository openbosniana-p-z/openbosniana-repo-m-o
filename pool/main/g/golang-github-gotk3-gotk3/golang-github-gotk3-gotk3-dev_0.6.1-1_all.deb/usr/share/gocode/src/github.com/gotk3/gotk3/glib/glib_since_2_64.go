// Same copyright and license as the rest of the files in this project

// +build !glib_2_40,!glib_2_42,!glib_2_44,!glib_2_46,!glib_2_48,!glib_2_50,!glib_2_52,!glib_2_54,!glib_2_56,!glib_2_58,!glib_2_60,!glib_2_62

package glib

// // #include <gio/gio.h>
// // #include <glib.h>
// // #include <glib-object.h>
// // #include "glib.go.h"
// // #include "glib_since_2_44.go.h"
// import "C"

/*
 * GListStore
 */

// TODO
// g_list_store_find
// g_list_store_find_with_equal_func
