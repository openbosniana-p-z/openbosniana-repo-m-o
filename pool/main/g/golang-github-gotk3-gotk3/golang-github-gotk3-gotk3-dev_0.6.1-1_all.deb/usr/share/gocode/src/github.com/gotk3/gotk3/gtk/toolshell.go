package gtk

// TODO:
// GtkToolShellIface
// gtk_tool_shell_get_ellipsize_mode().
// gtk_tool_shell_get_icon_size().
// gtk_tool_shell_get_orientation().
// gtk_tool_shell_get_relief_style().
// gtk_tool_shell_get_style().
// gtk_tool_shell_get_text_alignment().
// gtk_tool_shell_get_text_orientation().
// gtk_tool_shell_rebuild_menu().
// gtk_tool_shell_get_text_size_group().
