package main

import "github.com/gucumber/gucumber"

func main() {
	gucumber.RunMain()
}
