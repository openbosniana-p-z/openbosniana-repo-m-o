#ifndef CERT_TRANS_UTIL_INIT_H_
#define CERT_TRANS_UTIL_INIT_H_

#include <stdint.h>
#include <string>

namespace util {

void InitCT(int* argc, char** argv[]);

}  // namespace util

#endif  // CERT_TRANS_UTIL_INIT_H_
