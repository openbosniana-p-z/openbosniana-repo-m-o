#ifndef CERT_TRANS_VERSION_H_
#define CERT_TRANS_VERSION_H_

namespace cert_trans {


extern const char kBuildVersion[];


}  // namespace cert_trans

#endif  // CERT_TRANS_VERSION_H_
