#include "log/logged_entry.h"

#include <gtest/gtest.h>

typedef testing::Types<cert_trans::LoggedEntry> TestType;

#include "log/logged_test-inl.h"
