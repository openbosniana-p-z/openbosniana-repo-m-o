// +build tools

package main

import (
	_ "github.com/golang/protobuf/protoc-gen-go"
)
