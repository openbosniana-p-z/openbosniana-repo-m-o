/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef ODC_ecbuild_config_h
#define ODC_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.7.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.7.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/usr/share/ecbuild/cmake"
#endif

/* config info */

#define ODC_OS_NAME          "Linux-5.10.0-18-amd64"
#define ODC_OS_BITS          64
#define ODC_OS_BITS_STR      "64"
#define ODC_OS_STR           "linux.64"
#define ODC_OS_VERSION       "5.10.0-18-amd64"
#define ODC_SYS_PROCESSOR    "x86_64"

#define ODC_BUILD_TIMESTAMP  "20220917124255"
#define ODC_BUILD_TYPE       "Release"

#define ODC_C_COMPILER_ID      "GNU"
#define ODC_C_COMPILER_VERSION "12.2.0"

#define ODC_CXX_COMPILER_ID      "GNU"
#define ODC_CXX_COMPILER_VERSION "12.2.0"

#define ODC_C_COMPILER       "/usr/bin/cc"
#define ODC_C_FLAGS          "-g -O2 -ffile-prefix-map=/build/odc-unOWwx/odc-1.4.6=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -O3 -DNDEBUG"

#define ODC_CXX_COMPILER     "/usr/bin/c++"
#define ODC_CXX_FLAGS        "-g -O2 -ffile-prefix-map=/build/odc-unOWwx/odc-1.4.6=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable -Wno-sign-compare -O3 -DNDEBUG"

/* Needed for finding per package config files */

#define ODC_INSTALL_DIR       "/usr"
#define ODC_INSTALL_BIN_DIR   "/usr/bin"
#define ODC_INSTALL_LIB_DIR   "/usr/lib/x86_64-linux-gnu"
#define ODC_INSTALL_DATA_DIR  "/usr/share/odc"

#define ODC_DEVELOPER_SRC_DIR "/build/odc-unOWwx/odc-1.4.6"
#define ODC_DEVELOPER_BIN_DIR "/build/odc-unOWwx/odc-1.4.6/obj-x86_64-linux-gnu"

/* Fortran support */

#if 1

#define ODC_Fortran_COMPILER_ID      "GNU"
#define ODC_Fortran_COMPILER_VERSION "12.2.0"

#define ODC_Fortran_COMPILER "/usr/bin/gfortran"
#define ODC_Fortran_FLAGS    "-g -O2 -ffile-prefix-map=/build/odc-unOWwx/odc-1.4.6=. -fstack-protector-strong -O3 -DNDEBUG -funroll-all-loops -finline-functions"

#endif

#endif /* ODC_ecbuild_config_h */
