var classOpm_1_1RateConverter_1_1SurfaceToReservoirVoidage =
[
    [ "RegionId", "classOpm_1_1RateConverter_1_1SurfaceToReservoirVoidage.html#a2faebb40cc80b7d3bbfde9cc1dcccbef", null ],
    [ "SurfaceToReservoirVoidage", "classOpm_1_1RateConverter_1_1SurfaceToReservoirVoidage.html#a6ebd2f394a08249a6deda086ea7d6983", null ],
    [ "calcCoeff", "classOpm_1_1RateConverter_1_1SurfaceToReservoirVoidage.html#ac12e640a50b9520017a7ef750e48f4f7", null ],
    [ "calcCoeffSolvent", "classOpm_1_1RateConverter_1_1SurfaceToReservoirVoidage.html#a9584197527b91857646632a2304783a9", null ],
    [ "calcReservoirVoidageRates", "classOpm_1_1RateConverter_1_1SurfaceToReservoirVoidage.html#a9dcc6c49492a2f9d78420486b1f6d3b7", null ],
    [ "defineState", "classOpm_1_1RateConverter_1_1SurfaceToReservoirVoidage.html#aef14a3a86b0548cc4278ddf6d04c6d94", null ]
];