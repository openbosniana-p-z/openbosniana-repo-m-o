var classOpm_1_1WellInterfaceGeneric =
[
    [ "OperabilityStatus", "structOpm_1_1WellInterfaceGeneric_1_1OperabilityStatus.html", null ],
    [ "cells", "classOpm_1_1WellInterfaceGeneric.html#a2e808c9f3b89d98c27985bcaac0e746a", null ],
    [ "indexOfWell", "classOpm_1_1WellInterfaceGeneric.html#a4a569bd7909198929e3ec2f7237323dc", null ],
    [ "isInjector", "classOpm_1_1WellInterfaceGeneric.html#aca08445e1481de8ddf061a6e08112e0b", null ],
    [ "isProducer", "classOpm_1_1WellInterfaceGeneric.html#aba11499b2165a3ab98a9f87a83015354", null ],
    [ "name", "classOpm_1_1WellInterfaceGeneric.html#a8d09f363a3f18af570b308b629bd3e67", null ],
    [ "perforationData", "classOpm_1_1WellInterfaceGeneric.html#af33f47e991a151cbe6b4924158556ef7", null ],
    [ "underPredictionMode", "classOpm_1_1WellInterfaceGeneric.html#ab4babc3cb108c044518575393c1de868", null ],
    [ "wellHasTHPConstraints", "classOpm_1_1WellInterfaceGeneric.html#a01c14f84d204f93d5498fe5468c62f48", null ]
];