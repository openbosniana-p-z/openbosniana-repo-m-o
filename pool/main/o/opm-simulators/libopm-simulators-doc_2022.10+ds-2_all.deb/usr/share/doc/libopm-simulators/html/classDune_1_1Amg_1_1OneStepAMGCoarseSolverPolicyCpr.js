var classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr =
[
    [ "AMGType", "classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr.html#a136255df5f4201e4b446b0d1f672fe1c", null ],
    [ "CoarseLevelSolver", "classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr.html#a203655f3b4e127677494b28f616c50bb", null ],
    [ "Criterion", "classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr.html#a651dfae00f239b33378f0e06522f47c9", null ],
    [ "Operator", "classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr.html#adfd200a4b13ebc51cee8229ee1cf0d74", null ],
    [ "Smoother", "classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr.html#a2f3ab3cd1246220c758579bb0e717571", null ],
    [ "SmootherArgs", "classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr.html#a6cdded79ac8f95fb7c3350d2030677b0", null ],
    [ "X", "classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr.html#a973747ededd216b61679113d54ebc875", null ],
    [ "OneStepAMGCoarseSolverPolicyCpr", "classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr.html#a9d85824a08d0279efdf669cd4b8a4f30", null ],
    [ "OneStepAMGCoarseSolverPolicyCpr", "classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr.html#a164dde8f95bd585880020fd3ebe1c310", null ],
    [ "createCoarseLevelSolver", "classDune_1_1Amg_1_1OneStepAMGCoarseSolverPolicyCpr.html#a919aa41b38e7913240e5b6585295f4ae", null ]
];