var RegionAverageCalculator_8hpp =
[
    [ "Opm::RegionAverageCalculator::AverageRegionalPressure< FluidSystem, Region >", "classOpm_1_1RegionAverageCalculator_1_1AverageRegionalPressure.html", "classOpm_1_1RegionAverageCalculator_1_1AverageRegionalPressure" ]
];