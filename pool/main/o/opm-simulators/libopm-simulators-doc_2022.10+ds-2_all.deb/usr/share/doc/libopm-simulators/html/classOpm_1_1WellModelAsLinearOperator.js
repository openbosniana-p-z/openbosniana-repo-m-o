var classOpm_1_1WellModelAsLinearOperator =
[
    [ "apply", "classOpm_1_1WellModelAsLinearOperator.html#a38cd7f28541329fea05a2db03a5cb966", null ],
    [ "applyscaleadd", "classOpm_1_1WellModelAsLinearOperator.html#aa69b29a211e27610bb7d7e057f5461b5", null ],
    [ "category", "classOpm_1_1WellModelAsLinearOperator.html#ac38c58bcede45c7af3293880ad52a65d", null ]
];