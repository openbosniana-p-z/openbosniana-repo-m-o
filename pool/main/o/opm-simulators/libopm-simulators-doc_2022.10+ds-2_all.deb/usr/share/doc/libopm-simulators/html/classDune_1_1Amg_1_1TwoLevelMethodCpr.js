var classDune_1_1Amg_1_1TwoLevelMethodCpr =
[
    [ "CoarseDomainType", "classDune_1_1Amg_1_1TwoLevelMethodCpr.html#a8f17f5ba26de34d6e0e442190442cd58", null ],
    [ "CoarseLevelSolver", "classDune_1_1Amg_1_1TwoLevelMethodCpr.html#ada2dc26d9c9d9feb4d12128b7a36786a", null ],
    [ "CoarseLevelSolverPolicy", "classDune_1_1Amg_1_1TwoLevelMethodCpr.html#ab82311ac395199c942b915e08a18a796", null ],
    [ "CoarseOperatorType", "classDune_1_1Amg_1_1TwoLevelMethodCpr.html#a9800aab6aa9a8b6f9046c27d34febbea", null ],
    [ "CoarseRangeType", "classDune_1_1Amg_1_1TwoLevelMethodCpr.html#ade9c2e1dcdf368940a69b561a0093ebc", null ],
    [ "FineDomainType", "classDune_1_1Amg_1_1TwoLevelMethodCpr.html#a4302ce5116f341707f4c4535a692ab7c", null ],
    [ "FineOperatorType", "classDune_1_1Amg_1_1TwoLevelMethodCpr.html#afcf449f0c128cb200739f7b4aada432c", null ],
    [ "FineRangeType", "classDune_1_1Amg_1_1TwoLevelMethodCpr.html#a3bf06966e9301787a7c9d69706902513", null ],
    [ "SmootherType", "classDune_1_1Amg_1_1TwoLevelMethodCpr.html#a1933e4c312b8d549cbdf77d865ef9ca6", null ],
    [ "TwoLevelMethodCpr", "classDune_1_1Amg_1_1TwoLevelMethodCpr.html#a3eb3b793eb81f6a3e8ac341174f97aed", null ]
];