var classOpm_1_1MultisegmentWellGeneric =
[
    [ "detectOscillations", "classOpm_1_1MultisegmentWellGeneric.html#a8f8cf82d2ebbd8870c213c9384a0deff", null ],
    [ "numberOfSegments", "classOpm_1_1MultisegmentWellGeneric.html#a1f08079a26dca05d8d722547bd5d9b2c", null ]
];