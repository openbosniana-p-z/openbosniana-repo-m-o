var classOpm_1_1BdaBridge =
[
    [ "BdaBridge", "classOpm_1_1BdaBridge.html#aa46643ebf67748b050e80b4bb34c42b9", null ],
    [ "get_result", "classOpm_1_1BdaBridge.html#a21ab80e4a771c84f3ffaa489b542b427", null ],
    [ "getAccleratorName", "classOpm_1_1BdaBridge.html#aef2f9a9e9df140ca79360d6bfd3b0603", null ],
    [ "getUseFpga", "classOpm_1_1BdaBridge.html#aeed88bc03cfb9ed036088a72b08be109", null ],
    [ "getUseGpu", "classOpm_1_1BdaBridge.html#a953b2d43da3c3719df95c87f9329624a", null ],
    [ "initWellContributions", "classOpm_1_1BdaBridge.html#a9b0c751a86969d4bede9f80219f68e6c", null ],
    [ "solve_system", "classOpm_1_1BdaBridge.html#aaf8d9f8cc664b8d7d3841822c07d7d06", null ]
];