var classOpm_1_1Accelerator_1_1openclSolverBackend =
[
    [ "openclSolverBackend", "classOpm_1_1Accelerator_1_1openclSolverBackend.html#aaee1963bf12a2888272b26a5a5e7db5d", null ],
    [ "openclSolverBackend", "classOpm_1_1Accelerator_1_1openclSolverBackend.html#a77b4c3a4a04658efbe0fb566cd57c36c", null ],
    [ "~openclSolverBackend", "classOpm_1_1Accelerator_1_1openclSolverBackend.html#a29f18962488d6a60170235f572524076", null ],
    [ "get_result", "classOpm_1_1Accelerator_1_1openclSolverBackend.html#a2f30a0051aa8bd561cc0b8ed463eaf6f", null ],
    [ "setOpencl", "classOpm_1_1Accelerator_1_1openclSolverBackend.html#ab5979b8d908e550273740e7b92c54d03", null ],
    [ "solve_system", "classOpm_1_1Accelerator_1_1openclSolverBackend.html#acd7efbd056b682b9cd17253e88ef25fc", null ]
];