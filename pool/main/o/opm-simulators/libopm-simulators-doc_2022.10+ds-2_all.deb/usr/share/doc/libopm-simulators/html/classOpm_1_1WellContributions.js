var classOpm_1_1WellContributions =
[
    [ "MatrixType", "classOpm_1_1WellContributions.html#a9fa3b1edd047478ed778ae7670d1e0d4", [
      [ "C", "classOpm_1_1WellContributions.html#a9fa3b1edd047478ed778ae7670d1e0d4a0d61f8370cad1d412f80b84d143e1257", null ],
      [ "D", "classOpm_1_1WellContributions.html#a9fa3b1edd047478ed778ae7670d1e0d4af623e75af30e62bbd73d6df5b50bb7b5", null ],
      [ "B", "classOpm_1_1WellContributions.html#a9fa3b1edd047478ed778ae7670d1e0d4a9d5ed678fe57bcca610140957afab571", null ]
    ] ],
    [ "~WellContributions", "classOpm_1_1WellContributions.html#a2f57eea291acbf6e1097749ec882c1e6", null ],
    [ "addMatrix", "classOpm_1_1WellContributions.html#a7b14355b03374910f2aca97f656f16d9", null ],
    [ "addMultisegmentWellContribution", "classOpm_1_1WellContributions.html#a93c99c6222b2f665903d054177266f1d", null ],
    [ "addNumBlocks", "classOpm_1_1WellContributions.html#acf957c671091a6a99f6c484e21e8477f", null ],
    [ "alloc", "classOpm_1_1WellContributions.html#aad64138129826da8cfd2053b13b5fe64", null ],
    [ "APIaddMatrix", "classOpm_1_1WellContributions.html#ad6782ca918b02af7529ab26d1cbbc6c2", null ],
    [ "APIalloc", "classOpm_1_1WellContributions.html#a77decfb8cb05f3c9f339e997a4b7fb78", null ],
    [ "setBlockSize", "classOpm_1_1WellContributions.html#a62bc8ab329656ff97b43697dc941c74a", null ],
    [ "setVectorSize", "classOpm_1_1WellContributions.html#ac57d3db8bc02df33c1eb328c5e89186e", null ]
];