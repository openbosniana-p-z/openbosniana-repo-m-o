var classDune_1_1Amg_1_1LevelTransferPolicyCpr =
[
    [ "CoarseDomainType", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a3a8fbc19d6d3ddba085c9306fefcd5db", null ],
    [ "CoarseOperatorType", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#ab5469e58ba3a0f2a59aaa9fe00a252e2", null ],
    [ "CoarseRangeType", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a0029c3f4de9c91d4089856b5660a375d", null ],
    [ "FineDomainType", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a93b4cf24e0968e28b793e5ff184847e9", null ],
    [ "FineOperatorType", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a27fbee1d1f2bb358a0d6f2d8f8f96eae", null ],
    [ "FineRangeType", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a4a8d4b11f4b9ffba02fdaa1568fbcd2c", null ],
    [ "~LevelTransferPolicyCpr", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a55d310727721d0fc666c746fa893629d", null ],
    [ "calculateCoarseEntries", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a64e07684fe950ac64174c20fbc4188f9", null ],
    [ "clone", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a0e91b07bcbbf0d3046a46847b01f29f7", null ],
    [ "createCoarseLevelSystem", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a2832abab4aed915bc0ba5796f4a32c3c", null ],
    [ "getCoarseLevelLhs", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a036f12e83f05f2788063bb8aa3a9f105", null ],
    [ "getCoarseLevelOperator", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#aebc9f48418eeaeecaec4c71ed063f820", null ],
    [ "getCoarseLevelRhs", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a4b18ef71b15c2d74f85b6c97fe19a340", null ],
    [ "moveToCoarseLevel", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a31135461c33aca9e5dd4d104b936e8fd", null ],
    [ "moveToFineLevel", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a56801b3cdc40754a935104ee6cfdc70f", null ],
    [ "lhs_", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a76784d1c0519722c67aeed88006b96f4", null ],
    [ "operator_", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#af4c9ce3dd1bfda7908e39dd20afd0176", null ],
    [ "rhs_", "classDune_1_1Amg_1_1LevelTransferPolicyCpr.html#a7e9e7ce19a567547bb4a3e739e580e73", null ]
];