var classOpm_1_1HardcodedTimeStepControl =
[
    [ "HardcodedTimeStepControl", "classOpm_1_1HardcodedTimeStepControl.html#afe934365455358ea17ee47ea9d28c6cf", null ],
    [ "computeTimeStepSize", "classOpm_1_1HardcodedTimeStepControl.html#a03eff9ce10d563289126caeb58d75a52", null ]
];