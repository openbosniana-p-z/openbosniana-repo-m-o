var classDune_1_1Amg_1_1AggregationLevelTransferPolicyCpr =
[
    [ "clone", "classDune_1_1Amg_1_1AggregationLevelTransferPolicyCpr.html#ae0a2ab7d7bf78203728b3d720c9af15e", null ],
    [ "createCoarseLevelSystem", "classDune_1_1Amg_1_1AggregationLevelTransferPolicyCpr.html#a7a5681c6aeb9b44116a05127ffb5e39b", null ],
    [ "moveToFineLevel", "classDune_1_1Amg_1_1AggregationLevelTransferPolicyCpr.html#a071e322acfe4acda09cc84e51ac1a932", null ]
];