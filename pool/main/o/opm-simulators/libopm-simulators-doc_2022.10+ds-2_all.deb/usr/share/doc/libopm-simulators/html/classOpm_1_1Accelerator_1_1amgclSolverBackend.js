var classOpm_1_1Accelerator_1_1amgclSolverBackend =
[
    [ "amgclSolverBackend", "classOpm_1_1Accelerator_1_1amgclSolverBackend.html#ac1e13cd6ec5284037c99fee2d42cb11b", null ],
    [ "~amgclSolverBackend", "classOpm_1_1Accelerator_1_1amgclSolverBackend.html#a9ea59d254936049a7f22605c02a812a8", null ],
    [ "get_result", "classOpm_1_1Accelerator_1_1amgclSolverBackend.html#ab23dcdf98e1ca3f0bd9e2a420d9ca646", null ],
    [ "solve_system", "classOpm_1_1Accelerator_1_1amgclSolverBackend.html#aa3e59e598d71cbdcbc023a5fddb992a7", null ]
];