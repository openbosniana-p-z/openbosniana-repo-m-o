var classOpm_1_1MultisegmentWell =
[
    [ "apply", "classOpm_1_1MultisegmentWell.html#ad074f311c5860295a63c5b446de2a8b4", null ],
    [ "apply", "classOpm_1_1MultisegmentWell.html#a5d5d3ff0707a38383722658bb9104e71", null ],
    [ "computeCurrentWellRates", "classOpm_1_1MultisegmentWell.html#a7e965b1e365f30a03a142d4d807faa62", null ],
    [ "computeWellPotentials", "classOpm_1_1MultisegmentWell.html#aceca673e7dfc8ac469b3f881e9336a46", null ],
    [ "getWellConvergence", "classOpm_1_1MultisegmentWell.html#ad958f758e081e1cf8efadb649c54dc42", null ],
    [ "recoverWellSolutionAndUpdateWellState", "classOpm_1_1MultisegmentWell.html#a330c482022f2251a378086214a3981ce", null ],
    [ "updateWellStateWithTarget", "classOpm_1_1MultisegmentWell.html#a164239b270a212d30129e0e5b31df035", null ]
];