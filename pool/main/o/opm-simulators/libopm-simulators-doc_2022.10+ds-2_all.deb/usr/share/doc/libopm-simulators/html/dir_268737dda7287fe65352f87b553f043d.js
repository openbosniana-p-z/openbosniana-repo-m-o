var dir_268737dda7287fe65352f87b553f043d =
[
    [ "BILU0.hpp", "BILU0_8hpp_source.html", null ],
    [ "BISAI.hpp", "BISAI_8hpp_source.html", null ],
    [ "ChowPatelIlu.hpp", "ChowPatelIlu_8hpp_source.html", null ],
    [ "CPR.hpp", "CPR_8hpp_source.html", null ],
    [ "opencl.hpp", "opencl_8hpp_source.html", null ],
    [ "openclKernels.hpp", "openclKernels_8hpp_source.html", null ],
    [ "OpenclMatrix.hpp", "OpenclMatrix_8hpp_source.html", null ],
    [ "openclSolverBackend.hpp", "openclSolverBackend_8hpp_source.html", null ],
    [ "openclWellContributions.hpp", "openclWellContributions_8hpp_source.html", null ],
    [ "Preconditioner.hpp", "Preconditioner_8hpp_source.html", null ]
];