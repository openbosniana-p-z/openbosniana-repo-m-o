var classOpm_1_1DeferredLogger =
[
    [ "Message", "structOpm_1_1DeferredLogger_1_1Message.html", null ],
    [ "clearMessages", "classOpm_1_1DeferredLogger.html#a61618839303c05320882b52b5560175a", null ],
    [ "logMessages", "classOpm_1_1DeferredLogger.html#a4d4a82bebd1894dcf45ab14bf13669c8", null ],
    [ "gatherDeferredLogger", "classOpm_1_1DeferredLogger.html#a771e6a6b6671b6539bc9f7b8984024d6", null ]
];