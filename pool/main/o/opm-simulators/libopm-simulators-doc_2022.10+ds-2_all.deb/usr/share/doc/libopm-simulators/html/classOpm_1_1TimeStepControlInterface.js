var classOpm_1_1TimeStepControlInterface =
[
    [ "~TimeStepControlInterface", "classOpm_1_1TimeStepControlInterface.html#a8c1923d57047729673740b25090b93de", null ],
    [ "computeTimeStepSize", "classOpm_1_1TimeStepControlInterface.html#ae8885a9dd5ebfa356333bdf41d3973ee", null ]
];