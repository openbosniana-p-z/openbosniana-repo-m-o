var classOpm_1_1RelativeChangeInterface =
[
    [ "~RelativeChangeInterface", "classOpm_1_1RelativeChangeInterface.html#a696c98a40fedc3eb6ddf3c9e088d2fa5", null ],
    [ "relativeChange", "classOpm_1_1RelativeChangeInterface.html#a764fe694acc0a4f19eae7d152fc6c5dc", null ]
];