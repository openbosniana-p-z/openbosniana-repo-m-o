var classOpm_1_1PressureBhpTransferPolicy =
[
    [ "calculateCoarseEntries", "classOpm_1_1PressureBhpTransferPolicy.html#a251236827a06df3843796931ba89d4f6", null ],
    [ "clone", "classOpm_1_1PressureBhpTransferPolicy.html#a695ca0c5b9b76ca25bb1e131b6b66ad7", null ],
    [ "createCoarseLevelSystem", "classOpm_1_1PressureBhpTransferPolicy.html#ae62b538c6e3245ee8574c958b5542bed", null ],
    [ "moveToFineLevel", "classOpm_1_1PressureBhpTransferPolicy.html#a1f56de37bc946af65102fe47b3945237", null ]
];