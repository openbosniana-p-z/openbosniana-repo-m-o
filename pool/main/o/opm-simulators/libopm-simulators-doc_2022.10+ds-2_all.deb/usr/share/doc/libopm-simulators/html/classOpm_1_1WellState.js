var classOpm_1_1WellState =
[
    [ "init", "classOpm_1_1WellState.html#a1f4619800609d5d24b2f81647537256d", null ],
    [ "initWellStateMSWell", "classOpm_1_1WellState.html#a2d2e8279fae66eb2366e12109e2a43fa", null ],
    [ "numPhases", "classOpm_1_1WellState.html#a9d1412c547db996bcd020dbba34361d6", null ],
    [ "wellRates", "classOpm_1_1WellState.html#afbf86c93b13808ae29b854f10e6d5b66", null ]
];