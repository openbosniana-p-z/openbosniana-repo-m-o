var dir_2536a382f724192279985fbe5a154b08 =
[
    [ "satfunc", "dir_08afb449c6dabae2ccb017772094bda4.html", "dir_08afb449c6dabae2ccb017772094bda4" ],
    [ "BlackoilPhases.hpp", "BlackoilPhases_8hpp_source.html", null ],
    [ "phaseUsageFromDeck.hpp", "phaseUsageFromDeck_8hpp_source.html", null ]
];