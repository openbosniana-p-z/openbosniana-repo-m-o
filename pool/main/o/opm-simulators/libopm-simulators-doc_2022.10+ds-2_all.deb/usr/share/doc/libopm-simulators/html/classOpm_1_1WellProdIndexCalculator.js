var classOpm_1_1WellProdIndexCalculator =
[
    [ "WellProdIndexCalculator", "classOpm_1_1WellProdIndexCalculator.html#a896069be2fa8e74eacdc9bf3327a5dd7", null ],
    [ "connectionProdIndStandard", "classOpm_1_1WellProdIndexCalculator.html#a9fccef16e34ea8d8f5b6690950e8503c", null ],
    [ "numConnections", "classOpm_1_1WellProdIndexCalculator.html#a2ffc56976a88cfbc416f9e13d28b813b", null ],
    [ "reInit", "classOpm_1_1WellProdIndexCalculator.html#af956b69ce589e5d98cca62060d24694a", null ]
];