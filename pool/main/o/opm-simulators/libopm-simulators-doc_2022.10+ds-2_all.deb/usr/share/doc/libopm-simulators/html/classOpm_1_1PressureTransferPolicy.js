var classOpm_1_1PressureTransferPolicy =
[
    [ "calculateCoarseEntries", "classOpm_1_1PressureTransferPolicy.html#a2f43da36447a2293a340aa4250d8fd52", null ],
    [ "clone", "classOpm_1_1PressureTransferPolicy.html#a08ad310c4442beccf1d65d9277243fe5", null ],
    [ "createCoarseLevelSystem", "classOpm_1_1PressureTransferPolicy.html#a1be9cea9707a8f1531f0d9970cf526e0", null ],
    [ "moveToFineLevel", "classOpm_1_1PressureTransferPolicy.html#ab743c51e68f2d29d3298663c7ded071f", null ]
];