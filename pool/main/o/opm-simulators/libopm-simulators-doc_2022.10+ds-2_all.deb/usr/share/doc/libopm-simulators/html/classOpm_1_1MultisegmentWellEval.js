var classOpm_1_1MultisegmentWellEval =
[
    [ "addWellContribution", "classOpm_1_1MultisegmentWellEval.html#a3eff66f3182f1af94d93e4d08963cbfd", null ],
    [ "getWellConvergence", "classOpm_1_1MultisegmentWellEval.html#a670d9b2a77c62cfd0eb877cbe5765d28", null ],
    [ "duneDSolver_", "classOpm_1_1MultisegmentWellEval.html#ab883ce774897ae532a13075cdc6c5221", null ]
];