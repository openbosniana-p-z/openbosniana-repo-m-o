var classOpm_1_1WellContributionsCuda =
[
    [ "APIaddMatrix", "classOpm_1_1WellContributionsCuda.html#a7765ebcd22a3377b267b6ced19ab0fbc", null ],
    [ "APIalloc", "classOpm_1_1WellContributionsCuda.html#a27e31159ee526bb923e4f7e9b2d99f76", null ],
    [ "apply", "classOpm_1_1WellContributionsCuda.html#a7919faea2f14759db0a3c892a7466f8c", null ],
    [ "setCudaStream", "classOpm_1_1WellContributionsCuda.html#ab6fb26f3bc3dd66e49589acea33b2931", null ]
];