var classOpm_1_1MultisegmentWellContribution =
[
    [ "MultisegmentWellContribution", "classOpm_1_1MultisegmentWellContribution.html#a70d1296dc368e835a380de273485049d", null ],
    [ "~MultisegmentWellContribution", "classOpm_1_1MultisegmentWellContribution.html#a0bbb6d181c81fea79ee8e239f574cf14", null ],
    [ "apply", "classOpm_1_1MultisegmentWellContribution.html#a2f6dc6d7b20e4cc226a974e9d193c807", null ],
    [ "setReordering", "classOpm_1_1MultisegmentWellContribution.html#ac1368daef137557593bfc90487ec1109", null ]
];