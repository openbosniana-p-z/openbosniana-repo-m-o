var classOpm_1_1VFPProperties =
[
    [ "VFPProperties", "classOpm_1_1VFPProperties.html#a183440e15eca5a9631e41438b62b77cb", null ],
    [ "getInj", "classOpm_1_1VFPProperties.html#aa7cf0b57d4720dda9b7b409b30991602", null ],
    [ "getProd", "classOpm_1_1VFPProperties.html#a7cc22ca8180de0bda1f83ad044dab99d", null ]
];