var classOpm_1_1RegionAverageCalculator_1_1AverageRegionalPressure =
[
    [ "RegionId", "classOpm_1_1RegionAverageCalculator_1_1AverageRegionalPressure.html#ade5930f543b6e2a2f003d08591ecfb57", null ],
    [ "AverageRegionalPressure", "classOpm_1_1RegionAverageCalculator_1_1AverageRegionalPressure.html#a599988d9a0609270bca501a22ab64372", null ],
    [ "defineState", "classOpm_1_1RegionAverageCalculator_1_1AverageRegionalPressure.html#a0fcc1eca36026a33bee5e2e7b3c8a890", null ],
    [ "pressure", "classOpm_1_1RegionAverageCalculator_1_1AverageRegionalPressure.html#a77b35cb26b5ab7f9295dac4f8c86781d", null ]
];