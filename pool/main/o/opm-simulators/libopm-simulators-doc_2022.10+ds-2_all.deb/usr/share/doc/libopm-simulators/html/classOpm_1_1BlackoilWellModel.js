var classOpm_1_1BlackoilWellModel =
[
    [ "calculateExplicitQuantities", "classOpm_1_1BlackoilWellModel.html#aafad73ce1eb129639c9dfa0eaae82e6e", null ],
    [ "compressedIndexForInterior", "classOpm_1_1BlackoilWellModel.html#aef2504ac264bc80f118025d02ff83c0a", null ],
    [ "localNonshutWells", "classOpm_1_1BlackoilWellModel.html#a18e91760b2ec6040dbda1c29af13d1ac", null ],
    [ "serialize", "classOpm_1_1BlackoilWellModel.html#a0f4e852a08eb8a93174bebdd55dc8eb6", null ],
    [ "updateWellTestState", "classOpm_1_1BlackoilWellModel.html#aec077f7fd99764694e7a5b79e2769675", null ]
];