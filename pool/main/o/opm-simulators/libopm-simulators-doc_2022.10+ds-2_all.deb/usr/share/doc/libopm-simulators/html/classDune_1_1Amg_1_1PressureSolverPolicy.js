var classDune_1_1Amg_1_1PressureSolverPolicy =
[
    [ "CoarseLevelSolver", "classDune_1_1Amg_1_1PressureSolverPolicy.html#acf23916b58030f44c59f27b934b3bc49", null ],
    [ "Operator", "classDune_1_1Amg_1_1PressureSolverPolicy.html#a8f7547c361ac7b378905b7852f221d22", null ],
    [ "PressureSolverPolicy", "classDune_1_1Amg_1_1PressureSolverPolicy.html#a7fdf15337c579000b766ad2bc357151c", null ],
    [ "setCoarseOperator", "classDune_1_1Amg_1_1PressureSolverPolicy.html#ad8c440dd054bff3409f059d9d48f4378", null ]
];