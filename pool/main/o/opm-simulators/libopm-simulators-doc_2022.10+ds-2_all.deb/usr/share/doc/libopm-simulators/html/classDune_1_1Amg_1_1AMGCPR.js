var classDune_1_1Amg_1_1AMGCPR =
[
    [ "CoarseSolver", "group__ISTL__PAAMG.html#gacc546106cbaf5993d7d1298a5eb26673", null ],
    [ "Domain", "group__ISTL__PAAMG.html#ga9f06d7b5688446f0a2835e380d8c69e0", null ],
    [ "Operator", "group__ISTL__PAAMG.html#ga0a18f781d99fb01684a899a1084b4aaf", null ],
    [ "OperatorHierarchy", "group__ISTL__PAAMG.html#ga3c12cdceae3685f273b0d40e814ca581", null ],
    [ "ParallelInformation", "group__ISTL__PAAMG.html#gac533b41338d689052a2afa3fa865f6b0", null ],
    [ "ParallelInformationHierarchy", "group__ISTL__PAAMG.html#ga78743822417ee4d114b3b2443ce439ec", null ],
    [ "Range", "group__ISTL__PAAMG.html#ga94a8b29220922b85eb5c583e64bedb25", null ],
    [ "Smoother", "group__ISTL__PAAMG.html#gaaae6712649c9452c3c31bc0fd5a14321", null ],
    [ "SmootherArgs", "group__ISTL__PAAMG.html#ga89ecc95f5877dad5f800dce619cf6046", null ],
    [ "AMGCPR", "group__ISTL__PAAMG.html#ga2433f39cbaebb4a42c32ea1a122a1ff2", null ],
    [ "AMGCPR", "group__ISTL__PAAMG.html#gab2fd894a7cedbc2d673e89a84b8cff50", null ],
    [ "AMGCPR", "group__ISTL__PAAMG.html#ga0cb22117096c01c53f8acd3f6927aaa6", null ],
    [ "apply", "group__ISTL__PAAMG.html#ga51746dac747998811d39c6a93c0430d3", null ],
    [ "category", "group__ISTL__PAAMG.html#ga4e1f3e61c260507db2cee1eaa673aef0", null ],
    [ "getCoarsestAggregateNumbers", "group__ISTL__PAAMG.html#ga701c9a08650984d0b3ab79e7a6a202a6", null ],
    [ "post", "group__ISTL__PAAMG.html#ga77cecebbe0048aa666520af9af5c5b1b", null ],
    [ "pre", "group__ISTL__PAAMG.html#ga62af014929a303d66e199f502348b49d", null ],
    [ "recalculateHierarchy", "group__ISTL__PAAMG.html#ga7e8758517d9dd0471eb64c4c7f8a5d33", null ],
    [ "update", "group__ISTL__PAAMG.html#gac3e5a5117a62b00409ac2ae2ad9b452b", null ],
    [ "updateSolver", "group__ISTL__PAAMG.html#gaab61862d26acc9c8b2d451923d82af5a", null ],
    [ "usesDirectCoarseLevelSolver", "group__ISTL__PAAMG.html#gad2f4d20ec4d6bf96f7fc293b026c8751", null ]
];