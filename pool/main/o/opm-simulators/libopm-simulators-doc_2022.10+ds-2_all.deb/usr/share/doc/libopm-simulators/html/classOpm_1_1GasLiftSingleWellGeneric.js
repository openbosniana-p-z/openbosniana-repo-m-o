var classOpm_1_1GasLiftSingleWellGeneric =
[
    [ "BasicRates", "structOpm_1_1GasLiftSingleWellGeneric_1_1BasicRates.html", null ],
    [ "GradInfo", "structOpm_1_1GasLiftSingleWellGeneric_1_1GradInfo.html", null ],
    [ "LimitedRates", "structOpm_1_1GasLiftSingleWellGeneric_1_1LimitedRates.html", null ],
    [ "OptimizeState", "structOpm_1_1GasLiftSingleWellGeneric_1_1OptimizeState.html", null ]
];