var classOpm_1_1WellInterface =
[
    [ "WellInterface", "classOpm_1_1WellInterface.html#a9394c1072001befec800a1de2993e242", null ],
    [ "~WellInterface", "classOpm_1_1WellInterface.html#a8da2cd8ebfbf744472c5d931ee5fda29", null ],
    [ "apply", "classOpm_1_1WellInterface.html#a8816c4e180a4b5f144fd73b89499ad6c", null ],
    [ "apply", "classOpm_1_1WellInterface.html#a532b702b3ce90a53c02c6d2a56bfa284", null ],
    [ "computeCurrentWellRates", "classOpm_1_1WellInterface.html#a704e4dff8862afcb9d7a7a08d521bbf0", null ],
    [ "jacobianContainsWellContributions", "classOpm_1_1WellInterface.html#abc47ce08d3951fb74856360b4d1f8005", null ],
    [ "recoverWellSolutionAndUpdateWellState", "classOpm_1_1WellInterface.html#a8f350f7231fec741df9c0fe0971a37fb", null ],
    [ "updateWellStateRates", "classOpm_1_1WellInterface.html#a625e2754f6a5d7752b39cb1cbbe4e4d6", null ]
];