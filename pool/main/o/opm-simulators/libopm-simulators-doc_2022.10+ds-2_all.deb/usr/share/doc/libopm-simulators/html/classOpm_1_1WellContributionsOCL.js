var classOpm_1_1WellContributionsOCL =
[
    [ "APIaddMatrix", "classOpm_1_1WellContributionsOCL.html#a746b829060876054be2dbad8920d1baf", null ],
    [ "APIalloc", "classOpm_1_1WellContributionsOCL.html#a38d2b575b18f2a18cae403f3215ef4d0", null ],
    [ "setReordering", "classOpm_1_1WellContributionsOCL.html#a9c965fdc83ed608def4969d810e0f618", null ]
];