var classOpm_1_1SimpleIterationCountTimeStepControl =
[
    [ "SimpleIterationCountTimeStepControl", "classOpm_1_1SimpleIterationCountTimeStepControl.html#a263d531facd11d05e0e2d09dd80a679a", null ],
    [ "computeTimeStepSize", "classOpm_1_1SimpleIterationCountTimeStepControl.html#adc721e49148717ef964398037c50b8ab", null ]
];