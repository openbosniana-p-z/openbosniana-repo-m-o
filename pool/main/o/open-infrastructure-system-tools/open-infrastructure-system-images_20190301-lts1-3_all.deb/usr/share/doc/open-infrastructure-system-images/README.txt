NAME
----
system-images - Debian based live and installer images


DESCRIPTION
-----------
"In computing, configuration files, or config files configure the initial
settings for some computer programs."

    -- Wikipedia (https://en.wikipedia.org/wiki/Configuration_file)

system-images contains configuration trees of some Debian based live and
installer images.


DOWNLOAD
--------
  * Upstream Releases: https://files.open-infrastructure.net/software/system-images/upstream
  * Upstream Sources: https://sources.open-infrastructure.net/software/system-images
  * Debian Releases: https://files.open-infrastructure.net/software/system-images/debian
  * Debian Sources: https://sources.progress-linux.org/users/daniel/debian/packages/open-infrastructure-system-images


INSTALLATION
------------

SOURCE
~~~~~~
  1. sudo apt install asciidoc git docbook-xml docbook-xsl libxml2-utils make xsltproc imagemagick librsvg2-bin
  2. git clone https://sources.open-infrastructure.net/software/system-images
  3. cd system-images && sudo make install

DEBIAN 9 (STRETCH) AND NEWER
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  * sudo apt install system-images


DEVELOPMENT
-----------
Bug reports, feature requests, help, patches, support and everything else
are welcome on the Open Infrastructure Software Mailing List:

  * https://lists.open-infrastructure.net/listinfo/software

Please base patches against the 'next' Git branch using common sense:

  * https://www.kernel.org/doc/Documentation/SubmittingPatches

Debian specific bugs can also be reported in the Debian Bug Tracking System:

  * https://bugs.debian.org


USAGE
-----
The following configuration trees are available:

	* base-system: a Debian based, minmal system,
	  see https://debian.org

	* container-server: a Container Server system using container-tools,
	  see https://open-infrastructure.net/software/container-tools

	* gnome-desktop: a GNOME Desktop system using GNOME,
	  see https://gnome.org

A software called system-build can be used to automatically build images from
this configuration tree.

system-build can be obtained from https://open-infrastructure.net/software/system-build.

On Debian based systems, system-build can be installed with:

  # apt-get install system-build

system-build can be used to build this image with the following command executed
in this directory::

  # lb build


AUTHORS
-------

  * Daniel Baumann <daniel.baumann@open-infrastructure.net>
