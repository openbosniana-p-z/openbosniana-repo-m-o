# 1 "src/mmap_unix.ml"
module V1 = struct
  let map_file = Unix.map_file
end
