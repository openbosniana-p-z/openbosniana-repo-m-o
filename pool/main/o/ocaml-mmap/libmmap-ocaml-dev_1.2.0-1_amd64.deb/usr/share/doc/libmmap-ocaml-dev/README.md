Mmap
====

This project provides a `Mmap.map_file` functions for mapping files in
memory. This function is the same as the `Unix.map_file` funciton
added in OCaml >= 4.06.
