(* .cma/.cmxa needs something OCaml-ish to go in it *)
