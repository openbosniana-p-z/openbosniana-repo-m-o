(** @canonical Re.Automata *)
module Automata = Re__Automata


(** @canonical Re.Category *)
module Category = Re__Category


(** @canonical Re.Color_map *)
module Color_map = Re__Color_map


(** @canonical Re.Core *)
module Core = Re__Core


(** @canonical Re.Cset *)
module Cset = Re__Cset


(** @canonical Re.Emacs *)
module Emacs = Re__Emacs


(** @canonical Re.Fmt *)
module Fmt = Re__Fmt


(** @canonical Re.Glob *)
module Glob = Re__Glob


(** @canonical Re.Group *)
module Group = Re__Group


(** @canonical Re.Pcre *)
module Pcre = Re__Pcre


(** @canonical Re.Perl *)
module Perl = Re__Perl


(** @canonical Re.Pmark *)
module Pmark = Re__Pmark


(** @canonical Re.Posix *)
module Posix = Re__Posix


(** @canonical Re.Str *)
module Str = Re__Str
