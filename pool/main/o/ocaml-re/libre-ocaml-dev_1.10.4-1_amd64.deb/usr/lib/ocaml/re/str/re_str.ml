[@@@deprecated "Use Re.Str"]

include Re.Str
