[@@@deprecated "Use Re.Posix"]

include Re.Posix
