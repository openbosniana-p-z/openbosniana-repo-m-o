[@@@deprecated "Use Re.Perl"]

include Re.Perl
