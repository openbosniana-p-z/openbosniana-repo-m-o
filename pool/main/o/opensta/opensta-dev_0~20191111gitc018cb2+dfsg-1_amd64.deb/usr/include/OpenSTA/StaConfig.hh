#define STA_VERSION "2.0.17"

#define STA_GIT_SHA1 "GITDIR-NOTFOUND"

#define ZLIB 1

#define CUDD 0

#define SSTA 0
