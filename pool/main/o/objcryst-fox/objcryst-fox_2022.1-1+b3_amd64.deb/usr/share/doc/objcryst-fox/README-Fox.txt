FOX, Free Objects for Xtallography is open-source software.
Please read the LICENSE file for more information.

The documentation for Fox is available online on the Fox wiki at:
   https://fox.vincefn.net

If this is your first use of Fox, please start with the tutorials :
   https://fox.vincefn.net/Tutorials


A static (pdf) version of the online documentation can also be downloaded from:
https://sourceforge.net/project/showfiles.php?group_id=27546&package_id=19521
