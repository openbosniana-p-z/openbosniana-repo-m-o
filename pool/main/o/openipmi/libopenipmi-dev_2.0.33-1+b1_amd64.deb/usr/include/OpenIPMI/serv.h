/* This file is now pulled into lanserv. */
#include <OpenIPMI/lanserv.h>
