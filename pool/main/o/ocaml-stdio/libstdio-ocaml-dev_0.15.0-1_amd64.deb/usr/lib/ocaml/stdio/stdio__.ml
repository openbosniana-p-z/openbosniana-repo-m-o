(** @canonical Stdio.In_channel *)
module In_channel = Stdio__In_channel


(** @canonical Stdio.Out_channel *)
module Out_channel = Stdio__Out_channel
