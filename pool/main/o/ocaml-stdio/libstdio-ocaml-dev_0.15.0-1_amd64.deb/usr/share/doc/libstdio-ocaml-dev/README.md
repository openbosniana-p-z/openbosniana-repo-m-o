# Standard IO Library for OCaml

Stdio provides input/output functions for OCaml.  It re-exports the
buffered channels of the stdlib distributed with OCaml but with some
improvements.

API documentation for the latest release can be found
[here][https://ocaml.janestreet.com/ocaml-core/latest/doc/stdio/index.html].
