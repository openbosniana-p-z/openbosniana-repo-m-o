(** @canonical Angstrom.Buffering *)
module Buffering = Angstrom__Buffering


(** @canonical Angstrom.Exported_state *)
module Exported_state = Angstrom__Exported_state


(** @canonical Angstrom.Input *)
module Input = Angstrom__Input


(** @canonical Angstrom.More *)
module More = Angstrom__More


(** @canonical Angstrom.Parser *)
module Parser = Angstrom__Parser
