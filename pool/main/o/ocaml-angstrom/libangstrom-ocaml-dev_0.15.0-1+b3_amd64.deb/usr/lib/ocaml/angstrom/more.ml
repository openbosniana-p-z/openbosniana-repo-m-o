type t = 
  | Complete
  | Incomplete
