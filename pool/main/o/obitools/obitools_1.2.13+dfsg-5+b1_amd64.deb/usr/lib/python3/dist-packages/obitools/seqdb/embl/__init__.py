from obitools.seqdb import AnnotatedNucSequence, AnnotatedAASequence
from obitools.location import locationGenerator,extractExternalRefs



class EmblSequence(AnnotatedNucSequence):
    '''
    Class used to represent a nucleic sequence issued from EMBL.
    '''
    
    
    

