
fnaTag=' %s *= *([^\s]+)'
