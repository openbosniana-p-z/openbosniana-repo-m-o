class EcoTagResult(dict):
    pass