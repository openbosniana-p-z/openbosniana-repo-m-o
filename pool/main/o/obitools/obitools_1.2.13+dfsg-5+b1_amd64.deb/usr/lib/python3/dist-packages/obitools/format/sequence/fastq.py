'''
Created on 15 janv. 2010

@author: coissac
'''

from obitools.fastq import fastqIterator,fastqParserGenetator
from obitools.fastq import fastqSangerIterator,fastqSolexaIterator, \
                           fastqIlluminaIterator
from obitools.fastq import fastFastqIterator,fastFastqParserGenetator
from obitools.fastq import fastFastqSangerIterator,fastFastqSolexaIterator, \
                           fastFastqIlluminaIterator
from obitools.fastq import fastqAAIterator
from obitools.fastq import formatFastq


