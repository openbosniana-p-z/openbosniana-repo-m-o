'''
Created on 12 oct. 2009

@author: coissac
'''

from obitools.fnaqual.fasta import fnaFastaIterator
from obitools.fnaqual.quality import qualityIterator
