from obitools.seqdb.embl.parser import emblIterator,emblParser

