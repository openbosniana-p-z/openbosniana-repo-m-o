"""
fasta module provides functions to read and write sequences in fasta format.


"""

from obitools.fasta._fasta import parseFastaDescription, \
                   fastaParser, fastaNucParser,fastaAAParser, fastFastaParser, \
                   fastaIterator,fastFastaIterator, rawFastaIterator, \
                   fastaNucIterator, fastaAAIterator, \
                   formatFasta, formatSAPFastaGenerator


