'''
Created on 24 sept. 2010

@author: coissac
'''

from obitools.ecopcr.taxonomy import  TaxonomyDump 
from obitools.ecopcr.taxonomy import  Taxonomy
import sys

class EcoTaxonomyDB(TaxonomyDump) :

    def __init__(self,dbconnect):
        self._dbconnect=dbconnect
        
        print("Reading ecobarcode taxonomy database...", file=sys.stderr)
        
        self._readNodeTable()
        print(" ok", file=sys.stderr)
         
        print("Adding scientific name...", file=sys.stderr)
    
        self._name=[]
        for taxid,name,classname in self._nameIterator():
            self._name.append((name,classname,self._index[taxid]))
            if classname == 'scientific name':
                self._taxonomy[self._index[taxid]].append(name)
            
        print("Adding taxid alias...", file=sys.stderr)
        for taxid,current in self._mergedNodeIterator():
            self._index[taxid]=self._index[current]
        
        print("Adding deleted taxid...", file=sys.stderr)
        for taxid in self._deletedNodeIterator():
            self._index[taxid]=None

        
        Taxonomy.__init__(self)

    #####
    #
    # Iterator functions
    #
    #####
                   
    def _readNodeTable(self):
    
        cursor = self._dbconnect.cursor()
        
        cursor.execute("""
                            select     taxid,rank,parent
                            from ncbitaxonomy.nodes
                       """)
        
        print("Reading taxonomy nodes...", file=sys.stderr)
        taxonomy=[list(n) for n in cursor]
        
        print("List all taxonomy rank...", file=sys.stderr)    
        ranks =list(set(x[1] for x in taxonomy))
        ranks.sort()
        rankidx = dict(map(None,ranks,range(len(ranks))))
        
        print("Sorting taxons...", file=sys.stderr)
        taxonomy.sort(TaxonomyDump._taxonCmp)

        self._taxonomy=taxonomy
    
        print("Indexing taxonomy...", file=sys.stderr)
        index = {}
        for t in self._taxonomy:
            index[t[0]]=self._bsearchTaxon(t[0])
        
        print("Indexing parent and rank...", file=sys.stderr)
        for t in self._taxonomy:
            t[1]=rankidx[t[1]]
            t[2]=index[t[2]]
         
        self._ranks=ranks
        self._index=index 
        
        cursor.close()

    def _nameIterator(self):
        cursor = self._dbconnect.cursor()
        
        cursor.execute("""
                            select     taxid,name,nameclass
                            from ncbitaxonomy.names
                       """)

        for taxid,name,nameclass in cursor:
            yield taxid,name,nameclass
            
        cursor.close()
                        
    def _mergedNodeIterator(self):
        cursor = self._dbconnect.cursor()
        
        cursor.execute("""
                            select     oldtaxid,newtaxid
                            from ncbitaxonomy.merged
                       """)

        for oldtaxid,newtaxid in cursor:
                yield oldtaxid,newtaxid
                
        cursor.close()
      
    def _deletedNodeIterator(self):
        cursor = self._dbconnect.cursor()
        
        cursor.execute("""
                            select  taxid
                            from ncbitaxonomy.delnodes
                       """)

        for taxid in cursor:
                yield taxid[0]

        cursor.close()
