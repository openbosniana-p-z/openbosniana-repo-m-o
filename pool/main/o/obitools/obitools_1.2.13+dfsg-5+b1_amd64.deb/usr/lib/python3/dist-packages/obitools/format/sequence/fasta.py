from obitools.fasta import fastFastaIterator,fastaIterator,fastaParser
from obitools.fasta import fastaAAIterator,fastaAAParser
from obitools.fasta import fastaNucIterator,fastaNucParser
from obitools.fasta import formatFasta
