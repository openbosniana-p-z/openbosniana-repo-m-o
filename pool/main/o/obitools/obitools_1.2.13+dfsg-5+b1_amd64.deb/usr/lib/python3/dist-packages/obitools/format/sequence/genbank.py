from obitools.seqdb.genbank.parser import genpepIterator,genpepParser
from obitools.seqdb.genbank.parser import genbankIterator,genbankParser


