major = 1
minor = 2
serial= '13'

version = "%2d.%02d %s" % (major,minor,serial)
