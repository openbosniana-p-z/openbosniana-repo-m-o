import unittest

from obitools.unit.obitools import tests_group as obitools_tests_group

tests_group=obitools_tests_group



