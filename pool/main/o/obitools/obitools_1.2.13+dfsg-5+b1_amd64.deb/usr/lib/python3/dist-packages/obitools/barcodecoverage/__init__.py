'''

@author: merciece
Creates the tree representing the coverage of 2 primers from an ecoPCR output file and an ecoPCR database.


'''