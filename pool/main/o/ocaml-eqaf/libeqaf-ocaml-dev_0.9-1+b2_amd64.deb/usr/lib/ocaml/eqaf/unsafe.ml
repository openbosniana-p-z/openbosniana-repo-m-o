let set_int32_le b i x = Bytes.set_int32_le b i x
let get_int64_le b i = Bytes.get_int64_le b i
