(** @canonical Eqaf.Unsafe *)
module Unsafe = Eqaf__Unsafe
