=============
compute-tools
=============

--------------------------------
Manage systemd-nspawn containers
--------------------------------

:manual section: 7
:manual group: Open Infrastructure

Description
===========

[A Linux container] is an operating-system-level virtualization environment for
running multiple isolated Linux systems (containers) on a single Linux control
host.

  -- Wikipedia (https://en.wikipedia.org/wiki/LXC)

**compute-tools** provides the system integration for managing containers using
systemd-nspawn(1).

Download
========

| Upstream Releases:
| https://get.open-infrastructure.net/software/compute-tools/upstream

| Upstream Sources:
| https://git.open-infrastructure.net/software/compute-tools

| Debian Releases:
| https://get.open-infrastructure.net/software/compute-tools/debian

| Debian Sources:
| https://git.progress-linux.org/users/daniel/debian/packages/open-infrastructure-compute-tools

Installation
============

Source
------

| $ sudo apt install git make python3-docutils dbus systemd-container
| $ git clone https://git.open-infrastructure.net/software/compute-tools
| $ cd compute-tools && sudo make install

Debian 9 (stretch) and newer
----------------------------

| $ sudo apt install compute-tools

Development
===========

Bug reports, feature requests, help, patches, support and everything else are
welcome on the Open Infrastructure Software Mailing List
(https://lists.open-infrastructure.net/listinfo/software).

Please base patches against the 'next' Git branch using common sense
(https://www.kernel.org/doc/Documentation/SubmittingPatches).

Debian specific bugs can also be reported in the Debian Bug Tracking System
(https://bugs.debian.org).

Known limitations
=================

This version of compute-tools currently do not work with systemd-networkd and
depend on ifupdown.

Using overlay, the upper directory can not be an NFS mount due to limitations in
Linux' overlay filesystem
(https://git.kernel.org/cgit/linux/kernel/git/torvalds/linux.git/tree/Documentation/filesystems/overlayfs.txt).

Usage
=====

Build a new container:
  sudo container build -n NAME

Start a container:
  sudo container start -n NAME

Stop a container:
  sudo container stop -n NAME

Remove a container:
  sudo container remove -n NAME

List container on the system:
  sudo container list

Show container version:
  container version

See container(1) for a list of all container commands.

Links
=====

| * Linux Weekly News: Kernel / Containers
|   (https://lwn.net/Kernel/Index/#Containers)

| * Linux Weekly News: Security / Containers
|   (https://lwn.net/Security/Index/#Containers)

| * 2016-02-24: Systemd vs. Docker
|   (https://lwn.net/Articles/676831/)

| * 2015-06-10: Systemd and containers
|  (https://lwn.net/Articles/647634/)

| * 2014-07-07: Control groups
|   (https://lwn.net/Articles/604609/)

| * 2013-11-13: Systemd-Nspawn is Chroot on Steroids [LinuxCon Europe]
|   (https://www.youtube.com/watch?v=s7LlUs5D9p4)

| * 2013-11-03: Creating containers with systemd-nspawn
|   (https://lwn.net/Articles/572957/)

| * 2013-02-06: Systemd lightweight containers
|   (https://lwn.net/Articles/536033/)

| * 2013-01-04: Namespaces in operation
|   (https://lwn.net/Articles/531114/)

Authors
=======

compute-tools were written by Daniel Baumann
<daniel.baumann@open-infrastructure.net> and others.
