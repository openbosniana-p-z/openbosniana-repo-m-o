#auto generated private file
function ext = get_exeext()
  ext = "";
endfunction
