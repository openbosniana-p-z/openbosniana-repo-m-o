# Code Samples of oneAPI Threading Building Blocks (oneTBB)
This directory contains the examples referenced by the [oneAPI Threading Building Blocks Get Started Guide](https://software.intel.com/content/www/us/en/develop/documentation/get-started-with-onetbb/top.html)

| Code sample name | Description
|:--- |:---
| sub_string_finder | Finds largest matching substrings.
