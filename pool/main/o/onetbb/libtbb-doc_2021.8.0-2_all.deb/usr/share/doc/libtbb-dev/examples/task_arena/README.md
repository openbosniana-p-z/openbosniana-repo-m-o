# Code Samples of oneAPI Threading Building Blocks (oneTBB)
Examples using the `task_arena` feature.

| Code sample name | Description
|:--- |:---
| fractal |The example calculates two classical Mandelbrot fractals with different concurrency limits.
