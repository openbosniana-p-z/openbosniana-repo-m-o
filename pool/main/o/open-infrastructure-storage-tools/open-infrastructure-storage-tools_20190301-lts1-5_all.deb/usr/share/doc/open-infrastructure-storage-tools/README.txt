NAME
----
storage-tools - Additional utilities to manage storage related tasks


DESCRIPTION
-----------
"Computer data storage [...] is a technology consisting of computer components
and recording media used to retain digital data. It is a core function and
fundamental component of computers."
    -- Wikipedia (https://en.wikipedia.org/wiki/Data_storage_device)

storage-tools contains additional utilities to manage storage related tasks.


DOWNLOAD
--------
  * Upstream Releases: https://files.open-infrastructure.net/software/storage-tools/upstream
  * Upstream Sources: https://sources.open-infrastructure.net/software/storage-tools
  * Debian Releases: https://files.open-infrastructure.net/software/storage-tools/debian
  * Debian Sources: https://sources.progress-linux.org/users/daniel/debian/packages/open-infrastructure-storage-tools


INSTALLATION
------------

SOURCE
~~~~~~
  1. sudo apt install asciidoc git docbook-xml docbook-xsl libxml2-utils make xsltproc
  2. git clone https://sources.open-infrastructure.net/software/storage-tools
  3. cd storage-tools && sudo make install

DEBIAN 10 (BUSTER) AND NEWER
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  * sudo apt install storage-tools


DEVELOPMENT
-----------
Bug reports, feature requests, help, patches, support and everything else
are welcome on the Open Infrastructure Software Mailing List:

  * https://lists.open-infrastructure.net/listinfo/software

Please base patches against the 'next' Git branch using common sense:

  * https://www.kernel.org/doc/Documentation/SubmittingPatches

Debian specific bugs can also be reported in the Debian Bug Tracking System:

  * https://bugs.debian.org


TOOLS
-----
*ceph-log(1):*::
	store Ceph cluster log as a logfile.

*ceph-info(1):*::
	show Ceph cluster information as a website.

*cephfs-snap(1):*::
	create CephFS snapshots periodically.


AUTHORS
-------
  * Daniel Baumann <daniel.baumann@open-infrastructure.net>
