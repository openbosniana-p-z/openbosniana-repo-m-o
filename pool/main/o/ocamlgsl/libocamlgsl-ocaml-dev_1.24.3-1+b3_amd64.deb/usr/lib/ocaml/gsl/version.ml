(* gsl-ocaml - OCaml interface to GSL                       *)
(* Copyright (©) 2014- - Markus Mottl                       *)
(* Distributed under the terms of the GPL version 3         *)

let () = Error.init ()

let version = "%%VERSION_NUM%%"
