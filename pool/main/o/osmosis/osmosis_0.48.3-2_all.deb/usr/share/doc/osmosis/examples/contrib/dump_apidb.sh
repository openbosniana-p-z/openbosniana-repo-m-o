#!/bin/sh
/usr/bin/pg_dump -O -v -f "apidb_0.6.sql" api06
