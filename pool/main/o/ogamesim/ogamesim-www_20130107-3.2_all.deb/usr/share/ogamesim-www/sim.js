// открывает окошко репорта
function create_window_for_get_report(url, lang)
{
  url+='?lang='+lang;
  url+='&get_report=1';

  window.open(url, '', 'width=640, height=480, location=no, '+
      'menubar=no, scrollbars=yes, status=no, '+
      'toolbar=no, resizable=no');
}

// читает кукис
function get_cookie( name ) 
{
  var start = document.cookie.indexOf( name + "=" );
  var len = start + name.length + 1;
  if ( ( !start ) &&
    ( name != document.cookie.substring( 0, name.length ) ) )
  {
    return '';
  }
  if ( start == -1 ) return '';
  var end = document.cookie.indexOf( ";", len );
  if ( end == -1 ) end = document.cookie.length;
  return unescape( document.cookie.substring( len, end ) );
}

// записать кук
function set_cookie(name, value)
{
  cookie = name + "=" + escape(value) +
         '; expires=Sunday, 17-Jan-2038 00:00:00 GMT';
  document.cookie = cookie;
}

// сохраняет игрока
function save_gamer(prefix)
{
  els=document.getElementsByTagName('input');

  cookie='';
  for (i=0; i<els.length; i++)
  {
    if (els[i].type!='text') continue;
    if (!els[i].name.match('^'+prefix)) continue;
    cookie+='-'+els[i].value;
  }
  set_cookie(prefix, cookie);
}

// читает игрока
function load_gamer(prefix)
{
  cookies=get_cookie(prefix).split('-');
  els=document.getElementsByTagName('input');
  for (i=0, j=1; i<els.length; i++)
  {
    if (els[i].type!='text') continue;
    if (!els[i].name.match('^'+prefix)) continue;
    if (j<cookies.length) els[i].value=cookies[j]; 
    else els[i].value='';
    j++;
  }
}

// очищает игрока
function clean_gamer(prefix)
{
  els=document.getElementsByTagName('input');
  for (i=0; i<els.length; i++)
  {
    if (els[i].type!='text') continue;
    if (!els[i].name.match('^'+prefix)) continue;
    els[i].value='';
  }
}

// показывает счетчик посещений
function show_counter(counter)
{
  var letters=(''+counter).split('');
  var pletters=new Array();

  gr=0;
  for (i=letters.length-1; i>0; i--)
  {
    pletters[pletters.length]=letters[i];
    if (++gr==3)
    {
      pletters[pletters.length]='.';
      gr=0;
    }
  }
  pletters[pletters.length]=letters[0];

  for (i=pletters.length-1; i>=0; i--)
  {
    document.write('<img border="0" height="16" ');
    if (pletters[i]=='.') 
    {
      document.write('alt="." ');
      document.write('width="7" ');
    }
    else 
    {
      document.write('alt="'+pletters[i]+'" ');
      document.write('width="12" ');
    }
    document.write('src="img/counter/');
    if (pletters[i]=='.') document.write('point');
    else document.write(pletters[i]);
    document.write('.png">');
  }
  
}
