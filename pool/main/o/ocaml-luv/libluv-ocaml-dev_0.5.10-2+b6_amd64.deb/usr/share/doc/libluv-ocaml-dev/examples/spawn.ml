let () =
  ignore (Luv.Process.spawn "sleep" ["sleep"; "1"]);
  ignore (Luv.Loop.run () : bool)
