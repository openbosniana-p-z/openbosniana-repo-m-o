let () =
  print_endline "Hello, world!";
  ignore (Luv.Loop.run () : bool)
