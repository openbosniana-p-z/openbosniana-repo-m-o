module Non_blocking =
struct
module CI = Cstubs_internals

external luv_stub_1_uv_strerror_r : int -> bytes CI.ocaml -> int -> unit
  = "luv_stub_1_uv_strerror_r" 

external luv_stub_2_uv_err_name_r : int -> bytes CI.ocaml -> int -> unit
  = "luv_stub_2_uv_err_name_r" 

external luv_stub_3_uv_translate_sys_error : int -> int
  = "luv_stub_3_uv_translate_sys_error" 

external luv_stub_4_luv_version_suffix : unit -> CI.voidp
  = "luv_stub_4_luv_version_suffix" 

external luv_stub_5_uv_version : unit -> int = "luv_stub_5_uv_version" 

external luv_stub_6_luv_version_string : unit -> CI.voidp
  = "luv_stub_6_luv_version_string" 

external luv_stub_7_uv_loop_init : _ CI.fatptr -> int
  = "luv_stub_7_uv_loop_init" 

external luv_stub_8_uv_loop_configure : _ CI.fatptr -> int -> int -> int
  = "luv_stub_8_uv_loop_configure" 

external luv_stub_9_uv_loop_close : _ CI.fatptr -> int
  = "luv_stub_9_uv_loop_close" 

external luv_stub_10_uv_default_loop : unit -> CI.voidp
  = "luv_stub_10_uv_default_loop" 

external luv_stub_11_uv_loop_alive : _ CI.fatptr -> bool
  = "luv_stub_11_uv_loop_alive" 

external luv_stub_12_uv_stop : _ CI.fatptr -> unit = "luv_stub_12_uv_stop" 

external luv_stub_13_uv_backend_fd : _ CI.fatptr -> int
  = "luv_stub_13_uv_backend_fd" 

external luv_stub_14_uv_backend_timeout : _ CI.fatptr -> int
  = "luv_stub_14_uv_backend_timeout" 

external luv_stub_15_uv_now : _ CI.fatptr -> Unsigned.uint64
  = "luv_stub_15_uv_now" 

external luv_stub_16_uv_update_time : _ CI.fatptr -> unit
  = "luv_stub_16_uv_update_time" 

external luv_stub_17_uv_loop_fork : _ CI.fatptr -> int
  = "luv_stub_17_uv_loop_fork" 

external luv_stub_18_uv_library_shutdown : unit -> unit
  = "luv_stub_18_uv_library_shutdown" 

external luv_stub_19_luv_get_close_trampoline : unit -> CI.voidp
  = "luv_stub_19_luv_get_close_trampoline" 

external luv_stub_20_luv_get_alloc_trampoline : unit -> CI.voidp
  = "luv_stub_20_luv_get_alloc_trampoline" 

external luv_stub_21_uv_is_active : _ CI.fatptr -> bool
  = "luv_stub_21_uv_is_active" 

external luv_stub_22_uv_is_closing : _ CI.fatptr -> bool
  = "luv_stub_22_uv_is_closing" 

external luv_stub_23_uv_close : _ CI.fatptr -> _ CI.fatfunptr -> unit
  = "luv_stub_23_uv_close" 

external luv_stub_24_uv_ref : _ CI.fatptr -> unit = "luv_stub_24_uv_ref" 

external luv_stub_25_uv_unref : _ CI.fatptr -> unit = "luv_stub_25_uv_unref" 

external luv_stub_26_uv_has_ref : _ CI.fatptr -> bool
  = "luv_stub_26_uv_has_ref" 

external luv_stub_27_uv_send_buffer_size : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_27_uv_send_buffer_size" 

external luv_stub_28_uv_recv_buffer_size : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_28_uv_recv_buffer_size" 

external luv_stub_29_uv_fileno : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_29_uv_fileno" 

external luv_stub_30_uv_handle_get_loop : _ CI.fatptr -> CI.voidp
  = "luv_stub_30_uv_handle_get_loop" 

external luv_stub_31_uv_handle_get_data : _ CI.fatptr -> CI.voidp
  = "luv_stub_31_uv_handle_get_data" 

external luv_stub_32_uv_handle_set_data : _ CI.fatptr -> _ CI.fatptr -> unit
  = "luv_stub_32_uv_handle_set_data" 

external luv_stub_33_uv_cancel : _ CI.fatptr -> int = "luv_stub_33_uv_cancel" 

external luv_stub_34_uv_req_get_data : _ CI.fatptr -> CI.voidp
  = "luv_stub_34_uv_req_get_data" 

external luv_stub_35_uv_req_set_data : _ CI.fatptr -> _ CI.fatptr -> unit
  = "luv_stub_35_uv_req_set_data" 

external luv_stub_36_luv_get_timer_trampoline : unit -> CI.voidp
  = "luv_stub_36_luv_get_timer_trampoline" 

external luv_stub_37_uv_timer_init : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_37_uv_timer_init" 

external luv_stub_38_uv_timer_start
  : _ CI.fatptr -> _ CI.fatfunptr -> Unsigned.uint64 -> Unsigned.uint64 ->
    int = "luv_stub_38_uv_timer_start" 

external luv_stub_39_uv_timer_stop : _ CI.fatptr -> int
  = "luv_stub_39_uv_timer_stop" 

external luv_stub_40_uv_timer_again : _ CI.fatptr -> int
  = "luv_stub_40_uv_timer_again" 

external luv_stub_41_uv_timer_set_repeat
  : _ CI.fatptr -> Unsigned.uint64 -> unit
  = "luv_stub_41_uv_timer_set_repeat" 

external luv_stub_42_uv_timer_get_repeat : _ CI.fatptr -> Unsigned.uint64
  = "luv_stub_42_uv_timer_get_repeat" 

external luv_stub_43_uv_timer_get_due_in : _ CI.fatptr -> Unsigned.uint64
  = "luv_stub_43_uv_timer_get_due_in" 

external luv_stub_44_luv_get_prepare_trampoline : unit -> CI.voidp
  = "luv_stub_44_luv_get_prepare_trampoline" 

external luv_stub_45_uv_prepare_init : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_45_uv_prepare_init" 

external luv_stub_46_uv_prepare_start : _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_46_uv_prepare_start" 

external luv_stub_47_uv_prepare_stop : _ CI.fatptr -> int
  = "luv_stub_47_uv_prepare_stop" 

external luv_stub_48_luv_get_check_trampoline : unit -> CI.voidp
  = "luv_stub_48_luv_get_check_trampoline" 

external luv_stub_49_uv_check_init : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_49_uv_check_init" 

external luv_stub_50_uv_check_start : _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_50_uv_check_start" 

external luv_stub_51_uv_check_stop : _ CI.fatptr -> int
  = "luv_stub_51_uv_check_stop" 

external luv_stub_52_luv_get_idle_trampoline : unit -> CI.voidp
  = "luv_stub_52_luv_get_idle_trampoline" 

external luv_stub_53_uv_idle_init : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_53_uv_idle_init" 

external luv_stub_54_uv_idle_start : _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_54_uv_idle_start" 

external luv_stub_55_uv_idle_stop : _ CI.fatptr -> int
  = "luv_stub_55_uv_idle_stop" 

external luv_stub_56_luv_get_async_trampoline : unit -> CI.voidp
  = "luv_stub_56_luv_get_async_trampoline" 

external luv_stub_57_uv_async_init
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_57_uv_async_init" 

external luv_stub_58_uv_async_send : _ CI.fatptr -> int
  = "luv_stub_58_uv_async_send" 

external luv_stub_59_luv_get_poll_trampoline : unit -> CI.voidp
  = "luv_stub_59_luv_get_poll_trampoline" 

external luv_stub_60_uv_poll_init : _ CI.fatptr -> _ CI.fatptr -> int -> int
  = "luv_stub_60_uv_poll_init" 

external luv_stub_61_uv_poll_init_socket
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_61_uv_poll_init_socket" 

external luv_stub_62_uv_poll_start
  : _ CI.fatptr -> int -> _ CI.fatfunptr -> int = "luv_stub_62_uv_poll_start" 

external luv_stub_63_uv_poll_stop : _ CI.fatptr -> int
  = "luv_stub_63_uv_poll_stop" 

external luv_stub_64_luv_get_signal_trampoline : unit -> CI.voidp
  = "luv_stub_64_luv_get_signal_trampoline" 

external luv_stub_65_uv_signal_init : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_65_uv_signal_init" 

external luv_stub_66_uv_signal_start
  : _ CI.fatptr -> _ CI.fatfunptr -> int -> int
  = "luv_stub_66_uv_signal_start" 

external luv_stub_67_uv_signal_start_oneshot
  : _ CI.fatptr -> _ CI.fatfunptr -> int -> int
  = "luv_stub_67_uv_signal_start_oneshot" 

external luv_stub_68_uv_signal_stop : _ CI.fatptr -> int
  = "luv_stub_68_uv_signal_stop" 

external luv_stub_69_luv_get_connect_trampoline : unit -> CI.voidp
  = "luv_stub_69_luv_get_connect_trampoline" 

external luv_stub_70_luv_get_shutdown_trampoline : unit -> CI.voidp
  = "luv_stub_70_luv_get_shutdown_trampoline" 

external luv_stub_71_luv_get_write_trampoline : unit -> CI.voidp
  = "luv_stub_71_luv_get_write_trampoline" 

external luv_stub_72_luv_get_connection_trampoline : unit -> CI.voidp
  = "luv_stub_72_luv_get_connection_trampoline" 

external luv_stub_73_luv_get_read_trampoline : unit -> CI.voidp
  = "luv_stub_73_luv_get_read_trampoline" 

external luv_stub_74_uv_shutdown
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_74_uv_shutdown" 

external luv_stub_75_uv_listen : _ CI.fatptr -> int -> _ CI.fatfunptr -> int
  = "luv_stub_75_uv_listen" 

external luv_stub_76_uv_accept : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_76_uv_accept" 

external luv_stub_77_luv_read_start
  : _ CI.fatptr -> _ CI.fatfunptr -> _ CI.fatfunptr -> int
  = "luv_stub_77_luv_read_start" 

external luv_stub_78_uv_read_stop : _ CI.fatptr -> int
  = "luv_stub_78_uv_read_stop" 

external luv_stub_79_uv_write2
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> Unsigned.uint ->
    _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_79_uv_write2_byte6" "luv_stub_79_uv_write2" 

external luv_stub_80_uv_try_write
  : _ CI.fatptr -> _ CI.fatptr -> Unsigned.uint -> int
  = "luv_stub_80_uv_try_write" 

external luv_stub_81_uv_try_write2
  : _ CI.fatptr -> _ CI.fatptr -> Unsigned.uint -> _ CI.fatptr -> int
  = "luv_stub_81_uv_try_write2" 

external luv_stub_82_uv_is_readable : _ CI.fatptr -> bool
  = "luv_stub_82_uv_is_readable" 

external luv_stub_83_uv_is_writable : _ CI.fatptr -> bool
  = "luv_stub_83_uv_is_writable" 

external luv_stub_84_uv_stream_set_blocking : _ CI.fatptr -> bool -> int
  = "luv_stub_84_uv_stream_set_blocking" 

external luv_stub_85_uv_stream_get_write_queue_size
  : _ CI.fatptr -> Unsigned.size_t
  = "luv_stub_85_uv_stream_get_write_queue_size" 

external luv_stub_86_uv_tcp_init : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_86_uv_tcp_init" 

external luv_stub_87_uv_tcp_init_ex
  : _ CI.fatptr -> _ CI.fatptr -> Unsigned.uint -> int
  = "luv_stub_87_uv_tcp_init_ex" 

external luv_stub_88_uv_tcp_open : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_88_uv_tcp_open" 

external luv_stub_89_uv_socketpair
  : int -> int -> _ CI.fatptr -> int -> int -> int
  = "luv_stub_89_uv_socketpair" 

external luv_stub_90_uv_tcp_nodelay : _ CI.fatptr -> bool -> int
  = "luv_stub_90_uv_tcp_nodelay" 

external luv_stub_91_uv_tcp_keepalive : _ CI.fatptr -> bool -> int -> int
  = "luv_stub_91_uv_tcp_keepalive" 

external luv_stub_92_uv_tcp_simultaneous_accepts : _ CI.fatptr -> bool -> int
  = "luv_stub_92_uv_tcp_simultaneous_accepts" 

external luv_stub_93_uv_tcp_bind : _ CI.fatptr -> _ CI.fatptr -> int -> int
  = "luv_stub_93_uv_tcp_bind" 

external luv_stub_94_uv_tcp_getsockname
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_94_uv_tcp_getsockname" 

external luv_stub_95_uv_tcp_getpeername
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_95_uv_tcp_getpeername" 

external luv_stub_96_uv_tcp_connect
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_96_uv_tcp_connect" 

external luv_stub_97_uv_tcp_close_reset
  : _ CI.fatptr -> _ CI.fatfunptr -> int = "luv_stub_97_uv_tcp_close_reset" 

external luv_stub_98_uv_pipe_init : _ CI.fatptr -> _ CI.fatptr -> bool -> int
  = "luv_stub_98_uv_pipe_init" 

external luv_stub_99_uv_pipe : _ CI.fatptr -> int -> int -> int
  = "luv_stub_99_uv_pipe" 

external luv_stub_100_uv_pipe_open : _ CI.fatptr -> int -> int
  = "luv_stub_100_uv_pipe_open" 

external luv_stub_101_uv_pipe_connect
  : _ CI.fatptr -> _ CI.fatptr -> string CI.ocaml -> _ CI.fatfunptr -> unit
  = "luv_stub_101_uv_pipe_connect" 

external luv_stub_102_uv_pipe_getsockname
  : _ CI.fatptr -> bytes CI.ocaml -> _ CI.fatptr -> int
  = "luv_stub_102_uv_pipe_getsockname" 

external luv_stub_103_uv_pipe_getpeername
  : _ CI.fatptr -> bytes CI.ocaml -> _ CI.fatptr -> int
  = "luv_stub_103_uv_pipe_getpeername" 

external luv_stub_104_uv_pipe_pending_instances : _ CI.fatptr -> int -> unit
  = "luv_stub_104_uv_pipe_pending_instances" 

external luv_stub_105_uv_pipe_pending_count : _ CI.fatptr -> int
  = "luv_stub_105_uv_pipe_pending_count" 

external luv_stub_106_uv_pipe_pending_type : _ CI.fatptr -> int
  = "luv_stub_106_uv_pipe_pending_type" 

external luv_stub_107_uv_pipe_chmod : _ CI.fatptr -> int -> int
  = "luv_stub_107_uv_pipe_chmod" 

external luv_stub_108_uv_tty_init
  : _ CI.fatptr -> _ CI.fatptr -> int -> int -> int
  = "luv_stub_108_uv_tty_init" 

external luv_stub_109_uv_tty_set_mode : _ CI.fatptr -> Unsigned.uint32 -> int
  = "luv_stub_109_uv_tty_set_mode" 

external luv_stub_110_uv_tty_reset_mode : unit -> int
  = "luv_stub_110_uv_tty_reset_mode" 

external luv_stub_111_uv_tty_get_winsize
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_111_uv_tty_get_winsize" 

external luv_stub_112_uv_tty_set_vterm_state : Unsigned.uint32 -> unit
  = "luv_stub_112_uv_tty_set_vterm_state" 

external luv_stub_113_uv_tty_get_vterm_state : _ CI.fatptr -> int
  = "luv_stub_113_uv_tty_get_vterm_state" 

external luv_stub_114_uv_udp_init : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_114_uv_udp_init" 

external luv_stub_115_uv_udp_init_ex
  : _ CI.fatptr -> _ CI.fatptr -> Unsigned.uint -> int
  = "luv_stub_115_uv_udp_init_ex" 

external luv_stub_116_uv_udp_open : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_116_uv_udp_open" 

external luv_stub_117_uv_udp_bind : _ CI.fatptr -> _ CI.fatptr -> int -> int
  = "luv_stub_117_uv_udp_bind" 

external luv_stub_118_uv_udp_connect : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_118_uv_udp_connect" 

external luv_stub_119_uv_udp_getpeername
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_119_uv_udp_getpeername" 

external luv_stub_120_uv_udp_getsockname
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_120_uv_udp_getsockname" 

external luv_stub_121_uv_udp_set_membership
  : _ CI.fatptr -> string CI.ocaml -> string CI.ocaml -> Unsigned.uint32 ->
    int = "luv_stub_121_uv_udp_set_membership" 

external luv_stub_122_uv_udp_set_source_membership
  : _ CI.fatptr -> string CI.ocaml -> string CI.ocaml -> string CI.ocaml ->
    Unsigned.uint32 -> int = "luv_stub_122_uv_udp_set_source_membership" 

external luv_stub_123_uv_udp_set_multicast_loop : _ CI.fatptr -> bool -> int
  = "luv_stub_123_uv_udp_set_multicast_loop" 

external luv_stub_124_uv_udp_set_multicast_ttl : _ CI.fatptr -> int -> int
  = "luv_stub_124_uv_udp_set_multicast_ttl" 

external luv_stub_125_uv_udp_set_multicast_interface
  : _ CI.fatptr -> string CI.ocaml -> int
  = "luv_stub_125_uv_udp_set_multicast_interface" 

external luv_stub_126_uv_udp_set_broadcast : _ CI.fatptr -> bool -> int
  = "luv_stub_126_uv_udp_set_broadcast" 

external luv_stub_127_uv_udp_set_ttl : _ CI.fatptr -> int -> int
  = "luv_stub_127_uv_udp_set_ttl" 

external luv_stub_128_luv_get_send_trampoline : unit -> CI.voidp
  = "luv_stub_128_luv_get_send_trampoline" 

external luv_stub_129_uv_udp_send
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> Unsigned.uint ->
    _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_129_uv_udp_send_byte6" "luv_stub_129_uv_udp_send" 

external luv_stub_130_uv_udp_try_send
  : _ CI.fatptr -> _ CI.fatptr -> Unsigned.uint -> _ CI.fatptr -> int
  = "luv_stub_130_uv_udp_try_send" 

external luv_stub_131_luv_get_recv_trampoline : unit -> CI.voidp
  = "luv_stub_131_luv_get_recv_trampoline" 

external luv_stub_132_luv_udp_recv_start
  : _ CI.fatptr -> _ CI.fatfunptr -> _ CI.fatfunptr -> int
  = "luv_stub_132_luv_udp_recv_start" 

external luv_stub_133_uv_udp_recv_stop : _ CI.fatptr -> int
  = "luv_stub_133_uv_udp_recv_stop" 

external luv_stub_134_uv_udp_using_recvmmsg : _ CI.fatptr -> bool
  = "luv_stub_134_uv_udp_using_recvmmsg" 

external luv_stub_135_uv_udp_get_send_queue_size
  : _ CI.fatptr -> Unsigned.size_t
  = "luv_stub_135_uv_udp_get_send_queue_size" 

external luv_stub_136_uv_udp_get_send_queue_count
  : _ CI.fatptr -> Unsigned.size_t
  = "luv_stub_136_uv_udp_get_send_queue_count" 

external luv_stub_137_luv_get_exit_trampoline : unit -> CI.voidp
  = "luv_stub_137_luv_get_exit_trampoline" 

external luv_stub_138_luv_null_exit_trampoline : unit -> CI.voidp
  = "luv_stub_138_luv_null_exit_trampoline" 

external luv_stub_139_uv_disable_stdio_inheritance : unit -> unit
  = "luv_stub_139_uv_disable_stdio_inheritance" 

external luv_stub_140_luv_spawn
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> _ CI.fatptr ->
    _ CI.fatptr -> int -> _ CI.fatptr -> int -> bool -> _ CI.fatptr ->
    bool -> int -> int -> _ CI.fatptr -> int -> int -> int
  = "luv_stub_140_luv_spawn_byte16" "luv_stub_140_luv_spawn" 

external luv_stub_141_uv_process_kill : _ CI.fatptr -> int -> int
  = "luv_stub_141_uv_process_kill" 

external luv_stub_142_uv_kill : int -> int -> int = "luv_stub_142_uv_kill" 

external luv_stub_143_uv_process_get_pid : _ CI.fatptr -> int
  = "luv_stub_143_uv_process_get_pid" 

external luv_stub_144_luv_get_fs_event_trampoline : unit -> CI.voidp
  = "luv_stub_144_luv_get_fs_event_trampoline" 

external luv_stub_145_uv_fs_event_init : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_145_uv_fs_event_init" 

external luv_stub_146_luv_fs_event_start
  : _ CI.fatptr -> _ CI.fatfunptr -> string CI.ocaml -> int -> int
  = "luv_stub_146_luv_fs_event_start" 

external luv_stub_147_uv_fs_event_stop : _ CI.fatptr -> int
  = "luv_stub_147_uv_fs_event_stop" 

external luv_stub_148_luv_get_fs_poll_trampoline : unit -> CI.voidp
  = "luv_stub_148_luv_get_fs_poll_trampoline" 

external luv_stub_149_uv_fs_poll_init : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_149_uv_fs_poll_init" 

external luv_stub_150_luv_fs_poll_start
  : _ CI.fatptr -> _ CI.fatfunptr -> string CI.ocaml -> int -> int
  = "luv_stub_150_luv_fs_poll_start" 

external luv_stub_151_uv_fs_poll_stop : _ CI.fatptr -> int
  = "luv_stub_151_uv_fs_poll_stop" 

external luv_stub_152_luv_get_getaddrinfo_trampoline : unit -> CI.voidp
  = "luv_stub_152_luv_get_getaddrinfo_trampoline" 

external luv_stub_153_uv_getaddrinfo
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> _ CI.fatptr ->
    _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_153_uv_getaddrinfo_byte6" "luv_stub_153_uv_getaddrinfo" 

external luv_stub_154_uv_freeaddrinfo : _ CI.fatptr -> unit
  = "luv_stub_154_uv_freeaddrinfo" 

external luv_stub_155_luv_get_getnameinfo_trampoline : unit -> CI.voidp
  = "luv_stub_155_luv_get_getnameinfo_trampoline" 

external luv_stub_156_luv_getnameinfo
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> _ CI.fatptr -> int -> int
  = "luv_stub_156_luv_getnameinfo" 

external luv_stub_157_uv_dlopen : string CI.ocaml -> _ CI.fatptr -> bool
  = "luv_stub_157_uv_dlopen" 

external luv_stub_158_uv_dlclose : _ CI.fatptr -> unit
  = "luv_stub_158_uv_dlclose" 

external luv_stub_159_uv_dlsym
  : _ CI.fatptr -> string CI.ocaml -> _ CI.fatptr -> bool
  = "luv_stub_159_uv_dlsym" 

external luv_stub_160_luv_dlerror : _ CI.fatptr -> CI.voidp
  = "luv_stub_160_luv_dlerror" 

external luv_stub_161_uv_get_osfhandle : int -> CI.managed_buffer
  = "luv_stub_161_uv_get_osfhandle" 

external luv_stub_162_uv_open_osfhandle : _ CI.fatptr -> int
  = "luv_stub_162_uv_open_osfhandle" 

external luv_stub_163_luv_is_invalid_handle_value : _ CI.fatptr -> bool
  = "luv_stub_163_luv_is_invalid_handle_value" 

external luv_stub_164_luv_is_invalid_socket_value : _ CI.fatptr -> bool
  = "luv_stub_164_luv_is_invalid_socket_value" 

external luv_stub_165_memcpy : bytes CI.ocaml -> _ CI.fatptr -> int -> unit
  = "luv_stub_165_memcpy" 

external luv_stub_166_memcpy : _ CI.fatptr -> bytes CI.ocaml -> int -> unit
  = "luv_stub_166_memcpy" 

external luv_stub_167_luv_get_work_trampoline : unit -> CI.voidp
  = "luv_stub_167_luv_get_work_trampoline" 

external luv_stub_168_luv_get_after_work_trampoline : unit -> CI.voidp
  = "luv_stub_168_luv_get_after_work_trampoline" 

external luv_stub_169_luv_get_c_work_trampoline : unit -> CI.voidp
  = "luv_stub_169_luv_get_c_work_trampoline" 

external luv_stub_170_luv_get_after_c_work_trampoline : unit -> CI.voidp
  = "luv_stub_170_luv_get_after_c_work_trampoline" 

external luv_stub_171_luv_add_c_function_and_argument
  : _ CI.fatptr -> nativeint -> nativeint -> bool
  = "luv_stub_171_luv_add_c_function_and_argument" 

external luv_stub_172_uv_queue_work
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> _ CI.fatfunptr -> int
  = "luv_stub_172_uv_queue_work" 

external luv_stub_173_luv_get_thread_trampoline : unit -> CI.voidp
  = "luv_stub_173_luv_get_thread_trampoline" 

external luv_stub_174_uv_thread_create_ex
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> _ CI.fatptr -> int
  = "luv_stub_174_uv_thread_create_ex" 

external luv_stub_175_luv_thread_create_c
  : _ CI.fatptr -> _ CI.fatptr -> nativeint -> nativeint -> int
  = "luv_stub_175_luv_thread_create_c" 

external luv_stub_176_uv_thread_self : unit -> CI.managed_buffer
  = "luv_stub_176_uv_thread_self" 

external luv_stub_177_uv_thread_equal : _ CI.fatptr -> _ CI.fatptr -> bool
  = "luv_stub_177_uv_thread_equal" 

external luv_stub_178_uv_key_create : _ CI.fatptr -> int
  = "luv_stub_178_uv_key_create" 

external luv_stub_179_uv_key_delete : _ CI.fatptr -> unit
  = "luv_stub_179_uv_key_delete" 

external luv_stub_180_uv_key_get : _ CI.fatptr -> CI.voidp
  = "luv_stub_180_uv_key_get" 

external luv_stub_181_uv_key_set : _ CI.fatptr -> _ CI.fatptr -> unit
  = "luv_stub_181_uv_key_set" 

external luv_stub_182_luv_get_once_trampoline : unit -> CI.voidp
  = "luv_stub_182_luv_get_once_trampoline" 

external luv_stub_183_luv_once_init : _ CI.fatptr -> int
  = "luv_stub_183_luv_once_init" 

external luv_stub_184_uv_once : _ CI.fatptr -> _ CI.fatfunptr -> unit
  = "luv_stub_184_uv_once" 

external luv_stub_185_uv_mutex_init : _ CI.fatptr -> int
  = "luv_stub_185_uv_mutex_init" 

external luv_stub_186_uv_mutex_init_recursive : _ CI.fatptr -> int
  = "luv_stub_186_uv_mutex_init_recursive" 

external luv_stub_187_uv_mutex_destroy : _ CI.fatptr -> unit
  = "luv_stub_187_uv_mutex_destroy" 

external luv_stub_188_uv_mutex_trylock : _ CI.fatptr -> int
  = "luv_stub_188_uv_mutex_trylock" 

external luv_stub_189_uv_mutex_unlock : _ CI.fatptr -> unit
  = "luv_stub_189_uv_mutex_unlock" 

external luv_stub_190_uv_rwlock_init : _ CI.fatptr -> int
  = "luv_stub_190_uv_rwlock_init" 

external luv_stub_191_uv_rwlock_destroy : _ CI.fatptr -> unit
  = "luv_stub_191_uv_rwlock_destroy" 

external luv_stub_192_uv_rwlock_tryrdlock : _ CI.fatptr -> int
  = "luv_stub_192_uv_rwlock_tryrdlock" 

external luv_stub_193_uv_rwlock_rdunlock : _ CI.fatptr -> unit
  = "luv_stub_193_uv_rwlock_rdunlock" 

external luv_stub_194_uv_rwlock_trywrlock : _ CI.fatptr -> int
  = "luv_stub_194_uv_rwlock_trywrlock" 

external luv_stub_195_uv_rwlock_wrunlock : _ CI.fatptr -> unit
  = "luv_stub_195_uv_rwlock_wrunlock" 

external luv_stub_196_uv_sem_init : _ CI.fatptr -> Unsigned.uint -> int
  = "luv_stub_196_uv_sem_init" 

external luv_stub_197_uv_sem_destroy : _ CI.fatptr -> unit
  = "luv_stub_197_uv_sem_destroy" 

external luv_stub_198_uv_sem_post : _ CI.fatptr -> unit
  = "luv_stub_198_uv_sem_post" 

external luv_stub_199_uv_sem_trywait : _ CI.fatptr -> int
  = "luv_stub_199_uv_sem_trywait" 

external luv_stub_200_uv_cond_init : _ CI.fatptr -> int
  = "luv_stub_200_uv_cond_init" 

external luv_stub_201_uv_cond_destroy : _ CI.fatptr -> unit
  = "luv_stub_201_uv_cond_destroy" 

external luv_stub_202_uv_cond_signal : _ CI.fatptr -> unit
  = "luv_stub_202_uv_cond_signal" 

external luv_stub_203_uv_cond_broadcast : _ CI.fatptr -> unit
  = "luv_stub_203_uv_cond_broadcast" 

external luv_stub_204_uv_barrier_init : _ CI.fatptr -> Unsigned.uint -> int
  = "luv_stub_204_uv_barrier_init" 

external luv_stub_205_uv_barrier_destroy : _ CI.fatptr -> unit
  = "luv_stub_205_uv_barrier_destroy" 

external luv_stub_206_uv_ip4_addr
  : string CI.ocaml -> int -> _ CI.fatptr -> int = "luv_stub_206_uv_ip4_addr" 

external luv_stub_207_uv_ip6_addr
  : string CI.ocaml -> int -> _ CI.fatptr -> int = "luv_stub_207_uv_ip6_addr" 

external luv_stub_208_uv_ip4_name
  : _ CI.fatptr -> bytes CI.ocaml -> Unsigned.size_t -> int
  = "luv_stub_208_uv_ip4_name" 

external luv_stub_209_uv_ip6_name
  : _ CI.fatptr -> bytes CI.ocaml -> Unsigned.size_t -> int
  = "luv_stub_209_uv_ip6_name" 

external luv_stub_210_memcpy : _ CI.fatptr -> _ CI.fatptr -> int -> unit
  = "luv_stub_210_memcpy" 

external luv_stub_211_ntohs : Unsigned.ushort -> Unsigned.ushort
  = "luv_stub_211_ntohs" 

external luv_stub_212_luv_sa_family_to_int : _ CI.fatptr -> int
  = "luv_stub_212_luv_sa_family_to_int" 

external luv_stub_213_uv_resident_set_memory : _ CI.fatptr -> int
  = "luv_stub_213_uv_resident_set_memory" 

external luv_stub_214_uv_uptime : _ CI.fatptr -> int
  = "luv_stub_214_uv_uptime" 

external luv_stub_215_uv_loadavg : _ CI.fatptr -> unit
  = "luv_stub_215_uv_loadavg" 

external luv_stub_216_uv_get_free_memory : unit -> Unsigned.uint64
  = "luv_stub_216_uv_get_free_memory" 

external luv_stub_217_uv_get_total_memory : unit -> Unsigned.uint64
  = "luv_stub_217_uv_get_total_memory" 

external luv_stub_218_uv_get_constrained_memory : unit -> Unsigned.uint64
  = "luv_stub_218_uv_get_constrained_memory" 

external luv_stub_219_uv_os_getpriority : int -> _ CI.fatptr -> int
  = "luv_stub_219_uv_os_getpriority" 

external luv_stub_220_uv_os_setpriority : int -> int -> int
  = "luv_stub_220_uv_os_setpriority" 

external luv_stub_221_uv_getrusage : _ CI.fatptr -> int
  = "luv_stub_221_uv_getrusage" 

external luv_stub_222_uv_os_getpid : unit -> int
  = "luv_stub_222_uv_os_getpid" 

external luv_stub_223_uv_os_getppid : unit -> int
  = "luv_stub_223_uv_os_getppid" 

external luv_stub_224_uv_cpu_info : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_224_uv_cpu_info" 

external luv_stub_225_uv_free_cpu_info : _ CI.fatptr -> int -> unit
  = "luv_stub_225_uv_free_cpu_info" 

external luv_stub_226_uv_interface_addresses
  : _ CI.fatptr -> _ CI.fatptr -> int = "luv_stub_226_uv_interface_addresses" 

external luv_stub_227_uv_free_interface_addresses
  : _ CI.fatptr -> int -> unit = "luv_stub_227_uv_free_interface_addresses" 

external luv_stub_228_uv_if_indextoname
  : Unsigned.uint -> bytes CI.ocaml -> _ CI.fatptr -> int
  = "luv_stub_228_uv_if_indextoname" 

external luv_stub_229_uv_if_indextoiid
  : Unsigned.uint -> bytes CI.ocaml -> _ CI.fatptr -> int
  = "luv_stub_229_uv_if_indextoiid" 

external luv_stub_230_uv_os_gethostname
  : bytes CI.ocaml -> _ CI.fatptr -> int = "luv_stub_230_uv_os_gethostname" 

external luv_stub_231_uv_exepath : bytes CI.ocaml -> _ CI.fatptr -> int
  = "luv_stub_231_uv_exepath" 

external luv_stub_232_uv_cwd : bytes CI.ocaml -> _ CI.fatptr -> int
  = "luv_stub_232_uv_cwd" 

external luv_stub_233_uv_chdir : string CI.ocaml -> int
  = "luv_stub_233_uv_chdir" 

external luv_stub_234_uv_os_homedir : bytes CI.ocaml -> _ CI.fatptr -> int
  = "luv_stub_234_uv_os_homedir" 

external luv_stub_235_uv_os_tmpdir : bytes CI.ocaml -> _ CI.fatptr -> int
  = "luv_stub_235_uv_os_tmpdir" 

external luv_stub_236_uv_os_get_passwd : _ CI.fatptr -> int
  = "luv_stub_236_uv_os_get_passwd" 

external luv_stub_237_uv_os_free_passwd : _ CI.fatptr -> unit
  = "luv_stub_237_uv_os_free_passwd" 

external luv_stub_238_uv_os_getenv
  : string CI.ocaml -> bytes CI.ocaml -> _ CI.fatptr -> int
  = "luv_stub_238_uv_os_getenv" 

external luv_stub_239_uv_os_setenv
  : string CI.ocaml -> string CI.ocaml -> int = "luv_stub_239_uv_os_setenv" 

external luv_stub_240_uv_os_unsetenv : string CI.ocaml -> int
  = "luv_stub_240_uv_os_unsetenv" 

external luv_stub_241_uv_os_environ : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_241_uv_os_environ" 

external luv_stub_242_uv_os_free_environ : _ CI.fatptr -> int -> unit
  = "luv_stub_242_uv_os_free_environ" 

external luv_stub_243_luv_os_uname : bytes CI.ocaml -> int
  = "luv_stub_243_luv_os_uname" 

external luv_stub_244_uv_gettimeofday : _ CI.fatptr -> int
  = "luv_stub_244_uv_gettimeofday" 

external luv_stub_245_uv_hrtime : unit -> Unsigned.uint64
  = "luv_stub_245_uv_hrtime" 

external luv_stub_246_luv_get_random_trampoline : unit -> CI.voidp
  = "luv_stub_246_luv_get_random_trampoline" 

external luv_stub_247_luv_null_random_trampoline : unit -> CI.voidp
  = "luv_stub_247_luv_null_random_trampoline" 

external luv_stub_248_uv_random
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> Unsigned.size_t ->
    Unsigned.uint -> _ CI.fatfunptr -> int
  = "luv_stub_248_uv_random_byte6" "luv_stub_248_uv_random" 

external luv_stub_249_uv_metrics_idle_time : _ CI.fatptr -> Unsigned.uint64
  = "luv_stub_249_uv_metrics_idle_time" 

type 'a result = 'a
type 'a return = 'a
type 'a fn =
 | Returns  : 'a CI.typ   -> 'a return fn
 | Function : 'a CI.typ * 'b fn  -> ('a -> 'b) fn
let map_result f x = f x
let returning t = Returns t
let (@->) f p = Function (f, p)
let foreign : type a b. string -> (a -> b) fn -> (a -> b) =
  fun name t -> match t, name with
| Function (CI.Pointer _, Returns (CI.Primitive CI.Uint64_t)),
  "uv_metrics_idle_time" ->
  (fun x1 -> let CI.CPointer x2 = x1 in luv_stub_249_uv_metrics_idle_time x2)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Pointer _,
           Function
             (CI.Primitive CI.Size_t,
              Function
                (CI.Primitive CI.Uint,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_random" ->
  (fun x3 x5 x7 x9 x10 x11 ->
    let CI.Static_funptr x12 = x11 in
    let CI.CPointer x8 = x7 in
    let CI.CPointer x6 = x5 in
    let CI.CPointer x4 = x3 in luv_stub_248_uv_random x4 x6 x8 x9 x10 x12)
| Function (CI.Void, Returns (CI.Funptr x14)), "luv_null_random_trampoline" ->
  (fun x13 ->
    CI.make_fun_ptr x14 (luv_stub_247_luv_null_random_trampoline x13))
| Function (CI.Void, Returns (CI.Funptr x16)), "luv_get_random_trampoline" ->
  (fun x15 ->
    CI.make_fun_ptr x16 (luv_stub_246_luv_get_random_trampoline x15))
| Function (CI.Void, Returns (CI.Primitive CI.Uint64_t)), "uv_hrtime" ->
  luv_stub_245_uv_hrtime
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_gettimeofday" ->
  (fun x18 -> let CI.CPointer x19 = x18 in luv_stub_244_uv_gettimeofday x19)
| Function (CI.OCaml CI.Bytes, Returns (CI.Primitive CI.Int)), "luv_os_uname" ->
  luv_stub_243_luv_os_uname
| Function (CI.Pointer _, Function (CI.Primitive CI.Int, Returns CI.Void)),
  "uv_os_free_environ" ->
  (fun x21 x23 ->
    let CI.CPointer x22 = x21 in luv_stub_242_uv_os_free_environ x22 x23)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_os_environ" ->
  (fun x24 x26 ->
    let CI.CPointer x27 = x26 in
    let CI.CPointer x25 = x24 in luv_stub_241_uv_os_environ x25 x27)
| Function (CI.OCaml CI.String, Returns (CI.Primitive CI.Int)),
  "uv_os_unsetenv" -> luv_stub_240_uv_os_unsetenv
| Function
    (CI.OCaml CI.String,
     Function (CI.OCaml CI.String, Returns (CI.Primitive CI.Int))),
  "uv_os_setenv" -> luv_stub_239_uv_os_setenv
| Function
    (CI.OCaml CI.String,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_os_getenv" ->
  (fun x31 x32 x33 ->
    let CI.CPointer x34 = x33 in luv_stub_238_uv_os_getenv x31 x32 x34)
| Function (CI.Pointer _, Returns CI.Void), "uv_os_free_passwd" ->
  (fun x35 ->
    let CI.CPointer x36 = x35 in luv_stub_237_uv_os_free_passwd x36)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_os_get_passwd" ->
  (fun x37 -> let CI.CPointer x38 = x37 in luv_stub_236_uv_os_get_passwd x38)
| Function
    (CI.OCaml CI.Bytes,
     Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_os_tmpdir" ->
  (fun x39 x40 ->
    let CI.CPointer x41 = x40 in luv_stub_235_uv_os_tmpdir x39 x41)
| Function
    (CI.OCaml CI.Bytes,
     Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_os_homedir" ->
  (fun x42 x43 ->
    let CI.CPointer x44 = x43 in luv_stub_234_uv_os_homedir x42 x44)
| Function (CI.OCaml CI.String, Returns (CI.Primitive CI.Int)), "uv_chdir" ->
  luv_stub_233_uv_chdir
| Function
    (CI.OCaml CI.Bytes,
     Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_cwd" ->
  (fun x46 x47 -> let CI.CPointer x48 = x47 in luv_stub_232_uv_cwd x46 x48)
| Function
    (CI.OCaml CI.Bytes,
     Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_exepath" ->
  (fun x49 x50 ->
    let CI.CPointer x51 = x50 in luv_stub_231_uv_exepath x49 x51)
| Function
    (CI.OCaml CI.Bytes,
     Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_os_gethostname" ->
  (fun x52 x53 ->
    let CI.CPointer x54 = x53 in luv_stub_230_uv_os_gethostname x52 x54)
| Function
    (CI.Primitive CI.Uint,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_if_indextoiid" ->
  (fun x55 x56 x57 ->
    let CI.CPointer x58 = x57 in luv_stub_229_uv_if_indextoiid x55 x56 x58)
| Function
    (CI.Primitive CI.Uint,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_if_indextoname" ->
  (fun x59 x60 x61 ->
    let CI.CPointer x62 = x61 in luv_stub_228_uv_if_indextoname x59 x60 x62)
| Function (CI.Pointer _, Function (CI.Primitive CI.Int, Returns CI.Void)),
  "uv_free_interface_addresses" ->
  (fun x63 x65 ->
    let CI.CPointer x64 = x63 in
    luv_stub_227_uv_free_interface_addresses x64 x65)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_interface_addresses" ->
  (fun x66 x68 ->
    let CI.CPointer x69 = x68 in
    let CI.CPointer x67 = x66 in luv_stub_226_uv_interface_addresses x67 x69)
| Function (CI.Pointer _, Function (CI.Primitive CI.Int, Returns CI.Void)),
  "uv_free_cpu_info" ->
  (fun x70 x72 ->
    let CI.CPointer x71 = x70 in luv_stub_225_uv_free_cpu_info x71 x72)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_cpu_info" ->
  (fun x73 x75 ->
    let CI.CPointer x76 = x75 in
    let CI.CPointer x74 = x73 in luv_stub_224_uv_cpu_info x74 x76)
| Function (CI.Void, Returns (CI.Primitive CI.Int)), "uv_os_getppid" ->
  luv_stub_223_uv_os_getppid
| Function (CI.Void, Returns (CI.Primitive CI.Int)), "uv_os_getpid" ->
  luv_stub_222_uv_os_getpid
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_getrusage" ->
  (fun x79 -> let CI.CPointer x80 = x79 in luv_stub_221_uv_getrusage x80)
| Function
    (CI.Primitive CI.Int,
     Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int))),
  "uv_os_setpriority" -> luv_stub_220_uv_os_setpriority
| Function
    (CI.Primitive CI.Int,
     Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_os_getpriority" ->
  (fun x83 x84 ->
    let CI.CPointer x85 = x84 in luv_stub_219_uv_os_getpriority x83 x85)
| Function (CI.Void, Returns (CI.Primitive CI.Uint64_t)),
  "uv_get_constrained_memory" -> luv_stub_218_uv_get_constrained_memory
| Function (CI.Void, Returns (CI.Primitive CI.Uint64_t)),
  "uv_get_total_memory" -> luv_stub_217_uv_get_total_memory
| Function (CI.Void, Returns (CI.Primitive CI.Uint64_t)),
  "uv_get_free_memory" -> luv_stub_216_uv_get_free_memory
| Function (CI.Pointer _, Returns CI.Void), "uv_loadavg" ->
  (fun x89 -> let CI.CPointer x90 = x89 in luv_stub_215_uv_loadavg x90)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_uptime" ->
  (fun x91 -> let CI.CPointer x92 = x91 in luv_stub_214_uv_uptime x92)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)),
  "uv_resident_set_memory" ->
  (fun x93 ->
    let CI.CPointer x94 = x93 in luv_stub_213_uv_resident_set_memory x94)
| Function
    (CI.View {CI.ty = CI.Struct _; write = x96; _},
     Returns (CI.Primitive CI.Int)),
  "luv_sa_family_to_int" ->
  (fun x95 ->
    let CI.CPointer x98 = Ctypes.addr (x96 x95) in
    let x97 = x98 in luv_stub_212_luv_sa_family_to_int x97)
| Function (CI.Primitive CI.Ushort, Returns (CI.Primitive CI.Ushort)),
  "ntohs" -> luv_stub_211_ntohs
| Function
    (CI.Pointer _,
     Function (CI.Pointer _, Function (CI.Primitive CI.Int, Returns CI.Void))),
  "memcpy" ->
  (fun x100 x102 x104 ->
    let CI.CPointer x103 = x102 in
    let CI.CPointer x101 = x100 in luv_stub_210_memcpy x101 x103 x104)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Primitive CI.Size_t, Returns (CI.Primitive CI.Int)))),
  "uv_ip6_name" ->
  (fun x105 x107 x108 ->
    let CI.CPointer x106 = x105 in luv_stub_209_uv_ip6_name x106 x107 x108)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Primitive CI.Size_t, Returns (CI.Primitive CI.Int)))),
  "uv_ip4_name" ->
  (fun x109 x111 x112 ->
    let CI.CPointer x110 = x109 in luv_stub_208_uv_ip4_name x110 x111 x112)
| Function
    (CI.OCaml CI.String,
     Function
       (CI.Primitive CI.Int,
        Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_ip6_addr" ->
  (fun x113 x114 x115 ->
    let CI.CPointer x116 = x115 in luv_stub_207_uv_ip6_addr x113 x114 x116)
| Function
    (CI.OCaml CI.String,
     Function
       (CI.Primitive CI.Int,
        Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_ip4_addr" ->
  (fun x117 x118 x119 ->
    let CI.CPointer x120 = x119 in luv_stub_206_uv_ip4_addr x117 x118 x120)
| Function (CI.Pointer _, Returns CI.Void), "uv_barrier_destroy" ->
  (fun x121 ->
    let CI.CPointer x122 = x121 in luv_stub_205_uv_barrier_destroy x122)
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Uint, Returns (CI.Primitive CI.Int))),
  "uv_barrier_init" ->
  (fun x123 x125 ->
    let CI.CPointer x124 = x123 in luv_stub_204_uv_barrier_init x124 x125)
| Function (CI.Pointer _, Returns CI.Void), "uv_cond_broadcast" ->
  (fun x126 ->
    let CI.CPointer x127 = x126 in luv_stub_203_uv_cond_broadcast x127)
| Function (CI.Pointer _, Returns CI.Void), "uv_cond_signal" ->
  (fun x128 ->
    let CI.CPointer x129 = x128 in luv_stub_202_uv_cond_signal x129)
| Function (CI.Pointer _, Returns CI.Void), "uv_cond_destroy" ->
  (fun x130 ->
    let CI.CPointer x131 = x130 in luv_stub_201_uv_cond_destroy x131)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_cond_init" ->
  (fun x132 -> let CI.CPointer x133 = x132 in luv_stub_200_uv_cond_init x133)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_sem_trywait" ->
  (fun x134 ->
    let CI.CPointer x135 = x134 in luv_stub_199_uv_sem_trywait x135)
| Function (CI.Pointer _, Returns CI.Void), "uv_sem_post" ->
  (fun x136 -> let CI.CPointer x137 = x136 in luv_stub_198_uv_sem_post x137)
| Function (CI.Pointer _, Returns CI.Void), "uv_sem_destroy" ->
  (fun x138 ->
    let CI.CPointer x139 = x138 in luv_stub_197_uv_sem_destroy x139)
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Uint, Returns (CI.Primitive CI.Int))),
  "uv_sem_init" ->
  (fun x140 x142 ->
    let CI.CPointer x141 = x140 in luv_stub_196_uv_sem_init x141 x142)
| Function (CI.Pointer _, Returns CI.Void), "uv_rwlock_wrunlock" ->
  (fun x143 ->
    let CI.CPointer x144 = x143 in luv_stub_195_uv_rwlock_wrunlock x144)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)),
  "uv_rwlock_trywrlock" ->
  (fun x145 ->
    let CI.CPointer x146 = x145 in luv_stub_194_uv_rwlock_trywrlock x146)
| Function (CI.Pointer _, Returns CI.Void), "uv_rwlock_rdunlock" ->
  (fun x147 ->
    let CI.CPointer x148 = x147 in luv_stub_193_uv_rwlock_rdunlock x148)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)),
  "uv_rwlock_tryrdlock" ->
  (fun x149 ->
    let CI.CPointer x150 = x149 in luv_stub_192_uv_rwlock_tryrdlock x150)
| Function (CI.Pointer _, Returns CI.Void), "uv_rwlock_destroy" ->
  (fun x151 ->
    let CI.CPointer x152 = x151 in luv_stub_191_uv_rwlock_destroy x152)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_rwlock_init" ->
  (fun x153 ->
    let CI.CPointer x154 = x153 in luv_stub_190_uv_rwlock_init x154)
| Function (CI.Pointer _, Returns CI.Void), "uv_mutex_unlock" ->
  (fun x155 ->
    let CI.CPointer x156 = x155 in luv_stub_189_uv_mutex_unlock x156)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_mutex_trylock" ->
  (fun x157 ->
    let CI.CPointer x158 = x157 in luv_stub_188_uv_mutex_trylock x158)
| Function (CI.Pointer _, Returns CI.Void), "uv_mutex_destroy" ->
  (fun x159 ->
    let CI.CPointer x160 = x159 in luv_stub_187_uv_mutex_destroy x160)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)),
  "uv_mutex_init_recursive" ->
  (fun x161 ->
    let CI.CPointer x162 = x161 in luv_stub_186_uv_mutex_init_recursive x162)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_mutex_init" ->
  (fun x163 ->
    let CI.CPointer x164 = x163 in luv_stub_185_uv_mutex_init x164)
| Function (CI.Pointer _, Function (CI.Funptr _, Returns CI.Void)), "uv_once" ->
  (fun x165 x167 ->
    let CI.Static_funptr x168 = x167 in
    let CI.CPointer x166 = x165 in luv_stub_184_uv_once x166 x168)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "luv_once_init" ->
  (fun x169 ->
    let CI.CPointer x170 = x169 in luv_stub_183_luv_once_init x170)
| Function (CI.Void, Returns (CI.Funptr x172)), "luv_get_once_trampoline" ->
  (fun x171 ->
    CI.make_fun_ptr x172 (luv_stub_182_luv_get_once_trampoline x171))
| Function (CI.Pointer _, Function (CI.Pointer _, Returns CI.Void)),
  "uv_key_set" ->
  (fun x173 x175 ->
    let CI.CPointer x176 = x175 in
    let CI.CPointer x174 = x173 in luv_stub_181_uv_key_set x174 x176)
| Function (CI.Pointer _, Returns (CI.Pointer x179)), "uv_key_get" ->
  (fun x177 ->
    let CI.CPointer x178 = x177 in
    CI.make_ptr x179 (luv_stub_180_uv_key_get x178))
| Function (CI.Pointer _, Returns CI.Void), "uv_key_delete" ->
  (fun x180 ->
    let CI.CPointer x181 = x180 in luv_stub_179_uv_key_delete x181)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_key_create" ->
  (fun x182 ->
    let CI.CPointer x183 = x182 in luv_stub_178_uv_key_create x183)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Bool))),
  "uv_thread_equal" ->
  (fun x184 x186 ->
    let CI.CPointer x187 = x186 in
    let CI.CPointer x185 = x184 in luv_stub_177_uv_thread_equal x185 x187)
| Function
    (CI.Void,
     Returns (CI.View {CI.ty = (CI.Struct _ as x189); read = x190; _})),
  "uv_thread_self" ->
  (fun x188 ->
    x190 (CI.make_structured x189 (luv_stub_176_uv_thread_self x188)))
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Nativeint,
           Function
             (CI.Primitive CI.Nativeint, Returns (CI.Primitive CI.Int))))),
  "luv_thread_create_c" ->
  (fun x191 x193 x195 x196 ->
    let CI.CPointer x194 = x193 in
    let CI.CPointer x192 = x191 in
    luv_stub_175_luv_thread_create_c x192 x194 x195 x196)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Funptr _,
           Function (CI.Pointer _, Returns (CI.Primitive CI.Int))))),
  "uv_thread_create_ex" ->
  (fun x197 x199 x201 x203 ->
    let CI.CPointer x204 = x203 in
    let CI.Static_funptr x202 = x201 in
    let CI.CPointer x200 = x199 in
    let CI.CPointer x198 = x197 in
    luv_stub_174_uv_thread_create_ex x198 x200 x202 x204)
| Function (CI.Void, Returns (CI.Funptr x206)), "luv_get_thread_trampoline" ->
  (fun x205 ->
    CI.make_fun_ptr x206 (luv_stub_173_luv_get_thread_trampoline x205))
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Funptr _,
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_queue_work" ->
  (fun x207 x209 x211 x213 ->
    let CI.Static_funptr x214 = x213 in
    let CI.Static_funptr x212 = x211 in
    let CI.CPointer x210 = x209 in
    let CI.CPointer x208 = x207 in
    luv_stub_172_uv_queue_work x208 x210 x212 x214)
| Function
    (CI.Pointer _,
     Function
       (CI.Primitive CI.Nativeint,
        Function (CI.Primitive CI.Nativeint, Returns (CI.Primitive CI.Bool)))),
  "luv_add_c_function_and_argument" ->
  (fun x215 x217 x218 ->
    let CI.CPointer x216 = x215 in
    luv_stub_171_luv_add_c_function_and_argument x216 x217 x218)
| Function (CI.Void, Returns (CI.Funptr x220)),
  "luv_get_after_c_work_trampoline" ->
  (fun x219 ->
    CI.make_fun_ptr x220 (luv_stub_170_luv_get_after_c_work_trampoline x219))
| Function (CI.Void, Returns (CI.Funptr x222)), "luv_get_c_work_trampoline" ->
  (fun x221 ->
    CI.make_fun_ptr x222 (luv_stub_169_luv_get_c_work_trampoline x221))
| Function (CI.Void, Returns (CI.Funptr x224)),
  "luv_get_after_work_trampoline" ->
  (fun x223 ->
    CI.make_fun_ptr x224 (luv_stub_168_luv_get_after_work_trampoline x223))
| Function (CI.Void, Returns (CI.Funptr x226)), "luv_get_work_trampoline" ->
  (fun x225 ->
    CI.make_fun_ptr x226 (luv_stub_167_luv_get_work_trampoline x225))
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes, Function (CI.Primitive CI.Int, Returns CI.Void))),
  "memcpy" ->
  (fun x227 x229 x230 ->
    let CI.CPointer x228 = x227 in luv_stub_166_memcpy x228 x229 x230)
| Function
    (CI.OCaml CI.Bytes,
     Function (CI.Pointer _, Function (CI.Primitive CI.Int, Returns CI.Void))),
  "memcpy" ->
  (fun x231 x232 x234 ->
    let CI.CPointer x233 = x232 in luv_stub_165_memcpy x231 x233 x234)
| Function
    (CI.View {CI.ty = CI.Struct _; write = x236; _},
     Returns (CI.Primitive CI.Bool)),
  "luv_is_invalid_socket_value" ->
  (fun x235 ->
    let CI.CPointer x238 = Ctypes.addr (x236 x235) in
    let x237 = x238 in luv_stub_164_luv_is_invalid_socket_value x237)
| Function
    (CI.View {CI.ty = CI.Struct _; write = x240; _},
     Returns (CI.Primitive CI.Bool)),
  "luv_is_invalid_handle_value" ->
  (fun x239 ->
    let CI.CPointer x242 = Ctypes.addr (x240 x239) in
    let x241 = x242 in luv_stub_163_luv_is_invalid_handle_value x241)
| Function
    (CI.View {CI.ty = CI.Struct _; write = x244; _},
     Returns (CI.Primitive CI.Int)),
  "uv_open_osfhandle" ->
  (fun x243 ->
    let CI.CPointer x246 = Ctypes.addr (x244 x243) in
    let x245 = x246 in luv_stub_162_uv_open_osfhandle x245)
| Function
    (CI.Primitive CI.Int,
     Returns (CI.View {CI.ty = (CI.Struct _ as x248); read = x249; _})),
  "uv_get_osfhandle" ->
  (fun x247 ->
    x249 (CI.make_structured x248 (luv_stub_161_uv_get_osfhandle x247)))
| Function
    (CI.Pointer _,
     Returns (CI.View {CI.ty = CI.Pointer x252; read = x253; _})),
  "luv_dlerror" ->
  (fun x250 ->
    let CI.CPointer x251 = x250 in
    x253 (CI.make_ptr x252 (luv_stub_160_luv_dlerror x251)))
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.String,
        Function (CI.Pointer _, Returns (CI.Primitive CI.Bool)))),
  "uv_dlsym" ->
  (fun x254 x256 x257 ->
    let CI.CPointer x258 = x257 in
    let CI.CPointer x255 = x254 in luv_stub_159_uv_dlsym x255 x256 x258)
| Function (CI.Pointer _, Returns CI.Void), "uv_dlclose" ->
  (fun x259 -> let CI.CPointer x260 = x259 in luv_stub_158_uv_dlclose x260)
| Function
    (CI.OCaml CI.String,
     Function (CI.Pointer _, Returns (CI.Primitive CI.Bool))),
  "uv_dlopen" ->
  (fun x261 x262 ->
    let CI.CPointer x263 = x262 in luv_stub_157_uv_dlopen x261 x263)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Funptr _,
           Function
             (CI.Pointer _,
              Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)))))),
  "luv_getnameinfo" ->
  (fun x264 x266 x268 x270 x272 ->
    let CI.CPointer x271 = x270 in
    let CI.Static_funptr x269 = x268 in
    let CI.CPointer x267 = x266 in
    let CI.CPointer x265 = x264 in
    luv_stub_156_luv_getnameinfo x265 x267 x269 x271 x272)
| Function (CI.Void, Returns (CI.Funptr x274)),
  "luv_get_getnameinfo_trampoline" ->
  (fun x273 ->
    CI.make_fun_ptr x274 (luv_stub_155_luv_get_getnameinfo_trampoline x273))
| Function (CI.Pointer _, Returns CI.Void), "uv_freeaddrinfo" ->
  (fun x275 ->
    let CI.CPointer x276 = x275 in luv_stub_154_uv_freeaddrinfo x276)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Funptr _,
           Function
             (CI.View {CI.ty = CI.Pointer _; write = x284; _},
              Function
                (CI.View {CI.ty = CI.Pointer _; write = x288; _},
                 Function (CI.Pointer _, Returns (CI.Primitive CI.Int))))))),
  "uv_getaddrinfo" ->
  (fun x277 x279 x281 x283 x287 x291 ->
    let CI.CPointer x292 = x291 in
    let CI.CPointer x290 = x288 x287 in
    let CI.CPointer x286 = x284 x283 in
    let CI.Static_funptr x282 = x281 in
    let CI.CPointer x280 = x279 in
    let CI.CPointer x278 = x277 in
    let x285 = x286 in
    let x289 = x290 in
    luv_stub_153_uv_getaddrinfo x278 x280 x282 x285 x289 x292)
| Function (CI.Void, Returns (CI.Funptr x294)),
  "luv_get_getaddrinfo_trampoline" ->
  (fun x293 ->
    CI.make_fun_ptr x294 (luv_stub_152_luv_get_getaddrinfo_trampoline x293))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_fs_poll_stop" ->
  (fun x295 ->
    let CI.CPointer x296 = x295 in luv_stub_151_uv_fs_poll_stop x296)
| Function
    (CI.Pointer _,
     Function
       (CI.Funptr _,
        Function
          (CI.OCaml CI.String,
           Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int))))),
  "luv_fs_poll_start" ->
  (fun x297 x299 x301 x302 ->
    let CI.Static_funptr x300 = x299 in
    let CI.CPointer x298 = x297 in
    luv_stub_150_luv_fs_poll_start x298 x300 x301 x302)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_fs_poll_init" ->
  (fun x303 x305 ->
    let CI.CPointer x306 = x305 in
    let CI.CPointer x304 = x303 in luv_stub_149_uv_fs_poll_init x304 x306)
| Function (CI.Void, Returns (CI.Funptr x308)), "luv_get_fs_poll_trampoline" ->
  (fun x307 ->
    CI.make_fun_ptr x308 (luv_stub_148_luv_get_fs_poll_trampoline x307))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_fs_event_stop" ->
  (fun x309 ->
    let CI.CPointer x310 = x309 in luv_stub_147_uv_fs_event_stop x310)
| Function
    (CI.Pointer _,
     Function
       (CI.Funptr _,
        Function
          (CI.OCaml CI.String,
           Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int))))),
  "luv_fs_event_start" ->
  (fun x311 x313 x315 x316 ->
    let CI.Static_funptr x314 = x313 in
    let CI.CPointer x312 = x311 in
    luv_stub_146_luv_fs_event_start x312 x314 x315 x316)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_fs_event_init" ->
  (fun x317 x319 ->
    let CI.CPointer x320 = x319 in
    let CI.CPointer x318 = x317 in luv_stub_145_uv_fs_event_init x318 x320)
| Function (CI.Void, Returns (CI.Funptr x322)), "luv_get_fs_event_trampoline" ->
  (fun x321 ->
    CI.make_fun_ptr x322 (luv_stub_144_luv_get_fs_event_trampoline x321))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)),
  "uv_process_get_pid" ->
  (fun x323 ->
    let CI.CPointer x324 = x323 in luv_stub_143_uv_process_get_pid x324)
| Function
    (CI.Primitive CI.Int,
     Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int))),
  "uv_kill" -> luv_stub_142_uv_kill
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int))),
  "uv_process_kill" ->
  (fun x327 x329 ->
    let CI.CPointer x328 = x327 in luv_stub_141_uv_process_kill x328 x329)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Funptr _,
           Function
             (CI.Pointer _,
              Function
                (CI.Pointer _,
                 Function
                   (CI.Primitive CI.Int,
                    Function
                      (CI.Pointer _,
                       Function
                         (CI.Primitive CI.Int,
                          Function
                            (CI.Primitive CI.Bool,
                             Function
                               (CI.Pointer _,
                                Function
                                  (CI.Primitive CI.Bool,
                                   Function
                                     (CI.Primitive CI.Int,
                                      Function
                                        (CI.Primitive CI.Int,
                                         Function
                                           (CI.Pointer _,
                                            Function
                                              (CI.Primitive CI.Int,
                                               Function
                                                 (CI.Primitive CI.Int,
                                                  Returns
                                                    (CI.Primitive CI.Int))))))))))))))))),
  "luv_spawn" ->
  (fun x330 x332 x334 x336 x338 x340 x341 x343 x344 x345 x347 x348 x349 x350
    x352 x353 ->
    let CI.CPointer x351 = x350 in
    let CI.CPointer x346 = x345 in
    let CI.CPointer x342 = x341 in
    let CI.CPointer x339 = x338 in
    let CI.CPointer x337 = x336 in
    let CI.Static_funptr x335 = x334 in
    let CI.CPointer x333 = x332 in
    let CI.CPointer x331 = x330 in
    luv_stub_140_luv_spawn x331 x333 x335 x337 x339 x340 x342 x343 x344 x346
    x347 x348 x349 x351 x352 x353)
| Function (CI.Void, Returns CI.Void), "uv_disable_stdio_inheritance" ->
  luv_stub_139_uv_disable_stdio_inheritance
| Function (CI.Void, Returns (CI.Funptr x356)), "luv_null_exit_trampoline" ->
  (fun x355 ->
    CI.make_fun_ptr x356 (luv_stub_138_luv_null_exit_trampoline x355))
| Function (CI.Void, Returns (CI.Funptr x358)), "luv_get_exit_trampoline" ->
  (fun x357 ->
    CI.make_fun_ptr x358 (luv_stub_137_luv_get_exit_trampoline x357))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Size_t)),
  "uv_udp_get_send_queue_count" ->
  (fun x359 ->
    let CI.CPointer x360 = x359 in
    luv_stub_136_uv_udp_get_send_queue_count x360)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Size_t)),
  "uv_udp_get_send_queue_size" ->
  (fun x361 ->
    let CI.CPointer x362 = x361 in
    luv_stub_135_uv_udp_get_send_queue_size x362)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Bool)),
  "uv_udp_using_recvmmsg" ->
  (fun x363 ->
    let CI.CPointer x364 = x363 in luv_stub_134_uv_udp_using_recvmmsg x364)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_udp_recv_stop" ->
  (fun x365 ->
    let CI.CPointer x366 = x365 in luv_stub_133_uv_udp_recv_stop x366)
| Function
    (CI.Pointer _,
     Function
       (CI.Funptr _, Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))),
  "luv_udp_recv_start" ->
  (fun x367 x369 x371 ->
    let CI.Static_funptr x372 = x371 in
    let CI.Static_funptr x370 = x369 in
    let CI.CPointer x368 = x367 in
    luv_stub_132_luv_udp_recv_start x368 x370 x372)
| Function (CI.Void, Returns (CI.Funptr x374)), "luv_get_recv_trampoline" ->
  (fun x373 ->
    CI.make_fun_ptr x374 (luv_stub_131_luv_get_recv_trampoline x373))
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Uint,
           Function (CI.Pointer _, Returns (CI.Primitive CI.Int))))),
  "uv_udp_try_send" ->
  (fun x375 x377 x379 x380 ->
    let CI.CPointer x381 = x380 in
    let CI.CPointer x378 = x377 in
    let CI.CPointer x376 = x375 in
    luv_stub_130_uv_udp_try_send x376 x378 x379 x381)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Pointer _,
           Function
             (CI.Primitive CI.Uint,
              Function
                (CI.Pointer _,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_udp_send" ->
  (fun x382 x384 x386 x388 x389 x391 ->
    let CI.Static_funptr x392 = x391 in
    let CI.CPointer x390 = x389 in
    let CI.CPointer x387 = x386 in
    let CI.CPointer x385 = x384 in
    let CI.CPointer x383 = x382 in
    luv_stub_129_uv_udp_send x383 x385 x387 x388 x390 x392)
| Function (CI.Void, Returns (CI.Funptr x394)), "luv_get_send_trampoline" ->
  (fun x393 ->
    CI.make_fun_ptr x394 (luv_stub_128_luv_get_send_trampoline x393))
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int))),
  "uv_udp_set_ttl" ->
  (fun x395 x397 ->
    let CI.CPointer x396 = x395 in luv_stub_127_uv_udp_set_ttl x396 x397)
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Bool, Returns (CI.Primitive CI.Int))),
  "uv_udp_set_broadcast" ->
  (fun x398 x400 ->
    let CI.CPointer x399 = x398 in
    luv_stub_126_uv_udp_set_broadcast x399 x400)
| Function
    (CI.Pointer _,
     Function (CI.OCaml CI.String, Returns (CI.Primitive CI.Int))),
  "uv_udp_set_multicast_interface" ->
  (fun x401 x403 ->
    let CI.CPointer x402 = x401 in
    luv_stub_125_uv_udp_set_multicast_interface x402 x403)
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int))),
  "uv_udp_set_multicast_ttl" ->
  (fun x404 x406 ->
    let CI.CPointer x405 = x404 in
    luv_stub_124_uv_udp_set_multicast_ttl x405 x406)
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Bool, Returns (CI.Primitive CI.Int))),
  "uv_udp_set_multicast_loop" ->
  (fun x407 x409 ->
    let CI.CPointer x408 = x407 in
    luv_stub_123_uv_udp_set_multicast_loop x408 x409)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.String,
        Function
          (CI.OCaml CI.String,
           Function
             (CI.OCaml CI.String,
              Function
                (CI.View {CI.ty = CI.Primitive CI.Uint32_t; write = x416; _},
                 Returns (CI.Primitive CI.Int)))))),
  "uv_udp_set_source_membership" ->
  (fun x410 x412 x413 x414 x415 ->
    let CI.CPointer x411 = x410 in
    let x417 = x416 x415 in
    luv_stub_122_uv_udp_set_source_membership x411 x412 x413 x414 x417)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.String,
        Function
          (CI.OCaml CI.String,
           Function
             (CI.View {CI.ty = CI.Primitive CI.Uint32_t; write = x423; _},
              Returns (CI.Primitive CI.Int))))),
  "uv_udp_set_membership" ->
  (fun x418 x420 x421 x422 ->
    let CI.CPointer x419 = x418 in
    let x424 = x423 x422 in
    luv_stub_121_uv_udp_set_membership x419 x420 x421 x424)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_udp_getsockname" ->
  (fun x425 x427 x429 ->
    let CI.CPointer x430 = x429 in
    let CI.CPointer x428 = x427 in
    let CI.CPointer x426 = x425 in
    luv_stub_120_uv_udp_getsockname x426 x428 x430)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_udp_getpeername" ->
  (fun x431 x433 x435 ->
    let CI.CPointer x436 = x435 in
    let CI.CPointer x434 = x433 in
    let CI.CPointer x432 = x431 in
    luv_stub_119_uv_udp_getpeername x432 x434 x436)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_udp_connect" ->
  (fun x437 x439 ->
    let CI.CPointer x440 = x439 in
    let CI.CPointer x438 = x437 in luv_stub_118_uv_udp_connect x438 x440)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)))),
  "uv_udp_bind" ->
  (fun x441 x443 x445 ->
    let CI.CPointer x444 = x443 in
    let CI.CPointer x442 = x441 in luv_stub_117_uv_udp_bind x442 x444 x445)
| Function
    (CI.Pointer _,
     Function
       (CI.View {CI.ty = CI.Struct _; write = x449; _},
        Returns (CI.Primitive CI.Int))),
  "uv_udp_open" ->
  (fun x446 x448 ->
    let CI.CPointer x451 = Ctypes.addr (x449 x448) in
    let CI.CPointer x447 = x446 in
    let x450 = x451 in luv_stub_116_uv_udp_open x447 x450)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function (CI.Primitive CI.Uint, Returns (CI.Primitive CI.Int)))),
  "uv_udp_init_ex" ->
  (fun x452 x454 x456 ->
    let CI.CPointer x455 = x454 in
    let CI.CPointer x453 = x452 in luv_stub_115_uv_udp_init_ex x453 x455 x456)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_udp_init" ->
  (fun x457 x459 ->
    let CI.CPointer x460 = x459 in
    let CI.CPointer x458 = x457 in luv_stub_114_uv_udp_init x458 x460)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)),
  "uv_tty_get_vterm_state" ->
  (fun x461 ->
    let CI.CPointer x462 = x461 in luv_stub_113_uv_tty_get_vterm_state x462)
| Function
    (CI.View {CI.ty = CI.Primitive CI.Uint32_t; write = x464; _},
     Returns CI.Void),
  "uv_tty_set_vterm_state" ->
  (fun x463 ->
    let x465 = x464 x463 in luv_stub_112_uv_tty_set_vterm_state x465)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_tty_get_winsize" ->
  (fun x466 x468 x470 ->
    let CI.CPointer x471 = x470 in
    let CI.CPointer x469 = x468 in
    let CI.CPointer x467 = x466 in
    luv_stub_111_uv_tty_get_winsize x467 x469 x471)
| Function (CI.Void, Returns (CI.Primitive CI.Int)), "uv_tty_reset_mode" ->
  luv_stub_110_uv_tty_reset_mode
| Function
    (CI.Pointer _,
     Function
       (CI.View {CI.ty = CI.Primitive CI.Uint32_t; write = x476; _},
        Returns (CI.Primitive CI.Int))),
  "uv_tty_set_mode" ->
  (fun x473 x475 ->
    let CI.CPointer x474 = x473 in
    let x477 = x476 x475 in luv_stub_109_uv_tty_set_mode x474 x477)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int))))),
  "uv_tty_init" ->
  (fun x478 x480 x482 x483 ->
    let CI.CPointer x481 = x480 in
    let CI.CPointer x479 = x478 in
    luv_stub_108_uv_tty_init x479 x481 x482 x483)
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int))),
  "uv_pipe_chmod" ->
  (fun x484 x486 ->
    let CI.CPointer x485 = x484 in luv_stub_107_uv_pipe_chmod x485 x486)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)),
  "uv_pipe_pending_type" ->
  (fun x487 ->
    let CI.CPointer x488 = x487 in luv_stub_106_uv_pipe_pending_type x488)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)),
  "uv_pipe_pending_count" ->
  (fun x489 ->
    let CI.CPointer x490 = x489 in luv_stub_105_uv_pipe_pending_count x490)
| Function (CI.Pointer _, Function (CI.Primitive CI.Int, Returns CI.Void)),
  "uv_pipe_pending_instances" ->
  (fun x491 x493 ->
    let CI.CPointer x492 = x491 in
    luv_stub_104_uv_pipe_pending_instances x492 x493)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_pipe_getpeername" ->
  (fun x494 x496 x497 ->
    let CI.CPointer x498 = x497 in
    let CI.CPointer x495 = x494 in
    luv_stub_103_uv_pipe_getpeername x495 x496 x498)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_pipe_getsockname" ->
  (fun x499 x501 x502 ->
    let CI.CPointer x503 = x502 in
    let CI.CPointer x500 = x499 in
    luv_stub_102_uv_pipe_getsockname x500 x501 x503)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.OCaml CI.String, Function (CI.Funptr _, Returns CI.Void)))),
  "uv_pipe_connect" ->
  (fun x504 x506 x508 x509 ->
    let CI.Static_funptr x510 = x509 in
    let CI.CPointer x507 = x506 in
    let CI.CPointer x505 = x504 in
    luv_stub_101_uv_pipe_connect x505 x507 x508 x510)
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int))),
  "uv_pipe_open" ->
  (fun x511 x513 ->
    let CI.CPointer x512 = x511 in luv_stub_100_uv_pipe_open x512 x513)
| Function
    (CI.Pointer _,
     Function
       (CI.Primitive CI.Int,
        Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)))),
  "uv_pipe" ->
  (fun x514 x516 x517 ->
    let CI.CPointer x515 = x514 in luv_stub_99_uv_pipe x515 x516 x517)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function (CI.Primitive CI.Bool, Returns (CI.Primitive CI.Int)))),
  "uv_pipe_init" ->
  (fun x518 x520 x522 ->
    let CI.CPointer x521 = x520 in
    let CI.CPointer x519 = x518 in luv_stub_98_uv_pipe_init x519 x521 x522)
| Function
    (CI.Pointer _, Function (CI.Funptr _, Returns (CI.Primitive CI.Int))),
  "uv_tcp_close_reset" ->
  (fun x523 x525 ->
    let CI.Static_funptr x526 = x525 in
    let CI.CPointer x524 = x523 in luv_stub_97_uv_tcp_close_reset x524 x526)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Pointer _,
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_tcp_connect" ->
  (fun x527 x529 x531 x533 ->
    let CI.Static_funptr x534 = x533 in
    let CI.CPointer x532 = x531 in
    let CI.CPointer x530 = x529 in
    let CI.CPointer x528 = x527 in
    luv_stub_96_uv_tcp_connect x528 x530 x532 x534)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_tcp_getpeername" ->
  (fun x535 x537 x539 ->
    let CI.CPointer x540 = x539 in
    let CI.CPointer x538 = x537 in
    let CI.CPointer x536 = x535 in
    luv_stub_95_uv_tcp_getpeername x536 x538 x540)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int)))),
  "uv_tcp_getsockname" ->
  (fun x541 x543 x545 ->
    let CI.CPointer x546 = x545 in
    let CI.CPointer x544 = x543 in
    let CI.CPointer x542 = x541 in
    luv_stub_94_uv_tcp_getsockname x542 x544 x546)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)))),
  "uv_tcp_bind" ->
  (fun x547 x549 x551 ->
    let CI.CPointer x550 = x549 in
    let CI.CPointer x548 = x547 in luv_stub_93_uv_tcp_bind x548 x550 x551)
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Bool, Returns (CI.Primitive CI.Int))),
  "uv_tcp_simultaneous_accepts" ->
  (fun x552 x554 ->
    let CI.CPointer x553 = x552 in
    luv_stub_92_uv_tcp_simultaneous_accepts x553 x554)
| Function
    (CI.Pointer _,
     Function
       (CI.Primitive CI.Bool,
        Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)))),
  "uv_tcp_keepalive" ->
  (fun x555 x557 x558 ->
    let CI.CPointer x556 = x555 in
    luv_stub_91_uv_tcp_keepalive x556 x557 x558)
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Bool, Returns (CI.Primitive CI.Int))),
  "uv_tcp_nodelay" ->
  (fun x559 x561 ->
    let CI.CPointer x560 = x559 in luv_stub_90_uv_tcp_nodelay x560 x561)
| Function
    (CI.Primitive CI.Int,
     Function
       (CI.Primitive CI.Int,
        Function
          (CI.Pointer _,
           Function
             (CI.Primitive CI.Int,
              Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)))))),
  "uv_socketpair" ->
  (fun x562 x563 x564 x566 x567 ->
    let CI.CPointer x565 = x564 in
    luv_stub_89_uv_socketpair x562 x563 x565 x566 x567)
| Function
    (CI.Pointer _,
     Function
       (CI.View {CI.ty = CI.Struct _; write = x571; _},
        Returns (CI.Primitive CI.Int))),
  "uv_tcp_open" ->
  (fun x568 x570 ->
    let CI.CPointer x573 = Ctypes.addr (x571 x570) in
    let CI.CPointer x569 = x568 in
    let x572 = x573 in luv_stub_88_uv_tcp_open x569 x572)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function (CI.Primitive CI.Uint, Returns (CI.Primitive CI.Int)))),
  "uv_tcp_init_ex" ->
  (fun x574 x576 x578 ->
    let CI.CPointer x577 = x576 in
    let CI.CPointer x575 = x574 in luv_stub_87_uv_tcp_init_ex x575 x577 x578)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_tcp_init" ->
  (fun x579 x581 ->
    let CI.CPointer x582 = x581 in
    let CI.CPointer x580 = x579 in luv_stub_86_uv_tcp_init x580 x582)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Size_t)),
  "uv_stream_get_write_queue_size" ->
  (fun x583 ->
    let CI.CPointer x584 = x583 in
    luv_stub_85_uv_stream_get_write_queue_size x584)
| Function
    (CI.Pointer _,
     Function (CI.Primitive CI.Bool, Returns (CI.Primitive CI.Int))),
  "uv_stream_set_blocking" ->
  (fun x585 x587 ->
    let CI.CPointer x586 = x585 in
    luv_stub_84_uv_stream_set_blocking x586 x587)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Bool)), "uv_is_writable" ->
  (fun x588 ->
    let CI.CPointer x589 = x588 in luv_stub_83_uv_is_writable x589)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Bool)), "uv_is_readable" ->
  (fun x590 ->
    let CI.CPointer x591 = x590 in luv_stub_82_uv_is_readable x591)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Uint,
           Function (CI.Pointer _, Returns (CI.Primitive CI.Int))))),
  "uv_try_write2" ->
  (fun x592 x594 x596 x597 ->
    let CI.CPointer x598 = x597 in
    let CI.CPointer x595 = x594 in
    let CI.CPointer x593 = x592 in
    luv_stub_81_uv_try_write2 x593 x595 x596 x598)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function (CI.Primitive CI.Uint, Returns (CI.Primitive CI.Int)))),
  "uv_try_write" ->
  (fun x599 x601 x603 ->
    let CI.CPointer x602 = x601 in
    let CI.CPointer x600 = x599 in luv_stub_80_uv_try_write x600 x602 x603)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Pointer _,
           Function
             (CI.Primitive CI.Uint,
              Function
                (CI.Pointer _,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_write2" ->
  (fun x604 x606 x608 x610 x611 x613 ->
    let CI.Static_funptr x614 = x613 in
    let CI.CPointer x612 = x611 in
    let CI.CPointer x609 = x608 in
    let CI.CPointer x607 = x606 in
    let CI.CPointer x605 = x604 in
    luv_stub_79_uv_write2 x605 x607 x609 x610 x612 x614)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_read_stop" ->
  (fun x615 -> let CI.CPointer x616 = x615 in luv_stub_78_uv_read_stop x616)
| Function
    (CI.Pointer _,
     Function
       (CI.Funptr _, Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))),
  "luv_read_start" ->
  (fun x617 x619 x621 ->
    let CI.Static_funptr x622 = x621 in
    let CI.Static_funptr x620 = x619 in
    let CI.CPointer x618 = x617 in luv_stub_77_luv_read_start x618 x620 x622)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_accept" ->
  (fun x623 x625 ->
    let CI.CPointer x626 = x625 in
    let CI.CPointer x624 = x623 in luv_stub_76_uv_accept x624 x626)
| Function
    (CI.Pointer _,
     Function
       (CI.Primitive CI.Int,
        Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))),
  "uv_listen" ->
  (fun x627 x629 x630 ->
    let CI.Static_funptr x631 = x630 in
    let CI.CPointer x628 = x627 in luv_stub_75_uv_listen x628 x629 x631)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _, Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))),
  "uv_shutdown" ->
  (fun x632 x634 x636 ->
    let CI.Static_funptr x637 = x636 in
    let CI.CPointer x635 = x634 in
    let CI.CPointer x633 = x632 in luv_stub_74_uv_shutdown x633 x635 x637)
| Function (CI.Void, Returns (CI.Funptr x639)), "luv_get_read_trampoline" ->
  (fun x638 ->
    CI.make_fun_ptr x639 (luv_stub_73_luv_get_read_trampoline x638))
| Function (CI.Void, Returns (CI.Funptr x641)),
  "luv_get_connection_trampoline" ->
  (fun x640 ->
    CI.make_fun_ptr x641 (luv_stub_72_luv_get_connection_trampoline x640))
| Function (CI.Void, Returns (CI.Funptr x643)), "luv_get_write_trampoline" ->
  (fun x642 ->
    CI.make_fun_ptr x643 (luv_stub_71_luv_get_write_trampoline x642))
| Function (CI.Void, Returns (CI.Funptr x645)), "luv_get_shutdown_trampoline" ->
  (fun x644 ->
    CI.make_fun_ptr x645 (luv_stub_70_luv_get_shutdown_trampoline x644))
| Function (CI.Void, Returns (CI.Funptr x647)), "luv_get_connect_trampoline" ->
  (fun x646 ->
    CI.make_fun_ptr x647 (luv_stub_69_luv_get_connect_trampoline x646))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_signal_stop" ->
  (fun x648 ->
    let CI.CPointer x649 = x648 in luv_stub_68_uv_signal_stop x649)
| Function
    (CI.Pointer _,
     Function
       (CI.Funptr _,
        Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)))),
  "uv_signal_start_oneshot" ->
  (fun x650 x652 x654 ->
    let CI.Static_funptr x653 = x652 in
    let CI.CPointer x651 = x650 in
    luv_stub_67_uv_signal_start_oneshot x651 x653 x654)
| Function
    (CI.Pointer _,
     Function
       (CI.Funptr _,
        Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)))),
  "uv_signal_start" ->
  (fun x655 x657 x659 ->
    let CI.Static_funptr x658 = x657 in
    let CI.CPointer x656 = x655 in luv_stub_66_uv_signal_start x656 x658 x659)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_signal_init" ->
  (fun x660 x662 ->
    let CI.CPointer x663 = x662 in
    let CI.CPointer x661 = x660 in luv_stub_65_uv_signal_init x661 x663)
| Function (CI.Void, Returns (CI.Funptr x665)), "luv_get_signal_trampoline" ->
  (fun x664 ->
    CI.make_fun_ptr x665 (luv_stub_64_luv_get_signal_trampoline x664))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_poll_stop" ->
  (fun x666 -> let CI.CPointer x667 = x666 in luv_stub_63_uv_poll_stop x667)
| Function
    (CI.Pointer _,
     Function
       (CI.Primitive CI.Int,
        Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))),
  "uv_poll_start" ->
  (fun x668 x670 x671 ->
    let CI.Static_funptr x672 = x671 in
    let CI.CPointer x669 = x668 in luv_stub_62_uv_poll_start x669 x670 x672)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Struct _; write = x678; _},
           Returns (CI.Primitive CI.Int)))),
  "uv_poll_init_socket" ->
  (fun x673 x675 x677 ->
    let CI.CPointer x680 = Ctypes.addr (x678 x677) in
    let CI.CPointer x676 = x675 in
    let CI.CPointer x674 = x673 in
    let x679 = x680 in luv_stub_61_uv_poll_init_socket x674 x676 x679)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)))),
  "uv_poll_init" ->
  (fun x681 x683 x685 ->
    let CI.CPointer x684 = x683 in
    let CI.CPointer x682 = x681 in luv_stub_60_uv_poll_init x682 x684 x685)
| Function (CI.Void, Returns (CI.Funptr x687)), "luv_get_poll_trampoline" ->
  (fun x686 ->
    CI.make_fun_ptr x687 (luv_stub_59_luv_get_poll_trampoline x686))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_async_send" ->
  (fun x688 -> let CI.CPointer x689 = x688 in luv_stub_58_uv_async_send x689)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _, Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))),
  "uv_async_init" ->
  (fun x690 x692 x694 ->
    let CI.Static_funptr x695 = x694 in
    let CI.CPointer x693 = x692 in
    let CI.CPointer x691 = x690 in luv_stub_57_uv_async_init x691 x693 x695)
| Function (CI.Void, Returns (CI.Funptr x697)), "luv_get_async_trampoline" ->
  (fun x696 ->
    CI.make_fun_ptr x697 (luv_stub_56_luv_get_async_trampoline x696))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_idle_stop" ->
  (fun x698 -> let CI.CPointer x699 = x698 in luv_stub_55_uv_idle_stop x699)
| Function
    (CI.Pointer _, Function (CI.Funptr _, Returns (CI.Primitive CI.Int))),
  "uv_idle_start" ->
  (fun x700 x702 ->
    let CI.Static_funptr x703 = x702 in
    let CI.CPointer x701 = x700 in luv_stub_54_uv_idle_start x701 x703)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_idle_init" ->
  (fun x704 x706 ->
    let CI.CPointer x707 = x706 in
    let CI.CPointer x705 = x704 in luv_stub_53_uv_idle_init x705 x707)
| Function (CI.Void, Returns (CI.Funptr x709)), "luv_get_idle_trampoline" ->
  (fun x708 ->
    CI.make_fun_ptr x709 (luv_stub_52_luv_get_idle_trampoline x708))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_check_stop" ->
  (fun x710 -> let CI.CPointer x711 = x710 in luv_stub_51_uv_check_stop x711)
| Function
    (CI.Pointer _, Function (CI.Funptr _, Returns (CI.Primitive CI.Int))),
  "uv_check_start" ->
  (fun x712 x714 ->
    let CI.Static_funptr x715 = x714 in
    let CI.CPointer x713 = x712 in luv_stub_50_uv_check_start x713 x715)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_check_init" ->
  (fun x716 x718 ->
    let CI.CPointer x719 = x718 in
    let CI.CPointer x717 = x716 in luv_stub_49_uv_check_init x717 x719)
| Function (CI.Void, Returns (CI.Funptr x721)), "luv_get_check_trampoline" ->
  (fun x720 ->
    CI.make_fun_ptr x721 (luv_stub_48_luv_get_check_trampoline x720))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_prepare_stop" ->
  (fun x722 ->
    let CI.CPointer x723 = x722 in luv_stub_47_uv_prepare_stop x723)
| Function
    (CI.Pointer _, Function (CI.Funptr _, Returns (CI.Primitive CI.Int))),
  "uv_prepare_start" ->
  (fun x724 x726 ->
    let CI.Static_funptr x727 = x726 in
    let CI.CPointer x725 = x724 in luv_stub_46_uv_prepare_start x725 x727)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_prepare_init" ->
  (fun x728 x730 ->
    let CI.CPointer x731 = x730 in
    let CI.CPointer x729 = x728 in luv_stub_45_uv_prepare_init x729 x731)
| Function (CI.Void, Returns (CI.Funptr x733)), "luv_get_prepare_trampoline" ->
  (fun x732 ->
    CI.make_fun_ptr x733 (luv_stub_44_luv_get_prepare_trampoline x732))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Uint64_t)),
  "uv_timer_get_due_in" ->
  (fun x734 ->
    let CI.CPointer x735 = x734 in luv_stub_43_uv_timer_get_due_in x735)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Uint64_t)),
  "uv_timer_get_repeat" ->
  (fun x736 ->
    let CI.CPointer x737 = x736 in luv_stub_42_uv_timer_get_repeat x737)
| Function
    (CI.Pointer _, Function (CI.Primitive CI.Uint64_t, Returns CI.Void)),
  "uv_timer_set_repeat" ->
  (fun x738 x740 ->
    let CI.CPointer x739 = x738 in luv_stub_41_uv_timer_set_repeat x739 x740)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_timer_again" ->
  (fun x741 ->
    let CI.CPointer x742 = x741 in luv_stub_40_uv_timer_again x742)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_timer_stop" ->
  (fun x743 -> let CI.CPointer x744 = x743 in luv_stub_39_uv_timer_stop x744)
| Function
    (CI.Pointer _,
     Function
       (CI.Funptr _,
        Function
          (CI.Primitive CI.Uint64_t,
           Function (CI.Primitive CI.Uint64_t, Returns (CI.Primitive CI.Int))))),
  "uv_timer_start" ->
  (fun x745 x747 x749 x750 ->
    let CI.Static_funptr x748 = x747 in
    let CI.CPointer x746 = x745 in
    luv_stub_38_uv_timer_start x746 x748 x749 x750)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_timer_init" ->
  (fun x751 x753 ->
    let CI.CPointer x754 = x753 in
    let CI.CPointer x752 = x751 in luv_stub_37_uv_timer_init x752 x754)
| Function (CI.Void, Returns (CI.Funptr x756)), "luv_get_timer_trampoline" ->
  (fun x755 ->
    CI.make_fun_ptr x756 (luv_stub_36_luv_get_timer_trampoline x755))
| Function (CI.Pointer _, Function (CI.Pointer _, Returns CI.Void)),
  "uv_req_set_data" ->
  (fun x757 x759 ->
    let CI.CPointer x760 = x759 in
    let CI.CPointer x758 = x757 in luv_stub_35_uv_req_set_data x758 x760)
| Function (CI.Pointer _, Returns (CI.Pointer x763)), "uv_req_get_data" ->
  (fun x761 ->
    let CI.CPointer x762 = x761 in
    CI.make_ptr x763 (luv_stub_34_uv_req_get_data x762))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_cancel" ->
  (fun x764 -> let CI.CPointer x765 = x764 in luv_stub_33_uv_cancel x765)
| Function (CI.Pointer _, Function (CI.Pointer _, Returns CI.Void)),
  "uv_handle_set_data" ->
  (fun x766 x768 ->
    let CI.CPointer x769 = x768 in
    let CI.CPointer x767 = x766 in luv_stub_32_uv_handle_set_data x767 x769)
| Function (CI.Pointer _, Returns (CI.Pointer x772)), "uv_handle_get_data" ->
  (fun x770 ->
    let CI.CPointer x771 = x770 in
    CI.make_ptr x772 (luv_stub_31_uv_handle_get_data x771))
| Function (CI.Pointer _, Returns (CI.Pointer x775)), "uv_handle_get_loop" ->
  (fun x773 ->
    let CI.CPointer x774 = x773 in
    CI.make_ptr x775 (luv_stub_30_uv_handle_get_loop x774))
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_fileno" ->
  (fun x776 x778 ->
    let CI.CPointer x779 = x778 in
    let CI.CPointer x777 = x776 in luv_stub_29_uv_fileno x777 x779)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_recv_buffer_size" ->
  (fun x780 x782 ->
    let CI.CPointer x783 = x782 in
    let CI.CPointer x781 = x780 in luv_stub_28_uv_recv_buffer_size x781 x783)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_send_buffer_size" ->
  (fun x784 x786 ->
    let CI.CPointer x787 = x786 in
    let CI.CPointer x785 = x784 in luv_stub_27_uv_send_buffer_size x785 x787)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Bool)), "uv_has_ref" ->
  (fun x788 -> let CI.CPointer x789 = x788 in luv_stub_26_uv_has_ref x789)
| Function (CI.Pointer _, Returns CI.Void), "uv_unref" ->
  (fun x790 -> let CI.CPointer x791 = x790 in luv_stub_25_uv_unref x791)
| Function (CI.Pointer _, Returns CI.Void), "uv_ref" ->
  (fun x792 -> let CI.CPointer x793 = x792 in luv_stub_24_uv_ref x793)
| Function (CI.Pointer _, Function (CI.Funptr _, Returns CI.Void)),
  "uv_close" ->
  (fun x794 x796 ->
    let CI.Static_funptr x797 = x796 in
    let CI.CPointer x795 = x794 in luv_stub_23_uv_close x795 x797)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Bool)), "uv_is_closing" ->
  (fun x798 -> let CI.CPointer x799 = x798 in luv_stub_22_uv_is_closing x799)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Bool)), "uv_is_active" ->
  (fun x800 -> let CI.CPointer x801 = x800 in luv_stub_21_uv_is_active x801)
| Function (CI.Void, Returns (CI.Funptr x803)), "luv_get_alloc_trampoline" ->
  (fun x802 ->
    CI.make_fun_ptr x803 (luv_stub_20_luv_get_alloc_trampoline x802))
| Function (CI.Void, Returns (CI.Funptr x805)), "luv_get_close_trampoline" ->
  (fun x804 ->
    CI.make_fun_ptr x805 (luv_stub_19_luv_get_close_trampoline x804))
| Function (CI.Void, Returns CI.Void), "uv_library_shutdown" ->
  luv_stub_18_uv_library_shutdown
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_loop_fork" ->
  (fun x807 -> let CI.CPointer x808 = x807 in luv_stub_17_uv_loop_fork x808)
| Function (CI.Pointer _, Returns CI.Void), "uv_update_time" ->
  (fun x809 ->
    let CI.CPointer x810 = x809 in luv_stub_16_uv_update_time x810)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Uint64_t)), "uv_now" ->
  (fun x811 -> let CI.CPointer x812 = x811 in luv_stub_15_uv_now x812)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)),
  "uv_backend_timeout" ->
  (fun x813 ->
    let CI.CPointer x814 = x813 in luv_stub_14_uv_backend_timeout x814)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_backend_fd" ->
  (fun x815 -> let CI.CPointer x816 = x815 in luv_stub_13_uv_backend_fd x816)
| Function (CI.Pointer _, Returns CI.Void), "uv_stop" ->
  (fun x817 -> let CI.CPointer x818 = x817 in luv_stub_12_uv_stop x818)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Bool)), "uv_loop_alive" ->
  (fun x819 -> let CI.CPointer x820 = x819 in luv_stub_11_uv_loop_alive x820)
| Function (CI.Void, Returns (CI.Pointer x822)), "uv_default_loop" ->
  (fun x821 -> CI.make_ptr x822 (luv_stub_10_uv_default_loop x821))
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_loop_close" ->
  (fun x823 -> let CI.CPointer x824 = x823 in luv_stub_9_uv_loop_close x824)
| Function
    (CI.Pointer _,
     Function
       (CI.Primitive CI.Int,
        Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)))),
  "uv_loop_configure" ->
  (fun x825 x827 x828 ->
    let CI.CPointer x826 = x825 in
    luv_stub_8_uv_loop_configure x826 x827 x828)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_loop_init" ->
  (fun x829 -> let CI.CPointer x830 = x829 in luv_stub_7_uv_loop_init x830)
| Function
    (CI.Void, Returns (CI.View {CI.ty = CI.Pointer x832; read = x833; _})),
  "luv_version_string" ->
  (fun x831 -> x833 (CI.make_ptr x832 (luv_stub_6_luv_version_string x831)))
| Function (CI.Void, Returns (CI.Primitive CI.Int)), "uv_version" ->
  luv_stub_5_uv_version
| Function
    (CI.Void, Returns (CI.View {CI.ty = CI.Pointer x836; read = x837; _})),
  "luv_version_suffix" ->
  (fun x835 -> x837 (CI.make_ptr x836 (luv_stub_4_luv_version_suffix x835)))
| Function (CI.Primitive CI.Int, Returns (CI.Primitive CI.Int)),
  "uv_translate_sys_error" -> luv_stub_3_uv_translate_sys_error
| Function
    (CI.Primitive CI.Int,
     Function
       (CI.OCaml CI.Bytes, Function (CI.Primitive CI.Int, Returns CI.Void))),
  "uv_err_name_r" -> luv_stub_2_uv_err_name_r
| Function
    (CI.Primitive CI.Int,
     Function
       (CI.OCaml CI.Bytes, Function (CI.Primitive CI.Int, Returns CI.Void))),
  "uv_strerror_r" -> luv_stub_1_uv_strerror_r
| _, s ->  Printf.ksprintf failwith "No match for %s" s


let foreign_value : type a. string -> a Ctypes.typ -> a Ctypes.ptr =
  fun name t -> match t, name with
| _, s ->  Printf.ksprintf failwith "No match for %s" s
end

module Blocking =
struct

module CI = Cstubs_internals

external luv_stub_blocking_1_uv_run : _ CI.fatptr -> Unsigned.uint32 -> bool
  = "luv_stub_blocking_1_uv_run" 

external luv_stub_blocking_2_uv_pipe_bind : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_blocking_2_uv_pipe_bind" 

external luv_stub_blocking_3_luv_get_fs_trampoline : unit -> CI.voidp
  = "luv_stub_blocking_3_luv_get_fs_trampoline" 

external luv_stub_blocking_4_luv_null_fs_callback_pointer : unit -> CI.voidp
  = "luv_stub_blocking_4_luv_null_fs_callback_pointer" 

external luv_stub_blocking_5_uv_fs_req_cleanup : _ CI.fatptr -> unit
  = "luv_stub_blocking_5_uv_fs_req_cleanup" 

external luv_stub_blocking_6_uv_fs_close
  : _ CI.fatptr -> _ CI.fatptr -> int -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_6_uv_fs_close" 

external luv_stub_blocking_7_uv_fs_open
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int -> int ->
    _ CI.fatfunptr -> int
  = "luv_stub_blocking_7_uv_fs_open_byte6" "luv_stub_blocking_7_uv_fs_open" 

external luv_stub_blocking_8_uv_fs_read
  : _ CI.fatptr -> _ CI.fatptr -> int -> _ CI.fatptr -> Unsigned.uint ->
    int64 -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_8_uv_fs_read_byte7" "luv_stub_blocking_8_uv_fs_read" 

external luv_stub_blocking_9_uv_fs_write
  : _ CI.fatptr -> _ CI.fatptr -> int -> _ CI.fatptr -> Unsigned.uint ->
    int64 -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_9_uv_fs_write_byte7" "luv_stub_blocking_9_uv_fs_write" 

external luv_stub_blocking_10_uv_fs_unlink
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_10_uv_fs_unlink" 

external luv_stub_blocking_11_uv_fs_mkdir
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_11_uv_fs_mkdir" 

external luv_stub_blocking_12_uv_fs_mkdtemp
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_12_uv_fs_mkdtemp" 

external luv_stub_blocking_13_uv_fs_mkstemp
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_13_uv_fs_mkstemp" 

external luv_stub_blocking_14_uv_fs_rmdir
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_14_uv_fs_rmdir" 

external luv_stub_blocking_15_uv_fs_opendir
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_15_uv_fs_opendir" 

external luv_stub_blocking_16_uv_fs_closedir
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_16_uv_fs_closedir" 

external luv_stub_blocking_17_uv_fs_readdir
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_17_uv_fs_readdir" 

external luv_stub_blocking_18_uv_fs_scandir
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_18_uv_fs_scandir" 

external luv_stub_blocking_19_uv_fs_scandir_next
  : _ CI.fatptr -> _ CI.fatptr -> int
  = "luv_stub_blocking_19_uv_fs_scandir_next" 

external luv_stub_blocking_20_uv_fs_stat
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_20_uv_fs_stat" 

external luv_stub_blocking_21_uv_fs_lstat
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_21_uv_fs_lstat" 

external luv_stub_blocking_22_uv_fs_fstat
  : _ CI.fatptr -> _ CI.fatptr -> int -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_22_uv_fs_fstat" 

external luv_stub_blocking_23_uv_fs_statfs
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_23_uv_fs_statfs" 

external luv_stub_blocking_24_uv_fs_rename
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr ->
    _ CI.fatfunptr -> int = "luv_stub_blocking_24_uv_fs_rename" 

external luv_stub_blocking_25_uv_fs_fsync
  : _ CI.fatptr -> _ CI.fatptr -> int -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_25_uv_fs_fsync" 

external luv_stub_blocking_26_uv_fs_fdatasync
  : _ CI.fatptr -> _ CI.fatptr -> int -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_26_uv_fs_fdatasync" 

external luv_stub_blocking_27_uv_fs_ftruncate
  : _ CI.fatptr -> _ CI.fatptr -> int -> int64 -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_27_uv_fs_ftruncate" 

external luv_stub_blocking_28_uv_fs_copyfile
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int ->
    _ CI.fatfunptr -> int
  =
  "luv_stub_blocking_28_uv_fs_copyfile_byte6" "luv_stub_blocking_28_uv_fs_copyfile"
  

external luv_stub_blocking_29_uv_fs_sendfile
  : _ CI.fatptr -> _ CI.fatptr -> int -> int -> int64 -> Unsigned.size_t ->
    _ CI.fatfunptr -> int
  =
  "luv_stub_blocking_29_uv_fs_sendfile_byte7" "luv_stub_blocking_29_uv_fs_sendfile"
  

external luv_stub_blocking_30_uv_fs_access
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_30_uv_fs_access" 

external luv_stub_blocking_31_uv_fs_chmod
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_31_uv_fs_chmod" 

external luv_stub_blocking_32_uv_fs_fchmod
  : _ CI.fatptr -> _ CI.fatptr -> int -> int -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_32_uv_fs_fchmod" 

external luv_stub_blocking_33_uv_fs_utime
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> float -> float ->
    _ CI.fatfunptr -> int
  =
  "luv_stub_blocking_33_uv_fs_utime_byte6" "luv_stub_blocking_33_uv_fs_utime" 

external luv_stub_blocking_34_uv_fs_futime
  : _ CI.fatptr -> _ CI.fatptr -> int -> float -> float -> _ CI.fatfunptr ->
    int
  =
  "luv_stub_blocking_34_uv_fs_futime_byte6" "luv_stub_blocking_34_uv_fs_futime"
  

external luv_stub_blocking_35_uv_fs_lutime
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> float -> float ->
    _ CI.fatfunptr -> int
  =
  "luv_stub_blocking_35_uv_fs_lutime_byte6" "luv_stub_blocking_35_uv_fs_lutime"
  

external luv_stub_blocking_36_uv_fs_link
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr ->
    _ CI.fatfunptr -> int = "luv_stub_blocking_36_uv_fs_link" 

external luv_stub_blocking_37_uv_fs_symlink
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int ->
    _ CI.fatfunptr -> int
  =
  "luv_stub_blocking_37_uv_fs_symlink_byte6" "luv_stub_blocking_37_uv_fs_symlink"
  

external luv_stub_blocking_38_uv_fs_readlink
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_38_uv_fs_readlink" 

external luv_stub_blocking_39_uv_fs_realpath
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_39_uv_fs_realpath" 

external luv_stub_blocking_40_uv_fs_chown
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int -> int ->
    _ CI.fatfunptr -> int
  =
  "luv_stub_blocking_40_uv_fs_chown_byte6" "luv_stub_blocking_40_uv_fs_chown" 

external luv_stub_blocking_41_uv_fs_fchown
  : _ CI.fatptr -> _ CI.fatptr -> int -> int -> int -> _ CI.fatfunptr -> int
  =
  "luv_stub_blocking_41_uv_fs_fchown_byte6" "luv_stub_blocking_41_uv_fs_fchown"
  

external luv_stub_blocking_42_uv_fs_lchown
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> int -> int ->
    _ CI.fatfunptr -> int
  =
  "luv_stub_blocking_42_uv_fs_lchown_byte6" "luv_stub_blocking_42_uv_fs_lchown"
  

external luv_stub_blocking_43_uv_fs_get_result : _ CI.fatptr -> int64
  = "luv_stub_blocking_43_uv_fs_get_result" 

external luv_stub_blocking_44_uv_fs_get_ptr : _ CI.fatptr -> CI.voidp
  = "luv_stub_blocking_44_uv_fs_get_ptr" 

external luv_stub_blocking_45_uv_fs_get_ptr : _ CI.fatptr -> CI.voidp
  = "luv_stub_blocking_45_uv_fs_get_ptr" 

external luv_stub_blocking_46_luv_fs_get_path : _ CI.fatptr -> CI.voidp
  = "luv_stub_blocking_46_luv_fs_get_path" 

external luv_stub_blocking_47_uv_fs_get_statbuf : _ CI.fatptr -> CI.voidp
  = "luv_stub_blocking_47_uv_fs_get_statbuf" 

external luv_stub_blocking_48_uv_thread_join : _ CI.fatptr -> int
  = "luv_stub_blocking_48_uv_thread_join" 

external luv_stub_blocking_49_uv_mutex_lock : _ CI.fatptr -> unit
  = "luv_stub_blocking_49_uv_mutex_lock" 

external luv_stub_blocking_50_uv_rwlock_rdlock : _ CI.fatptr -> unit
  = "luv_stub_blocking_50_uv_rwlock_rdlock" 

external luv_stub_blocking_51_uv_rwlock_wrlock : _ CI.fatptr -> unit
  = "luv_stub_blocking_51_uv_rwlock_wrlock" 

external luv_stub_blocking_52_uv_sem_wait : _ CI.fatptr -> unit
  = "luv_stub_blocking_52_uv_sem_wait" 

external luv_stub_blocking_53_uv_cond_wait
  : _ CI.fatptr -> _ CI.fatptr -> unit = "luv_stub_blocking_53_uv_cond_wait" 

external luv_stub_blocking_54_uv_cond_timedwait
  : _ CI.fatptr -> _ CI.fatptr -> Unsigned.uint64 -> int
  = "luv_stub_blocking_54_uv_cond_timedwait" 

external luv_stub_blocking_55_uv_barrier_wait : _ CI.fatptr -> bool
  = "luv_stub_blocking_55_uv_barrier_wait" 

external luv_stub_blocking_56_uv_sleep : int -> unit
  = "luv_stub_blocking_56_uv_sleep" 

external luv_stub_blocking_57_uv_random
  : _ CI.fatptr -> _ CI.fatptr -> _ CI.fatptr -> Unsigned.size_t ->
    Unsigned.uint -> _ CI.fatfunptr -> int
  = "luv_stub_blocking_57_uv_random_byte6" "luv_stub_blocking_57_uv_random" 

type 'a result = 'a
type 'a return = 'a
type 'a fn =
 | Returns  : 'a CI.typ   -> 'a return fn
 | Function : 'a CI.typ * 'b fn  -> ('a -> 'b) fn
let map_result f x = f x
let returning t = Returns t
let (@->) f p = Function (f, p)
let foreign : type a b. string -> (a -> b) fn -> (a -> b) =
  fun name t -> match t, name with
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Pointer _,
           Function
             (CI.Primitive CI.Size_t,
              Function
                (CI.Primitive CI.Uint,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_random" ->
  (fun x845 x847 x849 x851 x852 x853 ->
    let CI.Static_funptr x854 = x853 in
    let CI.CPointer x850 = x849 in
    let CI.CPointer x848 = x847 in
    let CI.CPointer x846 = x845 in
    luv_stub_blocking_57_uv_random x846 x848 x850 x851 x852 x854)
| Function (CI.Primitive CI.Int, Returns CI.Void), "uv_sleep" ->
  luv_stub_blocking_56_uv_sleep
| Function (CI.Pointer _, Returns (CI.Primitive CI.Bool)), "uv_barrier_wait" ->
  (fun x856 ->
    let CI.CPointer x857 = x856 in luv_stub_blocking_55_uv_barrier_wait x857)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function (CI.Primitive CI.Uint64_t, Returns (CI.Primitive CI.Int)))),
  "uv_cond_timedwait" ->
  (fun x858 x860 x862 ->
    let CI.CPointer x861 = x860 in
    let CI.CPointer x859 = x858 in
    luv_stub_blocking_54_uv_cond_timedwait x859 x861 x862)
| Function (CI.Pointer _, Function (CI.Pointer _, Returns CI.Void)),
  "uv_cond_wait" ->
  (fun x863 x865 ->
    let CI.CPointer x866 = x865 in
    let CI.CPointer x864 = x863 in
    luv_stub_blocking_53_uv_cond_wait x864 x866)
| Function (CI.Pointer _, Returns CI.Void), "uv_sem_wait" ->
  (fun x867 ->
    let CI.CPointer x868 = x867 in luv_stub_blocking_52_uv_sem_wait x868)
| Function (CI.Pointer _, Returns CI.Void), "uv_rwlock_wrlock" ->
  (fun x869 ->
    let CI.CPointer x870 = x869 in luv_stub_blocking_51_uv_rwlock_wrlock x870)
| Function (CI.Pointer _, Returns CI.Void), "uv_rwlock_rdlock" ->
  (fun x871 ->
    let CI.CPointer x872 = x871 in luv_stub_blocking_50_uv_rwlock_rdlock x872)
| Function (CI.Pointer _, Returns CI.Void), "uv_mutex_lock" ->
  (fun x873 ->
    let CI.CPointer x874 = x873 in luv_stub_blocking_49_uv_mutex_lock x874)
| Function (CI.Pointer _, Returns (CI.Primitive CI.Int)), "uv_thread_join" ->
  (fun x875 ->
    let CI.CPointer x876 = x875 in luv_stub_blocking_48_uv_thread_join x876)
| Function (CI.Pointer _, Returns (CI.Pointer x879)), "uv_fs_get_statbuf" ->
  (fun x877 ->
    let CI.CPointer x878 = x877 in
    CI.make_ptr x879 (luv_stub_blocking_47_uv_fs_get_statbuf x878))
| Function
    (CI.Pointer _,
     Returns (CI.View {CI.ty = CI.Pointer x882; read = x883; _})),
  "luv_fs_get_path" ->
  (fun x880 ->
    let CI.CPointer x881 = x880 in
    x883 (CI.make_ptr x882 (luv_stub_blocking_46_luv_fs_get_path x881)))
| Function
    (CI.Pointer _,
     Returns (CI.View {CI.ty = CI.Pointer x886; read = x887; _})),
  "uv_fs_get_ptr" ->
  (fun x884 ->
    let CI.CPointer x885 = x884 in
    x887 (CI.make_ptr x886 (luv_stub_blocking_45_uv_fs_get_ptr x885)))
| Function (CI.Pointer _, Returns (CI.Pointer x890)), "uv_fs_get_ptr" ->
  (fun x888 ->
    let CI.CPointer x889 = x888 in
    CI.make_ptr x890 (luv_stub_blocking_44_uv_fs_get_ptr x889))
| Function
    (CI.Pointer _,
     Returns (CI.View {CI.ty = CI.Primitive CI.Int64_t; read = x893; _})),
  "uv_fs_get_result" ->
  (fun x891 ->
    let CI.CPointer x892 = x891 in
    x893 (luv_stub_blocking_43_uv_fs_get_result x892))
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x899; _},
           Function
             (CI.Primitive CI.Int,
              Function
                (CI.Primitive CI.Int,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_fs_lchown" ->
  (fun x894 x896 x898 x902 x903 x904 ->
    let CI.Static_funptr x905 = x904 in
    let CI.CPointer x901 = x899 x898 in
    let CI.CPointer x897 = x896 in
    let CI.CPointer x895 = x894 in
    let x900 = x901 in
    luv_stub_blocking_42_uv_fs_lchown x895 x897 x900 x902 x903 x905)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function
             (CI.Primitive CI.Int,
              Function
                (CI.Primitive CI.Int,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_fs_fchown" ->
  (fun x906 x908 x910 x911 x912 x913 ->
    let CI.Static_funptr x914 = x913 in
    let CI.CPointer x909 = x908 in
    let CI.CPointer x907 = x906 in
    luv_stub_blocking_41_uv_fs_fchown x907 x909 x910 x911 x912 x914)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x920; _},
           Function
             (CI.Primitive CI.Int,
              Function
                (CI.Primitive CI.Int,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_fs_chown" ->
  (fun x915 x917 x919 x923 x924 x925 ->
    let CI.Static_funptr x926 = x925 in
    let CI.CPointer x922 = x920 x919 in
    let CI.CPointer x918 = x917 in
    let CI.CPointer x916 = x915 in
    let x921 = x922 in
    luv_stub_blocking_40_uv_fs_chown x916 x918 x921 x923 x924 x926)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x932; _},
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_realpath" ->
  (fun x927 x929 x931 x935 ->
    let CI.Static_funptr x936 = x935 in
    let CI.CPointer x934 = x932 x931 in
    let CI.CPointer x930 = x929 in
    let CI.CPointer x928 = x927 in
    let x933 = x934 in
    luv_stub_blocking_39_uv_fs_realpath x928 x930 x933 x936)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x942; _},
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_readlink" ->
  (fun x937 x939 x941 x945 ->
    let CI.Static_funptr x946 = x945 in
    let CI.CPointer x944 = x942 x941 in
    let CI.CPointer x940 = x939 in
    let CI.CPointer x938 = x937 in
    let x943 = x944 in
    luv_stub_blocking_38_uv_fs_readlink x938 x940 x943 x946)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x952; _},
           Function
             (CI.View {CI.ty = CI.Pointer _; write = x956; _},
              Function
                (CI.Primitive CI.Int,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_fs_symlink" ->
  (fun x947 x949 x951 x955 x959 x960 ->
    let CI.Static_funptr x961 = x960 in
    let CI.CPointer x958 = x956 x955 in
    let CI.CPointer x954 = x952 x951 in
    let CI.CPointer x950 = x949 in
    let CI.CPointer x948 = x947 in
    let x953 = x954 in
    let x957 = x958 in
    luv_stub_blocking_37_uv_fs_symlink x948 x950 x953 x957 x959 x961)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x967; _},
           Function
             (CI.View {CI.ty = CI.Pointer _; write = x971; _},
              Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))),
  "uv_fs_link" ->
  (fun x962 x964 x966 x970 x974 ->
    let CI.Static_funptr x975 = x974 in
    let CI.CPointer x973 = x971 x970 in
    let CI.CPointer x969 = x967 x966 in
    let CI.CPointer x965 = x964 in
    let CI.CPointer x963 = x962 in
    let x968 = x969 in
    let x972 = x973 in
    luv_stub_blocking_36_uv_fs_link x963 x965 x968 x972 x975)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x981; _},
           Function
             (CI.Primitive CI.Float,
              Function
                (CI.Primitive CI.Float,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_fs_lutime" ->
  (fun x976 x978 x980 x984 x985 x986 ->
    let CI.Static_funptr x987 = x986 in
    let CI.CPointer x983 = x981 x980 in
    let CI.CPointer x979 = x978 in
    let CI.CPointer x977 = x976 in
    let x982 = x983 in
    luv_stub_blocking_35_uv_fs_lutime x977 x979 x982 x984 x985 x987)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function
             (CI.Primitive CI.Float,
              Function
                (CI.Primitive CI.Float,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_fs_futime" ->
  (fun x988 x990 x992 x993 x994 x995 ->
    let CI.Static_funptr x996 = x995 in
    let CI.CPointer x991 = x990 in
    let CI.CPointer x989 = x988 in
    luv_stub_blocking_34_uv_fs_futime x989 x991 x992 x993 x994 x996)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1002; _},
           Function
             (CI.Primitive CI.Float,
              Function
                (CI.Primitive CI.Float,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_fs_utime" ->
  (fun x997 x999 x1001 x1005 x1006 x1007 ->
    let CI.Static_funptr x1008 = x1007 in
    let CI.CPointer x1004 = x1002 x1001 in
    let CI.CPointer x1000 = x999 in
    let CI.CPointer x998 = x997 in
    let x1003 = x1004 in
    luv_stub_blocking_33_uv_fs_utime x998 x1000 x1003 x1005 x1006 x1008)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function
             (CI.Primitive CI.Int,
              Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))),
  "uv_fs_fchmod" ->
  (fun x1009 x1011 x1013 x1014 x1015 ->
    let CI.Static_funptr x1016 = x1015 in
    let CI.CPointer x1012 = x1011 in
    let CI.CPointer x1010 = x1009 in
    luv_stub_blocking_32_uv_fs_fchmod x1010 x1012 x1013 x1014 x1016)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1022; _},
           Function
             (CI.Primitive CI.Int,
              Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))),
  "uv_fs_chmod" ->
  (fun x1017 x1019 x1021 x1025 x1026 ->
    let CI.Static_funptr x1027 = x1026 in
    let CI.CPointer x1024 = x1022 x1021 in
    let CI.CPointer x1020 = x1019 in
    let CI.CPointer x1018 = x1017 in
    let x1023 = x1024 in
    luv_stub_blocking_31_uv_fs_chmod x1018 x1020 x1023 x1025 x1027)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1033; _},
           Function
             (CI.Primitive CI.Int,
              Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))),
  "uv_fs_access" ->
  (fun x1028 x1030 x1032 x1036 x1037 ->
    let CI.Static_funptr x1038 = x1037 in
    let CI.CPointer x1035 = x1033 x1032 in
    let CI.CPointer x1031 = x1030 in
    let CI.CPointer x1029 = x1028 in
    let x1034 = x1035 in
    luv_stub_blocking_30_uv_fs_access x1029 x1031 x1034 x1036 x1038)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function
             (CI.Primitive CI.Int,
              Function
                (CI.Primitive CI.Int64_t,
                 Function
                   (CI.Primitive CI.Size_t,
                    Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))))),
  "uv_fs_sendfile" ->
  (fun x1039 x1041 x1043 x1044 x1045 x1046 x1047 ->
    let CI.Static_funptr x1048 = x1047 in
    let CI.CPointer x1042 = x1041 in
    let CI.CPointer x1040 = x1039 in
    luv_stub_blocking_29_uv_fs_sendfile x1040 x1042 x1043 x1044 x1045 x1046
    x1048)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1054; _},
           Function
             (CI.View {CI.ty = CI.Pointer _; write = x1058; _},
              Function
                (CI.Primitive CI.Int,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_fs_copyfile" ->
  (fun x1049 x1051 x1053 x1057 x1061 x1062 ->
    let CI.Static_funptr x1063 = x1062 in
    let CI.CPointer x1060 = x1058 x1057 in
    let CI.CPointer x1056 = x1054 x1053 in
    let CI.CPointer x1052 = x1051 in
    let CI.CPointer x1050 = x1049 in
    let x1055 = x1056 in
    let x1059 = x1060 in
    luv_stub_blocking_28_uv_fs_copyfile x1050 x1052 x1055 x1059 x1061 x1063)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function
             (CI.Primitive CI.Int64_t,
              Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))),
  "uv_fs_ftruncate" ->
  (fun x1064 x1066 x1068 x1069 x1070 ->
    let CI.Static_funptr x1071 = x1070 in
    let CI.CPointer x1067 = x1066 in
    let CI.CPointer x1065 = x1064 in
    luv_stub_blocking_27_uv_fs_ftruncate x1065 x1067 x1068 x1069 x1071)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_fdatasync" ->
  (fun x1072 x1074 x1076 x1077 ->
    let CI.Static_funptr x1078 = x1077 in
    let CI.CPointer x1075 = x1074 in
    let CI.CPointer x1073 = x1072 in
    luv_stub_blocking_26_uv_fs_fdatasync x1073 x1075 x1076 x1078)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_fsync" ->
  (fun x1079 x1081 x1083 x1084 ->
    let CI.Static_funptr x1085 = x1084 in
    let CI.CPointer x1082 = x1081 in
    let CI.CPointer x1080 = x1079 in
    luv_stub_blocking_25_uv_fs_fsync x1080 x1082 x1083 x1085)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1091; _},
           Function
             (CI.View {CI.ty = CI.Pointer _; write = x1095; _},
              Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))),
  "uv_fs_rename" ->
  (fun x1086 x1088 x1090 x1094 x1098 ->
    let CI.Static_funptr x1099 = x1098 in
    let CI.CPointer x1097 = x1095 x1094 in
    let CI.CPointer x1093 = x1091 x1090 in
    let CI.CPointer x1089 = x1088 in
    let CI.CPointer x1087 = x1086 in
    let x1092 = x1093 in
    let x1096 = x1097 in
    luv_stub_blocking_24_uv_fs_rename x1087 x1089 x1092 x1096 x1099)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1105; _},
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_statfs" ->
  (fun x1100 x1102 x1104 x1108 ->
    let CI.Static_funptr x1109 = x1108 in
    let CI.CPointer x1107 = x1105 x1104 in
    let CI.CPointer x1103 = x1102 in
    let CI.CPointer x1101 = x1100 in
    let x1106 = x1107 in
    luv_stub_blocking_23_uv_fs_statfs x1101 x1103 x1106 x1109)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_fstat" ->
  (fun x1110 x1112 x1114 x1115 ->
    let CI.Static_funptr x1116 = x1115 in
    let CI.CPointer x1113 = x1112 in
    let CI.CPointer x1111 = x1110 in
    luv_stub_blocking_22_uv_fs_fstat x1111 x1113 x1114 x1116)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1122; _},
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_lstat" ->
  (fun x1117 x1119 x1121 x1125 ->
    let CI.Static_funptr x1126 = x1125 in
    let CI.CPointer x1124 = x1122 x1121 in
    let CI.CPointer x1120 = x1119 in
    let CI.CPointer x1118 = x1117 in
    let x1123 = x1124 in
    luv_stub_blocking_21_uv_fs_lstat x1118 x1120 x1123 x1126)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1132; _},
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_stat" ->
  (fun x1127 x1129 x1131 x1135 ->
    let CI.Static_funptr x1136 = x1135 in
    let CI.CPointer x1134 = x1132 x1131 in
    let CI.CPointer x1130 = x1129 in
    let CI.CPointer x1128 = x1127 in
    let x1133 = x1134 in
    luv_stub_blocking_20_uv_fs_stat x1128 x1130 x1133 x1136)
| Function
    (CI.Pointer _, Function (CI.Pointer _, Returns (CI.Primitive CI.Int))),
  "uv_fs_scandir_next" ->
  (fun x1137 x1139 ->
    let CI.CPointer x1140 = x1139 in
    let CI.CPointer x1138 = x1137 in
    luv_stub_blocking_19_uv_fs_scandir_next x1138 x1140)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1146; _},
           Function
             (CI.Primitive CI.Int,
              Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))),
  "uv_fs_scandir" ->
  (fun x1141 x1143 x1145 x1149 x1150 ->
    let CI.Static_funptr x1151 = x1150 in
    let CI.CPointer x1148 = x1146 x1145 in
    let CI.CPointer x1144 = x1143 in
    let CI.CPointer x1142 = x1141 in
    let x1147 = x1148 in
    luv_stub_blocking_18_uv_fs_scandir x1142 x1144 x1147 x1149 x1151)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Pointer _,
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_readdir" ->
  (fun x1152 x1154 x1156 x1158 ->
    let CI.Static_funptr x1159 = x1158 in
    let CI.CPointer x1157 = x1156 in
    let CI.CPointer x1155 = x1154 in
    let CI.CPointer x1153 = x1152 in
    luv_stub_blocking_17_uv_fs_readdir x1153 x1155 x1157 x1159)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Pointer _,
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_closedir" ->
  (fun x1160 x1162 x1164 x1166 ->
    let CI.Static_funptr x1167 = x1166 in
    let CI.CPointer x1165 = x1164 in
    let CI.CPointer x1163 = x1162 in
    let CI.CPointer x1161 = x1160 in
    luv_stub_blocking_16_uv_fs_closedir x1161 x1163 x1165 x1167)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1173; _},
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_opendir" ->
  (fun x1168 x1170 x1172 x1176 ->
    let CI.Static_funptr x1177 = x1176 in
    let CI.CPointer x1175 = x1173 x1172 in
    let CI.CPointer x1171 = x1170 in
    let CI.CPointer x1169 = x1168 in
    let x1174 = x1175 in
    luv_stub_blocking_15_uv_fs_opendir x1169 x1171 x1174 x1177)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1183; _},
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_rmdir" ->
  (fun x1178 x1180 x1182 x1186 ->
    let CI.Static_funptr x1187 = x1186 in
    let CI.CPointer x1185 = x1183 x1182 in
    let CI.CPointer x1181 = x1180 in
    let CI.CPointer x1179 = x1178 in
    let x1184 = x1185 in
    luv_stub_blocking_14_uv_fs_rmdir x1179 x1181 x1184 x1187)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1193; _},
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_mkstemp" ->
  (fun x1188 x1190 x1192 x1196 ->
    let CI.Static_funptr x1197 = x1196 in
    let CI.CPointer x1195 = x1193 x1192 in
    let CI.CPointer x1191 = x1190 in
    let CI.CPointer x1189 = x1188 in
    let x1194 = x1195 in
    luv_stub_blocking_13_uv_fs_mkstemp x1189 x1191 x1194 x1197)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1203; _},
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_mkdtemp" ->
  (fun x1198 x1200 x1202 x1206 ->
    let CI.Static_funptr x1207 = x1206 in
    let CI.CPointer x1205 = x1203 x1202 in
    let CI.CPointer x1201 = x1200 in
    let CI.CPointer x1199 = x1198 in
    let x1204 = x1205 in
    luv_stub_blocking_12_uv_fs_mkdtemp x1199 x1201 x1204 x1207)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1213; _},
           Function
             (CI.Primitive CI.Int,
              Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))),
  "uv_fs_mkdir" ->
  (fun x1208 x1210 x1212 x1216 x1217 ->
    let CI.Static_funptr x1218 = x1217 in
    let CI.CPointer x1215 = x1213 x1212 in
    let CI.CPointer x1211 = x1210 in
    let CI.CPointer x1209 = x1208 in
    let x1214 = x1215 in
    luv_stub_blocking_11_uv_fs_mkdir x1209 x1211 x1214 x1216 x1218)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1224; _},
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_unlink" ->
  (fun x1219 x1221 x1223 x1227 ->
    let CI.Static_funptr x1228 = x1227 in
    let CI.CPointer x1226 = x1224 x1223 in
    let CI.CPointer x1222 = x1221 in
    let CI.CPointer x1220 = x1219 in
    let x1225 = x1226 in
    luv_stub_blocking_10_uv_fs_unlink x1220 x1222 x1225 x1228)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function
             (CI.Pointer _,
              Function
                (CI.Primitive CI.Uint,
                 Function
                   (CI.Primitive CI.Int64_t,
                    Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))))),
  "uv_fs_write" ->
  (fun x1229 x1231 x1233 x1234 x1236 x1237 x1238 ->
    let CI.Static_funptr x1239 = x1238 in
    let CI.CPointer x1235 = x1234 in
    let CI.CPointer x1232 = x1231 in
    let CI.CPointer x1230 = x1229 in
    luv_stub_blocking_9_uv_fs_write x1230 x1232 x1233 x1235 x1236 x1237 x1239)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function
             (CI.Pointer _,
              Function
                (CI.Primitive CI.Uint,
                 Function
                   (CI.Primitive CI.Int64_t,
                    Function (CI.Funptr _, Returns (CI.Primitive CI.Int)))))))),
  "uv_fs_read" ->
  (fun x1240 x1242 x1244 x1245 x1247 x1248 x1249 ->
    let CI.Static_funptr x1250 = x1249 in
    let CI.CPointer x1246 = x1245 in
    let CI.CPointer x1243 = x1242 in
    let CI.CPointer x1241 = x1240 in
    luv_stub_blocking_8_uv_fs_read x1241 x1243 x1244 x1246 x1247 x1248 x1250)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.View {CI.ty = CI.Pointer _; write = x1256; _},
           Function
             (CI.Primitive CI.Int,
              Function
                (CI.Primitive CI.Int,
                 Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))))),
  "uv_fs_open" ->
  (fun x1251 x1253 x1255 x1259 x1260 x1261 ->
    let CI.Static_funptr x1262 = x1261 in
    let CI.CPointer x1258 = x1256 x1255 in
    let CI.CPointer x1254 = x1253 in
    let CI.CPointer x1252 = x1251 in
    let x1257 = x1258 in
    luv_stub_blocking_7_uv_fs_open x1252 x1254 x1257 x1259 x1260 x1262)
| Function
    (CI.Pointer _,
     Function
       (CI.Pointer _,
        Function
          (CI.Primitive CI.Int,
           Function (CI.Funptr _, Returns (CI.Primitive CI.Int))))),
  "uv_fs_close" ->
  (fun x1263 x1265 x1267 x1268 ->
    let CI.Static_funptr x1269 = x1268 in
    let CI.CPointer x1266 = x1265 in
    let CI.CPointer x1264 = x1263 in
    luv_stub_blocking_6_uv_fs_close x1264 x1266 x1267 x1269)
| Function (CI.Pointer _, Returns CI.Void), "uv_fs_req_cleanup" ->
  (fun x1270 ->
    let CI.CPointer x1271 = x1270 in
    luv_stub_blocking_5_uv_fs_req_cleanup x1271)
| Function (CI.Void, Returns (CI.Funptr x1273)),
  "luv_null_fs_callback_pointer" ->
  (fun x1272 ->
    CI.make_fun_ptr x1273
      (luv_stub_blocking_4_luv_null_fs_callback_pointer x1272))
| Function (CI.Void, Returns (CI.Funptr x1275)), "luv_get_fs_trampoline" ->
  (fun x1274 ->
    CI.make_fun_ptr x1275 (luv_stub_blocking_3_luv_get_fs_trampoline x1274))
| Function
    (CI.Pointer _,
     Function
       (CI.View {CI.ty = CI.Pointer _; write = x1279; _},
        Returns (CI.Primitive CI.Int))),
  "uv_pipe_bind" ->
  (fun x1276 x1278 ->
    let CI.CPointer x1281 = x1279 x1278 in
    let CI.CPointer x1277 = x1276 in
    let x1280 = x1281 in luv_stub_blocking_2_uv_pipe_bind x1277 x1280)
| Function
    (CI.Pointer _,
     Function
       (CI.View {CI.ty = CI.Primitive CI.Uint32_t; write = x1285; _},
        Returns (CI.Primitive CI.Bool))),
  "uv_run" ->
  (fun x1282 x1284 ->
    let CI.CPointer x1283 = x1282 in
    let x1286 = x1285 x1284 in luv_stub_blocking_1_uv_run x1283 x1286)
| _, s ->  Printf.ksprintf failwith "No match for %s" s


let foreign_value : type a. string -> a Ctypes.typ -> a Ctypes.ptr =
  fun name t -> match t, name with
| _, s ->  Printf.ksprintf failwith "No match for %s" s
end

