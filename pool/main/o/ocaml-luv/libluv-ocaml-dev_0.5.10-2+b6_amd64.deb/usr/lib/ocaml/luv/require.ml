type 'p s

type ___0
type ___1 = ___0 s
type ___2 = ___1 s
type ___3 = ___2 s
type ___4 = ___3 s
type ___5 = ___4 s
type ___6 = ___5 s
type ___7 = ___6 s
type ___8 = ___7 s
type ___9 = ___8 s
type ___10 = ___9 s
type ___11 = ___10 s
type ___12 = ___11 s
type ___13 = ___12 s
type ___14 = ___13 s
type ___15 = ___14 s
type ___16 = ___15 s
type ___17 = ___16 s
type ___18 = ___17 s
type ___19 = ___18 s
type ___20 = ___19 s
type ___21 = ___20 s
type ___22 = ___21 s
type ___23 = ___22 s
type ___24 = ___23 s
type ___25 = ___24 s
type ___26 = ___25 s
type ___27 = ___26 s
type ___28 = ___27 s
type ___29 = ___28 s
type ___30 = ___29 s
type ___31 = ___30 s
type ___32 = ___31 s
type ___33 = ___32 s
type ___34 = ___33 s
type ___35 = ___34 s
type ___36 = ___35 s
type ___37 = ___36 s
type ___38 = ___37 s
type ___39 = ___38 s
type ___40 = ___39 s
type ___41 = ___40 s
type ___42 = ___41 s
type ___43 = ___42 s
type ___44 = ___43 s
type ___45 = ___44 s
type ___46 = ___45 s
type ___47 = ___46 s
type ___48 = ___47 s
type ___49 = ___48 s
type ___50 = ___49 s
type ___51 = ___50 s
type ___52 = ___51 s
type ___53 = ___52 s
type ___54 = ___53 s
type ___55 = ___54 s
type ___56 = ___55 s
type ___57 = ___56 s
type ___58 = ___57 s
type ___59 = ___58 s
type ___60 = ___59 s
type ___61 = ___60 s
type ___62 = ___61 s
type ___63 = ___62 s
type ___64 = ___63 s
type ___65 = ___64 s
type ___66 = ___65 s
type ___67 = ___66 s
type ___68 = ___67 s
type ___69 = ___68 s
type ___70 = ___69 s
type ___71 = ___70 s
type ___72 = ___71 s
type ___73 = ___72 s
type ___74 = ___73 s
type ___75 = ___74 s
type ___76 = ___75 s
type ___77 = ___76 s
type ___78 = ___77 s
type ___79 = ___78 s
type ___80 = ___79 s
type ___81 = ___80 s
type ___82 = ___81 s
type ___83 = ___82 s
type ___84 = ___83 s
type ___85 = ___84 s
type ___86 = ___85 s
type ___87 = ___86 s
type ___88 = ___87 s
type ___89 = ___88 s
type ___90 = ___89 s
type ___91 = ___90 s
type ___92 = ___91 s
type ___93 = ___92 s
type ___94 = ___93 s
type ___95 = ___94 s
type ___96 = ___95 s
type ___97 = ___96 s
type ___98 = ___97 s
type ___99 = ___98 s
type ___inf = ___99 s

type _0 = int * ___0
type _1 = int * ___1
type _2 = int * ___2
type _3 = int * ___3
type _4 = int * ___4
type _5 = int * ___5
type _6 = int * ___6
type _7 = int * ___7
type _8 = int * ___8
type _9 = int * ___9
type _10 = int * ___10
type _11 = int * ___11
type _12 = int * ___12
type _13 = int * ___13
type _14 = int * ___14
type _15 = int * ___15
type _16 = int * ___16
type _17 = int * ___17
type _18 = int * ___18
type _19 = int * ___19
type _20 = int * ___20
type _21 = int * ___21
type _22 = int * ___22
type _23 = int * ___23
type _24 = int * ___24
type _25 = int * ___25
type _26 = int * ___26
type _27 = int * ___27
type _28 = int * ___28
type _29 = int * ___29
type _30 = int * ___30
type _31 = int * ___31
type _32 = int * ___32
type _33 = int * ___33
type _34 = int * ___34
type _35 = int * ___35
type _36 = int * ___36
type _37 = int * ___37
type _38 = int * ___38
type _39 = int * ___39
type _40 = int * ___40
type _41 = int * ___41
type _42 = int * ___42
type _43 = int * ___43
type _44 = int * ___44
type _45 = int * ___45
type _46 = int * ___46
type _47 = int * ___47
type _48 = int * ___48
type _49 = int * ___49
type _50 = int * ___50
type _51 = int * ___51
type _52 = int * ___52
type _53 = int * ___53
type _54 = int * ___54
type _55 = int * ___55
type _56 = int * ___56
type _57 = int * ___57
type _58 = int * ___58
type _59 = int * ___59
type _60 = int * ___60
type _61 = int * ___61
type _62 = int * ___62
type _63 = int * ___63
type _64 = int * ___64
type _65 = int * ___65
type _66 = int * ___66
type _67 = int * ___67
type _68 = int * ___68
type _69 = int * ___69
type _70 = int * ___70
type _71 = int * ___71
type _72 = int * ___72
type _73 = int * ___73
type _74 = int * ___74
type _75 = int * ___75
type _76 = int * ___76
type _77 = int * ___77
type _78 = int * ___78
type _79 = int * ___79
type _80 = int * ___80
type _81 = int * ___81
type _82 = int * ___82
type _83 = int * ___83
type _84 = int * ___84
type _85 = int * ___85
type _86 = int * ___86
type _87 = int * ___87
type _88 = int * ___88
type _89 = int * ___89
type _90 = int * ___90
type _91 = int * ___91
type _92 = int * ___92
type _93 = int * ___93
type _94 = int * ___94
type _95 = int * ___95
type _96 = int * ___96
type _97 = int * ___97
type _98 = int * ___98
type _99 = int * ___99
type _inf = int * ___inf

type 'u __0 = 'u
type 'u __1 = 'u __0 s
type 'u __2 = 'u __1 s
type 'u __3 = 'u __2 s
type 'u __4 = 'u __3 s
type 'u __5 = 'u __4 s
type 'u __6 = 'u __5 s
type 'u __7 = 'u __6 s
type 'u __8 = 'u __7 s
type 'u __9 = 'u __8 s
type 'u __10 = 'u __9 s
type 'u __11 = 'u __10 s
type 'u __12 = 'u __11 s
type 'u __13 = 'u __12 s
type 'u __14 = 'u __13 s
type 'u __15 = 'u __14 s
type 'u __16 = 'u __15 s
type 'u __17 = 'u __16 s
type 'u __18 = 'u __17 s
type 'u __19 = 'u __18 s
type 'u __20 = 'u __19 s
type 'u __21 = 'u __20 s
type 'u __22 = 'u __21 s
type 'u __23 = 'u __22 s
type 'u __24 = 'u __23 s
type 'u __25 = 'u __24 s
type 'u __26 = 'u __25 s
type 'u __27 = 'u __26 s
type 'u __28 = 'u __27 s
type 'u __29 = 'u __28 s
type 'u __30 = 'u __29 s
type 'u __31 = 'u __30 s
type 'u __32 = 'u __31 s
type 'u __33 = 'u __32 s
type 'u __34 = 'u __33 s
type 'u __35 = 'u __34 s
type 'u __36 = 'u __35 s
type 'u __37 = 'u __36 s
type 'u __38 = 'u __37 s
type 'u __39 = 'u __38 s
type 'u __40 = 'u __39 s
type 'u __41 = 'u __40 s
type 'u __42 = 'u __41 s
type 'u __43 = 'u __42 s
type 'u __44 = 'u __43 s
type 'u __45 = 'u __44 s
type 'u __46 = 'u __45 s
type 'u __47 = 'u __46 s
type 'u __48 = 'u __47 s
type 'u __49 = 'u __48 s
type 'u __50 = 'u __49 s
type 'u __51 = 'u __50 s
type 'u __52 = 'u __51 s
type 'u __53 = 'u __52 s
type 'u __54 = 'u __53 s
type 'u __55 = 'u __54 s
type 'u __56 = 'u __55 s
type 'u __57 = 'u __56 s
type 'u __58 = 'u __57 s
type 'u __59 = 'u __58 s
type 'u __60 = 'u __59 s
type 'u __61 = 'u __60 s
type 'u __62 = 'u __61 s
type 'u __63 = 'u __62 s
type 'u __64 = 'u __63 s
type 'u __65 = 'u __64 s
type 'u __66 = 'u __65 s
type 'u __67 = 'u __66 s
type 'u __68 = 'u __67 s
type 'u __69 = 'u __68 s
type 'u __70 = 'u __69 s
type 'u __71 = 'u __70 s
type 'u __72 = 'u __71 s
type 'u __73 = 'u __72 s
type 'u __74 = 'u __73 s
type 'u __75 = 'u __74 s
type 'u __76 = 'u __75 s
type 'u __77 = 'u __76 s
type 'u __78 = 'u __77 s
type 'u __79 = 'u __78 s
type 'u __80 = 'u __79 s
type 'u __81 = 'u __80 s
type 'u __82 = 'u __81 s
type 'u __83 = 'u __82 s
type 'u __84 = 'u __83 s
type 'u __85 = 'u __84 s
type 'u __86 = 'u __85 s
type 'u __87 = 'u __86 s
type 'u __88 = 'u __87 s
type 'u __89 = 'u __88 s
type 'u __90 = 'u __89 s
type 'u __91 = 'u __90 s
type 'u __92 = 'u __91 s
type 'u __93 = 'u __92 s
type 'u __94 = 'u __93 s
type 'u __95 = 'u __94 s
type 'u __96 = 'u __95 s
type 'u __97 = 'u __96 s
type 'u __98 = 'u __97 s
type 'u __99 = 'u __98 s

type 'compile_time_value number = unit

let _0 = ()
let _1 = ()
let _2 = ()
let _3 = ()
let _4 = ()
let _5 = ()
let _6 = ()
let _7 = ()
let _8 = ()
let _9 = ()
let _10 = ()
let _11 = ()
let _12 = ()
let _13 = ()
let _14 = ()
let _15 = ()
let _16 = ()
let _17 = ()
let _18 = ()
let _19 = ()
let _20 = ()
let _21 = ()
let _22 = ()
let _23 = ()
let _24 = ()
let _25 = ()
let _26 = ()
let _27 = ()
let _28 = ()
let _29 = ()
let _30 = ()
let _31 = ()
let _32 = ()
let _33 = ()
let _34 = ()
let _35 = ()
let _36 = ()
let _37 = ()
let _38 = ()
let _39 = ()
let _40 = ()
let _41 = ()
let _42 = ()
let _43 = ()
let _44 = ()
let _45 = ()
let _46 = ()
let _47 = ()
let _48 = ()
let _49 = ()
let _50 = ()
let _51 = ()
let _52 = ()
let _53 = ()
let _54 = ()
let _55 = ()
let _56 = ()
let _57 = ()
let _58 = ()
let _59 = ()
let _60 = ()
let _61 = ()
let _62 = ()
let _63 = ()
let _64 = ()
let _65 = ()
let _66 = ()
let _67 = ()
let _68 = ()
let _69 = ()
let _70 = ()
let _71 = ()
let _72 = ()
let _73 = ()
let _74 = ()
let _75 = ()
let _76 = ()
let _77 = ()
let _78 = ()
let _79 = ()
let _80 = ()
let _81 = ()
let _82 = ()
let _83 = ()
let _84 = ()
let _85 = ()
let _86 = ()
let _87 = ()
let _88 = ()
let _89 = ()
let _90 = ()
let _91 = ()
let _92 = ()
let _93 = ()
let _94 = ()
let _95 = ()
let _96 = ()
let _97 = ()
let _98 = ()
let _99 = ()

type __true
type __false

type _true = bool * __true
type _false = bool * __false

type 'a feature = 'run_time
  constraint 'a = 'run_time * _

let get feature =
  feature

let (>=) _ _ =
  ()

let has _ =
  ()

let libuv1 = 44

let luv05 = 7

let disconnect = true

let eftype = true

let eilseq = true

let enotty = true

let eoverflow = true

let esocktnosupport = true

let err_name_r = true

let fs_copyfile = true

let fs_copyfile_ficlone = true

let fs_lutime = true

let fs_lchown = true

let fs_mkstemp = true

let fs_o_filemap = true

let fs_realpath = true

let fs_statfs = true

let get_constrained_memory = true

let get_osfhandle = true

let gettimeofday = true

let if_indextoiid = true

let if_indextoname = true

let library_shutdown = true

let loop_fork = true

let maxhostnamesize = true

let metrics_idle_time = true

let mutex_init_recursive = true

let open_osfhandle = true

let os_environ = true

let os_homedir = true

let os_get_passwd = true

let os_getenv = true

let os_gethostname = true

let os_getpid = true

let os_getppid = true

let os_priority = true

let os_tmpdir = true

let os_uname = true

let overlapped_pipe = true

let pipe = true

let pipe_chmod = true

let prioritized = true

let process_windows_hide_console = true

let process_windows_hide_gui = true

let random = true

let readdir = true

let signal_start_oneshot = true

let sleep = true

let socketpair = true

let strerror_r = true

let tcp_close_reset = true

let tcp_init_ex = true

let timer_get_due_in = true

let thread_stack_size = true

let translate_sys_error = true

let try_write2 = true

let tty_vterm_state = true

let udp_connect = true

let udp_init_ex = true

let udp_mmsg_chunk = true

let udp_mmsg_free = true

let udp_recvmmsg = true

let udp_set_source_membership = true

let udp_using_recvmmsg = true
