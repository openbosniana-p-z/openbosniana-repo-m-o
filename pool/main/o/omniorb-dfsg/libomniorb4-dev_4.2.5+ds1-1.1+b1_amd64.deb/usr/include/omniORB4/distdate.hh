// distdate.hh -- Automatically generated file

#define OMNIORB_DIST_DATE "Sun  9 Jan 14:51:38 GMT 2022"
