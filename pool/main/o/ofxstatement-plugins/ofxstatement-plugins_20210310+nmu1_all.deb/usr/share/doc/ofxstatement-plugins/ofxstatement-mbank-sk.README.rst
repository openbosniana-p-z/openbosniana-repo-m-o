~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
MBank.sk plugin for ofxstatement
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CSV import plugin for MBank.sk
