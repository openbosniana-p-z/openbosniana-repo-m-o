This is a collection of parsers for propriatory statement formats, produced by
certain Lithuanian banks. It is a plugin for `ofxstatement`_.

CSV statements from these banks are currently supported:

* Danske
* Swedbank
* DnB

.. _ofxstatement: https://github.com/kedder/ofxstatement