Collection of Plugins for ofxstatement
=========

Some plugins for `ofxstatement`_

It includes at the moment three different plugins for german banks:

`Flatex`_

`DKB Deutsche Kreditbank AG`_

`Amazon Creditcard @ LBB Landesbank Berlin`_

.. _ofxstatement: https://github.com/kedder/ofxstatement
.. _Flatex: https://www.flatex.de/
.. _DKB Deutsche Kreditbank AG: http://www.dkb.de/
.. _Amazon Creditcard @ LBB Landesbank Berlin: http://lbb.de/amazon
