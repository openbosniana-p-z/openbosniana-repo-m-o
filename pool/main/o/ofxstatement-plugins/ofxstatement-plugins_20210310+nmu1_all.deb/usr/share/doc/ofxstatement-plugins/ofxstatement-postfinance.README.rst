~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Plugin for Post Finance for ofxstatement
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Support for reading E-Finance Java text output for detailed bank and
credit card statements.

