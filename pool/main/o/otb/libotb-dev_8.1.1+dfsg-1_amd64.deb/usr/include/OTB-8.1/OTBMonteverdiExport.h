
#ifndef OTBMonteverdi_EXPORT_H
#define OTBMonteverdi_EXPORT_H

#ifdef OTB_STATIC
#  define OTBMonteverdi_EXPORT
#  define OTBMonteverdi_HIDDEN
#  define OTBMonteverdi_EXPORT_TEMPLATE
#  define OTBMonteverdi_EXPORT_EXPLICIT_TEMPLATE
#else
#  ifndef OTBMonteverdi_EXPORT
#    ifdef OTBMonteverdi_EXPORTS
        /* We are building this library */
#      define OTBMonteverdi_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBMonteverdi_EXPORT __attribute__((visibility("default")))
#    endif
#  endif
#  ifndef OTBMonteverdi_EXPORT_TEMPLATE
        /* We are building this library */
#      define OTBMonteverdi_EXPORT_TEMPLATE __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBMonteverdi_EXPORT_TEMPLATE __attribute__((visibility("default")))
#  endif
#  ifndef OTBMonteverdi_EXPORT_EXPLICIT_TEMPLATE
        /* We are building this library */
#      define OTBMonteverdi_EXPORT_EXPLICIT_TEMPLATE 
#    else
        /* We are using this library */
#      define OTBMonteverdi_EXPORT_EXPLICIT_TEMPLATE 
#  endif
#  ifndef OTBMonteverdi_HIDDEN
#    define OTBMonteverdi_HIDDEN __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OTBMonteverdi_DEPRECATED
#  define OTBMonteverdi_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OTBMonteverdi_DEPRECATED_EXPORT
#  define OTBMonteverdi_DEPRECATED_EXPORT OTBMonteverdi_EXPORT OTBMonteverdi_DEPRECATED
#endif

#ifndef OTBMonteverdi_DEPRECATED_NO_EXPORT
#  define OTBMonteverdi_DEPRECATED_NO_EXPORT OTBMonteverdi_HIDDEN OTBMonteverdi_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OTBMONTEVERDI_NO_DEPRECATED
#    define OTBMONTEVERDI_NO_DEPRECATED
#  endif
#endif

#endif /* OTBMonteverdi_EXPORT_H */
