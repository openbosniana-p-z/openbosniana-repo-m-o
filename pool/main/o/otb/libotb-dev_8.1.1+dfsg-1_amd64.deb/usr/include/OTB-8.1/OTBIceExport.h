
#ifndef OTBIce_EXPORT_H
#define OTBIce_EXPORT_H

#ifdef OTB_STATIC
#  define OTBIce_EXPORT
#  define OTBIce_HIDDEN
#  define OTBIce_EXPORT_TEMPLATE
#  define OTBIce_EXPORT_EXPLICIT_TEMPLATE
#else
#  ifndef OTBIce_EXPORT
#    ifdef OTBIce_EXPORTS
        /* We are building this library */
#      define OTBIce_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBIce_EXPORT __attribute__((visibility("default")))
#    endif
#  endif
#  ifndef OTBIce_EXPORT_TEMPLATE
        /* We are building this library */
#      define OTBIce_EXPORT_TEMPLATE __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBIce_EXPORT_TEMPLATE __attribute__((visibility("default")))
#  endif
#  ifndef OTBIce_EXPORT_EXPLICIT_TEMPLATE
        /* We are building this library */
#      define OTBIce_EXPORT_EXPLICIT_TEMPLATE 
#    else
        /* We are using this library */
#      define OTBIce_EXPORT_EXPLICIT_TEMPLATE 
#  endif
#  ifndef OTBIce_HIDDEN
#    define OTBIce_HIDDEN __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OTBIce_DEPRECATED
#  define OTBIce_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OTBIce_DEPRECATED_EXPORT
#  define OTBIce_DEPRECATED_EXPORT OTBIce_EXPORT OTBIce_DEPRECATED
#endif

#ifndef OTBIce_DEPRECATED_NO_EXPORT
#  define OTBIce_DEPRECATED_NO_EXPORT OTBIce_HIDDEN OTBIce_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OTBICE_NO_DEPRECATED
#    define OTBICE_NO_DEPRECATED
#  endif
#endif

#endif /* OTBIce_EXPORT_H */
