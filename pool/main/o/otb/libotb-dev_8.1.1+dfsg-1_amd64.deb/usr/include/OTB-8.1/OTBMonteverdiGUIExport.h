
#ifndef OTBMonteverdiGUI_EXPORT_H
#define OTBMonteverdiGUI_EXPORT_H

#ifdef OTB_STATIC
#  define OTBMonteverdiGUI_EXPORT
#  define OTBMonteverdiGUI_HIDDEN
#  define OTBMonteverdiGUI_EXPORT_TEMPLATE
#  define OTBMonteverdiGUI_EXPORT_EXPLICIT_TEMPLATE
#else
#  ifndef OTBMonteverdiGUI_EXPORT
#    ifdef OTBMonteverdiGUI_EXPORTS
        /* We are building this library */
#      define OTBMonteverdiGUI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBMonteverdiGUI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif
#  ifndef OTBMonteverdiGUI_EXPORT_TEMPLATE
        /* We are building this library */
#      define OTBMonteverdiGUI_EXPORT_TEMPLATE __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBMonteverdiGUI_EXPORT_TEMPLATE __attribute__((visibility("default")))
#  endif
#  ifndef OTBMonteverdiGUI_EXPORT_EXPLICIT_TEMPLATE
        /* We are building this library */
#      define OTBMonteverdiGUI_EXPORT_EXPLICIT_TEMPLATE 
#    else
        /* We are using this library */
#      define OTBMonteverdiGUI_EXPORT_EXPLICIT_TEMPLATE 
#  endif
#  ifndef OTBMonteverdiGUI_HIDDEN
#    define OTBMonteverdiGUI_HIDDEN __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OTBMonteverdiGUI_DEPRECATED
#  define OTBMonteverdiGUI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OTBMonteverdiGUI_DEPRECATED_EXPORT
#  define OTBMonteverdiGUI_DEPRECATED_EXPORT OTBMonteverdiGUI_EXPORT OTBMonteverdiGUI_DEPRECATED
#endif

#ifndef OTBMonteverdiGUI_DEPRECATED_NO_EXPORT
#  define OTBMonteverdiGUI_DEPRECATED_NO_EXPORT OTBMonteverdiGUI_HIDDEN OTBMonteverdiGUI_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OTBMONTEVERDIGUI_NO_DEPRECATED
#    define OTBMONTEVERDIGUI_NO_DEPRECATED
#  endif
#endif

#endif /* OTBMonteverdiGUI_EXPORT_H */
