
#ifndef OTBMonteverdiCore_EXPORT_H
#define OTBMonteverdiCore_EXPORT_H

#ifdef OTB_STATIC
#  define OTBMonteverdiCore_EXPORT
#  define OTBMonteverdiCore_HIDDEN
#  define OTBMonteverdiCore_EXPORT_TEMPLATE
#  define OTBMonteverdiCore_EXPORT_EXPLICIT_TEMPLATE
#else
#  ifndef OTBMonteverdiCore_EXPORT
#    ifdef OTBMonteverdiCore_EXPORTS
        /* We are building this library */
#      define OTBMonteverdiCore_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBMonteverdiCore_EXPORT __attribute__((visibility("default")))
#    endif
#  endif
#  ifndef OTBMonteverdiCore_EXPORT_TEMPLATE
        /* We are building this library */
#      define OTBMonteverdiCore_EXPORT_TEMPLATE __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBMonteverdiCore_EXPORT_TEMPLATE __attribute__((visibility("default")))
#  endif
#  ifndef OTBMonteverdiCore_EXPORT_EXPLICIT_TEMPLATE
        /* We are building this library */
#      define OTBMonteverdiCore_EXPORT_EXPLICIT_TEMPLATE 
#    else
        /* We are using this library */
#      define OTBMonteverdiCore_EXPORT_EXPLICIT_TEMPLATE 
#  endif
#  ifndef OTBMonteverdiCore_HIDDEN
#    define OTBMonteverdiCore_HIDDEN __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OTBMonteverdiCore_DEPRECATED
#  define OTBMonteverdiCore_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OTBMonteverdiCore_DEPRECATED_EXPORT
#  define OTBMonteverdiCore_DEPRECATED_EXPORT OTBMonteverdiCore_EXPORT OTBMonteverdiCore_DEPRECATED
#endif

#ifndef OTBMonteverdiCore_DEPRECATED_NO_EXPORT
#  define OTBMonteverdiCore_DEPRECATED_NO_EXPORT OTBMonteverdiCore_HIDDEN OTBMonteverdiCore_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OTBMONTEVERDICORE_NO_DEPRECATED
#    define OTBMONTEVERDICORE_NO_DEPRECATED
#  endif
#endif

#endif /* OTBMonteverdiCore_EXPORT_H */
