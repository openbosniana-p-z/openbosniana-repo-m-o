
#ifndef OTBQtAdapters_EXPORT_H
#define OTBQtAdapters_EXPORT_H

#ifdef OTB_STATIC
#  define OTBQtAdapters_EXPORT
#  define OTBQtAdapters_HIDDEN
#  define OTBQtAdapters_EXPORT_TEMPLATE
#  define OTBQtAdapters_EXPORT_EXPLICIT_TEMPLATE
#else
#  ifndef OTBQtAdapters_EXPORT
#    ifdef OTBQtAdapters_EXPORTS
        /* We are building this library */
#      define OTBQtAdapters_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBQtAdapters_EXPORT __attribute__((visibility("default")))
#    endif
#  endif
#  ifndef OTBQtAdapters_EXPORT_TEMPLATE
        /* We are building this library */
#      define OTBQtAdapters_EXPORT_TEMPLATE __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBQtAdapters_EXPORT_TEMPLATE __attribute__((visibility("default")))
#  endif
#  ifndef OTBQtAdapters_EXPORT_EXPLICIT_TEMPLATE
        /* We are building this library */
#      define OTBQtAdapters_EXPORT_EXPLICIT_TEMPLATE 
#    else
        /* We are using this library */
#      define OTBQtAdapters_EXPORT_EXPLICIT_TEMPLATE 
#  endif
#  ifndef OTBQtAdapters_HIDDEN
#    define OTBQtAdapters_HIDDEN __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OTBQtAdapters_DEPRECATED
#  define OTBQtAdapters_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OTBQtAdapters_DEPRECATED_EXPORT
#  define OTBQtAdapters_DEPRECATED_EXPORT OTBQtAdapters_EXPORT OTBQtAdapters_DEPRECATED
#endif

#ifndef OTBQtAdapters_DEPRECATED_NO_EXPORT
#  define OTBQtAdapters_DEPRECATED_NO_EXPORT OTBQtAdapters_HIDDEN OTBQtAdapters_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OTBQTADAPTERS_NO_DEPRECATED
#    define OTBQTADAPTERS_NO_DEPRECATED
#  endif
#endif

#endif /* OTBQtAdapters_EXPORT_H */
