
#ifndef OTBMapla_EXPORT_H
#define OTBMapla_EXPORT_H

#ifdef OTB_STATIC
#  define OTBMapla_EXPORT
#  define OTBMapla_HIDDEN
#  define OTBMapla_EXPORT_TEMPLATE
#  define OTBMapla_EXPORT_EXPLICIT_TEMPLATE
#else
#  ifndef OTBMapla_EXPORT
#    ifdef OTBMapla_EXPORTS
        /* We are building this library */
#      define OTBMapla_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBMapla_EXPORT __attribute__((visibility("default")))
#    endif
#  endif
#  ifndef OTBMapla_EXPORT_TEMPLATE
        /* We are building this library */
#      define OTBMapla_EXPORT_TEMPLATE __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBMapla_EXPORT_TEMPLATE __attribute__((visibility("default")))
#  endif
#  ifndef OTBMapla_EXPORT_EXPLICIT_TEMPLATE
        /* We are building this library */
#      define OTBMapla_EXPORT_EXPLICIT_TEMPLATE 
#    else
        /* We are using this library */
#      define OTBMapla_EXPORT_EXPLICIT_TEMPLATE 
#  endif
#  ifndef OTBMapla_HIDDEN
#    define OTBMapla_HIDDEN __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OTBMapla_DEPRECATED
#  define OTBMapla_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OTBMapla_DEPRECATED_EXPORT
#  define OTBMapla_DEPRECATED_EXPORT OTBMapla_EXPORT OTBMapla_DEPRECATED
#endif

#ifndef OTBMapla_DEPRECATED_NO_EXPORT
#  define OTBMapla_DEPRECATED_NO_EXPORT OTBMapla_HIDDEN OTBMapla_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OTBMAPLA_NO_DEPRECATED
#    define OTBMAPLA_NO_DEPRECATED
#  endif
#endif

#endif /* OTBMapla_EXPORT_H */
