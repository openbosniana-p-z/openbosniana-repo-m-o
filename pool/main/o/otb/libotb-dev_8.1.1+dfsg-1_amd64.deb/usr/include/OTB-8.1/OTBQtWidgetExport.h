
#ifndef OTBQtWidget_EXPORT_H
#define OTBQtWidget_EXPORT_H

#ifdef OTB_STATIC
#  define OTBQtWidget_EXPORT
#  define OTBQtWidget_HIDDEN
#  define OTBQtWidget_EXPORT_TEMPLATE
#  define OTBQtWidget_EXPORT_EXPLICIT_TEMPLATE
#else
#  ifndef OTBQtWidget_EXPORT
#    ifdef OTBQtWidget_EXPORTS
        /* We are building this library */
#      define OTBQtWidget_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBQtWidget_EXPORT __attribute__((visibility("default")))
#    endif
#  endif
#  ifndef OTBQtWidget_EXPORT_TEMPLATE
        /* We are building this library */
#      define OTBQtWidget_EXPORT_TEMPLATE __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBQtWidget_EXPORT_TEMPLATE __attribute__((visibility("default")))
#  endif
#  ifndef OTBQtWidget_EXPORT_EXPLICIT_TEMPLATE
        /* We are building this library */
#      define OTBQtWidget_EXPORT_EXPLICIT_TEMPLATE 
#    else
        /* We are using this library */
#      define OTBQtWidget_EXPORT_EXPLICIT_TEMPLATE 
#  endif
#  ifndef OTBQtWidget_HIDDEN
#    define OTBQtWidget_HIDDEN __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OTBQtWidget_DEPRECATED
#  define OTBQtWidget_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OTBQtWidget_DEPRECATED_EXPORT
#  define OTBQtWidget_DEPRECATED_EXPORT OTBQtWidget_EXPORT OTBQtWidget_DEPRECATED
#endif

#ifndef OTBQtWidget_DEPRECATED_NO_EXPORT
#  define OTBQtWidget_DEPRECATED_NO_EXPORT OTBQtWidget_HIDDEN OTBQtWidget_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OTBQTWIDGET_NO_DEPRECATED
#    define OTBQTWIDGET_NO_DEPRECATED
#  endif
#endif

#endif /* OTBQtWidget_EXPORT_H */
