More contributed samples of plugins can be found and added in
the "OrthancContributed" repository on GitHub:
https://github.com/jodogne/OrthancContributed/tree/master/Plugins
