More contributed samples and documentation can be found and added in
the "OrthancContributed" repository on GitHub:
https://github.com/jodogne/OrthancContributed

The integration tests of Orthanc provide many samples about the
features of the REST API of Orthanc:
https://hg.orthanc-server.com/orthanc-tests/file/tip/Tests/Tests.py
