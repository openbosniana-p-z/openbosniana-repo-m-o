include Digest

(*
let equal : t -> t -> bool = ( = )
*)

(*
let bytes = string

let subbytes = substring

let compare = compare
*)

(*
let from_hex s =
  if String.length s <> 32 then invalid_arg "Digest.from_hex";
  let digit c =
    match c with
    | '0'..'9' -> Char.code c - Char.code '0'
    | 'A'..'F' -> Char.code c - Char.code 'A' + 10
    | 'a'..'f' -> Char.code c - Char.code 'a' + 10
    | _ -> raise (Invalid_argument "Digest.from_hex")
  in
  let byte i = digit s.[i] lsl 4 + digit s.[i+1] in
  let result = String.create 16 in
  for i = 0 to 15 do
    String.set result i (Char.chr (byte (2 * i)));
  done;
  result
*)
