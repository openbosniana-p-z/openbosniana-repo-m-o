#if 0
#include <caml/alloc.h>

value
caml_alloc_initialized_string(mlsize_t len, const char *p);
#endif
