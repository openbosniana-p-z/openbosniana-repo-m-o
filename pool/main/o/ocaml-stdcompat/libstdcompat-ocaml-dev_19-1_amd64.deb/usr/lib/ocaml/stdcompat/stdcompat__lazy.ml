include Lazy

(*
let from_fun = lazy_from_fun

let from_val = lazy_from_val

let is_val = lazy_is_val
*)

(*
let map f v =
  lazy (f (force v))

let map_val f v =
  if is_val v then
    from_val (f (force v))
  else
    map f v
*)
