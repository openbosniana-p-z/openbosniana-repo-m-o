type bytes = Stdcompat__init.bytes

type floatarray = Stdcompat__init.floatarray
