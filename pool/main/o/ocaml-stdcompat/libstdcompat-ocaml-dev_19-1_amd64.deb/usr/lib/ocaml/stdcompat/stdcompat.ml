include Stdcompat__root

module Stdlib = Stdcompat__stdlib

include Stdcompat__stdlib
