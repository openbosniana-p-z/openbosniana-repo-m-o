
include Unit

(*
type t = unit = ()

let equal () () = true

let compare () () = 0

let to_string () = "()"
*)
