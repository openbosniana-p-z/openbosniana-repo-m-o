
type 'a lazy_t = 'a CamlinternalLazy.t

(*
type 'a lazy_t_ = 'a lazy_t
type 'a lazy_t = 'a lazy_t_
*)

type in_channel_ = in_channel
type in_channel = in_channel_

type out_channel_ = out_channel
type out_channel = out_channel_


type nonrec floatarray = floatarray

type ('a, 'b, 'c, 'd, 'e, 'f) format6 =
    ('a, 'b, 'c, 'd, 'e, 'f) CamlinternalFormatBasics.format6

(*
type floatarray = float array


type ('a, 'b, 'c, 'd, 'e, 'f) format6_ =
    ('a, 'b, 'c, 'd, 'e, 'f) format6
type ('a, 'b, 'c, 'd, 'e, 'f) format6 =
    ('a, 'b, 'c, 'd, 'e, 'f) format6_

(*
type ('a, 'b, 'c, 'd, 'e, 'f) format6 =
    ('a, 'b, 'c, 'f) format4
*)
*)


type nonrec bytes = bytes

(*
type bytes = string
*)

type ('a, 'b) result =

('a, 'b) Stdlib.result =

(*

('a, 'b) Pervasives.result =

(*
(*
('a, 'b) Result.result =
*)
*)
*)
  | Ok of 'a 
  | Error of 'b


type 'a seq = unit -> 'a seq_node
and 'a seq_node = 'a Seq.node =
  | Nil 
  | Cons of 'a * 'a seq

(*
type 'a seq = unit -> 'a seq_node
and 'a seq_node =
(*
  'a Seq.node =
*)
  | Nil
  | Cons of 'a * 'a seq
*)


type ('a, 'b) either = ('a, 'b) Either.t =
  | Left of 'a
  | Right of 'b

(*
type ('a, 'b) either =
  | Left of 'a
  | Right of 'b
*)
