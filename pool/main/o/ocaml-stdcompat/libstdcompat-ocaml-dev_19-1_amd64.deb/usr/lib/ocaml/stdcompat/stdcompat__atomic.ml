
include Atomic

(*
type 'a t = 'a ref

let make = ref

let get = (!)

let set = (:=)

let exchange r new_value =
  let old_value = !r in
  r := new_value;
  old_value

let compare_and_set r seen v =
  if !r = seen then
    begin
      r := v;
      true
    end
  else
    false

let fetch_and_add r n =
  let old_value = !r in
  r := old_value + n;
  old_value

let incr = incr

let decr = decr
*)
