
include Printexc



(*

type raw_backtrace_entry = private int

(*
type raw_backtrace_entry = int
*)

let not_implemented () =
  failwith "Stdcompat: not implemented."

let backtrace_slots_of_raw_entry _ =
  not_implemented ()

let raw_backtrace_entries _ =
  not_implemented ()
*)

(*

type t = exn = ..

(*
type t = exn
*)
*)


type raw_backtrace = Printexc.raw_backtrace

(*
type raw_backtrace = unit
*)


type backtrace_slot = Printexc.backtrace_slot

(*
type backtrace_slot
*)


type location = Printexc.location =
  {
  filename: string ;
  line_number: int ;
  start_char: int ;
  end_char: int }

(*
type location =
  {
  filename: string ;
  line_number: int ;
  start_char: int ;
  end_char: int }
*)

let to_string = Printexc.to_string

(*
let use_printers e =
  Some (to_string e)

let to_string_default e =
  to_string e
*)


module Slot = Printexc.Slot

(*
module Slot = struct

  include Printexc.Slot

(*
  type t = backtrace_slot

  let is_raise = Printexc.Slot.is_raise
  let location = Printexc.Slot.location
  let format = Printexc.Slot.format

(*
  let is_raise _ =
    false

  let location _ =
    None

  let format _ _ =
    None
*)

  let is_inline _ =
    false
*)
  let name _ =
    None
end
*)


type raw_backtrace_slot = Printexc.raw_backtrace_slot

(*
type raw_backtrace_slot
*)


external raise_with_backtrace :
  exn -> raw_backtrace -> 'a = "%raise_with_backtrace"

(*
let raise_with_backtrace exn _ =
  raise exn
*)


let get_raw_backtrace_next_slot = Printexc.get_raw_backtrace_next_slot

(*
let get_raw_backtrace_next_slot _ =
  not_implemented ()
*)


let set_uncaught_exception_handler = Printexc.set_uncaught_exception_handler

let backtrace_slots = Printexc.backtrace_slots

let raw_backtrace_length = Printexc.raw_backtrace_length

let get_raw_backtrace_slot = Printexc.get_raw_backtrace_slot

let convert_raw_backtrace_slot = Printexc.convert_raw_backtrace_slot

let exn_slot_id = Printexc.exn_slot_id

let exn_slot_name = Printexc.exn_slot_name

(*
let set_uncaught_exception_handler _ =
  not_implemented ()

let backtrace_slots _ =
  not_implemented ()

let raw_backtrace_length _ =
  not_implemented ()

let get_raw_backtrace_slot _ =
  not_implemented ()

let convert_raw_backtrace_slot _ =
  not_implemented ()

let exn_slot_id _ =
  not_implemented ()

let exn_slot_name _ =
  not_implemented ()
*)


external get_callstack : int -> raw_backtrace = "caml_get_current_callstack"

(*

let get_callstack = Printexc.get_callstack

(*
let get_callstack _ =
  not_implemented ()
*)
*)


let get_raw_backtrace = Printexc.get_raw_backtrace

let print_raw_backtrace = Printexc.print_raw_backtrace

let raw_backtrace_to_string = Printexc.raw_backtrace_to_string

(*
let get_raw_backtrace _ = ()

let print_raw_backtrace _stderr _raw_backtrace =
  ()

let raw_backtrace_to_string _ =
  not_implemented ()
*)


let print_backtrace = Printexc.print_backtrace

let get_backtrace = Printexc.get_backtrace

let record_backtrace = Printexc.record_backtrace

let backtrace_status = Printexc.backtrace_status

let register_printer = Printexc.register_printer

(*
let print_backtrace _ =
  not_implemented ()

let get_backtrace _ =
  not_implemented ()

let record_backtrace _ =
  not_implemented ()

let backtrace_status _ =
  not_implemented ()

let register_printer _ =
  not_implemented ()
*)

let print = Printexc.print
let catch = Printexc.catch

(*
let default_uncaught_exception_handler exn raw_backtrace =
  Printf.eprintf "Fatal error: exception %s\n" (to_string exn);
  print_raw_backtrace stderr raw_backtrace;
  flush stderr
*)
