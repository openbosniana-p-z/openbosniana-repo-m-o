
module Hashtbl = MoreLabels.Hashtbl

(*
module Hashtbl = Stdcompat__hashtbl
*)


module Map = MoreLabels.Map

(*
module Map = Stdcompat__map
*)


module Set = MoreLabels.Set

(*
module Set = Stdcompat__set
*)
