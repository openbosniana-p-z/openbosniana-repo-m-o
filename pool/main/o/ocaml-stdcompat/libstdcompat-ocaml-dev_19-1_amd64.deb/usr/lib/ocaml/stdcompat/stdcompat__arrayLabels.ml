
include (Stdcompat__array : module type of struct
  include Stdcompat__array
end with module Floatarray := Array.Floatarray)

module Floatarray = ArrayLabels.Floatarray

(*
include Stdcompat__array
*)

