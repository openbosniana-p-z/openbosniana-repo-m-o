module type S = sig

type t = bytes

(*
type t = Stdcompat__init.bytes
*)
(** @since 4.02.0: type t = bytes
 *)

(*
val get_utf_8_uchar : t -> int -> Uchar.utf_decode
*)

val get_utf_8_uchar : t -> int -> Stdcompat__uchar.utf_decode

(** @since 4.14.0: val get_utf_8_uchar : t -> int -> Uchar.utf_decode
 *)

(*
val set_utf_8_uchar : t -> int -> Uchar.t -> int
*)

val set_utf_8_uchar : t -> int -> Stdcompat__uchar.t -> int

(** @since 4.14.0: val set_utf_8_uchar : t -> int -> Uchar.t -> int
 *)

val is_valid_utf_8 : t -> bool
(** @since 4.14.0: val is_valid_utf_8 : t -> bool *)

(*
val get_utf_16be_uchar : t -> int -> Uchar.utf_decode
*)

val get_utf_16be_uchar : t -> int -> Stdcompat__uchar.utf_decode

(** @since 4.14.0: val get_utf_16be_uchar : t -> int -> Uchar.utf_decode
 *)

(*
val set_utf_16be_uchar : t -> int -> Uchar.t -> int
*)

val set_utf_16be_uchar : t -> int -> Stdcompat__uchar.t -> int

(** @since 4.14.0: val set_utf_16be_uchar : t -> int -> Uchar.t -> int
 *)

val is_valid_utf_16be : t -> bool
(** @since 4.14.0: val is_valid_utf_16be : t -> bool *)

(*
val get_utf_16le_uchar : t -> int -> Uchar.utf_decode
*)

val get_utf_16le_uchar : t -> int -> Stdcompat__uchar.utf_decode

(** @since 4.14.0: val get_utf_16le_uchar : t -> int -> Uchar.utf_decode
 *)

(*
val set_utf_16le_uchar : t -> int -> Uchar.t -> int
*)

val set_utf_16le_uchar : t -> int -> Stdcompat__uchar.t -> int

(** @since 4.14.0: val set_utf_16le_uchar : t -> int -> Uchar.t -> int
 *)

val is_valid_utf_16le : t -> bool
(** @since 4.14.0: val is_valid_utf_16le : t -> bool *)


val fold_left : ('a -> char -> 'a) -> 'a -> bytes -> 'a

(*
val fold_left : ('a -> char -> 'a) -> 'a -> Stdcompat__init.bytes -> 'a
*)
(** @since 4.13.0: val fold_left : ('a -> char -> 'a) -> 'a -> bytes -> 'a
 *)


val fold_right : (char -> 'a -> 'a) -> bytes -> 'a -> 'a

(*
val fold_right : (char -> 'a -> 'a) -> Stdcompat__init.bytes -> 'a -> 'a
*)
(** @since 4.13.0: val fold_right : (char -> 'a -> 'a) -> bytes -> 'a -> 'a
 *)


val for_all : (char -> bool) -> bytes -> bool

(*
val for_all : (char -> bool) -> Stdcompat__init.bytes -> bool
*)
(** @since 4.13.0: val for_all : (char -> bool) -> bytes -> bool
 *)


val exists : (char -> bool) -> bytes -> bool

(*
val exists : (char -> bool) -> Stdcompat__init.bytes -> bool
*)
(** @since 4.13.0: val exists : (char -> bool) -> bytes -> bool
 *)


val starts_with : prefix:bytes -> bytes -> bool

(*
val starts_with :
  prefix:Stdcompat__init.bytes -> Stdcompat__init.bytes -> bool
*)
(** @since 4.13.0: val starts_with : prefix:bytes -> bytes -> bool
 *)


val ends_with : suffix:bytes -> bytes -> bool

(*
val ends_with : suffix:Stdcompat__init.bytes -> Stdcompat__init.bytes -> bool
*)
(** @since 4.13.0: val ends_with : suffix:bytes -> bytes -> bool
 *)


val split_on_char : char -> bytes -> bytes list

(*
val split_on_char :
  char -> Stdcompat__init.bytes -> Stdcompat__init.bytes list
*)
(** @since 4.13.0: val split_on_char : char -> bytes -> bytes list
 *)


external unsafe_blit_string :
  string -> int -> bytes -> int -> int -> unit = "caml_blit_string"[@@noalloc
                                                                    ]

(*

external unsafe_blit_string :
  string -> int -> Stdcompat__init.bytes -> int -> int -> unit =
    "caml_blit_string" "noalloc"

(*
external unsafe_blit_string :
  string -> int -> Stdcompat__init.bytes -> int -> int -> unit =
    "blit_string" "noalloc"
*)

*)
(** @since 4.09.0:
    external unsafe_blit_string :
      string -> int -> bytes -> int -> int -> unit = "caml_blit_string"
    [@@noalloc ]
 *)


val get_uint8 : bytes -> int -> int

(*
val get_uint8 : Stdcompat__init.bytes -> int -> int
*)
(** @since 4.08.0: val get_uint8 : bytes -> int -> int
 *)


val get_int8 : bytes -> int -> int

(*
val get_int8 : Stdcompat__init.bytes -> int -> int
*)
(** @since 4.08.0: val get_int8 : bytes -> int -> int
 *)


val get_uint16_ne : bytes -> int -> int

(*
val get_uint16_ne : Stdcompat__init.bytes -> int -> int
*)
(** @since 4.08.0: val get_uint16_ne : bytes -> int -> int
 *)


val get_uint16_be : bytes -> int -> int

(*
val get_uint16_be : Stdcompat__init.bytes -> int -> int
*)
(** @since 4.08.0: val get_uint16_be : bytes -> int -> int
 *)


val get_uint16_le : bytes -> int -> int

(*
val get_uint16_le : Stdcompat__init.bytes -> int -> int
*)
(** @since 4.08.0: val get_uint16_le : bytes -> int -> int
 *)


val get_int16_ne : bytes -> int -> int

(*
val get_int16_ne : Stdcompat__init.bytes -> int -> int
*)
(** @since 4.08.0: val get_int16_ne : bytes -> int -> int
 *)


val get_int16_be : bytes -> int -> int

(*
val get_int16_be : Stdcompat__init.bytes -> int -> int
*)
(** @since 4.08.0: val get_int16_be : bytes -> int -> int
 *)


val get_int16_le : bytes -> int -> int

(*
val get_int16_le : Stdcompat__init.bytes -> int -> int
*)
(** @since 4.08.0: val get_int16_le : bytes -> int -> int
 *)


val get_int32_ne : bytes -> int -> int32

(*
val get_int32_ne : Stdcompat__init.bytes -> int -> int32
*)
(** @since 4.08.0: val get_int32_ne : bytes -> int -> int32
 *)


val get_int32_be : bytes -> int -> int32

(*
val get_int32_be : Stdcompat__init.bytes -> int -> int32
*)
(** @since 4.08.0: val get_int32_be : bytes -> int -> int32
 *)


val get_int32_le : bytes -> int -> int32

(*
val get_int32_le : Stdcompat__init.bytes -> int -> int32
*)
(** @since 4.08.0: val get_int32_le : bytes -> int -> int32
 *)


val get_int64_ne : bytes -> int -> int64

(*
val get_int64_ne : Stdcompat__init.bytes -> int -> int64
*)
(** @since 4.08.0: val get_int64_ne : bytes -> int -> int64
 *)


val get_int64_be : bytes -> int -> int64

(*
val get_int64_be : Stdcompat__init.bytes -> int -> int64
*)
(** @since 4.08.0: val get_int64_be : bytes -> int -> int64
 *)


val get_int64_le : bytes -> int -> int64

(*
val get_int64_le : Stdcompat__init.bytes -> int -> int64
*)
(** @since 4.08.0: val get_int64_le : bytes -> int -> int64
 *)


val set_uint8 : bytes -> int -> int -> unit

(*
val set_uint8 : Stdcompat__init.bytes -> int -> int -> unit
*)
(** @since 4.08.0: val set_uint8 : bytes -> int -> int -> unit
 *)


val set_int8 : bytes -> int -> int -> unit

(*
val set_int8 : Stdcompat__init.bytes -> int -> int -> unit
*)
(** @since 4.08.0: val set_int8 : bytes -> int -> int -> unit
 *)


val set_uint16_ne : bytes -> int -> int -> unit

(*
val set_uint16_ne : Stdcompat__init.bytes -> int -> int -> unit
*)
(** @since 4.08.0: val set_uint16_ne : bytes -> int -> int -> unit
 *)


val set_uint16_be : bytes -> int -> int -> unit

(*
val set_uint16_be : Stdcompat__init.bytes -> int -> int -> unit
*)
(** @since 4.08.0: val set_uint16_be : bytes -> int -> int -> unit
 *)


val set_uint16_le : bytes -> int -> int -> unit

(*
val set_uint16_le : Stdcompat__init.bytes -> int -> int -> unit
*)
(** @since 4.08.0: val set_uint16_le : bytes -> int -> int -> unit
 *)


val set_int16_ne : bytes -> int -> int -> unit

(*
val set_int16_ne : Stdcompat__init.bytes -> int -> int -> unit
*)
(** @since 4.08.0: val set_int16_ne : bytes -> int -> int -> unit
 *)


val set_int16_be : bytes -> int -> int -> unit

(*
val set_int16_be : Stdcompat__init.bytes -> int -> int -> unit
*)
(** @since 4.08.0: val set_int16_be : bytes -> int -> int -> unit
 *)


val set_int16_le : bytes -> int -> int -> unit

(*
val set_int16_le : Stdcompat__init.bytes -> int -> int -> unit
*)
(** @since 4.08.0: val set_int16_le : bytes -> int -> int -> unit
 *)


val set_int32_ne : bytes -> int -> int32 -> unit

(*
val set_int32_ne : Stdcompat__init.bytes -> int -> int32 -> unit
*)
(** @since 4.08.0: val set_int32_ne : bytes -> int -> int32 -> unit
 *)


val set_int32_be : bytes -> int -> int32 -> unit

(*
val set_int32_be : Stdcompat__init.bytes -> int -> int32 -> unit
*)
(** @since 4.08.0: val set_int32_be : bytes -> int -> int32 -> unit
 *)


val set_int32_le : bytes -> int -> int32 -> unit

(*
val set_int32_le : Stdcompat__init.bytes -> int -> int32 -> unit
*)
(** @since 4.08.0: val set_int32_le : bytes -> int -> int32 -> unit
 *)


val set_int64_ne : bytes -> int -> int64 -> unit

(*
val set_int64_ne : Stdcompat__init.bytes -> int -> int64 -> unit
*)
(** @since 4.08.0: val set_int64_ne : bytes -> int -> int64 -> unit
 *)


val set_int64_be : bytes -> int -> int64 -> unit

(*
val set_int64_be : Stdcompat__init.bytes -> int -> int64 -> unit
*)
(** @since 4.08.0: val set_int64_be : bytes -> int -> int64 -> unit
 *)


val set_int64_le : bytes -> int -> int64 -> unit

(*
val set_int64_le : Stdcompat__init.bytes -> int -> int64 -> unit
*)
(** @since 4.08.0: val set_int64_le : bytes -> int -> int64 -> unit
 *)


val to_seq : t -> char Seq.t

(*
val to_seq : t -> char Stdcompat__seq.t
*)
(** @since 4.07.0: val to_seq : t -> char Seq.t
 *)


val to_seqi : t -> (int * char) Seq.t

(*
val to_seqi : t -> (int * char) Stdcompat__seq.t
*)
(** @since 4.07.0: val to_seqi : t -> (int * char) Seq.t
 *)


val of_seq : char Seq.t -> t

(*
val of_seq : char Stdcompat__seq.t -> t
*)
(** @since 4.07.0: val of_seq : char Seq.t -> t
 *)


val index_opt : bytes -> char -> int option

(*
val index_opt : Stdcompat__init.bytes -> char -> int option
*)
(** @since 4.05.0: val index_opt : bytes -> char -> int option
 *)


val rindex_opt : bytes -> char -> int option

(*
val rindex_opt : Stdcompat__init.bytes -> char -> int option
*)
(** @since 4.05.0: val rindex_opt : bytes -> char -> int option
 *)


val index_from_opt : bytes -> int -> char -> int option

(*
val index_from_opt : Stdcompat__init.bytes -> int -> char -> int option
*)
(** @since 4.05.0: val index_from_opt : bytes -> int -> char -> int option
 *)


val rindex_from_opt : bytes -> int -> char -> int option

(*
val rindex_from_opt : Stdcompat__init.bytes -> int -> char -> int option
*)
(** @since 4.05.0: val rindex_from_opt : bytes -> int -> char -> int option
 *)


val uppercase_ascii : bytes -> bytes

(*
val uppercase_ascii : Stdcompat__init.bytes -> Stdcompat__init.bytes
*)
(** @since 4.03.0: val uppercase_ascii : bytes -> bytes
 *)


val lowercase_ascii : bytes -> bytes

(*
val lowercase_ascii : Stdcompat__init.bytes -> Stdcompat__init.bytes
*)
(** @since 4.03.0: val lowercase_ascii : bytes -> bytes
 *)


val capitalize_ascii : bytes -> bytes

(*
val capitalize_ascii : Stdcompat__init.bytes -> Stdcompat__init.bytes
*)
(** @since 4.03.0: val capitalize_ascii : bytes -> bytes
 *)


val uncapitalize_ascii : bytes -> bytes

(*
val uncapitalize_ascii : Stdcompat__init.bytes -> Stdcompat__init.bytes
*)
(** @since 4.03.0: val uncapitalize_ascii : bytes -> bytes
 *)

val equal : t -> t -> bool
(** @since 4.03.0: val equal : t -> t -> bool *)


external length : bytes -> int = "%bytes_length"

(*

external length : bytes -> int = "%string_length"

(*
val length : Stdcompat__init.bytes -> int
*)

*)
(** @since 4.04.0: external length : bytes -> int = "%bytes_length"
@since 4.02.0: external length : bytes -> int = "%string_length"
 *)


external get : bytes -> int -> char = "%bytes_safe_get"

(*

external get : bytes -> int -> char = "%string_safe_get"

(*
val get : Stdcompat__init.bytes -> int -> char
*)

*)
(** @since 4.04.0: external get : bytes -> int -> char = "%bytes_safe_get"
@since 4.02.0: external get : bytes -> int -> char = "%string_safe_get"
 *)


external set : bytes -> int -> char -> unit = "%bytes_safe_set"

(*

external set : bytes -> int -> char -> unit = "%string_safe_set"

(*
val set : Stdcompat__init.bytes -> int -> char -> unit
*)

*)
(** @since 4.04.0:
    external set : bytes -> int -> char -> unit = "%bytes_safe_set"
@since 4.02.0:
external set : bytes -> int -> char -> unit = "%string_safe_set"
 *)


external create : int -> bytes = "caml_create_bytes"

(*

external create : int -> bytes = "caml_create_string"

(*
val create : int -> Stdcompat__init.bytes
*)

*)
(** @since 4.04.0: external create : int -> bytes = "caml_create_bytes"
@since 4.02.0: external create : int -> bytes = "caml_create_string"
 *)


val make : int -> char -> bytes

(*
val make : int -> char -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val make : int -> char -> bytes
 *)


val init : int -> (int -> char) -> bytes

(*
val init : int -> (int -> char) -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val init : int -> (int -> char) -> bytes
 *)


val empty : bytes

(*
val empty : Stdcompat__init.bytes
*)
(** @since 4.02.0: val empty : bytes
 *)


val copy : bytes -> bytes

(*
val copy : Stdcompat__init.bytes -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val copy : bytes -> bytes
 *)


val of_string : string -> bytes

(*
val of_string : string -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val of_string : string -> bytes
 *)


val to_string : bytes -> string

(*
val to_string : Stdcompat__init.bytes -> string
*)
(** @since 4.02.0: val to_string : bytes -> string
 *)


val sub : bytes -> int -> int -> bytes

(*
val sub : Stdcompat__init.bytes -> int -> int -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val sub : bytes -> int -> int -> bytes
 *)


val sub_string : bytes -> int -> int -> string

(*
val sub_string : Stdcompat__init.bytes -> int -> int -> string
*)
(** @since 4.02.0: val sub_string : bytes -> int -> int -> string
 *)


val extend : bytes -> int -> int -> bytes

(*
val extend : Stdcompat__init.bytes -> int -> int -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val extend : bytes -> int -> int -> bytes
 *)


val fill : bytes -> int -> int -> char -> unit

(*
val fill : Stdcompat__init.bytes -> int -> int -> char -> unit
*)
(** @since 4.02.0: val fill : bytes -> int -> int -> char -> unit
 *)


val blit : bytes -> int -> bytes -> int -> int -> unit

(*
val blit :
  Stdcompat__init.bytes -> int -> Stdcompat__init.bytes -> int -> int -> unit
*)
(** @since 4.02.0: val blit : bytes -> int -> bytes -> int -> int -> unit
 *)


val blit_string : string -> int -> bytes -> int -> int -> unit

(*
val blit_string :
  string -> int -> Stdcompat__init.bytes -> int -> int -> unit
*)
(** @since 4.02.0:
    val blit_string : string -> int -> bytes -> int -> int -> unit
 *)


val concat : bytes -> bytes list -> bytes

(*
val concat :
  Stdcompat__init.bytes ->
    Stdcompat__init.bytes list -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val concat : bytes -> bytes list -> bytes
 *)


val cat : bytes -> bytes -> bytes

(*
val cat :
  Stdcompat__init.bytes -> Stdcompat__init.bytes -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val cat : bytes -> bytes -> bytes
 *)


val iter : (char -> unit) -> bytes -> unit

(*
val iter : (char -> unit) -> Stdcompat__init.bytes -> unit
*)
(** @since 4.02.0: val iter : (char -> unit) -> bytes -> unit
 *)


val iteri : (int -> char -> unit) -> bytes -> unit

(*
val iteri : (int -> char -> unit) -> Stdcompat__init.bytes -> unit
*)
(** @since 4.02.0: val iteri : (int -> char -> unit) -> bytes -> unit
 *)


val map : (char -> char) -> bytes -> bytes

(*
val map : (char -> char) -> Stdcompat__init.bytes -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val map : (char -> char) -> bytes -> bytes
 *)


val mapi : (int -> char -> char) -> bytes -> bytes

(*
val mapi :
  (int -> char -> char) -> Stdcompat__init.bytes -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val mapi : (int -> char -> char) -> bytes -> bytes
 *)


val trim : bytes -> bytes

(*
val trim : Stdcompat__init.bytes -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val trim : bytes -> bytes
 *)


val escaped : bytes -> bytes

(*
val escaped : Stdcompat__init.bytes -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val escaped : bytes -> bytes
 *)


val index : bytes -> char -> int

(*
val index : Stdcompat__init.bytes -> char -> int
*)
(** @since 4.02.0: val index : bytes -> char -> int
 *)


val rindex : bytes -> char -> int

(*
val rindex : Stdcompat__init.bytes -> char -> int
*)
(** @since 4.02.0: val rindex : bytes -> char -> int
 *)


val index_from : bytes -> int -> char -> int

(*
val index_from : Stdcompat__init.bytes -> int -> char -> int
*)
(** @since 4.02.0: val index_from : bytes -> int -> char -> int
 *)


val rindex_from : bytes -> int -> char -> int

(*
val rindex_from : Stdcompat__init.bytes -> int -> char -> int
*)
(** @since 4.02.0: val rindex_from : bytes -> int -> char -> int
 *)


val contains : bytes -> char -> bool

(*
val contains : Stdcompat__init.bytes -> char -> bool
*)
(** @since 4.02.0: val contains : bytes -> char -> bool
 *)


val contains_from : bytes -> int -> char -> bool

(*
val contains_from : Stdcompat__init.bytes -> int -> char -> bool
*)
(** @since 4.02.0: val contains_from : bytes -> int -> char -> bool
 *)


val rcontains_from : bytes -> int -> char -> bool

(*
val rcontains_from : Stdcompat__init.bytes -> int -> char -> bool
*)
(** @since 4.02.0: val rcontains_from : bytes -> int -> char -> bool
 *)

val compare : t -> t -> int
(** @since 4.02.0: val compare : t -> t -> int *)


val unsafe_to_string : bytes -> string

(*
val unsafe_to_string : Stdcompat__init.bytes -> string
*)
(** @since 4.02.0: val unsafe_to_string : bytes -> string
 *)


val unsafe_of_string : string -> bytes

(*
val unsafe_of_string : string -> Stdcompat__init.bytes
*)
(** @since 4.02.0: val unsafe_of_string : string -> bytes
 *)


external unsafe_get : bytes -> int -> char = "%bytes_unsafe_get"

(*

external unsafe_get : bytes -> int -> char = "%string_unsafe_get"

(*
val unsafe_get : Stdcompat__init.bytes -> int -> char
*)

*)
(** @since 4.04.0:
    external unsafe_get : bytes -> int -> char = "%bytes_unsafe_get"
@since 4.02.0:
external unsafe_get : bytes -> int -> char = "%string_unsafe_get"
 *)


external unsafe_set : bytes -> int -> char -> unit = "%bytes_unsafe_set"

(*

external unsafe_set : bytes -> int -> char -> unit = "%string_unsafe_set"

(*
val unsafe_set : Stdcompat__init.bytes -> int -> char -> unit
*)

*)
(** @since 4.04.0:
    external unsafe_set : bytes -> int -> char -> unit = "%bytes_unsafe_set"
@since 4.02.0:
external unsafe_set : bytes -> int -> char -> unit = "%string_unsafe_set"
 *)


external unsafe_blit :
  bytes -> int -> bytes -> int -> int -> unit = "caml_blit_bytes"[@@noalloc ]

(*

external unsafe_blit :
  bytes -> int -> bytes -> int -> int -> unit = "caml_blit_string"[@@noalloc
                                                                    ]

(*

external unsafe_blit :
  bytes -> int -> bytes -> int -> int -> unit = "caml_blit_string" "noalloc"

(*
val unsafe_blit :
  Stdcompat__init.bytes -> int -> Stdcompat__init.bytes -> int -> int -> unit
*)

*)

*)
(** @since 4.04.0:
    external unsafe_blit :
      bytes -> int -> bytes -> int -> int -> unit = "caml_blit_bytes"
    [@@noalloc ]
@since 4.03.0:
external unsafe_blit :
  bytes -> int -> bytes -> int -> int -> unit = "caml_blit_string"[@@noalloc
                                                                    ]
@since 4.02.0:
external unsafe_blit :
  bytes -> int -> bytes -> int -> int -> unit = "caml_blit_string" "noalloc"
 *)


external unsafe_fill :
  bytes -> int -> int -> char -> unit = "caml_fill_bytes"[@@noalloc ]

(*

external unsafe_fill :
  bytes -> int -> int -> char -> unit = "caml_fill_string"[@@noalloc ]

(*

external unsafe_fill :
  bytes -> int -> int -> char -> unit = "caml_fill_string" "noalloc"

(*
val unsafe_fill : Stdcompat__init.bytes -> int -> int -> char -> unit
*)

*)

*)
(** @since 4.04.0:
    external unsafe_fill :
      bytes -> int -> int -> char -> unit = "caml_fill_bytes"[@@noalloc ]
@since 4.03.0:
external unsafe_fill :
  bytes -> int -> int -> char -> unit = "caml_fill_string"[@@noalloc ]
@since 4.02.0:
external unsafe_fill :
  bytes -> int -> int -> char -> unit = "caml_fill_string" "noalloc"
 *)

end
