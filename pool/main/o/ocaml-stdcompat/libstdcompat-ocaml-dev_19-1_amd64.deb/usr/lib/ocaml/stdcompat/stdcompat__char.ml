include Char

(*
let lowercase_ascii = Char.lowercase

let uppercase_ascii = Char.uppercase

let equal : t -> t -> bool = ( = )
*)
