include Lexing

(*
let set_position lexbuf position =
  lexbuf.lex_curr_p <-
    { position with pos_fname = lexbuf.lex_curr_p.pos_fname };
  lexbuf.lex_abs_pos <- position.pos_cnum

let set_filename lexbuf filename =
  lexbuf.lex_curr_p <- { lexbuf.lex_curr_p with pos_fname = filename }
*)

(*
let from_channel ?with_positions chan =
  from_channel chan

let from_string ?with_positions s =
  from_string s

let from_function ?with_positions f =
  from_function f

let with_positions _lexbuf =
  true
*)

(*
let new_line lexbuf =
  let lex_curr_p = lexbuf.Lexing.lex_curr_p in
  if lex_curr_p != Lexing.dummy_pos then
    lexbuf.Lexing.lex_curr_p <- { lex_curr_p with
      Lexing.pos_lnum = succ lex_curr_p.Lexing.pos_lnum;
      Lexing.pos_bol = lex_curr_p.Lexing.pos_cnum; }
*)
