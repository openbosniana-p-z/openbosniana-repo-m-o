
include Bool

(*
type t = bool =
  | false 
  | true

let not = not

external (&&) : bool -> bool -> bool = "%sequand"

external (||) : bool -> bool -> bool = "%sequor"

let equal = ( = )

let compare = compare

let to_int b =
  if b then 1
  else 0

let to_float b =
  if b then 1.
  else 0.

let to_string = string_of_bool
*)
