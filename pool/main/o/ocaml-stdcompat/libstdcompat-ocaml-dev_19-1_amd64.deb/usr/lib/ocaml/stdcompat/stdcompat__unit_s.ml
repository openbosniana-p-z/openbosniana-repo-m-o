module type S = sig

type t = unit =
  | () 

(*
type t = unit =
  | () 
*)
(** @since 4.08.0: type t = unit =
                     | () 
 *)

val equal : t -> t -> bool
(** @since 4.08.0: val equal : t -> t -> bool *)

val compare : t -> t -> int
(** @since 4.08.0: val compare : t -> t -> int *)

val to_string : t -> string
(** @since 4.08.0: val to_string : t -> string *)

end
