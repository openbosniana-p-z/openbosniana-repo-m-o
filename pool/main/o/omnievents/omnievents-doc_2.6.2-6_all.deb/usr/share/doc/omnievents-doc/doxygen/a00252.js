var a00252 =
[
    [ "timestamp", "a00252.html#ad1c6463c57485c464f68e0981d1d9280", null ],
    [ "t", "a00252.html#a8ac0b24af4de58fc0a4925fae0c323db", null ],
    [ "str", "a00252.html#a3eb471bd51b81240b94f5fb2060a4e56", null ]
];