var a00074 =
[
    [ "BILLION", "a00074.html#a31f99d9c502b52b5f36dc7e2028c2e80", null ],
    [ "MILLION", "a00074.html#a368e7704f92e34c8ea0a5c263a95a1b1", null ]
];