var a00056 =
[
    [ "CYCLE_PERIOD_NS", "a00056.html#a8c8a573ab84d7bd087053706367816bd", null ],
    [ "MAX_NUM_PROXIES", "a00056.html#ab3623a83e38a375f97d21d1561746e69", null ],
    [ "MAX_QUEUE_LENGTH", "a00056.html#a984a1fb71ddc8e691fb1255072d2ec46", null ],
    [ "OMNIEVENTS_LOG_CHECKPOINT_PERIOD", "a00056.html#a6225229d32093f737a26eec4d193d8a8", null ],
    [ "OMNIEVENTS_LOG_DEFAULT_LOCATION", "a00056.html#adba3d4eadc2e513b88b2899a2af1fca5", null ],
    [ "OMNIEVENTS_LOGDIR_ENV_VAR", "a00056.html#af7ec7e13e8eedf7cc8f84aa0d2744cee", null ],
    [ "PULL_RETRY_PERIOD_MS", "a00056.html#a5c7ef6341fd3f331fd48a20ed87f1c98", null ]
];