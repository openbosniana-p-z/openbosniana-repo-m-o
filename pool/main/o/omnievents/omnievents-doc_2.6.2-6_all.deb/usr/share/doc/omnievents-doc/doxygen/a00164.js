var a00164 =
[
    [ "Time", "a00336.html", "a00336" ],
    [ "Consumer_i", "a00340.html", "a00340" ],
    [ "Supplier_i", "a00344.html", "a00344" ],
    [ "BILLION", "a00164.html#a31f99d9c502b52b5f36dc7e2028c2e80", null ],
    [ "STDIN_FILENO", "a00164.html#afcf80a6d91178952d107ad00b165752b", null ],
    [ "STDOUT_FILENO", "a00164.html#abd165ee6474b5b75bf075842fff13a04", null ],
    [ "main", "a00164.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "usage", "a00164.html#ac8925fe8d8bafbceaae4ed83336d7339", null ],
    [ "orb", "a00164.html#a641a09a07aa31ddd37207650c9f8277d", null ]
];