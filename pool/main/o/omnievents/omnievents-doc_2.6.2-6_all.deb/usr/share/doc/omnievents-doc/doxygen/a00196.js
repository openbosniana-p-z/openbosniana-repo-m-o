var a00196 =
[
    [ "Daemon", "a00196.html#a8b773ae892bbf786a23fa93e56feadc6", null ],
    [ "Daemon", "a00196.html#a1de6b59f046731b4ebaae6f756fb12f0", null ],
    [ "~Daemon", "a00196.html#ae9d1193288f7505e5ddd0b70de0683e3", null ],
    [ "daemonize", "a00196.html#ae54d940afbac0e64c7b4dc6a5c00c40b", null ],
    [ "foreground", "a00196.html#a9b3c69f1f43ae8ea284f2437dd8236ee", null ],
    [ "pidfile", "a00196.html#a33f2ed1687e36cc42f62528f42a232f0", null ],
    [ "runningOk", "a00196.html#ab450e54210a7992b07ae4d6b6fe4ea29", null ],
    [ "tracefile", "a00196.html#ab56e5557da13906f02dc67b27949367f", null ]
];