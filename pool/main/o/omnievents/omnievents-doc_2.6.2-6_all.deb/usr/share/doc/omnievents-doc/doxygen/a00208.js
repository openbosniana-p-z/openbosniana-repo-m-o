var a00208 =
[
    [ "RegistryKey", "a00208.html#a8401cbd5315fb6c76e34b15eab710cd8", null ],
    [ "RegistryKey", "a00208.html#ab6694d548073c5878a7dd2ed685ff60c", null ],
    [ "RegistryKey", "a00208.html#ab7db608a552706751476e0b5054005b4", null ],
    [ "RegistryKey", "a00208.html#ae72bef353b8b81589b6bacd6b61852b7", null ],
    [ "~RegistryKey", "a00208.html#a2c628f612bff9a6e680af8ba2184b731", null ],
    [ "operator bool", "a00208.html#a12dbdc4fddebc1bd4d9d6b2e608064aa", null ],
    [ "queryValueStr", "a00208.html#a59ab9853afb62cec78608989e5bd1446", null ],
    [ "setValueStr", "a00208.html#ad0073ea39a0d9290d6f1981fa775b509", null ],
    [ "_hkey", "a00208.html#a09fa7f486fff12db955c19b373f96a16", null ],
    [ "_open", "a00208.html#a86795afd6b28f44f94166d3aae083f1c", null ]
];