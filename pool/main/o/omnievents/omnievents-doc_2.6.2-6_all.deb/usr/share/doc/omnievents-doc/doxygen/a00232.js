var a00232 =
[
    [ "Reader", "a00232.html#ae929e138df4914014ef087ae80f09d16", null ],
    [ "moreEvents", "a00232.html#aa9c1918176e887527ccdbc472e2217a4", null ],
    [ "nextEvent", "a00232.html#a3d3a79dad7c34568bceef8f6fc38c631", null ],
    [ "_eventQueue", "a00232.html#a6dddcb7f40896848c11b48376ffdeb63", null ],
    [ "_next", "a00232.html#a9327b1c8d6ff691627375732ebb47c10", null ]
];