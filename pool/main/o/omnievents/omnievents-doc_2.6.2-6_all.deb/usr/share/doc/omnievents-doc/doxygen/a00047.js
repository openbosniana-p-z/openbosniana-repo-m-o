var a00047 =
[
    [ "getopt", "a00047.html#ae48aecef4b30566038b822712033071f", null ],
    [ "optarg", "a00047.html#adb50a0eab9fed92fc3bfc7dfa4f2c410", null ],
    [ "opterr", "a00047.html#ae30f05ee1e2e5652f174a35c7875d25e", null ],
    [ "optind", "a00047.html#ad5e1c16213bbee2d5e8cc363309f418c", null ]
];