var hierarchy =
[
    [ "POA_CosEventChannelAdmin::ConsumerAdmin", null, [
      [ "OmniEvents::ConsumerAdmin_i", "a00192.html", null ]
    ] ],
    [ "OmniEvents::Daemon", "a00196.html", null ],
    [ "OmniEvents::DaemonImpl", "a00200.html", null ],
    [ "POA_omniEvents::EventChannel", null, [
      [ "OmniEvents::EventChannel_i", "a00216.html", null ]
    ] ],
    [ "POA_omniEvents::EventChannelFactory", null, [
      [ "OmniEvents::EventChannelFactory_i", "a00224.html", null ]
    ] ],
    [ "OmniEvents::EventChannelStore", "a00220.html", null ],
    [ "OmniEvents::EventQueue", "a00228.html", null ],
    [ "OmniEvents::Filter", "a00236.html", [
      [ "OmniEvents::FilterByRepositoryId", "a00244.html", null ],
      [ "OmniEvents::FilterByTCKind", "a00240.html", null ]
    ] ],
    [ "OmniEvents::omniEventsLog::IOError", "a00260.html", null ],
    [ "OmniEvents::omni_mutex_kcol", "a00312.html", null ],
    [ "omni_thread", null, [
      [ "OmniEvents::EventChannel_i", "a00216.html", null ],
      [ "OmniEvents::ProxyPushSupplierManager", "a00316.html", null ],
      [ "OmniEvents::omniEventsLogWorker", "a00264.html", null ]
    ] ],
    [ "OmniEvents::omniEventsLog", "a00256.html", null ],
    [ "OmniEvents::Orb", "a00272.html", null ],
    [ "OmniEvents::ProxyPushSupplierManager::PauseThenWake", "a00320.html", null ],
    [ "OmniEvents::PersistNode", "a00276.html", null ],
    [ "POA_CosEventChannelAdmin::ProxyPullConsumer", null, [
      [ "OmniEvents::ProxyPullConsumer_i", "a00292.html", null ]
    ] ],
    [ "POA_CosEventChannelAdmin::ProxyPullSupplier", null, [
      [ "OmniEvents::ProxyPullSupplier_i", "a00300.html", null ]
    ] ],
    [ "POA_CosEventChannelAdmin::ProxyPushConsumer", null, [
      [ "OmniEvents::ProxyPushConsumer_i", "a00304.html", null ]
    ] ],
    [ "POA_CosEventChannelAdmin::ProxyPushSupplier", null, [
      [ "OmniEvents::ProxyPushSupplier_i", "a00324.html", null ]
    ] ],
    [ "POA_CosEventComm::PullConsumer", null, [
      [ "Consumer_i", "a00340.html", null ]
    ] ],
    [ "POA_CosEventComm::PullSupplier", null, [
      [ "Supplier_i", "a00344.html", null ]
    ] ],
    [ "POA_CosEventComm::PushConsumer", null, [
      [ "Consumer_i", "a00340.html", null ],
      [ "Consumer_i", "a00340.html", null ]
    ] ],
    [ "POA_CosEventComm::PushSupplier", null, [
      [ "Supplier_i", "a00344.html", null ],
      [ "Supplier_i", "a00344.html", null ]
    ] ],
    [ "OmniEvents::EventQueue::Reader", "a00232.html", [
      [ "OmniEvents::ProxyPullSupplier_i", "a00300.html", null ],
      [ "OmniEvents::ProxyPushSupplier_i", "a00324.html", null ]
    ] ],
    [ "PortableServer::RefCountServantBase", null, [
      [ "OmniEvents::Callback", "a00188.html", [
        [ "OmniEvents::ProxyPushConsumer_i::Connection", "a00308.html", null ],
        [ "OmniEvents::ProxyPushSupplier_i", "a00324.html", null ]
      ] ],
      [ "OmniEvents::ConsumerAdmin_i", "a00192.html", null ],
      [ "OmniEvents::EventChannelFactory_i", "a00224.html", null ],
      [ "OmniEvents::Mapper", "a00248.html", null ],
      [ "OmniEvents::ProxyPullConsumerManager", "a00288.html", null ],
      [ "OmniEvents::ProxyPullSupplierManager", "a00296.html", null ],
      [ "OmniEvents::SupplierAdmin_i", "a00332.html", null ]
    ] ],
    [ "OmniEvents::RegistryKey", "a00208.html", null ],
    [ "POA_PortableServer::ServantActivator", null, [
      [ "OmniEvents::ProxyManager", "a00280.html", [
        [ "OmniEvents::ProxyPullConsumerManager", "a00288.html", null ],
        [ "OmniEvents::ProxyPullSupplierManager", "a00296.html", null ],
        [ "OmniEvents::ProxyPushSupplierManager", "a00316.html", null ]
      ] ]
    ] ],
    [ "PortableServer::ServantBase", null, [
      [ "OmniEvents::Callback", "a00188.html", null ],
      [ "OmniEvents::Proxy", "a00284.html", [
        [ "OmniEvents::ProxyPullConsumer_i", "a00292.html", null ],
        [ "OmniEvents::ProxyPullSupplier_i", "a00300.html", null ],
        [ "OmniEvents::ProxyPushSupplier_i", "a00324.html", null ]
      ] ],
      [ "OmniEvents::Servant", "a00328.html", [
        [ "OmniEvents::ConsumerAdmin_i", "a00192.html", null ],
        [ "OmniEvents::EventChannelFactory_i", "a00224.html", null ],
        [ "OmniEvents::EventChannel_i", "a00216.html", null ],
        [ "OmniEvents::Mapper", "a00248.html", null ],
        [ "OmniEvents::Proxy", "a00284.html", null ],
        [ "OmniEvents::ProxyManager", "a00280.html", null ],
        [ "OmniEvents::ProxyPushConsumer_i", "a00304.html", null ],
        [ "OmniEvents::SupplierAdmin_i", "a00332.html", null ]
      ] ]
    ] ],
    [ "OmniEvents::Service", "a00212.html", null ],
    [ "POA_CosEventChannelAdmin::SupplierAdmin", null, [
      [ "OmniEvents::SupplierAdmin_i", "a00332.html", null ]
    ] ],
    [ "Time", "a00336.html", null ],
    [ "OmniEvents::timestamp", "a00252.html", null ],
    [ "OmniEvents::Win", "a00204.html", null ],
    [ "OmniEvents::WriteLock", "a00268.html", null ]
];