var a00272 =
[
    [ "RequestCallback_t", "a00272.html#a1aa992484090fc99254344ae611fbe57", null ],
    [ "Orb", "a00272.html#ae217d754e69f3aa08a613fef1b1caa1e", null ],
    [ "~Orb", "a00272.html#a26bfb206d3bd0d1ab30836cebeb2a8ed", null ],
    [ "cancelCallback", "a00272.html#a2f89238f04608c9663413387a816db53", null ],
    [ "deferredRequest", "a00272.html#a74135de016716ae2df7471526296a13c", null ],
    [ "inst", "a00272.html#ad54350fad61bd6fd480c801b1354239a", null ],
    [ "reportObjectFailure", "a00272.html#a8de4ce996344d71bc502f7f39e7e92e6", null ],
    [ "resolveInitialReferences", "a00272.html#a95a9f34469f4c15665c8bdf9d6bfa0a7", null ],
    [ "run", "a00272.html#afac4f5c207b3acb1d47dbd067dc6960d", null ],
    [ "shutdown", "a00272.html#a4e1a28e63a80f3ddbf23581ef35f72cd", null ],
    [ "OmniEvents_Orb_shutdown", "a00272.html#a611492b97d203b8c65c868dfe9602312", null ],
    [ "_deferredRequests", "a00272.html#a2c02c69d8a06725a9aeaf373779c8d61", null ],
    [ "_deferredRequestsLock", "a00272.html#aed0b7bbe8053a53e097ed3377ec48765", null ],
    [ "_inst", "a00272.html#a3317c37f11008cb9d2946fc1bb783707", null ],
    [ "_NameService", "a00272.html#a6bb90d23b08ba5ffce110c59a5464788", null ],
    [ "_omniINSPOA", "a00272.html#afeef535e3db3b62bd76ae7ea95365f13", null ],
    [ "_orb", "a00272.html#a2ecb511abdcc6fb9e133c61bbc034eb5", null ],
    [ "_RootPOA", "a00272.html#a013bf72cdcbdd2e8241409d8a76dd590", null ],
    [ "_shutdownRequested", "a00272.html#a3baff0a9df066b32ff9466da63ef8859", null ]
];