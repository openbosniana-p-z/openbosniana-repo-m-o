var a00240 =
[
    [ "FilterByTCKind", "a00240.html#ada6cbf57afb4bd616c9719d28de7f044", null ],
    [ "~FilterByTCKind", "a00240.html#ab379554c1ced7f0832fff6547fc36a76", null ],
    [ "keep", "a00240.html#a7308c3b4941d00f1365508b730bc4371", null ],
    [ "output", "a00240.html#ae87162f4104712860a88c69f95683dc7", null ],
    [ "_kind", "a00240.html#a968e30e755e98e9c074cac58dd001c67", null ]
];