var a00080 =
[
    [ "OmniEvents::ProxyPushSupplierManager", "a00316.html", "a00316" ],
    [ "OmniEvents::ProxyPushSupplierManager::PauseThenWake", "a00320.html", "a00320" ],
    [ "OmniEvents::ProxyPushSupplier_i", "a00324.html", "a00324" ]
];