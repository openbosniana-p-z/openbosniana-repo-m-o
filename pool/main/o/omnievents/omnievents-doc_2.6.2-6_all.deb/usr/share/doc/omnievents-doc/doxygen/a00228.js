var a00228 =
[
    [ "Reader", "a00232.html", "a00232" ],
    [ "EventQueue", "a00228.html#a88a1765b944e6e4fac95a201c19d44e3", null ],
    [ "~EventQueue", "a00228.html#ae6d5bdc0ffb99e76ebecade35cdda927", null ],
    [ "append", "a00228.html#adfa3576347e53dc6a2944319e7f17596", null ],
    [ "setFilter", "a00228.html#a43e1c4a6d1ab3a4646759afced77e95c", null ],
    [ "Reader", "a00228.html#a35cb182752752c74a30050705acc3c06", null ],
    [ "_filter", "a00228.html#a0c41fca6a9014d707473b756143b6357", null ],
    [ "_next", "a00228.html#a7935852d7d75f61a9cfac484388300c4", null ],
    [ "_queue", "a00228.html#ac16258e1b4cecb9605a1cdb26662f00f", null ],
    [ "_size", "a00228.html#a782a19b8255a05c924e0efcf7c4ba73a", null ]
];