var namespaces_dup =
[
    [ "OmniEvents", "a00182.html", "a00182" ],
    [ "omniORB", "a00183.html", [
      [ "setLogFunction", "a00183.html#a459587f508ff691528c813dc3cf6333c", null ]
    ] ]
];