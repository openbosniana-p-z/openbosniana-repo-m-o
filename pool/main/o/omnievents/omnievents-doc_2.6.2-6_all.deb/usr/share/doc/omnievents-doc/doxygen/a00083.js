var a00083 =
[
    [ "OmniEvents::omni_mutex_kcol", "a00312.html", "a00312" ]
];