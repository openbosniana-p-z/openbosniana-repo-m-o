var a00312 =
[
    [ "omni_mutex_kcol", "a00312.html#a50f5d7c8c0b4a71cab233e8e1eed9732", null ],
    [ "~omni_mutex_kcol", "a00312.html#aa5e99252d76fbd474613bf7684eaa8a6", null ],
    [ "omni_mutex_kcol", "a00312.html#af9dea145ffaf1bb1179a308bdf9cb009", null ],
    [ "operator=", "a00312.html#a050e6975215aa5a67a9405e6109fac1e", null ],
    [ "mutex", "a00312.html#aa1fd80dc5660754da535bc868d176dd3", null ]
];