var a00008 =
[
    [ "NEED_PACKAGE_INFO", "a00008.html#ae207686a562ec87e68be7ecee803cc16", null ],
    [ "PIPE_READ", "a00008.html#a4d3fd39039e53cbef1db585ad1099a22", null ],
    [ "PIPE_WRITE", "a00008.html#a9c4636b2eca0b9f6c873269df40f3dda", null ],
    [ "STRERR_FILE_LINE", "a00008.html#a0d10093d072314b8bbb3195c6fbecfd9", null ],
    [ "setLogFunction", "a00008.html#a459587f508ff691528c813dc3cf6333c", null ],
    [ "shutdown0", "a00008.html#ae759785ed620f018824ab5ca54c4323a", null ],
    [ "shutdown2", "a00008.html#ad86965d744c0820dd0a1173e2cb54a63", null ],
    [ "daemon", "a00008.html#a69d6b61a3ecd44c94cc5a43b11122be0", null ]
];