var a00011 =
[
    [ "OMNIEVENTS__ADDR", "a00011.html#abb3de69693fb2d4147f702f7f495d129", null ],
    [ "createReference", "a00011.html#a2cbd8159b74c2c5bc57be973fdaead95", null ],
    [ "newUniqueId", "a00011.html#a56af9283cb050aa4436be8172d05ad0e", null ]
];