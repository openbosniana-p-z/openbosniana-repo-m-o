var a00128 =
[
    [ "OmniEvents::EventQueue", "a00228.html", "a00228" ],
    [ "OmniEvents::EventQueue::Reader", "a00232.html", "a00232" ]
];