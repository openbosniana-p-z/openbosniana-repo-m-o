var a00077 =
[
    [ "OmniEvents::Servant", "a00328.html", "a00328" ],
    [ "OMNIEVENTS__DEBUG_REF_COUNTS", "a00077.html#a8aa9d05ec55fbd77b0512ce7dd589955", null ],
    [ "OMNIEVENTS__DEBUG_REF_COUNTS__DECL", "a00077.html#a1d4d194a45335338dade8d3efba7d45f", null ],
    [ "OMNIEVENTS__DEBUG_REF_COUNTS__DEFN", "a00077.html#a8136c441e9ba6e3534769d744ff2f9fd", null ],
    [ "OMNIEVENTS__DEBUG_SERVANT", "a00077.html#a5a3c478c535c6fc3ce87842b8169f8bd", null ],
    [ "createNarrowedReference", "a00077.html#a4e75c8b01dba5b9c51f97ddd88d228bf", null ],
    [ "createReference", "a00077.html#a2cbd8159b74c2c5bc57be973fdaead95", null ],
    [ "newUniqueId", "a00077.html#a56af9283cb050aa4436be8172d05ad0e", null ]
];