var a00062 =
[
    [ "OmniEvents::Win", "a00204.html", "a00204" ],
    [ "OmniEvents::RegistryKey", "a00208.html", "a00208" ],
    [ "AS_STR_1", "a00062.html#a1e8942465f0b5cf1ddfc461086ea94a1", null ],
    [ "AS_STR_2", "a00062.html#adb0259a0f348cdf667bda93f0b2e9299", null ],
    [ "HERE", "a00062.html#a3fe03e23176f4fe277d1d3b41f3d3d06", null ],
    [ "NEED_PACKAGE_INFO", "a00062.html#ae207686a562ec87e68be7ecee803cc16", null ],
    [ "setLogFunction", "a00062.html#a459587f508ff691528c813dc3cf6333c", null ],
    [ "shutdown0", "a00062.html#ae759785ed620f018824ab5ca54c4323a", null ],
    [ "service", "a00062.html#a4805a1f9ccd20c402515138fe9cb228f", null ]
];