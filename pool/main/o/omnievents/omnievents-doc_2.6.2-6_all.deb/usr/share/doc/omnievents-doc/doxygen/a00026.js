var a00026 =
[
    [ "OmniEvents::omniEventsLog", "a00256.html", "a00256" ],
    [ "OmniEvents::omniEventsLog::IOError", "a00260.html", null ],
    [ "OmniEvents::omniEventsLogWorker", "a00264.html", "a00264" ],
    [ "OmniEvents::WriteLock", "a00268.html", "a00268" ],
    [ "OMNIEVENTS_LOGDIR_ENV_VAR", "a00026.html#af7ec7e13e8eedf7cc8f84aa0d2744cee", null ]
];