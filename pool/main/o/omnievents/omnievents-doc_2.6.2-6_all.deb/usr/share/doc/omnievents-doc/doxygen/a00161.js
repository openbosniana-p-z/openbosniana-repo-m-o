var a00161 =
[
    [ "appendCriterion", "a00161.html#a0fef36fff148400dfee004e8941c9bd6", null ],
    [ "appendCriterionStr", "a00161.html#a713918deae5c70ca49658dc6e9b3c90c", null ],
    [ "main", "a00161.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "usage", "a00161.html#ac8925fe8d8bafbceaae4ed83336d7339", null ]
];