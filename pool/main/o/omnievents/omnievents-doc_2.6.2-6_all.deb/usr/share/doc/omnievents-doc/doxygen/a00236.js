var a00236 =
[
    [ "Filter", "a00236.html#a1b6ee6aa0c0b5ca16df9918bad695215", null ],
    [ "~Filter", "a00236.html#a94e1a5d7da44903335192af9400f1b6e", null ],
    [ "keep", "a00236.html#aad0fc6675a1b45d14b29c1fe040fdb88", null ],
    [ "output", "a00236.html#aebe1101aa893ff2141661d7b2586a8f3", null ]
];