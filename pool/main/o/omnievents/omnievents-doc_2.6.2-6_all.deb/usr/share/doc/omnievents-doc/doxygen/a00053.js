var a00053 =
[
    [ "MAXHOSTNAMELEN", "a00053.html#afd80ecbe3170ca4fc85b65cda8659f82", null ],
    [ "gethostname", "a00053.html#a9ecf8fd1a2c0bd5216173745d5d42422", null ]
];