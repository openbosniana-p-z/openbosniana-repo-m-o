var a00020 =
[
    [ "NEED_PACKAGE_INFO", "a00020.html#ae207686a562ec87e68be7ecee803cc16", null ],
    [ "version", "a00020.html#a883c40a597fd579c6f9fe999a196d082", null ]
];