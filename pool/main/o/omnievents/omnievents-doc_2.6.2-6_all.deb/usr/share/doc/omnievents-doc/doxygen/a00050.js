var a00050 =
[
    [ "getopt", "a00050.html#ae48aecef4b30566038b822712033071f", null ],
    [ "letP", "a00050.html#add874c564d5a8099913a4c7f1425f91b", null ],
    [ "optarg", "a00050.html#adb50a0eab9fed92fc3bfc7dfa4f2c410", null ],
    [ "opterr", "a00050.html#ae30f05ee1e2e5652f174a35c7875d25e", null ],
    [ "optind", "a00050.html#ad5e1c16213bbee2d5e8cc363309f418c", null ],
    [ "SW", "a00050.html#a9363957c8bd4b81de1b36f960c340dbc", null ]
];