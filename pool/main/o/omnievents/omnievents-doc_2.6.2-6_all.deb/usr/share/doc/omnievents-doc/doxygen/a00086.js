var a00086 =
[
    [ "OmniEvents::ProxyPushConsumer_i", "a00304.html", "a00304" ],
    [ "OmniEvents::ProxyPushConsumer_i::Connection", "a00308.html", "a00308" ]
];