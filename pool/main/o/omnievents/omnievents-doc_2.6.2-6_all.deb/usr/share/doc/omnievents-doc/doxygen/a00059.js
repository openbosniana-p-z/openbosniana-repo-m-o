var a00059 =
[
    [ "OmniEvents::Service", "a00212.html", "a00212" ]
];