var a00134 =
[
    [ "OmniEvents::EventChannelFactory_i", "a00224.html", "a00224" ]
];