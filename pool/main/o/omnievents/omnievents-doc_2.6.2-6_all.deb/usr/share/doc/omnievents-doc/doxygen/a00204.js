var a00204 =
[
    [ "perror", "a00204.html#a8a73652af3abb40147407f35523aabb1", null ],
    [ "strerror", "a00204.html#a9ce72c360725360ce9ee227832c61ec4", null ]
];