from PyQt5.QtCore import Qt

FLAGS_NO_ICON = Qt.Dialog | Qt.CustomizeWindowHint | Qt.WindowTitleHint | Qt.WindowCloseButtonHint
