"""Conains constants needed for motor calculations."""

# R, in units of J/(kmol*K)
gasConstant = 8314.462618