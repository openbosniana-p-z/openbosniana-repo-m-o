import sys
from .app import App
from PyQt5.QtCore import Qt

app = App(sys.argv)
sys.exit(app.exec())

