The multimedia library
======================

ocaml-mm is a library dedicated to performing operations on multimedia contents:
audio, video and MIDI. The core is designed as a pure OCaml library (no
dependencies are required). Some extensions requiring bindings to various
libraries are located in the [external](external) directory.
