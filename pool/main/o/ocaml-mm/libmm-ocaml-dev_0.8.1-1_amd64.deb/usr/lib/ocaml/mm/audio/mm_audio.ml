(** @canonical Mm_audio.Audio *)
module Audio = Mm_audio__Audio
