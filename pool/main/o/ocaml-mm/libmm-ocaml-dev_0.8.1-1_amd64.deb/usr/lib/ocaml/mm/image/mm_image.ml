(** @canonical Mm_image.Image *)
module Image = Mm_image__Image


(** @canonical Mm_image.ImageBGRA *)
module ImageBGRA = Mm_image__ImageBGRA


(** @canonical Mm_image.ImageBase *)
module ImageBase = Mm_image__ImageBase


(** @canonical Mm_image.ImageBitmap *)
module ImageBitmap = Mm_image__ImageBitmap


(** @canonical Mm_image.ImageCanvas *)
module ImageCanvas = Mm_image__ImageCanvas


(** @canonical Mm_image.ImageGeneric *)
module ImageGeneric = Mm_image__ImageGeneric


(** @canonical Mm_image.ImageRGBA32 *)
module ImageRGBA32 = Mm_image__ImageRGBA32


(** @canonical Mm_image.ImageYUV420 *)
module ImageYUV420 = Mm_image__ImageYUV420
