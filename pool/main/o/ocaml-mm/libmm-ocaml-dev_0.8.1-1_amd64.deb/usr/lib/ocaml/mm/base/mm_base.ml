(** @canonical Mm_base.IO *)
module IO = Mm_base__IO


(** @canonical Mm_base.Ringbuffer *)
module Ringbuffer = Mm_base__Ringbuffer
