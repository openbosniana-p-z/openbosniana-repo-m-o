(** @canonical Mm_midi.MIDI *)
module MIDI = Mm_midi__MIDI


(** @canonical Mm_midi.Synth *)
module Synth = Mm_midi__Synth
