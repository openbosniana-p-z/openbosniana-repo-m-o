(** @canonical Mm_video.Video *)
module Video = Mm_video__Video
