Features
--------

- defcustom to roll each monster's initiative separately (as in 3e),
  rather than having type of monster act at the same time (as in 5e)
