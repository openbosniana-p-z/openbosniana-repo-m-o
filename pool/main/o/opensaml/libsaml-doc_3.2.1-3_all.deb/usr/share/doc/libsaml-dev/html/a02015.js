var a02015 =
[
    [ "declareNonVisibleNamespaces", "a02015.html#aee44f33e71bce86c0bf7c92adb02ff80", null ],
    [ "getSignature", "a02015.html#a5eb531102debbf6a97a64fec0ed794ac", null ],
    [ "setSignature", "a02015.html#a422facef2b414637e9f4448f724f8381", null ]
];