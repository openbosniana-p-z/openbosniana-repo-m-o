var a01983 =
[
    [ "Criteria", "a01987.html", "a01987" ],
    [ "MetadataProvider", "a01983.html#a4c90948561c1fb1e4a9d88f1072f0ba1", null ],
    [ "~MetadataProvider", "a01983.html#aa420e88393390847885576b5d8157faa", null ],
    [ "addMetadataFilter", "a01983.html#a232cddca76b68d7e6b72841171e2a2af", null ],
    [ "doFilters", "a01983.html#aeac356e698d713078235e404091393fe", null ],
    [ "getEntitiesDescriptor", "a01983.html#a7adb10a09368ba3aa0cb930ab6d85ec2", null ],
    [ "getEntitiesDescriptor", "a01983.html#aa300869ec32065a6b881338f39a50d0f", null ],
    [ "getEntityDescriptor", "a01983.html#a60da28b378bb650f08f26f5792723bcb", null ],
    [ "getId", "a01983.html#a158605adc1864d190a2c70628fd1bb58", null ],
    [ "getMetadata", "a01983.html#ace73fb05d63ad1261d7ad157bd95a1da", null ],
    [ "init", "a01983.html#a761aef228223cc70f6e4e96b07faebdb", null ],
    [ "outputStatus", "a01983.html#a86e272cb4f47043e41f78f28d23aab19", null ],
    [ "removeMetadataFilter", "a01983.html#a8829bcc1835b2a1bf2c158c90c26eddd", null ],
    [ "setContext", "a01983.html#a46070e7111047039e3df52765e56058c", null ]
];