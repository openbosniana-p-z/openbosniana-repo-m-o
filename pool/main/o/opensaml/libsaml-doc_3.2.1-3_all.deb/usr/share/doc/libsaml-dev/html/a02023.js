var a02023 =
[
    [ "CommonDomainCookie", "a02023.html#a135af27e35b9aad96aa28b7ecc77fec0", null ],
    [ "get", "a02023.html#a539e97bb39830ceb8f994bc4976d0757", null ],
    [ "set", "a02023.html#aaab4576e3556e8de1430451cf6adf7ff", null ],
    [ "CDCName", "a02023.html#aad414706ad5ccc8873cec1bb58d4b365", null ]
];