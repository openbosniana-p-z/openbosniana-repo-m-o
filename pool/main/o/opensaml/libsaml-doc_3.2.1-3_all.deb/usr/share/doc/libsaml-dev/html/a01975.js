var a01975 =
[
    [ "doFilter", "a01975.html#ae314b1699b85a452b823d079acd022ad", null ],
    [ "getId", "a01975.html#a0b4b8c4fcd7ae07063ee16f6c05a104b", null ]
];