var a01895 =
[
    [ "getMessage", "a01895.html#a6ff9d222c3de41827f76535ffae861a7", null ],
    [ "getSubStatus", "a01895.html#a3402fd06998b1de5c0e70762be929e53", null ],
    [ "getTopStatus", "a01895.html#afe0c5b88463386185bfff157cb130cde", null ],
    [ "hasAdditionalStatus", "a01895.html#a37ea4cdd11ecdab4857c2434182dfe50", null ]
];