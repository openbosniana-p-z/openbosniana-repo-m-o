var a01995 =
[
    [ "Observer", "a01999.html", "a01999" ],
    [ "ObservableMetadataProvider", "a01995.html#a9edc77e0625aeed1c45614862e48a429", null ],
    [ "addObserver", "a01995.html#a2a742bf321bbf039303d4020ee2ebefa", null ],
    [ "emitChangeEvent", "a01995.html#ae6cea4929838ab82f50df26e07c25841", null ],
    [ "emitChangeEvent", "a01995.html#a9e05ef17cf593d576623df5c5d4454c9", null ],
    [ "removeObserver", "a01995.html#a02d37767c0623c27695f62e4ae1a275e", null ]
];