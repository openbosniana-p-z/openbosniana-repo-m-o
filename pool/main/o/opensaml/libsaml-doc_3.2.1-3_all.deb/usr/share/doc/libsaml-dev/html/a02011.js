var a02011 =
[
    [ "ContentReference", "a02011.html#a2e708d640ab4ea12f6e6abae40d78e5c", null ],
    [ "addInclusivePrefix", "a02011.html#a6f41baf15c4449c3fc3976b7425e4ee7", null ],
    [ "createReferences", "a02011.html#a9f7946e4c8a16b7a1dcfe74a7bf1bc3b", null ],
    [ "setCanonicalizationMethod", "a02011.html#aafc0ae5c17319be9df04a3bdf7fa4eed", null ],
    [ "setDigestAlgorithm", "a02011.html#a740760f163fc88b3a867e2bd53ca7645", null ]
];