var a01899 =
[
    [ "extractMessageDetails", "a01899.html#aaa601d41009e69043ad8a90910073fdf", null ],
    [ "getProtocolFamily", "a01899.html#a3abd2831a4390659265caa20f67a0818", null ]
];