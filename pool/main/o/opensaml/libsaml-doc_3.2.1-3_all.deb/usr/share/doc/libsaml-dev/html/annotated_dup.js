var annotated_dup =
[
    [ "opensaml", "a00995.html", [
      [ "saml1p", null, [
        [ "SAML1MessageDecoder", "a01899.html", "a01899" ],
        [ "SAML1SOAPClient", "a01903.html", "a01903" ],
        [ "SAMLArtifactType0001", "a01907.html", "a01907" ],
        [ "SAMLArtifactType0002", "a01911.html", "a01911" ]
      ] ],
      [ "saml2", null, [
        [ "SAML2AssertionPolicy", "a02003.html", "a02003" ]
      ] ],
      [ "saml2md", null, [
        [ "AbstractDynamicMetadataProvider", "a01935.html", "a01935" ],
        [ "AbstractMetadataProvider", "a01939.html", "a01939" ],
        [ "BatchLoadMetadataFilterContext", "a01971.html", "a01971" ],
        [ "DiscoverableMetadataProvider", "a01943.html", "a01943" ],
        [ "EndpointManager", "a01947.html", "a01947" ],
        [ "EntityMatcher", "a01955.html", "a01955" ],
        [ "IndexedEndpointManager", "a01951.html", "a01951" ],
        [ "MetadataCredentialContext", "a01959.html", "a01959" ],
        [ "MetadataCredentialCriteria", "a01963.html", "a01963" ],
        [ "MetadataException", "a01991.html", "a01991" ],
        [ "MetadataFilter", "a01975.html", "a01975" ],
        [ "MetadataFilterContext", "a01967.html", null ],
        [ "MetadataFilterException", "a01979.html", "a01979" ],
        [ "MetadataProvider", "a01983.html", "a01983" ],
        [ "ObservableMetadataProvider", "a01995.html", "a01995" ]
      ] ],
      [ "saml2p", null, [
        [ "SAML2Artifact", "a01915.html", "a01915" ],
        [ "SAML2ArtifactType0004", "a01919.html", "a01919" ],
        [ "SAML2MessageDecoder", "a01923.html", "a01923" ],
        [ "SAML2MessageEncoder", "a01927.html", "a01927" ],
        [ "SAML2SOAPClient", "a01931.html", "a01931" ]
      ] ],
      [ "ArtifactException", "a01843.html", "a01843" ],
      [ "ArtifactMap", "a01819.html", "a01819" ],
      [ "Assertion", "a01891.html", null ],
      [ "BindingException", "a01871.html", "a01871" ],
      [ "CommonDomainCookie", "a02023.html", "a02023" ],
      [ "ContentReference", "a02011.html", "a02011" ],
      [ "EncryptedKeyResolver", "a01863.html", "a01863" ],
      [ "FatalProfileException", "a01879.html", "a01879" ],
      [ "MessageDecoder", "a01823.html", "a01823" ],
      [ "MessageEncoder", "a01831.html", "a01831" ],
      [ "ProfileException", "a01875.html", "a01875" ],
      [ "RetryableProfileException", "a01883.html", "a01883" ],
      [ "RootObject", "a01887.html", "a01887" ],
      [ "SAMLArtifact", "a01839.html", "a01839" ],
      [ "SAMLConfig", "a02007.html", "a02007" ],
      [ "SecurityPolicy", "a01847.html", "a01847" ],
      [ "SecurityPolicyException", "a01867.html", "a01867" ],
      [ "SecurityPolicyRule", "a01855.html", "a01855" ],
      [ "SignableObject", "a02015.html", "a02015" ],
      [ "SignatureProfileValidator", "a02019.html", "a02019" ],
      [ "SOAPClient", "a01859.html", "a01859" ],
      [ "Status", "a01895.html", "a01895" ]
    ] ]
];