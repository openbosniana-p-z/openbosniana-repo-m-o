var a01959 =
[
    [ "MetadataCredentialContext", "a01959.html#a01f20591bc8962ca55eceecc0a1f4c09", null ],
    [ "getKeyDescriptor", "a01959.html#acf78ffcb760f17043ca0b21d216af8a4", null ]
];