var a01927 =
[
    [ "getProtocolFamily", "a01927.html#a5039cbcced203ba2ed615321bd268cc0", null ],
    [ "preserveCorrelationID", "a01927.html#a3095b257949ba076fbde9e129d720e9d", null ]
];