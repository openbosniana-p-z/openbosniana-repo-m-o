var a01971 =
[
    [ "BatchLoadMetadataFilterContext", "a01971.html#aee652aca1092bcc9258f586440068843", null ],
    [ "isBackingFile", "a01971.html#a82f4750d953824582e37562676d0e832", null ],
    [ "setBackingFile", "a01971.html#a1502aefc7530813fd1224e92d07b5d0f", null ]
];