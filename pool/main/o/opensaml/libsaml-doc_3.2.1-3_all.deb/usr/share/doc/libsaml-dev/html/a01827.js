var a01827 =
[
    [ "isSupported", "a01827.html#af23da2241088509c24da9e288c6aba30", null ],
    [ "resolve", "a01827.html#a15f1d39079076e30b1c1f76aec5ae2e8", null ],
    [ "resolve", "a01827.html#a437bf62d13c1c597305ffbf0aa261f98", null ]
];