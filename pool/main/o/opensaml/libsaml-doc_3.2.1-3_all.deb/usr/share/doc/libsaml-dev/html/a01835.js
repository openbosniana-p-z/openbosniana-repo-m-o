var a01835 =
[
    [ "generateSAML1Artifact", "a01835.html#a997919a8af93c664fc833c0a9badbd23", null ],
    [ "generateSAML2Artifact", "a01835.html#a135288c198b40dc62c7f1635f0e822ba", null ]
];