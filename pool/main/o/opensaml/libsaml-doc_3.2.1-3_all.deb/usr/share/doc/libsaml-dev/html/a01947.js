var a01947 =
[
    [ "EndpointManager", "a01947.html#a8e84a19f5a87c15a728fb5af362b2d82", null ],
    [ "getByBinding", "a01947.html#abd2d34385103dae11707767e4562602d", null ],
    [ "m_endpoints", "a01947.html#a78ab70c14570dda5d9791f38e3c8aefb", null ]
];