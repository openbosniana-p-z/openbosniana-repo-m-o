var a01987 =
[
    [ "Criteria", "a01987.html#a5d9a7fbf1ae67d8ce9e8c491e5f4192d", null ],
    [ "Criteria", "a01987.html#a2f2b2e00fa92885fd841244ee0fc36c9", null ],
    [ "Criteria", "a01987.html#afbd0676b023f4dc71a97b4b160ac8396", null ],
    [ "Criteria", "a01987.html#ab85456e2fdbdf43cae14502691cb51eb", null ],
    [ "reset", "a01987.html#a08a083470e432b567a9a5ed032c7f750", null ],
    [ "artifact", "a01987.html#ad1f7d22a286d2c77089051692ec15ee1", null ],
    [ "entityID_ascii", "a01987.html#ad1616d40d6b9af9836a3e99d0cdcc008", null ],
    [ "entityID_unicode", "a01987.html#a89104cbcbc282459d2a43f6776334e92", null ],
    [ "protocol", "a01987.html#a5af43b52c8de1c19c88e24ae9bcb7c00", null ],
    [ "protocol2", "a01987.html#a707c4110d9c5905ff595a2efc6bc2736", null ],
    [ "role", "a01987.html#ad2e6dc20cadb27b2aaacbcb66dae8a8f", null ],
    [ "validOnly", "a01987.html#afc1e53c772f34a448308b2c758421f97", null ]
];