var a01923 =
[
    [ "extractCorrelationID", "a01923.html#a9267d6f0ddf9745872975544f7cc627a", null ],
    [ "extractMessageDetails", "a01923.html#a55b9b1c6a97780a8071dc64abdc6f498", null ],
    [ "getProtocolFamily", "a01923.html#aa7f9f0125f1fd9789850332653ecc96b", null ]
];