var a01831 =
[
    [ "ArtifactGenerator", "a01835.html", "a01835" ],
    [ "encode", "a01831.html#af3d178ea3bd8064a3e39266821ae0ab9", null ],
    [ "getProtocolFamily", "a01831.html#a34c74476a5f830bca4a830838e91dfda", null ],
    [ "isCompact", "a01831.html#a15aef34bdd024cdf7041f3434e2555ff", null ],
    [ "isUserAgentPresent", "a01831.html#af7ecbc050dfbbb002a36dd7b8846bd4d", null ]
];