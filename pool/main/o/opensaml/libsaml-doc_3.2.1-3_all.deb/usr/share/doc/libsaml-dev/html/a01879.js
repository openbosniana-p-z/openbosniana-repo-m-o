var a01879 =
[
    [ "FatalProfileException", "a01879.html#a1f6f58a300a2e3553dfea8033cd3eb17", null ],
    [ "FatalProfileException", "a01879.html#a3e0d47daf301715829c8787eb7e4d317", null ],
    [ "FatalProfileException", "a01879.html#ab92de81a83e78960b64f1c24a1f56e28", null ],
    [ "FatalProfileException", "a01879.html#a3621fe2547210cf0ea987a6b355b8aa5", null ]
];