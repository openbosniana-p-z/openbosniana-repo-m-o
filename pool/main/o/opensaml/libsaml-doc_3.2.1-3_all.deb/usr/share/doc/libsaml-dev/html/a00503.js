var a00503 =
[
    [ "opensaml::SAMLArtifact", "a01839.html", "a01839" ],
    [ "opensaml::ArtifactException", "a01843.html", "a01843" ],
    [ "registerSAMLArtifacts", "a00503.html#a77e32a7f1e6905e6a905d7ec6e431c9e", null ]
];