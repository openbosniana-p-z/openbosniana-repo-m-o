var a01855 =
[
    [ "SecurityPolicyRule", "a01855.html#a09e5bb36c1554dadbc0ed4262a02f9dc", null ],
    [ "evaluate", "a01855.html#a063fcf8be3011f3bac31efa9b18a66f1", null ],
    [ "getType", "a01855.html#a4204bd4bc08758c568368658a6ba0d31", null ]
];