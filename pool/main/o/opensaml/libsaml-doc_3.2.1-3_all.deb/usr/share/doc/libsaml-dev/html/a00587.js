var a00587 =
[
    [ "opensaml::saml2md::ObservableMetadataProvider", "a01995.html", "a01995" ],
    [ "opensaml::saml2md::ObservableMetadataProvider::Observer", "a01999.html", "a01999" ]
];