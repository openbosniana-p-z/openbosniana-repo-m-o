var a01963 =
[
    [ "MetadataCredentialCriteria", "a01963.html#a3f9bfe08e677a90dd6106fd8401ba4f5", null ],
    [ "getRole", "a01963.html#ac7bd2aa4ba62dc4d04bfaefcea2395c4", null ],
    [ "matches", "a01963.html#a56f4786b8b40e545045303411b6b7923", null ]
];