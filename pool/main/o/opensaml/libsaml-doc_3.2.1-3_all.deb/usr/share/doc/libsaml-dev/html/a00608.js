var a00608 =
[
    [ "opensaml::saml2md::EndpointManager< _Tx >", "a01947.html", "a01947" ],
    [ "opensaml::saml2md::IndexedEndpointManager< _Tx >", "a01951.html", "a01951" ]
];