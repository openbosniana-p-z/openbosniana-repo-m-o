var a01991 =
[
    [ "MetadataException", "a01991.html#a8ca6c14b928c14d9d54c7f37d835d88f", null ],
    [ "MetadataException", "a01991.html#ae457904884ed3e97a269ebff76f91220", null ],
    [ "MetadataException", "a01991.html#a9c80fdd295c32c8e7c3d4ceda3f0bd35", null ],
    [ "MetadataException", "a01991.html#a722b5d6042814a8cf6ef7b963260c03c", null ]
];