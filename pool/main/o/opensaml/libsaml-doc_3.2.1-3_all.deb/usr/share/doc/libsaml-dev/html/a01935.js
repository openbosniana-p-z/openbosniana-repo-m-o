var a01935 =
[
    [ "AbstractDynamicMetadataProvider", "a01935.html#a211a486fd71ccb8c3eb9c4719c844667", null ],
    [ "cacheEntity", "a01935.html#a6dd91bf8830d23d458986541b901c368", null ],
    [ "computeNextRefresh", "a01935.html#aa47ab318a5741b03fa5c04e0316ded36", null ],
    [ "entityFromStream", "a01935.html#ad3a4bad8cb9a085e6f4874df29da4587", null ],
    [ "getEntityDescriptor", "a01935.html#ad497f7f166593e031af848f2007494a6", null ],
    [ "getId", "a01935.html#ac3563d12b3c633fe42768e4a4c4b4b1c", null ],
    [ "getMetadata", "a01935.html#a64a178c9b045fa72ca8e78d69654c292", null ],
    [ "resolve", "a01935.html#aa9298a811846408d1d399a1e81ec132e", null ],
    [ "m_validate", "a01935.html#a1b3dc62d8af387c9ad3b1b88f2fa2b4e", null ]
];