var a00590 =
[
    [ "opensaml::saml2md::MetadataProvider", "a01983.html", "a01983" ],
    [ "opensaml::saml2md::MetadataProvider::Criteria", "a01987.html", "a01987" ],
    [ "opensaml::saml2md::MetadataException", "a01991.html", "a01991" ],
    [ "CHAINING_METADATA_PROVIDER", "a00590.html#a71c615e6362c0444cfccca3bb1b41308", null ],
    [ "DYNAMIC_METADATA_PROVIDER", "a00590.html#a18099991cb32fb79eff6b01e703d68af", null ],
    [ "FOLDER_METADATA_PROVIDER", "a00590.html#a12d411ef2fa660b68826b6362c0b00f6", null ],
    [ "LOCAL_DYNAMIC_METADATA_PROVIDER", "a00590.html#a63eefdb94c1654111836bb1e66878743", null ],
    [ "MDQ_METADATA_PROVIDER", "a00590.html#a4e62ba65689733be1de2d5eb8222c10f", null ],
    [ "NULL_METADATA_PROVIDER", "a00590.html#a3d77981f8dc8cf896f812946095483fa", null ],
    [ "XML_METADATA_PROVIDER", "a00590.html#a53c67319d07b553a9c52daf1a0e78a9e", null ],
    [ "registerMetadataProviders", "a00590.html#ab4d824799476852cfb99257161d5371d", null ]
];