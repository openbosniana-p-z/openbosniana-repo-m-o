var a00935 =
[
    [ "opensaml::RootObject", "a01887.html", "a01887" ],
    [ "opensaml::Assertion", "a01891.html", null ],
    [ "opensaml::Status", "a01895.html", "a01895" ]
];