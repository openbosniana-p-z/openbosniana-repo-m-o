var hierarchy =
[
    [ "opensaml::MessageEncoder::ArtifactGenerator", "a01835.html", null ],
    [ "opensaml::ArtifactMap", "a01819.html", null ],
    [ "opensaml::MessageDecoder::ArtifactResolver", "a01827.html", null ],
    [ "opensaml::CommonDomainCookie", "a02023.html", null ],
    [ "xmlsignature::ContentReference", null, [
      [ "opensaml::ContentReference", "a02011.html", null ]
    ] ],
    [ "xmltooling::CredentialCriteria", null, [
      [ "opensaml::saml2md::MetadataCredentialCriteria", "a01963.html", null ]
    ] ],
    [ "xmltooling::CredentialResolver", null, [
      [ "opensaml::saml2md::MetadataProvider", "a01983.html", [
        [ "opensaml::saml2md::DiscoverableMetadataProvider", "a01943.html", null ],
        [ "opensaml::saml2md::ObservableMetadataProvider", "a01995.html", [
          [ "opensaml::saml2md::AbstractMetadataProvider", "a01939.html", [
            [ "opensaml::saml2md::AbstractDynamicMetadataProvider", "a01935.html", null ]
          ] ]
        ] ]
      ] ]
    ] ],
    [ "opensaml::saml2md::MetadataProvider::Criteria", "a01987.html", null ],
    [ "xmlencryption::EncryptedKeyResolver", null, [
      [ "opensaml::EncryptedKeyResolver", "a01863.html", null ]
    ] ],
    [ "opensaml::saml2md::EndpointManager< _Tx >", "a01947.html", [
      [ "opensaml::saml2md::IndexedEndpointManager< _Tx >", "a01951.html", null ]
    ] ],
    [ "opensaml::saml2md::EntityMatcher", "a01955.html", null ],
    [ "opensaml::SecurityPolicy::IssuerMatchingPolicy", "a01851.html", null ],
    [ "xmltooling::KeyInfoCredentialContext", null, [
      [ "opensaml::saml2md::MetadataCredentialContext", "a01959.html", null ]
    ] ],
    [ "opensaml::MessageDecoder", "a01823.html", [
      [ "opensaml::saml1p::SAML1MessageDecoder", "a01899.html", null ],
      [ "opensaml::saml2p::SAML2MessageDecoder", "a01923.html", null ]
    ] ],
    [ "opensaml::MessageEncoder", "a01831.html", [
      [ "opensaml::saml2p::SAML2MessageEncoder", "a01927.html", null ]
    ] ],
    [ "opensaml::saml2md::MetadataFilter", "a01975.html", null ],
    [ "opensaml::saml2md::MetadataFilterContext", "a01967.html", [
      [ "opensaml::saml2md::BatchLoadMetadataFilterContext", "a01971.html", null ]
    ] ],
    [ "opensaml::saml2md::ObservableMetadataProvider::Observer", "a01999.html", null ],
    [ "opensaml::saml1p::SAML1SOAPClient", "a01903.html", null ],
    [ "opensaml::saml2p::SAML2SOAPClient", "a01931.html", null ],
    [ "opensaml::SAMLArtifact", "a01839.html", [
      [ "opensaml::saml1p::SAMLArtifactType0001", "a01907.html", null ],
      [ "opensaml::saml1p::SAMLArtifactType0002", "a01911.html", null ],
      [ "opensaml::saml2p::SAML2Artifact", "a01915.html", [
        [ "opensaml::saml2p::SAML2ArtifactType0004", "a01919.html", null ]
      ] ]
    ] ],
    [ "opensaml::SAMLConfig", "a02007.html", null ],
    [ "opensaml::SecurityPolicy", "a01847.html", [
      [ "opensaml::saml2::SAML2AssertionPolicy", "a02003.html", null ]
    ] ],
    [ "opensaml::SecurityPolicyRule", "a01855.html", null ],
    [ "soap11::SOAPClient", null, [
      [ "opensaml::SOAPClient", "a01859.html", null ]
    ] ],
    [ "xmltooling::ValidationException", null, [
      [ "opensaml::ProfileException", "a01875.html", [
        [ "opensaml::FatalProfileException", "a01879.html", null ],
        [ "opensaml::RetryableProfileException", "a01883.html", null ]
      ] ]
    ] ],
    [ "xmltooling::Validator", null, [
      [ "opensaml::SignatureProfileValidator", "a02019.html", null ]
    ] ],
    [ "xmltooling::XMLObject", null, [
      [ "opensaml::SignableObject", "a02015.html", [
        [ "opensaml::RootObject", "a01887.html", [
          [ "opensaml::Assertion", "a01891.html", null ]
        ] ]
      ] ],
      [ "opensaml::Status", "a01895.html", null ]
    ] ],
    [ "xmltooling::XMLToolingException", null, [
      [ "opensaml::ArtifactException", "a01843.html", null ],
      [ "opensaml::BindingException", "a01871.html", null ],
      [ "opensaml::SecurityPolicyException", "a01867.html", null ],
      [ "opensaml::saml2md::MetadataException", "a01991.html", [
        [ "opensaml::saml2md::MetadataFilterException", "a01979.html", null ]
      ] ]
    ] ]
];