var a00926 =
[
    [ "opensaml::SecurityPolicyException", "a01867.html", "a01867" ],
    [ "opensaml::BindingException", "a01871.html", "a01871" ],
    [ "opensaml::ProfileException", "a01875.html", "a01875" ],
    [ "opensaml::FatalProfileException", "a01879.html", "a01879" ],
    [ "opensaml::RetryableProfileException", "a01883.html", "a01883" ],
    [ "annotateException", "a00926.html#a9400a40de3745f15c7e2b6f39ae18b92", null ],
    [ "annotateException", "a00926.html#abde7c6b47d7631916e1f86d20494ab4c", null ]
];