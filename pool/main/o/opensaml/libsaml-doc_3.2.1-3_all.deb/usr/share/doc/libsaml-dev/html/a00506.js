var a00506 =
[
    [ "opensaml::SecurityPolicy", "a01847.html", "a01847" ],
    [ "opensaml::SecurityPolicy::IssuerMatchingPolicy", "a01851.html", "a01851" ]
];