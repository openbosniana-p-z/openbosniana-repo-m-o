Release Notes
-----------
https://issues.shibboleth.net/jira/secure/ReleaseNote.jspa?projectId=10032

Documentation:
--------------
The OpenSAML wiki is the home for any documentation.
https://wiki.shibboleth.net/confluence/display/OpenSAML/

Reporting Bugs:
---------------
A Jira instance is available.
https://issues.shibboleth.net/

Support:
--------
A mailing list is available.
https://wiki.shibboleth.net/confluence/display/OpenSAML/MailingList
