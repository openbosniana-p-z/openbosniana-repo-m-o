var EclHysteresisTwoPhaseLawParams_8hpp =
[
    [ "Opm::EclHysteresisTwoPhaseLawParams< EffLawT >", "classOpm_1_1EclHysteresisTwoPhaseLawParams.html", "classOpm_1_1EclHysteresisTwoPhaseLawParams" ]
];