var DynamicEvaluation_8hpp =
[
    [ "Opm::DenseAd::Evaluation< ValueT, DynamicSize, staticSize >", "classOpm_1_1DenseAd_1_1Evaluation_3_01ValueT_00_01DynamicSize_00_01staticSize_01_4.html", "classOpm_1_1DenseAd_1_1Evaluation_3_01ValueT_00_01DynamicSize_00_01staticSize_01_4" ]
];