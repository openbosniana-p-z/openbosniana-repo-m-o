var Math_8hpp =
[
    [ "Opm::MathToolbox< DenseAd::Evaluation< ValueT, numVars, staticSize > >", "structOpm_1_1MathToolbox_3_01DenseAd_1_1Evaluation_3_01ValueT_00_01numVars_00_01staticSize_01_4_01_4.html", null ]
];