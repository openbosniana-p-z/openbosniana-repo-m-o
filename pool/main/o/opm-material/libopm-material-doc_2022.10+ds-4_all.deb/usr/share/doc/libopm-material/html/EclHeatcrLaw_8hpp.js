var EclHeatcrLaw_8hpp =
[
    [ "Opm::EclHeatcrLaw< ScalarT, FluidSystem, ParamsT >", "classOpm_1_1EclHeatcrLaw.html", null ]
];