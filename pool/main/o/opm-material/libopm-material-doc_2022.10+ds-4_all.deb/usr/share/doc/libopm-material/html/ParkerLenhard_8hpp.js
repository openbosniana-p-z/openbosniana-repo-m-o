var ParkerLenhard_8hpp =
[
    [ "Opm::PLScanningCurve< ScalarT >", "classOpm_1_1PLScanningCurve.html", "classOpm_1_1PLScanningCurve" ],
    [ "Opm::ParkerLenhard< TraitsT, ParamsT >", "classOpm_1_1ParkerLenhard.html", null ]
];