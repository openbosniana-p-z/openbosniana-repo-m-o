var EclStone2Material_8hpp =
[
    [ "Opm::EclStone2Material< TraitsT, GasOilMaterialLawT, OilWaterMaterialLawT, ParamsT >", "classOpm_1_1EclStone2Material.html", null ]
];