var Exceptions_8hpp =
[
    [ "Opm::NumericalIssue", "classOpm_1_1NumericalIssue.html", null ]
];