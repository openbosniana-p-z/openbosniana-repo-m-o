var EclEpsScalingPoints_8hpp =
[
    [ "Opm::EclEpsScalingPointsInfo< Scalar >", "structOpm_1_1EclEpsScalingPointsInfo.html", null ],
    [ "Opm::EclEpsScalingPoints< Scalar >", "classOpm_1_1EclEpsScalingPoints.html", "classOpm_1_1EclEpsScalingPoints" ]
];