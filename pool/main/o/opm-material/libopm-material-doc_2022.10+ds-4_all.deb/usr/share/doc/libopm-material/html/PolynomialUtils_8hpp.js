var PolynomialUtils_8hpp =
[
    [ "cubicRoots", "PolynomialUtils_8hpp.html#ab1e64ac7397943f187416d7e1b928961", null ],
    [ "invertCubicPolynomial", "PolynomialUtils_8hpp.html#aef416356cad22b1ef76f2f95050492f2", null ],
    [ "invertLinearPolynomial", "PolynomialUtils_8hpp.html#a305e17262772f9ab5ee17ab8ae6ae497", null ],
    [ "invertQuadraticPolynomial", "PolynomialUtils_8hpp.html#a15eff099c83a83fc39a9dd531c2372b0", null ]
];