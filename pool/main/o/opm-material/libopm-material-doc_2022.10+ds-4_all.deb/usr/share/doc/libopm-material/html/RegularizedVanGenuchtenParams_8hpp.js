var RegularizedVanGenuchtenParams_8hpp =
[
    [ "Opm::RegularizedVanGenuchtenParams< TraitsT >", "classOpm_1_1RegularizedVanGenuchtenParams.html", "classOpm_1_1RegularizedVanGenuchtenParams" ]
];