var EclMultiplexerMaterialParams_8hpp =
[
    [ "Opm::EclMultiplexerMaterialParams< Traits, GasOilMaterialLawT, OilWaterMaterialLawT, GasWaterMaterialLawT >", "classOpm_1_1EclMultiplexerMaterialParams.html", "classOpm_1_1EclMultiplexerMaterialParams" ]
];