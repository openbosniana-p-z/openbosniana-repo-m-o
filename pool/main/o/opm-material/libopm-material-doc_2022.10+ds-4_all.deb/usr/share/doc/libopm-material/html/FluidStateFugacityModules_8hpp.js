var FluidStateFugacityModules_8hpp =
[
    [ "Opm::FluidStateExplicitFugacityModule< Scalar, numPhases, numComponents, Implementation >", "classOpm_1_1FluidStateExplicitFugacityModule.html", "classOpm_1_1FluidStateExplicitFugacityModule" ],
    [ "Opm::FluidStateImmiscibleFugacityModule< Scalar, numPhases, numComponents, Implementation >", "classOpm_1_1FluidStateImmiscibleFugacityModule.html", "classOpm_1_1FluidStateImmiscibleFugacityModule" ],
    [ "Opm::FluidStateNullFugacityModule< Scalar >", "classOpm_1_1FluidStateNullFugacityModule.html", "classOpm_1_1FluidStateNullFugacityModule" ]
];