var EffToAbsLaw_8hpp =
[
    [ "Opm::EffToAbsLaw< EffLawT, ParamsT >", "classOpm_1_1EffToAbsLaw.html", null ]
];