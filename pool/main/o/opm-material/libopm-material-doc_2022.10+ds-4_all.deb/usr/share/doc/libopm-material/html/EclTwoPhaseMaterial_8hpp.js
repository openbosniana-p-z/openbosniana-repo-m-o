var EclTwoPhaseMaterial_8hpp =
[
    [ "Opm::EclTwoPhaseMaterial< TraitsT, GasOilMaterialLawT, OilWaterMaterialLawT, GasWaterMaterialLawT, ParamsT >", "classOpm_1_1EclTwoPhaseMaterial.html", null ]
];