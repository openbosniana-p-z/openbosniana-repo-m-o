var PiecewiseLinearTwoPhaseMaterial_8hpp =
[
    [ "Opm::PiecewiseLinearTwoPhaseMaterial< TraitsT, ParamsT >", "classOpm_1_1PiecewiseLinearTwoPhaseMaterial.html", "classOpm_1_1PiecewiseLinearTwoPhaseMaterial" ]
];