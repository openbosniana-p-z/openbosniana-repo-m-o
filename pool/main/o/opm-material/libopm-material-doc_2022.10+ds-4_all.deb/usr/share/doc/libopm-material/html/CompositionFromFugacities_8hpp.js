var CompositionFromFugacities_8hpp =
[
    [ "Opm::CompositionFromFugacities< Scalar, FluidSystem, Evaluation >", "classOpm_1_1CompositionFromFugacities.html", null ]
];