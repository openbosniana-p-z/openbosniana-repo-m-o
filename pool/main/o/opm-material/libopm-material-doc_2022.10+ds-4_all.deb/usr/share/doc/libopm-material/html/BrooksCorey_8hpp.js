var BrooksCorey_8hpp =
[
    [ "Opm::BrooksCorey< TraitsT, ParamsT >", "classOpm_1_1BrooksCorey.html", null ]
];