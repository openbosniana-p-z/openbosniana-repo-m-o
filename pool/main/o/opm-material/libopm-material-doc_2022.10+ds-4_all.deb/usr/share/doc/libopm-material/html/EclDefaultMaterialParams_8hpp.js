var EclDefaultMaterialParams_8hpp =
[
    [ "Opm::EclDefaultMaterialParams< Traits, GasOilParamsT, OilWaterParamsT >", "classOpm_1_1EclDefaultMaterialParams.html", "classOpm_1_1EclDefaultMaterialParams" ]
];