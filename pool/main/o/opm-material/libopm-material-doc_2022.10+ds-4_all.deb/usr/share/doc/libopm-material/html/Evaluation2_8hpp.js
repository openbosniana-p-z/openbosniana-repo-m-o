var Evaluation2_8hpp =
[
    [ "Opm::DenseAd::Evaluation< ValueT, 2 >", "classOpm_1_1DenseAd_1_1Evaluation_3_01ValueT_00_012_01_4.html", "classOpm_1_1DenseAd_1_1Evaluation_3_01ValueT_00_012_01_4" ]
];