var EclMultiplexerMaterial_8hpp =
[
    [ "Opm::EclMultiplexerMaterial< TraitsT, GasOilMaterialLawT, OilWaterMaterialLawT, GasWaterMaterialLawT, ParamsT >", "classOpm_1_1EclMultiplexerMaterial.html", null ]
];