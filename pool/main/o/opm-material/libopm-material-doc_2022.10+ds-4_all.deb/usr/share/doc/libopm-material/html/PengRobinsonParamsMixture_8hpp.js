var PengRobinsonParamsMixture_8hpp =
[
    [ "Opm::PengRobinsonParamsMixture< Scalar, FluidSystem, phaseIdx, useSpe5Relations >", "classOpm_1_1PengRobinsonParamsMixture.html", "classOpm_1_1PengRobinsonParamsMixture" ]
];