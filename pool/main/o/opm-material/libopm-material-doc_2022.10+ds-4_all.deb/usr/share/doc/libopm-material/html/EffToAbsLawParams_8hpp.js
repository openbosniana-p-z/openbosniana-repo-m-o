var EffToAbsLawParams_8hpp =
[
    [ "Opm::EffToAbsLawParams< EffLawParamsT, numPhases >", "classOpm_1_1EffToAbsLawParams.html", "classOpm_1_1EffToAbsLawParams" ]
];