var EclHysteresisTwoPhaseLaw_8hpp =
[
    [ "Opm::EclHysteresisTwoPhaseLaw< EffectiveLawT, ParamsT >", "classOpm_1_1EclHysteresisTwoPhaseLaw.html", null ]
];