var EclDefaultMaterial_8hpp =
[
    [ "Opm::EclDefaultMaterial< TraitsT, GasOilMaterialLawT, OilWaterMaterialLawT, ParamsT >", "classOpm_1_1EclDefaultMaterial.html", null ]
];