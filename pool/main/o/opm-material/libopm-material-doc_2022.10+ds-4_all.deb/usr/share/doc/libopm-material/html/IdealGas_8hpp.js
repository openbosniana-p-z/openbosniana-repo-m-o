var IdealGas_8hpp =
[
    [ "Opm::IdealGas< Scalar >", "classOpm_1_1IdealGas.html", null ]
];