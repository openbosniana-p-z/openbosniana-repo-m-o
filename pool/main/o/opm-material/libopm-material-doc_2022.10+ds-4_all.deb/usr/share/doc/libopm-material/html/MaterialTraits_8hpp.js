var MaterialTraits_8hpp =
[
    [ "Opm::NullMaterialTraits< ScalarT, numPhasesV >", "classOpm_1_1NullMaterialTraits.html", "classOpm_1_1NullMaterialTraits" ],
    [ "Opm::TwoPhaseMaterialTraits< ScalarT, wettingPhaseIdxV, nonWettingPhaseIdxV >", "classOpm_1_1TwoPhaseMaterialTraits.html", "classOpm_1_1TwoPhaseMaterialTraits" ],
    [ "Opm::ThreePhaseMaterialTraits< ScalarT, wettingPhaseIdxV, nonWettingasPhaseIdxV, gasPhaseIdxV >", "classOpm_1_1ThreePhaseMaterialTraits.html", "classOpm_1_1ThreePhaseMaterialTraits" ]
];