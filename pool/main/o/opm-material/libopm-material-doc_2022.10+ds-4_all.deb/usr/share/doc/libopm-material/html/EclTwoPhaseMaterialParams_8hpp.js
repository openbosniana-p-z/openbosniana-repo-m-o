var EclTwoPhaseMaterialParams_8hpp =
[
    [ "Opm::EclTwoPhaseMaterialParams< Traits, GasOilParamsT, OilWaterParamsT, GasWaterParamsT >", "classOpm_1_1EclTwoPhaseMaterialParams.html", "classOpm_1_1EclTwoPhaseMaterialParams" ]
];