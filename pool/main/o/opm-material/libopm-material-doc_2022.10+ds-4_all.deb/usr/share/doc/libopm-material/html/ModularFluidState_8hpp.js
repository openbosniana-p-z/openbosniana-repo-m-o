var ModularFluidState_8hpp =
[
    [ "Opm::ModularFluidState< ScalarT, numPhasesV, numComponentsV, PressureModule, TemperatureModule, CompositionModule, FugacityModule, SaturationModule, DensityModule, ViscosityModule, EnthalpyModule >", "classOpm_1_1ModularFluidState.html", "classOpm_1_1ModularFluidState" ]
];