var EclSpecrockLawParams_8hpp =
[
    [ "Opm::EclSpecrockLawParams< ScalarT >", "classOpm_1_1EclSpecrockLawParams.html", "classOpm_1_1EclSpecrockLawParams" ]
];