var DeadOilPvt_8hpp =
[
    [ "Opm::DeadOilPvt< Scalar >", "classOpm_1_1DeadOilPvt.html", "classOpm_1_1DeadOilPvt" ]
];