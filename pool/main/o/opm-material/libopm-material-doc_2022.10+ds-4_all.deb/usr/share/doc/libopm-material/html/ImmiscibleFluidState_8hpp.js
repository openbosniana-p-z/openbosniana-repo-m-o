var ImmiscibleFluidState_8hpp =
[
    [ "Opm::ImmiscibleFluidState< Scalar, FluidSystem, true >", "classOpm_1_1ImmiscibleFluidState_3_01Scalar_00_01FluidSystem_00_01true_01_4.html", null ],
    [ "Opm::ImmiscibleFluidState< Scalar, FluidSystem, false >", "classOpm_1_1ImmiscibleFluidState_3_01Scalar_00_01FluidSystem_00_01false_01_4.html", null ]
];