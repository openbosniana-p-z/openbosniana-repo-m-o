var EclEpsTwoPhaseLaw_8hpp =
[
    [ "Opm::EclEpsTwoPhaseLaw< EffLawT, ParamsT >", "classOpm_1_1EclEpsTwoPhaseLaw.html", null ]
];