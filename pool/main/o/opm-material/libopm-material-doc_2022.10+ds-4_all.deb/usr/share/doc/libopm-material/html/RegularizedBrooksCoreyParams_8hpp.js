var RegularizedBrooksCoreyParams_8hpp =
[
    [ "Opm::RegularizedBrooksCoreyParams< TraitsT >", "classOpm_1_1RegularizedBrooksCoreyParams.html", "classOpm_1_1RegularizedBrooksCoreyParams" ]
];