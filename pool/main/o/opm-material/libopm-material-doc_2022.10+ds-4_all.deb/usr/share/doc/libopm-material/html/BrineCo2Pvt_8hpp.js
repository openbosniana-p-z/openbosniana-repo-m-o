var BrineCo2Pvt_8hpp =
[
    [ "Opm::BrineCo2Pvt< Scalar >", "classOpm_1_1BrineCo2Pvt.html", "classOpm_1_1BrineCo2Pvt" ]
];