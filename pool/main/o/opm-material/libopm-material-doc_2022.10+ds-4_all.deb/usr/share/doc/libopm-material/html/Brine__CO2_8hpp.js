var Brine__CO2_8hpp =
[
    [ "Opm::BinaryCoeff::Brine_CO2< Scalar, H2O, CO2, verbose >", "classOpm_1_1BinaryCoeff_1_1Brine__CO2.html", null ]
];