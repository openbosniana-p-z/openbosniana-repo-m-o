var EclEpsTwoPhaseLawParams_8hpp =
[
    [ "Opm::EclEpsTwoPhaseLawParams< EffLawT >", "classOpm_1_1EclEpsTwoPhaseLawParams.html", "classOpm_1_1EclEpsTwoPhaseLawParams" ]
];