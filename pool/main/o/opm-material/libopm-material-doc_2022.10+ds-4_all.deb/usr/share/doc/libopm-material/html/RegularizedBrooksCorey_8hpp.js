var RegularizedBrooksCorey_8hpp =
[
    [ "Opm::RegularizedBrooksCorey< TraitsT, ParamsT >", "classOpm_1_1RegularizedBrooksCorey.html", null ]
];