var BrooksCoreyParams_8hpp =
[
    [ "Opm::BrooksCoreyParams< TraitsT >", "classOpm_1_1BrooksCoreyParams.html", "classOpm_1_1BrooksCoreyParams" ]
];