var EclSpecrockLaw_8hpp =
[
    [ "Opm::EclSpecrockLaw< ScalarT, ParamsT >", "classOpm_1_1EclSpecrockLaw.html", null ]
];