var Means_8hpp =
[
    [ "arithmeticMean", "Means_8hpp.html#afa0a03d0db6f8795bfe0e14d1ad3ecfd", null ],
    [ "geometricMean", "Means_8hpp.html#a2645c2f628d66367f270eaad1c616828", null ],
    [ "harmonicMean", "Means_8hpp.html#a5376184cac9d3e7ed4d0e9c5ade853a7", null ]
];