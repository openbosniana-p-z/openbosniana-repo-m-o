var Evaluation_8hpp =
[
    [ "Opm::DenseAd::Evaluation< ValueT, numDerivs, staticSize >", "classOpm_1_1DenseAd_1_1Evaluation.html", "classOpm_1_1DenseAd_1_1Evaluation" ],
    [ "Dune::FieldTraits< Opm::DenseAd::Evaluation< ValueType, numVars, staticSize > >", "structDune_1_1FieldTraits_3_01Opm_1_1DenseAd_1_1Evaluation_3_01ValueType_00_01numVars_00_01staticSize_01_4_01_4.html", null ]
];