var BrineCO2FluidSystem_8hpp =
[
    [ "Opm::BrineCO2FluidSystem< Scalar, CO2Tables >", "classOpm_1_1BrineCO2FluidSystem.html", "classOpm_1_1BrineCO2FluidSystem" ],
    [ "Opm::BrineCO2FluidSystem< Scalar, CO2Tables >::ParameterCache< Evaluation >", "structOpm_1_1BrineCO2FluidSystem_1_1ParameterCache.html", null ]
];