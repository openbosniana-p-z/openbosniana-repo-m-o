var EclHysteresisConfig_8hpp =
[
    [ "Opm::EclHysteresisConfig", "classOpm_1_1EclHysteresisConfig.html", "classOpm_1_1EclHysteresisConfig" ]
];