var NonEquilibriumFluidState_8hpp =
[
    [ "Opm::NonEquilibriumFluidState< Scalar, FluidSystem, true >", "classOpm_1_1NonEquilibriumFluidState_3_01Scalar_00_01FluidSystem_00_01true_01_4.html", null ],
    [ "Opm::NonEquilibriumFluidState< Scalar, FluidSystem, false >", "classOpm_1_1NonEquilibriumFluidState_3_01Scalar_00_01FluidSystem_00_01false_01_4.html", null ]
];