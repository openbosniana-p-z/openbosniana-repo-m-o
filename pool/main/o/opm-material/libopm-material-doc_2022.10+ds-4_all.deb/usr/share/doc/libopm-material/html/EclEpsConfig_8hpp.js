var EclEpsConfig_8hpp =
[
    [ "Opm::EclEpsConfig", "classOpm_1_1EclEpsConfig.html", "classOpm_1_1EclEpsConfig" ],
    [ "EclTwoPhaseSystemType", "EclEpsConfig_8hpp.html#a19c862884dadb5ea3f0d52a150b25a6c", [
      [ "EclGasOilSystem", "EclEpsConfig_8hpp.html#a19c862884dadb5ea3f0d52a150b25a6ca6db305fc963cf91d0ce461494658f40c", null ],
      [ "EclOilWaterSystem", "EclEpsConfig_8hpp.html#a19c862884dadb5ea3f0d52a150b25a6cac470235398e1ca023f100425e36986f9", null ],
      [ "EclGasWaterSystem", "EclEpsConfig_8hpp.html#a19c862884dadb5ea3f0d52a150b25a6ca960b7a162261e7a7b5ff94e014eeeed7", null ]
    ] ]
];