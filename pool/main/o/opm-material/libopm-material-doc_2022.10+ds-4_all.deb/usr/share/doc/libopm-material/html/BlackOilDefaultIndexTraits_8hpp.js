var BlackOilDefaultIndexTraits_8hpp =
[
    [ "Opm::BlackOilDefaultIndexTraits", "classOpm_1_1BlackOilDefaultIndexTraits.html", null ]
];