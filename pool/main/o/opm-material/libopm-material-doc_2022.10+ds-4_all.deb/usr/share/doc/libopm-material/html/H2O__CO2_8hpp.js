var H2O__CO2_8hpp =
[
    [ "Opm::BinaryCoeff::H2O_CO2", "classOpm_1_1BinaryCoeff_1_1H2O__CO2.html", null ]
];