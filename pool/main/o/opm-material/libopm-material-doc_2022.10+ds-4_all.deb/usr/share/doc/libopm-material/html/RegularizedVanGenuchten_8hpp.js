var RegularizedVanGenuchten_8hpp =
[
    [ "Opm::RegularizedVanGenuchten< TraitsT, ParamsT >", "classOpm_1_1RegularizedVanGenuchten.html", null ]
];