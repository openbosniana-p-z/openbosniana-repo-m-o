var FluidStateViscosityModules_8hpp =
[
    [ "Opm::FluidStateExplicitViscosityModule< Scalar, numPhases, Implementation >", "classOpm_1_1FluidStateExplicitViscosityModule.html", "classOpm_1_1FluidStateExplicitViscosityModule" ],
    [ "Opm::FluidStateNullViscosityModule< Scalar, numPhases, Implementation >", "classOpm_1_1FluidStateNullViscosityModule.html", "classOpm_1_1FluidStateNullViscosityModule" ]
];