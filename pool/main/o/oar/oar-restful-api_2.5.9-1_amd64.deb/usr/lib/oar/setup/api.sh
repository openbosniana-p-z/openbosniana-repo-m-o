
set -e

#
# Variables defined during the oar installation process
#
PREFIX="/usr"
BINDIR="/usr/bin"
CGIDIR="/usr/lib/cgi-bin"
DOCDIR="/usr/share/doc/oar-restful-api"
EXAMPLEDIR="/usr/share/doc/oar-restful-api/examples"
ETCDIR="/etc"
OARCONFDIR="/etc/oar"
OARDIR="/usr/lib/oar"
SHAREDIR="/usr/share/oar/oar-api"
PERLLIBDIR="/usr/share/perl5"
RUNDIR="/var/run"
LOGDIR="/var/log"
MANDIR="/usr/share/man"
SBINDIR="/usr/sbin"
VARLIBDIR="/var/lib"
OARHOMEDIR="/var/lib/oar"
ROOTUSER="root"
ROOTGROUP="root"
OARDO_DEFAULTUSER="root"
OARDO_DEFAULTGROUP="oar"
OARUSER="oar"
OAROWNER="oar"
OAROWNERGROUP="oar"
WWWUSER="www-data"
APACHECONFDIR="/etc/apache2"
WWWROOTDIR="/var/www"
WWWDIR="/usr/share/oar-web-status"
XAUTHCMDPATH="/usr/bin/xauth"
OARSHCMD="oarsh_oardo"
INITDIR="/etc/init.d"
DEFAULTDIR="/etc/default"
SETUP_TYPE="deb"
TARGET_DIST="debian"
OARDOPATH="/bin:/sbin:/usr/bin:/usr/sbin:/usr/bin:/usr/sbin:/usr/lib/oar/oardodo"

#
# shared functions for oar setup files.
#

install_conffile() {

    
    case "${SETUP_TYPE}" in
        "deb")
            install_deb_conffile $*
            ;;
        "rpm")
            install_rpm_conffile $*
            ;;
        "tgz"|*)
            install_if_not_exist $*
            ;;
    esac

}


install_deb_conffile() {
    local src dst rights owner tmpfile package
    src=$1
    dst=$2
    rights=$3
    owner=$4

    # PACKAGE need to be defined in the postinst before calling *-setup.
    package=$PACKAGE

    ucf --debconf-ok --three-way $src $dst
    ucfr $package $dst

    if [ -n "$rights" ]; then
        chmod $rights $dst
    fi
    if [ -n "$owner" ]; then
        chown $owner $dst
    fi
    
    if [ -f "$tmpfile" ]; then
        rm -f "$tmpfile"
    fi
}

install_rpm_conffile() {
    # I've not found ucf or equivalent to install config file during postinst
    # in the rpm world. So the config file are nstalled manually in the spec
    # file.

    local src dst rights owner tmpfile
    src=$1
    dst=$2
    rights=$3
    owner=$4
    
    if [ -n "$rights" ]; then
        chmod $rights $dst
    fi
    if [ -n "$owner" ]; then
        chown $owner $dst
    fi
}

install_if_not_exist() {
    local src dst rights owner
    src=$1
    dst=$2
    rights=$3
    owner=$4

        
    # Decompress the file, if compressed
    tmpfile=
    if [ ! -f "$src" ] && [ -f "${src}.gz" ]; then
        tmpfile=$(tempfile)
        zcat ${src}.gz > $tmpfile
        src=$tmpfile
    fi

    if [ -f "$dst" ]; then 
        :
    else 
        install $src $dst
        if [ -n "$rights" ]; then
            chmod $rights $dst
        fi
        if [ -n "$owner" ]; then
            chown $owner $dst
        fi
    fi
    
    if [ -f "$tmpfile" ]; then
        rm -f "$tmpfile"
    fi
}

set_rights() {
  file=$1
  perms=$2
  owner=$3
  group=$4

  [ -n "$owner" ] && chown $owner $file
  [ -n "$group" ] && chgrp $group $file
  [ -n "$perms" ] && chmod $perms $file
}


api_setup() {
    mkdir -p ${OARCONFDIR}/apache2 || true
    # Check for an old configuration file
    if [ -f ${OARCONFDIR}/apache-api.conf ]; then
        mv ${OARCONFDIR}/apache-api.conf ${OARCONFDIR}/apache2/oar-restful-api.conf
    fi
    install_conffile \
        ${SHAREDIR}/apache2.conf \
        ${OARCONFDIR}/apache2/oar-restful-api.conf \
        0600 ${WWWUSER}

    install_conffile \
        ${SHAREDIR}/api_html_header.pl \
        ${OARCONFDIR}/api_html_header.pl \
        0600 ${OAROWNER}

    install_conffile \
        ${SHAREDIR}/api_html_postform.pl \
        ${OARCONFDIR}/api_html_postform.pl \
        0644 ${OAROWNER}

    install_conffile \
        ${SHAREDIR}/api_html_postform_resources.pl \
        ${OARCONFDIR}/api_html_postform_resources.pl \
        0644 ${OAROWNER}

    install_conffile \
        ${SHAREDIR}/api_html_postform_rule.pl \
        ${OARCONFDIR}/api_html_postform_rule.pl \
        0644 ${OAROWNER}

    install_conffile \
        ${SHAREDIR}/stress_factor.sh \
        ${OARCONFDIR}/stress_factor.sh \
        0700 ${OAROWNER}

    # Install the apache2 configuration file
    #
    # Starting with Debian8, Apache configs are managed using a2enconf/a2disconf/a2query -c, 
    # and stored in the conf-{available,enabled} directories
    if a2query -c > /dev/null 2>&1; then 
        if [ -L  ${APACHECONFDIR}/conf-available/oar-api.conf ]; then
            rm ${APACHECONFDIR}/conf-available/oar-api.conf
        elif [ -f ${APACHECONFDIR}/conf-available/oar-api.conf ]; then
            mv ${APACHECONFDIR}/conf-available/oar-api.conf ${APACHECONFDIR}/conf-available/oar-restful-api.conf
        fi
        if [ ! -e ${APACHECONFDIR}/conf-available/oar-restful-api.conf ]; then
            ln -s ${OARCONFDIR}/apache2/oar-restful-api.conf ${APACHECONFDIR}/conf-available/oar-restful-api.conf
        fi
    # UnTil Debian7, Centos6, Apache configs are stored in the conf.d directory
    elif [ -d ${APACHECONFDIR}/conf.d ]; then
        if [ -L  ${APACHECONFDIR}/conf.d/oar-api.conf ]; then
            rm ${APACHECONFDIR}/conf.d/oar-api.conf
        elif [ -f ${APACHECONFDIR}/conf.d/oar-api.conf ]; then
            mv ${APACHECONFDIR}/conf.d/oar-api.conf ${APACHECONFDIR}/conf.d/oar-restful-api.conf
        fi
        if [ ! -e ${APACHECONFDIR}/conf.d/oar-restful-api.conf ]; then
            ln -s ${OARCONFDIR}/apache2/oar-restful-api.conf ${APACHECONFDIR}/conf.d/oar-restful-api.conf
        fi 
    fi
    
    set_rights ${CGIDIR}/oarapi                  0755 ${OAROWNER} ${OAROWNERGROUP}
    set_rights ${CGIDIR}/oarapi/oarapi.cgi       0755 ${OAROWNER} ${OAROWNERGROUP}
    set_rights ${CGIDIR}/oarapi/oarapi-debug.cgi 0755 ${OAROWNER} ${OAROWNERGROUP}
}
