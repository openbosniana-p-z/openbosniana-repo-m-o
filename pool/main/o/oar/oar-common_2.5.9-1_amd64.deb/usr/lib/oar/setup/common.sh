
set -e

#
# Variables defined during the oar installation process
#
PREFIX="/usr"
BINDIR="/usr/bin"
CGIDIR="/usr/lib/cgi-bin"
DOCDIR="/usr/share/doc/oar-common"
EXAMPLEDIR="/usr/share/doc/oar-common/examples"
ETCDIR="/etc"
OARCONFDIR="/etc/oar"
OARDIR="/usr/lib/oar"
SHAREDIR="/usr/share/oar/oar-common"
PERLLIBDIR="/usr/share/perl5"
RUNDIR="/var/run"
LOGDIR="/var/log"
MANDIR="/usr/share/man"
SBINDIR="/usr/sbin"
VARLIBDIR="/var/lib"
OARHOMEDIR="/var/lib/oar"
ROOTUSER="root"
ROOTGROUP="root"
OARDO_DEFAULTUSER="root"
OARDO_DEFAULTGROUP="oar"
OARUSER="oar"
OAROWNER="oar"
OAROWNERGROUP="oar"
WWWUSER="www-data"
APACHECONFDIR="/etc/apache2"
WWWROOTDIR="/var/www"
WWWDIR="/usr/share/oar-web-status"
XAUTHCMDPATH="/usr/bin/xauth"
OARSHCMD="oarsh_oardo"
INITDIR="/etc/init.d"
DEFAULTDIR="/etc/default"
SETUP_TYPE="deb"
TARGET_DIST="debian"
OARDOPATH="/bin:/sbin:/usr/bin:/usr/sbin:/usr/bin:/usr/sbin:/usr/lib/oar/oardodo"

#
# shared functions for oar setup files.
#

install_conffile() {

    
    case "${SETUP_TYPE}" in
        "deb")
            install_deb_conffile $*
            ;;
        "rpm")
            install_rpm_conffile $*
            ;;
        "tgz"|*)
            install_if_not_exist $*
            ;;
    esac

}


install_deb_conffile() {
    local src dst rights owner tmpfile package
    src=$1
    dst=$2
    rights=$3
    owner=$4

    # PACKAGE need to be defined in the postinst before calling *-setup.
    package=$PACKAGE

    ucf --debconf-ok --three-way $src $dst
    ucfr $package $dst

    if [ -n "$rights" ]; then
        chmod $rights $dst
    fi
    if [ -n "$owner" ]; then
        chown $owner $dst
    fi
    
    if [ -f "$tmpfile" ]; then
        rm -f "$tmpfile"
    fi
}

install_rpm_conffile() {
    # I've not found ucf or equivalent to install config file during postinst
    # in the rpm world. So the config file are nstalled manually in the spec
    # file.

    local src dst rights owner tmpfile
    src=$1
    dst=$2
    rights=$3
    owner=$4
    
    if [ -n "$rights" ]; then
        chmod $rights $dst
    fi
    if [ -n "$owner" ]; then
        chown $owner $dst
    fi
}

install_if_not_exist() {
    local src dst rights owner
    src=$1
    dst=$2
    rights=$3
    owner=$4

        
    # Decompress the file, if compressed
    tmpfile=
    if [ ! -f "$src" ] && [ -f "${src}.gz" ]; then
        tmpfile=$(tempfile)
        zcat ${src}.gz > $tmpfile
        src=$tmpfile
    fi

    if [ -f "$dst" ]; then 
        :
    else 
        install $src $dst
        if [ -n "$rights" ]; then
            chmod $rights $dst
        fi
        if [ -n "$owner" ]; then
            chown $owner $dst
        fi
    fi
    
    if [ -f "$tmpfile" ]; then
        rm -f "$tmpfile"
    fi
}

set_rights() {
  file=$1
  perms=$2
  owner=$3
  group=$4

  [ -n "$owner" ] && chown $owner $file
  [ -n "$group" ] && chgrp $group $file
  [ -n "$perms" ] && chmod $perms $file
}

create_oar_group() {
    if ! getent group | grep -q "^${OAROWNERGROUP}:"; then 
        echo -n "Adding group ${OAROWNERGROUP}.."
        case "$TARGET_DIST" in
            "debian")
                addgroup --quiet --system ${OAROWNERGROUP} 2>/dev/null || true
                ;;
            *)
                groupadd --system ${OAROWNERGROUP} 2>/dev/null  >/dev/null || true
                ;;
        esac
        echo "..done"
    fi
}

create_oar_home() {
    test -d "${OARHOMEDIR}" || mkdir -p ${OARHOMEDIR}
}

create_oar_user() {    
    # Create oar user
    if ! getent passwd | grep -q "^${OAROWNER}:"; then
        echo -n "Adding system user ${OAROWNER}.."
        case "$TARGET_DIST" in
            "debian")
                adduser --quiet \
                        --system \
                        --ingroup ${OAROWNERGROUP} \
                        --shell /bin/bash \
                        --no-create-home \
                        --disabled-password \
                        ${OAROWNER} 2>/dev/null || true
                ;;
            *)
                useradd --system \
                        --gid ${OAROWNERGROUP} \
                        --shell /bin/bash \
                        --password "*" \
                        ${OAROWNER} >/dev/null 2>&1
                passwd -u ${OAROWNER} >/dev/null 2>&1 ||true
                ;;
        esac
        echo "..done"
    fi

    # Adjust the password entry
    usermod -d ${OARHOMEDIR} \
            -g ${OAROWNERGROUP} \
               ${OAROWNER}

    # Adjust the file and directory permissions
    case "$SETUP_TYPE" in
        "deb")
            if ! dpkg-statoverride --list ${OARHOMEDIR} >/dev/null; then
                chown $OAROWNER:$OAROWNERGROUP $OARHOMEDIR
                chmod u=rwx,g=rxs,o= $OARHOMEDIR
            fi
            ;;
        *)
            chown $OAROWNER:$OAROWNERGROUP $OARHOMEDIR
            chmod u=rwx,g=rxs,o= $OARHOMEDIR
            ;;
    esac

    # set OAR shell
    if [ "`getent passwd ${OAROWNER} |cut -f7 -d:`" != "${OARDIR}/oarsh_shell" ]; then 
        chsh -s ${OARDIR}/oarsh_shell ${OAROWNER} 
    fi 

    # Fix the bash profile
    cat > ${OARHOMEDIR}/.bash_oar <<EOF
#
# OAR bash environnement file for the oar user
#
# /!\ This file is automatically created at update installation/upgrade. 
#     Do not modify this file.
#

bash_oar() {
    # Prevent to be executed twice or more
    [ -n "\$OAR_BASHRC" ] && return

    export PATH="/usr/lib/oar/oardodo:\$PATH"
    OAR_BASHRC=yes
}

bash_oar
EOF
    # Default bash sourced file in a batch job (BASH_ENV)
    [ ! -f "${OARHOMEDIR}/.batch_job_bashrc" ] && cat > ${OARHOMEDIR}/.batch_job_bashrc <<EOF
#
# OAR bash environnement file for only the batch job users
#

source ~/.bashrc

EOF
    touch ${OARHOMEDIR}/.bash_profile
    touch ${OARHOMEDIR}/.bashrc
    if ! grep -q "${OARHOMEDIR}/.bash_oar" ${OARHOMEDIR}/.bash_profile 2> /dev/null; then
        echo '' >> ${OARHOMEDIR}/.bash_profile
        echo "[ -f ${OARHOMEDIR}/.bash_oar ] && . ${OARHOMEDIR}/.bash_oar" >> ${OARHOMEDIR}/.bash_profile
    fi
    if ! grep -q "${OARHOMEDIR}/.bash_oar" ${OARHOMEDIR}/.bashrc 2> /dev/null; then
        echo '' >> ${OARHOMEDIR}/.bashrc
        echo "[ -f ${OARHOMEDIR}/.bash_oar ] && . ${OARHOMEDIR}/.bash_oar" >> ${OARHOMEDIR}/.bashrc
    fi

    set_rights ${OARHOMEDIR} 0755 ${OARUSER} ${OAROWNERGROUP}
    chown ${OAROWNER}:${OAROWNERGROUP} ${OARHOMEDIR}/.bash_oar
    chown ${OAROWNER}:${OAROWNERGROUP} ${OARHOMEDIR}/.bash_profile
    chown ${OAROWNER}:${OAROWNERGROUP} ${OARHOMEDIR}/.bashrc
}

install_run_dir() {
    # nothing to do
    :
}

create_log_file() {
    # Log file
    touch ${LOGDIR}/oar.log && chown ${OAROWNER}:${ROOTGROUP} ${LOGDIR}/oar.log && chmod 0644 ${LOGDIR}/oar.log || true
}

common_setup() {

    # Update before 2.5.2: Fix a bug causing an empty ${OARHOMEDIR}/.bash_oar
    if [ -e ${OARHOMEDIR}/.bash_oar ] && [ -z "$(cat ${OARHOMEDIR}/.bash_oar)" ]; then
        rm -f ${OARHOMEDIR}/.bash_oar
    fi

    create_oar_group
    create_oar_home
    create_oar_user
    install_run_dir
    create_log_file

    mkdir -p ${OARCONFDIR}/

    install_conffile \
        ${SHAREDIR}/oar.conf \
        ${OARCONFDIR}/oar.conf \
        0600 ${OAROWNER}:${ROOTGROUP}

    install_conffile \
        ${SHAREDIR}/oarnodesetting_ssh \
        ${OARCONFDIR}/oarnodesetting_ssh \
        0755

    install_conffile \
        ${SHAREDIR}/update_cpuset_id.sh \
        ${OARCONFDIR}/update_cpuset_id.sh \
        0755

    set_rights ${BINDIR}/oarsh           6755 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}
    set_rights ${SBINDIR}/oarnodesetting 6750 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}

    set_rights ${OARDIR}/oardodo/oardodo 6750 ${ROOTUSER} ${OAROWNERGROUP}
    set_rights ${OARDIR}/oardodo         0755 ${ROOTUSER} ${OAROWNERGROUP}
}
