
set -e

#
# Variables defined during the oar installation process
#
PREFIX="/usr"
BINDIR="/usr/bin"
CGIDIR="/usr/lib/cgi-bin"
DOCDIR="/usr/share/doc/oar-server"
EXAMPLEDIR="/usr/share/doc/oar-server/examples"
ETCDIR="/etc"
OARCONFDIR="/etc/oar"
OARDIR="/usr/lib/oar"
SHAREDIR="/usr/share/oar/oar-server"
PERLLIBDIR="/usr/share/perl5"
RUNDIR="/var/run"
LOGDIR="/var/log"
MANDIR="/usr/share/man"
SBINDIR="/usr/sbin"
VARLIBDIR="/var/lib"
OARHOMEDIR="/var/lib/oar"
ROOTUSER="root"
ROOTGROUP="root"
OARDO_DEFAULTUSER="root"
OARDO_DEFAULTGROUP="oar"
OARUSER="oar"
OAROWNER="oar"
OAROWNERGROUP="oar"
WWWUSER="www-data"
APACHECONFDIR="/etc/apache2"
WWWROOTDIR="/var/www"
WWWDIR="/usr/share/oar-web-status"
XAUTHCMDPATH="/usr/bin/xauth"
OARSHCMD="oarsh_oardo"
INITDIR="/etc/init.d"
DEFAULTDIR="/etc/default"
SETUP_TYPE="deb"
TARGET_DIST="debian"
OARDOPATH="/bin:/sbin:/usr/bin:/usr/sbin:/usr/bin:/usr/sbin:/usr/lib/oar/oardodo"

#
# shared functions for oar setup files.
#

install_conffile() {

    
    case "${SETUP_TYPE}" in
        "deb")
            install_deb_conffile $*
            ;;
        "rpm")
            install_rpm_conffile $*
            ;;
        "tgz"|*)
            install_if_not_exist $*
            ;;
    esac

}


install_deb_conffile() {
    local src dst rights owner tmpfile package
    src=$1
    dst=$2
    rights=$3
    owner=$4

    # PACKAGE need to be defined in the postinst before calling *-setup.
    package=$PACKAGE

    ucf --debconf-ok --three-way $src $dst
    ucfr $package $dst

    if [ -n "$rights" ]; then
        chmod $rights $dst
    fi
    if [ -n "$owner" ]; then
        chown $owner $dst
    fi
    
    if [ -f "$tmpfile" ]; then
        rm -f "$tmpfile"
    fi
}

install_rpm_conffile() {
    # I've not found ucf or equivalent to install config file during postinst
    # in the rpm world. So the config file are nstalled manually in the spec
    # file.

    local src dst rights owner tmpfile
    src=$1
    dst=$2
    rights=$3
    owner=$4
    
    if [ -n "$rights" ]; then
        chmod $rights $dst
    fi
    if [ -n "$owner" ]; then
        chown $owner $dst
    fi
}

install_if_not_exist() {
    local src dst rights owner
    src=$1
    dst=$2
    rights=$3
    owner=$4

        
    # Decompress the file, if compressed
    tmpfile=
    if [ ! -f "$src" ] && [ -f "${src}.gz" ]; then
        tmpfile=$(tempfile)
        zcat ${src}.gz > $tmpfile
        src=$tmpfile
    fi

    if [ -f "$dst" ]; then 
        :
    else 
        install $src $dst
        if [ -n "$rights" ]; then
            chmod $rights $dst
        fi
        if [ -n "$owner" ]; then
            chown $owner $dst
        fi
    fi
    
    if [ -f "$tmpfile" ]; then
        rm -f "$tmpfile"
    fi
}

set_rights() {
  file=$1
  perms=$2
  owner=$3
  group=$4

  [ -n "$owner" ] && chown $owner $file
  [ -n "$group" ] && chgrp $group $file
  [ -n "$perms" ] && chmod $perms $file
}


setup_oar_ssh() {
    if [ ! -e ${OARHOMEDIR}/.ssh ]; then
        mkdir -p ${OARHOMEDIR}/.ssh
        ssh-keygen -t rsa -q -f ${OARHOMEDIR}/.ssh/id_rsa -N '' || true
        echo -n 'environment="OAR_KEY=1" ' > ${OARHOMEDIR}/.ssh/authorized_keys || true
        cat ${OARHOMEDIR}/.ssh/id_rsa.pub >> ${OARHOMEDIR}/.ssh/authorized_keys || true
        cat <<-EOF > ${OARHOMEDIR}/.ssh/config || true
	Host *
	ForwardX11 no
	StrictHostKeyChecking no
	PasswordAuthentication no
	AddressFamily inet
	EOF
        chown ${OAROWNER}:${OAROWNERGROUP} ${OARHOMEDIR}/.ssh -R || true
    fi
}

create_phoenix_home() {
    mkdir -p ${OARHOMEDIR}/phoenix
    chown ${OAROWNER}:${OAROWNERGROUP} ${OARHOMEDIR}/phoenix
}

server_setup() {
    install_conffile \
        ${SHAREDIR}/job_resource_manager.pl \
        ${OARCONFDIR}/job_resource_manager.pl \
        0644

    install_conffile \
        ${SHAREDIR}/job_resource_manager_cgroups.pl \
        ${OARCONFDIR}/job_resource_manager_cgroups.pl \
        0644

    install_conffile \
        ${SHAREDIR}/suspend_resume_manager.pl \
        ${OARCONFDIR}/suspend_resume_manager.pl \
        0644

    install_conffile \
        ${SHAREDIR}/oarmonitor_sensor.pl \
        ${OARCONFDIR}/oarmonitor_sensor.pl \
        0644

    install_conffile \
        ${SHAREDIR}/wake_up_nodes.sh \
        ${OARCONFDIR}/wake_up_nodes.sh

    install_conffile \
        ${SHAREDIR}/shut_down_nodes.sh \
        ${OARCONFDIR}/shut_down_nodes.sh

    install_conffile \
        ${SHAREDIR}/server_prologue \
        ${OARCONFDIR}/server_prologue \
        0755

    install_conffile \
        ${SHAREDIR}/server_epilogue \
        ${OARCONFDIR}/server_epilogue \
        0755

    install_conffile \
        ${SHAREDIR}/scheduler_quotas.conf \
        ${OARCONFDIR}/scheduler_quotas.conf

    setup_oar_ssh
    create_phoenix_home

    set_rights ${SBINDIR}/oar_resources_init 6750 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}
    set_rights ${SBINDIR}/Almighty           6750 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}
    set_rights ${SBINDIR}/oarnotify          6750 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}
    set_rights ${SBINDIR}/oarremoveresource  6750 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}
    set_rights ${SBINDIR}/oaraccounting      6750 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}
    set_rights ${SBINDIR}/oarproperty        6750 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}
    set_rights ${SBINDIR}/oarmonitor         6750 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}
    set_rights ${SBINDIR}/oar_resources_init 6750 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}
    set_rights ${SBINDIR}/oar_phoenix        6750 ${OARDO_DEFAULTUSER} ${OARDO_DEFAULTGROUP}

}
