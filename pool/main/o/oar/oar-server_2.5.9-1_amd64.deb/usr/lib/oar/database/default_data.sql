INSERT INTO queues (queue_name, priority, scheduler_policy) VALUES ('admin','10','oar_sched_gantt_with_timesharing_and_fairsharing_and_quotas');
INSERT INTO queues (queue_name, priority, scheduler_policy) VALUES ('default','2','oar_sched_gantt_with_timesharing_and_fairsharing_and_quotas');
INSERT INTO queues (queue_name, priority, scheduler_policy) VALUES ('besteffort','0','oar_sched_gantt_with_timesharing_and_fairsharing_and_quotas');
INSERT INTO gantt_jobs_predictions (moldable_job_id , start_time) VALUES ('0','0');
