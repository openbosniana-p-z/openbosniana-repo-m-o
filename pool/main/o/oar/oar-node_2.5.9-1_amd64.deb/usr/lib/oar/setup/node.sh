
set -e

#
# Variables defined during the oar installation process
#
PREFIX="/usr"
BINDIR="/usr/bin"
CGIDIR="/usr/lib/cgi-bin"
DOCDIR="/usr/share/doc/oar-node"
EXAMPLEDIR="/usr/share/doc/oar-node/examples"
ETCDIR="/etc"
OARCONFDIR="/etc/oar"
OARDIR="/usr/lib/oar"
SHAREDIR="/usr/share/oar/oar-node"
PERLLIBDIR="/usr/share/perl5"
RUNDIR="/var/run"
LOGDIR="/var/log"
MANDIR="/usr/share/man"
SBINDIR="/usr/sbin"
VARLIBDIR="/var/lib"
OARHOMEDIR="/var/lib/oar"
ROOTUSER="root"
ROOTGROUP="root"
OARDO_DEFAULTUSER="root"
OARDO_DEFAULTGROUP="oar"
OARUSER="oar"
OAROWNER="oar"
OAROWNERGROUP="oar"
WWWUSER="www-data"
APACHECONFDIR="/etc/apache2"
WWWROOTDIR="/var/www"
WWWDIR="/usr/share/oar-web-status"
XAUTHCMDPATH="/usr/bin/xauth"
OARSHCMD="oarsh_oardo"
INITDIR="/etc/init.d"
DEFAULTDIR="/etc/default"
SETUP_TYPE="deb"
TARGET_DIST="debian"
OARDOPATH="/bin:/sbin:/usr/bin:/usr/sbin:/usr/bin:/usr/sbin:/usr/lib/oar/oardodo"

#
# shared functions for oar setup files.
#

install_conffile() {

    
    case "${SETUP_TYPE}" in
        "deb")
            install_deb_conffile $*
            ;;
        "rpm")
            install_rpm_conffile $*
            ;;
        "tgz"|*)
            install_if_not_exist $*
            ;;
    esac

}


install_deb_conffile() {
    local src dst rights owner tmpfile package
    src=$1
    dst=$2
    rights=$3
    owner=$4

    # PACKAGE need to be defined in the postinst before calling *-setup.
    package=$PACKAGE

    ucf --debconf-ok --three-way $src $dst
    ucfr $package $dst

    if [ -n "$rights" ]; then
        chmod $rights $dst
    fi
    if [ -n "$owner" ]; then
        chown $owner $dst
    fi
    
    if [ -f "$tmpfile" ]; then
        rm -f "$tmpfile"
    fi
}

install_rpm_conffile() {
    # I've not found ucf or equivalent to install config file during postinst
    # in the rpm world. So the config file are nstalled manually in the spec
    # file.

    local src dst rights owner tmpfile
    src=$1
    dst=$2
    rights=$3
    owner=$4
    
    if [ -n "$rights" ]; then
        chmod $rights $dst
    fi
    if [ -n "$owner" ]; then
        chown $owner $dst
    fi
}

install_if_not_exist() {
    local src dst rights owner
    src=$1
    dst=$2
    rights=$3
    owner=$4

        
    # Decompress the file, if compressed
    tmpfile=
    if [ ! -f "$src" ] && [ -f "${src}.gz" ]; then
        tmpfile=$(tempfile)
        zcat ${src}.gz > $tmpfile
        src=$tmpfile
    fi

    if [ -f "$dst" ]; then 
        :
    else 
        install $src $dst
        if [ -n "$rights" ]; then
            chmod $rights $dst
        fi
        if [ -n "$owner" ]; then
            chown $owner $dst
        fi
    fi
    
    if [ -f "$tmpfile" ]; then
        rm -f "$tmpfile"
    fi
}

set_rights() {
  file=$1
  perms=$2
  owner=$3
  group=$4

  [ -n "$owner" ] && chown $owner $file
  [ -n "$group" ] && chgrp $group $file
  [ -n "$perms" ] && chmod $perms $file
}

install_ssh_host_keys() {
    if [ ! -r ${OARCONFDIR}/oar_ssh_host_rsa_key ]; then 
        rm -f ${OARCONFDIR}/oar_ssh_host_rsa_key.pub

        if [ -e "${ETCDIR}/ssh/ssh_host_rsa_key" ]; then
            install_if_not_exist \
                ${ETCDIR}/ssh/ssh_host_rsa_key \
                ${OARCONFDIR}/oar_ssh_host_rsa_key \
                0600
        
            install_if_not_exist \
                ${ETCDIR}/ssh/ssh_host_rsa_key.pub \
                ${OARCONFDIR}/oar_ssh_host_rsa_key.pub 
        fi

    fi

    if [ ! -r ${OARCONFDIR}/oar_ssh_host_dsa_key ]; then 
        rm -f ${OARCONFDIR}/oar_ssh_host_dsa_key.pub 

        if [ -e "${ETCDIR}/ssh/ssh_host_dsa_key" ]; then
            install_if_not_exist \
                ${ETCDIR}/ssh/ssh_host_dsa_key \
                ${OARCONFDIR}/oar_ssh_host_dsa_key \
                0600

            install_if_not_exist \
                ${ETCDIR}/ssh/ssh_host_dsa_key.pub \
                ${OARCONFDIR}/oar_ssh_host_dsa_key.pub
        fi 
    fi

    if [ ! "-d ${VARLIBDIR}/oar/.ssh/id_rsa" ] && [ ! "-d ${VARLIBDIR}/oar/.ssh/id_dsa" ]; then
        echo "
    ##########################################################################
    # node #
    ########
    #   You need to install the ssh keys (private and public) of the oar user
    #   into ${VARLIBDIR}/oar/.ssh.
    #   A common way is to copy the entire .ssh directory from the server on 
    #   all the nodes of your cluster.
    ##########################################################################
    "
    fi
}

node_setup() {
    install_conffile \
        ${SHAREDIR}/epilogue \
        ${OARCONFDIR}/epilogue \
        0755
    
    install_conffile \
        ${SHAREDIR}/prologue \
        ${OARCONFDIR}/prologue \
        0755

    install_conffile \
        ${SHAREDIR}/sshd_config \
        ${OARCONFDIR}/sshd_config \
        0600 ${OAROWNER}

    install_ssh_host_keys
}
