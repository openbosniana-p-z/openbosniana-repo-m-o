var annotated_dup =
[
    [ "opengv", "namespaceopengv.html", [
      [ "absolute_pose", "namespaceopengv_1_1absolute__pose.html", [
        [ "AbsoluteAdapterBase", "classopengv_1_1absolute__pose_1_1AbsoluteAdapterBase.html", "classopengv_1_1absolute__pose_1_1AbsoluteAdapterBase" ],
        [ "AbsoluteMultiAdapterBase", "classopengv_1_1absolute__pose_1_1AbsoluteMultiAdapterBase.html", "classopengv_1_1absolute__pose_1_1AbsoluteMultiAdapterBase" ],
        [ "CentralAbsoluteAdapter", "classopengv_1_1absolute__pose_1_1CentralAbsoluteAdapter.html", "classopengv_1_1absolute__pose_1_1CentralAbsoluteAdapter" ],
        [ "MACentralAbsolute", "classopengv_1_1absolute__pose_1_1MACentralAbsolute.html", "classopengv_1_1absolute__pose_1_1MACentralAbsolute" ],
        [ "MANoncentralAbsolute", "classopengv_1_1absolute__pose_1_1MANoncentralAbsolute.html", "classopengv_1_1absolute__pose_1_1MANoncentralAbsolute" ],
        [ "NoncentralAbsoluteAdapter", "classopengv_1_1absolute__pose_1_1NoncentralAbsoluteAdapter.html", "classopengv_1_1absolute__pose_1_1NoncentralAbsoluteAdapter" ],
        [ "NoncentralAbsoluteMultiAdapter", "classopengv_1_1absolute__pose_1_1NoncentralAbsoluteMultiAdapter.html", "classopengv_1_1absolute__pose_1_1NoncentralAbsoluteMultiAdapter" ]
      ] ],
      [ "math", "namespaceopengv_1_1math.html", [
        [ "Bracket", "classopengv_1_1math_1_1Bracket.html", null ],
        [ "Sturm", "classopengv_1_1math_1_1Sturm.html", "classopengv_1_1math_1_1Sturm" ]
      ] ],
      [ "point_cloud", "namespaceopengv_1_1point__cloud.html", [
        [ "MAPointCloud", "classopengv_1_1point__cloud_1_1MAPointCloud.html", "classopengv_1_1point__cloud_1_1MAPointCloud" ],
        [ "PointCloudAdapter", "classopengv_1_1point__cloud_1_1PointCloudAdapter.html", "classopengv_1_1point__cloud_1_1PointCloudAdapter" ],
        [ "PointCloudAdapterBase", "classopengv_1_1point__cloud_1_1PointCloudAdapterBase.html", "classopengv_1_1point__cloud_1_1PointCloudAdapterBase" ]
      ] ],
      [ "relative_pose", "namespaceopengv_1_1relative__pose.html", [
        [ "CentralRelativeAdapter", "classopengv_1_1relative__pose_1_1CentralRelativeAdapter.html", "classopengv_1_1relative__pose_1_1CentralRelativeAdapter" ],
        [ "CentralRelativeMultiAdapter", "classopengv_1_1relative__pose_1_1CentralRelativeMultiAdapter.html", "classopengv_1_1relative__pose_1_1CentralRelativeMultiAdapter" ],
        [ "CentralRelativeWeightingAdapter", "classopengv_1_1relative__pose_1_1CentralRelativeWeightingAdapter.html", "classopengv_1_1relative__pose_1_1CentralRelativeWeightingAdapter" ],
        [ "MACentralRelative", "classopengv_1_1relative__pose_1_1MACentralRelative.html", "classopengv_1_1relative__pose_1_1MACentralRelative" ],
        [ "MANoncentralRelative", "classopengv_1_1relative__pose_1_1MANoncentralRelative.html", "classopengv_1_1relative__pose_1_1MANoncentralRelative" ],
        [ "MANoncentralRelativeMulti", "classopengv_1_1relative__pose_1_1MANoncentralRelativeMulti.html", "classopengv_1_1relative__pose_1_1MANoncentralRelativeMulti" ],
        [ "NoncentralRelativeAdapter", "classopengv_1_1relative__pose_1_1NoncentralRelativeAdapter.html", "classopengv_1_1relative__pose_1_1NoncentralRelativeAdapter" ],
        [ "NoncentralRelativeMultiAdapter", "classopengv_1_1relative__pose_1_1NoncentralRelativeMultiAdapter.html", "classopengv_1_1relative__pose_1_1NoncentralRelativeMultiAdapter" ],
        [ "RelativeAdapterBase", "classopengv_1_1relative__pose_1_1RelativeAdapterBase.html", "classopengv_1_1relative__pose_1_1RelativeAdapterBase" ],
        [ "RelativeMultiAdapterBase", "classopengv_1_1relative__pose_1_1RelativeMultiAdapterBase.html", "classopengv_1_1relative__pose_1_1RelativeMultiAdapterBase" ]
      ] ],
      [ "sac", "namespaceopengv_1_1sac.html", [
        [ "Lmeds", "classopengv_1_1sac_1_1Lmeds.html", "classopengv_1_1sac_1_1Lmeds" ],
        [ "MultiRansac", "classopengv_1_1sac_1_1MultiRansac.html", "classopengv_1_1sac_1_1MultiRansac" ],
        [ "MultiSampleConsensus", "classopengv_1_1sac_1_1MultiSampleConsensus.html", "classopengv_1_1sac_1_1MultiSampleConsensus" ],
        [ "MultiSampleConsensusProblem", "classopengv_1_1sac_1_1MultiSampleConsensusProblem.html", "classopengv_1_1sac_1_1MultiSampleConsensusProblem" ],
        [ "Ransac", "classopengv_1_1sac_1_1Ransac.html", "classopengv_1_1sac_1_1Ransac" ],
        [ "SampleConsensus", "classopengv_1_1sac_1_1SampleConsensus.html", "classopengv_1_1sac_1_1SampleConsensus" ],
        [ "SampleConsensusProblem", "classopengv_1_1sac_1_1SampleConsensusProblem.html", "classopengv_1_1sac_1_1SampleConsensusProblem" ]
      ] ],
      [ "sac_problems", "namespaceopengv_1_1sac__problems.html", [
        [ "absolute_pose", "namespaceopengv_1_1sac__problems_1_1absolute__pose.html", [
          [ "AbsolutePoseSacProblem", "classopengv_1_1sac__problems_1_1absolute__pose_1_1AbsolutePoseSacProblem.html", "classopengv_1_1sac__problems_1_1absolute__pose_1_1AbsolutePoseSacProblem" ],
          [ "MultiNoncentralAbsolutePoseSacProblem", "classopengv_1_1sac__problems_1_1absolute__pose_1_1MultiNoncentralAbsolutePoseSacProblem.html", "classopengv_1_1sac__problems_1_1absolute__pose_1_1MultiNoncentralAbsolutePoseSacProblem" ]
        ] ],
        [ "point_cloud", "namespaceopengv_1_1sac__problems_1_1point__cloud.html", [
          [ "PointCloudSacProblem", "classopengv_1_1sac__problems_1_1point__cloud_1_1PointCloudSacProblem.html", "classopengv_1_1sac__problems_1_1point__cloud_1_1PointCloudSacProblem" ]
        ] ],
        [ "relative_pose", "namespaceopengv_1_1sac__problems_1_1relative__pose.html", [
          [ "CentralRelativePoseSacProblem", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem" ],
          [ "EigensolverSacProblem", "classopengv_1_1sac__problems_1_1relative__pose_1_1EigensolverSacProblem.html", "classopengv_1_1sac__problems_1_1relative__pose_1_1EigensolverSacProblem" ],
          [ "MultiCentralRelativePoseSacProblem", "classopengv_1_1sac__problems_1_1relative__pose_1_1MultiCentralRelativePoseSacProblem.html", "classopengv_1_1sac__problems_1_1relative__pose_1_1MultiCentralRelativePoseSacProblem" ],
          [ "MultiNoncentralRelativePoseSacProblem", "classopengv_1_1sac__problems_1_1relative__pose_1_1MultiNoncentralRelativePoseSacProblem.html", "classopengv_1_1sac__problems_1_1relative__pose_1_1MultiNoncentralRelativePoseSacProblem" ],
          [ "NoncentralRelativePoseSacProblem", "classopengv_1_1sac__problems_1_1relative__pose_1_1NoncentralRelativePoseSacProblem.html", "classopengv_1_1sac__problems_1_1relative__pose_1_1NoncentralRelativePoseSacProblem" ],
          [ "RotationOnlySacProblem", "classopengv_1_1sac__problems_1_1relative__pose_1_1RotationOnlySacProblem.html", "classopengv_1_1sac__problems_1_1relative__pose_1_1RotationOnlySacProblem" ],
          [ "TranslationOnlySacProblem", "classopengv_1_1sac__problems_1_1relative__pose_1_1TranslationOnlySacProblem.html", "classopengv_1_1sac__problems_1_1relative__pose_1_1TranslationOnlySacProblem" ]
        ] ]
      ] ],
      [ "EigensolverOutput", "structopengv_1_1EigensolverOutput.html", "structopengv_1_1EigensolverOutput" ],
      [ "GeOutput", "structopengv_1_1GeOutput.html", "structopengv_1_1GeOutput" ],
      [ "Indices", "structopengv_1_1Indices.html", "structopengv_1_1Indices" ],
      [ "OptimizationFunctor", "structopengv_1_1OptimizationFunctor.html", "structopengv_1_1OptimizationFunctor" ]
    ] ]
];