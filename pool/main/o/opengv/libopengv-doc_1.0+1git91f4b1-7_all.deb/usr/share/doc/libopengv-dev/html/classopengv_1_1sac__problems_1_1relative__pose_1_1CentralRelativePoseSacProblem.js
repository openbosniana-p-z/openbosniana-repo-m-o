var classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem =
[
    [ "adapter_t", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#aa594ef47c87aab0e62f270209ed5d299", null ],
    [ "algorithm_t", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#a42af38e64d4cf8301e21e8de1a406eb1", null ],
    [ "model_t", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#a79c43371e4a8cdafe7f27c3940c5b60b", null ],
    [ "Algorithm", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#aa6899b90d7ed0d60ce7715bce402542d", [
      [ "STEWENIUS", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#aa6899b90d7ed0d60ce7715bce402542da88af5091c4d0d28e042e22809b0b28ae", null ],
      [ "NISTER", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#aa6899b90d7ed0d60ce7715bce402542daaa4fc7408d878a6cc6db29b09705e679", null ],
      [ "SEVENPT", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#aa6899b90d7ed0d60ce7715bce402542dace1951175972334d115e0cef54cdee7f", null ],
      [ "EIGHTPT", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#aa6899b90d7ed0d60ce7715bce402542daf6aafb5c04c1cc3c91a29d3f6a828bbf", null ]
    ] ],
    [ "CentralRelativePoseSacProblem", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#adc835b94c23ce777b06250abb6ac9038", null ],
    [ "CentralRelativePoseSacProblem", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#ad8717bdc7128eaaafc5712bf4c06fd9a", null ],
    [ "~CentralRelativePoseSacProblem", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#a511dfd424822c2778232549d643a66e7", null ],
    [ "computeModelCoefficients", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#add5cd01adcebf369f8ab6ece003ff85d", null ],
    [ "getSampleSize", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#a1d5c1125b881606d6e7b4776914cccb8", null ],
    [ "getSelectedDistancesToModel", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#ae245d0d03daa712f679a8f02f66e79b1", null ],
    [ "optimizeModelCoefficients", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#aa55664a8ea28553ab79baa99f71833b7", null ],
    [ "_adapter", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#abf9ae5d2cf744c752d18f4c98d16df26", null ],
    [ "_algorithm", "classopengv_1_1sac__problems_1_1relative__pose_1_1CentralRelativePoseSacProblem.html#a49befb03013042e20d2c3e7f815db51d", null ]
];