var searchData=
[
  ['jacobiantype_0',['JacobianType',['../structopengv_1_1OptimizationFunctor.html#a68e680cdd69a26082a9c3487204afbd0',1,'opengv::OptimizationFunctor']]]
];
