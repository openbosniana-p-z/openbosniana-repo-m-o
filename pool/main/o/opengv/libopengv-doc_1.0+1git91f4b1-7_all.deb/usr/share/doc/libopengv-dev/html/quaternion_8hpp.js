var quaternion_8hpp =
[
    [ "quaternion2rot", "quaternion_8hpp.html#a4f3417e3cb24b6ef4f4c2579c8de2d4f", null ],
    [ "rot2quaternion", "quaternion_8hpp.html#aa434976a0b93505926704062753475e4", null ]
];