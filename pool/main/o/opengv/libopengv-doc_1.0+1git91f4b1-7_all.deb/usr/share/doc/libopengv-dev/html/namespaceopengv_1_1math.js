var namespaceopengv_1_1math =
[
    [ "Bracket", "classopengv_1_1math_1_1Bracket.html", null ],
    [ "Sturm", "classopengv_1_1math_1_1Sturm.html", "classopengv_1_1math_1_1Sturm" ],
    [ "arun", "namespaceopengv_1_1math.html#a5befeeb5e3bab769347254e5b1ac4053", null ],
    [ "arun_complete", "namespaceopengv_1_1math.html#aa42a135f601eba16a0a70df908f3daf2", null ],
    [ "cayley2rot", "namespaceopengv_1_1math.html#a44a3af7feda5d9b9de2c1b143e61049d", null ],
    [ "cayley2rot_reduced", "namespaceopengv_1_1math.html#a55cd18a70a99b064f5f624d216e5a476", null ],
    [ "gauss_jordan", "namespaceopengv_1_1math.html#ad51e30698f712ca60e9882f002af39d5", null ],
    [ "o3_roots", "namespaceopengv_1_1math.html#ab7b12fa23e67af69c6845a83c11bb361", null ],
    [ "o4_roots", "namespaceopengv_1_1math.html#a581bea36343b4aef2e3c3438d594f25a", null ],
    [ "o4_roots", "namespaceopengv_1_1math.html#ac1f856025e56a38fcd5eeb4f5bb96d56", null ],
    [ "quaternion2rot", "namespaceopengv_1_1math.html#a4f3417e3cb24b6ef4f4c2579c8de2d4f", null ],
    [ "rot2cayley", "namespaceopengv_1_1math.html#a5fff725c79e2f1fc80cc4d49e22523cb", null ],
    [ "rot2quaternion", "namespaceopengv_1_1math.html#aa434976a0b93505926704062753475e4", null ]
];