var searchData=
[
  ['bracketroots_0',['bracketRoots',['../classopengv_1_1math_1_1Sturm.html#a71699db06e82f2b74ce62cc941f1e97d',1,'opengv::math::Sturm']]]
];
