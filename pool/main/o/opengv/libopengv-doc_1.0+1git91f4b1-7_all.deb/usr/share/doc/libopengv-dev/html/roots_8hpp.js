var roots_8hpp =
[
    [ "o3_roots", "roots_8hpp.html#ab7b12fa23e67af69c6845a83c11bb361", null ],
    [ "o4_roots", "roots_8hpp.html#a581bea36343b4aef2e3c3438d594f25a", null ],
    [ "o4_roots", "roots_8hpp.html#ac1f856025e56a38fcd5eeb4f5bb96d56", null ]
];