var dir_acafc96daba33e4690df22b2309f8fbf =
[
    [ "arun.hpp", "arun_8hpp.html", "arun_8hpp" ],
    [ "cayley.hpp", "cayley_8hpp.html", "cayley_8hpp" ],
    [ "gauss_jordan.hpp", "gauss__jordan_8hpp.html", "gauss__jordan_8hpp" ],
    [ "quaternion.hpp", "quaternion_8hpp.html", "quaternion_8hpp" ],
    [ "roots.hpp", "roots_8hpp.html", "roots_8hpp" ],
    [ "Sturm.hpp", "Sturm_8hpp.html", "Sturm_8hpp" ]
];