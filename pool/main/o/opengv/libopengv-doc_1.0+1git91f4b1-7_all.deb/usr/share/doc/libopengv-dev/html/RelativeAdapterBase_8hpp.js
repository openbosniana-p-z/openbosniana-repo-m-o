var RelativeAdapterBase_8hpp =
[
    [ "opengv::relative_pose::RelativeAdapterBase", "classopengv_1_1relative__pose_1_1RelativeAdapterBase.html", "classopengv_1_1relative__pose_1_1RelativeAdapterBase" ]
];