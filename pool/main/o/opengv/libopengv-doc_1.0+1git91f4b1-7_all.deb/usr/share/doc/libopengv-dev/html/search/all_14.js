var searchData=
[
  ['upnp_0',['upnp',['../namespaceopengv_1_1absolute__pose.html#af5b8a22250c87666eea6b3aac4a60163',1,'opengv::absolute_pose::upnp(const AbsoluteAdapterBase &amp;adapter)'],['../namespaceopengv_1_1absolute__pose.html#a7a7c07204fa474c087fa5d2b9785c85e',1,'opengv::absolute_pose::upnp(const AbsoluteAdapterBase &amp;adapter, const std::vector&lt; int &gt; &amp;indices)']]]
];
