var OptimizationFunctor_8hpp =
[
    [ "opengv::OptimizationFunctor< _Scalar, NX, NY >", "structopengv_1_1OptimizationFunctor.html", "structopengv_1_1OptimizationFunctor" ]
];