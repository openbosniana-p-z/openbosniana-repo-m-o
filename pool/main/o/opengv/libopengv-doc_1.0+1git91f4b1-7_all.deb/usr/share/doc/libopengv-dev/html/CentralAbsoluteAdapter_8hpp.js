var CentralAbsoluteAdapter_8hpp =
[
    [ "opengv::absolute_pose::CentralAbsoluteAdapter", "classopengv_1_1absolute__pose_1_1CentralAbsoluteAdapter.html", "classopengv_1_1absolute__pose_1_1CentralAbsoluteAdapter" ]
];