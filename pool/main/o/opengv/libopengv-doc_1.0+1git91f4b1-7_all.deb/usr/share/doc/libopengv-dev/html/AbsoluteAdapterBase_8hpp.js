var AbsoluteAdapterBase_8hpp =
[
    [ "opengv::absolute_pose::AbsoluteAdapterBase", "classopengv_1_1absolute__pose_1_1AbsoluteAdapterBase.html", "classopengv_1_1absolute__pose_1_1AbsoluteAdapterBase" ]
];