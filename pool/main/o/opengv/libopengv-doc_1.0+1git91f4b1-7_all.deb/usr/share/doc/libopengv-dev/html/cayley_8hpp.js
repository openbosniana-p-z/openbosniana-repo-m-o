var cayley_8hpp =
[
    [ "cayley2rot", "cayley_8hpp.html#a44a3af7feda5d9b9de2c1b143e61049d", null ],
    [ "cayley2rot_reduced", "cayley_8hpp.html#a55cd18a70a99b064f5f624d216e5a476", null ],
    [ "rot2cayley", "cayley_8hpp.html#a5fff725c79e2f1fc80cc4d49e22523cb", null ]
];