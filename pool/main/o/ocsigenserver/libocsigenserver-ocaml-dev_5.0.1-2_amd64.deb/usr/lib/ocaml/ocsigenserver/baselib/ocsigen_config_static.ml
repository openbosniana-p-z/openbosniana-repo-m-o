(* Warning! ocsigen_config_static.ml is generated automatically from
   ocsigen_config_static.ml.in! Do not modify it manually *)
(* Ocsigen
 * Copyright (C) 2005 Vincent Balat
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, with linking exception;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *)

let version_number = "4.0.1"
let config_file = ref "/etc/ocsigenserver/ocsigenserver.conf"
let is_native = Sys.backend_type = Sys.Native
let logdir = ref (Some "/var/log/ocsigenserver")
let default_user = ref "ocsigen"
let default_group = ref "ocsigen"
let mimefile = ref "/etc/ocsigenserver/mime.types"
let datadir = ref "/var/lib/ocsigenserver"
let bindir = ref "/usr/bin"
let extdir = ref "/usr/lib/ocaml/ocsigenserver/extensions"
let command_pipe = ref "/var/run/ocsigenserver_command"
let builtin_packages =
  List.fold_left
    (fun a s -> Ocsigen_lib.String.Set.add s a)
    Ocsigen_lib.String.Set.empty
    ["unix";"bigarray";"bytes";"lwt";"ocplib-endian";"ocplib-endian.bigstring";"threads";"lwt.unix";"ssl";"lwt_ssl";"lwt_log.core";"lwt_log";"domain-name";"macaddr";"ipaddr";"findlib.internal";"findlib";"zarith";"cryptokit";"pcre";"str";"xml-light";"dynlink";"base64";"sexplib0";"ppx_sexp_conv.runtime-lib";"seq";"re";"stringext";"bigstringaf";"angstrom";"uri";"uri-sexp";"cohttp";"logs";"logs.lwt";"cohttp-lwt";"astring";"ipaddr-sexp";"base.caml";"parsexp";"sexplib";"conduit";"conduit-lwt";"ipaddr.unix";"uri.services";"conduit-lwt-unix";"fmt";"logs.fmt";"magic-mime";"cohttp-lwt-unix";"hmap"; "ocsigenserver.polytables"; "ocsigenserver.cookies"; "ocsigenserver.baselib.base"; "ocsigenserver.baselib"; "ocsigenserver.http"; "ocsigenserver"; ]
