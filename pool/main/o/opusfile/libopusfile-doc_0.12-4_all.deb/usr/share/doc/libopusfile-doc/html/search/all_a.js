var searchData=
[
  ['name_0',['name',['../structOpusServerInfo.html#a6c1e013bd64991b75709ef1d76f962b6',1,'OpusServerInfo']]]
];
