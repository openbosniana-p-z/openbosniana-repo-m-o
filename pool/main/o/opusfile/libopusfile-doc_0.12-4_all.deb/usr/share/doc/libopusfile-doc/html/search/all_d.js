var searchData=
[
  ['read_0',['read',['../structOpusFileCallbacks.html#a602ea09a84743a8f4fdc76ab7c0b6ee6',1,'OpusFileCallbacks']]]
];
