var indexSectionsWithContent =
{
  0: "abcdefghimnoprstuvw",
  1: "o",
  2: "bcdfghimnoprstuvw",
  3: "adehosu",
  4: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables",
  3: "groups",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Variables",
  3: "Modules",
  4: "Pages"
};

