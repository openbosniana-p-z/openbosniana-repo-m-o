var searchData=
[
  ['bitrate_5fkbps_0',['bitrate_kbps',['../structOpusServerInfo.html#a1cf5db210f1cad5cf809bf54ddff68de',1,'OpusServerInfo']]]
];
