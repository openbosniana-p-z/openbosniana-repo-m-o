var searchData=
[
  ['tell_0',['tell',['../structOpusFileCallbacks.html#a1464ae2f33850101add14a7eb278ff1c',1,'OpusFileCallbacks']]],
  ['type_1',['type',['../structOpusPictureTag.html#a6e668caeb395b1ec7d438d4a4a9fa845',1,'OpusPictureTag']]]
];
