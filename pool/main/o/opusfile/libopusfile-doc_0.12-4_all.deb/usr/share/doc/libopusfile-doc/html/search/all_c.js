var searchData=
[
  ['pre_5fskip_0',['pre_skip',['../structOpusHead.html#ab448d3d3289d99f01dca8f19e878d57f',1,'OpusHead']]]
];
