var searchData=
[
  ['opening_20and_20closing_0',['Opening and Closing',['../group__stream__open__close.html',1,'']]],
  ['opusfile_1',['opusfile',['../index.html',1,'']]],
  ['opusfilecallbacks_2',['OpusFileCallbacks',['../structOpusFileCallbacks.html',1,'']]],
  ['opushead_3',['OpusHead',['../structOpusHead.html',1,'']]],
  ['opuspicturetag_4',['OpusPictureTag',['../structOpusPictureTag.html',1,'']]],
  ['opusserverinfo_5',['OpusServerInfo',['../structOpusServerInfo.html',1,'']]],
  ['opustags_6',['OpusTags',['../structOpusTags.html',1,'']]],
  ['output_5fgain_7',['output_gain',['../structOpusHead.html#a1f1c9e144ab05fe281f088d3e73eeab2',1,'OpusHead']]]
];
