var searchData=
[
  ['mapping_0',['mapping',['../structOpusHead.html#ac6372a8a1729b034308bae47253d94b7',1,'OpusHead']]],
  ['mapping_5ffamily_1',['mapping_family',['../structOpusHead.html#a338268b4264e059ae9ede890e6177304',1,'OpusHead']]],
  ['mime_5ftype_2',['mime_type',['../structOpusPictureTag.html#ace7f4978d815b186f6aebefed938c9e2',1,'OpusPictureTag']]]
];
