var searchData=
[
  ['seek_0',['seek',['../structOpusFileCallbacks.html#acf98bb1d13f75d3770206a398be05c8f',1,'OpusFileCallbacks']]],
  ['seeking_1',['Seeking',['../group__stream__seeking.html',1,'']]],
  ['server_2',['server',['../structOpusServerInfo.html#a7aa583abd214ca9cefab6c1c99097202',1,'OpusServerInfo']]],
  ['stream_20information_3',['Stream Information',['../group__stream__info.html',1,'']]],
  ['stream_5fcount_4',['stream_count',['../structOpusHead.html#a241b040792d2181f3ff6fa7e9911ac40',1,'OpusHead']]]
];
