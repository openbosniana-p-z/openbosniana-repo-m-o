var searchData=
[
  ['input_5fsample_5frate_0',['input_sample_rate',['../structOpusHead.html#a73b80a913eca33d829f1667caee80d9e',1,'OpusHead']]],
  ['is_5fpublic_1',['is_public',['../structOpusServerInfo.html#a9e81d2992f3009847c30bb4b0dc5c7de',1,'OpusServerInfo']]],
  ['is_5fssl_2',['is_ssl',['../structOpusServerInfo.html#a3bce31c0a77548625a4d8125251e9b11',1,'OpusServerInfo']]]
];
