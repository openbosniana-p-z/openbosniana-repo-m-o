var searchData=
[
  ['format_0',['format',['../structOpusPictureTag.html#aba2d71a09ecf0999cf5faf7c2276fb37',1,'OpusPictureTag']]]
];
