var searchData=
[
  ['opening_20and_20closing_0',['Opening and Closing',['../group__stream__open__close.html',1,'']]]
];
