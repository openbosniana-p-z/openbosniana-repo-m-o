var searchData=
[
  ['output_5fgain_0',['output_gain',['../structOpusHead.html#a1f1c9e144ab05fe281f088d3e73eeab2',1,'OpusHead']]]
];
