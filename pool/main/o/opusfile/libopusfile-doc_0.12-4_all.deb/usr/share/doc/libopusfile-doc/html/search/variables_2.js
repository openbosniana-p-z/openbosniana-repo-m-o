var searchData=
[
  ['data_0',['data',['../structOpusPictureTag.html#a0514cb1431547c8b3042b9f3bc9b694f',1,'OpusPictureTag']]],
  ['data_5flength_1',['data_length',['../structOpusPictureTag.html#aaa458d48cd3c9c86b54614389f5b726d',1,'OpusPictureTag']]],
  ['depth_2',['depth',['../structOpusPictureTag.html#a9af23c314edf9a995c95a4d28f49eac0',1,'OpusPictureTag']]],
  ['description_3',['description',['../structOpusPictureTag.html#aa32d8bfcd831aa218b0de6d6af92dc08',1,'OpusPictureTag::description()'],['../structOpusServerInfo.html#ab16d58f0d67d6473e12629676e2641ca',1,'OpusServerInfo::description()']]]
];
