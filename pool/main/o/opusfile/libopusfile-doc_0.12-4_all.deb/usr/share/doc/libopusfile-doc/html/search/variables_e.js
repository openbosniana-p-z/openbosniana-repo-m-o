var searchData=
[
  ['url_0',['url',['../structOpusServerInfo.html#a7f9aef47413c849bb240ef70394401b1',1,'OpusServerInfo']]],
  ['user_5fcomments_1',['user_comments',['../structOpusTags.html#ad53d571bd8b23691089242e4e161358a',1,'OpusTags']]]
];
