var searchData=
[
  ['vendor_0',['vendor',['../structOpusTags.html#af6ff133dfd801934d981bc5905dae0bd',1,'OpusTags']]],
  ['version_1',['version',['../structOpusHead.html#a9b0e040fc6404ddc2b1fdbccf505f71e',1,'OpusHead']]]
];
