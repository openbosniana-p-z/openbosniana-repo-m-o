var searchData=
[
  ['abstract_20stream_20reading_20interface_0',['Abstract Stream Reading Interface',['../group__stream__callbacks.html',1,'']]]
];
