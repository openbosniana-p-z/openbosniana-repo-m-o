var searchData=
[
  ['genre_0',['genre',['../structOpusServerInfo.html#a293431ddf20c3baa3a4751ad08f518bb',1,'OpusServerInfo']]]
];
