var searchData=
[
  ['seek_0',['seek',['../structOpusFileCallbacks.html#acf98bb1d13f75d3770206a398be05c8f',1,'OpusFileCallbacks']]],
  ['server_1',['server',['../structOpusServerInfo.html#a7aa583abd214ca9cefab6c1c99097202',1,'OpusServerInfo']]],
  ['stream_5fcount_2',['stream_count',['../structOpusHead.html#a241b040792d2181f3ff6fa7e9911ac40',1,'OpusHead']]]
];
