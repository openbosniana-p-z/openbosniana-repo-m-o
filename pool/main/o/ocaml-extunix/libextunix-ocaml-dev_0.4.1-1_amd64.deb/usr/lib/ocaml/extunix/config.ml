(** @return whether feature is available *)
let feature = function
| "EVENTFD" -> Some true
| "ATFILE" -> Some true
| "DIRFD" -> Some true
| "STATVFS" -> Some true
| "FSTATVFS" -> Some true
| "SIOCGIFCONF" -> Some true
| "IFADDRS" -> Some true
| "INET_NTOA" -> Some true
| "INET_NTOP" -> Some true
| "UNAME" -> Some true
| "FADVISE" -> Some true
| "FALLOCATE" -> Some true
| "TTY_IOCTL" -> Some true
| "TTYNAME" -> Some true
| "CTERMID" -> Some true
| "GETTID" -> Some true
| "PGID" -> Some true
| "SETREUID" -> Some true
| "FSYNC" -> Some true
| "FDATASYNC" -> Some true
| "SYNC" -> Some true
| "SYNCFS" -> Some true
| "REALPATH" -> Some true
| "SIGNALFD" -> Some true
| "PTRACE" -> Some true
| "RESOURCE" -> Some true
| "MLOCKALL" -> Some true
| "STRPTIME" -> Some true
| "STRTIME" -> Some true
| "TIMEZONE" -> Some true
| "TIMEGM" -> Some true
| "PTS" -> Some true
| "FCNTL" -> Some true
| "TCPGRP" -> Some true
| "EXECINFO" -> Some true
| "SETENV" -> Some true
| "CLEARENV" -> Some true
| "MKDTEMP" -> Some true
| "MALLOC_INFO" -> Some true
| "MALLOC_STATS" -> Some true
| "MEMALIGN" -> Some true
| "ENDIAN" -> Some true
| "READ_CREDENTIALS" -> Some true
| "FEXECVE" -> Some true
| "SENDMSG" -> Some true
| "PREAD" -> Some true
| "PWRITE" -> Some true
| "READ" -> Some true
| "WRITE" -> Some true
| "MKSTEMPS" -> Some true
| "MKOSTEMPS" -> Some true
| "SETRESUID" -> Some true
| "SYSCONF" -> Some true
| "SPLICE" -> Some true
| "TEE" -> Some true
| "VMSPLICE" -> Some true
| "SOCKOPT" -> Some true
| "TCP_KEEPIDLE" -> Some true
| "TCP_KEEPCNT" -> Some true
| "TCP_KEEPINTVL" -> Some true
| "SO_REUSEPORT" -> Some true
| "POLL" -> Some true
| "SYSINFO" -> Some true
| "MCHECK" -> Some true
| "MOUNT" -> Some true
| "UNSHARE" -> Some true
| "CHROOT" -> Some true
| "SYSLOG" -> Some true
| _ -> None

(** @return whether feature is available *)
let have = function
| `EVENTFD -> true
| `ATFILE -> true
| `DIRFD -> true
| `STATVFS -> true
| `FSTATVFS -> true
| `SIOCGIFCONF -> true
| `IFADDRS -> true
| `INET_NTOA -> true
| `INET_NTOP -> true
| `UNAME -> true
| `FADVISE -> true
| `FALLOCATE -> true
| `TTY_IOCTL -> true
| `TTYNAME -> true
| `CTERMID -> true
| `GETTID -> true
| `PGID -> true
| `SETREUID -> true
| `FSYNC -> true
| `FDATASYNC -> true
| `SYNC -> true
| `SYNCFS -> true
| `REALPATH -> true
| `SIGNALFD -> true
| `PTRACE -> true
| `RESOURCE -> true
| `MLOCKALL -> true
| `STRPTIME -> true
| `STRTIME -> true
| `TIMEZONE -> true
| `TIMEGM -> true
| `PTS -> true
| `FCNTL -> true
| `TCPGRP -> true
| `EXECINFO -> true
| `SETENV -> true
| `CLEARENV -> true
| `MKDTEMP -> true
| `MALLOC_INFO -> true
| `MALLOC_STATS -> true
| `MEMALIGN -> true
| `ENDIAN -> true
| `READ_CREDENTIALS -> true
| `FEXECVE -> true
| `SENDMSG -> true
| `PREAD -> true
| `PWRITE -> true
| `READ -> true
| `WRITE -> true
| `MKSTEMPS -> true
| `MKOSTEMPS -> true
| `SETRESUID -> true
| `SYSCONF -> true
| `SPLICE -> true
| `TEE -> true
| `VMSPLICE -> true
| `SOCKOPT -> true
| `TCP_KEEPIDLE -> true
| `TCP_KEEPCNT -> true
| `TCP_KEEPINTVL -> true
| `SO_REUSEPORT -> true
| `POLL -> true
| `SYSINFO -> true
| `MCHECK -> true
| `MOUNT -> true
| `UNSHARE -> true
| `CHROOT -> true
| `SYSLOG -> true
