(** @canonical ExtUnix.All *)
module All = ExtUnix__All


(** @canonical ExtUnix.Config *)
module Config = ExtUnix__Config


(** @canonical ExtUnix.Specific *)
module Specific = ExtUnix__Specific
