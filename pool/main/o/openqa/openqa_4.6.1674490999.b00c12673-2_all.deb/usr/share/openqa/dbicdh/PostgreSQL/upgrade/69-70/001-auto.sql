-- Convert schema '/hdd/openqa-devel/repos/openQA/script/../dbicdh/_source/deploy/69/001-auto.yml' to '/hdd/openqa-devel/repos/openQA/script/../dbicdh/_source/deploy/70/001-auto.yml':;

;
-- No differences found;

