// http://marcgg.com/blog/2015/01/05/css-animations-failing-capybara-specs/
$.fx.off = true;
