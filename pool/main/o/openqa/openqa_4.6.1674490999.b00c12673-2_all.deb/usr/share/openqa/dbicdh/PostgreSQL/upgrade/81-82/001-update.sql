update job_templates set name='' where name is null;
