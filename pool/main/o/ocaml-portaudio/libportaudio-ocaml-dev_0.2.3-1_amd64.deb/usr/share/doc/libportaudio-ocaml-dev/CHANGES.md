0.2.3 (02-01-2022)
=====
- Added `read_stream_available_frames` and `write_stream_available_frames` (#3).

0.2.2 (10-12-2020)
======

- Switch to dune!

0.2.1 (03-08-2015)
=====
- Switch to standard int32_t type.

0.2.0 (02-07-2011)
=====
Changes contributed by Niki Yoshiuchi:
- Added bigarray interface
- Added support for callbacks

0.1.3 (12-10-2009)
=====
- Added support for --enable-debugging configure option
- Added NO_CUSTOM to build in standard mode.
- Added prefix to main compilation variables if passed to configure.
- Makefile now honnors LIBDIRS variable for linking against libraries located in
  other places than then standard ones.

0.1.2 (16-04-2008)
=====
- More portable make invokation
- Install .cmx file

0.1.1 (19-11-2007)
=====
- Changed licence to LGPL+link exception

0.1.0 (17-10-2007)
=====
- Initial release
