var elasticity_8hpp =
[
    [ "Opm::Elasticity::Elasticity< GridType >", "classOpm_1_1Elasticity_1_1Elasticity.html", "classOpm_1_1Elasticity_1_1Elasticity" ],
    [ "waveSpeeds", "elasticity_8hpp.html#a67d615fc6a71d664cac01d8eec3c672c", null ]
];