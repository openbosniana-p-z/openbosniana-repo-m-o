var classOpm_1_1GIE_1_1Face =
[
    [ "area", "classOpm_1_1GIE_1_1Face.html#afb5b9fb9bfe4f1555165bec4aa107a52", null ],
    [ "boundary", "classOpm_1_1GIE_1_1Face.html#a6c66b149939f47823463a5861f4d4554", null ],
    [ "boundaryId", "classOpm_1_1GIE_1_1Face.html#a9e592ebbfec56a17de9164bd13a9009f", null ],
    [ "cell", "classOpm_1_1GIE_1_1Face.html#a7921a45c8ffde2426551474b6652bcd4", null ],
    [ "cellIndex", "classOpm_1_1GIE_1_1Face.html#a83310a52e9c91f169df9297e9b769a79", null ],
    [ "centroid", "classOpm_1_1GIE_1_1Face.html#a27dac8315a97cfc195abb1abd4bb11f4", null ],
    [ "index", "classOpm_1_1GIE_1_1Face.html#afe95b3c1f5da115c95ebb525a3a7aaf3", null ],
    [ "localIndex", "classOpm_1_1GIE_1_1Face.html#aa62c5244e67a8848ccd27c8831d5530a", null ],
    [ "neighbourCell", "classOpm_1_1GIE_1_1Face.html#a90509a7a5bd2da10f11826a95f4bc70e", null ],
    [ "neighbourCellIndex", "classOpm_1_1GIE_1_1Face.html#a617f082d3248e384b04166628920af7b", null ],
    [ "neighbourCellVolume", "classOpm_1_1GIE_1_1Face.html#ab936db4856d8748f31722896b4e58836", null ],
    [ "normal", "classOpm_1_1GIE_1_1Face.html#a2591f300979ece9b77ff329ea96f703b", null ]
];