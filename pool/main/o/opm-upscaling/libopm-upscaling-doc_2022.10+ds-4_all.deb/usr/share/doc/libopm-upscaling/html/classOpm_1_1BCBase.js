var classOpm_1_1BCBase =
[
    [ "BCType", "classOpm_1_1BCBase.html#a1e0e011cf92958ddaf44a00fc7f9f137", [
      [ "Dirichlet", "classOpm_1_1BCBase.html#a1e0e011cf92958ddaf44a00fc7f9f137af53e72b254a42d9418fb1c97248dacfd", null ],
      [ "Neumann", "classOpm_1_1BCBase.html#a1e0e011cf92958ddaf44a00fc7f9f137ae34a5ea5d6bc6cae8bca8fb042807f66", null ],
      [ "Periodic", "classOpm_1_1BCBase.html#a1e0e011cf92958ddaf44a00fc7f9f137acd09179e7f4eac5e711e41a4263f9700", null ]
    ] ],
    [ "BCBase", "classOpm_1_1BCBase.html#ac1c3a46ac937f623da56b31a195472cd", null ],
    [ "BCBase", "classOpm_1_1BCBase.html#ac7e470ebf320f0aaae0d813af64ffb3c", null ],
    [ "isDirichlet", "classOpm_1_1BCBase.html#ac7fa7b1441df0a0df00235f22f15a811", null ],
    [ "isNeumann", "classOpm_1_1BCBase.html#ae051d49c8945173ff1bfa6583008f42a", null ],
    [ "isPeriodic", "classOpm_1_1BCBase.html#aa566cd2c3fd7da2d2d951a8696bc0e05", null ],
    [ "write", "classOpm_1_1BCBase.html#ad3aa85fbeea13e549eb6fc8e54701d6f", null ]
];