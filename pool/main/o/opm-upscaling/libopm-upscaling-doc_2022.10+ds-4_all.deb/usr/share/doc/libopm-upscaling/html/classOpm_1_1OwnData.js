var classOpm_1_1OwnData =
[
    [ "OwnData", "classOpm_1_1OwnData.html#a183a635657539ccda60cff3821597589", null ],
    [ "data", "classOpm_1_1OwnData.html#a7a61cb0096c9746680f257000e2821ae", null ],
    [ "operator[]", "classOpm_1_1OwnData.html#a4c2dd83520af8e1e751a44712746df3f", null ],
    [ "size", "classOpm_1_1OwnData.html#ab1de6502f63db32dc538954133f00d4d", null ]
];