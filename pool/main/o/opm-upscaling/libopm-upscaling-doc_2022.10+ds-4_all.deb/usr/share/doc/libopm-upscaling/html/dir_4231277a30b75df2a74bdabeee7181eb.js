var dir_4231277a30b75df2a74bdabeee7181eb =
[
    [ "CornerpointChopper.hpp", "CornerpointChopper_8hpp_source.html", null ],
    [ "initCPGrid.hpp", "initCPGrid_8hpp_source.html", null ],
    [ "ParserAdditions.hpp", "ParserAdditions_8hpp_source.html", null ],
    [ "RelPermUtils.hpp", "RelPermUtils_8hpp_source.html", null ],
    [ "SinglePhaseUpscaler.hpp", "SinglePhaseUpscaler_8hpp_source.html", null ],
    [ "SteadyStateUpscaler.hpp", "SteadyStateUpscaler_8hpp_source.html", null ],
    [ "SteadyStateUpscaler_impl.hpp", "SteadyStateUpscaler__impl_8hpp_source.html", null ],
    [ "SteadyStateUpscalerImplicit.hpp", "SteadyStateUpscalerImplicit_8hpp_source.html", null ],
    [ "SteadyStateUpscalerImplicit_impl.hpp", "SteadyStateUpscalerImplicit__impl_8hpp_source.html", null ],
    [ "SteadyStateUpscalerManager.hpp", "SteadyStateUpscalerManager_8hpp_source.html", null ],
    [ "SteadyStateUpscalerManagerImplicit.hpp", "SteadyStateUpscalerManagerImplicit_8hpp_source.html", null ],
    [ "UpscalerBase.hpp", "UpscalerBase_8hpp_source.html", null ],
    [ "UpscalerBase_impl.hpp", "UpscalerBase__impl_8hpp_source.html", null ],
    [ "UpscalingTraits.hpp", "UpscalingTraits_8hpp_source.html", null ],
    [ "writeECLData.hpp", "writeECLData_8hpp_source.html", null ]
];