var classMeshColorizer =
[
    [ "MeshColorizer", "classMeshColorizer.html#a9e35222080258a217da7996614489d98", null ],
    [ "calcGroups", "classMeshColorizer.html#a6c76ee39f4aa488a7d9dc76e7a298934", null ],
    [ "operator[]", "classMeshColorizer.html#acd1e519a4856810be55a0d3eda18cc6a", null ]
];