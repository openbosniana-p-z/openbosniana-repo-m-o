var SinglePointUpwindTwoPhase_8hpp =
[
    [ "Opm::spu_2p::ModelParameterStorage", "classOpm_1_1spu__2p_1_1ModelParameterStorage.html", "classOpm_1_1spu__2p_1_1ModelParameterStorage" ],
    [ "Opm::SinglePointUpwindTwoPhase< TwophaseFluid >", "classOpm_1_1SinglePointUpwindTwoPhase.html", null ]
];