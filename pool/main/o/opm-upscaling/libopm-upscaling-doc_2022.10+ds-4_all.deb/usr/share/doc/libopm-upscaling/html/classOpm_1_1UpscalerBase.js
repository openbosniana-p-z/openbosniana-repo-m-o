var classOpm_1_1UpscalerBase =
[
    [ "permtensor_t", "classOpm_1_1UpscalerBase.html#a2e10ff3553ee0b6e0bcad45a2fb1f904", null ],
    [ "UpscalerBase", "classOpm_1_1UpscalerBase.html#aee5152acfa5b4e2d0c90bc2214c69288", null ],
    [ "grid", "classOpm_1_1UpscalerBase.html#a4275478d4f70879040f732403863be17", null ],
    [ "init", "classOpm_1_1UpscalerBase.html#a45a905e0f1787cfc53452c6be76c27dc", null ],
    [ "init", "classOpm_1_1UpscalerBase.html#abeba3d8d02303168de518e381e4b9fb3", null ],
    [ "setBoundaryConditionType", "classOpm_1_1UpscalerBase.html#ad3159f97d277f5f83634d4260f7e9d40", null ],
    [ "setPermeability", "classOpm_1_1UpscalerBase.html#a13493a7b2c4dc868e4fa6580fb90b4d7", null ],
    [ "upscaleNetPorosity", "classOpm_1_1UpscalerBase.html#addfd7edae3cf758a07309339ba0bff79", null ],
    [ "upscaleNTG", "classOpm_1_1UpscalerBase.html#a54f2e7a88d2907187c908d198b250815", null ],
    [ "upscalePorosity", "classOpm_1_1UpscalerBase.html#a1f3bc2558882b8789da99b5f47e4dbfe", null ],
    [ "upscaleSinglePhase", "classOpm_1_1UpscalerBase.html#a0795ef2c6b038c7e29df4aa58266da6e", null ],
    [ "upscaleSOWCR", "classOpm_1_1UpscalerBase.html#ab599370049e2842ec745c4c48db6e0de", null ],
    [ "upscaleSWCR", "classOpm_1_1UpscalerBase.html#ae46689f92c9148518beb6bc9aaa01e9f", null ]
];