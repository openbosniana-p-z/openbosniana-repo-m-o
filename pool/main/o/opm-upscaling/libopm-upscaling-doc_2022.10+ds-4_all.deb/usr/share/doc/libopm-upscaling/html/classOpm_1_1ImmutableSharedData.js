var classOpm_1_1ImmutableSharedData =
[
    [ "ImmutableSharedData", "classOpm_1_1ImmutableSharedData.html#a456a607a92e9a249f7df2cf3664d6b8e", null ],
    [ "data", "classOpm_1_1ImmutableSharedData.html#a11b8cc6105e4467c5e41d1a2f77cb3cb", null ],
    [ "operator[]", "classOpm_1_1ImmutableSharedData.html#a6a92aea944cffa064b1a1bd28e843870", null ],
    [ "size", "classOpm_1_1ImmutableSharedData.html#a83648dae5e3727c7990cf430f933c311", null ]
];