var classLoggerHelper =
[
    [ "LoggerHelper", "classLoggerHelper.html#ad466ba50b5425c0568a55066da8a4a5e", null ],
    [ "group", "classLoggerHelper.html#aa4b26832b11d1cc9835a5580aa4847a1", null ],
    [ "log", "classLoggerHelper.html#a712bc7cc5fee6d581bb145fcd2d68f21", null ],
    [ "groups", "classLoggerHelper.html#a14453459299c4d0321f529403a2bcf37", null ],
    [ "max", "classLoggerHelper.html#ae510c52f3aa42273df1dd3586e14ad9d", null ],
    [ "per_chunk", "classLoggerHelper.html#a502baa43e4367bee4c21dd3a3721e71c", null ]
];