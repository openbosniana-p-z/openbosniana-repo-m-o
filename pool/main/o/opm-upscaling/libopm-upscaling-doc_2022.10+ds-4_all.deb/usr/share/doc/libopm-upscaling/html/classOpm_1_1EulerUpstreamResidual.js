var classOpm_1_1EulerUpstreamResidual =
[
    [ "EulerUpstreamResidual", "classOpm_1_1EulerUpstreamResidual.html#a0d40dcca886de2a0b5eeb905d51bdee0", null ],
    [ "EulerUpstreamResidual", "classOpm_1_1EulerUpstreamResidual.html#a55f6fd622cd66174a4e01c72dba3ed63", null ]
];