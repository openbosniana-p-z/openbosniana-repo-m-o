var classOpm_1_1SharedData =
[
    [ "SharedData", "classOpm_1_1SharedData.html#aad5db252ceec36deb6644b7ec7348e42", null ],
    [ "data", "classOpm_1_1SharedData.html#ae9b3ed76592d44c42bf719e96ae89627", null ],
    [ "operator[]", "classOpm_1_1SharedData.html#a5e7310e8335866b49f9fd6c0000c4159", null ],
    [ "size", "classOpm_1_1SharedData.html#a6023a22d3a4c5db26d6d5f798a3bdb09", null ]
];