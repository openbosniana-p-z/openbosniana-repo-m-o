var classOpm_1_1Rock =
[
    [ "MutablePermTensor", "classOpm_1_1Rock.html#a1b7ea62a7d6d6a63db336a6b654c36d3", null ],
    [ "PermTensor", "classOpm_1_1Rock.html#a763f014c025f6f8e4fa7900cf1fa8998", null ],
    [ "SharedPermTensor", "classOpm_1_1Rock.html#a44a927de60df8b0fc8e584bc5ce8b5fa", null ],
    [ "Rock", "classOpm_1_1Rock.html#a7e7903b0cc3671f79aa08cce888bb1a9", null ],
    [ "init", "classOpm_1_1Rock.html#a72c43872dc307c4bf8c9e270ebf40b40", null ],
    [ "init", "classOpm_1_1Rock.html#ac23d8cfeada6a7a7ca44802aea01f18f", null ],
    [ "permeability", "classOpm_1_1Rock.html#a05c3895b1f5b873515aead306ae67a3f", null ],
    [ "permeabilityModifiable", "classOpm_1_1Rock.html#a1374ce13d1ad629dd9719b2a36706ec4", null ],
    [ "porosity", "classOpm_1_1Rock.html#ac21f08774a7a8fb01e4c9c7b801ba868", null ]
];