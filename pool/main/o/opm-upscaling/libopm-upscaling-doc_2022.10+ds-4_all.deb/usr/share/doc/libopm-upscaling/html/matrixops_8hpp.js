var matrixops_8hpp =
[
    [ "Opm::Elasticity::MatrixOps", "classOpm_1_1Elasticity_1_1MatrixOps.html", null ],
    [ "AdjacencyPattern", "matrixops_8hpp.html#a8ec8c383b7335afb9a561da18c3a1a1a", null ],
    [ "Matrix", "matrixops_8hpp.html#a2a875712726e40e7c5eb1b271e1c2a0a", null ],
    [ "Vector", "matrixops_8hpp.html#a3e64d0b05c66e3d299d0854024064473", null ]
];