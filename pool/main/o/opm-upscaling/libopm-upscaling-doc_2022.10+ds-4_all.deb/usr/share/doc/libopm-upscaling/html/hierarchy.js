var hierarchy =
[
    [ "Opm::ImplicitTransportDefault::AccumulationNorm< Vector, NormImpl >", "classOpm_1_1ImplicitTransportDefault_1_1AccumulationNorm.html", null ],
    [ "Opm::Elasticity::AMG1< Smoother >", "structOpm_1_1Elasticity_1_1AMG1.html", null ],
    [ "Opm::Elasticity::AMG2Level< Smoother >", "structOpm_1_1Elasticity_1_1AMG2Level.html", null ],
    [ "Opm::Anisotropic", "structOpm_1_1Anisotropic.html", null ],
    [ "ArithmeticAverage", "classArithmeticAverage.html", null ],
    [ "Opm::Elasticity::ASMHandler< GridType >", "classOpm_1_1Elasticity_1_1ASMHandler.html", null ],
    [ "Opm::BCBase< T >", "classOpm_1_1BCBase.html", null ],
    [ "Opm::BCBase< double >", "classOpm_1_1BCBase.html", [
      [ "Opm::FlowBC", "classOpm_1_1FlowBC.html", null ],
      [ "Opm::SatBC", "classOpm_1_1SatBC.html", null ]
    ] ],
    [ "Opm::BCBase< Dune::FieldVector< double, numComponents > >", "classOpm_1_1BCBase.html", [
      [ "Opm::SurfvolBC< numComponents >", "classOpm_1_1SurfvolBC.html", null ]
    ] ],
    [ "std::binary_function", null, [
      [ "Opm::ImplicitTransportDefault::Euclid< T >", "classOpm_1_1ImplicitTransportDefault_1_1Euclid.html", null ],
      [ "Opm::ImplicitTransportDefault::MaxAbs< T >", "classOpm_1_1ImplicitTransportDefault_1_1MaxAbs.html", null ],
      [ "Opm::ImplicitTransportDefault::SumAbs< T >", "classOpm_1_1ImplicitTransportDefault_1_1SumAbs.html", null ]
    ] ],
    [ "Opm::BoundaryFaceInfo", "structOpm_1_1BoundaryFaceInfo.html", null ],
    [ "Opm::Elasticity::BoundaryGrid", "classOpm_1_1Elasticity_1_1BoundaryGrid.html", null ],
    [ "Opm::Elasticity::BoundaryGrid::BoundedPredicate", "structOpm_1_1Elasticity_1_1BoundaryGrid_1_1BoundedPredicate.html", null ],
    [ "Opm::GIE::Cell< GridInterface, EntityType >", "classOpm_1_1GIE_1_1Cell.html", null ],
    [ "Opm::GIE::Cell< GridInterface, GridInterface::GridType::template Codim< 0 >::LeafIterator >", "classOpm_1_1GIE_1_1Cell.html", [
      [ "Opm::GIE::CellIterator< GridInterface >", "classOpm_1_1GIE_1_1CellIterator.html", null ]
    ] ],
    [ "Opm::CornerPointChopper", "classOpm_1_1CornerPointChopper.html", null ],
    [ "Opm::CpGridCellMapper", "structOpm_1_1CpGridCellMapper.html", null ],
    [ "Opm::Elasticity::MPC::DOF", "structOpm_1_1Elasticity_1_1MPC_1_1DOF.html", null ],
    [ "Opm::DummyVec< T >", "classOpm_1_1DummyVec.html", null ],
    [ "Opm::Elasticity::Elasticity< GridType >", "classOpm_1_1Elasticity_1_1Elasticity.html", null ],
    [ "Opm::Elasticity::ElasticityUpscale< GridType, PC >", "classOpm_1_1Elasticity_1_1ElasticityUpscale.html", null ],
    [ "Opm::EulerUpstream< GridInterface, ReservoirProperties, BoundaryConditions >", "classOpm_1_1EulerUpstream.html", null ],
    [ "Opm::EulerUpstreamImplicit< GridInterface, ReservoirProperties, BoundaryConditions >", "classOpm_1_1EulerUpstreamImplicit.html", null ],
    [ "Opm::EulerUpstreamResidual< GridInterface, ReservoirProperties, BoundaryConditions >", "classOpm_1_1EulerUpstreamResidual.html", null ],
    [ "Opm::Explicit< IsotropyPolicy >", "structOpm_1_1Explicit.html", null ],
    [ "Opm::GIE::Face< GI >", "classOpm_1_1GIE_1_1Face.html", null ],
    [ "Opm::GIE::Face< GridInterface >", "classOpm_1_1GIE_1_1Face.html", [
      [ "Opm::GIE::FaceIterator< GridInterface >", "classOpm_1_1GIE_1_1FaceIterator.html", null ]
    ] ],
    [ "Opm::Elasticity::FastAMG", "structOpm_1_1Elasticity_1_1FastAMG.html", null ],
    [ "Opm::SimulatorTraits< RelpermPolicy, TransportPolicy >::FlowSolver< GridInterface, BoundaryConditions >", "structOpm_1_1SimulatorTraits_1_1FlowSolver.html", null ],
    [ "Opm::GICellMapper< DuneGrid >", "structOpm_1_1GICellMapper.html", null ],
    [ "Opm::GridInterfaceEuler< DuneGrid >", "classOpm_1_1GridInterfaceEuler.html", null ],
    [ "Opm::GridInterfaceEuler< GridType >", "classOpm_1_1GridInterfaceEuler.html", null ],
    [ "Opm::Elasticity::HexGeometry< mydim, cdim, GridImp >", "classOpm_1_1Elasticity_1_1HexGeometry.html", null ],
    [ "Opm::Elasticity::HexGeometry< 2, cdim, GridImp >", "classOpm_1_1Elasticity_1_1HexGeometry_3_012_00_01cdim_00_01GridImp_01_4.html", null ],
    [ "Opm::ImmutableSharedData< T >", "classOpm_1_1ImmutableSharedData.html", null ],
    [ "Opm::ImplicitAssembly< Model >", "classOpm_1_1ImplicitAssembly.html", null ],
    [ "Opm::ImplicitCap< IsotropyPolicy >", "structOpm_1_1ImplicitCap.html", null ],
    [ "Opm::ImplicitCapillarity< GridInterface, ReservoirProperties, BoundaryConditions, InnerProd >", "classOpm_1_1ImplicitCapillarity.html", null ],
    [ "Opm::ImplicitTransport< Model, JacobianSystem, VNorm, VNeg, VZero, MZero, VAsgn >", "classOpm_1_1ImplicitTransport.html", null ],
    [ "Opm::IncompFlowSolverHybrid< GridInterface, RockInterface, BCInterface, InnerProduct >", "classOpm_1_1IncompFlowSolverHybrid.html", null ],
    [ "Opm::IncompFlowSolverHybrid< GridInterface, ReservoirProperties, BoundaryConditions, MimeticIPEvaluator >", "classOpm_1_1IncompFlowSolverHybrid.html", null ],
    [ "Opm::EulerUpstreamResidualDetails::IndirectRange< Iter >", "structOpm_1_1EulerUpstreamResidualDetails_1_1IndirectRange.html", null ],
    [ "Dune::InverseOperator", null, [
      [ "Opm::Elasticity::UzawaSolver< X, Y >", "classOpm_1_1Elasticity_1_1UzawaSolver.html", null ]
    ] ],
    [ "Opm::Isotropic", "structOpm_1_1Isotropic.html", null ],
    [ "boost::iterator_facade", null, [
      [ "Opm::GIE::CellIterator< GridInterface >", "classOpm_1_1GIE_1_1CellIterator.html", null ],
      [ "Opm::GIE::FaceIterator< GridInterface >", "classOpm_1_1GIE_1_1FaceIterator.html", null ]
    ] ],
    [ "Opm::ImplicitTransportDefault::JacobianSystem< Matrix, NVecCollection >", "classOpm_1_1ImplicitTransportDefault_1_1JacobianSystem.html", null ],
    [ "Opm::Elasticity::LagrangeCardinalFunction< ctype, rtype >", "classOpm_1_1Elasticity_1_1LagrangeCardinalFunction.html", null ],
    [ "Opm::Elasticity::MPC::Less", "classOpm_1_1Elasticity_1_1MPC_1_1Less.html", null ],
    [ "Dune::LinearOperator", null, [
      [ "Opm::Elasticity::MortarBlockEvaluator< T >", "classOpm_1_1Elasticity_1_1MortarBlockEvaluator.html", null ],
      [ "Opm::Elasticity::MortarEvaluator", "classOpm_1_1Elasticity_1_1MortarEvaluator.html", null ]
    ] ],
    [ "Opm::Elasticity::LinearShapeFunction< ctype, rtype, dim >", "classOpm_1_1Elasticity_1_1LinearShapeFunction.html", null ],
    [ "Opm::LinearSolverBICGSTAB", "classOpm_1_1LinearSolverBICGSTAB.html", null ],
    [ "Opm::Elasticity::LinSolParams", "structOpm_1_1Elasticity_1_1LinSolParams.html", null ],
    [ "LoggerHelper", "classLoggerHelper.html", null ],
    [ "Opm::MatchSaturatedVolumeFunctor< GridInterface, ReservoirProperties >", "structOpm_1_1MatchSaturatedVolumeFunctor.html", null ],
    [ "Opm::Elasticity::Material", "classOpm_1_1Elasticity_1_1Material.html", [
      [ "Opm::Elasticity::Isotropic", "classOpm_1_1Elasticity_1_1Isotropic.html", null ],
      [ "Opm::Elasticity::OrthotropicD", "classOpm_1_1Elasticity_1_1OrthotropicD.html", null ],
      [ "Opm::Elasticity::OrthotropicSym", "classOpm_1_1Elasticity_1_1OrthotropicSym.html", null ]
    ] ],
    [ "Opm::ImplicitTransportDefault::MatrixBlockAssembler< ISTLTypeDetails::ScalarBCRSMatrix >", "classOpm_1_1ImplicitTransportDefault_1_1MatrixBlockAssembler_3_01ISTLTypeDetails_1_1ScalarBCRSMatrix_01_4.html", null ],
    [ "Opm::Elasticity::MatrixOps", "classOpm_1_1Elasticity_1_1MatrixOps.html", null ],
    [ "Opm::ImplicitTransportDefault::MatrixZero< Matrix >", "classOpm_1_1ImplicitTransportDefault_1_1MatrixZero.html", null ],
    [ "Opm::ImplicitTransportDefault::MatrixZero< ISTLTypeDetails::ScalarBCRSMatrix >", "classOpm_1_1ImplicitTransportDefault_1_1MatrixZero_3_01ISTLTypeDetails_1_1ScalarBCRSMatrix_01_4.html", null ],
    [ "Opm::MaxNormDune< Vector >", "classOpm_1_1MaxNormDune.html", null ],
    [ "Opm::MaxNormStl< Vector >", "classOpm_1_1MaxNormStl.html", null ],
    [ "MeshColorizer< GridType >", "classMeshColorizer.html", null ],
    [ "Opm::MimeticIPAnisoRelpermEvaluator< GridInterface, RockInterface >", "classOpm_1_1MimeticIPAnisoRelpermEvaluator.html", [
      [ "Opm::Anisotropic::InnerProduct< GridInterface, RockInterface >", "structOpm_1_1Anisotropic_1_1InnerProduct.html", null ]
    ] ],
    [ "MimeticIPAnisoRelpermEvaluator< CellIter, dim, computeInverseIP >", "classMimeticIPAnisoRelpermEvaluator_3_01CellIter_00_01dim_00_01computeInverseIP_01_4.html", null ],
    [ "Opm::MimeticIPEvaluator< GridInterface, RockInterface >", "classOpm_1_1MimeticIPEvaluator.html", [
      [ "Opm::Isotropic::InnerProduct< GridInterface, RockInterface >", "structOpm_1_1Isotropic_1_1InnerProduct.html", null ]
    ] ],
    [ "Opm::MimeticIPEvaluator< GridInterface, ReservoirProperties >", "classOpm_1_1MimeticIPEvaluator.html", null ],
    [ "MimeticIPEvaluator< GridInterface, RockInterface >", "classMimeticIPEvaluator_3_01GridInterface_00_01RockInterface_01_4.html", null ],
    [ "Opm::spu_2p::ModelParameterStorage", "classOpm_1_1spu__2p_1_1ModelParameterStorage.html", null ],
    [ "ModelThickness", "classModelThickness.html", null ],
    [ "Opm::Elasticity::MortarUtils", "classOpm_1_1Elasticity_1_1MortarUtils.html", null ],
    [ "Opm::Elasticity::MPC", "classOpm_1_1Elasticity_1_1MPC.html", null ],
    [ "Opm::ImplicitTransportDefault::NewtonVectorCollection< BaseVec, VSzSetter, VAdd, VBlkAsm >", "classOpm_1_1ImplicitTransportDefault_1_1NewtonVectorCollection.html", null ],
    [ "Opm::ImplicitTransportDetails::NRControl", "structOpm_1_1ImplicitTransportDetails_1_1NRControl.html", null ],
    [ "Opm::ImplicitTransportDetails::NRReport", "structOpm_1_1ImplicitTransportDetails_1_1NRReport.html", null ],
    [ "Opm::Elasticity::OperatorApplier< T >", "structOpm_1_1Elasticity_1_1OperatorApplier.html", null ],
    [ "Opm::OwnData< T >", "classOpm_1_1OwnData.html", null ],
    [ "Opm::Elasticity::P1ShapeFunctionSet< ctype, rtype, dim >", "classOpm_1_1Elasticity_1_1P1ShapeFunctionSet.html", null ],
    [ "Opm::PeriodicConditionHandler", "classOpm_1_1PeriodicConditionHandler.html", [
      [ "Opm::BasicBoundaryConditions< true, true >", "classOpm_1_1BasicBoundaryConditions.html", null ],
      [ "Opm::BasicBoundaryConditions< FC, SC, ZC, numComponents >", "classOpm_1_1BasicBoundaryConditions.html", null ]
    ] ],
    [ "Opm::Elasticity::PNShapeFunctionSet< dim >", "classOpm_1_1Elasticity_1_1PNShapeFunctionSet.html", null ],
    [ "Dune::Preconditioner", null, [
      [ "Opm::Elasticity::MortarSchurPre< PrecondElasticityBlock >", "classOpm_1_1Elasticity_1_1MortarSchurPre.html", null ]
    ] ],
    [ "Opm::Elasticity::BoundaryGrid::Quad", "classOpm_1_1Elasticity_1_1BoundaryGrid_1_1Quad.html", null ],
    [ "RelpermPolicy", null, [
      [ "Opm::SimulatorTraits< RelpermPolicy, TransportPolicy >", "structOpm_1_1SimulatorTraits.html", null ]
    ] ],
    [ "Opm::RelPermUpscaleHelper", "classOpm_1_1RelPermUpscaleHelper.html", null ],
    [ "Opm::ReservoirPropertyCommon< dim, RPImpl, RockType >", "classOpm_1_1ReservoirPropertyCommon.html", null ],
    [ "Opm::ReservoirPropertyCommon< dim, ReservoirPropertyCapillary< dim >, RockJfunc >", "classOpm_1_1ReservoirPropertyCommon.html", [
      [ "Opm::ReservoirPropertyCapillary< 3 >", "classOpm_1_1ReservoirPropertyCapillary.html", null ],
      [ "Opm::ReservoirPropertyCapillary< dim >", "classOpm_1_1ReservoirPropertyCapillary.html", null ]
    ] ],
    [ "Opm::ReservoirPropertyCommon< dim, ReservoirPropertyCapillaryAnisotropicRelperm< dim >, RockAnisotropicRelperm >", "classOpm_1_1ReservoirPropertyCommon.html", [
      [ "Opm::ReservoirPropertyCapillaryAnisotropicRelperm< dim >", "classOpm_1_1ReservoirPropertyCapillaryAnisotropicRelperm.html", null ]
    ] ],
    [ "Opm::ReservoirPropertyFixedMobility< Mobility >", "classOpm_1_1ReservoirPropertyFixedMobility.html", null ],
    [ "Opm::ReservoirPropertyTracerFluid", "classOpm_1_1ReservoirPropertyTracerFluid.html", null ],
    [ "Opm::ReservoirState< np >", "classOpm_1_1ReservoirState.html", null ],
    [ "Opm::Anisotropic::ResProp< Dimension >", "structOpm_1_1Anisotropic_1_1ResProp.html", null ],
    [ "Opm::Isotropic::ResProp< Dimension >", "structOpm_1_1Isotropic_1_1ResProp.html", null ],
    [ "Opm::Rock< dim >", "classOpm_1_1Rock.html", null ],
    [ "Opm::RockAnisotropicRelperm", "classOpm_1_1RockAnisotropicRelperm.html", null ],
    [ "Opm::RockJfunc", "classOpm_1_1RockJfunc.html", null ],
    [ "Opm::ScalarMobility", "structOpm_1_1ScalarMobility.html", null ],
    [ "Opm::Elasticity::Schwarz", "structOpm_1_1Elasticity_1_1Schwarz.html", null ],
    [ "Opm::SharedData< T >", "classOpm_1_1SharedData.html", null ],
    [ "Opm::SimulatorBase< SimTraits >", "classOpm_1_1SimulatorBase.html", null ],
    [ "Opm::SinglePointUpwindTwoPhase< TwophaseFluid >", "classOpm_1_1SinglePointUpwindTwoPhase.html", null ],
    [ "Opm::SteadyStateUpscalerManager< Traits >", "classOpm_1_1SteadyStateUpscalerManager.html", null ],
    [ "Opm::SteadyStateUpscalerManagerImplicit< Upscaler >", "classOpm_1_1SteadyStateUpscalerManagerImplicit.html", null ],
    [ "Opm::TensorMobility< dim >", "structOpm_1_1TensorMobility.html", null ],
    [ "Opm::Elasticity::TensorProductFunction< rtype, ctype, ftype, dim >", "classOpm_1_1Elasticity_1_1TensorProductFunction.html", null ],
    [ "TransportPolicy", null, [
      [ "Opm::SimulatorTraits< RelpermPolicy, TransportPolicy >", "structOpm_1_1SimulatorTraits.html", null ]
    ] ],
    [ "Opm::Explicit< IsotropyPolicy >::TransportSolver< GridInterface, BoundaryConditions >", "structOpm_1_1Explicit_1_1TransportSolver.html", null ],
    [ "Opm::ImplicitCap< IsotropyPolicy >::TransportSolver< GridInterface, BoundaryConditions >", "structOpm_1_1ImplicitCap_1_1TransportSolver.html", null ],
    [ "Opm::TransportSource", "classOpm_1_1TransportSource.html", null ],
    [ "TransportSource", "structTransportSource.html", null ],
    [ "Opm::TwophaseFluidWrapper", "classOpm_1_1TwophaseFluidWrapper.html", null ],
    [ "std::conditional::type", null, [
      [ "Opm::BasicBoundaryConditions< FC, SC, ZC, numComponents >", "classOpm_1_1BasicBoundaryConditions.html", null ]
    ] ],
    [ "std::conditional::type", null, [
      [ "Opm::BasicBoundaryConditions< FC, SC, ZC, numComponents >", "classOpm_1_1BasicBoundaryConditions.html", null ]
    ] ],
    [ "std::conditional::type", null, [
      [ "Opm::BasicBoundaryConditions< true, true >", "classOpm_1_1BasicBoundaryConditions.html", null ],
      [ "Opm::BasicBoundaryConditions< FC, SC, ZC, numComponents >", "classOpm_1_1BasicBoundaryConditions.html", null ]
    ] ],
    [ "std::conditional::type", null, [
      [ "Opm::BasicBoundaryConditions< true, true >", "classOpm_1_1BasicBoundaryConditions.html", null ]
    ] ],
    [ "std::conditional::type", null, [
      [ "Opm::BasicBoundaryConditions< true, true >", "classOpm_1_1BasicBoundaryConditions.html", null ]
    ] ],
    [ "Opm::EulerUpstreamResidualDetails::UpdateForCell< UpstreamSolver, PressureSolution >", "structOpm_1_1EulerUpstreamResidualDetails_1_1UpdateForCell.html", null ],
    [ "Opm::EulerUpstreamResidualDetails::UpdateLoopBody< Updater >", "structOpm_1_1EulerUpstreamResidualDetails_1_1UpdateLoopBody.html", null ],
    [ "Opm::UpscalerBase< Traits >", "classOpm_1_1UpscalerBase.html", [
      [ "Opm::SteadyStateUpscaler< Traits >", "classOpm_1_1SteadyStateUpscaler.html", null ],
      [ "Opm::SteadyStateUpscalerImplicit< Traits >", "classOpm_1_1SteadyStateUpscalerImplicit.html", null ]
    ] ],
    [ "Opm::UpscalerBase< UpscalingTraitsBasic >", "classOpm_1_1UpscalerBase.html", [
      [ "Opm::SinglePhaseUpscaler", "classOpm_1_1SinglePhaseUpscaler.html", null ]
    ] ],
    [ "Opm::ImplicitTransportDefault::VectorAdder< BaseVec >", "classOpm_1_1ImplicitTransportDefault_1_1VectorAdder.html", null ],
    [ "Opm::ImplicitTransportDefault::VectorAdder< ISTLTypeDetails::ScalarBlockVector >", "classOpm_1_1ImplicitTransportDefault_1_1VectorAdder_3_01ISTLTypeDetails_1_1ScalarBlockVector_01_4.html", null ],
    [ "Opm::ImplicitTransportDefault::VectorAssign< BaseVec >", "classOpm_1_1ImplicitTransportDefault_1_1VectorAssign.html", null ],
    [ "Opm::ImplicitTransportDefault::VectorAssign< ISTLTypeDetails::ScalarBlockVector >", "classOpm_1_1ImplicitTransportDefault_1_1VectorAssign_3_01ISTLTypeDetails_1_1ScalarBlockVector_01_4.html", null ],
    [ "Opm::ImplicitTransportDefault::VectorBlockAssembler< BaseVec >", "classOpm_1_1ImplicitTransportDefault_1_1VectorBlockAssembler.html", null ],
    [ "Opm::ImplicitTransportDefault::VectorBlockAssembler< ISTLTypeDetails::ScalarBlockVector >", "classOpm_1_1ImplicitTransportDefault_1_1VectorBlockAssembler_3_01ISTLTypeDetails_1_1ScalarBlockVector_01_4.html", null ],
    [ "Opm::ImplicitTransportDefault::VectorNegater< BaseVec >", "classOpm_1_1ImplicitTransportDefault_1_1VectorNegater.html", null ],
    [ "Opm::ImplicitTransportDefault::VectorNegater< ISTLTypeDetails::ScalarBlockVector >", "classOpm_1_1ImplicitTransportDefault_1_1VectorNegater_3_01ISTLTypeDetails_1_1ScalarBlockVector_01_4.html", null ],
    [ "Opm::ImplicitTransportDefault::VectorSizeSetter< BaseVec >", "classOpm_1_1ImplicitTransportDefault_1_1VectorSizeSetter.html", null ],
    [ "Opm::ImplicitTransportDefault::VectorZero< BaseVec >", "classOpm_1_1ImplicitTransportDefault_1_1VectorZero.html", null ],
    [ "Opm::ImplicitTransportDefault::VectorZero< ISTLTypeDetails::ScalarBlockVector >", "classOpm_1_1ImplicitTransportDefault_1_1VectorZero_3_01ISTLTypeDetails_1_1ScalarBlockVector_01_4.html", null ],
    [ "Opm::Elasticity::BoundaryGrid::Vertex", "classOpm_1_1Elasticity_1_1BoundaryGrid_1_1Vertex.html", null ],
    [ "Opm::Elasticity::BoundaryGrid::VertexLess", "structOpm_1_1Elasticity_1_1BoundaryGrid_1_1VertexLess.html", null ],
    [ "Opm::Wells", "classOpm_1_1Wells.html", null ]
];