var classOpm_1_1SatBC =
[
    [ "SatBC", "classOpm_1_1SatBC.html#a76efe756a5ef2cc17c09adcf08f10f15", null ],
    [ "SatBC", "classOpm_1_1SatBC.html#aa9cf63c43eee66feb9507add7475cdfe", null ],
    [ "saturation", "classOpm_1_1SatBC.html#a3e017410500ab3c9ae62d66ab0ae1b34", null ],
    [ "saturationDifference", "classOpm_1_1SatBC.html#a5cb3ad4ecdd4041e77f7e86dfb565407", null ]
];