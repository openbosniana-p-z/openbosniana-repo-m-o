var dir_e78c8ede32a2413fefdf20fa54ebe1bf =
[
    [ "Average.hpp", "Average_8hpp_source.html", null ]
];