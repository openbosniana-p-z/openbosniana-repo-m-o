var classOpm_1_1ReservoirPropertyCapillary =
[
    [ "Mobility", "classOpm_1_1ReservoirPropertyCapillary.html#a6cae8892481767e5b682e808013be7b0", null ],
    [ "computeCflFactors", "classOpm_1_1ReservoirPropertyCapillary.html#a1056b1242cd7f421d3151848beeb1074", null ],
    [ "fractionalFlow", "classOpm_1_1ReservoirPropertyCapillary.html#aaa9eedbafd238e7eb1184b59be5e3103", null ],
    [ "mobilityFirstPhase", "classOpm_1_1ReservoirPropertyCapillary.html#a7fc18244cc981d3abb411c7116c0c12d", null ],
    [ "mobilitySecondPhase", "classOpm_1_1ReservoirPropertyCapillary.html#a36c9b58da493e66e7b4f13aef4f064f9", null ],
    [ "phaseMobilities", "classOpm_1_1ReservoirPropertyCapillary.html#a17879219686638170e5d2459fc9579f5", null ],
    [ "phaseMobility", "classOpm_1_1ReservoirPropertyCapillary.html#a5e11012fd14e38185d971ad3e00450a3", null ],
    [ "totalMobility", "classOpm_1_1ReservoirPropertyCapillary.html#a84364ac460e2f21ac19cb7f49293294b", null ]
];