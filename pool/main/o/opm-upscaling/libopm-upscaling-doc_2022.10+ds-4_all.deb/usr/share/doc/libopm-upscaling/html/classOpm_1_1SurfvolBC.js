var classOpm_1_1SurfvolBC =
[
    [ "SurfvolBC", "classOpm_1_1SurfvolBC.html#aa45d2736d3afd6ffcacc50ea4c9b76c1", null ],
    [ "SurfvolBC", "classOpm_1_1SurfvolBC.html#adf337081e261caf5fa3aab7237895c91", null ],
    [ "isDirichlet", "classOpm_1_1SurfvolBC.html#ac7fa7b1441df0a0df00235f22f15a811", null ],
    [ "surfvol", "classOpm_1_1SurfvolBC.html#a80b8389c783c3a1a38ec55165afeef29", null ]
];