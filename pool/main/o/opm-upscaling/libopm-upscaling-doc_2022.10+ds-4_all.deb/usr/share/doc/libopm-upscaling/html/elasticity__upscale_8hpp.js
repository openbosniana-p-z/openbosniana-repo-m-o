var elasticity__upscale_8hpp =
[
    [ "Opm::Elasticity::LinSolParams", "structOpm_1_1Elasticity_1_1LinSolParams.html", "structOpm_1_1Elasticity_1_1LinSolParams" ],
    [ "Opm::Elasticity::ElasticityUpscale< GridType, PC >", "classOpm_1_1Elasticity_1_1ElasticityUpscale.html", "classOpm_1_1Elasticity_1_1ElasticityUpscale" ],
    [ "MultiplierPreconditioner", "elasticity__upscale_8hpp.html#a4dbfa745746efd1ea262f350a2dda7b9", [
      [ "SIMPLE", "elasticity__upscale_8hpp.html#a4dbfa745746efd1ea262f350a2dda7b9ae4bfdf230549889bc3937a6befaeda3d", null ],
      [ "SCHUR", "elasticity__upscale_8hpp.html#a4dbfa745746efd1ea262f350a2dda7b9aa285e509ecbaf4fcdbfc4fe237f01f2e", null ],
      [ "SCHURAMG", "elasticity__upscale_8hpp.html#a4dbfa745746efd1ea262f350a2dda7b9a21bca576ad3ac138a187ef51df047b40", null ],
      [ "SCHURSCHWARZ", "elasticity__upscale_8hpp.html#a4dbfa745746efd1ea262f350a2dda7b9ae7077cc06de4e9ebb507009d77e9c153", null ],
      [ "SCHURTWOLEVEL", "elasticity__upscale_8hpp.html#a4dbfa745746efd1ea262f350a2dda7b9ace58f78c6ad25a45e0f6c62fa4d4256f", null ]
    ] ],
    [ "Smoother", "elasticity__upscale_8hpp.html#a6671ea63f51cdb7eba2d0f4853da5cb2", [
      [ "SMOOTH_SSOR", "elasticity__upscale_8hpp.html#a6671ea63f51cdb7eba2d0f4853da5cb2abbd61234646e5f32d280de12ef88ead2", null ],
      [ "SMOOTH_SCHWARZ", "elasticity__upscale_8hpp.html#a6671ea63f51cdb7eba2d0f4853da5cb2af30dda23887a43ddb80ef5cb4b8571d3", null ],
      [ "SMOOTH_JACOBI", "elasticity__upscale_8hpp.html#a6671ea63f51cdb7eba2d0f4853da5cb2afc92d5b2f3e42fed3cee5a6ac2091245", null ],
      [ "SMOOTH_ILU", "elasticity__upscale_8hpp.html#a6671ea63f51cdb7eba2d0f4853da5cb2a8599969174b0864b6561b46b97ec99b5", null ]
    ] ],
    [ "Solver", "elasticity__upscale_8hpp.html#a174c4564a169c24a77b7536f1d22e969", [
      [ "DIRECT", "elasticity__upscale_8hpp.html#a174c4564a169c24a77b7536f1d22e969afa21d63747e83e6ae3f56650c91d81f6", null ],
      [ "ITERATIVE", "elasticity__upscale_8hpp.html#a174c4564a169c24a77b7536f1d22e969a9818def585a4e6e0b1367debbcb4a0b4", null ]
    ] ]
];