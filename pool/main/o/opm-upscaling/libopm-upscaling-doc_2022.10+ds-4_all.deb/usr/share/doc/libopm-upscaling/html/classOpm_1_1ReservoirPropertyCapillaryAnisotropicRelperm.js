var classOpm_1_1ReservoirPropertyCapillaryAnisotropicRelperm =
[
    [ "Mobility", "classOpm_1_1ReservoirPropertyCapillaryAnisotropicRelperm.html#a756db6240d62dd5ea1d30060f7e468ad", null ],
    [ "fractionalFlow", "classOpm_1_1ReservoirPropertyCapillaryAnisotropicRelperm.html#a2bff7e5f9077409e0042c79d4a0bd6b5", null ],
    [ "phaseMobility", "classOpm_1_1ReservoirPropertyCapillaryAnisotropicRelperm.html#a80d556a39acef6eaf279b6e234bb6b6b", null ]
];