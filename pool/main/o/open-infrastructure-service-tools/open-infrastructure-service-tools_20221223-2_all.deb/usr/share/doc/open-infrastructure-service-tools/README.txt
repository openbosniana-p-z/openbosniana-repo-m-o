============
apache-tools
============

----------------------------------
Extra tools for Apache HTTP server
----------------------------------

:manual section: 7
:manual group: Open Infrastructure

Description
===========

This package is a collection of extra tools for the Apache HTTP server,
currently containing:

  * alternative icons for Apache autoindex
    (Tango Icons and Font Awesome based themes)

Download
========

| Upstream Releases:
| https://get.open-infrastructure.net/software/service-tools/upstream

| Upstream Sources:
| https://git.open-infrastructure.net/software/service-tools

| Debian Releases:
| https://get.open-infrastructure.net/software/service-tools/debian

| Debian Sources:
| https://git.progress-linux.org/users/daniel/debian/packages/open-infrastructure-service-tools

Installation
============

Source
------

| $ sudo apt install git make python3-docutils
| $ git clone https://git.open-infrastructure.net/software/service-tools
| $ cd service-tools/apache && sudo make install

Debian 9 (stretch) and newer
----------------------------

| $ sudo apt install apache-tools

Development
===========

Bug reports, feature requests, help, patches, support and everything else are
welcome on the Open Infrastructure Software Mailing List
(https://lists.open-infrastructure.net/listinfo/software).

Please base patches against the 'next' Git branch using common sense
(https://www.kernel.org/doc/Documentation/SubmittingPatches).

Debian specific bugs can also be reported in the Debian Bug Tracking System
(https://bugs.debian.org).

Known limitations
=================

Changing from one icon set to the other requires a reload of the apache webserver.

Usage
=====

The default icon theme is determined by the /usr/share/apache-icons/default
(and /usr/share/apache-icons/default.conf respectivly) file.

On Debian based system "sudo update-alternatives --config apache-icons" can be
used to automatically select the active icon theme (including the default apache
icons).

The following themes are available:

  * awesome-png: Fork Awesome based, PNG format
  * awesome-svg: Fork Awesome based, SVG format
  * tango-png: Tango Icons based, PNG format
  * tango-svg: Tango Icons based, SVG format

The SVG themes are preferable because they are sharper and scale losless.
Very old browser can not render SVG icons, use PNG if that is a concern.

An example of the tango-svg theme can be seen on
https://get.open-infrastructure.net.

Links
=====

| * Fork Awesome
|   (https://forkaweso.me)

| * Tango Desktop Project
|   (http://tango.freedesktop.org)

Authors
=======

service-tools were written by Daniel Baumann
<daniel.baumann@open-infrastructure.net> and others.
