INSERT INTO `config` VALUES('IPDISCOVER_PURGE_OLD',0,'','Purge of the old IPDiscover data');
INSERT INTO `config` VALUES('IPDISCOVER_PURGE_VALIDITY_TIME',30,'','IPDiscover data validity time');