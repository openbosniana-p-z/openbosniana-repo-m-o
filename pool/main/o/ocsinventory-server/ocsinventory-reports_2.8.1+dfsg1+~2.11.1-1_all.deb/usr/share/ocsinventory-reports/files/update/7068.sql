UNLOCK TABLE;

ALTER TABLE `auth_attempt` CHARACTER SET utf8, COLLATE utf8_general_ci;
ALTER TABLE `cve_search_computer` CHARACTER SET utf8, COLLATE utf8_general_ci;
ALTER TABLE `local_groups` CHARACTER SET utf8, COLLATE utf8_general_ci;
ALTER TABLE `local_users` CHARACTER SET utf8, COLLATE utf8_general_ci;
ALTER TABLE `snmp_types_conditions` CHARACTER SET utf8, COLLATE utf8_general_ci;
ALTER TABLE `software_categories_link` CHARACTER SET utf8, COLLATE utf8_general_ci;
ALTER TABLE `software_link` CHARACTER SET utf8, COLLATE utf8_general_ci;