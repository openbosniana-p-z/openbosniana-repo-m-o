-- Add INTERFACE_LAST_CONTACT default value

INSERT INTO `config` VALUES('INTERFACE_LAST_CONTACT',15,'','Custom frequency');
