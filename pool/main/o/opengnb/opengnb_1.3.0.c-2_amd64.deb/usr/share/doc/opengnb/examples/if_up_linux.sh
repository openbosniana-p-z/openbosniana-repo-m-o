#!/bin/sh
# if_up_linux.sh

#GNB ENV $GNB_IF_NAME $GNB_MTU $GNB_TUN_IPV4 $GNB_TUN_IPV6
