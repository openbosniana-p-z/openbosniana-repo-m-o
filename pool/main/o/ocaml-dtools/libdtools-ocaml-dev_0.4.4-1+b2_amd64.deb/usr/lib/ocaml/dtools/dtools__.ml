(** @canonical Dtools.Dtools_impl *)
module Dtools_impl = Dtools__Dtools_impl


(** @canonical Dtools.Dtools_syslog *)
module Dtools_syslog = Dtools__Dtools_syslog
