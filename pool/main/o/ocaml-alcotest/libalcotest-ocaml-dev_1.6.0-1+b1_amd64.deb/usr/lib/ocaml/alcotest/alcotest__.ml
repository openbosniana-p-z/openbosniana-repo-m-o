(** @canonical Alcotest.Terminal *)
module Terminal = Alcotest__Terminal
