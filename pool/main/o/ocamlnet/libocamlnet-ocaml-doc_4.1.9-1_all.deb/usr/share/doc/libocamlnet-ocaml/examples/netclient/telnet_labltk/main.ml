open Tk;;
open Telnet;;

let top = openTk() in
fill_main_window top;
mainLoop()
;;
