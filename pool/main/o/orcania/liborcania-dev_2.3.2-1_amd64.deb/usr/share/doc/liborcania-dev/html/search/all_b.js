var searchData=
[
  ['trimcharacter_0',['trimcharacter',['../group__str.html#ga61fe05fd9a9c6580ee6ec9eee5a7224f',1,'trimcharacter(char *str, char to_remove):&#160;orcania.c'],['../group__str.html#ga61fe05fd9a9c6580ee6ec9eee5a7224f',1,'trimcharacter(char *str, char to_remove):&#160;orcania.c']]],
  ['trimwhitespace_1',['trimwhitespace',['../group__str.html#gaa1b61a381363b7b542eb995e0cf974ff',1,'trimwhitespace(char *str):&#160;orcania.c'],['../group__str.html#gaa1b61a381363b7b542eb995e0cf974ff',1,'trimwhitespace(char *str):&#160;orcania.c']]]
];
