var searchData=
[
  ['_5fgnu_5fsource_0',['_GNU_SOURCE',['../orcania_8c.html#a369266c24eacffb87046522897a570d5',1,'orcania.c']]]
];
