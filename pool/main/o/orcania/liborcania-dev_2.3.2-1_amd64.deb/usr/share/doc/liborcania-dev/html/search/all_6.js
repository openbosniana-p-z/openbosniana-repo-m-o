var searchData=
[
  ['memory_20functions_0',['Memory functions',['../group__mem.html',1,'']]],
  ['memory_2ec_1',['memory.c',['../memory_8c.html',1,'']]],
  ['msprintf_2',['msprintf',['../group__str.html#ga40a3ba6b56e1cf7d6b5b9c029ea78c71',1,'msprintf(const char *message,...):&#160;orcania.c'],['../group__str.html#ga40a3ba6b56e1cf7d6b5b9c029ea78c71',1,'msprintf(const char *message,...):&#160;orcania.c']]],
  ['mstrcatf_3',['mstrcatf',['../group__str.html#ga58136a92131d06cec76dfd01bed12a5e',1,'mstrcatf(char *source, const char *message,...):&#160;orcania.c'],['../group__str.html#ga58136a92131d06cec76dfd01bed12a5e',1,'mstrcatf(char *source, const char *message,...):&#160;orcania.c']]]
];
