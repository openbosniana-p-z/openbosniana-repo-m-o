var searchData=
[
  ['memory_20functions_0',['Memory functions',['../group__mem.html',1,'']]]
];
