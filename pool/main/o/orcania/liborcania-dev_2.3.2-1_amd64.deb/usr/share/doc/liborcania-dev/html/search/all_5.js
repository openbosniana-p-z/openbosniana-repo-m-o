var searchData=
[
  ['list_0',['list',['../struct__pointer__list.html#a9a9ee6a4fb9f59e00881fa124fe78acf',1,'_pointer_list']]]
];
