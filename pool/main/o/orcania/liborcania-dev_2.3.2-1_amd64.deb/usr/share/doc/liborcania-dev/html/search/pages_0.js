var searchData=
[
  ['base64url_3a_20base64url_20encode_20or_20decode_20file_2c_20or_20standard_20input_2c_20to_20standard_20output_2e_0',['base64url: Base64Url encode or decode FILE, or standard input, to standard output.',['../md_tools_base64url_README.html',1,'']]]
];
