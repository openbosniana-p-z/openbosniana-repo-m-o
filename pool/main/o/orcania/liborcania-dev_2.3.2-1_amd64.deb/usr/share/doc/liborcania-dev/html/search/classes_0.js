var searchData=
[
  ['_5fo_5fdatum_0',['_o_datum',['../struct__o__datum.html',1,'']]],
  ['_5fpointer_5flist_1',['_pointer_list',['../struct__pointer__list.html',1,'']]]
];
