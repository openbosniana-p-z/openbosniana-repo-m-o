var searchData=
[
  ['o_5ffree_5ft_0',['o_free_t',['../group__mem.html#gab0d34b728909ce22d40980a7bffe93a3',1,'orcania.h']]],
  ['o_5fmalloc_5ft_1',['o_malloc_t',['../group__mem.html#ga2e346d3d6152926ffce99eb57d731aa8',1,'orcania.h']]],
  ['o_5frealloc_5ft_2',['o_realloc_t',['../group__mem.html#gaa6d5028a89b9d6806048b3340e00d8f7',1,'orcania.h']]]
];
