var searchData=
[
  ['size_0',['size',['../struct__o__datum.html#adbaec8bf8c0d3321eb910f1548e2082e',1,'_o_datum::size()'],['../struct__pointer__list.html#a34b2208959c90164854a9f6f9fda90bb',1,'_pointer_list::size()']]]
];
