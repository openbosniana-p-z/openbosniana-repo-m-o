var searchData=
[
  ['free_5fstring_5farray_0',['free_string_array',['../group__split.html#gab3e2db03a466150e816f87fd9d152845',1,'free_string_array(char **array):&#160;orcania.c'],['../group__split.html#gab3e2db03a466150e816f87fd9d152845',1,'free_string_array(char **array):&#160;orcania.c']]]
];
