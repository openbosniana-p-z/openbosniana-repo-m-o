var searchData=
[
  ['msprintf_0',['msprintf',['../group__str.html#ga40a3ba6b56e1cf7d6b5b9c029ea78c71',1,'msprintf(const char *message,...):&#160;orcania.c'],['../group__str.html#ga40a3ba6b56e1cf7d6b5b9c029ea78c71',1,'msprintf(const char *message,...):&#160;orcania.c']]],
  ['mstrcatf_1',['mstrcatf',['../group__str.html#ga58136a92131d06cec76dfd01bed12a5e',1,'mstrcatf(char *source, const char *message,...):&#160;orcania.c'],['../group__str.html#ga58136a92131d06cec76dfd01bed12a5e',1,'mstrcatf(char *source, const char *message,...):&#160;orcania.c']]]
];
