var searchData=
[
  ['_5fgnu_5fsource_0',['_GNU_SOURCE',['../orcania_8c.html#a369266c24eacffb87046522897a570d5',1,'orcania.c']]],
  ['_5fo_5fdatum_1',['_o_datum',['../struct__o__datum.html',1,'']]],
  ['_5fpointer_5flist_2',['_pointer_list',['../struct__pointer__list.html',1,'']]],
  ['_5fpointer_5flist_20structure_3',['_pointer_list structure',['../group__plist.html',1,'']]]
];
