var searchData=
[
  ['orcania_2ec_0',['orcania.c',['../orcania_8c.html',1,'']]],
  ['orcania_2eh_1',['orcania.h',['../orcania_8h.html',1,'']]]
];
