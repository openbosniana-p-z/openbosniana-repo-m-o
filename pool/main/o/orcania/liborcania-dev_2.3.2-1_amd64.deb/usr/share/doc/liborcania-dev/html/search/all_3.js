var searchData=
[
  ['data_0',['data',['../struct__o__datum.html#a6cc7ffc33698ba8c47fce25ae826d3e2',1,'_o_datum']]]
];
