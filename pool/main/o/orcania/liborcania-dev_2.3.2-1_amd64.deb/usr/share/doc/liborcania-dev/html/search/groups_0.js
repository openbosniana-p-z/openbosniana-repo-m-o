var searchData=
[
  ['_5fpointer_5flist_20structure_0',['_pointer_list structure',['../group__plist.html',1,'']]]
];
