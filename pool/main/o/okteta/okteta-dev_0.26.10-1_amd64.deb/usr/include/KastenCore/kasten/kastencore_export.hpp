
#ifndef KASTENCORE_EXPORT_H
#define KASTENCORE_EXPORT_H

#ifdef KASTENCORE_STATIC_DEFINE
#  define KASTENCORE_EXPORT
#  define KASTENCORE_NO_EXPORT
#else
#  ifndef KASTENCORE_EXPORT
#    ifdef KastenCore_EXPORTS
        /* We are building this library */
#      define KASTENCORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KASTENCORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KASTENCORE_NO_EXPORT
#    define KASTENCORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KASTENCORE_DEPRECATED
#  define KASTENCORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KASTENCORE_DEPRECATED_EXPORT
#  define KASTENCORE_DEPRECATED_EXPORT KASTENCORE_EXPORT KASTENCORE_DEPRECATED
#endif

#ifndef KASTENCORE_DEPRECATED_NO_EXPORT
#  define KASTENCORE_DEPRECATED_NO_EXPORT KASTENCORE_NO_EXPORT KASTENCORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KASTENCORE_NO_DEPRECATED
#    define KASTENCORE_NO_DEPRECATED
#  endif
#endif

#endif /* KASTENCORE_EXPORT_H */
