
#ifndef OKTETAGUI_EXPORT_H
#define OKTETAGUI_EXPORT_H

#ifdef OKTETAGUI_STATIC_DEFINE
#  define OKTETAGUI_EXPORT
#  define OKTETAGUI_NO_EXPORT
#else
#  ifndef OKTETAGUI_EXPORT
#    ifdef OktetaGui_EXPORTS
        /* We are building this library */
#      define OKTETAGUI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OKTETAGUI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef OKTETAGUI_NO_EXPORT
#    define OKTETAGUI_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OKTETAGUI_DEPRECATED
#  define OKTETAGUI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OKTETAGUI_DEPRECATED_EXPORT
#  define OKTETAGUI_DEPRECATED_EXPORT OKTETAGUI_EXPORT OKTETAGUI_DEPRECATED
#endif

#ifndef OKTETAGUI_DEPRECATED_NO_EXPORT
#  define OKTETAGUI_DEPRECATED_NO_EXPORT OKTETAGUI_NO_EXPORT OKTETAGUI_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OKTETAGUI_NO_DEPRECATED
#    define OKTETAGUI_NO_DEPRECATED
#  endif
#endif

#endif /* OKTETAGUI_EXPORT_H */
