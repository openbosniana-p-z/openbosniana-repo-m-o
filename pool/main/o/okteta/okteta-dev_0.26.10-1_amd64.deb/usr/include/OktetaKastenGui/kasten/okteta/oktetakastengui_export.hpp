
#ifndef OKTETAKASTENGUI_EXPORT_H
#define OKTETAKASTENGUI_EXPORT_H

#ifdef OKTETAKASTENGUI_STATIC_DEFINE
#  define OKTETAKASTENGUI_EXPORT
#  define OKTETAKASTENGUI_NO_EXPORT
#else
#  ifndef OKTETAKASTENGUI_EXPORT
#    ifdef OktetaKastenGui_EXPORTS
        /* We are building this library */
#      define OKTETAKASTENGUI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OKTETAKASTENGUI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef OKTETAKASTENGUI_NO_EXPORT
#    define OKTETAKASTENGUI_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OKTETAKASTENGUI_DEPRECATED
#  define OKTETAKASTENGUI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OKTETAKASTENGUI_DEPRECATED_EXPORT
#  define OKTETAKASTENGUI_DEPRECATED_EXPORT OKTETAKASTENGUI_EXPORT OKTETAKASTENGUI_DEPRECATED
#endif

#ifndef OKTETAKASTENGUI_DEPRECATED_NO_EXPORT
#  define OKTETAKASTENGUI_DEPRECATED_NO_EXPORT OKTETAKASTENGUI_NO_EXPORT OKTETAKASTENGUI_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OKTETAKASTENGUI_NO_DEPRECATED
#    define OKTETAKASTENGUI_NO_DEPRECATED
#  endif
#endif

#endif /* OKTETAKASTENGUI_EXPORT_H */
