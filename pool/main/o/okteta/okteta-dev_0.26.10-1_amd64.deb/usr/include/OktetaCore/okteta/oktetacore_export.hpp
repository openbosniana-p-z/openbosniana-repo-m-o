
#ifndef OKTETACORE_EXPORT_H
#define OKTETACORE_EXPORT_H

#ifdef OKTETACORE_STATIC_DEFINE
#  define OKTETACORE_EXPORT
#  define OKTETACORE_NO_EXPORT
#else
#  ifndef OKTETACORE_EXPORT
#    ifdef OktetaCore_EXPORTS
        /* We are building this library */
#      define OKTETACORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OKTETACORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef OKTETACORE_NO_EXPORT
#    define OKTETACORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OKTETACORE_DEPRECATED
#  define OKTETACORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OKTETACORE_DEPRECATED_EXPORT
#  define OKTETACORE_DEPRECATED_EXPORT OKTETACORE_EXPORT OKTETACORE_DEPRECATED
#endif

#ifndef OKTETACORE_DEPRECATED_NO_EXPORT
#  define OKTETACORE_DEPRECATED_NO_EXPORT OKTETACORE_NO_EXPORT OKTETACORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OKTETACORE_NO_DEPRECATED
#    define OKTETACORE_NO_DEPRECATED
#  endif
#endif

#endif /* OKTETACORE_EXPORT_H */
