
#ifndef KASTENGUI_EXPORT_H
#define KASTENGUI_EXPORT_H

#ifdef KASTENGUI_STATIC_DEFINE
#  define KASTENGUI_EXPORT
#  define KASTENGUI_NO_EXPORT
#else
#  ifndef KASTENGUI_EXPORT
#    ifdef KastenGui_EXPORTS
        /* We are building this library */
#      define KASTENGUI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KASTENGUI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KASTENGUI_NO_EXPORT
#    define KASTENGUI_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KASTENGUI_DEPRECATED
#  define KASTENGUI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KASTENGUI_DEPRECATED_EXPORT
#  define KASTENGUI_DEPRECATED_EXPORT KASTENGUI_EXPORT KASTENGUI_DEPRECATED
#endif

#ifndef KASTENGUI_DEPRECATED_NO_EXPORT
#  define KASTENGUI_DEPRECATED_NO_EXPORT KASTENGUI_NO_EXPORT KASTENGUI_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KASTENGUI_NO_DEPRECATED
#    define KASTENGUI_NO_DEPRECATED
#  endif
#endif

#endif /* KASTENGUI_EXPORT_H */
