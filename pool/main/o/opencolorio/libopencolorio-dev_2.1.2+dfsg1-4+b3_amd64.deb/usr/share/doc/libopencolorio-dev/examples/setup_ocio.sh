#!/bin/sh
# SPDX-License-Identifier: BSD-3-Clause
# Copyright Contributors to the OpenColorIO Project.

# For OS X
export DYLD_LIBRARY_PATH="/usr/lib/x86_64-linux-gnu:${DYLD_LIBRARY_PATH}"

# For Linux
export LD_LIBRARY_PATH="/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH}"

export PATH="/usr/bin:${PATH}"
export PYTHONPATH="/usr/lib/x86_64-linux-gnu/python3.11/site-packages:${PYTHONPATH}"
