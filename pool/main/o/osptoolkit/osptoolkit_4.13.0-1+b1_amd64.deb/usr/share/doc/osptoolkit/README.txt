Installation
------------

See the document titled: 
"How to Build and Test the OSP Toolkit"
found on the company website at www.transnexus.com
