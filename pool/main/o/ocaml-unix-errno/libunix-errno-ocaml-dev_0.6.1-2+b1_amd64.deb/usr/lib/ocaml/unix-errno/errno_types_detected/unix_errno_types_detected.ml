include Ctypes
let lift x = x
open Ctypes_static

let rec field : type t a. t typ -> string -> a typ -> (a, t) field =
  fun s fname ftype -> match s, fname with
  | View { ty; _ }, _ ->
    let { ftype; foffset; fname } = field ty fname ftype in
    { ftype; foffset; fname }
  | _ -> failwith ("Unexpected field "^ fname)

let rec seal : type a. a typ -> unit = function
  | Struct { tag; spec = Complete _; _ } ->
    raise (ModifyingSealedType tag)
  | Union { utag; uspec = Some _; _ } ->
    raise (ModifyingSealedType utag)
  | View { ty; _ } -> seal ty
  | _ ->
    raise (Unsupported "Sealing a non-structured type")

type 'a const = 'a
let constant (type t) name (t : t typ) : t = match t, name with
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EXDEV" ->
    Signed.SInt.of_string "18"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EWOULDBLOCK" ->
    Signed.SInt.of_string "11"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EUSERS" ->
    Signed.SInt.of_string "87"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ETXTBSY" ->
    Signed.SInt.of_string "26"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ETOOMANYREFS" ->
    Signed.SInt.of_string "109"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ETIMEDOUT" ->
    Signed.SInt.of_string "110"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ESTALE" ->
    Signed.SInt.of_string "116"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ESRCH" ->
    Signed.SInt.of_string "3"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ESPIPE" ->
    Signed.SInt.of_string "29"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ESOCKTNOSUPPORT" ->
    Signed.SInt.of_string "94"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ESHUTDOWN" ->
    Signed.SInt.of_string "108"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EROFS" ->
    Signed.SInt.of_string "30"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EREMOTE" ->
    Signed.SInt.of_string "66"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ERANGE" ->
    Signed.SInt.of_string "34"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EPROTOTYPE" ->
    Signed.SInt.of_string "91"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EPROTONOSUPPORT" ->
    Signed.SInt.of_string "93"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EPROTO" ->
    Signed.SInt.of_string "71"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EPIPE" ->
    Signed.SInt.of_string "32"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EPFNOSUPPORT" ->
    Signed.SInt.of_string "96"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EPERM" ->
    Signed.SInt.of_string "1"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EOWNERDEAD" ->
    Signed.SInt.of_string "130"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EOVERFLOW" ->
    Signed.SInt.of_string "75"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EOPNOTSUPP" ->
    Signed.SInt.of_string "95"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENXIO" ->
    Signed.SInt.of_string "6"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOTTY" ->
    Signed.SInt.of_string "25"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOTSUP" ->
    Signed.SInt.of_string "95"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOTSOCK" ->
    Signed.SInt.of_string "88"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOTRECOVERABLE" ->
    Signed.SInt.of_string "131"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOTEMPTY" ->
    Signed.SInt.of_string "39"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOTDIR" ->
    Signed.SInt.of_string "20"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOTCONN" ->
    Signed.SInt.of_string "107"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOTBLK" ->
    Signed.SInt.of_string "15"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOSYS" ->
    Signed.SInt.of_string "38"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOSPC" ->
    Signed.SInt.of_string "28"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOPROTOOPT" ->
    Signed.SInt.of_string "92"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOMSG" ->
    Signed.SInt.of_string "42"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOMEM" ->
    Signed.SInt.of_string "12"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOLINK" ->
    Signed.SInt.of_string "67"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOLCK" ->
    Signed.SInt.of_string "37"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOEXEC" ->
    Signed.SInt.of_string "8"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOENT" ->
    Signed.SInt.of_string "2"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENODEV" ->
    Signed.SInt.of_string "19"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENOBUFS" ->
    Signed.SInt.of_string "105"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENFILE" ->
    Signed.SInt.of_string "23"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENETUNREACH" ->
    Signed.SInt.of_string "101"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENETRESET" ->
    Signed.SInt.of_string "102"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENETDOWN" ->
    Signed.SInt.of_string "100"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ENAMETOOLONG" ->
    Signed.SInt.of_string "36"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EMULTIHOP" ->
    Signed.SInt.of_string "72"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EMSGSIZE" ->
    Signed.SInt.of_string "90"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EMLINK" ->
    Signed.SInt.of_string "31"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EMFILE" ->
    Signed.SInt.of_string "24"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ELOOP" ->
    Signed.SInt.of_string "40"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EISDIR" ->
    Signed.SInt.of_string "21"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EISCONN" ->
    Signed.SInt.of_string "106"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EIO" ->
    Signed.SInt.of_string "5"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EINVAL" ->
    Signed.SInt.of_string "22"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EINTR" ->
    Signed.SInt.of_string "4"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EINPROGRESS" ->
    Signed.SInt.of_string "115"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EILSEQ" ->
    Signed.SInt.of_string "84"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EIDRM" ->
    Signed.SInt.of_string "43"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EHOSTUNREACH" ->
    Signed.SInt.of_string "113"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EHOSTDOWN" ->
    Signed.SInt.of_string "112"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EFBIG" ->
    Signed.SInt.of_string "27"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EFAULT" ->
    Signed.SInt.of_string "14"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EEXIST" ->
    Signed.SInt.of_string "17"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EDQUOT" ->
    Signed.SInt.of_string "122"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EDOM" ->
    Signed.SInt.of_string "33"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EDESTADDRREQ" ->
    Signed.SInt.of_string "89"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EDEADLK" ->
    Signed.SInt.of_string "35"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ECONNRESET" ->
    Signed.SInt.of_string "104"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ECONNREFUSED" ->
    Signed.SInt.of_string "111"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ECONNABORTED" ->
    Signed.SInt.of_string "103"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ECHILD" ->
    Signed.SInt.of_string "10"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "ECANCELED" ->
    Signed.SInt.of_string "125"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EBUSY" ->
    Signed.SInt.of_string "16"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EBADMSG" ->
    Signed.SInt.of_string "74"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EBADF" ->
    Signed.SInt.of_string "9"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EALREADY" ->
    Signed.SInt.of_string "114"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EAGAIN" ->
    Signed.SInt.of_string "11"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EAFNOSUPPORT" ->
    Signed.SInt.of_string "97"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EADDRNOTAVAIL" ->
    Signed.SInt.of_string "99"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EADDRINUSE" ->
    Signed.SInt.of_string "98"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "EACCES" ->
    Signed.SInt.of_string "13"
  | Ctypes_static.Primitive Cstubs_internals.Sint, "E2BIG" ->
    Signed.SInt.of_string "7"
  | _, s -> failwith ("unmatched constant: "^ s)

let enum (type a) name ?typedef ?unexpected (alist : (a * int64) list) =
  match name with
  | s ->
    failwith ("unmatched enum: "^ s)
