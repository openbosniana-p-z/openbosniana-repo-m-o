module CI = Cstubs_internals

external caml__1_unix_errno_reset : unit -> unit = "caml__1_unix_errno_reset" 

external caml__2_unix_errno_get : unit -> Signed.sint
  = "caml__2_unix_errno_get" 

external caml__3_unix_errno_echrng : unit -> Signed.sint
  = "caml__3_unix_errno_echrng" 

external caml__4_unix_errno_el2nsync : unit -> Signed.sint
  = "caml__4_unix_errno_el2nsync" 

external caml__5_unix_errno_el3hlt : unit -> Signed.sint
  = "caml__5_unix_errno_el3hlt" 

external caml__6_unix_errno_el3rst : unit -> Signed.sint
  = "caml__6_unix_errno_el3rst" 

external caml__7_unix_errno_elnrng : unit -> Signed.sint
  = "caml__7_unix_errno_elnrng" 

external caml__8_unix_errno_eunatch : unit -> Signed.sint
  = "caml__8_unix_errno_eunatch" 

external caml__9_unix_errno_enocsi : unit -> Signed.sint
  = "caml__9_unix_errno_enocsi" 

external caml__10_unix_errno_el2hlt : unit -> Signed.sint
  = "caml__10_unix_errno_el2hlt" 

external caml__11_unix_errno_ebade : unit -> Signed.sint
  = "caml__11_unix_errno_ebade" 

external caml__12_unix_errno_ebadr : unit -> Signed.sint
  = "caml__12_unix_errno_ebadr" 

external caml__13_unix_errno_exfull : unit -> Signed.sint
  = "caml__13_unix_errno_exfull" 

external caml__14_unix_errno_enoano : unit -> Signed.sint
  = "caml__14_unix_errno_enoano" 

external caml__15_unix_errno_ebadrqc : unit -> Signed.sint
  = "caml__15_unix_errno_ebadrqc" 

external caml__16_unix_errno_ebadslt : unit -> Signed.sint
  = "caml__16_unix_errno_ebadslt" 

external caml__17_unix_errno_ebfont : unit -> Signed.sint
  = "caml__17_unix_errno_ebfont" 

external caml__18_unix_errno_enonet : unit -> Signed.sint
  = "caml__18_unix_errno_enonet" 

external caml__19_unix_errno_enopkg : unit -> Signed.sint
  = "caml__19_unix_errno_enopkg" 

external caml__20_unix_errno_eadv : unit -> Signed.sint
  = "caml__20_unix_errno_eadv" 

external caml__21_unix_errno_esrmnt : unit -> Signed.sint
  = "caml__21_unix_errno_esrmnt" 

external caml__22_unix_errno_ecomm : unit -> Signed.sint
  = "caml__22_unix_errno_ecomm" 

external caml__23_unix_errno_edotdot : unit -> Signed.sint
  = "caml__23_unix_errno_edotdot" 

external caml__24_unix_errno_enotuniq : unit -> Signed.sint
  = "caml__24_unix_errno_enotuniq" 

external caml__25_unix_errno_ebadfd : unit -> Signed.sint
  = "caml__25_unix_errno_ebadfd" 

external caml__26_unix_errno_eremchg : unit -> Signed.sint
  = "caml__26_unix_errno_eremchg" 

external caml__27_unix_errno_elibacc : unit -> Signed.sint
  = "caml__27_unix_errno_elibacc" 

external caml__28_unix_errno_elibbad : unit -> Signed.sint
  = "caml__28_unix_errno_elibbad" 

external caml__29_unix_errno_elibscn : unit -> Signed.sint
  = "caml__29_unix_errno_elibscn" 

external caml__30_unix_errno_elibmax : unit -> Signed.sint
  = "caml__30_unix_errno_elibmax" 

external caml__31_unix_errno_elibexec : unit -> Signed.sint
  = "caml__31_unix_errno_elibexec" 

external caml__32_unix_errno_erestart : unit -> Signed.sint
  = "caml__32_unix_errno_erestart" 

external caml__33_unix_errno_estrpipe : unit -> Signed.sint
  = "caml__33_unix_errno_estrpipe" 

external caml__34_unix_errno_euclean : unit -> Signed.sint
  = "caml__34_unix_errno_euclean" 

external caml__35_unix_errno_enotnam : unit -> Signed.sint
  = "caml__35_unix_errno_enotnam" 

external caml__36_unix_errno_enavail : unit -> Signed.sint
  = "caml__36_unix_errno_enavail" 

external caml__37_unix_errno_eisnam : unit -> Signed.sint
  = "caml__37_unix_errno_eisnam" 

external caml__38_unix_errno_eremoteio : unit -> Signed.sint
  = "caml__38_unix_errno_eremoteio" 

external caml__39_unix_errno_enomedium : unit -> Signed.sint
  = "caml__39_unix_errno_enomedium" 

external caml__40_unix_errno_emediumtype : unit -> Signed.sint
  = "caml__40_unix_errno_emediumtype" 

external caml__41_unix_errno_enokey : unit -> Signed.sint
  = "caml__41_unix_errno_enokey" 

external caml__42_unix_errno_ekeyexpired : unit -> Signed.sint
  = "caml__42_unix_errno_ekeyexpired" 

external caml__43_unix_errno_ekeyrevoked : unit -> Signed.sint
  = "caml__43_unix_errno_ekeyrevoked" 

external caml__44_unix_errno_ekeyrejected : unit -> Signed.sint
  = "caml__44_unix_errno_ekeyrejected" 

external caml__45_unix_errno_erfkill : unit -> Signed.sint
  = "caml__45_unix_errno_erfkill" 

external caml__46_unix_errno_ehwpoison : unit -> Signed.sint
  = "caml__46_unix_errno_ehwpoison" 

external caml__47_unix_errno_epwroff : unit -> Signed.sint
  = "caml__47_unix_errno_epwroff" 

external caml__48_unix_errno_edeverr : unit -> Signed.sint
  = "caml__48_unix_errno_edeverr" 

external caml__49_unix_errno_ebadexec : unit -> Signed.sint
  = "caml__49_unix_errno_ebadexec" 

external caml__50_unix_errno_ebadarch : unit -> Signed.sint
  = "caml__50_unix_errno_ebadarch" 

external caml__51_unix_errno_eshlibvers : unit -> Signed.sint
  = "caml__51_unix_errno_eshlibvers" 

external caml__52_unix_errno_ebadmacho : unit -> Signed.sint
  = "caml__52_unix_errno_ebadmacho" 

external caml__53_unix_errno_enopolicy : unit -> Signed.sint
  = "caml__53_unix_errno_enopolicy" 

external caml__54_unix_errno_eqfull : unit -> Signed.sint
  = "caml__54_unix_errno_eqfull" 

external caml__55_unix_errno_edoofus : unit -> Signed.sint
  = "caml__55_unix_errno_edoofus" 

external caml__56_unix_errno_enotcapable : unit -> Signed.sint
  = "caml__56_unix_errno_enotcapable" 

external caml__57_unix_errno_ecapmode : unit -> Signed.sint
  = "caml__57_unix_errno_ecapmode" 

external caml__58_unix_errno_eproclim : unit -> Signed.sint
  = "caml__58_unix_errno_eproclim" 

external caml__59_unix_errno_ebadrpc : unit -> Signed.sint
  = "caml__59_unix_errno_ebadrpc" 

external caml__60_unix_errno_erpcmismatch : unit -> Signed.sint
  = "caml__60_unix_errno_erpcmismatch" 

external caml__61_unix_errno_eprogunavail : unit -> Signed.sint
  = "caml__61_unix_errno_eprogunavail" 

external caml__62_unix_errno_eprogmismatch : unit -> Signed.sint
  = "caml__62_unix_errno_eprogmismatch" 

external caml__63_unix_errno_eprocunavail : unit -> Signed.sint
  = "caml__63_unix_errno_eprocunavail" 

external caml__64_unix_errno_eftype : unit -> Signed.sint
  = "caml__64_unix_errno_eftype" 

external caml__65_unix_errno_eauth : unit -> Signed.sint
  = "caml__65_unix_errno_eauth" 

external caml__66_unix_errno_eneedauth : unit -> Signed.sint
  = "caml__66_unix_errno_eneedauth" 

external caml__67_unix_errno_enoattr : unit -> Signed.sint
  = "caml__67_unix_errno_enoattr" 

external caml__68_unix_errno_enostr : unit -> Signed.sint
  = "caml__68_unix_errno_enostr" 

external caml__69_unix_errno_enodata : unit -> Signed.sint
  = "caml__69_unix_errno_enodata" 

external caml__70_unix_errno_etime : unit -> Signed.sint
  = "caml__70_unix_errno_etime" 

external caml__71_unix_errno_enosr : unit -> Signed.sint
  = "caml__71_unix_errno_enosr" 

type 'a result = 'a
type 'a return = 'a
type 'a fn =
 | Returns  : 'a CI.typ   -> 'a return fn
 | Function : 'a CI.typ * 'b fn  -> ('a -> 'b) fn
let map_result f x = f x
let returning t = Returns t
let (@->) f p = Function (f, p)
let foreign : type a b. string -> (a -> b) fn -> (a -> b) =
  fun name t -> match t, name with
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enosr" ->
  caml__71_unix_errno_enosr
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_etime" ->
  caml__70_unix_errno_etime
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enodata" ->
  caml__69_unix_errno_enodata
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enostr" ->
  caml__68_unix_errno_enostr
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enoattr" ->
  caml__67_unix_errno_enoattr
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eneedauth" ->
  caml__66_unix_errno_eneedauth
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eauth" ->
  caml__65_unix_errno_eauth
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eftype" ->
  caml__64_unix_errno_eftype
| Function (CI.Void, Returns (CI.Primitive CI.Sint)),
  "unix_errno_eprocunavail" -> caml__63_unix_errno_eprocunavail
| Function (CI.Void, Returns (CI.Primitive CI.Sint)),
  "unix_errno_eprogmismatch" -> caml__62_unix_errno_eprogmismatch
| Function (CI.Void, Returns (CI.Primitive CI.Sint)),
  "unix_errno_eprogunavail" -> caml__61_unix_errno_eprogunavail
| Function (CI.Void, Returns (CI.Primitive CI.Sint)),
  "unix_errno_erpcmismatch" -> caml__60_unix_errno_erpcmismatch
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ebadrpc" ->
  caml__59_unix_errno_ebadrpc
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eproclim" ->
  caml__58_unix_errno_eproclim
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ecapmode" ->
  caml__57_unix_errno_ecapmode
| Function (CI.Void, Returns (CI.Primitive CI.Sint)),
  "unix_errno_enotcapable" -> caml__56_unix_errno_enotcapable
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_edoofus" ->
  caml__55_unix_errno_edoofus
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eqfull" ->
  caml__54_unix_errno_eqfull
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enopolicy" ->
  caml__53_unix_errno_enopolicy
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ebadmacho" ->
  caml__52_unix_errno_ebadmacho
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eshlibvers" ->
  caml__51_unix_errno_eshlibvers
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ebadarch" ->
  caml__50_unix_errno_ebadarch
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ebadexec" ->
  caml__49_unix_errno_ebadexec
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_edeverr" ->
  caml__48_unix_errno_edeverr
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_epwroff" ->
  caml__47_unix_errno_epwroff
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ehwpoison" ->
  caml__46_unix_errno_ehwpoison
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_erfkill" ->
  caml__45_unix_errno_erfkill
| Function (CI.Void, Returns (CI.Primitive CI.Sint)),
  "unix_errno_ekeyrejected" -> caml__44_unix_errno_ekeyrejected
| Function (CI.Void, Returns (CI.Primitive CI.Sint)),
  "unix_errno_ekeyrevoked" -> caml__43_unix_errno_ekeyrevoked
| Function (CI.Void, Returns (CI.Primitive CI.Sint)),
  "unix_errno_ekeyexpired" -> caml__42_unix_errno_ekeyexpired
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enokey" ->
  caml__41_unix_errno_enokey
| Function (CI.Void, Returns (CI.Primitive CI.Sint)),
  "unix_errno_emediumtype" -> caml__40_unix_errno_emediumtype
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enomedium" ->
  caml__39_unix_errno_enomedium
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eremoteio" ->
  caml__38_unix_errno_eremoteio
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eisnam" ->
  caml__37_unix_errno_eisnam
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enavail" ->
  caml__36_unix_errno_enavail
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enotnam" ->
  caml__35_unix_errno_enotnam
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_euclean" ->
  caml__34_unix_errno_euclean
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_estrpipe" ->
  caml__33_unix_errno_estrpipe
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_erestart" ->
  caml__32_unix_errno_erestart
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_elibexec" ->
  caml__31_unix_errno_elibexec
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_elibmax" ->
  caml__30_unix_errno_elibmax
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_elibscn" ->
  caml__29_unix_errno_elibscn
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_elibbad" ->
  caml__28_unix_errno_elibbad
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_elibacc" ->
  caml__27_unix_errno_elibacc
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eremchg" ->
  caml__26_unix_errno_eremchg
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ebadfd" ->
  caml__25_unix_errno_ebadfd
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enotuniq" ->
  caml__24_unix_errno_enotuniq
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_edotdot" ->
  caml__23_unix_errno_edotdot
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ecomm" ->
  caml__22_unix_errno_ecomm
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_esrmnt" ->
  caml__21_unix_errno_esrmnt
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eadv" ->
  caml__20_unix_errno_eadv
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enopkg" ->
  caml__19_unix_errno_enopkg
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enonet" ->
  caml__18_unix_errno_enonet
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ebfont" ->
  caml__17_unix_errno_ebfont
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ebadslt" ->
  caml__16_unix_errno_ebadslt
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ebadrqc" ->
  caml__15_unix_errno_ebadrqc
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enoano" ->
  caml__14_unix_errno_enoano
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_exfull" ->
  caml__13_unix_errno_exfull
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ebadr" ->
  caml__12_unix_errno_ebadr
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_ebade" ->
  caml__11_unix_errno_ebade
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_el2hlt" ->
  caml__10_unix_errno_el2hlt
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_enocsi" ->
  caml__9_unix_errno_enocsi
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_eunatch" ->
  caml__8_unix_errno_eunatch
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_elnrng" ->
  caml__7_unix_errno_elnrng
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_el3rst" ->
  caml__6_unix_errno_el3rst
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_el3hlt" ->
  caml__5_unix_errno_el3hlt
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_el2nsync" ->
  caml__4_unix_errno_el2nsync
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_echrng" ->
  caml__3_unix_errno_echrng
| Function (CI.Void, Returns (CI.Primitive CI.Sint)), "unix_errno_get" ->
  caml__2_unix_errno_get
| Function (CI.Void, Returns CI.Void), "unix_errno_reset" ->
  caml__1_unix_errno_reset
| _, s ->  Printf.ksprintf failwith "No match for %s" s


let foreign_value : type a. string -> a Ctypes.typ -> a Ctypes.ptr =
  fun name t -> match t, name with
| _, s ->  Printf.ksprintf failwith "No match for %s" s
