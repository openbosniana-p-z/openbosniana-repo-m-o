test data taken from the gdcmData repo of GDCM.
http://sourceforge.net/projects/gdcm/files/gdcmData/gdcmData/
