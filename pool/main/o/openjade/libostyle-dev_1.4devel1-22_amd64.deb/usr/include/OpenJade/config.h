/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */
// Copyright (C) 1999 Matthias Clasen, Peter Nilsson
// See the file COPYING for copying permissions.


#include <OpenSP/config.h>


/* these are needed for GNU gettext */
#define ENABLE_NLS 1
/* #undef HAVE_CATGETS */
#define HAVE_GETTEXT 1
/* #undef HAVE_LC_MESSAGES */
/* #undef HAVE_STPCPY */

#define OPENJADE_PACKAGE "OpenJade"
#define OPENJADE_VERSION "1.4devel"
/* #undef OPENJADE_LOCALE_DIR */

/* set this to the location of builtins.dsl */
#define DEFAULT_SCHEME_BUILTINS "/usr/share/sgml/OpenJade/builtins.dsl"

/* define this to build the html backend */
#define JADE_HTML 1

/* define this to build the mif backend */
#define JADE_MIF 1

/* define this to build the grove in a separate thread, if possible */
/* #undef USE_THREADS */
 
/* define this appropriately if the type sig_atomic_t is not available */
/* #undef sig_atomic_t */

/* define this if your system misses new.h */
/* #undef SP_NEW_H_MISSING */

/* define this if  set_new_handler() has to be declared extern "C" */
/* #undef SP_SET_NEW_HANDLER_EXTERN_C */

/* define this to build a multi-byte version */
#define SP_MULTI_BYTE 1

/* define this to include template definitions in the headers */
#define SP_DEFINE_TEMPLATES 1

/* define this to compile explicit template instantiations */
/* #undef SP_MANUAL_INST */

/* define this if new.h doesn't declare void *operator new(size_t, void *p) */
/* #undef SP_DECLARE_PLACEMENT_OPERATOR_NEW */

/* define this if the new handler takes size_t and returns int. */
/* #undef SP_FANCY_NEW_HANDLER */


/* set this to the location of builtins.dsl */
#define DEFAULT_SCHEME_BUILTINS "/usr/share/sgml/OpenJade/builtins.dsl"

/* Define to 1 if translation of program messages to the user's native
   language is requested. */
#define ENABLE_NLS 1

/* define if bool is a built-in type */
#define HAVE_BOOL /**/

/* Define to 1 if you have the <cassert> header file. */
#define HAVE_CASSERT 1

/* Define to 1 if you have the Mac OS X function
   CFLocaleCopyPreferredLanguages in the CoreFoundation framework. */
/* #undef HAVE_CFLOCALECOPYPREFERREDLANGUAGES */

/* Define to 1 if you have the Mac OS X function CFPreferencesCopyAppValue in
   the CoreFoundation framework. */
/* #undef HAVE_CFPREFERENCESCOPYAPPVALUE */

/* Define if the GNU dcgettext() function is already present or preinstalled.
   */
#define HAVE_DCGETTEXT 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* define if the compiler supports dynamic_cast<> */
#define HAVE_DYNAMIC_CAST /**/

/* Define if the GNU gettext() function is already present or preinstalled. */
#define HAVE_GETTEXT 1

/* Define if you have the iconv() function and it works. */
/* #undef HAVE_ICONV */

/* define if the compiler supports explicit instantiations */
#define HAVE_INSTANTIATIONS /**/

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `pthread' library (-lpthread). */
#define HAVE_LIBPTHREAD 1

/* Define to 1 if you have the `threads' library (-lthreads). */
/* #undef HAVE_LIBTHREADS */

/* Define to 1 if you have the `w' library (-lw). */
/* #undef HAVE_LIBW */

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if you have the <locale.h> header file. */
#define HAVE_LOCALE_H 1

/* Define to 1 if you have the `memcmp' function. */
#define HAVE_MEMCMP 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* define if the compiler supports the mutable keyword */
#define HAVE_MUTABLE /**/

/* define if the compiler implements namespaces */
#define HAVE_NAMESPACES /**/

/* define if the C++ compiler supports the std namespace */
#define HAVE_NAMESPACE_STD 1

/* Define to 1 if you have the <new> header file. */
#define HAVE_NEW 1

/* define if the compiler accepts the new for scoping rules */
#define HAVE_NEW_FOR_SCOPING /**/

/* define if the compiler supports placement operator delete */
/* #undef HAVE_PLACEMENT_OPERATOR_DELETE */

/* define if placement operator new is declared */
#define HAVE_PLACEMENT_OPERATOR_NEW 1

/* Define to 1 if you have the `setlocale' function. */
#define HAVE_SETLOCALE 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if `st_blksize' is a member of `struct stat'. */
#define HAVE_STRUCT_STAT_ST_BLKSIZE 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* define if the compiler recognizes typename */
#define HAVE_TYPENAME /**/

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* define this to build the html backend */
#define JADE_HTML 1

/* define this to build the mif backend */
#define JADE_MIF 1

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* location of message catalogs */
/* #undef OPENJADE_LOCALE_DIR */

/* message domain */
#define OPENJADE_MESSAGE_DOMAIN "jade"

/* Package name */
#define OPENJADE_PACKAGE "OpenJade"

/* Package version */
#define OPENJADE_VERSION "1.4devel"

/* Name of package */
#define PACKAGE "OpenJade"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "OpenJade"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "OpenJade 1.4devel"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "OpenJade"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.4devel"

/* The size of `bool', as computed by sizeof. */
#define SIZEOF_BOOL 1

/* The size of `size_t', as computed by sizeof. */
#define SIZEOF_SIZE_T 8

/* The size of `unsigned int', as computed by sizeof. */
#define SIZEOF_UNSIGNED_INT 4

/* The size of `unsigned short', as computed by sizeof. */
#define SIZEOF_UNSIGNED_SHORT 2

/* Size of the wchar_t type */
#define SIZEOF_WCHAR_T 0

/* define this to include template definitions in the headers */
#define SP_DEFINE_TEMPLATES 1

/* define this if the new handler takes size_t and returns int */
/* #undef SP_FANCY_NEW_HANDLER */

/* define this to compile explicit template instantiations */
/* #undef SP_MANUAL_INST */

/* define this to build a multi-byte version */
#define SP_MULTI_BYTE 1

/* define this if your system misses new.h */
/* #undef SP_NEW_H_MISSING */

/* define this if set_new_handler() has to be declared extern "C" */
/* #undef SP_SET_NEW_HANDLER_EXTERN_C */

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Enable extensions on AIX 3, Interix.  */
#ifndef _ALL_SOURCE
# define _ALL_SOURCE 1
#endif
/* Enable GNU extensions on systems that have them.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE 1
#endif
/* Enable threading extensions on Solaris.  */
#ifndef _POSIX_PTHREAD_SEMANTICS
# define _POSIX_PTHREAD_SEMANTICS 1
#endif
/* Enable extensions on HP NonStop.  */
#ifndef _TANDEM_SOURCE
# define _TANDEM_SOURCE 1
#endif
/* Enable general extensions on Solaris.  */
#ifndef __EXTENSIONS__
# define __EXTENSIONS__ 1
#endif


/* define this to build the grove in a separate thread, if possible */
/* #undef USE_THREADS */

/* Version number of package */
#define VERSION "1.4devel"

/* Define to 1 if on MINIX. */
/* #undef _MINIX */

/* Define to 2 if the system does not provide POSIX.1 features except with
   this defined. */
/* #undef _POSIX_1_SOURCE */

/* Define to 1 if you need to in order for `stat' and other things to work. */
/* #undef _POSIX_SOURCE */

/* Define to `int' if <sys/types.h> does not define. */
/* #undef sig_atomic_t */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */

#ifdef HAVE_BOOL 
#define SP_HAVE_BOOL
#endif /* HAVE_BOOL */

#if (SIZEOF_BOOL == 1)
#define SP_SIZEOF_BOOL_1
#endif

#if (SIZEOF_WCHAR_T == SIZEOF_UNSIGNED_SHORT)
#define SP_WCHAR_T_USHORT
#endif

#ifdef SP_HAVE_SETMODE
#ifndef SP_LINE_TERM1
#define SP_LINE_TERM1 '\r'
#define SP_LINE_TERM2 '\n'
#endif
#endif /* not SP_HAVE_SETMODE */

#ifndef SP_LINE_TERM1
#define SP_LINE_TERM1 '\n'
#endif

#ifndef HAVE_NEW_FOR_SCOPING
// This simulates the new ANSI "for" scope rules
#define for if (0); else for
#endif /* HAVE_NEW_FOR_SCOPING */

#ifndef SP_HAVE_TYPENAME
#define typename /* as nothing */
#endif

#ifndef SP_DLLEXPORT
#define SP_DLLEXPORT /* as nothing */
#endif

#ifndef SP_DLLIMPORT
#define SP_DLLIMPORT /* as nothing */
#endif

#ifdef SP_USE_DLL

#ifdef BUILD_LIBSP
#define SP_API SP_DLLEXPORT
#else
#define SP_API SP_DLLIMPORT
#endif

#else /* not SP_USE_DLL */

#define SP_API /* as nothing */

#endif /* not SP_USE_DLL */

#ifdef SP_WIDE_SYSTEM
#ifndef SP_MULTI_BYTE
#define SP_MULTI_BYTE 1
#endif
#endif

#ifdef HAVE_NAMESPACES
#define SP_NAMESPACE OpenSP
#define DSSSL_NAMESPACE OpenJade_DSSSL
#define GROVE_NAMESPACE OpenJade_Grove
#endif /* HAVE_NAMESPACES */

#ifdef SP_NAMESPACE
#define SP_NAMESPACE_SCOPE SP_NAMESPACE::
#else
#define SP_NAMESPACE_SCOPE
#endif /* SP_NAMESPACE */

#ifdef HAVE_DYNAMIC_CAST
#define SP_HAVE_RTTI
#endif /* HAVE_DYNAMIC_CAST */

#ifdef HAVE_TYPENAME
#define SP_HAVE_TYPENAME
#endif /* HAVE_TYPENAME */

#ifdef HAVE_PATHNAME_STYLE_DOS
#define SP_MSDOS_FILENAMES 
#else 
#define SP_POSIX_FILENAMES  
#endif /* HAVE_PATHNAME_STYLE_DOS */

#ifdef HAVE_INSTANTIATIONS
#define SP_ANSI_CLASS_INST
#endif /* HAVE_INSTANTIATIONS */ 

#ifdef HAVE_SETLOCALE
#define SP_HAVE_LOCALE
#endif /* HAVE_SETLOCALE */

#ifdef HAVE_GETTEXT
#define SP_HAVE_GETTEXT 
#endif /* HAVE_GETTEXT */

#ifdef WORDS_BIGENDIAN
#define SP_BIG_ENDIAN
#endif /* WORDS_BIGENDIAN */

#ifdef HAVE_LIBTHREADS
#define SP_MUTEX_MACH
#endif /* HAVE_LIBTHREADS */

#ifdef HAVE_LIBPTHREAD
#define SP_MUTEX_PTHREADS
#endif /* HAVE_LIBPTHREAD */

#ifdef HAVE_PLACEMENT_OPERATOR_DELETE
#define SP_HAVE_PLACEMENT_OPERATOR_DELETE
#endif /* HAVE_PLACEMENT_OPERATOR_DELETE */

#ifndef HAVE_PLACEMENT_OPERATOR_NEW
#define SP_DECLARE_PLACEMENT_OPERATOR_NEW
#endif /* HAVE_PLACEMENT_OPERATOR_NEW */

#ifndef HAVE_NAMESPACE_STD
#define SP_NO_STD_NAMESPACE
#endif /* HAVE_NAMESPACE_STD */
