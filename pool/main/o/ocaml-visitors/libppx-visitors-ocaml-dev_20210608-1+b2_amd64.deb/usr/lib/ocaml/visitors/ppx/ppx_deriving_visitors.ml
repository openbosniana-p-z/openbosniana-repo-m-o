(** @canonical Ppx_deriving_visitors.Visitors *)
module Visitors = Ppx_deriving_visitors__Visitors


(** @canonical Ppx_deriving_visitors.VisitorsAnalysis *)
module VisitorsAnalysis = Ppx_deriving_visitors__VisitorsAnalysis


(** @canonical Ppx_deriving_visitors.VisitorsCompatibility *)
module VisitorsCompatibility = Ppx_deriving_visitors__VisitorsCompatibility


(** @canonical Ppx_deriving_visitors.VisitorsGeneration *)
module VisitorsGeneration = Ppx_deriving_visitors__VisitorsGeneration


(** @canonical Ppx_deriving_visitors.VisitorsList *)
module VisitorsList = Ppx_deriving_visitors__VisitorsList


(** @canonical Ppx_deriving_visitors.VisitorsPlugin *)
module VisitorsPlugin = Ppx_deriving_visitors__VisitorsPlugin


(** @canonical Ppx_deriving_visitors.VisitorsSettings *)
module VisitorsSettings = Ppx_deriving_visitors__VisitorsSettings


(** @canonical Ppx_deriving_visitors.VisitorsString *)
module VisitorsString = Ppx_deriving_visitors__VisitorsString
