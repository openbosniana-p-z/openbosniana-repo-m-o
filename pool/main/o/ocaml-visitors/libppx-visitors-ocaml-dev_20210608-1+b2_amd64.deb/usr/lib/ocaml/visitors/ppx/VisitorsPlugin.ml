(* The name of our [ppx_deriving] plugin. *)

let plugin =
  "visitors"
