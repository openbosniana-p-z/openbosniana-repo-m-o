#!/usr/bin/env bash

# This script echoes back the environment. This is used for spec testing
# and possible debugging.

env
