module OctocatalogDiff
  class Version
    VERSION = "2.1.0-1".freeze
  end
end
