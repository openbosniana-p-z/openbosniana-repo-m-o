import orthanc
orthanc.LogWarning('Hello world from Python!')
