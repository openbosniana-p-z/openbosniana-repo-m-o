(** @canonical Base64.Unsafe *)
module Unsafe = Base64__Unsafe
