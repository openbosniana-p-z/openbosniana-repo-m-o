external unsafe_set_uint16 : bytes -> int -> int -> unit = "%caml_bytes_set16u"
  [@@noalloc]
