(** @canonical Atdgen_runtime.Json_adapter *)
module Json_adapter = Atdgen_runtime__Json_adapter


(** @canonical Atdgen_runtime.Ob_run *)
module Ob_run = Atdgen_runtime__Ob_run


(** @canonical Atdgen_runtime.Oj_run *)
module Oj_run = Atdgen_runtime__Oj_run


(** @canonical Atdgen_runtime.Ov_run *)
module Ov_run = Atdgen_runtime__Ov_run


(** @canonical Atdgen_runtime.Util *)
module Util = Atdgen_runtime__Util


(** @canonical Atdgen_runtime.Version *)
module Version = Atdgen_runtime__Version
