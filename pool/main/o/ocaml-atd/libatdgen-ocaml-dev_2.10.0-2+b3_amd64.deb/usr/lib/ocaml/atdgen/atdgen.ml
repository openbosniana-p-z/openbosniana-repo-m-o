[@@@deprecated "The runtime for Atdgen is now the module Atdgen_runtime existing
in the atdgen-runtime opam package"]
include Atdgen_runtime
