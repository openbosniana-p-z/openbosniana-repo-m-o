(** @canonical Atdgen_codec_runtime.Decode *)
module Decode = Atdgen_codec_runtime__Decode


(** @canonical Atdgen_codec_runtime.Encode *)
module Encode = Atdgen_codec_runtime__Encode


(** @canonical Atdgen_codec_runtime.Json *)
module Json = Atdgen_codec_runtime__Json


(** @canonical Atdgen_codec_runtime.Json_adapter *)
module Json_adapter = Atdgen_codec_runtime__Json_adapter
