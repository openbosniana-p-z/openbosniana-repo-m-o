(** @canonical Atdgen.Version *)
module Version = Atdgen__Version
