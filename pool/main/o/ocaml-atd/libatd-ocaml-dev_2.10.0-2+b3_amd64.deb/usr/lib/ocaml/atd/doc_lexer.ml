# 1 "atd/src/doc_lexer.mll"
 
  open Doc_types

  let close_paragraph a1 a2 a3 =
    let a2 =
      match String.concat "" (List.rev a3) with
          "" -> a2
        | s -> Text s :: a2
    in
    match List.rev a2 with
        [] -> a1
      | l -> Paragraph l :: a1

# 16 "atd/src/doc_lexer.ml"
let __ocaml_lex_tables = {
  Lexing.lex_base =
   "\000\000\248\255\249\255\005\000\010\000\012\000\001\000\003\000\
    \004\000\255\255\006\000\008\000\014\000\253\255\001\000\009\000\
    \011\000\020\000\025\000\249\255\011\000\030\000\036\000\012\000\
    \013\000\255\255\254\255\014\000\250\255\050\000\248\255\250\255\
    \015\000\016\000\056\000\002\000\253\255\019\000\020\000\255\255\
    \021\000\254\255\022\000\024\000\026\000\249\255";
  Lexing.lex_backtrk =
   "\004\000\255\255\255\255\003\000\004\000\004\000\007\000\007\000\
    \255\255\255\255\000\000\001\000\002\000\255\255\255\255\255\255\
    \255\255\005\000\255\255\255\255\004\000\003\000\002\000\004\000\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \005\000\005\000\004\000\005\000\255\255\005\000\255\255\255\255\
    \255\255\255\255\003\000\255\255\255\255\255\255";
  Lexing.lex_default =
   "\003\000\000\000\000\000\003\000\255\255\255\255\255\255\255\255\
    \255\255\000\000\255\255\255\255\255\255\000\000\255\255\255\255\
    \255\255\255\255\021\000\000\000\255\255\021\000\255\255\255\255\
    \255\255\000\000\000\000\255\255\000\000\034\000\000\000\000\000\
    \255\255\255\255\034\000\255\255\000\000\255\255\255\255\000\000\
    \255\255\000\000\255\255\255\255\255\255\000\000";
  Lexing.lex_trans =
   "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\005\000\004\000\013\000\042\000\005\000\255\255\255\255\
    \000\000\000\000\255\255\004\000\017\000\005\000\004\000\004\000\
    \013\000\005\000\000\000\014\000\000\000\017\000\017\000\000\000\
    \005\000\017\000\022\000\022\000\000\000\255\255\022\000\255\255\
    \255\255\000\000\004\000\255\255\005\000\022\000\022\000\000\000\
    \000\000\022\000\000\000\000\000\017\000\000\000\000\000\000\000\
    \000\000\022\000\000\000\036\000\033\000\000\000\255\255\035\000\
    \000\000\255\255\255\255\000\000\022\000\255\255\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\031\000\000\000\000\000\000\000\000\000\000\000\
    \255\255\000\000\000\000\000\000\007\000\000\000\000\000\009\000\
    \000\000\255\255\000\000\000\000\000\000\000\000\000\000\000\000\
    \025\000\000\000\000\000\000\000\000\000\000\000\000\000\039\000\
    \000\000\000\000\000\000\000\000\000\000\023\000\000\000\000\000\
    \000\000\000\000\255\255\006\000\011\000\001\000\008\000\010\000\
    \255\255\009\000\255\255\012\000\016\000\015\000\012\000\015\000\
    \028\000\024\000\026\000\028\000\044\000\043\000\037\000\015\000\
    \038\000\040\000\041\000\043\000\255\255\044\000\020\000\045\000\
    \000\000\000\000\000\000\255\255\000\000\000\000\000\000\000\000\
    \000\000\027\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\032\000\
    \000\000\000\000\000\000\000\000\000\000\255\255\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \002\000\000\000\000\000\000\000\000\000\255\255\000\000\000\000\
    \000\000\000\000\002\000\000\000\002\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\002\000\000\000\000\000\000\000\
    \000\000\019\000\000\000\000\000\000\000\000\000\255\255\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\030\000\000\000\000\000\000\000\000\000\000\000\
    \255\255";
  Lexing.lex_check =
   "\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\000\000\000\000\014\000\035\000\000\000\003\000\003\000\
    \255\255\255\255\003\000\004\000\004\000\005\000\005\000\004\000\
    \012\000\005\000\255\255\012\000\255\255\017\000\017\000\255\255\
    \000\000\017\000\018\000\018\000\255\255\003\000\018\000\021\000\
    \021\000\255\255\004\000\021\000\005\000\022\000\022\000\255\255\
    \255\255\022\000\255\255\255\255\017\000\255\255\255\255\255\255\
    \255\255\018\000\255\255\029\000\029\000\255\255\021\000\029\000\
    \255\255\034\000\034\000\255\255\022\000\034\000\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\029\000\255\255\255\255\255\255\255\255\255\255\
    \034\000\255\255\255\255\255\255\000\000\255\255\255\255\007\000\
    \255\255\003\000\255\255\255\255\255\255\255\255\255\255\255\255\
    \023\000\255\255\255\255\255\255\255\255\255\255\255\255\037\000\
    \255\255\255\255\255\255\255\255\255\255\018\000\255\255\255\255\
    \255\255\255\255\021\000\000\000\006\000\000\000\007\000\008\000\
    \003\000\010\000\003\000\011\000\015\000\004\000\016\000\005\000\
    \020\000\023\000\024\000\027\000\032\000\033\000\029\000\017\000\
    \037\000\038\000\040\000\042\000\034\000\043\000\018\000\044\000\
    \255\255\255\255\255\255\021\000\255\255\255\255\255\255\255\255\
    \255\255\022\000\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\029\000\
    \255\255\255\255\255\255\255\255\255\255\034\000\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \000\000\255\255\255\255\255\255\255\255\003\000\255\255\255\255\
    \255\255\255\255\004\000\255\255\005\000\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\017\000\255\255\255\255\255\255\
    \255\255\018\000\255\255\255\255\255\255\255\255\021\000\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\029\000\255\255\255\255\255\255\255\255\255\255\
    \034\000";
  Lexing.lex_base_code =
   "";
  Lexing.lex_backtrk_code =
   "";
  Lexing.lex_default_code =
   "";
  Lexing.lex_trans_code =
   "";
  Lexing.lex_check_code =
   "";
  Lexing.lex_code =
   "";
}

let rec paragraph a1 a2 a3 lexbuf =
   __ocaml_lex_paragraph_rec a1 a2 a3 lexbuf 0
and __ocaml_lex_paragraph_rec a1 a2 a3 lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
let
# 27 "atd/src/doc_lexer.mll"
                                 s
# 143 "atd/src/doc_lexer.ml"
= Lexing.sub_lexeme lexbuf (lexbuf.Lexing.lex_start_pos + 1) lexbuf.Lexing.lex_curr_pos in
# 28 "atd/src/doc_lexer.mll"
                        ( paragraph a1 a2 (s :: a3) lexbuf )
# 147 "atd/src/doc_lexer.ml"

  | 1 ->
# 30 "atd/src/doc_lexer.mll"
                        ( let code = inline_verbatim [] lexbuf in
                          let a2 =
                            match String.concat "" (List.rev a3) with
                                "" -> a2
                              | s -> Text s :: a2
                          in
                          let a2 = Code code :: a2 in
                          paragraph a1 a2 [] lexbuf
                        )
# 160 "atd/src/doc_lexer.ml"

  | 2 ->
# 40 "atd/src/doc_lexer.mll"
                        ( let pre = verbatim [] lexbuf in
                          let a1 = close_paragraph a1 a2 a3 in
                          let a1 = Pre pre :: a1 in
                          paragraph a1 [] [] lexbuf
                        )
# 169 "atd/src/doc_lexer.ml"

  | 3 ->
let
# 45 "atd/src/doc_lexer.mll"
                        s
# 175 "atd/src/doc_lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 46 "atd/src/doc_lexer.mll"
                        ( paragraph a1 a2 (s :: a3) lexbuf )
# 179 "atd/src/doc_lexer.ml"

  | 4 ->
# 48 "atd/src/doc_lexer.mll"
                        ( paragraph a1 a2 (" " :: a3) lexbuf )
# 184 "atd/src/doc_lexer.ml"

  | 5 ->
# 50 "atd/src/doc_lexer.mll"
                        ( let a1 = close_paragraph a1 a2 a3 in
                          paragraph a1 [] [] lexbuf
                        )
# 191 "atd/src/doc_lexer.ml"

  | 6 ->
# 53 "atd/src/doc_lexer.mll"
                        ( let a1 = close_paragraph a1 a2 a3 in
                          List.rev a1 )
# 197 "atd/src/doc_lexer.ml"

  | 7 ->
let
# 56 "atd/src/doc_lexer.mll"
         c
# 203 "atd/src/doc_lexer.ml"
= Lexing.sub_lexeme_char lexbuf lexbuf.Lexing.lex_start_pos in
# 56 "atd/src/doc_lexer.mll"
                        ( paragraph a1 a2 (String.make 1 c :: a3) lexbuf )
# 207 "atd/src/doc_lexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf;
      __ocaml_lex_paragraph_rec a1 a2 a3 lexbuf __ocaml_lex_state

and inline_verbatim accu lexbuf =
   __ocaml_lex_inline_verbatim_rec accu lexbuf 18
and __ocaml_lex_inline_verbatim_rec accu lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 66 "atd/src/doc_lexer.mll"
                        ( inline_verbatim ("\\" :: accu) lexbuf )
# 219 "atd/src/doc_lexer.ml"

  | 1 ->
# 67 "atd/src/doc_lexer.mll"
                        ( inline_verbatim ("}}" :: accu) lexbuf )
# 224 "atd/src/doc_lexer.ml"

  | 2 ->
# 68 "atd/src/doc_lexer.mll"
                        ( inline_verbatim (" " :: accu) lexbuf )
# 229 "atd/src/doc_lexer.ml"

  | 3 ->
let
# 69 "atd/src/doc_lexer.mll"
                         s
# 235 "atd/src/doc_lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 70 "atd/src/doc_lexer.mll"
                        ( inline_verbatim (s :: accu) lexbuf )
# 239 "atd/src/doc_lexer.ml"

  | 4 ->
let
# 71 "atd/src/doc_lexer.mll"
         c
# 245 "atd/src/doc_lexer.ml"
= Lexing.sub_lexeme_char lexbuf lexbuf.Lexing.lex_start_pos in
# 71 "atd/src/doc_lexer.mll"
                        ( inline_verbatim (String.make 1 c :: accu) lexbuf )
# 249 "atd/src/doc_lexer.ml"

  | 5 ->
# 73 "atd/src/doc_lexer.mll"
                        ( String.concat "" (List.rev accu) )
# 254 "atd/src/doc_lexer.ml"

  | 6 ->
# 75 "atd/src/doc_lexer.mll"
                        ( failwith "Missing `}}'" )
# 259 "atd/src/doc_lexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf;
      __ocaml_lex_inline_verbatim_rec accu lexbuf __ocaml_lex_state

and verbatim accu lexbuf =
   __ocaml_lex_verbatim_rec accu lexbuf 29
and __ocaml_lex_verbatim_rec accu lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 84 "atd/src/doc_lexer.mll"
                        ( verbatim ("\\" :: accu) lexbuf )
# 271 "atd/src/doc_lexer.ml"

  | 1 ->
# 85 "atd/src/doc_lexer.mll"
                        ( verbatim ("}}}" :: accu) lexbuf )
# 276 "atd/src/doc_lexer.ml"

  | 2 ->
# 86 "atd/src/doc_lexer.mll"
                        ( verbatim ("        " :: accu) lexbuf )
# 281 "atd/src/doc_lexer.ml"

  | 3 ->
# 87 "atd/src/doc_lexer.mll"
                        ( verbatim ("\n" :: accu) lexbuf )
# 286 "atd/src/doc_lexer.ml"

  | 4 ->
let
# 88 "atd/src/doc_lexer.mll"
                         s
# 292 "atd/src/doc_lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 89 "atd/src/doc_lexer.mll"
                        ( verbatim (s :: accu) lexbuf )
# 296 "atd/src/doc_lexer.ml"

  | 5 ->
let
# 90 "atd/src/doc_lexer.mll"
         c
# 302 "atd/src/doc_lexer.ml"
= Lexing.sub_lexeme_char lexbuf lexbuf.Lexing.lex_start_pos in
# 90 "atd/src/doc_lexer.mll"
                        ( verbatim (String.make 1 c :: accu) lexbuf )
# 306 "atd/src/doc_lexer.ml"

  | 6 ->
# 92 "atd/src/doc_lexer.mll"
                        ( String.concat "" (List.rev accu) )
# 311 "atd/src/doc_lexer.ml"

  | 7 ->
# 94 "atd/src/doc_lexer.mll"
                        ( failwith "Missing `}}}'" )
# 316 "atd/src/doc_lexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf;
      __ocaml_lex_verbatim_rec accu lexbuf __ocaml_lex_state

;;

# 96 "atd/src/doc_lexer.mll"
 
  let parse_string s =
    let lexbuf = Lexing.from_string s in
    paragraph [] [] [] lexbuf

# 329 "atd/src/doc_lexer.ml"
