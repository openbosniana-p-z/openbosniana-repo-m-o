(** @canonical Atd.Annot *)
module Annot = Atd__Annot


(** @canonical Atd.Ast *)
module Ast = Atd__Ast


(** @canonical Atd.Check *)
module Check = Atd__Check


(** @canonical Atd.Doc *)
module Doc = Atd__Doc


(** @canonical Atd.Doc_lexer *)
module Doc_lexer = Atd__Doc_lexer


(** @canonical Atd.Doc_types *)
module Doc_types = Atd__Doc_types


(** @canonical Atd.Expand *)
module Expand = Atd__Expand


(** @canonical Atd.Import *)
module Import = Atd__Import


(** @canonical Atd.Inherit *)
module Inherit = Atd__Inherit


(** @canonical Atd.Json *)
module Json = Atd__Json


(** @canonical Atd.Jsonschema *)
module Jsonschema = Atd__Jsonschema


(** @canonical Atd.Lexer *)
module Lexer = Atd__Lexer


(** @canonical Atd.Parser *)
module Parser = Atd__Parser


(** @canonical Atd.Predef *)
module Predef = Atd__Predef


(** @canonical Atd.Print *)
module Print = Atd__Print


(** @canonical Atd.Reflect *)
module Reflect = Atd__Reflect


(** @canonical Atd.Sort *)
module Sort = Atd__Sort


(** @canonical Atd.Unique_name *)
module Unique_name = Atd__Unique_name


(** @canonical Atd.Util *)
module Util = Atd__Util


(** @canonical Atd.Version *)
module Version = Atd__Version
