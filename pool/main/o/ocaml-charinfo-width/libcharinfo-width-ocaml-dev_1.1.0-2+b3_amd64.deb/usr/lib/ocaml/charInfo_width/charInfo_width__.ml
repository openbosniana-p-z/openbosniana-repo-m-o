(** @canonical CharInfo_width.Cfg *)
module Cfg = CharInfo_width__Cfg


(** @canonical CharInfo_width.Codes *)
module Codes = CharInfo_width__Codes


(** @canonical CharInfo_width.Combining *)
module Combining = CharInfo_width__Combining


(** @canonical CharInfo_width.Fullwidth *)
module Fullwidth = CharInfo_width__Fullwidth
