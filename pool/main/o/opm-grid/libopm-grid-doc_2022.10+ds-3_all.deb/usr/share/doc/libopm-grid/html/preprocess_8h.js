var preprocess_8h =
[
    [ "grdecl", "structgrdecl.html", "structgrdecl" ],
    [ "processed_grid", "structprocessed__grid.html", "structprocessed__grid" ],
    [ "face_tag", "preprocess_8h.html#a3d04b7dd1579e4fe1cc2e5b25bd4138d", [
      [ "I_FACE", "preprocess_8h.html#a3d04b7dd1579e4fe1cc2e5b25bd4138daa48ada05ea50eb6c5822d9f2d131b504", null ],
      [ "J_FACE", "preprocess_8h.html#a3d04b7dd1579e4fe1cc2e5b25bd4138da2c2ecf4f44b75783de81c75bc300b69c", null ],
      [ "K_FACE", "preprocess_8h.html#a3d04b7dd1579e4fe1cc2e5b25bd4138da0bf81796bbd6d12d2ef46f40cd1c0988", null ],
      [ "NNC_FACE", "preprocess_8h.html#a3d04b7dd1579e4fe1cc2e5b25bd4138da9a93c0fbd45515f21035ac8192c71256", null ]
    ] ],
    [ "free_processed_grid", "preprocess_8h.html#af5b4d71c21e6015446bec009b55d4d79", null ],
    [ "process_grdecl", "preprocess_8h.html#a5c196e3723e6a053e87544535cfdebc5", null ]
];