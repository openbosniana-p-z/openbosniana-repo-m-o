var namespaces_dup =
[
    [ "Dune", "namespaceDune.html", "namespaceDune" ],
    [ "Opm", "namespaceOpm.html", "namespaceOpm" ]
];