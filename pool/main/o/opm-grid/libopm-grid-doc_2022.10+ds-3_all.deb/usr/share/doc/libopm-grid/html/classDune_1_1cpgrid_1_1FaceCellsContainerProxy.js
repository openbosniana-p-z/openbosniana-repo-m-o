var classDune_1_1cpgrid_1_1FaceCellsContainerProxy =
[
    [ "FaceCellsContainerProxy", "classDune_1_1cpgrid_1_1FaceCellsContainerProxy.html#a1f65afffa1a80aaec1ca9d637ebb4071", null ],
    [ "operator()", "classDune_1_1cpgrid_1_1FaceCellsContainerProxy.html#a29eade229095431cc3f4c07b2aa9d0e7", null ],
    [ "operator[]", "classDune_1_1cpgrid_1_1FaceCellsContainerProxy.html#a5b8cbb2a95df7da08c4a88e3447f1bd2", null ]
];