var searchData=
[
  ['datahandleinterface_0',['DataHandleInterface',['../classDune_1_1Point2PointCommunicator_1_1DataHandleInterface.html',1,'Dune::Point2PointCommunicator']]],
  ['defaultgeometrypolicy_1',['DefaultGeometryPolicy',['../classDune_1_1cpgrid_1_1DefaultGeometryPolicy.html',1,'Dune::cpgrid']]],
  ['dgfgridfactory_3c_20cpgrid_20_3e_2',['DGFGridFactory&lt; CpGrid &gt;',['../structDune_1_1DGFGridFactory_3_01CpGrid_01_4.html',1,'Dune']]],
  ['dgfgridfactory_3c_20polyhedralgrid_3c_20dim_2c_20dimworld_2c_20coord_5ft_20_3e_20_3e_3',['DGFGridFactory&lt; PolyhedralGrid&lt; dim, dimworld, coord_t &gt; &gt;',['../structDune_1_1DGFGridFactory_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html',1,'Dune']]],
  ['dgfgridinfo_3c_20cpgrid_20_3e_4',['DGFGridInfo&lt; CpGrid &gt;',['../structDune_1_1DGFGridInfo_3_01CpGrid_01_4.html',1,'Dune']]],
  ['dgfgridinfo_3c_20polyhedralgrid_3c_20dim_2c_20dimworld_20_3e_20_3e_5',['DGFGridInfo&lt; PolyhedralGrid&lt; dim, dimworld &gt; &gt;',['../structDune_1_1DGFGridInfo_3_01PolyhedralGrid_3_01dim_00_01dimworld_01_4_01_4.html',1,'Dune']]]
];
