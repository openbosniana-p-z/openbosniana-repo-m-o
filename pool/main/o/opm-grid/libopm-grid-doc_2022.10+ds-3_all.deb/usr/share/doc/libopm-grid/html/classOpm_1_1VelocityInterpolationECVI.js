var classOpm_1_1VelocityInterpolationECVI =
[
    [ "VelocityInterpolationECVI", "classOpm_1_1VelocityInterpolationECVI.html#ac33abe7e164528f4cc3e549e53f9c0d3", null ],
    [ "interpolate", "classOpm_1_1VelocityInterpolationECVI.html#a5b4dddc1ccc9bdde490fc5ce7214420c", null ],
    [ "setupFluxes", "classOpm_1_1VelocityInterpolationECVI.html#a2a2383a900429548eb9210400e8f5927", null ]
];