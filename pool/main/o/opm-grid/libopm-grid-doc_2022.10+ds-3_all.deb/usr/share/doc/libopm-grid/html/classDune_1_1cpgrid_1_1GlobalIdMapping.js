var classDune_1_1cpgrid_1_1GlobalIdMapping =
[
    [ "getMapping", "classDune_1_1cpgrid_1_1GlobalIdMapping.html#a0faf50fc2355f61314d90b86f9f5a2f0", null ],
    [ "getMapping", "classDune_1_1cpgrid_1_1GlobalIdMapping.html#abca4ffe528f6044524cc68296c87b2ae", null ],
    [ "swap", "classDune_1_1cpgrid_1_1GlobalIdMapping.html#af3d58fafc7d4019fd22c06e5579da407", null ],
    [ "cellMapping_", "classDune_1_1cpgrid_1_1GlobalIdMapping.html#a69396917da1c6596198945cebadd2f32", null ],
    [ "faceMapping_", "classDune_1_1cpgrid_1_1GlobalIdMapping.html#ac1f13e0c6717ef6e51d1668e6a0f82ee", null ],
    [ "pointMapping_", "classDune_1_1cpgrid_1_1GlobalIdMapping.html#a0b172e4a51bb8e34ef0869b616b2df06", null ]
];