var classDune_1_1cpgrid_1_1FaceCellsProxy =
[
    [ "FaceCellsProxy", "classDune_1_1cpgrid_1_1FaceCellsProxy.html#a82ef20fe9c138a8b6a17b0aa285ffa44", null ],
    [ "operator[]", "classDune_1_1cpgrid_1_1FaceCellsProxy.html#a94bbf1676eb50523875d49436de3ede9", null ]
];