var searchData=
[
  ['regionmapping_0',['RegionMapping',['../classOpm_1_1RegionMapping.html',1,'Opm']]],
  ['result_1',['Result',['../structOpm_1_1MinpvProcessor_1_1Result.html',1,'Opm::MinpvProcessor']]],
  ['reversepointglobalidset_2',['ReversePointGlobalIdSet',['../classDune_1_1cpgrid_1_1ReversePointGlobalIdSet.html',1,'Dune::cpgrid']]]
];
