var searchData=
[
  ['n_0',['n',['../structprocessed__grid.html#ae2d4d8eaf6aaf26f93ae97b53f762321',1,'processed_grid']]],
  ['name_1',['name',['../classDune_1_1CpGrid.html#a03b3953b740be2174e8465a203950df2',1,'Dune::CpGrid']]],
  ['neighbor_2',['neighbor',['../classDune_1_1cpgrid_1_1Intersection.html#a4ce33f8422f0cd218f091f101f364948',1,'Dune::cpgrid::Intersection']]],
  ['nnc_5fface_3',['NNC_FACE',['../preprocess_8h.html#a3d04b7dd1579e4fe1cc2e5b25bd4138da9a93c0fbd45515f21035ac8192c71256',1,'preprocess.h']]],
  ['node_5fcoordinates_4',['node_coordinates',['../structUnstructuredGrid.html#afb923f51405a4251254f4d9cbbe8c069',1,'UnstructuredGrid::node_coordinates()'],['../structprocessed__grid.html#a4884e2c9193cbaed253efc5b87afc7fb',1,'processed_grid::node_coordinates()']]],
  ['noentries_5',['noEntries',['../classDune_1_1cpgrid_1_1Cell2FacesContainer.html#acccfabb836461a3af17df85dca7be187',1,'Dune::cpgrid::Cell2FacesContainer::noEntries()'],['../classOpm_1_1UgGridHelpers_1_1SparseTableView.html#a47521a660dc61c15f163e90c3349f876',1,'Opm::UgGridHelpers::SparseTableView::noEntries()']]],
  ['number_5fof_5fcells_6',['number_of_cells',['../structprocessed__grid.html#ab54df07159b04dc4df453e0d9b7698ae',1,'processed_grid::number_of_cells()'],['../structUnstructuredGrid.html#a308d1c10b622822a40e58f57f1657e8a',1,'UnstructuredGrid::number_of_cells()']]],
  ['number_5fof_5ffaces_7',['number_of_faces',['../structprocessed__grid.html#ac2dbc4173d72da00c967873bb12e6731',1,'processed_grid::number_of_faces()'],['../structUnstructuredGrid.html#a6ad4d281a1f96c6cf35f35c3b728935d',1,'UnstructuredGrid::number_of_faces()']]],
  ['number_5fof_5fnodes_8',['number_of_nodes',['../structprocessed__grid.html#af3ee310e25e59faaa8ddb11189d81317',1,'processed_grid::number_of_nodes()'],['../structUnstructuredGrid.html#ad54025cb4edd61f10609bd7a06764b9f',1,'UnstructuredGrid::number_of_nodes()']]],
  ['number_5fof_5fnodes_5fon_5fpillars_9',['number_of_nodes_on_pillars',['../structprocessed__grid.html#aa4f025859db28a54e9636ca4c3cd0774',1,'processed_grid']]],
  ['numboundarysegments_10',['numBoundarySegments',['../classDune_1_1CpGrid.html#a0feea9dd4d816aa481b087d86cda94a7',1,'Dune::CpGrid::numBoundarySegments()'],['../classDune_1_1PolyhedralGrid.html#ac340f59e6a5434ffcbd9efe6403103d8',1,'Dune::PolyhedralGrid::numBoundarySegments()']]],
  ['numcellfaces_11',['numCellFaces',['../classDune_1_1CpGrid.html#a9da40dc395dfc79c865ceba58765247a',1,'Dune::CpGrid::numCellFaces(int cell) const'],['../classDune_1_1CpGrid.html#a4418926f573d520206e6fc0a34cebafc',1,'Dune::CpGrid::numCellFaces() const']]],
  ['numcells_12',['numCells',['../classDune_1_1CpGrid.html#acfed1ca23cf7f7612c592d3d7ecb9a1e',1,'Dune::CpGrid']]],
  ['numcorners_13',['numCorners',['../classOpm_1_1WachspressCoord.html#afbcad324ddf5b7ee89c427700113bd4d',1,'Opm::WachspressCoord']]],
  ['numfaces_14',['numFaces',['../classDune_1_1CpGrid.html#ae7428d0c961517ab55aa52340b2b9bc9',1,'Dune::CpGrid']]],
  ['numvertices_15',['numVertices',['../classDune_1_1CpGrid.html#a78e5b2cb7831979d6feb7bf2ba5c0570',1,'Dune::CpGrid']]]
];
