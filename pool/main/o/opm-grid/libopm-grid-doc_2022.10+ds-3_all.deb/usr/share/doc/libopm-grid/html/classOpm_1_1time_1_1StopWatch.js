var classOpm_1_1time_1_1StopWatch =
[
    [ "StopWatch", "classOpm_1_1time_1_1StopWatch.html#a22b0beba433a9aa228156f0e212c44a8", null ],
    [ "secsSinceLast", "classOpm_1_1time_1_1StopWatch.html#a5f7d516f2d50e863c21cd65ee53f2f29", null ],
    [ "secsSinceStart", "classOpm_1_1time_1_1StopWatch.html#a549aebee2dfb9de6eed2faddcc17030f", null ],
    [ "start", "classOpm_1_1time_1_1StopWatch.html#ac1d68968e7094e91a3a87323a73bedf5", null ],
    [ "stop", "classOpm_1_1time_1_1StopWatch.html#a52d4091a503bdb70471067535f094c3a", null ]
];