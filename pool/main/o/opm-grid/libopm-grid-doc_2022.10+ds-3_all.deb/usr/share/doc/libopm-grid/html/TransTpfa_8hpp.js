var TransTpfa_8hpp =
[
    [ "tpfa_eff_trans_compute", "TransTpfa_8hpp.html#af53065aee9247586f6bf135440a7361d", null ],
    [ "tpfa_htrans_compute", "TransTpfa_8hpp.html#aea751e8a7a7f9a4e29ab57f2d3354394", null ],
    [ "tpfa_trans_compute", "TransTpfa_8hpp.html#a2b506fe3dae4da0e86e8f7fba1a3de13", null ]
];