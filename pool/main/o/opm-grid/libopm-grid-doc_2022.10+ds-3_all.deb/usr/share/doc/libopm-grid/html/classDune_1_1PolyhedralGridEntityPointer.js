var classDune_1_1PolyhedralGridEntityPointer =
[
    [ "Entity", "classDune_1_1PolyhedralGridEntityPointer.html#af9947f4d429e1e4e73b589e2d52bf34e", null ],
    [ "dereference", "classDune_1_1PolyhedralGridEntityPointer.html#ad7d0177f887b250488b0876b9d802dcf", null ],
    [ "equals", "classDune_1_1PolyhedralGridEntityPointer.html#a6c54d2b0f37946bfb967c6a3f00b099b", null ],
    [ "level", "classDune_1_1PolyhedralGridEntityPointer.html#a6fbbe64607ec681668267aaf2f3a74b1", null ]
];