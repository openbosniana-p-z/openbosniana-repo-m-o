var hierarchy =
[
    [ "BasicBlock", null, [
      [ "Dune::dgf::PolyhedralGrid::PolygonBlock", "structDune_1_1dgf_1_1PolyhedralGrid_1_1PolygonBlock.html", null ],
      [ "Dune::dgf::PolyhedralGrid::PolyhedronBlock", "structDune_1_1dgf_1_1PolyhedralGrid_1_1PolyhedronBlock.html", null ]
    ] ],
    [ "Dune::Capabilities::canCommunicate< CpGrid, 0 >", "structDune_1_1Capabilities_1_1canCommunicate_3_01CpGrid_00_010_01_4.html", null ],
    [ "Dune::Capabilities::canCommunicate< CpGrid, 3 >", "structDune_1_1Capabilities_1_1canCommunicate_3_01CpGrid_00_013_01_4.html", null ],
    [ "Dune::Capabilities::canCommunicate< PolyhedralGrid< dim, dimworld, coord_t >, codim >", "structDune_1_1Capabilities_1_1canCommunicate_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_00_01codim_01_4.html", null ],
    [ "Dune::CartesianIndexMapper< Grid >", "classDune_1_1CartesianIndexMapper.html", null ],
    [ "Dune::CartesianIndexMapper< CpGrid >", "classDune_1_1CartesianIndexMapper_3_01CpGrid_01_4.html", null ],
    [ "Dune::CartesianIndexMapper< PolyhedralGrid< dim, dimworld, coord_t > >", "classDune_1_1CartesianIndexMapper_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html", null ],
    [ "Dune::cpgrid::Cell2FacesContainer", "classDune_1_1cpgrid_1_1Cell2FacesContainer.html", null ],
    [ "Dune::cpgrid::Cell2FacesRow", "classDune_1_1cpgrid_1_1Cell2FacesRow.html", null ],
    [ "Opm::UgGridHelpers::Cell2FacesTraits< T >", "structOpm_1_1UgGridHelpers_1_1Cell2FacesTraits.html", null ],
    [ "Opm::UgGridHelpers::Cell2FacesTraits< Dune::CpGrid >", "structOpm_1_1UgGridHelpers_1_1Cell2FacesTraits_3_01Dune_1_1CpGrid_01_4.html", null ],
    [ "Opm::UgGridHelpers::Cell2FacesTraits< UnstructuredGrid >", "structOpm_1_1UgGridHelpers_1_1Cell2FacesTraits_3_01UnstructuredGrid_01_4.html", [
      [ "Opm::UgGridHelpers::Cell2FacesTraits< Dune::PolyhedralGrid< dim, dimworld > >", "structOpm_1_1UgGridHelpers_1_1Cell2FacesTraits_3_01Dune_1_1PolyhedralGrid_3_01dim_00_01dimworld_01_4_01_4.html", null ]
    ] ],
    [ "Opm::UgGridHelpers::CellCentroidTraits< G >", "structOpm_1_1UgGridHelpers_1_1CellCentroidTraits.html", null ],
    [ "Opm::UgGridHelpers::CellCentroidTraits< Dune::CpGrid >", "structOpm_1_1UgGridHelpers_1_1CellCentroidTraits_3_01Dune_1_1CpGrid_01_4.html", null ],
    [ "Opm::UgGridHelpers::CellCentroidTraits< UnstructuredGrid >", "structOpm_1_1UgGridHelpers_1_1CellCentroidTraits_3_01UnstructuredGrid_01_4.html", [
      [ "Opm::UgGridHelpers::CellCentroidTraits< Dune::PolyhedralGrid< dim, dimworld > >", "structOpm_1_1UgGridHelpers_1_1CellCentroidTraits_3_01Dune_1_1PolyhedralGrid_3_01dim_00_01dimworld_01_4_01_4.html", null ]
    ] ],
    [ "Opm::CellQuadrature", "classOpm_1_1CellQuadrature.html", null ],
    [ "Opm::UgGridHelpers::CellVolumeIteratorTraits< T >", "structOpm_1_1UgGridHelpers_1_1CellVolumeIteratorTraits.html", null ],
    [ "Opm::UgGridHelpers::CellVolumeIteratorTraits< Dune::CpGrid >", "structOpm_1_1UgGridHelpers_1_1CellVolumeIteratorTraits_3_01Dune_1_1CpGrid_01_4.html", null ],
    [ "Opm::UgGridHelpers::CellVolumeIteratorTraits< UnstructuredGrid >", "structOpm_1_1UgGridHelpers_1_1CellVolumeIteratorTraits_3_01UnstructuredGrid_01_4.html", [
      [ "Opm::UgGridHelpers::CellVolumeIteratorTraits< Dune::PolyhedralGrid< dim, dimworld > >", "structOpm_1_1UgGridHelpers_1_1CellVolumeIteratorTraits_3_01Dune_1_1PolyhedralGrid_3_01dim_00_01dimworld_01_4_01_4.html", null ]
    ] ],
    [ "Dune::cpgrid::Entity< codim >::Codim< cd >", "structDune_1_1cpgrid_1_1Entity_1_1Codim.html", null ],
    [ "Dune::cpgrid::IndexSet::Codim< cc >", "structDune_1_1cpgrid_1_1IndexSet_1_1Codim.html", null ],
    [ "Dune::CpGridTraits::Codim< cd >", "structDune_1_1CpGridTraits_1_1Codim.html", null ],
    [ "Dune::PolyhedralGridFamily< dim, dimworld, coord_t >::Traits::Codim< codim >", "structDune_1_1PolyhedralGridFamily_1_1Traits_1_1Codim.html", null ],
    [ "Dune::PolyhedralGridViewTraits< dim, dimworld, coord_t, ptype >::Codim< codim >", "structDune_1_1PolyhedralGridViewTraits_1_1Codim.html", null ],
    [ "CollectiveCommunication", null, [
      [ "Dune::Point2PointCommunicator< MsgBuffer >", "classDune_1_1Point2PointCommunicator.html", null ]
    ] ],
    [ "Dune::cpgrid::CombinedGridWellGraph", "classDune_1_1cpgrid_1_1CombinedGridWellGraph.html", null ],
    [ "Opm::WachspressCoord::CornerInfo", "structOpm_1_1WachspressCoord_1_1CornerInfo.html", null ],
    [ "Dune::PolyhedralGridBasicGeometry< mydim, cdim, Grid >::PolyhedralMultiLinearGeometryTraits< ct >::CornerStorage< mdim, cordim >", "structDune_1_1PolyhedralGridBasicGeometry_1_1PolyhedralMultiLinearGeometryTraits_1_1CornerStorage.html", null ],
    [ "Dune::cpgrid::CpGridData", "classDune_1_1cpgrid_1_1CpGridData.html", null ],
    [ "Dune::CpGridFamily", "structDune_1_1CpGridFamily.html", null ],
    [ "Dune::CpGridTraits", "structDune_1_1CpGridTraits.html", null ],
    [ "Dune::Point2PointCommunicator< MsgBuffer >::DataHandleInterface", "classDune_1_1Point2PointCommunicator_1_1DataHandleInterface.html", null ],
    [ "Dune::cpgrid::DefaultGeometryPolicy", "classDune_1_1cpgrid_1_1DefaultGeometryPolicy.html", null ],
    [ "Dune::DGFGridFactory< CpGrid >", "structDune_1_1DGFGridFactory_3_01CpGrid_01_4.html", null ],
    [ "Dune::DGFGridFactory< PolyhedralGrid< dim, dimworld, coord_t > >", "structDune_1_1DGFGridFactory_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html", null ],
    [ "Dune::DGFGridInfo< CpGrid >", "structDune_1_1DGFGridInfo_3_01CpGrid_01_4.html", null ],
    [ "Dune::DGFGridInfo< PolyhedralGrid< dim, dimworld > >", "structDune_1_1DGFGridInfo_3_01PolyhedralGrid_3_01dim_00_01dimworld_01_4_01_4.html", null ],
    [ "Dune::cpgrid::Entity2IndexDataHandle< DataHandle, codim >", "classDune_1_1cpgrid_1_1Entity2IndexDataHandle.html", null ],
    [ "Dune::cpgrid::EntityRep< codim >", "classDune_1_1cpgrid_1_1EntityRep.html", [
      [ "Dune::cpgrid::Entity< 0 >", "classDune_1_1cpgrid_1_1Entity.html", [
        [ "Dune::cpgrid::HierarchicIterator", "classDune_1_1cpgrid_1_1HierarchicIterator.html", null ]
      ] ],
      [ "Dune::cpgrid::Entity< cd >", "classDune_1_1cpgrid_1_1Entity.html", [
        [ "Dune::cpgrid::Iterator< cd, pitype >", "classDune_1_1cpgrid_1_1Iterator.html", null ]
      ] ],
      [ "Dune::cpgrid::Entity< codim >", "classDune_1_1cpgrid_1_1Entity.html", null ]
    ] ],
    [ "Opm::UgGridHelpers::Face2VerticesTraits< T >", "structOpm_1_1UgGridHelpers_1_1Face2VerticesTraits.html", null ],
    [ "Opm::UgGridHelpers::Face2VerticesTraits< Dune::CpGrid >", "structOpm_1_1UgGridHelpers_1_1Face2VerticesTraits_3_01Dune_1_1CpGrid_01_4.html", null ],
    [ "Opm::UgGridHelpers::Face2VerticesTraits< UnstructuredGrid >", "structOpm_1_1UgGridHelpers_1_1Face2VerticesTraits_3_01UnstructuredGrid_01_4.html", [
      [ "Opm::UgGridHelpers::Face2VerticesTraits< Dune::PolyhedralGrid< dim, dimworld > >", "structOpm_1_1UgGridHelpers_1_1Face2VerticesTraits_3_01Dune_1_1PolyhedralGrid_3_01dim_00_01dimworld_01_4_01_4.html", null ]
    ] ],
    [ "Dune::cpgrid::FaceCellsContainerProxy", "classDune_1_1cpgrid_1_1FaceCellsContainerProxy.html", null ],
    [ "Dune::cpgrid::FaceCellsProxy", "classDune_1_1cpgrid_1_1FaceCellsProxy.html", null ],
    [ "Opm::UgGridHelpers::FaceCellsProxy", "classOpm_1_1UgGridHelpers_1_1FaceCellsProxy.html", null ],
    [ "Opm::UgGridHelpers::FaceCellTraits< T >", "structOpm_1_1UgGridHelpers_1_1FaceCellTraits.html", null ],
    [ "Opm::UgGridHelpers::FaceCellTraits< Dune::CpGrid >", "structOpm_1_1UgGridHelpers_1_1FaceCellTraits_3_01Dune_1_1CpGrid_01_4.html", null ],
    [ "Opm::UgGridHelpers::FaceCellTraits< UnstructuredGrid >", "structOpm_1_1UgGridHelpers_1_1FaceCellTraits_3_01UnstructuredGrid_01_4.html", [
      [ "Opm::UgGridHelpers::FaceCellTraits< Dune::PolyhedralGrid< dim, dimworld > >", "structOpm_1_1UgGridHelpers_1_1FaceCellTraits_3_01Dune_1_1PolyhedralGrid_3_01dim_00_01dimworld_01_4_01_4.html", null ]
    ] ],
    [ "Opm::UgGridHelpers::FaceCentroidTraits< G >", "structOpm_1_1UgGridHelpers_1_1FaceCentroidTraits.html", null ],
    [ "Opm::UgGridHelpers::FaceCentroidTraits< Dune::CpGrid >", "structOpm_1_1UgGridHelpers_1_1FaceCentroidTraits_3_01Dune_1_1CpGrid_01_4.html", null ],
    [ "Opm::UgGridHelpers::FaceCentroidTraits< UnstructuredGrid >", "structOpm_1_1UgGridHelpers_1_1FaceCentroidTraits_3_01UnstructuredGrid_01_4.html", [
      [ "Opm::UgGridHelpers::FaceCentroidTraits< Dune::PolyhedralGrid< dim, dimworld > >", "structOpm_1_1UgGridHelpers_1_1FaceCentroidTraits_3_01Dune_1_1PolyhedralGrid_3_01dim_00_01dimworld_01_4_01_4.html", null ]
    ] ],
    [ "Opm::FaceQuadrature", "classOpm_1_1FaceQuadrature.html", null ],
    [ "Dune::cpgrid::FaceViaCellHandleWrapper< Handle >", "structDune_1_1cpgrid_1_1FaceViaCellHandleWrapper.html", null ],
    [ "Dune::ForwardIteratorFacade", null, [
      [ "Dune::PolyhedralGridBasicGeometry< mydim, cdim, Grid >::PolyhedralMultiLinearGeometryTraits< ct >::Storage::Iterator", "structDune_1_1PolyhedralGridBasicGeometry_1_1PolyhedralMultiLinearGeometryTraits_1_1Storage_1_1Iterator.html", null ]
    ] ],
    [ "Dune::cpgrid::Geometry< mydim, cdim >", "classDune_1_1cpgrid_1_1Geometry.html", null ],
    [ "Dune::cpgrid::Geometry< 0, 3 >", "classDune_1_1cpgrid_1_1Geometry.html", null ],
    [ "Dune::cpgrid::Geometry< 0, cdim >", "classDune_1_1cpgrid_1_1Geometry_3_010_00_01cdim_01_4.html", null ],
    [ "Dune::cpgrid::Geometry< 2, 3 >", "classDune_1_1cpgrid_1_1Geometry.html", null ],
    [ "Dune::cpgrid::Geometry< 2, cdim >", "classDune_1_1cpgrid_1_1Geometry_3_012_00_01cdim_01_4.html", null ],
    [ "Dune::cpgrid::Geometry< 3, cdim >", "classDune_1_1cpgrid_1_1Geometry_3_013_00_01cdim_01_4.html", null ],
    [ "Dune::cpgrid::GlobalIdMapping", "classDune_1_1cpgrid_1_1GlobalIdMapping.html", [
      [ "Dune::cpgrid::LevelGlobalIdSet", "classDune_1_1cpgrid_1_1LevelGlobalIdSet.html", null ]
    ] ],
    [ "Dune::cpgrid::GlobalIdSet", "classDune_1_1cpgrid_1_1GlobalIdSet.html", null ],
    [ "grdecl", "structgrdecl.html", null ],
    [ "GridAdapter", "classGridAdapter.html", null ],
    [ "GridDefaultImplementation", null, [
      [ "Dune::CpGrid", "classDune_1_1CpGrid.html", null ]
    ] ],
    [ "GridFactoryInterface", null, [
      [ "Dune::GridFactory< PolyhedralGrid< dim, dimworld, coord_t > >", "classDune_1_1GridFactory_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html", null ]
    ] ],
    [ "Opm::GridManager", "classOpm_1_1GridManager.html", null ],
    [ "Dune::Capabilities::hasBackupRestoreFacilities< CpGrid >", "structDune_1_1Capabilities_1_1hasBackupRestoreFacilities_3_01CpGrid_01_4.html", null ],
    [ "Dune::Capabilities::hasBackupRestoreFacilities< PolyhedralGrid< dim, dimworld, coord_t > >", "structDune_1_1Capabilities_1_1hasBackupRestoreFacilities_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html", null ],
    [ "Dune::Capabilities::hasEntity< CpGrid, 0 >", "structDune_1_1Capabilities_1_1hasEntity_3_01CpGrid_00_010_01_4.html", null ],
    [ "Dune::Capabilities::hasEntity< CpGrid, 3 >", "structDune_1_1Capabilities_1_1hasEntity_3_01CpGrid_00_013_01_4.html", null ],
    [ "Dune::Capabilities::hasEntity< PolyhedralGrid< dim, dimworld, coord_t >, codim >", "structDune_1_1Capabilities_1_1hasEntity_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_00_01codim_01_4.html", null ],
    [ "Dune::Capabilities::hasEntityIterator< PolyhedralGrid< dim, dimworld, coord_t >, codim >", "structDune_1_1Capabilities_1_1hasEntityIterator_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_00_01codim_01_4.html", null ],
    [ "Dune::Capabilities::hasSingleGeometryType< PolyhedralGrid< dim, dimworld, coord_t > >", "structDune_1_1Capabilities_1_1hasSingleGeometryType_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html", null ],
    [ "Dune::cpgrid::IdSet", "classDune_1_1cpgrid_1_1IdSet.html", null ],
    [ "IdSet", null, [
      [ "Dune::PolyhedralGridIdSet< dim, dimworld, coord_t >", "classDune_1_1PolyhedralGridIdSet.html", null ]
    ] ],
    [ "Dune::cpgrid::IndexIterator", "classDune_1_1cpgrid_1_1IndexIterator.html", [
      [ "Dune::cpgrid::Cell2FacesRow::iterator", "classDune_1_1cpgrid_1_1Cell2FacesRow_1_1iterator.html", null ],
      [ "Dune::cpgrid::LocalIndexProxy< AccessMethod, SizeMethod >::iterator", "classDune_1_1cpgrid_1_1LocalIndexProxy_1_1iterator.html", null ]
    ] ],
    [ "Dune::cpgrid::IndexSet", "classDune_1_1cpgrid_1_1IndexSet.html", null ],
    [ "IndexSet", null, [
      [ "Dune::PolyhedralGridIndexSet< dim, dimworld, coord_t >", "classDune_1_1PolyhedralGridIndexSet.html", null ]
    ] ],
    [ "Dune::cpgrid::Intersection", "classDune_1_1cpgrid_1_1Intersection.html", [
      [ "Dune::cpgrid::IntersectionIterator", "classDune_1_1cpgrid_1_1IntersectionIterator.html", null ]
    ] ],
    [ "Dune::Capabilities::isCartesian< PolyhedralGrid< dim, dimworld, coord_t > >", "structDune_1_1Capabilities_1_1isCartesian_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html", null ],
    [ "Dune::Capabilities::isLeafwiseConforming< PolyhedralGrid< dim, dimworld, coord_t > >", "structDune_1_1Capabilities_1_1isLeafwiseConforming_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html", null ],
    [ "Dune::Capabilities::isLevelwiseConforming< PolyhedralGrid< dim, dimworld, coord_t > >", "structDune_1_1Capabilities_1_1isLevelwiseConforming_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html", null ],
    [ "Opm::SparseTable< T >::Iterator", "classOpm_1_1SparseTable_1_1Iterator.html", null ],
    [ "Opm::iterator_range< Iter >", "structOpm_1_1iterator__range.html", [
      [ "Dune::cpgrid::OrientedEntityRange< codim_to >", "classDune_1_1cpgrid_1_1OrientedEntityRange.html", null ]
    ] ],
    [ "Opm::iterator_range_pod< DataType >", "structOpm_1_1iterator__range__pod.html", null ],
    [ "std::iterator_traits< Dune::cpgrid::HierarchicIterator >", "structstd_1_1iterator__traits_3_01Dune_1_1cpgrid_1_1HierarchicIterator_01_4.html", null ],
    [ "std::iterator_traits< Dune::cpgrid::Iterator< codim, pitype > >", "structstd_1_1iterator__traits_3_01Dune_1_1cpgrid_1_1Iterator_3_01codim_00_01pitype_01_4_01_4.html", null ],
    [ "Dune::cpgrid::LocalIndexContainerProxy< AccessMethod, SizeMethod >", "classDune_1_1cpgrid_1_1LocalIndexContainerProxy.html", null ],
    [ "Dune::cpgrid::LocalIndexContainerProxy<&Dune::CpGrid::faceVertex, &Dune::CpGrid::numFaceVertices >", "classDune_1_1cpgrid_1_1LocalIndexContainerProxy.html", [
      [ "Dune::cpgrid::FaceVerticesContainerProxy", "classDune_1_1cpgrid_1_1FaceVerticesContainerProxy.html", null ]
    ] ],
    [ "Dune::cpgrid::LocalIndexProxy< AccessMethod, SizeMethod >", "classDune_1_1cpgrid_1_1LocalIndexProxy.html", null ],
    [ "Opm::MinpvProcessor", "classOpm_1_1MinpvProcessor.html", null ],
    [ "Dune::cpgrid::mover::Mover< T, i >", "structDune_1_1cpgrid_1_1mover_1_1Mover.html", null ],
    [ "Dune::MultiLinearGeometryTraits", null, [
      [ "Dune::PolyhedralGridBasicGeometry< mydim, cdim, Grid >::PolyhedralMultiLinearGeometryTraits< ctype >", "structDune_1_1PolyhedralGridBasicGeometry_1_1PolyhedralMultiLinearGeometryTraits.html", null ],
      [ "Dune::PolyhedralGridBasicGeometry< mydim, cdim, Grid >::PolyhedralMultiLinearGeometryTraits< ct >", "structDune_1_1PolyhedralGridBasicGeometry_1_1PolyhedralMultiLinearGeometryTraits.html", null ]
    ] ],
    [ "Opm::mutable_iterator_range< Iter >", "structOpm_1_1mutable__iterator__range.html", [
      [ "Dune::cpgrid::MutableOrientedEntityRange< codim_to >", "classDune_1_1cpgrid_1_1MutableOrientedEntityRange.html", null ]
    ] ],
    [ "Dune::OrderByFirst", "structDune_1_1OrderByFirst.html", null ],
    [ "Dune::CpGridTraits::Codim< cd >::Partition< pitype >", "structDune_1_1CpGridTraits_1_1Codim_1_1Partition.html", null ],
    [ "Dune::CpGridTraits::Partition< pitype >", "structDune_1_1CpGridTraits_1_1Partition.html", null ],
    [ "Dune::PolyhedralGrid< dim, dimworld, coord_t >::Codim< codim >::Partition< pitype >", "structDune_1_1PolyhedralGrid_1_1Codim_1_1Partition.html", null ],
    [ "Dune::PolyhedralGrid< dim, dimworld, coord_t >::Partition< pitype >", "structDune_1_1PolyhedralGrid_1_1Partition.html", null ],
    [ "Dune::PolyhedralGridFamily< dim, dimworld, coord_t >::Traits::Codim< codim >::Partition< pitype >", "structDune_1_1PolyhedralGridFamily_1_1Traits_1_1Codim_1_1Partition.html", null ],
    [ "Dune::PolyhedralGridFamily< dim, dimworld, coord_t >::Traits::Partition< pitype >", "structDune_1_1PolyhedralGridFamily_1_1Traits_1_1Partition.html", null ],
    [ "Dune::PolyhedralGridViewTraits< dim, dimworld, coord_t, ptype >::Codim< codim >::Partition< pit >", "structDune_1_1PolyhedralGridViewTraits_1_1Codim_1_1Partition.html", null ],
    [ "Dune::cpgrid::PartitionIteratorRule< pitype >", "structDune_1_1cpgrid_1_1PartitionIteratorRule.html", null ],
    [ "Dune::cpgrid::PartitionIteratorRule< All_Partition >", "structDune_1_1cpgrid_1_1PartitionIteratorRule_3_01All__Partition_01_4.html", [
      [ "Dune::cpgrid::PartitionIteratorRule< OverlapFront_Partition >", "structDune_1_1cpgrid_1_1PartitionIteratorRule_3_01OverlapFront__Partition_01_4.html", null ]
    ] ],
    [ "Dune::cpgrid::PartitionIteratorRule< Interior_Partition >", "structDune_1_1cpgrid_1_1PartitionIteratorRule_3_01Interior__Partition_01_4.html", null ],
    [ "Dune::cpgrid::PartitionIteratorRule< InteriorBorder_Partition >", "structDune_1_1cpgrid_1_1PartitionIteratorRule_3_01InteriorBorder__Partition_01_4.html", null ],
    [ "Dune::cpgrid::PartitionIteratorRule< Overlap_Partition >", "structDune_1_1cpgrid_1_1PartitionIteratorRule_3_01Overlap__Partition_01_4.html", null ],
    [ "Dune::cpgrid::PartitionTypeIndicator", "classDune_1_1cpgrid_1_1PartitionTypeIndicator.html", null ],
    [ "PersistentContainerVector", null, [
      [ "Dune::PersistentContainer< CpGrid, Data >", "classDune_1_1PersistentContainer_3_01CpGrid_00_01Data_01_4.html", null ],
      [ "Dune::PersistentContainer< PolyhedralGrid< dim, dimworld >, Data >", "classDune_1_1PersistentContainer_3_01PolyhedralGrid_3_01dim_00_01dimworld_01_4_00_01Data_01_4.html", null ]
    ] ],
    [ "Dune::cpgrid::PointViaCellWarner", "structDune_1_1cpgrid_1_1PointViaCellWarner.html", [
      [ "Dune::cpgrid::PointViaCellHandleWrapper< Handle >", "structDune_1_1cpgrid_1_1PointViaCellHandleWrapper.html", null ]
    ] ],
    [ "Dune::PolyhedralGrid< dim, dimworld, coord_t >", "classDune_1_1PolyhedralGrid.html", null ],
    [ "Dune::PolyhedralGridBasicGeometry< mydim, cdim, Grid >", "structDune_1_1PolyhedralGridBasicGeometry.html", [
      [ "Dune::PolyhedralGridGeometry< mydim, cdim, Grid >", "classDune_1_1PolyhedralGridGeometry.html", null ],
      [ "Dune::PolyhedralGridLocalGeometry< mydim, cdim, Grid >", "classDune_1_1PolyhedralGridLocalGeometry.html", null ]
    ] ],
    [ "Dune::PolyhedralGridEntityBasic< codim, dim, Grid >", "classDune_1_1PolyhedralGridEntityBasic.html", [
      [ "Dune::PolyhedralGridEntity< codim, dim, Grid >", "classDune_1_1PolyhedralGridEntity.html", null ]
    ] ],
    [ "Dune::PolyhedralGridEntityBasic< 0, dim, Grid >", "classDune_1_1PolyhedralGridEntityBasic.html", [
      [ "Dune::PolyhedralGridEntity< 0, dim, Grid >", "classDune_1_1PolyhedralGridEntity_3_010_00_01dim_00_01Grid_01_4.html", null ]
    ] ],
    [ "Dune::PolyhedralGridEntityPointer< codim, Grid >", "classDune_1_1PolyhedralGridEntityPointer.html", [
      [ "Dune::PolyhedralGridIterator< codim, Grid, pitype >", "classDune_1_1PolyhedralGridIterator.html", null ]
    ] ],
    [ "Dune::PolyhedralGridEntitySeed< codim, Grd >", "classDune_1_1PolyhedralGridEntitySeed.html", null ],
    [ "Dune::PolyhedralGridFamily< dim, dimworld, coord_t >", "structDune_1_1PolyhedralGridFamily.html", null ],
    [ "Dune::PolyhedralGridIntersection< Grid >", "classDune_1_1PolyhedralGridIntersection.html", null ],
    [ "Dune::PolyhedralGridIntersectionIterator< Grid >", "classDune_1_1PolyhedralGridIntersectionIterator.html", null ],
    [ "Dune::PolyhedralGridView< dim, dimworld, coord_t, defaultpitype >", "classDune_1_1PolyhedralGridView.html", null ],
    [ "Dune::PolyhedralGridViewTraits< dim, dimworld, coord_t, ptype >", "structDune_1_1PolyhedralGridViewTraits.html", null ],
    [ "processed_grid", "structprocessed__grid.html", null ],
    [ "Dune::RandomAccessIteratorFacade", null, [
      [ "Dune::cpgrid::Cell2FacesRow::iterator", "classDune_1_1cpgrid_1_1Cell2FacesRow_1_1iterator.html", null ],
      [ "Dune::cpgrid::LocalIndexProxy< AccessMethod, SizeMethod >::iterator", "classDune_1_1cpgrid_1_1LocalIndexProxy_1_1iterator.html", null ],
      [ "Opm::UgGridHelpers::CellVolumeIterator", "classOpm_1_1UgGridHelpers_1_1CellVolumeIterator.html", null ],
      [ "Opm::UgGridHelpers::CpGridCentroidIterator< Method >", "classOpm_1_1UgGridHelpers_1_1CpGridCentroidIterator.html", null ]
    ] ],
    [ "RandomAccessIteratorFacade", null, [
      [ "Dune::CpGrid::CentroidIterator< codim >", "classDune_1_1CpGrid_1_1CentroidIterator.html", null ]
    ] ],
    [ "Opm::RegionMapping< Region >", "classOpm_1_1RegionMapping.html", null ],
    [ "Opm::MinpvProcessor::Result", "structOpm_1_1MinpvProcessor_1_1Result.html", null ],
    [ "Dune::cpgrid::ReversePointGlobalIdSet", "classDune_1_1cpgrid_1_1ReversePointGlobalIdSet.html", null ],
    [ "Dune::SimpleMessageBuffer", "classDune_1_1SimpleMessageBuffer.html", null ],
    [ "Opm::SparseTable< T >", "classOpm_1_1SparseTable.html", null ],
    [ "Opm::SparseTable< EntityRep< codim_to > >", "classOpm_1_1SparseTable.html", [
      [ "Dune::cpgrid::OrientedEntityTable< 0, 1 >", "classDune_1_1cpgrid_1_1OrientedEntityTable.html", null ],
      [ "Dune::cpgrid::OrientedEntityTable< 1, 0 >", "classDune_1_1cpgrid_1_1OrientedEntityTable.html", null ],
      [ "Dune::cpgrid::OrientedEntityTable< codim_from, codim_to >", "classDune_1_1cpgrid_1_1OrientedEntityTable.html", null ]
    ] ],
    [ "Opm::SparseTable< int >", "classOpm_1_1SparseTable.html", null ],
    [ "Opm::SparseTable< Opm::WachspressCoord::CornerInfo >", "classOpm_1_1SparseTable.html", null ],
    [ "Opm::UgGridHelpers::SparseTableView", "classOpm_1_1UgGridHelpers_1_1SparseTableView.html", null ],
    [ "Opm::time::StopWatch", "classOpm_1_1time_1_1StopWatch.html", null ],
    [ "Dune::PolyhedralGridBasicGeometry< mydim, cdim, Grid >::PolyhedralMultiLinearGeometryTraits< ct >::Storage", "structDune_1_1PolyhedralGridBasicGeometry_1_1PolyhedralMultiLinearGeometryTraits_1_1Storage.html", null ],
    [ "Base::template Codim", null, [
      [ "Dune::PolyhedralGrid< dim, dimworld, coord_t >::Codim< codim >", "structDune_1_1PolyhedralGrid_1_1Codim.html", null ]
    ] ],
    [ "Traits::template Codim", null, [
      [ "Dune::PolyhedralGridView< dim, dimworld, coord_t, defaultpitype >::Codim< codim >", "structDune_1_1PolyhedralGridView_1_1Codim.html", null ]
    ] ],
    [ "Dune::Capabilities::threadSafe< PolyhedralGrid< dim, dimworld, coord_t > >", "structDune_1_1Capabilities_1_1threadSafe_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html", null ],
    [ "Dune::PolyhedralGridFamily< dim, dimworld, coord_t >::Traits", "structDune_1_1PolyhedralGridFamily_1_1Traits.html", null ],
    [ "UnstructuredGrid", "structUnstructuredGrid.html", null ],
    [ "Dune::PolyhedralGrid< dim, dimworld, coord_t >::UnstructuredGridDeleter", "structDune_1_1PolyhedralGrid_1_1UnstructuredGridDeleter.html", null ],
    [ "GridAdapter::Vector", "structGridAdapter_1_1Vector.html", null ],
    [ "std::vector", null, [
      [ "Dune::cpgrid::EntityVariableBase< enum face_tag >", "classDune_1_1cpgrid_1_1EntityVariableBase.html", [
        [ "Dune::cpgrid::EntityVariable< enum face_tag, 1 >", "classDune_1_1cpgrid_1_1EntityVariable.html", null ]
      ] ],
      [ "Dune::cpgrid::EntityVariableBase< PointType >", "classDune_1_1cpgrid_1_1EntityVariableBase.html", [
        [ "Dune::cpgrid::SignedEntityVariable< PointType, 1 >", "classDune_1_1cpgrid_1_1SignedEntityVariable.html", null ]
      ] ],
      [ "Dune::cpgrid::EntityVariableBase< int >", "classDune_1_1cpgrid_1_1EntityVariableBase.html", [
        [ "Dune::cpgrid::EntityVariable< int, 1 >", "classDune_1_1cpgrid_1_1EntityVariable.html", null ]
      ] ],
      [ "Dune::cpgrid::EntityVariableBase< Dune::cpgrid::Geometry< 3, 3 > >", "classDune_1_1cpgrid_1_1EntityVariableBase.html", [
        [ "Dune::cpgrid::EntityVariable< Dune::cpgrid::Geometry< 3, 3 >, 0 >", "classDune_1_1cpgrid_1_1EntityVariable.html", null ]
      ] ],
      [ "Dune::cpgrid::EntityVariableBase< Dune::cpgrid::Geometry< 2, 3 > >", "classDune_1_1cpgrid_1_1EntityVariableBase.html", [
        [ "Dune::cpgrid::EntityVariable< Dune::cpgrid::Geometry< 2, 3 >, 1 >", "classDune_1_1cpgrid_1_1EntityVariable.html", null ]
      ] ],
      [ "Dune::cpgrid::EntityVariableBase< Dune::cpgrid::Geometry< 0, 3 > >", "classDune_1_1cpgrid_1_1EntityVariableBase.html", [
        [ "Dune::cpgrid::EntityVariable< Dune::cpgrid::Geometry< 0, 3 >, 3 >", "classDune_1_1cpgrid_1_1EntityVariable.html", null ]
      ] ],
      [ "Dune::cpgrid::EntityVariableBase< T >", "classDune_1_1cpgrid_1_1EntityVariableBase.html", [
        [ "Dune::cpgrid::EntityVariable< T, codim >", "classDune_1_1cpgrid_1_1EntityVariable.html", null ],
        [ "Dune::cpgrid::SignedEntityVariable< T, codim >", "classDune_1_1cpgrid_1_1SignedEntityVariable.html", null ]
      ] ]
    ] ],
    [ "Opm::VelocityInterpolationInterface", "classOpm_1_1VelocityInterpolationInterface.html", [
      [ "Opm::VelocityInterpolationConstant", "classOpm_1_1VelocityInterpolationConstant.html", null ],
      [ "Opm::VelocityInterpolationECVI", "classOpm_1_1VelocityInterpolationECVI.html", null ]
    ] ],
    [ "Dune::Capabilities::viewThreadSafe< PolyhedralGrid< dim, dimworld, coord_t > >", "structDune_1_1Capabilities_1_1viewThreadSafe_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html", null ],
    [ "Opm::WachspressCoord", "classOpm_1_1WachspressCoord.html", null ],
    [ "Dune::cpgrid::WellConnections", "classDune_1_1cpgrid_1_1WellConnections.html", null ]
];