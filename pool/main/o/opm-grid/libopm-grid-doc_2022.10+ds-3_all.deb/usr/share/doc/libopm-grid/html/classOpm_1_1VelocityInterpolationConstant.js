var classOpm_1_1VelocityInterpolationConstant =
[
    [ "VelocityInterpolationConstant", "classOpm_1_1VelocityInterpolationConstant.html#ace54ad7f49b14ce0e365dbba3c64fc69", null ],
    [ "interpolate", "classOpm_1_1VelocityInterpolationConstant.html#ab3d60e3e16aef49d0c54e159dabfa827", null ],
    [ "setupFluxes", "classOpm_1_1VelocityInterpolationConstant.html#a84314f9d5d68b43407900976458ea7e5", null ]
];