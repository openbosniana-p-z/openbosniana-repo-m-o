var searchData=
[
  ['datahandleinterface_0',['DataHandleInterface',['../classDune_1_1Point2PointCommunicator_1_1DataHandleInterface.html',1,'Dune::Point2PointCommunicator']]],
  ['datasize_1',['dataSize',['../classOpm_1_1SparseTable.html#aab2bc0f2526d73edc9d10c21b73377cc',1,'Opm::SparseTable::dataSize()'],['../classDune_1_1cpgrid_1_1OrientedEntityTable.html#aab2bc0f2526d73edc9d10c21b73377cc',1,'Dune::cpgrid::OrientedEntityTable::dataSize()']]],
  ['defaultgeometrypolicy_2',['DefaultGeometryPolicy',['../classDune_1_1cpgrid_1_1DefaultGeometryPolicy.html#a5312bf0c845fae33f842b906ad86328e',1,'Dune::cpgrid::DefaultGeometryPolicy::DefaultGeometryPolicy()'],['../classDune_1_1cpgrid_1_1DefaultGeometryPolicy.html#a73151579887a3da1b555c1abffa6bbd1',1,'Dune::cpgrid::DefaultGeometryPolicy::DefaultGeometryPolicy(const EntityVariable&lt; cpgrid::Geometry&lt; 3, 3 &gt;, 0 &gt; &amp;cell_geom, const EntityVariable&lt; cpgrid::Geometry&lt; 2, 3 &gt;, 1 &gt; &amp;face_geom, const EntityVariable&lt; cpgrid::Geometry&lt; 0, 3 &gt;, 3 &gt; &amp;point_geom)'],['../classDune_1_1cpgrid_1_1DefaultGeometryPolicy.html',1,'Dune::cpgrid::DefaultGeometryPolicy']]],
  ['defaulttransedgewgt_3',['defaultTransEdgeWgt',['../namespaceDune.html#acadb22c6302f57c0b6cabe80237e3030a6211e1477ebe58996782a1a2d7eb0086',1,'Dune']]],
  ['dereference_4',['dereference',['../classDune_1_1PolyhedralGridEntityPointer.html#ad7d0177f887b250488b0876b9d802dcf',1,'Dune::PolyhedralGridEntityPointer']]],
  ['destroy_5fgrid_5',['destroy_grid',['../UnstructuredGrid_8h.html#a11b08b55d339f945eea7174b2ac91dad',1,'UnstructuredGrid.c']]],
  ['determinantof_6',['determinantOf',['../namespaceDune.html#a58a3c5f92e15224fe104d30e89680921',1,'Dune::determinantOf(const Point&lt; T, 3 &gt; *a)'],['../namespaceDune.html#a62bea6a864ff77587a153725eb3eec87',1,'Dune::determinantOf(const Point&lt; T, 2 &gt; *a)']]],
  ['dgfgridfactory_3c_20cpgrid_20_3e_7',['DGFGridFactory&lt; CpGrid &gt;',['../structDune_1_1DGFGridFactory_3_01CpGrid_01_4.html',1,'Dune']]],
  ['dgfgridfactory_3c_20polyhedralgrid_3c_20dim_2c_20dimworld_2c_20coord_5ft_20_3e_20_3e_8',['DGFGridFactory&lt; PolyhedralGrid&lt; dim, dimworld, coord_t &gt; &gt;',['../structDune_1_1DGFGridFactory_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html',1,'Dune']]],
  ['dgfgridinfo_3c_20cpgrid_20_3e_9',['DGFGridInfo&lt; CpGrid &gt;',['../structDune_1_1DGFGridInfo_3_01CpGrid_01_4.html',1,'Dune']]],
  ['dgfgridinfo_3c_20polyhedralgrid_3c_20dim_2c_20dimworld_20_3e_20_3e_10',['DGFGridInfo&lt; PolyhedralGrid&lt; dim, dimworld &gt; &gt;',['../structDune_1_1DGFGridInfo_3_01PolyhedralGrid_3_01dim_00_01dimworld_01_4_01_4.html',1,'Dune']]],
  ['dimension_11',['dimension',['../classDune_1_1CartesianIndexMapper.html#a70be5ee9bf7471ad323a2bd2a1cdaa97',1,'Dune::CartesianIndexMapper::dimension()'],['../classDune_1_1PolyhedralGridEntityBasic.html#a320c758143098000cc625cc35230d5b3',1,'Dune::PolyhedralGridEntityBasic::dimension()'],['../classDune_1_1PolyhedralGridEntityPointer.html#afaaed650aed67e60b11ebf9f71955b2f',1,'Dune::PolyhedralGridEntityPointer::dimension()']]],
  ['dimensions_12',['dimensions',['../structprocessed__grid.html#ad8e486de753a8ac0cd180e3a523256ac',1,'processed_grid::dimensions()'],['../structUnstructuredGrid.html#adfa11c1232e1affa2b077c0f7f5c23ab',1,'UnstructuredGrid::dimensions()']]],
  ['dimensionworld_13',['dimensionworld',['../classDune_1_1PolyhedralGridEntityBasic.html#a4ee8450e908de81aa8a5045bd56667e0',1,'Dune::PolyhedralGridEntityBasic']]],
  ['dims_14',['dims',['../structgrdecl.html#a4eabd720326e3dfc152fb8d894d86fe7',1,'grdecl']]],
  ['distributeglobalgrid_15',['distributeGlobalGrid',['../classDune_1_1cpgrid_1_1CpGridData.html#a92275dad5d1186f49a65bcee29f15cb2',1,'Dune::cpgrid::CpGridData']]],
  ['dune_16',['Dune',['../namespaceDune.html',1,'']]]
];
