var classOpm_1_1VelocityInterpolationInterface =
[
    [ "interpolate", "classOpm_1_1VelocityInterpolationInterface.html#af5628ee729bdcab74931fe78a3a0f597", null ],
    [ "setupFluxes", "classOpm_1_1VelocityInterpolationInterface.html#aa5d16629f63abdb359a727af8229450d", null ]
];