var searchData=
[
  ['threadsafe_3c_20polyhedralgrid_3c_20dim_2c_20dimworld_2c_20coord_5ft_20_3e_20_3e_0',['threadSafe&lt; PolyhedralGrid&lt; dim, dimworld, coord_t &gt; &gt;',['../structDune_1_1Capabilities_1_1threadSafe_3_01PolyhedralGrid_3_01dim_00_01dimworld_00_01coord__t_01_4_01_4.html',1,'Dune::Capabilities']]],
  ['traits_1',['Traits',['../structDune_1_1PolyhedralGridFamily_1_1Traits.html',1,'Dune::PolyhedralGridFamily']]]
];
