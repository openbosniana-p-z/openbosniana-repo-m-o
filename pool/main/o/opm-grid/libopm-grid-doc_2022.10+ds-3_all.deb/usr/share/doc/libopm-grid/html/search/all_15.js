var searchData=
[
  ['wachspresscoord_0',['WachspressCoord',['../classOpm_1_1WachspressCoord.html',1,'Opm::WachspressCoord'],['../classOpm_1_1WachspressCoord.html#ab07aa34bbbddcc7b2706acb113046a3a',1,'Opm::WachspressCoord::WachspressCoord()']]],
  ['wellconnections_1',['WellConnections',['../classDune_1_1cpgrid_1_1WellConnections.html',1,'Dune::cpgrid::WellConnections'],['../classDune_1_1cpgrid_1_1WellConnections.html#a4b15315b1b3f98b9bc0b578200ef06c6',1,'Dune::cpgrid::WellConnections::WellConnections(const std::vector&lt; OpmWellType &gt; &amp;wells, const std::array&lt; int, 3 &gt; &amp;cartesianSize, const std::vector&lt; int &gt; &amp;cartesian_to_compressed)'],['../classDune_1_1cpgrid_1_1WellConnections.html#aa78368fdcf265f1e4b8985a265428709',1,'Dune::cpgrid::WellConnections::WellConnections(const std::vector&lt; OpmWellType &gt; &amp;wells, const Dune::CpGrid &amp;cpGrid)']]],
  ['write_2',['write',['../classDune_1_1SimpleMessageBuffer.html#ad3dd9a82f951c5c156392d8f1c9ea8e2',1,'Dune::SimpleMessageBuffer']]],
  ['writesinteflegacyformat_3',['writeSintefLegacyFormat',['../classDune_1_1CpGrid.html#aa7454763173439301c58e6b6be3b467d',1,'Dune::CpGrid::writeSintefLegacyFormat()'],['../classDune_1_1cpgrid_1_1CpGridData.html#abcbd2f1de535e916c00bda5397e7d1ca',1,'Dune::cpgrid::CpGridData::writeSintefLegacyFormat()']]]
];
