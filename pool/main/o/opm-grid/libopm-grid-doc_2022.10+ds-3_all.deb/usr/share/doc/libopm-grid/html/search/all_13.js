var searchData=
[
  ['uniformedgewgt_0',['uniformEdgeWgt',['../namespaceDune.html#acadb22c6302f57c0b6cabe80237e3030ab8c8223be58abf7cd5ac2525a96dc1e2',1,'Dune']]],
  ['uniqueboundaryids_1',['uniqueBoundaryIds',['../classDune_1_1CpGrid.html#a7f33df7209eaf8c76e02725e214f9cf4',1,'Dune::CpGrid::uniqueBoundaryIds()'],['../classDune_1_1cpgrid_1_1CpGridData.html#a29eeb8d394c99c767bf513438ae8ecd6',1,'Dune::cpgrid::CpGridData::uniqueBoundaryIds()']]],
  ['unitouternormal_2',['unitOuterNormal',['../classDune_1_1cpgrid_1_1Intersection.html#a510fd6053bde64b8199805e6a1d7647d',1,'Dune::cpgrid::Intersection']]],
  ['unstructuredgrid_3',['UnstructuredGrid',['../structUnstructuredGrid.html',1,'']]],
  ['unstructuredgrid_2eh_4',['UnstructuredGrid.h',['../UnstructuredGrid_8h.html',1,'']]],
  ['unstructuredgriddeleter_5',['UnstructuredGridDeleter',['../structDune_1_1PolyhedralGrid_1_1UnstructuredGridDeleter.html',1,'Dune::PolyhedralGrid']]],
  ['update_6',['update',['../classDune_1_1PolyhedralGrid.html#a6a6bbad4853f24d87e55e0edbd5883c7',1,'Dune::PolyhedralGrid']]]
];
