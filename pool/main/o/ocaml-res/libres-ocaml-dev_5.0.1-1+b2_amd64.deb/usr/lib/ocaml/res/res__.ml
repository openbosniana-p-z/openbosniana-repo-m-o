(** @canonical Res.Nopres_impl *)
module Nopres_impl = Res__Nopres_impl


(** @canonical Res.Nopres_intf *)
module Nopres_intf = Res__Nopres_intf


(** @canonical Res.Pres_impl *)
module Pres_impl = Res__Pres_impl


(** @canonical Res.Pres_intf *)
module Pres_intf = Res__Pres_intf


(** @canonical Res.Strat *)
module Strat = Res__Strat


(** @canonical Res.Weak_impl *)
module Weak_impl = Res__Weak_impl


(** @canonical Res.Weak_intf *)
module Weak_intf = Res__Weak_intf
