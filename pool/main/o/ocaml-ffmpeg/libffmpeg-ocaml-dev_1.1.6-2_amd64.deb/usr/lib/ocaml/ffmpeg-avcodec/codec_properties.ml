type t = [
  | `Intra_only
  | `Lossy
  | `Lossless
  | `Reorder
  | `Bitmap_sub
  | `Text_sub
]

let t: t list  = [
`Text_sub;
`Bitmap_sub;
`Reorder;
`Lossless;
`Lossy;
`Intra_only;
]

