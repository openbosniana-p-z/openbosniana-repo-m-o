type t = [
  | `None
  | `Yuv420p
  | `Yuyv422
  | `Rgb24
  | `Bgr24
  | `Yuv422p
  | `Yuv444p
  | `Yuv410p
  | `Yuv411p
  | `Gray8
  | `Monowhite
  | `Monoblack
  | `Pal8
  | `Yuvj420p
  | `Yuvj422p
  | `Yuvj444p
  | `Uyvy422
  | `Uyyvyy411
  | `Bgr8
  | `Bgr4
  | `Bgr4_byte
  | `Rgb8
  | `Rgb4
  | `Rgb4_byte
  | `Nv12
  | `Nv21
  | `Argb
  | `Rgba
  | `Abgr
  | `Bgra
  | `Gray16be
  | `Gray16le
  | `Yuv440p
  | `Yuvj440p
  | `Yuva420p
  | `Rgb48be
  | `Rgb48le
  | `Rgb565be
  | `Rgb565le
  | `Rgb555be
  | `Rgb555le
  | `Bgr565be
  | `Bgr565le
  | `Bgr555be
  | `Bgr555le
  | `Vaapi
  | `Yuv420p16le
  | `Yuv420p16be
  | `Yuv422p16le
  | `Yuv422p16be
  | `Yuv444p16le
  | `Yuv444p16be
  | `Dxva2_vld
  | `Rgb444le
  | `Rgb444be
  | `Bgr444le
  | `Bgr444be
  | `Ya8
  | `Y400a
  | `Gray8a
  | `Bgr48be
  | `Bgr48le
  | `Yuv420p9be
  | `Yuv420p9le
  | `Yuv420p10be
  | `Yuv420p10le
  | `Yuv422p10be
  | `Yuv422p10le
  | `Yuv444p9be
  | `Yuv444p9le
  | `Yuv444p10be
  | `Yuv444p10le
  | `Yuv422p9be
  | `Yuv422p9le
  | `Gbrp
  | `Gbr24p
  | `Gbrp9be
  | `Gbrp9le
  | `Gbrp10be
  | `Gbrp10le
  | `Gbrp16be
  | `Gbrp16le
  | `Yuva422p
  | `Yuva444p
  | `Yuva420p9be
  | `Yuva420p9le
  | `Yuva422p9be
  | `Yuva422p9le
  | `Yuva444p9be
  | `Yuva444p9le
  | `Yuva420p10be
  | `Yuva420p10le
  | `Yuva422p10be
  | `Yuva422p10le
  | `Yuva444p10be
  | `Yuva444p10le
  | `Yuva420p16be
  | `Yuva420p16le
  | `Yuva422p16be
  | `Yuva422p16le
  | `Yuva444p16be
  | `Yuva444p16le
  | `Vdpau
  | `Xyz12le
  | `Xyz12be
  | `Nv16
  | `Nv20le
  | `Nv20be
  | `Rgba64be
  | `Rgba64le
  | `Bgra64be
  | `Bgra64le
  | `Yvyu422
  | `Ya16be
  | `Ya16le
  | `Gbrap
  | `Gbrap16be
  | `Gbrap16le
  | `Qsv
  | `Mmal
  | `D3d11va_vld
  | `Cuda
  | `_0rgb
  | `Rgb0
  | `_0bgr
  | `Bgr0
  | `Yuv420p12be
  | `Yuv420p12le
  | `Yuv420p14be
  | `Yuv420p14le
  | `Yuv422p12be
  | `Yuv422p12le
  | `Yuv422p14be
  | `Yuv422p14le
  | `Yuv444p12be
  | `Yuv444p12le
  | `Yuv444p14be
  | `Yuv444p14le
  | `Gbrp12be
  | `Gbrp12le
  | `Gbrp14be
  | `Gbrp14le
  | `Yuvj411p
  | `Bayer_bggr8
  | `Bayer_rggb8
  | `Bayer_gbrg8
  | `Bayer_grbg8
  | `Bayer_bggr16le
  | `Bayer_bggr16be
  | `Bayer_rggb16le
  | `Bayer_rggb16be
  | `Bayer_gbrg16le
  | `Bayer_gbrg16be
  | `Bayer_grbg16le
  | `Bayer_grbg16be
  | `Xvmc
  | `Yuv440p10le
  | `Yuv440p10be
  | `Yuv440p12le
  | `Yuv440p12be
  | `Ayuv64le
  | `Ayuv64be
  | `Videotoolbox
  | `P010le
  | `P010be
  | `Gbrap12be
  | `Gbrap12le
  | `Gbrap10be
  | `Gbrap10le
  | `Mediacodec
  | `Gray12be
  | `Gray12le
  | `Gray10be
  | `Gray10le
  | `P016le
  | `P016be
  | `D3d11
  | `Gray9be
  | `Gray9le
  | `Gbrpf32be
  | `Gbrpf32le
  | `Gbrapf32be
  | `Gbrapf32le
]

let t: t list  = [
`Gbrapf32le;
`Gbrapf32be;
`Gbrpf32le;
`Gbrpf32be;
`Gray9le;
`Gray9be;
`D3d11;
`P016be;
`P016le;
`Gray10le;
`Gray10be;
`Gray12le;
`Gray12be;
`Mediacodec;
`Gbrap10le;
`Gbrap10be;
`Gbrap12le;
`Gbrap12be;
`P010be;
`P010le;
`Videotoolbox;
`Ayuv64be;
`Ayuv64le;
`Yuv440p12be;
`Yuv440p12le;
`Yuv440p10be;
`Yuv440p10le;
`Xvmc;
`Bayer_grbg16be;
`Bayer_grbg16le;
`Bayer_gbrg16be;
`Bayer_gbrg16le;
`Bayer_rggb16be;
`Bayer_rggb16le;
`Bayer_bggr16be;
`Bayer_bggr16le;
`Bayer_grbg8;
`Bayer_gbrg8;
`Bayer_rggb8;
`Bayer_bggr8;
`Yuvj411p;
`Gbrp14le;
`Gbrp14be;
`Gbrp12le;
`Gbrp12be;
`Yuv444p14le;
`Yuv444p14be;
`Yuv444p12le;
`Yuv444p12be;
`Yuv422p14le;
`Yuv422p14be;
`Yuv422p12le;
`Yuv422p12be;
`Yuv420p14le;
`Yuv420p14be;
`Yuv420p12le;
`Yuv420p12be;
`Bgr0;
`_0bgr;
`Rgb0;
`_0rgb;
`Cuda;
`D3d11va_vld;
`Mmal;
`Qsv;
`Gbrap16le;
`Gbrap16be;
`Gbrap;
`Ya16le;
`Ya16be;
`Yvyu422;
`Bgra64le;
`Bgra64be;
`Rgba64le;
`Rgba64be;
`Nv20be;
`Nv20le;
`Nv16;
`Xyz12be;
`Xyz12le;
`Vdpau;
`Yuva444p16le;
`Yuva444p16be;
`Yuva422p16le;
`Yuva422p16be;
`Yuva420p16le;
`Yuva420p16be;
`Yuva444p10le;
`Yuva444p10be;
`Yuva422p10le;
`Yuva422p10be;
`Yuva420p10le;
`Yuva420p10be;
`Yuva444p9le;
`Yuva444p9be;
`Yuva422p9le;
`Yuva422p9be;
`Yuva420p9le;
`Yuva420p9be;
`Yuva444p;
`Yuva422p;
`Gbrp16le;
`Gbrp16be;
`Gbrp10le;
`Gbrp10be;
`Gbrp9le;
`Gbrp9be;
`Gbr24p;
`Gbrp;
`Yuv422p9le;
`Yuv422p9be;
`Yuv444p10le;
`Yuv444p10be;
`Yuv444p9le;
`Yuv444p9be;
`Yuv422p10le;
`Yuv422p10be;
`Yuv420p10le;
`Yuv420p10be;
`Yuv420p9le;
`Yuv420p9be;
`Bgr48le;
`Bgr48be;
`Gray8a;
`Y400a;
`Ya8;
`Bgr444be;
`Bgr444le;
`Rgb444be;
`Rgb444le;
`Dxva2_vld;
`Yuv444p16be;
`Yuv444p16le;
`Yuv422p16be;
`Yuv422p16le;
`Yuv420p16be;
`Yuv420p16le;
`Vaapi;
`Bgr555le;
`Bgr555be;
`Bgr565le;
`Bgr565be;
`Rgb555le;
`Rgb555be;
`Rgb565le;
`Rgb565be;
`Rgb48le;
`Rgb48be;
`Yuva420p;
`Yuvj440p;
`Yuv440p;
`Gray16le;
`Gray16be;
`Bgra;
`Abgr;
`Rgba;
`Argb;
`Nv21;
`Nv12;
`Rgb4_byte;
`Rgb4;
`Rgb8;
`Bgr4_byte;
`Bgr4;
`Bgr8;
`Uyyvyy411;
`Uyvy422;
`Yuvj444p;
`Yuvj422p;
`Yuvj420p;
`Pal8;
`Monoblack;
`Monowhite;
`Gray8;
`Yuv411p;
`Yuv410p;
`Yuv444p;
`Yuv422p;
`Bgr24;
`Rgb24;
`Yuyv422;
`Yuv420p;
`None;
]

