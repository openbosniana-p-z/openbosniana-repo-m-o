type t = [
  | `Be
  | `Pal
  | `Bitstream
  | `Hwaccel
  | `Planar
  | `Rgb
  | `Alpha
  | `Bayer
  | `Float
]

let t: t list  = [
`Float;
`Bayer;
`Alpha;
`Rgb;
`Planar;
`Hwaccel;
`Bitstream;
`Pal;
`Be;
]

