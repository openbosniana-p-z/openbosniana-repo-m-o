type t = [
  | `Unknown
  | `Video
  | `Audio
  | `Data
  | `Subtitle
  | `Attachment
]

let t: t list  = [
`Attachment;
`Subtitle;
`Data;
`Audio;
`Video;
`Unknown;
]

