type t = [
  | `None
  | `U8
  | `S16
  | `S32
  | `Flt
  | `Dbl
  | `U8p
  | `S16p
  | `S32p
  | `Fltp
  | `Dblp
  | `S64
  | `S64p
]

let t: t list  = [
`S64p;
`S64;
`Dblp;
`Fltp;
`S32p;
`S16p;
`U8p;
`Dbl;
`Flt;
`S32;
`S16;
`U8;
`None;
]

