(** @canonical Avutil.Channel_layout *)
module Channel_layout = Avutil__Channel_layout


(** @canonical Avutil.Hw_device_type *)
module Hw_device_type = Avutil__Hw_device_type


(** @canonical Avutil.Media_types *)
module Media_types = Avutil__Media_types


(** @canonical Avutil.Pixel_format *)
module Pixel_format = Avutil__Pixel_format


(** @canonical Avutil.Pixel_format_flag *)
module Pixel_format_flag = Avutil__Pixel_format_flag


(** @canonical Avutil.Sample_format *)
module Sample_format = Avutil__Sample_format
