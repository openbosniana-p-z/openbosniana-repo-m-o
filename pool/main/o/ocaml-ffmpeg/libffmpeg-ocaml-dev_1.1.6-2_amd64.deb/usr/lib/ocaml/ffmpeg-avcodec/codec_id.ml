type video = [
  | `Mpeg1video
  | `Mpeg2video
  | `H261
  | `H263
  | `Rv10
  | `Rv20
  | `Mjpeg
  | `Mjpegb
  | `Ljpeg
  | `Sp5x
  | `Jpegls
  | `Mpeg4
  | `Rawvideo
  | `Msmpeg4v1
  | `Msmpeg4v2
  | `Msmpeg4v3
  | `Wmv1
  | `Wmv2
  | `H263p
  | `H263i
  | `Flv1
  | `Svq1
  | `Svq3
  | `Dvvideo
  | `Huffyuv
  | `Cyuv
  | `H264
  | `Indeo3
  | `Vp3
  | `Theora
  | `Asv1
  | `Asv2
  | `Ffv1
  | `_4xm
  | `Vcr1
  | `Cljr
  | `Mdec
  | `Roq
  | `Interplay_video
  | `Xan_wc3
  | `Xan_wc4
  | `Rpza
  | `Cinepak
  | `Ws_vqa
  | `Msrle
  | `Msvideo1
  | `Idcin
  | `_8bps
  | `Smc
  | `Flic
  | `Truemotion1
  | `Vmdvideo
  | `Mszh
  | `Zlib
  | `Qtrle
  | `Tscc
  | `Ulti
  | `Qdraw
  | `Vixl
  | `Qpeg
  | `Png
  | `Ppm
  | `Pbm
  | `Pgm
  | `Pgmyuv
  | `Pam
  | `Ffvhuff
  | `Rv30
  | `Rv40
  | `Vc1
  | `Wmv3
  | `Loco
  | `Wnv1
  | `Aasc
  | `Indeo2
  | `Fraps
  | `Truemotion2
  | `Bmp
  | `Cscd
  | `Mmvideo
  | `Zmbv
  | `Avs
  | `Smackvideo
  | `Nuv
  | `Kmvc
  | `Flashsv
  | `Cavs
  | `Jpeg2000
  | `Vmnc
  | `Vp5
  | `Vp6
  | `Vp6f
  | `Targa
  | `Dsicinvideo
  | `Tiertexseqvideo
  | `Tiff
  | `Gif
  | `Dxa
  | `Dnxhd
  | `Thp
  | `Sgi
  | `C93
  | `Bethsoftvid
  | `Ptx
  | `Txd
  | `Vp6a
  | `Amv
  | `Vb
  | `Pcx
  | `Sunrast
  | `Indeo4
  | `Indeo5
  | `Mimic
  | `Rl2
  | `Escape124
  | `Dirac
  | `Bfi
  | `Cmv
  | `Motionpixels
  | `Tgv
  | `Tgq
  | `Tqi
  | `Aura
  | `Aura2
  | `V210x
  | `Tmv
  | `V210
  | `Dpx
  | `Mad
  | `Frwu
  | `Flashsv2
  | `Cdgraphics
  | `R210
  | `Anm
  | `Binkvideo
  | `Iff_ilbm
  | `Kgv1
  | `Yop
  | `Vp8
  | `Pictor
  | `Ansi
  | `A64_multi
  | `A64_multi5
  | `R10k
  | `Mxpeg
  | `Lagarith
  | `Prores
  | `Jv
  | `Dfa
  | `Wmv3image
  | `Vc1image
  | `Utvideo
  | `Bmv_video
  | `Vble
  | `Dxtory
  | `V410
  | `Xwd
  | `Cdxl
  | `Xbm
  | `Zerocodec
  | `Mss1
  | `Msa1
  | `Tscc2
  | `Mts2
  | `Cllc
  | `Mss2
  | `Vp9
  | `Aic
  | `Escape130
  | `G2m
  | `Webp
  | `Hnm4_video
  | `Hevc
  | `Fic
  | `Alias_pix
  | `Brender_pix
  | `Paf_video
  | `Exr
  | `Vp7
  | `Sanm
  | `Sgirle
  | `Mvc1
  | `Mvc2
  | `Hqx
  | `Tdsc
  | `Hq_hqa
  | `Hap
  | `Dds
  | `Dxv
  | `Screenpresso
  | `Rscc
  | `Avs2
  | `Pgx
  | `Avs3
  | `Msp2
  | `Vvc
  | `Y41p
  | `Avrp
  | `_012v
  | `Avui
  | `Ayuv
  | `Targa_y216
  | `V308
  | `V408
  | `Yuv4
  | `Avrn
  | `Cpia
  | `Xface
  | `Snow
  | `Smvjpeg
  | `Apng
  | `Daala
  | `Cfhd
  | `Truemotion2rt
  | `M101
  | `Magicyuv
  | `Sheervideo
  | `Ylc
  | `Psd
  | `Pixlet
  | `Speedhq
  | `Fmvc
  | `Scpr
  | `Clearvideo
  | `Xpm
  | `Av1
  | `Bitpacked
  | `Mscc
  | `Srgc
  | `Svg
  | `Gdv
  | `Fits
  | `Imm4
  | `Prosumer
  | `Mwsc
  | `Wcmv
  | `Rasc
  | `Hymt
  | `Arbc
  | `Agm
  | `Lscr
  | `Vp4
  | `Imm5
  | `Mvdv
  | `Mvha
  | `Cdtoons
  | `Mv30
  | `Notchlc
  | `Pfm
  | `Mobiclip
  | `Photocd
  | `Ipu
  | `Argo
  | `Cri
  | `Simbiosis_imx
  | `Sga_video
  | `Gem
  | `Vbn
  | `Jpegxl
  | `Qoi
  | `Phm
]

let video: video list  = [
`Phm;
`Qoi;
`Jpegxl;
`Vbn;
`Gem;
`Sga_video;
`Simbiosis_imx;
`Cri;
`Argo;
`Ipu;
`Photocd;
`Mobiclip;
`Pfm;
`Notchlc;
`Mv30;
`Cdtoons;
`Mvha;
`Mvdv;
`Imm5;
`Vp4;
`Lscr;
`Agm;
`Arbc;
`Hymt;
`Rasc;
`Wcmv;
`Mwsc;
`Prosumer;
`Imm4;
`Fits;
`Gdv;
`Svg;
`Srgc;
`Mscc;
`Bitpacked;
`Av1;
`Xpm;
`Clearvideo;
`Scpr;
`Fmvc;
`Speedhq;
`Pixlet;
`Psd;
`Ylc;
`Sheervideo;
`Magicyuv;
`M101;
`Truemotion2rt;
`Cfhd;
`Daala;
`Apng;
`Smvjpeg;
`Snow;
`Xface;
`Cpia;
`Avrn;
`Yuv4;
`V408;
`V308;
`Targa_y216;
`Ayuv;
`Avui;
`_012v;
`Avrp;
`Y41p;
`Vvc;
`Msp2;
`Avs3;
`Pgx;
`Avs2;
`Rscc;
`Screenpresso;
`Dxv;
`Dds;
`Hap;
`Hq_hqa;
`Tdsc;
`Hqx;
`Mvc2;
`Mvc1;
`Sgirle;
`Sanm;
`Vp7;
`Exr;
`Paf_video;
`Brender_pix;
`Alias_pix;
`Fic;
`Hevc;
`Hnm4_video;
`Webp;
`G2m;
`Escape130;
`Aic;
`Vp9;
`Mss2;
`Cllc;
`Mts2;
`Tscc2;
`Msa1;
`Mss1;
`Zerocodec;
`Xbm;
`Cdxl;
`Xwd;
`V410;
`Dxtory;
`Vble;
`Bmv_video;
`Utvideo;
`Vc1image;
`Wmv3image;
`Dfa;
`Jv;
`Prores;
`Lagarith;
`Mxpeg;
`R10k;
`A64_multi5;
`A64_multi;
`Ansi;
`Pictor;
`Vp8;
`Yop;
`Kgv1;
`Iff_ilbm;
`Binkvideo;
`Anm;
`R210;
`Cdgraphics;
`Flashsv2;
`Frwu;
`Mad;
`Dpx;
`V210;
`Tmv;
`V210x;
`Aura2;
`Aura;
`Tqi;
`Tgq;
`Tgv;
`Motionpixels;
`Cmv;
`Bfi;
`Dirac;
`Escape124;
`Rl2;
`Mimic;
`Indeo5;
`Indeo4;
`Sunrast;
`Pcx;
`Vb;
`Amv;
`Vp6a;
`Txd;
`Ptx;
`Bethsoftvid;
`C93;
`Sgi;
`Thp;
`Dnxhd;
`Dxa;
`Gif;
`Tiff;
`Tiertexseqvideo;
`Dsicinvideo;
`Targa;
`Vp6f;
`Vp6;
`Vp5;
`Vmnc;
`Jpeg2000;
`Cavs;
`Flashsv;
`Kmvc;
`Nuv;
`Smackvideo;
`Avs;
`Zmbv;
`Mmvideo;
`Cscd;
`Bmp;
`Truemotion2;
`Fraps;
`Indeo2;
`Aasc;
`Wnv1;
`Loco;
`Wmv3;
`Vc1;
`Rv40;
`Rv30;
`Ffvhuff;
`Pam;
`Pgmyuv;
`Pgm;
`Pbm;
`Ppm;
`Png;
`Qpeg;
`Vixl;
`Qdraw;
`Ulti;
`Tscc;
`Qtrle;
`Zlib;
`Mszh;
`Vmdvideo;
`Truemotion1;
`Flic;
`Smc;
`_8bps;
`Idcin;
`Msvideo1;
`Msrle;
`Ws_vqa;
`Cinepak;
`Rpza;
`Xan_wc4;
`Xan_wc3;
`Interplay_video;
`Roq;
`Mdec;
`Cljr;
`Vcr1;
`_4xm;
`Ffv1;
`Asv2;
`Asv1;
`Theora;
`Vp3;
`Indeo3;
`H264;
`Cyuv;
`Huffyuv;
`Dvvideo;
`Svq3;
`Svq1;
`Flv1;
`H263i;
`H263p;
`Wmv2;
`Wmv1;
`Msmpeg4v3;
`Msmpeg4v2;
`Msmpeg4v1;
`Rawvideo;
`Mpeg4;
`Jpegls;
`Sp5x;
`Ljpeg;
`Mjpegb;
`Mjpeg;
`Rv20;
`Rv10;
`H263;
`H261;
`Mpeg2video;
`Mpeg1video;
]

type audio = [
  | `Pcm_s16le
  | `Pcm_s16be
  | `Pcm_u16le
  | `Pcm_u16be
  | `Pcm_s8
  | `Pcm_u8
  | `Pcm_mulaw
  | `Pcm_alaw
  | `Pcm_s32le
  | `Pcm_s32be
  | `Pcm_u32le
  | `Pcm_u32be
  | `Pcm_s24le
  | `Pcm_s24be
  | `Pcm_u24le
  | `Pcm_u24be
  | `Pcm_s24daud
  | `Pcm_zork
  | `Pcm_s16le_planar
  | `Pcm_dvd
  | `Pcm_f32be
  | `Pcm_f32le
  | `Pcm_f64be
  | `Pcm_f64le
  | `Pcm_bluray
  | `Pcm_lxf
  | `S302m
  | `Pcm_s8_planar
  | `Pcm_s24le_planar
  | `Pcm_s32le_planar
  | `Pcm_s16be_planar
  | `Pcm_s64le
  | `Pcm_s64be
  | `Pcm_f16le
  | `Pcm_f24le
  | `Pcm_vidc
  | `Pcm_sga
  | `Adpcm_ima_qt
  | `Adpcm_ima_wav
  | `Adpcm_ima_dk3
  | `Adpcm_ima_dk4
  | `Adpcm_ima_ws
  | `Adpcm_ima_smjpeg
  | `Adpcm_ms
  | `Adpcm_4xm
  | `Adpcm_xa
  | `Adpcm_adx
  | `Adpcm_ea
  | `Adpcm_g726
  | `Adpcm_ct
  | `Adpcm_swf
  | `Adpcm_yamaha
  | `Adpcm_sbpro_4
  | `Adpcm_sbpro_3
  | `Adpcm_sbpro_2
  | `Adpcm_thp
  | `Adpcm_ima_amv
  | `Adpcm_ea_r1
  | `Adpcm_ea_r3
  | `Adpcm_ea_r2
  | `Adpcm_ima_ea_sead
  | `Adpcm_ima_ea_eacs
  | `Adpcm_ea_xas
  | `Adpcm_ea_maxis_xa
  | `Adpcm_ima_iss
  | `Adpcm_g722
  | `Adpcm_ima_apc
  | `Adpcm_vima
  | `Adpcm_afc
  | `Adpcm_ima_oki
  | `Adpcm_dtk
  | `Adpcm_ima_rad
  | `Adpcm_g726le
  | `Adpcm_thp_le
  | `Adpcm_psx
  | `Adpcm_aica
  | `Adpcm_ima_dat4
  | `Adpcm_mtaf
  | `Adpcm_agm
  | `Adpcm_argo
  | `Adpcm_ima_ssi
  | `Adpcm_zork
  | `Adpcm_ima_apm
  | `Adpcm_ima_alp
  | `Adpcm_ima_mtf
  | `Adpcm_ima_cunning
  | `Adpcm_ima_moflex
  | `Adpcm_ima_acorn
  | `Amr_nb
  | `Amr_wb
  | `Ra_144
  | `Ra_288
  | `Roq_dpcm
  | `Interplay_dpcm
  | `Xan_dpcm
  | `Sol_dpcm
  | `Sdx2_dpcm
  | `Gremlin_dpcm
  | `Derf_dpcm
  | `Mp2
  | `Mp3
  | `Aac
  | `Ac3
  | `Dts
  | `Vorbis
  | `Dvaudio
  | `Wmav1
  | `Wmav2
  | `Mace3
  | `Mace6
  | `Vmdaudio
  | `Flac
  | `Mp3adu
  | `Mp3on4
  | `Shorten
  | `Alac
  | `Westwood_snd1
  | `Gsm
  | `Qdm2
  | `Cook
  | `Truespeech
  | `Tta
  | `Smackaudio
  | `Qcelp
  | `Wavpack
  | `Dsicinaudio
  | `Imc
  | `Musepack7
  | `Mlp
  | `Gsm_ms
  | `Atrac3
  | `Ape
  | `Nellymoser
  | `Musepack8
  | `Speex
  | `Wmavoice
  | `Wmapro
  | `Wmalossless
  | `Atrac3p
  | `Eac3
  | `Sipr
  | `Mp1
  | `Twinvq
  | `Truehd
  | `Mp4als
  | `Atrac1
  | `Binkaudio_rdft
  | `Binkaudio_dct
  | `Aac_latm
  | `Qdmc
  | `Celt
  | `G723_1
  | `G729
  | `_8svx_exp
  | `_8svx_fib
  | `Bmv_audio
  | `Ralf
  | `Iac
  | `Ilbc
  | `Opus
  | `Comfort_noise
  | `Tak
  | `Metasound
  | `Paf_audio
  | `On2avc
  | `Dss_sp
  | `Codec2
  | `Ffwavesynth
  | `Sonic
  | `Sonic_ls
  | `Evrc
  | `Smv
  | `Dsd_lsbf
  | `Dsd_msbf
  | `Dsd_lsbf_planar
  | `Dsd_msbf_planar
  | `_4gv
  | `Interplay_acm
  | `Xma1
  | `Xma2
  | `Dst
  | `Atrac3al
  | `Atrac3pal
  | `Dolby_e
  | `Aptx
  | `Aptx_hd
  | `Sbc
  | `Atrac9
  | `Hcom
  | `Acelp_kelvin
  | `Mpegh_3d_audio
  | `Siren
  | `Hca
  | `Fastaudio
  | `Msnsiren
  | `Dfpwm
]

let audio: audio list  = [
`Dfpwm;
`Msnsiren;
`Fastaudio;
`Hca;
`Siren;
`Mpegh_3d_audio;
`Acelp_kelvin;
`Hcom;
`Atrac9;
`Sbc;
`Aptx_hd;
`Aptx;
`Dolby_e;
`Atrac3pal;
`Atrac3al;
`Dst;
`Xma2;
`Xma1;
`Interplay_acm;
`_4gv;
`Dsd_msbf_planar;
`Dsd_lsbf_planar;
`Dsd_msbf;
`Dsd_lsbf;
`Smv;
`Evrc;
`Sonic_ls;
`Sonic;
`Ffwavesynth;
`Codec2;
`Dss_sp;
`On2avc;
`Paf_audio;
`Metasound;
`Tak;
`Comfort_noise;
`Opus;
`Ilbc;
`Iac;
`Ralf;
`Bmv_audio;
`_8svx_fib;
`_8svx_exp;
`G729;
`G723_1;
`Celt;
`Qdmc;
`Aac_latm;
`Binkaudio_dct;
`Binkaudio_rdft;
`Atrac1;
`Mp4als;
`Truehd;
`Twinvq;
`Mp1;
`Sipr;
`Eac3;
`Atrac3p;
`Wmalossless;
`Wmapro;
`Wmavoice;
`Speex;
`Musepack8;
`Nellymoser;
`Ape;
`Atrac3;
`Gsm_ms;
`Mlp;
`Musepack7;
`Imc;
`Dsicinaudio;
`Wavpack;
`Qcelp;
`Smackaudio;
`Tta;
`Truespeech;
`Cook;
`Qdm2;
`Gsm;
`Westwood_snd1;
`Alac;
`Shorten;
`Mp3on4;
`Mp3adu;
`Flac;
`Vmdaudio;
`Mace6;
`Mace3;
`Wmav2;
`Wmav1;
`Dvaudio;
`Vorbis;
`Dts;
`Ac3;
`Aac;
`Mp3;
`Mp2;
`Derf_dpcm;
`Gremlin_dpcm;
`Sdx2_dpcm;
`Sol_dpcm;
`Xan_dpcm;
`Interplay_dpcm;
`Roq_dpcm;
`Ra_288;
`Ra_144;
`Amr_wb;
`Amr_nb;
`Adpcm_ima_acorn;
`Adpcm_ima_moflex;
`Adpcm_ima_cunning;
`Adpcm_ima_mtf;
`Adpcm_ima_alp;
`Adpcm_ima_apm;
`Adpcm_zork;
`Adpcm_ima_ssi;
`Adpcm_argo;
`Adpcm_agm;
`Adpcm_mtaf;
`Adpcm_ima_dat4;
`Adpcm_aica;
`Adpcm_psx;
`Adpcm_thp_le;
`Adpcm_g726le;
`Adpcm_ima_rad;
`Adpcm_dtk;
`Adpcm_ima_oki;
`Adpcm_afc;
`Adpcm_vima;
`Adpcm_ima_apc;
`Adpcm_g722;
`Adpcm_ima_iss;
`Adpcm_ea_maxis_xa;
`Adpcm_ea_xas;
`Adpcm_ima_ea_eacs;
`Adpcm_ima_ea_sead;
`Adpcm_ea_r2;
`Adpcm_ea_r3;
`Adpcm_ea_r1;
`Adpcm_ima_amv;
`Adpcm_thp;
`Adpcm_sbpro_2;
`Adpcm_sbpro_3;
`Adpcm_sbpro_4;
`Adpcm_yamaha;
`Adpcm_swf;
`Adpcm_ct;
`Adpcm_g726;
`Adpcm_ea;
`Adpcm_adx;
`Adpcm_xa;
`Adpcm_4xm;
`Adpcm_ms;
`Adpcm_ima_smjpeg;
`Adpcm_ima_ws;
`Adpcm_ima_dk4;
`Adpcm_ima_dk3;
`Adpcm_ima_wav;
`Adpcm_ima_qt;
`Pcm_sga;
`Pcm_vidc;
`Pcm_f24le;
`Pcm_f16le;
`Pcm_s64be;
`Pcm_s64le;
`Pcm_s16be_planar;
`Pcm_s32le_planar;
`Pcm_s24le_planar;
`Pcm_s8_planar;
`S302m;
`Pcm_lxf;
`Pcm_bluray;
`Pcm_f64le;
`Pcm_f64be;
`Pcm_f32le;
`Pcm_f32be;
`Pcm_dvd;
`Pcm_s16le_planar;
`Pcm_zork;
`Pcm_s24daud;
`Pcm_u24be;
`Pcm_u24le;
`Pcm_s24be;
`Pcm_s24le;
`Pcm_u32be;
`Pcm_u32le;
`Pcm_s32be;
`Pcm_s32le;
`Pcm_alaw;
`Pcm_mulaw;
`Pcm_u8;
`Pcm_s8;
`Pcm_u16be;
`Pcm_u16le;
`Pcm_s16be;
`Pcm_s16le;
]

type subtitle = [
  | `Dvd_subtitle
  | `Dvb_subtitle
  | `Text
  | `Xsub
  | `Ssa
  | `Mov_text
  | `Hdmv_pgs_subtitle
  | `Dvb_teletext
  | `Srt
  | `Microdvd
  | `Eia_608
  | `Jacosub
  | `Sami
  | `Realtext
  | `Stl
  | `Subviewer1
  | `Subviewer
  | `Subrip
  | `Webvtt
  | `Mpl2
  | `Vplayer
  | `Pjs
  | `Ass
  | `Hdmv_text_subtitle
  | `Ttml
  | `Arib_caption
]

let subtitle: subtitle list  = [
`Arib_caption;
`Ttml;
`Hdmv_text_subtitle;
`Ass;
`Pjs;
`Vplayer;
`Mpl2;
`Webvtt;
`Subrip;
`Subviewer;
`Subviewer1;
`Stl;
`Realtext;
`Sami;
`Jacosub;
`Eia_608;
`Microdvd;
`Srt;
`Dvb_teletext;
`Hdmv_pgs_subtitle;
`Mov_text;
`Ssa;
`Xsub;
`Text;
`Dvb_subtitle;
`Dvd_subtitle;
]

type codec_id = [
  | `Mpeg1video
  | `Mpeg2video
  | `H261
  | `H263
  | `Rv10
  | `Rv20
  | `Mjpeg
  | `Mjpegb
  | `Ljpeg
  | `Sp5x
  | `Jpegls
  | `Mpeg4
  | `Rawvideo
  | `Msmpeg4v1
  | `Msmpeg4v2
  | `Msmpeg4v3
  | `Wmv1
  | `Wmv2
  | `H263p
  | `H263i
  | `Flv1
  | `Svq1
  | `Svq3
  | `Dvvideo
  | `Huffyuv
  | `Cyuv
  | `H264
  | `Indeo3
  | `Vp3
  | `Theora
  | `Asv1
  | `Asv2
  | `Ffv1
  | `_4xm
  | `Vcr1
  | `Cljr
  | `Mdec
  | `Roq
  | `Interplay_video
  | `Xan_wc3
  | `Xan_wc4
  | `Rpza
  | `Cinepak
  | `Ws_vqa
  | `Msrle
  | `Msvideo1
  | `Idcin
  | `_8bps
  | `Smc
  | `Flic
  | `Truemotion1
  | `Vmdvideo
  | `Mszh
  | `Zlib
  | `Qtrle
  | `Tscc
  | `Ulti
  | `Qdraw
  | `Vixl
  | `Qpeg
  | `Png
  | `Ppm
  | `Pbm
  | `Pgm
  | `Pgmyuv
  | `Pam
  | `Ffvhuff
  | `Rv30
  | `Rv40
  | `Vc1
  | `Wmv3
  | `Loco
  | `Wnv1
  | `Aasc
  | `Indeo2
  | `Fraps
  | `Truemotion2
  | `Bmp
  | `Cscd
  | `Mmvideo
  | `Zmbv
  | `Avs
  | `Smackvideo
  | `Nuv
  | `Kmvc
  | `Flashsv
  | `Cavs
  | `Jpeg2000
  | `Vmnc
  | `Vp5
  | `Vp6
  | `Vp6f
  | `Targa
  | `Dsicinvideo
  | `Tiertexseqvideo
  | `Tiff
  | `Gif
  | `Dxa
  | `Dnxhd
  | `Thp
  | `Sgi
  | `C93
  | `Bethsoftvid
  | `Ptx
  | `Txd
  | `Vp6a
  | `Amv
  | `Vb
  | `Pcx
  | `Sunrast
  | `Indeo4
  | `Indeo5
  | `Mimic
  | `Rl2
  | `Escape124
  | `Dirac
  | `Bfi
  | `Cmv
  | `Motionpixels
  | `Tgv
  | `Tgq
  | `Tqi
  | `Aura
  | `Aura2
  | `V210x
  | `Tmv
  | `V210
  | `Dpx
  | `Mad
  | `Frwu
  | `Flashsv2
  | `Cdgraphics
  | `R210
  | `Anm
  | `Binkvideo
  | `Iff_ilbm
  | `Kgv1
  | `Yop
  | `Vp8
  | `Pictor
  | `Ansi
  | `A64_multi
  | `A64_multi5
  | `R10k
  | `Mxpeg
  | `Lagarith
  | `Prores
  | `Jv
  | `Dfa
  | `Wmv3image
  | `Vc1image
  | `Utvideo
  | `Bmv_video
  | `Vble
  | `Dxtory
  | `V410
  | `Xwd
  | `Cdxl
  | `Xbm
  | `Zerocodec
  | `Mss1
  | `Msa1
  | `Tscc2
  | `Mts2
  | `Cllc
  | `Mss2
  | `Vp9
  | `Aic
  | `Escape130
  | `G2m
  | `Webp
  | `Hnm4_video
  | `Hevc
  | `Fic
  | `Alias_pix
  | `Brender_pix
  | `Paf_video
  | `Exr
  | `Vp7
  | `Sanm
  | `Sgirle
  | `Mvc1
  | `Mvc2
  | `Hqx
  | `Tdsc
  | `Hq_hqa
  | `Hap
  | `Dds
  | `Dxv
  | `Screenpresso
  | `Rscc
  | `Avs2
  | `Pgx
  | `Avs3
  | `Msp2
  | `Vvc
  | `Y41p
  | `Avrp
  | `_012v
  | `Avui
  | `Ayuv
  | `Targa_y216
  | `V308
  | `V408
  | `Yuv4
  | `Avrn
  | `Cpia
  | `Xface
  | `Snow
  | `Smvjpeg
  | `Apng
  | `Daala
  | `Cfhd
  | `Truemotion2rt
  | `M101
  | `Magicyuv
  | `Sheervideo
  | `Ylc
  | `Psd
  | `Pixlet
  | `Speedhq
  | `Fmvc
  | `Scpr
  | `Clearvideo
  | `Xpm
  | `Av1
  | `Bitpacked
  | `Mscc
  | `Srgc
  | `Svg
  | `Gdv
  | `Fits
  | `Imm4
  | `Prosumer
  | `Mwsc
  | `Wcmv
  | `Rasc
  | `Hymt
  | `Arbc
  | `Agm
  | `Lscr
  | `Vp4
  | `Imm5
  | `Mvdv
  | `Mvha
  | `Cdtoons
  | `Mv30
  | `Notchlc
  | `Pfm
  | `Mobiclip
  | `Photocd
  | `Ipu
  | `Argo
  | `Cri
  | `Simbiosis_imx
  | `Sga_video
  | `Gem
  | `Vbn
  | `Jpegxl
  | `Qoi
  | `Phm
  | `First_audio
  | `Pcm_s16le
  | `Pcm_s16be
  | `Pcm_u16le
  | `Pcm_u16be
  | `Pcm_s8
  | `Pcm_u8
  | `Pcm_mulaw
  | `Pcm_alaw
  | `Pcm_s32le
  | `Pcm_s32be
  | `Pcm_u32le
  | `Pcm_u32be
  | `Pcm_s24le
  | `Pcm_s24be
  | `Pcm_u24le
  | `Pcm_u24be
  | `Pcm_s24daud
  | `Pcm_zork
  | `Pcm_s16le_planar
  | `Pcm_dvd
  | `Pcm_f32be
  | `Pcm_f32le
  | `Pcm_f64be
  | `Pcm_f64le
  | `Pcm_bluray
  | `Pcm_lxf
  | `S302m
  | `Pcm_s8_planar
  | `Pcm_s24le_planar
  | `Pcm_s32le_planar
  | `Pcm_s16be_planar
  | `Pcm_s64le
  | `Pcm_s64be
  | `Pcm_f16le
  | `Pcm_f24le
  | `Pcm_vidc
  | `Pcm_sga
  | `Adpcm_ima_qt
  | `Adpcm_ima_wav
  | `Adpcm_ima_dk3
  | `Adpcm_ima_dk4
  | `Adpcm_ima_ws
  | `Adpcm_ima_smjpeg
  | `Adpcm_ms
  | `Adpcm_4xm
  | `Adpcm_xa
  | `Adpcm_adx
  | `Adpcm_ea
  | `Adpcm_g726
  | `Adpcm_ct
  | `Adpcm_swf
  | `Adpcm_yamaha
  | `Adpcm_sbpro_4
  | `Adpcm_sbpro_3
  | `Adpcm_sbpro_2
  | `Adpcm_thp
  | `Adpcm_ima_amv
  | `Adpcm_ea_r1
  | `Adpcm_ea_r3
  | `Adpcm_ea_r2
  | `Adpcm_ima_ea_sead
  | `Adpcm_ima_ea_eacs
  | `Adpcm_ea_xas
  | `Adpcm_ea_maxis_xa
  | `Adpcm_ima_iss
  | `Adpcm_g722
  | `Adpcm_ima_apc
  | `Adpcm_vima
  | `Adpcm_afc
  | `Adpcm_ima_oki
  | `Adpcm_dtk
  | `Adpcm_ima_rad
  | `Adpcm_g726le
  | `Adpcm_thp_le
  | `Adpcm_psx
  | `Adpcm_aica
  | `Adpcm_ima_dat4
  | `Adpcm_mtaf
  | `Adpcm_agm
  | `Adpcm_argo
  | `Adpcm_ima_ssi
  | `Adpcm_zork
  | `Adpcm_ima_apm
  | `Adpcm_ima_alp
  | `Adpcm_ima_mtf
  | `Adpcm_ima_cunning
  | `Adpcm_ima_moflex
  | `Adpcm_ima_acorn
  | `Amr_nb
  | `Amr_wb
  | `Ra_144
  | `Ra_288
  | `Roq_dpcm
  | `Interplay_dpcm
  | `Xan_dpcm
  | `Sol_dpcm
  | `Sdx2_dpcm
  | `Gremlin_dpcm
  | `Derf_dpcm
  | `Mp2
  | `Mp3
  | `Aac
  | `Ac3
  | `Dts
  | `Vorbis
  | `Dvaudio
  | `Wmav1
  | `Wmav2
  | `Mace3
  | `Mace6
  | `Vmdaudio
  | `Flac
  | `Mp3adu
  | `Mp3on4
  | `Shorten
  | `Alac
  | `Westwood_snd1
  | `Gsm
  | `Qdm2
  | `Cook
  | `Truespeech
  | `Tta
  | `Smackaudio
  | `Qcelp
  | `Wavpack
  | `Dsicinaudio
  | `Imc
  | `Musepack7
  | `Mlp
  | `Gsm_ms
  | `Atrac3
  | `Ape
  | `Nellymoser
  | `Musepack8
  | `Speex
  | `Wmavoice
  | `Wmapro
  | `Wmalossless
  | `Atrac3p
  | `Eac3
  | `Sipr
  | `Mp1
  | `Twinvq
  | `Truehd
  | `Mp4als
  | `Atrac1
  | `Binkaudio_rdft
  | `Binkaudio_dct
  | `Aac_latm
  | `Qdmc
  | `Celt
  | `G723_1
  | `G729
  | `_8svx_exp
  | `_8svx_fib
  | `Bmv_audio
  | `Ralf
  | `Iac
  | `Ilbc
  | `Opus
  | `Comfort_noise
  | `Tak
  | `Metasound
  | `Paf_audio
  | `On2avc
  | `Dss_sp
  | `Codec2
  | `Ffwavesynth
  | `Sonic
  | `Sonic_ls
  | `Evrc
  | `Smv
  | `Dsd_lsbf
  | `Dsd_msbf
  | `Dsd_lsbf_planar
  | `Dsd_msbf_planar
  | `_4gv
  | `Interplay_acm
  | `Xma1
  | `Xma2
  | `Dst
  | `Atrac3al
  | `Atrac3pal
  | `Dolby_e
  | `Aptx
  | `Aptx_hd
  | `Sbc
  | `Atrac9
  | `Hcom
  | `Acelp_kelvin
  | `Mpegh_3d_audio
  | `Siren
  | `Hca
  | `Fastaudio
  | `Msnsiren
  | `Dfpwm
  | `First_subtitle
  | `Dvd_subtitle
  | `Dvb_subtitle
  | `Text
  | `Xsub
  | `Ssa
  | `Mov_text
  | `Hdmv_pgs_subtitle
  | `Dvb_teletext
  | `Srt
  | `Microdvd
  | `Eia_608
  | `Jacosub
  | `Sami
  | `Realtext
  | `Stl
  | `Subviewer1
  | `Subviewer
  | `Subrip
  | `Webvtt
  | `Mpl2
  | `Vplayer
  | `Pjs
  | `Ass
  | `Hdmv_text_subtitle
  | `Ttml
  | `Arib_caption
  | `First_unknown
  | `Ttf
  | `Scte_35
  | `Epg
  | `Bintext
  | `Xbin
  | `Idf
  | `Otf
  | `Smpte_klv
  | `Dvd_nav
  | `Timed_id3
  | `Bin_data
  | `Probe
  | `Mpeg2ts
  | `Mpeg4systems
  | `Ffmetadata
  | `Wrapped_avframe
]

let codec_id: codec_id list  = [
`Wrapped_avframe;
`Ffmetadata;
`Mpeg4systems;
`Mpeg2ts;
`Probe;
`Bin_data;
`Timed_id3;
`Dvd_nav;
`Smpte_klv;
`Otf;
`Idf;
`Xbin;
`Bintext;
`Epg;
`Scte_35;
`Ttf;
`First_unknown;
`Arib_caption;
`Ttml;
`Hdmv_text_subtitle;
`Ass;
`Pjs;
`Vplayer;
`Mpl2;
`Webvtt;
`Subrip;
`Subviewer;
`Subviewer1;
`Stl;
`Realtext;
`Sami;
`Jacosub;
`Eia_608;
`Microdvd;
`Srt;
`Dvb_teletext;
`Hdmv_pgs_subtitle;
`Mov_text;
`Ssa;
`Xsub;
`Text;
`Dvb_subtitle;
`Dvd_subtitle;
`First_subtitle;
`Dfpwm;
`Msnsiren;
`Fastaudio;
`Hca;
`Siren;
`Mpegh_3d_audio;
`Acelp_kelvin;
`Hcom;
`Atrac9;
`Sbc;
`Aptx_hd;
`Aptx;
`Dolby_e;
`Atrac3pal;
`Atrac3al;
`Dst;
`Xma2;
`Xma1;
`Interplay_acm;
`_4gv;
`Dsd_msbf_planar;
`Dsd_lsbf_planar;
`Dsd_msbf;
`Dsd_lsbf;
`Smv;
`Evrc;
`Sonic_ls;
`Sonic;
`Ffwavesynth;
`Codec2;
`Dss_sp;
`On2avc;
`Paf_audio;
`Metasound;
`Tak;
`Comfort_noise;
`Opus;
`Ilbc;
`Iac;
`Ralf;
`Bmv_audio;
`_8svx_fib;
`_8svx_exp;
`G729;
`G723_1;
`Celt;
`Qdmc;
`Aac_latm;
`Binkaudio_dct;
`Binkaudio_rdft;
`Atrac1;
`Mp4als;
`Truehd;
`Twinvq;
`Mp1;
`Sipr;
`Eac3;
`Atrac3p;
`Wmalossless;
`Wmapro;
`Wmavoice;
`Speex;
`Musepack8;
`Nellymoser;
`Ape;
`Atrac3;
`Gsm_ms;
`Mlp;
`Musepack7;
`Imc;
`Dsicinaudio;
`Wavpack;
`Qcelp;
`Smackaudio;
`Tta;
`Truespeech;
`Cook;
`Qdm2;
`Gsm;
`Westwood_snd1;
`Alac;
`Shorten;
`Mp3on4;
`Mp3adu;
`Flac;
`Vmdaudio;
`Mace6;
`Mace3;
`Wmav2;
`Wmav1;
`Dvaudio;
`Vorbis;
`Dts;
`Ac3;
`Aac;
`Mp3;
`Mp2;
`Derf_dpcm;
`Gremlin_dpcm;
`Sdx2_dpcm;
`Sol_dpcm;
`Xan_dpcm;
`Interplay_dpcm;
`Roq_dpcm;
`Ra_288;
`Ra_144;
`Amr_wb;
`Amr_nb;
`Adpcm_ima_acorn;
`Adpcm_ima_moflex;
`Adpcm_ima_cunning;
`Adpcm_ima_mtf;
`Adpcm_ima_alp;
`Adpcm_ima_apm;
`Adpcm_zork;
`Adpcm_ima_ssi;
`Adpcm_argo;
`Adpcm_agm;
`Adpcm_mtaf;
`Adpcm_ima_dat4;
`Adpcm_aica;
`Adpcm_psx;
`Adpcm_thp_le;
`Adpcm_g726le;
`Adpcm_ima_rad;
`Adpcm_dtk;
`Adpcm_ima_oki;
`Adpcm_afc;
`Adpcm_vima;
`Adpcm_ima_apc;
`Adpcm_g722;
`Adpcm_ima_iss;
`Adpcm_ea_maxis_xa;
`Adpcm_ea_xas;
`Adpcm_ima_ea_eacs;
`Adpcm_ima_ea_sead;
`Adpcm_ea_r2;
`Adpcm_ea_r3;
`Adpcm_ea_r1;
`Adpcm_ima_amv;
`Adpcm_thp;
`Adpcm_sbpro_2;
`Adpcm_sbpro_3;
`Adpcm_sbpro_4;
`Adpcm_yamaha;
`Adpcm_swf;
`Adpcm_ct;
`Adpcm_g726;
`Adpcm_ea;
`Adpcm_adx;
`Adpcm_xa;
`Adpcm_4xm;
`Adpcm_ms;
`Adpcm_ima_smjpeg;
`Adpcm_ima_ws;
`Adpcm_ima_dk4;
`Adpcm_ima_dk3;
`Adpcm_ima_wav;
`Adpcm_ima_qt;
`Pcm_sga;
`Pcm_vidc;
`Pcm_f24le;
`Pcm_f16le;
`Pcm_s64be;
`Pcm_s64le;
`Pcm_s16be_planar;
`Pcm_s32le_planar;
`Pcm_s24le_planar;
`Pcm_s8_planar;
`S302m;
`Pcm_lxf;
`Pcm_bluray;
`Pcm_f64le;
`Pcm_f64be;
`Pcm_f32le;
`Pcm_f32be;
`Pcm_dvd;
`Pcm_s16le_planar;
`Pcm_zork;
`Pcm_s24daud;
`Pcm_u24be;
`Pcm_u24le;
`Pcm_s24be;
`Pcm_s24le;
`Pcm_u32be;
`Pcm_u32le;
`Pcm_s32be;
`Pcm_s32le;
`Pcm_alaw;
`Pcm_mulaw;
`Pcm_u8;
`Pcm_s8;
`Pcm_u16be;
`Pcm_u16le;
`Pcm_s16be;
`Pcm_s16le;
`First_audio;
`Phm;
`Qoi;
`Jpegxl;
`Vbn;
`Gem;
`Sga_video;
`Simbiosis_imx;
`Cri;
`Argo;
`Ipu;
`Photocd;
`Mobiclip;
`Pfm;
`Notchlc;
`Mv30;
`Cdtoons;
`Mvha;
`Mvdv;
`Imm5;
`Vp4;
`Lscr;
`Agm;
`Arbc;
`Hymt;
`Rasc;
`Wcmv;
`Mwsc;
`Prosumer;
`Imm4;
`Fits;
`Gdv;
`Svg;
`Srgc;
`Mscc;
`Bitpacked;
`Av1;
`Xpm;
`Clearvideo;
`Scpr;
`Fmvc;
`Speedhq;
`Pixlet;
`Psd;
`Ylc;
`Sheervideo;
`Magicyuv;
`M101;
`Truemotion2rt;
`Cfhd;
`Daala;
`Apng;
`Smvjpeg;
`Snow;
`Xface;
`Cpia;
`Avrn;
`Yuv4;
`V408;
`V308;
`Targa_y216;
`Ayuv;
`Avui;
`_012v;
`Avrp;
`Y41p;
`Vvc;
`Msp2;
`Avs3;
`Pgx;
`Avs2;
`Rscc;
`Screenpresso;
`Dxv;
`Dds;
`Hap;
`Hq_hqa;
`Tdsc;
`Hqx;
`Mvc2;
`Mvc1;
`Sgirle;
`Sanm;
`Vp7;
`Exr;
`Paf_video;
`Brender_pix;
`Alias_pix;
`Fic;
`Hevc;
`Hnm4_video;
`Webp;
`G2m;
`Escape130;
`Aic;
`Vp9;
`Mss2;
`Cllc;
`Mts2;
`Tscc2;
`Msa1;
`Mss1;
`Zerocodec;
`Xbm;
`Cdxl;
`Xwd;
`V410;
`Dxtory;
`Vble;
`Bmv_video;
`Utvideo;
`Vc1image;
`Wmv3image;
`Dfa;
`Jv;
`Prores;
`Lagarith;
`Mxpeg;
`R10k;
`A64_multi5;
`A64_multi;
`Ansi;
`Pictor;
`Vp8;
`Yop;
`Kgv1;
`Iff_ilbm;
`Binkvideo;
`Anm;
`R210;
`Cdgraphics;
`Flashsv2;
`Frwu;
`Mad;
`Dpx;
`V210;
`Tmv;
`V210x;
`Aura2;
`Aura;
`Tqi;
`Tgq;
`Tgv;
`Motionpixels;
`Cmv;
`Bfi;
`Dirac;
`Escape124;
`Rl2;
`Mimic;
`Indeo5;
`Indeo4;
`Sunrast;
`Pcx;
`Vb;
`Amv;
`Vp6a;
`Txd;
`Ptx;
`Bethsoftvid;
`C93;
`Sgi;
`Thp;
`Dnxhd;
`Dxa;
`Gif;
`Tiff;
`Tiertexseqvideo;
`Dsicinvideo;
`Targa;
`Vp6f;
`Vp6;
`Vp5;
`Vmnc;
`Jpeg2000;
`Cavs;
`Flashsv;
`Kmvc;
`Nuv;
`Smackvideo;
`Avs;
`Zmbv;
`Mmvideo;
`Cscd;
`Bmp;
`Truemotion2;
`Fraps;
`Indeo2;
`Aasc;
`Wnv1;
`Loco;
`Wmv3;
`Vc1;
`Rv40;
`Rv30;
`Ffvhuff;
`Pam;
`Pgmyuv;
`Pgm;
`Pbm;
`Ppm;
`Png;
`Qpeg;
`Vixl;
`Qdraw;
`Ulti;
`Tscc;
`Qtrle;
`Zlib;
`Mszh;
`Vmdvideo;
`Truemotion1;
`Flic;
`Smc;
`_8bps;
`Idcin;
`Msvideo1;
`Msrle;
`Ws_vqa;
`Cinepak;
`Rpza;
`Xan_wc4;
`Xan_wc3;
`Interplay_video;
`Roq;
`Mdec;
`Cljr;
`Vcr1;
`_4xm;
`Ffv1;
`Asv2;
`Asv1;
`Theora;
`Vp3;
`Indeo3;
`H264;
`Cyuv;
`Huffyuv;
`Dvvideo;
`Svq3;
`Svq1;
`Flv1;
`H263i;
`H263p;
`Wmv2;
`Wmv1;
`Msmpeg4v3;
`Msmpeg4v2;
`Msmpeg4v1;
`Rawvideo;
`Mpeg4;
`Jpegls;
`Sp5x;
`Ljpeg;
`Mjpegb;
`Mjpeg;
`Rv20;
`Rv10;
`H263;
`H261;
`Mpeg2video;
`Mpeg1video;
]

