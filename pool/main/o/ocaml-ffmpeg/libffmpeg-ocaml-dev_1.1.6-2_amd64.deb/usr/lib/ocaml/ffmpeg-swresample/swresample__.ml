(** @canonical Swresample.Swresample_options *)
module Swresample_options = Swresample__Swresample_options
