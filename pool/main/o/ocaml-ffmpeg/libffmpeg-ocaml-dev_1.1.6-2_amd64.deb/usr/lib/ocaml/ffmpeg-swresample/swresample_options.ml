type dither_type = [
  | `Dither_rectangular
  | `Dither_triangular
  | `Dither_triangular_highpass
]

let dither_type: dither_type list  = [
`Dither_triangular_highpass;
`Dither_triangular;
`Dither_rectangular;
]

type engine = [
  | `Engine_swr
  | `Engine_soxr
]

let engine: engine list  = [
`Engine_soxr;
`Engine_swr;
]

type filter_type = [
  | `Filter_type_cubic
  | `Filter_type_blackman_nuttall
  | `Filter_type_kaiser
]

let filter_type: filter_type list  = [
`Filter_type_kaiser;
`Filter_type_blackman_nuttall;
`Filter_type_cubic;
]

