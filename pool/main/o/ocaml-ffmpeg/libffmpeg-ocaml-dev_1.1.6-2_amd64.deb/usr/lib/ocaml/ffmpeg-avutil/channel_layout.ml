type t = [
  | `Native
  | `Mono
  | `Stereo
  | `_2point1
  | `_2_1
  | `Surround
  | `_3point1
  | `_4point0
  | `_4point1
  | `_2_2
  | `Quad
  | `_5point0
  | `_5point1
  | `_5point0_back
  | `_5point1_back
  | `_6point0
  | `_6point0_front
  | `Hexagonal
  | `_6point1
  | `_6point1_back
  | `_6point1_front
  | `_7point0
  | `_7point0_front
  | `_7point1
  | `_7point1_wide
  | `_7point1_wide_back
  | `Octagonal
  | `Hexadecagonal
  | `Stereo_downmix
  | `_22point2
]

let t: t list  = [
`_22point2;
`Stereo_downmix;
`Hexadecagonal;
`Octagonal;
`_7point1_wide_back;
`_7point1_wide;
`_7point1;
`_7point0_front;
`_7point0;
`_6point1_front;
`_6point1_back;
`_6point1;
`Hexagonal;
`_6point0_front;
`_6point0;
`_5point1_back;
`_5point0_back;
`_5point1;
`_5point0;
`Quad;
`_2_2;
`_4point1;
`_4point0;
`_3point1;
`Surround;
`_2_1;
`_2point1;
`Stereo;
`Mono;
`Native;
]

