type t = [
  | `Draw_horiz_band
  | `Dr1
  | `Truncated
  | `Delay
  | `Small_last_frame
  | `Subframes
  | `Experimental
  | `Channel_conf
  | `Frame_threads
  | `Slice_threads
  | `Param_change
  | `Other_threads
  | `Auto_threads
  | `Variable_frame_size
  | `Avoid_probing
  | `Intra_only
  | `Lossless
  | `Hardware
  | `Hybrid
  | `Encoder_reordered_opaque
  | `Encoder_flush
]

let t: t list  = [
`Encoder_flush;
`Encoder_reordered_opaque;
`Hybrid;
`Hardware;
`Lossless;
`Intra_only;
`Avoid_probing;
`Variable_frame_size;
`Auto_threads;
`Other_threads;
`Param_change;
`Slice_threads;
`Frame_threads;
`Channel_conf;
`Experimental;
`Subframes;
`Small_last_frame;
`Delay;
`Truncated;
`Dr1;
`Draw_horiz_band;
]

