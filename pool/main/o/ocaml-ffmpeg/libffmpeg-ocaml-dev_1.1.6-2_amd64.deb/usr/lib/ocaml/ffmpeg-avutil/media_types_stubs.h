#include "avutil_stubs.h"

#define VALUE_NOT_FOUND 0xFFFFFFF

static const int64_t AVMEDIA_TYPE_T_TAB[][2] = {
  {(1570281173), AVMEDIA_TYPE_UNKNOWN},
  {(-1806497609), AVMEDIA_TYPE_VIDEO},
  {(1968951661), AVMEDIA_TYPE_AUDIO},
  {(1517880469), AVMEDIA_TYPE_DATA},
  {(-1749192591), AVMEDIA_TYPE_SUBTITLE},
  {(-1471670265), AVMEDIA_TYPE_ATTACHMENT},
};

#define AVMEDIA_TYPE_T_TAB_LEN 6
uint64_t MediaTypes_val(value v){
int i;
for(i=0;i<AVMEDIA_TYPE_T_TAB_LEN;i++){
if(v==AVMEDIA_TYPE_T_TAB[i][0])return AVMEDIA_TYPE_T_TAB[i][1];
}
Fail("Could not find C value for %ld in AVMEDIA_TYPE_T_TAB. Do you need to recompile the ffmpeg binding?", v);
return -1;
}
uint64_t MediaTypes_val_no_raise(value v){
int i;
for(i=0;i<AVMEDIA_TYPE_T_TAB_LEN;i++){
if(v==AVMEDIA_TYPE_T_TAB[i][0])return AVMEDIA_TYPE_T_TAB[i][1];
}
return VALUE_NOT_FOUND;
}
value Val_MediaTypes(uint64_t t){
int i;
for(i=0;i<AVMEDIA_TYPE_T_TAB_LEN; i++){
if(t==AVMEDIA_TYPE_T_TAB[i][1])return AVMEDIA_TYPE_T_TAB[i][0];
}
Fail("Could not find OCaml value for %d in AVMEDIA_TYPE_T_TAB. Do you need to recompile the ffmpeg binding?", t);
return -1;
}
