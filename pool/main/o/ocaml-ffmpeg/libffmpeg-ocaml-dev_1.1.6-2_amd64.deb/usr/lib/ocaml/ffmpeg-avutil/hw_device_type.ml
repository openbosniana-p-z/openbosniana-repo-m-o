type t = [
  | `None
  | `Vdpau
  | `Cuda
  | `Vaapi
  | `Dxva2
  | `Qsv
  | `Videotoolbox
  | `D3d11va
  | `Drm
  | `Opencl
  | `Mediacodec
  | `Vulkan
]

let t: t list  = [
`Vulkan;
`Mediacodec;
`Opencl;
`Drm;
`D3d11va;
`Videotoolbox;
`Qsv;
`Dxva2;
`Vaapi;
`Cuda;
`Vdpau;
`None;
]

