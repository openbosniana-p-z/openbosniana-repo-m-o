type t = [
  | `Hw_device_ctx
  | `Hw_frames_ctx
  | `Internal
  | `Ad_hoc
]

let t: t list  = [
`Ad_hoc;
`Internal;
`Hw_frames_ctx;
`Hw_device_ctx;
]

