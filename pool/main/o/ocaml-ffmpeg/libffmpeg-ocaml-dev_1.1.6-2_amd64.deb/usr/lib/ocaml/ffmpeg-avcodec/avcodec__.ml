(** @canonical Avcodec.Codec_capabilities *)
module Codec_capabilities = Avcodec__Codec_capabilities


(** @canonical Avcodec.Codec_id *)
module Codec_id = Avcodec__Codec_id


(** @canonical Avcodec.Codec_properties *)
module Codec_properties = Avcodec__Codec_properties


(** @canonical Avcodec.Hw_config_method *)
module Hw_config_method = Avcodec__Hw_config_method
