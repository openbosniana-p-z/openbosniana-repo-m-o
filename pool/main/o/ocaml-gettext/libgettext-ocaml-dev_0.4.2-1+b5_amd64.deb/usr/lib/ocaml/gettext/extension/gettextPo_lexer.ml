# 23 "src/lib/gettext/extension/gettextPo_lexer.mll"
 

open GettextPo_parser;;

let next_line lexbuf =
  lexbuf.Lexing.lex_curr_p <-
  {
    lexbuf.Lexing.lex_curr_p with
    Lexing.pos_lnum = lexbuf.Lexing.lex_curr_p.Lexing.pos_lnum + 1;
    Lexing.pos_bol  = lexbuf.Lexing.lex_curr_p.Lexing.pos_cnum;
  }
;;


# 17 "src/lib/gettext/extension/gettextPo_lexer.ml"
let __ocaml_lex_tables = {
  Lexing.lex_base =
   "\000\000\242\255\243\255\244\255\000\000\248\255\011\000\250\255\
    \251\255\000\000\000\000\000\000\001\000\001\000\001\000\000\000\
    \255\255\000\000\000\000\000\000\001\000\005\000\000\000\002\000\
    \253\255\004\000\001\000\000\000\010\000\252\255\246\255\247\255\
    \002\000\243\255\004\000\035\000\108\000\022\000\247\255\248\255\
    \249\255\250\255\251\255\252\255\253\255\254\255\255\255\131\000\
    \246\255\146\000\245\255\001\000\254\255\255\255\005\000\006\000\
    \253\255\002\000\000\000\255\255";
  Lexing.lex_backtrk =
   "\255\255\255\255\255\255\255\255\010\000\255\255\006\000\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\001\000\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\011\000\255\255\255\255\009\000\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\009\000\
    \255\255\010\000\255\255\255\255\255\255\255\255\003\000\003\000\
    \255\255\001\000\255\255\255\255";
  Lexing.lex_default =
   "\255\255\000\000\000\000\000\000\255\255\000\000\255\255\000\000\
    \000\000\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \000\000\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \000\000\255\255\255\255\255\255\255\255\000\000\000\000\000\000\
    \034\000\000\000\034\000\255\255\255\255\255\255\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\255\255\
    \000\000\255\255\000\000\052\000\000\000\000\000\055\000\055\000\
    \000\000\255\255\255\255\000\000";
  Lexing.lex_trans =
   "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\003\000\002\000\053\000\000\000\002\000\000\000\057\000\
    \255\255\000\000\056\000\255\255\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \003\000\000\000\005\000\004\000\033\000\058\000\255\255\000\000\
    \000\000\000\000\000\000\000\000\030\000\000\000\059\000\000\000\
    \006\000\006\000\006\000\006\000\006\000\006\000\006\000\006\000\
    \006\000\006\000\031\000\006\000\006\000\006\000\006\000\006\000\
    \006\000\006\000\006\000\006\000\006\000\039\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\000\000\000\000\
    \000\000\000\000\000\000\037\000\037\000\037\000\037\000\037\000\
    \037\000\037\000\037\000\008\000\000\000\007\000\035\000\018\000\
    \255\255\023\000\027\000\000\000\009\000\017\000\000\000\012\000\
    \000\000\028\000\013\000\000\000\020\000\010\000\024\000\025\000\
    \019\000\026\000\016\000\011\000\014\000\015\000\021\000\022\000\
    \029\000\000\000\000\000\000\000\000\000\000\000\000\000\038\000\
    \000\000\000\000\000\000\000\000\040\000\044\000\000\000\000\000\
    \000\000\042\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\046\000\000\000\000\000\000\000\043\000\000\000\045\000\
    \000\000\041\000\000\000\036\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\048\000\048\000\048\000\048\000\048\000\
    \048\000\048\000\048\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\050\000\050\000\050\000\050\000\050\000\050\000\
    \050\000\050\000\050\000\050\000\000\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\050\000\050\000\050\000\050\000\050\000\
    \050\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\050\000\050\000\050\000\050\000\050\000\
    \050\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \001\000\255\255\255\255\000\000\255\255\255\255\255\255\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000";
  Lexing.lex_check =
   "\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\000\000\000\000\051\000\255\255\000\000\255\255\054\000\
    \055\000\255\255\054\000\055\000\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \000\000\255\255\000\000\000\000\032\000\057\000\034\000\255\255\
    \255\255\255\255\255\255\255\255\004\000\255\255\058\000\255\255\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\004\000\006\000\006\000\006\000\006\000\006\000\
    \006\000\006\000\006\000\006\000\006\000\035\000\037\000\037\000\
    \037\000\037\000\037\000\037\000\037\000\037\000\255\255\255\255\
    \255\255\255\255\255\255\035\000\035\000\035\000\035\000\035\000\
    \035\000\035\000\035\000\000\000\255\255\000\000\032\000\017\000\
    \034\000\022\000\026\000\255\255\000\000\013\000\255\255\011\000\
    \255\255\027\000\012\000\255\255\019\000\000\000\023\000\009\000\
    \018\000\025\000\015\000\010\000\012\000\014\000\020\000\021\000\
    \028\000\255\255\255\255\255\255\255\255\255\255\255\255\035\000\
    \255\255\255\255\255\255\255\255\035\000\035\000\255\255\255\255\
    \255\255\035\000\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\035\000\255\255\255\255\255\255\035\000\255\255\035\000\
    \255\255\035\000\255\255\035\000\036\000\036\000\036\000\036\000\
    \036\000\036\000\036\000\036\000\036\000\036\000\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\036\000\036\000\036\000\
    \036\000\036\000\036\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\255\255\036\000\036\000\036\000\
    \036\000\036\000\036\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\049\000\049\000\049\000\049\000\049\000\
    \049\000\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \000\000\051\000\032\000\255\255\034\000\054\000\055\000\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255";
  Lexing.lex_base_code =
   "";
  Lexing.lex_backtrk_code =
   "";
  Lexing.lex_default_code =
   "";
  Lexing.lex_trans_code =
   "";
  Lexing.lex_check_code =
   "";
  Lexing.lex_code =
   "";
}

let rec token lexbuf =
   __ocaml_lex_token_rec lexbuf 0
and __ocaml_lex_token_rec lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 40 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( MSGSTR )
# 171 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 1 ->
# 41 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( MSGID )
# 176 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 2 ->
# 42 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( MSGID_PLURAL )
# 181 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 3 ->
# 43 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( DOMAIN )
# 186 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 4 ->
# 44 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( LBRACKET )
# 191 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 5 ->
# 45 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( RBRACKET )
# 196 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 6 ->
let
# 46 "src/lib/gettext/extension/gettextPo_lexer.mll"
                nbr
# 202 "src/lib/gettext/extension/gettextPo_lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 46 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( NUMBER (int_of_string nbr) )
# 206 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 7 ->
# 47 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( STRING (string_val lexbuf) )
# 211 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 8 ->
# 48 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( COMMENT_FILEPOS(comment_join (Buffer.create 80) lexbuf))
# 216 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 9 ->
# 49 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( COMMENT_SPECIAL(comment_join (Buffer.create 80) lexbuf))
# 221 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 10 ->
# 50 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( comment_skip lexbuf )
# 226 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 11 ->
# 51 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( token lexbuf )
# 231 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 12 ->
# 52 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( next_line lexbuf; token lexbuf )
# 236 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 13 ->
# 53 "src/lib/gettext/extension/gettextPo_lexer.mll"
                             ( EOF )
# 241 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf;
      __ocaml_lex_token_rec lexbuf __ocaml_lex_state

and string_val lexbuf =
   __ocaml_lex_string_val_rec lexbuf 32
and __ocaml_lex_string_val_rec lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 57 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( "\n" ^ ( string_val lexbuf) )
# 253 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 1 ->
# 58 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( "\t" ^ ( string_val lexbuf) )
# 258 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 2 ->
# 59 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( "\b" ^ ( string_val lexbuf) )
# 263 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 3 ->
# 60 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( "\r" ^ ( string_val lexbuf) )
# 268 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 4 ->
# 61 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( "\012" ^ ( string_val lexbuf) )
# 273 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 5 ->
# 62 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( "\011" ^ ( string_val lexbuf) )
# 278 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 6 ->
# 63 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( "\007" ^ ( string_val lexbuf) )
# 283 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 7 ->
# 64 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( "\"" ^ ( string_val lexbuf) )
# 288 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 8 ->
# 65 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( "\\" ^ ( string_val lexbuf) )
# 293 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 9 ->
let
# 66 "src/lib/gettext/extension/gettextPo_lexer.mll"
                                            oct
# 299 "src/lib/gettext/extension/gettextPo_lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 67 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     (
                       let chr =
                         try
                           char_of_int (int_of_string ( "0o" ^ oct ))
                         with _ ->
                           char_of_int 255
                       in
                       ( String.make 1 chr ) ^ ( string_val lexbuf )
                     )
# 311 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 10 ->
let
# 76 "src/lib/gettext/extension/gettextPo_lexer.mll"
                                                              hex
# 317 "src/lib/gettext/extension/gettextPo_lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 77 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     (
                       let chr =
                         try
                           char_of_int (int_of_string ("0x" ^ hex ))
                         with _ ->
                           char_of_int 255
                       in
                       ( String.make 1 chr ) ^ ( string_val lexbuf )
                     )
# 329 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 11 ->
let
# 86 "src/lib/gettext/extension/gettextPo_lexer.mll"
                 str
# 335 "src/lib/gettext/extension/gettextPo_lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 86 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( str ^ (string_val lexbuf) )
# 339 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 12 ->
# 87 "src/lib/gettext/extension/gettextPo_lexer.mll"
                     ( "" )
# 344 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf;
      __ocaml_lex_string_val_rec lexbuf __ocaml_lex_state

and comment_skip lexbuf =
   __ocaml_lex_comment_skip_rec lexbuf 51
and __ocaml_lex_comment_skip_rec lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 91 "src/lib/gettext/extension/gettextPo_lexer.mll"
           ( next_line lexbuf; token lexbuf )
# 356 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 1 ->
# 92 "src/lib/gettext/extension/gettextPo_lexer.mll"
               ( comment_skip lexbuf )
# 361 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf;
      __ocaml_lex_comment_skip_rec lexbuf __ocaml_lex_state

and comment_join strbuf lexbuf =
   __ocaml_lex_comment_join_rec strbuf lexbuf 54
and __ocaml_lex_comment_join_rec strbuf lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 96 "src/lib/gettext/extension/gettextPo_lexer.mll"
                  ( next_line lexbuf; comment_join strbuf lexbuf )
# 373 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 1 ->
# 97 "src/lib/gettext/extension/gettextPo_lexer.mll"
                  ( next_line lexbuf; Buffer.contents strbuf )
# 378 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 2 ->
# 98 "src/lib/gettext/extension/gettextPo_lexer.mll"
                  ( comment_join strbuf lexbuf )
# 383 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | 3 ->
let
# 99 "src/lib/gettext/extension/gettextPo_lexer.mll"
                  str
# 389 "src/lib/gettext/extension/gettextPo_lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 99 "src/lib/gettext/extension/gettextPo_lexer.mll"
                      ( Buffer.add_string strbuf str; comment_join strbuf lexbuf )
# 393 "src/lib/gettext/extension/gettextPo_lexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf;
      __ocaml_lex_comment_join_rec strbuf lexbuf __ocaml_lex_state

;;

