type token =
  | EOF
  | NPLURALS
  | SEMICOLON
  | PLURAL
  | EQUAL
  | CHARSET
  | QUESTION_MARK
  | COLON
  | OR
  | AND
  | EQ
  | NEQ
  | LE
  | L
  | GE
  | G
  | PLUS
  | MINUS
  | MUL
  | DIV
  | MOD
  | NOT
  | ID
  | RPAREN
  | LPAREN
  | FIELD_NAME of (string*string)
  | CONTENT_TYPE of (string)
  | PLURAL_FORMS of (string)
  | NUMBER of (int)
  | STRING of (string)

open Parsing;;
let _ = parse_error;;
# 24 "src/lib/gettext/base/gettextMo_parser.mly"
# 37 "src/lib/gettext/base/gettextMo_parser.ml"
let yytransl_const = [|
    0 (* EOF *);
  257 (* NPLURALS *);
  258 (* SEMICOLON *);
  259 (* PLURAL *);
  260 (* EQUAL *);
  261 (* CHARSET *);
  262 (* QUESTION_MARK *);
  263 (* COLON *);
  264 (* OR *);
  265 (* AND *);
  266 (* EQ *);
  267 (* NEQ *);
  268 (* LE *);
  269 (* L *);
  270 (* GE *);
  271 (* G *);
  272 (* PLUS *);
  273 (* MINUS *);
  274 (* MUL *);
  275 (* DIV *);
  276 (* MOD *);
  277 (* NOT *);
  278 (* ID *);
  279 (* RPAREN *);
  280 (* LPAREN *);
    0|]

let yytransl_block = [|
  281 (* FIELD_NAME *);
  282 (* CONTENT_TYPE *);
  283 (* PLURAL_FORMS *);
  284 (* NUMBER *);
  285 (* STRING *);
    0|]

let yylhs = "\255\255\
\001\000\004\000\004\000\005\000\005\000\005\000\002\000\002\000\
\003\000\006\000\006\000\006\000\006\000\006\000\006\000\006\000\
\006\000\006\000\006\000\006\000\006\000\006\000\006\000\006\000\
\006\000\006\000\006\000\000\000\000\000\000\000"

let yylen = "\002\000\
\002\000\002\000\001\000\001\000\001\000\001\000\007\000\008\000\
\005\000\001\000\001\000\005\000\003\000\003\000\003\000\003\000\
\003\000\003\000\003\000\003\000\003\000\003\000\003\000\003\000\
\003\000\002\000\003\000\002\000\002\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\004\000\005\000\006\000\028\000\
\000\000\003\000\000\000\029\000\000\000\030\000\001\000\002\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\009\000\
\000\000\000\000\010\000\000\000\011\000\000\000\026\000\000\000\
\008\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\027\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\023\000\024\000\025\000\000\000\000\000"

let yydgoto = "\004\000\
\008\000\012\000\014\000\009\000\010\000\030\000"

let yysindex = "\040\000\
\052\255\255\254\231\254\000\000\000\000\000\000\000\000\000\000\
\001\000\000\000\021\255\000\000\024\255\000\000\000\000\000\000\
\016\255\055\255\059\255\053\255\092\255\067\255\111\255\000\000\
\107\255\107\255\000\000\107\255\000\000\056\255\000\000\074\255\
\000\000\107\255\107\255\107\255\107\255\107\255\107\255\107\255\
\107\255\107\255\107\255\107\255\107\255\107\255\107\255\000\000\
\094\255\019\255\036\255\106\255\106\255\246\254\246\254\246\254\
\246\254\114\255\114\255\000\000\000\000\000\000\107\255\138\255"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\098\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\145\000\137\000\117\000\127\000\045\000\063\000\081\000\
\099\000\002\000\027\000\000\000\000\000\000\000\000\000\059\000"

let yygindex = "\000\000\
\000\000\000\000\000\000\000\000\107\000\233\255"

let yytablesize = 424
let yytable = "\011\000\
\015\000\021\000\031\000\013\000\032\000\043\000\044\000\045\000\
\046\000\047\000\049\000\050\000\051\000\052\000\053\000\054\000\
\055\000\056\000\057\000\058\000\059\000\060\000\061\000\062\000\
\017\000\018\000\022\000\036\000\037\000\038\000\039\000\040\000\
\041\000\042\000\043\000\044\000\045\000\046\000\047\000\064\000\
\001\000\002\000\003\000\019\000\017\000\037\000\038\000\039\000\
\040\000\041\000\042\000\043\000\044\000\045\000\046\000\047\000\
\022\000\033\000\012\000\020\000\021\000\034\000\018\000\035\000\
\036\000\037\000\038\000\039\000\040\000\041\000\042\000\043\000\
\044\000\045\000\046\000\047\000\005\000\006\000\007\000\034\000\
\019\000\035\000\036\000\037\000\038\000\039\000\040\000\041\000\
\042\000\043\000\044\000\045\000\046\000\047\000\023\000\024\000\
\048\000\007\000\020\000\034\000\063\000\035\000\036\000\037\000\
\038\000\039\000\040\000\041\000\042\000\043\000\044\000\045\000\
\046\000\047\000\025\000\016\000\015\000\039\000\040\000\041\000\
\042\000\043\000\044\000\045\000\046\000\047\000\016\000\026\000\
\027\000\000\000\028\000\045\000\046\000\047\000\029\000\000\000\
\014\000\000\000\000\000\000\000\000\000\000\000\000\000\034\000\
\013\000\035\000\036\000\037\000\038\000\039\000\040\000\041\000\
\042\000\043\000\044\000\045\000\046\000\047\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\021\000\000\000\000\000\000\000\021\000\
\021\000\021\000\021\000\021\000\021\000\021\000\021\000\021\000\
\021\000\021\000\021\000\000\000\000\000\000\000\000\000\000\000\
\021\000\005\000\006\000\007\000\022\000\000\000\000\000\000\000\
\022\000\022\000\022\000\022\000\022\000\022\000\022\000\022\000\
\022\000\022\000\022\000\022\000\000\000\000\000\017\000\000\000\
\000\000\022\000\017\000\017\000\017\000\017\000\017\000\017\000\
\017\000\017\000\017\000\017\000\012\000\000\000\000\000\000\000\
\018\000\012\000\000\000\017\000\018\000\018\000\018\000\018\000\
\018\000\018\000\018\000\018\000\018\000\018\000\000\000\000\000\
\000\000\012\000\019\000\000\000\000\000\018\000\019\000\019\000\
\019\000\019\000\019\000\019\000\019\000\019\000\019\000\019\000\
\000\000\000\000\000\000\000\000\020\000\000\000\000\000\019\000\
\020\000\020\000\020\000\020\000\020\000\020\000\020\000\020\000\
\020\000\020\000\000\000\000\000\000\000\000\000\015\000\000\000\
\000\000\020\000\015\000\015\000\015\000\015\000\015\000\015\000\
\016\000\000\000\000\000\000\000\016\000\016\000\016\000\016\000\
\016\000\016\000\014\000\015\000\000\000\000\000\014\000\014\000\
\014\000\014\000\013\000\000\000\000\000\016\000\013\000\013\000\
\013\000\000\000\000\000\000\000\000\000\000\000\000\000\014\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\013\000"

let yycheck = "\001\001\
\000\000\000\000\026\000\029\001\028\000\016\001\017\001\018\001\
\019\001\020\001\034\000\035\000\036\000\037\000\038\000\039\000\
\040\000\041\000\042\000\043\000\044\000\045\000\046\000\047\000\
\004\001\002\001\000\000\009\001\010\001\011\001\012\001\013\001\
\014\001\015\001\016\001\017\001\018\001\019\001\020\001\063\000\
\001\000\002\000\003\000\028\001\000\000\010\001\011\001\012\001\
\013\001\014\001\015\001\016\001\017\001\018\001\019\001\020\001\
\004\001\002\001\000\000\005\001\002\001\006\001\000\000\008\001\
\009\001\010\001\011\001\012\001\013\001\014\001\015\001\016\001\
\017\001\018\001\019\001\020\001\025\001\026\001\027\001\006\001\
\000\000\008\001\009\001\010\001\011\001\012\001\013\001\014\001\
\015\001\016\001\017\001\018\001\019\001\020\001\003\001\029\001\
\023\001\000\000\000\000\006\001\007\001\008\001\009\001\010\001\
\011\001\012\001\013\001\014\001\015\001\016\001\017\001\018\001\
\019\001\020\001\004\001\009\000\000\000\012\001\013\001\014\001\
\015\001\016\001\017\001\018\001\019\001\020\001\000\000\021\001\
\022\001\255\255\024\001\018\001\019\001\020\001\028\001\255\255\
\000\000\255\255\255\255\255\255\255\255\255\255\255\255\006\001\
\000\000\008\001\009\001\010\001\011\001\012\001\013\001\014\001\
\015\001\016\001\017\001\018\001\019\001\020\001\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\002\001\255\255\255\255\255\255\006\001\
\007\001\008\001\009\001\010\001\011\001\012\001\013\001\014\001\
\015\001\016\001\017\001\255\255\255\255\255\255\255\255\255\255\
\023\001\025\001\026\001\027\001\002\001\255\255\255\255\255\255\
\006\001\007\001\008\001\009\001\010\001\011\001\012\001\013\001\
\014\001\015\001\016\001\017\001\255\255\255\255\002\001\255\255\
\255\255\023\001\006\001\007\001\008\001\009\001\010\001\011\001\
\012\001\013\001\014\001\015\001\002\001\255\255\255\255\255\255\
\002\001\007\001\255\255\023\001\006\001\007\001\008\001\009\001\
\010\001\011\001\012\001\013\001\014\001\015\001\255\255\255\255\
\255\255\023\001\002\001\255\255\255\255\023\001\006\001\007\001\
\008\001\009\001\010\001\011\001\012\001\013\001\014\001\015\001\
\255\255\255\255\255\255\255\255\002\001\255\255\255\255\023\001\
\006\001\007\001\008\001\009\001\010\001\011\001\012\001\013\001\
\014\001\015\001\255\255\255\255\255\255\255\255\002\001\255\255\
\255\255\023\001\006\001\007\001\008\001\009\001\010\001\011\001\
\002\001\255\255\255\255\255\255\006\001\007\001\008\001\009\001\
\010\001\011\001\002\001\023\001\255\255\255\255\006\001\007\001\
\008\001\009\001\002\001\255\255\255\255\023\001\006\001\007\001\
\008\001\255\255\255\255\255\255\255\255\255\255\255\255\023\001\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\023\001"

let yynames_const = "\
  EOF\000\
  NPLURALS\000\
  SEMICOLON\000\
  PLURAL\000\
  EQUAL\000\
  CHARSET\000\
  QUESTION_MARK\000\
  COLON\000\
  OR\000\
  AND\000\
  EQ\000\
  NEQ\000\
  LE\000\
  L\000\
  GE\000\
  G\000\
  PLUS\000\
  MINUS\000\
  MUL\000\
  DIV\000\
  MOD\000\
  NOT\000\
  ID\000\
  RPAREN\000\
  LPAREN\000\
  "

let yynames_block = "\
  FIELD_NAME\000\
  CONTENT_TYPE\000\
  PLURAL_FORMS\000\
  NUMBER\000\
  STRING\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'lines) in
    Obj.repr(
# 79 "src/lib/gettext/base/gettextMo_parser.mly"
               (  _1 )
# 276 "src/lib/gettext/base/gettextMo_parser.ml"
               :  (string * string) list ))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'lines) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'line) in
    Obj.repr(
# 83 "src/lib/gettext/base/gettextMo_parser.mly"
               ( _2 :: _1 )
# 284 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'lines))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'line) in
    Obj.repr(
# 84 "src/lib/gettext/base/gettextMo_parser.mly"
               ( [_1] )
# 291 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'lines))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string*string) in
    Obj.repr(
# 88 "src/lib/gettext/base/gettextMo_parser.mly"
               ( let (a,b) = _1 in (a, b) )
# 298 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'line))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 89 "src/lib/gettext/base/gettextMo_parser.mly"
               ( ("Content-Type", _1) )
# 305 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'line))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 90 "src/lib/gettext/base/gettextMo_parser.mly"
               ( ("Plural-Forms", _1) )
# 312 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'line))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 4 : int) in
    let _7 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 94 "src/lib/gettext/base/gettextMo_parser.mly"
                                                              ( (_3,_7) )
# 320 "src/lib/gettext/base/gettextMo_parser.ml"
               :  int * ( int -> int ) ))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 5 : int) in
    let _7 = (Parsing.peek_val __caml_parser_env 1 : 'expr) in
    Obj.repr(
# 95 "src/lib/gettext/base/gettextMo_parser.mly"
                                                              ( (_3,_7) )
# 328 "src/lib/gettext/base/gettextMo_parser.ml"
               :  int * ( int -> int ) ))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : string) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 99 "src/lib/gettext/base/gettextMo_parser.mly"
                                                    ( (_1,String.uppercase_ascii _5) )
# 336 "src/lib/gettext/base/gettextMo_parser.ml"
               :  string * string ))
; (fun __caml_parser_env ->
    Obj.repr(
# 103 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> x  )
# 342 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 104 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun _x -> _1 )
# 349 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 105 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> if (_1 x) != 0 then (_3 x) else (_5 x) )
# 358 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 106 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> if (_1 x) != 0 then 1 else (_3 x) )
# 366 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 107 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> if (_1 x) != 0 then 0 else (_3 x) )
# 374 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 108 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> if (_1 x)  = (_3 x) then 1 else 0 )
# 382 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 109 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> if (_1 x) != (_3 x) then 1 else 0 )
# 390 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 110 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> if (_1 x) <= (_3 x) then 1 else 0 )
# 398 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 111 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> if (_1 x) <  (_3 x) then 1 else 0 )
# 406 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 112 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> if (_1 x) >= (_3 x) then 1 else 0 )
# 414 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 113 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> if (_1 x) >  (_3 x) then 1 else 0 )
# 422 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 114 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> (_1 x) + (_3 x) )
# 430 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 115 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> (_1 x) - (_3 x) )
# 438 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 116 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> (_1 x) * (_3 x) )
# 446 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 117 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> (_1 x) / (_3 x) )
# 454 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 118 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> (_1 x) mod (_3 x) )
# 462 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'expr) in
    Obj.repr(
# 119 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> if (_2 x) = 0 then 1 else 0 )
# 469 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'expr) in
    Obj.repr(
# 120 "src/lib/gettext/base/gettextMo_parser.mly"
                                      ( fun x -> _2 x)
# 476 "src/lib/gettext/base/gettextMo_parser.ml"
               : 'expr))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry plural_forms *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry content_type *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf :  (string * string) list )
let plural_forms (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 2 lexfun lexbuf :  int * ( int -> int ) )
let content_type (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 3 lexfun lexbuf :  string * string )
;;
