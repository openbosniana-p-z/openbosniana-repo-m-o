let default_localedir = "/usr/share/locale"

let localedir = "/usr/local/share/locale"

let version = "dev"
