type token =
  | COLON
  | LINE of (int)
  | KEYWORD of (string)
  | FILENAME of (string)
  | COMMENT_EOF

open Parsing;;
let _ = parse_error;;
# 25 "src/lib/gettext/extension/gettextPoComment_parser.mly"
# 12 "src/lib/gettext/extension/gettextPoComment_parser.ml"
let yytransl_const = [|
  257 (* COLON *);
  261 (* COMMENT_EOF *);
    0|]

let yytransl_block = [|
  258 (* LINE *);
  259 (* KEYWORD *);
  260 (* FILENAME *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\003\000\003\000\004\000\002\000\002\000\005\000\
\005\000\000\000\000\000"

let yylen = "\002\000\
\002\000\001\000\002\000\001\000\003\000\002\000\001\000\002\000\
\001\000\002\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\002\000\010\000\000\000\004\000\
\009\000\007\000\011\000\000\000\000\000\001\000\003\000\008\000\
\006\000\005\000"

let yydgoto = "\003\000\
\006\000\011\000\007\000\008\000\012\000"

let yysindex = "\003\000\
\002\255\253\254\000\000\009\255\000\000\000\000\004\255\000\000\
\000\000\000\000\000\000\254\254\010\255\000\000\000\000\000\000\
\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000"

let yygindex = "\000\000\
\000\000\000\000\000\000\004\000\000\000"

let yytablesize = 12
let yytable = "\009\000\
\016\000\010\000\017\000\001\000\002\000\004\000\005\000\004\000\
\014\000\013\000\015\000\018\000"

let yycheck = "\003\001\
\003\001\005\001\005\001\001\000\002\000\004\001\005\001\004\001\
\005\001\001\001\007\000\002\001"

let yynames_const = "\
  COLON\000\
  COMMENT_EOF\000\
  "

let yynames_block = "\
  LINE\000\
  KEYWORD\000\
  FILENAME\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'filepos_list) in
    Obj.repr(
# 40 "src/lib/gettext/extension/gettextPoComment_parser.mly"
                           ( List.rev _1 )
# 80 "src/lib/gettext/extension/gettextPoComment_parser.ml"
               : GettextTypes.po_filepos list))
; (fun __caml_parser_env ->
    Obj.repr(
# 41 "src/lib/gettext/extension/gettextPoComment_parser.mly"
                           ( [] )
# 86 "src/lib/gettext/extension/gettextPoComment_parser.ml"
               : GettextTypes.po_filepos list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'filepos_list) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'filepos) in
    Obj.repr(
# 45 "src/lib/gettext/extension/gettextPoComment_parser.mly"
                       ( _2 :: _1 )
# 94 "src/lib/gettext/extension/gettextPoComment_parser.ml"
               : 'filepos_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'filepos) in
    Obj.repr(
# 46 "src/lib/gettext/extension/gettextPoComment_parser.mly"
                       ( [_1] )
# 101 "src/lib/gettext/extension/gettextPoComment_parser.ml"
               : 'filepos_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 50 "src/lib/gettext/extension/gettextPoComment_parser.mly"
                      ( (_1,_3) )
# 109 "src/lib/gettext/extension/gettextPoComment_parser.ml"
               : 'filepos))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'special_list) in
    Obj.repr(
# 54 "src/lib/gettext/extension/gettextPoComment_parser.mly"
                           ( List.rev _1 )
# 116 "src/lib/gettext/extension/gettextPoComment_parser.ml"
               : GettextTypes.po_special list))
; (fun __caml_parser_env ->
    Obj.repr(
# 55 "src/lib/gettext/extension/gettextPoComment_parser.mly"
                           ( [] )
# 122 "src/lib/gettext/extension/gettextPoComment_parser.ml"
               : GettextTypes.po_special list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'special_list) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 59 "src/lib/gettext/extension/gettextPoComment_parser.mly"
                       ( _2 :: _1 )
# 130 "src/lib/gettext/extension/gettextPoComment_parser.ml"
               : 'special_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 60 "src/lib/gettext/extension/gettextPoComment_parser.mly"
                       ( [_1] )
# 137 "src/lib/gettext/extension/gettextPoComment_parser.ml"
               : 'special_list))
(* Entry comment_filepos *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry comment_special *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let comment_filepos (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : GettextTypes.po_filepos list)
let comment_special (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 2 lexfun lexbuf : GettextTypes.po_special list)
