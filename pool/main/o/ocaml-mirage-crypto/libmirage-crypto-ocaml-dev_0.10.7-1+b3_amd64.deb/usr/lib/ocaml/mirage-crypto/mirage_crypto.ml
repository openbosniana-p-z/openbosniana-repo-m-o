module Uncommon = Uncommon
module Hash = Hash
module Poly1305 = Poly1305.It
module type AEAD = Aead.AEAD
module Cipher_block = Cipher_block
module Chacha20 = Chacha20
module Cipher_stream = Cipher_stream
