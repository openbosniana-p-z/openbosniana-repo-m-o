include Rng

module Fortuna = Fortuna
module Hmac_drbg = Hmac_drbg.Make
module Entropy = Entropy
