(** @canonical Mirage_crypto_rng.Entropy *)
module Entropy = Mirage_crypto_rng__Entropy


(** @canonical Mirage_crypto_rng.Fortuna *)
module Fortuna = Mirage_crypto_rng__Fortuna


(** @canonical Mirage_crypto_rng.Hmac_drbg *)
module Hmac_drbg = Mirage_crypto_rng__Hmac_drbg


(** @canonical Mirage_crypto_rng.Rng *)
module Rng = Mirage_crypto_rng__Rng
