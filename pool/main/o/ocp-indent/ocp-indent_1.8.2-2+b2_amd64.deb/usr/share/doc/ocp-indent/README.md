ocp-indent is a simple tool and library to indent OCaml code.

ocp-indent is part of TypeRex, developed and maintained by OCamlPro. Documentation to install and use this tool is available on http://www.typerex.org/ocp-indent.html

It is released under LGPL v2.1 with linking exception.
