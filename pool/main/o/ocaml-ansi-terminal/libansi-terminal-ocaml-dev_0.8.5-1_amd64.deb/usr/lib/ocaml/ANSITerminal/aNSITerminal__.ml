(** @canonical ANSITerminal.ANSITerminal_common *)
module ANSITerminal_common = ANSITerminal__ANSITerminal_common
