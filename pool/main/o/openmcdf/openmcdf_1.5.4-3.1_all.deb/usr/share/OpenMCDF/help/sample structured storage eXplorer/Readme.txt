Sample Structured Storage explorer source code is located in main src directory of the distribution as TESTOpenMCDF subdirectory.

--
This application has to be considered ONLY a sample and NOT a production tool.