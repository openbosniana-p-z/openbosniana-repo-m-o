(** @canonical Bitstring.Bitstring_config *)
module Bitstring_config = Bitstring__Bitstring_config


(** @canonical Bitstring.Bitstring_types *)
module Bitstring_types = Bitstring__Bitstring_types
