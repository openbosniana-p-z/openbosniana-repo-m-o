var classOpm_1_1EclIO_1_1OutputStream_1_1SummarySpecification =
[
    [ "Parameters", "classOpm_1_1EclIO_1_1OutputStream_1_1SummarySpecification_1_1Parameters.html", null ],
    [ "RestartSpecification", "structOpm_1_1EclIO_1_1OutputStream_1_1SummarySpecification_1_1RestartSpecification.html", null ]
];