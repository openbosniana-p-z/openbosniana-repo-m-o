var classOpm_1_1EclHysterConfig =
[
    [ "active", "classOpm_1_1EclHysterConfig.html#ab15b6a9a01be8eefbb1e07b9a2ec93fa", null ],
    [ "curvatureCapPrs", "classOpm_1_1EclHysterConfig.html#a8a9206373192809aba4ed05ed2fb5278", null ],
    [ "krHysteresisModel", "classOpm_1_1EclHysterConfig.html#ab6f08dd6850f30aac4e5f61166329a01", null ],
    [ "modParamTrapped", "classOpm_1_1EclHysterConfig.html#a6ddc7540a6c1f100d8a017f76ee3c5e1", null ],
    [ "pcHysteresisModel", "classOpm_1_1EclHysterConfig.html#a0b94fc20e3c0fbbc97756b7c877075e0", null ]
];