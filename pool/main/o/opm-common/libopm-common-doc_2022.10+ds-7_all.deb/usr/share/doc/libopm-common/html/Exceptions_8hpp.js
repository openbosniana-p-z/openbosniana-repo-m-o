var Exceptions_8hpp =
[
    [ "Opm::NotImplemented", "classOpm_1_1NotImplemented.html", null ],
    [ "Opm::NumericalProblem", "classOpm_1_1NumericalProblem.html", null ],
    [ "Opm::MaterialLawProblem", "classOpm_1_1MaterialLawProblem.html", null ],
    [ "Opm::LinearSolverProblem", "classOpm_1_1LinearSolverProblem.html", null ],
    [ "Opm::TooManyIterations", "classOpm_1_1TooManyIterations.html", null ]
];