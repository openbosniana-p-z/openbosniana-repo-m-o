var classOpm_1_1DenT =
[
    [ "entry", "structOpm_1_1DenT_1_1entry.html", null ]
];