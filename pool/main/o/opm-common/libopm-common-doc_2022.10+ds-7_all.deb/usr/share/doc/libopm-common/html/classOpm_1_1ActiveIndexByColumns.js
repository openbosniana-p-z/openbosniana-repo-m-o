var classOpm_1_1ActiveIndexByColumns =
[
    [ "ActiveIndexByColumns", "classOpm_1_1ActiveIndexByColumns.html#a30c877d5c4dbecb3f7c7228015e3bae3", null ],
    [ "getColumnarActiveIndex", "classOpm_1_1ActiveIndexByColumns.html#aa907a4f79f5ade866570b692f634832d", null ]
];