
#ifndef OPM_PARSER_INIT_J_HH
#define OPM_PARSER_INIT_J_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsJ(Parser& p);
}
}
#endif
