
#ifndef OPM_PARSER_INIT_E_HH
#define OPM_PARSER_INIT_E_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsE(Parser& p);
}
}
#endif
