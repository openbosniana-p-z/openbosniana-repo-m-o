
#ifndef OPM_PARSER_INIT_I_HH
#define OPM_PARSER_INIT_I_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsI(Parser& p);
}
}
#endif
