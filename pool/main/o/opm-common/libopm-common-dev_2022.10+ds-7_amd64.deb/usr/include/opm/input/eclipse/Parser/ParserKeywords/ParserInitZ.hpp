
#ifndef OPM_PARSER_INIT_Z_HH
#define OPM_PARSER_INIT_Z_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsZ(Parser& p);
}
}
#endif
