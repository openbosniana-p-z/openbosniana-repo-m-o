
#ifndef OPM_PARSER_INIT_F_HH
#define OPM_PARSER_INIT_F_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsF(Parser& p);
}
}
#endif
