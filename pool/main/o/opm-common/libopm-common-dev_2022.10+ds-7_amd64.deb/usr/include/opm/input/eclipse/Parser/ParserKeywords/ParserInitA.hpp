
#ifndef OPM_PARSER_INIT_A_HH
#define OPM_PARSER_INIT_A_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsA(Parser& p);
}
}
#endif
