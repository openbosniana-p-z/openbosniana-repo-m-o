
#ifndef OPM_PARSER_INIT_O_HH
#define OPM_PARSER_INIT_O_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsO(Parser& p);
}
}
#endif
