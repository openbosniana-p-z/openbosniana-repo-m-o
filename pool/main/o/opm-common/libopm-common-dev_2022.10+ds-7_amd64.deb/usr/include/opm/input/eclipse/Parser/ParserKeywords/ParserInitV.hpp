
#ifndef OPM_PARSER_INIT_V_HH
#define OPM_PARSER_INIT_V_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsV(Parser& p);
}
}
#endif
