
#ifndef OPM_PARSER_INIT_G_HH
#define OPM_PARSER_INIT_G_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsG(Parser& p);
}
}
#endif
