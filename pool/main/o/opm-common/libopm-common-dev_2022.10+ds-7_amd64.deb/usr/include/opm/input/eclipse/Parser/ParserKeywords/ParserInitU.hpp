
#ifndef OPM_PARSER_INIT_U_HH
#define OPM_PARSER_INIT_U_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsU(Parser& p);
}
}
#endif
