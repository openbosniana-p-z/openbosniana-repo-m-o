
#ifndef OPM_PARSER_INIT_P_HH
#define OPM_PARSER_INIT_P_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsP(Parser& p);
}
}
#endif
