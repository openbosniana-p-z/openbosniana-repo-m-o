
#ifndef OPM_PARSER_INIT_B_HH
#define OPM_PARSER_INIT_B_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsB(Parser& p);
}
}
#endif
