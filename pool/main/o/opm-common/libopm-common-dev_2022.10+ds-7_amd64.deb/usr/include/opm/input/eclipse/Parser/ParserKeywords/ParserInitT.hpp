
#ifndef OPM_PARSER_INIT_T_HH
#define OPM_PARSER_INIT_T_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsT(Parser& p);
}
}
#endif
