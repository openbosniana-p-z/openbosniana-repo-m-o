
#ifndef OPM_PARSER_INIT_C_HH
#define OPM_PARSER_INIT_C_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsC(Parser& p);
}
}
#endif
