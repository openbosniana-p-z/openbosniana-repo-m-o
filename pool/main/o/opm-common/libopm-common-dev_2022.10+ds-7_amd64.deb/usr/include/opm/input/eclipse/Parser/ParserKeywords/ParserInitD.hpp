
#ifndef OPM_PARSER_INIT_D_HH
#define OPM_PARSER_INIT_D_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsD(Parser& p);
}
}
#endif
