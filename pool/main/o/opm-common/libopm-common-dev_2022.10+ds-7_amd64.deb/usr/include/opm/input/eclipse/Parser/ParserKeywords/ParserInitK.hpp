
#ifndef OPM_PARSER_INIT_K_HH
#define OPM_PARSER_INIT_K_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsK(Parser& p);
}
}
#endif
