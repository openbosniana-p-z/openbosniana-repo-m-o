
#ifndef OPM_PARSER_INIT_Y_HH
#define OPM_PARSER_INIT_Y_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsY(Parser& p);
}
}
#endif
