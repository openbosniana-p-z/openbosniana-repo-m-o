
#ifndef OPM_PARSER_INIT_Q_HH
#define OPM_PARSER_INIT_Q_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsQ(Parser& p);
}
}
#endif
