
#ifndef OPM_PARSER_INIT_R_HH
#define OPM_PARSER_INIT_R_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsR(Parser& p);
}
}
#endif
