
#ifndef OPM_PARSER_INIT_L_HH
#define OPM_PARSER_INIT_L_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsL(Parser& p);
}
}
#endif
