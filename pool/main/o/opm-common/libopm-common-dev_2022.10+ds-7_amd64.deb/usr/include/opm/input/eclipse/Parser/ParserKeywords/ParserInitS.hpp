
#ifndef OPM_PARSER_INIT_S_HH
#define OPM_PARSER_INIT_S_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsS(Parser& p);
}
}
#endif
