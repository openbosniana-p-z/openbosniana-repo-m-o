
#ifndef OPM_PARSER_INIT_X_HH
#define OPM_PARSER_INIT_X_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsX(Parser& p);
}
}
#endif
