
#ifndef OPM_PARSER_INIT_W_HH
#define OPM_PARSER_INIT_W_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsW(Parser& p);
}
}
#endif
