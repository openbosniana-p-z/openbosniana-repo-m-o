
#ifndef OPM_PARSER_INIT_M_HH
#define OPM_PARSER_INIT_M_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsM(Parser& p);
}
}
#endif
