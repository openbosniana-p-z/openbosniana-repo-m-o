
#ifndef OPM_PARSER_INIT_N_HH
#define OPM_PARSER_INIT_N_HH

namespace Opm {
class Parser;
namespace ParserKeywords {
void addDefaultKeywordsN(Parser& p);
}
}
#endif
