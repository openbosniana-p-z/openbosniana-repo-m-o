#ifndef OPARI_OMP_H
#define OPARI_OMP_H

  #ifdef _OPENMP
    #include <omp.h>
  #endif
#endif
