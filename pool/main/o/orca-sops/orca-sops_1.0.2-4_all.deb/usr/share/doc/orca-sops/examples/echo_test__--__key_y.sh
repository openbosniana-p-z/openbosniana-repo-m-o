#!/bin/bash
# simple hello world plugin. (Yea it is as simple as it looks)
echo "Hello World"
