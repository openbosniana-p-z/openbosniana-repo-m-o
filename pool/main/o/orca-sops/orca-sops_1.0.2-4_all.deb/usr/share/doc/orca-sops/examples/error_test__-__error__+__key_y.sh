#!/bin/bash
# this is just a test for testing stderr (error below: command not found) 
nonexistingcommand
