#!/usr/bin/python
# -*- coding: utf-8 -*-
# an example for import an advanced plugin
# speak "hello world"
import orca.orca # Imports the main screen reader
orca.speech.speak("hello world")
