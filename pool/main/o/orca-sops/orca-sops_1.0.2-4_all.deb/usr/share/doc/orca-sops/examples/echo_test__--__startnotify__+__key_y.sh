#!/bin/bash
# startnotify example (announce the start, wait 4 seconds, announce hello world
sleep 4
echo "Hello World"
