#!/bin/sh
# supressoutput test, you would just hear nothing :).
echo "This is a test that you would not hear, because the plugin is silenced."
