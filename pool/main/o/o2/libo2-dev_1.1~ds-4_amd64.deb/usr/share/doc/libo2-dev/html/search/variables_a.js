var searchData=
[
  ['o2_5factive_5fsched_0',['o2_active_sched',['../group__basics.html#ga91fe84d524309a27b579ea169d5816ae',1,'o2.h']]],
  ['o2_5fclock_5fis_5fsynchronized_1',['o2_clock_is_synchronized',['../group__basics.html#gaafc6760fd6ddcbcb20f99306b83c5b85',1,'o2.h']]],
  ['o2_5fgtsched_2',['o2_gtsched',['../group__basics.html#ga12a5538a2b701920639e89be06ad8d49',1,'o2.h']]],
  ['o2_5fltsched_3',['o2_ltsched',['../group__basics.html#ga65a8e27a3d04e922c4903e54f3399752',1,'o2.h']]],
  ['o2_5fstop_5fflag_4',['o2_stop_flag',['../group__basics.html#ga0148f5dab667f58540f2f2ce1074aa88',1,'o2.h']]]
];
