var searchData=
[
  ['address_0',['address',['../structo2__msg__data.html#aaa379598b83135e2bbf444c796af951a',1,'o2_msg_data']]],
  ['allocated_1',['allocated',['../structo2__message.html#a50b3015b5e78a568c2e0ac027850c121',1,'o2_message']]]
];
