var searchData=
[
  ['word_5falign_5fptr_0',['WORD_ALIGN_PTR',['../group__basics.html#ga22dcab1b6323a34f6587304996a45891',1,'o2.h']]]
];
