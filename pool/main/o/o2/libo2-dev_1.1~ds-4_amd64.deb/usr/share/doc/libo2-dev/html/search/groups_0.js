var searchData=
[
  ['basics_0',['Basics',['../group__basics.html',1,'']]]
];
