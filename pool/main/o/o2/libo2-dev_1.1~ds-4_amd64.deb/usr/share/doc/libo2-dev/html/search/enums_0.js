var searchData=
[
  ['o2_5ftype_0',['o2_type',['../group__basics.html#gadf84af81a4f69b65b351008e3146279f',1,'o2.h']]]
];
