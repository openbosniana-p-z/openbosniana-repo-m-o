var searchData=
[
  ['b_0',['B',['../uniono2__arg.html#a472e916e67bee7d2b7392a350e02e4bb',1,'o2_arg']]],
  ['b_1',['b',['../uniono2__arg.html#a6ac8817c5c66822d8ac7bb3b1fc1644e',1,'o2_arg']]]
];
