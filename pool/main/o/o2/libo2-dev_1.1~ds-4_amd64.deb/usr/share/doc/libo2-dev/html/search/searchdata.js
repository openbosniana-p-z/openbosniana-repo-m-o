var indexSectionsWithContent =
{
  0: "abcdfhilmnoprstvw",
  1: "o",
  2: "o",
  3: "o",
  4: "abcdfhilmnopstv",
  5: "o",
  6: "o",
  7: "o",
  8: "bdlr",
  9: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

