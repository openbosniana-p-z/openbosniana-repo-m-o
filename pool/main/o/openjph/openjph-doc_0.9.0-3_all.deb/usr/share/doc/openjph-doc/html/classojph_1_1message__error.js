var classojph_1_1message__error =
[
    [ "operator()", "classojph_1_1message__error.html#a73cae8aaaee798838b3faf3e96a7521e", null ]
];