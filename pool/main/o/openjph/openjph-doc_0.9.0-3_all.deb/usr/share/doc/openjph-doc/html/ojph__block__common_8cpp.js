var ojph__block__common_8cpp =
[
    [ "uvlc_init_tables", "ojph__block__common_8cpp.html#gab40d647a815cba166f28eee8b703d1e1", null ],
    [ "vlc_init_tables", "ojph__block__common_8cpp.html#ga2321384a030e92d82c71336117235310", null ],
    [ "uvlc_tables_initialized", "ojph__block__common_8cpp.html#ga7988800540a7aa06363e4b1b28ccdf7d", null ],
    [ "uvlc_tbl0", "ojph__block__common_8cpp.html#gac57518f95865823d3bd45cd38b3cafcb", null ],
    [ "uvlc_tbl1", "ojph__block__common_8cpp.html#gae6b0ec4c23a42c5d23c5cccb0db53ec5", null ],
    [ "vlc_tables_initialized", "ojph__block__common_8cpp.html#ga155222ada46b7ba970a60c67b1c99ed0", null ],
    [ "vlc_tbl0", "ojph__block__common_8cpp.html#ga896decad4e54a6aa149eb52f38b1f773", null ],
    [ "vlc_tbl1", "ojph__block__common_8cpp.html#ga3699f20545c8da9d965101b6f918a267", null ]
];