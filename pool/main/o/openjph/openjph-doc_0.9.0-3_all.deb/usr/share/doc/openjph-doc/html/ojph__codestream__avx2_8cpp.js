var ojph__codestream__avx2_8cpp =
[
    [ "avx2_find_max_val", "ojph__codestream__avx2_8cpp.html#a05cbf05671f84319a2a88c0a94058069", null ],
    [ "avx2_irv_tx_from_cb", "ojph__codestream__avx2_8cpp.html#a0e22306258539bf6e4b6a86c135faa0c", null ],
    [ "avx2_irv_tx_to_cb", "ojph__codestream__avx2_8cpp.html#ad61e21634b066fc1a1a01b61b6faaa2a", null ],
    [ "avx2_rev_tx_from_cb", "ojph__codestream__avx2_8cpp.html#ac531a382e05373774138bb6c1d90cc40", null ],
    [ "avx2_rev_tx_to_cb", "ojph__codestream__avx2_8cpp.html#a5de3ca58b73ed353d226524503fed316", null ]
];