var classojph_1_1image__in__base =
[
    [ "~image_in_base", "classojph_1_1image__in__base.html#ad4b567ffc96a9e82d28074e753a84446", null ],
    [ "close", "classojph_1_1image__in__base.html#a07e3c21b14f46d8f6b85fb7c33a9483f", null ],
    [ "read", "classojph_1_1image__in__base.html#ac912a5c00f20cea07c4b481556894239", null ]
];