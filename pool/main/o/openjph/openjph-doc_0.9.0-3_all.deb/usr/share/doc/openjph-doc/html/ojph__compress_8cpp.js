var ojph__compress_8cpp =
[
    [ "size_list_interpreter", "structsize__list__interpreter.html", "structsize__list__interpreter" ],
    [ "point_list_interpreter", "structpoint__list__interpreter.html", "structpoint__list__interpreter" ],
    [ "size_interpreter", "structsize__interpreter.html", "structsize__interpreter" ],
    [ "point_interpreter", "structpoint__interpreter.html", "structpoint__interpreter" ],
    [ "ui32_list_interpreter", "structui32__list__interpreter.html", "structui32__list__interpreter" ],
    [ "si32_to_bool_list_interpreter", "structsi32__to__bool__list__interpreter.html", "structsi32__to__bool__list__interpreter" ],
    [ "get_arguments", "ojph__compress_8cpp.html#a5b37ce36b4d19ad4bb09b1e76998d12f", null ],
    [ "get_file_extension", "ojph__compress_8cpp.html#ab453180833fbc91159493038237c34f4", null ],
    [ "main", "ojph__compress_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];