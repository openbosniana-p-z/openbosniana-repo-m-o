var classojph_1_1infile__base =
[
    [ "seek", "classojph_1_1infile__base.html#a85eb2a58349758637d43c47181e50eb0", [
      [ "OJPH_SEEK_SET", "classojph_1_1infile__base.html#a85eb2a58349758637d43c47181e50eb0a8438bad81700b8e057fecf08ed31fde4", null ],
      [ "OJPH_SEEK_CUR", "classojph_1_1infile__base.html#a85eb2a58349758637d43c47181e50eb0a9a10c509ac583ffbb7f5353c50c45091", null ],
      [ "OJPH_SEEK_END", "classojph_1_1infile__base.html#a85eb2a58349758637d43c47181e50eb0a14d5ca22098709d48173abf80d3bd691", null ]
    ] ],
    [ "~infile_base", "classojph_1_1infile__base.html#ab52fc55d2258ef8076f9ce58b5e2ee8c", null ],
    [ "close", "classojph_1_1infile__base.html#a9550285fed20e186fa464d483a6ba362", null ],
    [ "eof", "classojph_1_1infile__base.html#a4150115bb83abb6937730a157bc7ffce", null ],
    [ "read", "classojph_1_1infile__base.html#aef5977db92b3832c07ce417feee82de7", null ],
    [ "seek", "classojph_1_1infile__base.html#a24c1b46fd78c265f8e1ae3b791b31861", null ],
    [ "tell", "classojph_1_1infile__base.html#abd0f5c0f054ab05e3fe1b686e1341564", null ]
];