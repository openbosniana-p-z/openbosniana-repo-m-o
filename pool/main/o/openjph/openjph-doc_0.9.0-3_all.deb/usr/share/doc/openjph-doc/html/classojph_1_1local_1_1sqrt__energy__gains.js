var classojph_1_1local_1_1sqrt__energy__gains =
[
    [ "get_gain_h", "classojph_1_1local_1_1sqrt__energy__gains.html#af3ab1289450908107b058bd4ff85e72f", null ],
    [ "get_gain_l", "classojph_1_1local_1_1sqrt__energy__gains.html#a6a062e558a7f1b3b7a9d161fc3792c67", null ],
    [ "gain_5x3_h", "classojph_1_1local_1_1sqrt__energy__gains.html#a449a759b9fb522be7d40c4e6d60cef69", null ],
    [ "gain_5x3_l", "classojph_1_1local_1_1sqrt__energy__gains.html#a281046171aa0867cda8c0e7029af223c", null ],
    [ "gain_9x7_h", "classojph_1_1local_1_1sqrt__energy__gains.html#af55852f4d52c374c800a831ab06b112b", null ],
    [ "gain_9x7_l", "classojph_1_1local_1_1sqrt__energy__gains.html#a77968e585b7029296e7ffec5306dd2fa", null ]
];