var classojph_1_1param__qcd =
[
    [ "param_qcd", "classojph_1_1param__qcd.html#a3da4ad1a2a658e1f49376ebcd5c305ef", null ],
    [ "set_irrev_quant", "classojph_1_1param__qcd.html#a50e888493f9a68ac2ff15c0d2b4d4ff0", null ],
    [ "state", "classojph_1_1param__qcd.html#a7ae938312696ac2321c4cb1ed7ed4996", null ]
];