var classojph_1_1mem__elastic__allocator =
[
    [ "stores_list", "structojph_1_1mem__elastic__allocator_1_1stores__list.html", "structojph_1_1mem__elastic__allocator_1_1stores__list" ],
    [ "mem_elastic_allocator", "classojph_1_1mem__elastic__allocator.html#a8f6d199dbfc3f8c43c5f48347e0bc816", null ],
    [ "~mem_elastic_allocator", "classojph_1_1mem__elastic__allocator.html#a6d0b30b10a9f58449a7056dc70922348", null ],
    [ "get_buffer", "classojph_1_1mem__elastic__allocator.html#a2b085ab8f2bd193e1d65e09f2de8f7b5", null ],
    [ "chunk_size", "classojph_1_1mem__elastic__allocator.html#a117ae88b45035c8d6535c2ccea661fe2", null ],
    [ "cur_store", "classojph_1_1mem__elastic__allocator.html#ad5cad3c2093ee0c23f15f487e9b2f166", null ],
    [ "store", "classojph_1_1mem__elastic__allocator.html#a4ef124d48f42766562a0e8cb4b034b34", null ],
    [ "total_allocated", "classojph_1_1mem__elastic__allocator.html#ade755c068956e83f59714ffc03ad6275", null ]
];