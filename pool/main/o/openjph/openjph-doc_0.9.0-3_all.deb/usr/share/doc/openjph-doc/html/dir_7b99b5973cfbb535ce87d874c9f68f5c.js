var dir_7b99b5973cfbb535ce87d874c9f68f5c =
[
    [ "ojph_compress.cpp", "ojph__compress_8cpp.html", "ojph__compress_8cpp" ]
];