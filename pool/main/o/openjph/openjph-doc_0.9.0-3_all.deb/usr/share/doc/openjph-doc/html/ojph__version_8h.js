var ojph__version_8h =
[
    [ "OPENJPH_VERSION_MAJOR", "ojph__version_8h.html#aa326c5258b597fb73c8027f3c66c7bb3", null ],
    [ "OPENJPH_VERSION_MINOR", "ojph__version_8h.html#aa8a00aeb9a2cf1bb203958fb0cfc0c18", null ],
    [ "OPENJPH_VERSION_PATCH", "ojph__version_8h.html#a2115c07ef1f29ae16add37e4d3a900c4", null ]
];