var ojph__colour__avx_8cpp =
[
    [ "avx_cnvrt_float_to_si32", "ojph__colour__avx_8cpp.html#a29ccd7f3d29ad4c8ff26c5309bea061c", null ],
    [ "avx_cnvrt_float_to_si32_shftd", "ojph__colour__avx_8cpp.html#acabdb6e7ca68bfb451bd00696e5e1d63", null ],
    [ "avx_cnvrt_si32_to_float", "ojph__colour__avx_8cpp.html#a8e36e31bed66c4b32fbe2f38faeec31f", null ],
    [ "avx_cnvrt_si32_to_float_shftd", "ojph__colour__avx_8cpp.html#a3a84c298147c7b74094de7665fa766d9", null ],
    [ "avx_ict_backward", "ojph__colour__avx_8cpp.html#acb5178d695910b6c93e4ab9671a22bb7", null ],
    [ "avx_ict_forward", "ojph__colour__avx_8cpp.html#a2fa99915af4af57fe20f6c0e10389512", null ]
];