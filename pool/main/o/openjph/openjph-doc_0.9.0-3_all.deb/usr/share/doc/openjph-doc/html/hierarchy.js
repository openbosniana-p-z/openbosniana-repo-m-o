var hierarchy =
[
    [ "ojph::cli_interpreter::arg_inter_base", "structojph_1_1cli__interpreter_1_1arg__inter__base.html", [
      [ "point_interpreter", "structpoint__interpreter.html", null ],
      [ "point_list_interpreter", "structpoint__list__interpreter.html", null ],
      [ "si32_to_bool_list_interpreter", "structsi32__to__bool__list__interpreter.html", null ],
      [ "size_interpreter", "structsize__interpreter.html", null ],
      [ "size_list_interpreter", "structsize__list__interpreter.html", null ],
      [ "ui32_list_interpreter", "structui32__list__interpreter.html", null ],
      [ "ui32_list_interpreter", "structui32__list__interpreter.html", null ]
    ] ],
    [ "ojph::argument", "classojph_1_1argument.html", null ],
    [ "ojph::local::bibo_gains", "classojph_1_1local_1_1bibo__gains.html", null ],
    [ "ojph::local::bit_read_buf", "structojph_1_1local_1_1bit__read__buf.html", null ],
    [ "ojph::local::bit_write_buf", "structojph_1_1local_1_1bit__write__buf.html", null ],
    [ "ojph::cli_interpreter", "classojph_1_1cli__interpreter.html", null ],
    [ "ojph::local::cod_SGcod", "structojph_1_1local_1_1cod__SGcod.html", null ],
    [ "ojph::local::cod_SPcod", "structojph_1_1local_1_1cod__SPcod.html", null ],
    [ "ojph::local::codeblock", "classojph_1_1local_1_1codeblock.html", null ],
    [ "ojph::local::coded_cb_header", "structojph_1_1local_1_1coded__cb__header.html", null ],
    [ "ojph::coded_lists", "structojph_1_1coded__lists.html", null ],
    [ "ojph::codestream", "classojph_1_1codestream.html", null ],
    [ "ojph::local::codestream", "classojph_1_1local_1_1codestream.html", null ],
    [ "ojph::local::CT_CNST", "structojph_1_1local_1_1CT__CNST.html", null ],
    [ "ojph::local::dec_mel_st", "structojph_1_1local_1_1dec__mel__st.html", null ],
    [ "ojph::local::frwd_struct", "structojph_1_1local_1_1frwd__struct.html", null ],
    [ "ojph::image_in_base", "classojph_1_1image__in__base.html", [
      [ "ojph::ppm_in", "classojph_1_1ppm__in.html", null ],
      [ "ojph::yuv_in", "classojph_1_1yuv__in.html", null ]
    ] ],
    [ "ojph::image_out_base", "classojph_1_1image__out__base.html", [
      [ "ojph::ppm_out", "classojph_1_1ppm__out.html", null ],
      [ "ojph::yuv_out", "classojph_1_1yuv__out.html", null ]
    ] ],
    [ "img_info", "structimg__info.html", null ],
    [ "ojph::infile_base", "classojph_1_1infile__base.html", [
      [ "ojph::j2c_infile", "classojph_1_1j2c__infile.html", null ],
      [ "ojph::mem_infile", "classojph_1_1mem__infile.html", null ]
    ] ],
    [ "j2k_struct", "structj2k__struct.html", null ],
    [ "ojph::local::LIFTING_FACTORS", "structojph_1_1local_1_1LIFTING__FACTORS.html", null ],
    [ "ojph::line_buf", "structojph_1_1line__buf.html", null ],
    [ "ojph::local::mel_struct", "structojph_1_1local_1_1mel__struct.html", null ],
    [ "ojph::mem_elastic_allocator", "classojph_1_1mem__elastic__allocator.html", null ],
    [ "ojph::mem_fixed_allocator", "classojph_1_1mem__fixed__allocator.html", null ],
    [ "ojph::message_base", "classojph_1_1message__base.html", [
      [ "ojph::message_error", "classojph_1_1message__error.html", null ],
      [ "ojph::message_info", "classojph_1_1message__info.html", null ],
      [ "ojph::message_warning", "classojph_1_1message__warning.html", null ]
    ] ],
    [ "ojph::local::ms_struct", "structojph_1_1local_1_1ms__struct.html", null ],
    [ "ojph::outfile_base", "classojph_1_1outfile__base.html", [
      [ "ojph::j2c_outfile", "classojph_1_1j2c__outfile.html", null ],
      [ "ojph::mem_outfile", "classojph_1_1mem__outfile.html", null ]
    ] ],
    [ "ojph::local::param_cap", "structojph_1_1local_1_1param__cap.html", null ],
    [ "ojph::local::param_cod", "structojph_1_1local_1_1param__cod.html", null ],
    [ "ojph::param_cod", "classojph_1_1param__cod.html", null ],
    [ "ojph::local::param_qcd", "structojph_1_1local_1_1param__qcd.html", [
      [ "ojph::local::param_qcc", "structojph_1_1local_1_1param__qcc.html", null ]
    ] ],
    [ "ojph::param_qcd", "classojph_1_1param__qcd.html", null ],
    [ "ojph::local::param_siz", "structojph_1_1local_1_1param__siz.html", null ],
    [ "ojph::param_siz", "classojph_1_1param__siz.html", null ],
    [ "ojph::local::param_sot", "structojph_1_1local_1_1param__sot.html", null ],
    [ "ojph::local::param_tlm", "structojph_1_1local_1_1param__tlm.html", null ],
    [ "ojph::point", "structojph_1_1point.html", null ],
    [ "ojph::local::precinct", "structojph_1_1local_1_1precinct.html", null ],
    [ "ojph::rect", "structojph_1_1rect.html", null ],
    [ "ojph::local::resolution", "classojph_1_1local_1_1resolution.html", null ],
    [ "ojph::local::rev_struct", "structojph_1_1local_1_1rev__struct.html", null ],
    [ "ojph::local::siz_comp_info", "structojph_1_1local_1_1siz__comp__info.html", null ],
    [ "ojph::size", "structojph_1_1size.html", null ],
    [ "ojph::local::sqrt_energy_gains", "classojph_1_1local_1_1sqrt__energy__gains.html", null ],
    [ "ojph::mem_elastic_allocator::stores_list", "structojph_1_1mem__elastic__allocator_1_1stores__list.html", null ],
    [ "ojph::local::subband", "classojph_1_1local_1_1subband.html", null ],
    [ "ojph::local::tag_tree", "structojph_1_1local_1_1tag__tree.html", null ],
    [ "ojph::local::tile", "classojph_1_1local_1_1tile.html", null ],
    [ "ojph::local::tile_comp", "classojph_1_1local_1_1tile__comp.html", null ],
    [ "ojph::local::param_tlm::Ttlm_Ptlm_pair", "structojph_1_1local_1_1param__tlm_1_1Ttlm__Ptlm__pair.html", null ],
    [ "ojph::local::vlc_struct", "structojph_1_1local_1_1vlc__struct.html", null ]
];