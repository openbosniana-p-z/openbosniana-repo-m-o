var ojph__block__decoder_8h =
[
    [ "ojph_decode_codeblock", "ojph__block__decoder_8h.html#ac7fa5de1e5b3387aef20afe94607c059", null ],
    [ "ojph_decode_codeblock_ssse3", "ojph__block__decoder_8h.html#a29a74571b35e23c7aef54b102b8bba09", null ],
    [ "ojph_decode_codeblock_wasm", "ojph__block__decoder_8h.html#a026df29c190f626d24b399ddf37d388a", null ]
];