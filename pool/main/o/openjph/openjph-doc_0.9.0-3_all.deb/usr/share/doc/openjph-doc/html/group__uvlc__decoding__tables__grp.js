var group__uvlc__decoding__tables__grp =
[
    [ "uvlc_init_tables", "group__uvlc__decoding__tables__grp.html#gab40d647a815cba166f28eee8b703d1e1", null ],
    [ "uvlc_tables_initialized", "group__uvlc__decoding__tables__grp.html#ga7988800540a7aa06363e4b1b28ccdf7d", null ],
    [ "uvlc_tbl0", "group__uvlc__decoding__tables__grp.html#gac57518f95865823d3bd45cd38b3cafcb", null ],
    [ "uvlc_tbl1", "group__uvlc__decoding__tables__grp.html#gae6b0ec4c23a42c5d23c5cccb0db53ec5", null ]
];