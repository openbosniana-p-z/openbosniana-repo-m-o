var classojph_1_1j2c__infile =
[
    [ "j2c_infile", "classojph_1_1j2c__infile.html#a95371f63b9816aa9eed9ddcdcea2cb24", null ],
    [ "~j2c_infile", "classojph_1_1j2c__infile.html#a14ec734b70b8512d86fdf0c725086e2b", null ],
    [ "close", "classojph_1_1j2c__infile.html#af09eaf032c486cc4d3083c1558bab45a", null ],
    [ "eof", "classojph_1_1j2c__infile.html#afc1cbc872e56ef4c7746c47ce4ae3738", null ],
    [ "open", "classojph_1_1j2c__infile.html#a35b6fa41c9e2b1e20a977deb9f88051e", null ],
    [ "read", "classojph_1_1j2c__infile.html#aab58b4a82eb30b44161dbbf4400f8f8c", null ],
    [ "seek", "classojph_1_1j2c__infile.html#aa8b5d21466647c4cc643b6a40a7a0fa8", null ],
    [ "tell", "classojph_1_1j2c__infile.html#a9ea3056b481a4f2d0bd9066462cfe93a", null ],
    [ "fh", "classojph_1_1j2c__infile.html#a84c5c3e4c5d922fbad516e254f1461b9", null ]
];