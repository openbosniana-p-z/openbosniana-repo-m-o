var ojph__transform__wasm_8cpp =
[
    [ "wasm_irrev_horz_wvlt_bwd_tx", "ojph__transform__wasm_8cpp.html#a269ac83b6b1044a4a26acf69a9f36a48", null ],
    [ "wasm_irrev_horz_wvlt_fwd_tx", "ojph__transform__wasm_8cpp.html#ae2f71e3bd1611e3cd046ab91091a64f7", null ],
    [ "wasm_irrev_vert_wvlt_K", "ojph__transform__wasm_8cpp.html#a3b3501a7765f1c0036cd2d9caabb0ad2", null ],
    [ "wasm_irrev_vert_wvlt_step", "ojph__transform__wasm_8cpp.html#aa8a9566298df7e1d787b53a30f86adb0", null ],
    [ "wasm_rev_horz_wvlt_bwd_tx", "ojph__transform__wasm_8cpp.html#a02dd6f46905178ed8da9336ced499a02", null ],
    [ "wasm_rev_horz_wvlt_fwd_tx", "ojph__transform__wasm_8cpp.html#adaddf33c9f6d8a7cabc86c7dca78efa3", null ],
    [ "wasm_rev_vert_wvlt_bwd_predict", "ojph__transform__wasm_8cpp.html#a1ead3984cf0229c306152ef83010fd44", null ],
    [ "wasm_rev_vert_wvlt_bwd_update", "ojph__transform__wasm_8cpp.html#affc5a1923319c96263ac133341e24b6f", null ],
    [ "wasm_rev_vert_wvlt_fwd_predict", "ojph__transform__wasm_8cpp.html#ae49fb1358aeba8799f9a87740f872121", null ],
    [ "wasm_rev_vert_wvlt_fwd_update", "ojph__transform__wasm_8cpp.html#a1b4c7094222f1b2fc9b11fe95715a222", null ]
];