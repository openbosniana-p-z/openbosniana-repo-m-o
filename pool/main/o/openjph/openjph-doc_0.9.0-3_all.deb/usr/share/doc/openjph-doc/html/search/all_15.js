var searchData=
[
  ['u16_5fspqcd_837',['u16_SPqcd',['../structojph_1_1local_1_1param__qcd.html#a72767d2c0d57e13cd1aafd43ab6244ca',1,'ojph::local::param_qcd']]],
  ['u8_5fspqcd_838',['u8_SPqcd',['../structojph_1_1local_1_1param__qcd.html#a9b02e949d2d42528d73b78538748dcc8',1,'ojph::local::param_qcd']]],
  ['ui16_839',['ui16',['../namespaceojph.html#a833feb6951f040292369227c0c523a39',1,'ojph']]],
  ['ui32_840',['ui32',['../namespaceojph.html#aecb99bd81b3e138430e0bbb0f85edde4',1,'ojph']]],
  ['ui32_5flist_5finterpreter_841',['ui32_list_interpreter',['../structui32__list__interpreter.html#a760a541addcf2f38807e89017ec567f1',1,'ui32_list_interpreter::ui32_list_interpreter(const int max_num_elements, int &amp;num_elements, ojph::ui32 *list)'],['../structui32__list__interpreter.html#a736fa8f2d6607075d2b2a75ec6181be1',1,'ui32_list_interpreter::ui32_list_interpreter(const ojph::ui32 max_num_elements, ojph::ui32 &amp;num_elements, ojph::ui32 *list)'],['../structui32__list__interpreter.html',1,'ui32_list_interpreter']]],
  ['ui32list_842',['ui32list',['../structui32__list__interpreter.html#ae73c89f79eed1e3ffef35f6f205d993a',1,'ui32_list_interpreter']]],
  ['ui64_843',['ui64',['../namespaceojph.html#a61420cef650cde7cd26991a9f1bf5d36',1,'ojph']]],
  ['ui8_844',['ui8',['../namespaceojph.html#aeeb62f8ee0306cee97944c27b9effaee',1,'ojph']]],
  ['ulvc_5fcwd_5fpre_845',['ulvc_cwd_pre',['../namespaceojph_1_1local.html#aa709759871afb0580f83c3ed8807a467',1,'ojph::local']]],
  ['ulvc_5fcwd_5fpre_5flen_846',['ulvc_cwd_pre_len',['../namespaceojph_1_1local.html#aa18809268d3039d5b42f9b0ede74239f',1,'ojph::local']]],
  ['ulvc_5fcwd_5fsuf_847',['ulvc_cwd_suf',['../namespaceojph_1_1local.html#a12ad6375603e40e86de073d9975510eb',1,'ojph::local']]],
  ['ulvc_5fcwd_5fsuf_5flen_848',['ulvc_cwd_suf_len',['../namespaceojph_1_1local.html#a159ebdd71a4ae7c4034f45b5fdfc7ea5',1,'ojph::local']]],
  ['undefined_849',['UNDEFINED',['../psnr__pae_8cpp.html#af7570c724df75312224ca4607b08b7d5a605159e8a4c32319fd69b5d151369d93',1,'psnr_pae.cpp']]],
  ['unstuff_850',['unstuff',['../structojph_1_1local_1_1frwd__struct.html#ab25ccc13cccf80c6b2a1d99ec7fbff61',1,'ojph::local::frwd_struct::unstuff()'],['../structojph_1_1local_1_1rev__struct.html#abcd328267d8fb9f4c24c9fd79ee335bd',1,'ojph::local::rev_struct::unstuff()'],['../structojph_1_1local_1_1dec__mel__st.html#a19f76761a5de2981379cb406145454d7',1,'ojph::local::dec_mel_st::unstuff()'],['../structojph_1_1local_1_1bit__read__buf.html#a4bb4f77ea805bdf6c2d1497618829adf',1,'ojph::local::bit_read_buf::unstuff()']]],
  ['used_5fbits_851',['used_bits',['../structojph_1_1local_1_1vlc__struct.html#af0bf0f4feefa6a4aad1d005d25f911eb',1,'ojph::local::vlc_struct::used_bits()'],['../structojph_1_1local_1_1ms__struct.html#a8f9854f32a370e5dc7d7d3bc858374a7',1,'ojph::local::ms_struct::used_bits()']]],
  ['used_5fqcc_5ffields_852',['used_qcc_fields',['../classojph_1_1local_1_1codestream.html#a3e3fa22767a6b784f672ead9d293c78e',1,'ojph::local::codestream']]],
  ['uses_5feph_853',['uses_eph',['../structojph_1_1local_1_1precinct.html#ab5bd5ce20c9b7d2c41bcca74206bdbf0',1,'ojph::local::precinct']]],
  ['uvlc_5finit_5ftables_854',['uvlc_init_tables',['../group__uvlc__decoding__tables__grp.html#gab40d647a815cba166f28eee8b703d1e1',1,'ojph::local::uvlc_init_tables()'],['../namespaceojph_1_1local.html#ab40d647a815cba166f28eee8b703d1e1',1,'ojph::local::uvlc_init_tables()']]],
  ['uvlc_5ftables_5finitialized_855',['uvlc_tables_initialized',['../group__uvlc__decoding__tables__grp.html#ga7988800540a7aa06363e4b1b28ccdf7d',1,'ojph::local::uvlc_tables_initialized()'],['../namespaceojph_1_1local.html#a7988800540a7aa06363e4b1b28ccdf7d',1,'ojph::local::uvlc_tables_initialized()']]],
  ['uvlc_5ftbl0_856',['uvlc_tbl0',['../group__uvlc__decoding__tables__grp.html#gac57518f95865823d3bd45cd38b3cafcb',1,'ojph::local']]],
  ['uvlc_5ftbl1_857',['uvlc_tbl1',['../group__uvlc__decoding__tables__grp.html#gae6b0ec4c23a42c5d23c5cccb0db53ec5',1,'ojph::local']]]
];
