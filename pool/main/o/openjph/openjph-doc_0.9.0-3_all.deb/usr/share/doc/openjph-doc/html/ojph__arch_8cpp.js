var ojph__arch_8cpp =
[
    [ "get_cpu_ext_level", "ojph__arch_8cpp.html#abdb0c49125bca6f38418a4b4cc89771e", null ],
    [ "init_cpu_ext_level", "ojph__arch_8cpp.html#a001c3c6929d696d0b1215b5beaf30ee6", null ],
    [ "read_xcr", "ojph__arch_8cpp.html#a9e1ed8248ede6a512da03fdd96363f41", null ],
    [ "run_cpuid", "ojph__arch_8cpp.html#af560e2cd7828cf37c89781ddec58c0eb", null ],
    [ "cpu_level", "ojph__arch_8cpp.html#adfd2ce5f486cb00ba1a8fe3a14e4893e", null ],
    [ "cpu_level_initialized", "ojph__arch_8cpp.html#aec7fb7497795b20d1f488c957d0b35dd", null ]
];