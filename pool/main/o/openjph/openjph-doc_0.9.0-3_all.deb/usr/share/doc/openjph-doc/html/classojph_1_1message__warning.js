var classojph_1_1message__warning =
[
    [ "operator()", "classojph_1_1message__warning.html#ae0394b9287b3e794c430d6abdd864fa3", null ]
];