var ojph__message_8cpp =
[
    [ "configure_error", "ojph__message_8cpp.html#a4051c29bb0bb05a6c60267639dfd709b", null ],
    [ "configure_info", "ojph__message_8cpp.html#ac2a52e5684abfeba4328cb2a99935b03", null ],
    [ "configure_warning", "ojph__message_8cpp.html#a8fa10116eb30216e1d098fe86a00666f", null ],
    [ "get_error", "ojph__message_8cpp.html#a1e82fbd7b1e96697aae76bc3cf708ba0", null ],
    [ "get_info", "ojph__message_8cpp.html#abf90019ada9bb14b361ffbcf22068b5f", null ],
    [ "get_warning", "ojph__message_8cpp.html#a6ae05eaf57529fc66f31c8dc1f9e0f6e", null ],
    [ "set_error_stream", "ojph__message_8cpp.html#a2517c7578fc47ea1e279ed62a9c647d4", null ],
    [ "set_info_stream", "ojph__message_8cpp.html#a816c1c0650fba79371b52cd681962096", null ],
    [ "set_warning_stream", "ojph__message_8cpp.html#a800c71aa3ad400e783249112900831b1", null ],
    [ "error", "ojph__message_8cpp.html#adbc837749ecdf473fd99aa658dd4c952", null ],
    [ "error_stream", "ojph__message_8cpp.html#ae3003f548d3c373d02fdd42b53105ea5", null ],
    [ "info", "ojph__message_8cpp.html#a31dffe2a8a91b07ec1aee66d2a2dfbc7", null ],
    [ "info_stream", "ojph__message_8cpp.html#a5f437cbf5286c1d192284f3e4cf13a6e", null ],
    [ "local_error", "ojph__message_8cpp.html#a8e710a26e11f405bb99c29c914612754", null ],
    [ "local_info", "ojph__message_8cpp.html#af27bf63e53a0b0b3c2cd57a6909ab514", null ],
    [ "local_warn", "ojph__message_8cpp.html#a22fae511a1dd28ef62251dbff1b45a88", null ],
    [ "warn", "ojph__message_8cpp.html#a11e0cc8b499cc043e1edb80183cd5de5", null ],
    [ "warning_stream", "ojph__message_8cpp.html#a80657f9731e99e2689af59d0294da889", null ]
];