var ojph__block__encoder_8cpp =
[
    [ "mel_struct", "structojph_1_1local_1_1mel__struct.html", "structojph_1_1local_1_1mel__struct" ],
    [ "vlc_struct", "structojph_1_1local_1_1vlc__struct.html", "structojph_1_1local_1_1vlc__struct" ],
    [ "ms_struct", "structojph_1_1local_1_1ms__struct.html", "structojph_1_1local_1_1ms__struct" ],
    [ "mel_emit_bit", "ojph__block__encoder_8cpp.html#ab729e55df17955437f7b9b10268a6cb9", null ],
    [ "mel_encode", "ojph__block__encoder_8cpp.html#ab709771272683f6199a718d4f23915b5", null ],
    [ "mel_init", "ojph__block__encoder_8cpp.html#abbd897c21245749d0bc7362f0688cbc8", null ],
    [ "ms_encode", "ojph__block__encoder_8cpp.html#a969d15af86b9f54c5672277cceed728c", null ],
    [ "ms_init", "ojph__block__encoder_8cpp.html#a88a60162465c71a59ea0169929ed0d1c", null ],
    [ "ms_terminate", "ojph__block__encoder_8cpp.html#a021ae915e9a142830fc8ed598741c668", null ],
    [ "ojph_encode_codeblock", "ojph__block__encoder_8cpp.html#ae0fe6609fc7c30a16cdf5b6821b7856f", null ],
    [ "terminate_mel_vlc", "ojph__block__encoder_8cpp.html#a6e4c67796898771d8fc6ce43fd0fe690", null ],
    [ "uvlc_init_tables", "ojph__block__encoder_8cpp.html#ab40d647a815cba166f28eee8b703d1e1", null ],
    [ "vlc_encode", "ojph__block__encoder_8cpp.html#a4a6520b41cc7d6430497cd9b044a452e", null ],
    [ "vlc_init", "ojph__block__encoder_8cpp.html#ae6be7d4244c4698fe3db76f3b76a2df1", null ],
    [ "vlc_init_tables", "ojph__block__encoder_8cpp.html#a2321384a030e92d82c71336117235310", null ],
    [ "ulvc_cwd_pre", "ojph__block__encoder_8cpp.html#aa709759871afb0580f83c3ed8807a467", null ],
    [ "ulvc_cwd_pre_len", "ojph__block__encoder_8cpp.html#aa18809268d3039d5b42f9b0ede74239f", null ],
    [ "ulvc_cwd_suf", "ojph__block__encoder_8cpp.html#a12ad6375603e40e86de073d9975510eb", null ],
    [ "ulvc_cwd_suf_len", "ojph__block__encoder_8cpp.html#a159ebdd71a4ae7c4034f45b5fdfc7ea5", null ],
    [ "uvlc_tables_initialized", "ojph__block__encoder_8cpp.html#a7988800540a7aa06363e4b1b28ccdf7d", null ],
    [ "vlc_tables_initialized", "ojph__block__encoder_8cpp.html#a155222ada46b7ba970a60c67b1c99ed0", null ]
];