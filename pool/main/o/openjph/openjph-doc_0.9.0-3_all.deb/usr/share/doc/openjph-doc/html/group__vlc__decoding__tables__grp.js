var group__vlc__decoding__tables__grp =
[
    [ "vlc_init_tables", "group__vlc__decoding__tables__grp.html#ga2321384a030e92d82c71336117235310", null ],
    [ "vlc_tables_initialized", "group__vlc__decoding__tables__grp.html#ga155222ada46b7ba970a60c67b1c99ed0", null ],
    [ "vlc_tbl0", "group__vlc__decoding__tables__grp.html#ga896decad4e54a6aa149eb52f38b1f773", null ],
    [ "vlc_tbl1", "group__vlc__decoding__tables__grp.html#ga3699f20545c8da9d965101b6f918a267", null ]
];