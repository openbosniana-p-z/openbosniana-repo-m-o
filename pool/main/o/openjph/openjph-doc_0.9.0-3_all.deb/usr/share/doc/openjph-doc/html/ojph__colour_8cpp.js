var ojph__colour_8cpp =
[
    [ "gen_cnvrt_float_to_si32", "ojph__colour_8cpp.html#aa4139cc91bfbeb13196662eefa6353e6", null ],
    [ "gen_cnvrt_float_to_si32_shftd", "ojph__colour_8cpp.html#aadb1e77047cfd59cf48ce594761f2e97", null ],
    [ "gen_cnvrt_si32_to_float", "ojph__colour_8cpp.html#a55b8c7b0489c43558599191a4d4445a1", null ],
    [ "gen_cnvrt_si32_to_float_shftd", "ojph__colour_8cpp.html#ae3da79798be1b8cd568dd3485a9ec215", null ],
    [ "gen_cnvrt_si32_to_si32_shftd", "ojph__colour_8cpp.html#a7aa76d7c2a239fb015adce6d3c403ca7", null ],
    [ "gen_ict_backward", "ojph__colour_8cpp.html#aa43fa8540270c2689280888c9373bd3a", null ],
    [ "gen_ict_forward", "ojph__colour_8cpp.html#a5f7ecfc08ca4d964eb1b133572652e71", null ],
    [ "gen_rct_backward", "ojph__colour_8cpp.html#a47479c6d6c1957d2f9c344d8fe9618d3", null ],
    [ "gen_rct_forward", "ojph__colour_8cpp.html#ac62a0a9aad2e1ec53bd558c5fd322619", null ],
    [ "init_colour_transform_functions", "ojph__colour_8cpp.html#a5eb99c56675edbc7044ec7bc7513bf59", null ],
    [ "cnvrt_float_to_si32", "ojph__colour_8cpp.html#a0397fb0d241ebc3c21fd2dd4e6d00448", null ],
    [ "cnvrt_float_to_si32_shftd", "ojph__colour_8cpp.html#a694083686176bed23ff53fc0970ea202", null ],
    [ "cnvrt_si32_to_float", "ojph__colour_8cpp.html#a990a509f8c79e7a136b83a63ebd91a26", null ],
    [ "cnvrt_si32_to_float_shftd", "ojph__colour_8cpp.html#a2a52ef517e2127b71bbfc99d410ed32f", null ],
    [ "cnvrt_si32_to_si32_shftd", "ojph__colour_8cpp.html#a37bc7ad821db7430c80095f33e7a4fee", null ],
    [ "colour_transform_functions_initialized", "ojph__colour_8cpp.html#a8ec62e59d33dfaf1faa97790312e6f50", null ],
    [ "ict_backward", "ojph__colour_8cpp.html#a442c487e6888efaa0b8a4c61d0460983", null ],
    [ "ict_forward", "ojph__colour_8cpp.html#a2bec3e474daaadb8fe9b2ccf8720bb2c", null ],
    [ "rct_backward", "ojph__colour_8cpp.html#a4e022dfffb315d45455f7823fc8fcfe8", null ],
    [ "rct_forward", "ojph__colour_8cpp.html#aa9cbc46079238a14a91bab89d9a6e08c", null ]
];