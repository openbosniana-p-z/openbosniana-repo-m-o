var ojph__colour__sse2_8cpp =
[
    [ "sse2_cnvrt_float_to_si32", "ojph__colour__sse2_8cpp.html#ace15e1117883dc8205a6264a77d25116", null ],
    [ "sse2_cnvrt_float_to_si32_shftd", "ojph__colour__sse2_8cpp.html#a66abe760a08277b7b35a2a744b04beb2", null ],
    [ "sse2_cnvrt_si32_to_si32_shftd", "ojph__colour__sse2_8cpp.html#a7886cc128afcba97bcea7d394889a2ae", null ],
    [ "sse2_rct_backward", "ojph__colour__sse2_8cpp.html#aa5387c63b62d7bef6224e6fcd1712101", null ],
    [ "sse2_rct_forward", "ojph__colour__sse2_8cpp.html#a600f84ffce752bed4b7b6a8b14aa984c", null ]
];