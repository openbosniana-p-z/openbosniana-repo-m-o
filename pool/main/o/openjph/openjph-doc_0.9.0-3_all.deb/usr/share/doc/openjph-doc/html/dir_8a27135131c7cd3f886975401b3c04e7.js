var dir_8a27135131c7cd3f886975401b3c04e7 =
[
    [ "ojph_codestream.cpp", "ojph__codestream_8cpp.html", "ojph__codestream_8cpp" ],
    [ "ojph_codestream_avx.cpp", "ojph__codestream__avx_8cpp.html", "ojph__codestream__avx_8cpp" ],
    [ "ojph_codestream_avx2.cpp", "ojph__codestream__avx2_8cpp.html", "ojph__codestream__avx2_8cpp" ],
    [ "ojph_codestream_local.h", "ojph__codestream__local_8h.html", "ojph__codestream__local_8h" ],
    [ "ojph_codestream_sse.cpp", "ojph__codestream__sse_8cpp.html", "ojph__codestream__sse_8cpp" ],
    [ "ojph_codestream_sse2.cpp", "ojph__codestream__sse2_8cpp.html", "ojph__codestream__sse2_8cpp" ],
    [ "ojph_codestream_wasm.cpp", "ojph__codestream__wasm_8cpp.html", "ojph__codestream__wasm_8cpp" ],
    [ "ojph_params.cpp", "ojph__params_8cpp.html", "ojph__params_8cpp" ],
    [ "ojph_params_local.h", "ojph__params__local_8h.html", "ojph__params__local_8h" ]
];