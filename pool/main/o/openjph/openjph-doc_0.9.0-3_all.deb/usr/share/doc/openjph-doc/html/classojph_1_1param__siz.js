var classojph_1_1param__siz =
[
    [ "param_siz", "classojph_1_1param__siz.html#a88b16cb44097bef95118f636ff56b8be", null ],
    [ "get_bit_depth", "classojph_1_1param__siz.html#a529ad841487b6a34bfeccdf8b22a255a", null ],
    [ "get_downsampling", "classojph_1_1param__siz.html#a9b3c0a7f4a318e643ad991fb57f00738", null ],
    [ "get_image_extent", "classojph_1_1param__siz.html#a257ab82936b26ec92ca18536f3b69792", null ],
    [ "get_image_offset", "classojph_1_1param__siz.html#a61cee8ae93f09f7ad4df7201c64982ca", null ],
    [ "get_num_components", "classojph_1_1param__siz.html#aee7c01a35cbdc45120ec5ddffc8bcbb5", null ],
    [ "get_recon_height", "classojph_1_1param__siz.html#a975b4ef8fd706e03a3f24d1dd3ccbebc", null ],
    [ "get_recon_width", "classojph_1_1param__siz.html#ad73451cee4751b1fb37b9b30dca40f3e", null ],
    [ "get_tile_offset", "classojph_1_1param__siz.html#ad28ac11ca2fcccbeae2251b5cf1f44ad", null ],
    [ "get_tile_size", "classojph_1_1param__siz.html#a957a7a466c5860d29192d47ce813efb1", null ],
    [ "is_signed", "classojph_1_1param__siz.html#aee4a6fc0f61f2999c2d853dc4e46f9e6", null ],
    [ "set_component", "classojph_1_1param__siz.html#a2d29cee7567eac4079e7b355c666c39f", null ],
    [ "set_image_extent", "classojph_1_1param__siz.html#ad1de28c3246bf9497dd28f6842796bf7", null ],
    [ "set_image_offset", "classojph_1_1param__siz.html#a65eb4c9c6d22e94cb1a5f19e52032872", null ],
    [ "set_num_components", "classojph_1_1param__siz.html#a4088fba78516153a27329e38e6656754", null ],
    [ "set_tile_offset", "classojph_1_1param__siz.html#a56ccea7af0f9ffd747f8edef2b42d332", null ],
    [ "set_tile_size", "classojph_1_1param__siz.html#a19ce873c2b9294479c703d4b724a454e", null ],
    [ "state", "classojph_1_1param__siz.html#a634887277b198b1dae6e8f2d4363255b", null ]
];