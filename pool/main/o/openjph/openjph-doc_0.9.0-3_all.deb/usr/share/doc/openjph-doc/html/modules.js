var modules =
[
    [ "VLC decoding tables", "group__vlc__decoding__tables__grp.html", "group__vlc__decoding__tables__grp" ],
    [ "VLC decoding tables", "group__uvlc__decoding__tables__grp.html", "group__uvlc__decoding__tables__grp" ]
];