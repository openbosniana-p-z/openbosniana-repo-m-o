var ojph__transform__avx2_8cpp =
[
    [ "avx2_rev_horz_wvlt_bwd_tx", "ojph__transform__avx2_8cpp.html#ab9a63b8ff7a20b045512c59e6a1ad1ae", null ],
    [ "avx2_rev_horz_wvlt_fwd_tx", "ojph__transform__avx2_8cpp.html#a18274c6cbabc24545659080d5765cc7f", null ],
    [ "avx2_rev_vert_wvlt_bwd_predict", "ojph__transform__avx2_8cpp.html#a5783386568404b51bf087cd6c00d6b73", null ],
    [ "avx2_rev_vert_wvlt_bwd_update", "ojph__transform__avx2_8cpp.html#af7a3ea45641a349cc295e8cf10394f64", null ],
    [ "avx2_rev_vert_wvlt_fwd_predict", "ojph__transform__avx2_8cpp.html#a241171e6bea118fd2ab1b9bf291e6865", null ],
    [ "avx2_rev_vert_wvlt_fwd_update", "ojph__transform__avx2_8cpp.html#a02ff0a8e3446361d919c764ecacf06a3", null ]
];