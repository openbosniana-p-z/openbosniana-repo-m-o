var ojph__message_8h =
[
    [ "message_base", "classojph_1_1message__base.html", "classojph_1_1message__base" ],
    [ "message_info", "classojph_1_1message__info.html", "classojph_1_1message__info" ],
    [ "message_warning", "classojph_1_1message__warning.html", "classojph_1_1message__warning" ],
    [ "message_error", "classojph_1_1message__error.html", "classojph_1_1message__error" ],
    [ "__OJPHFILE__", "ojph__message_8h.html#a594a9eea4d979bdf573635cb77cecc62", null ],
    [ "OJPH_ERROR", "ojph__message_8h.html#ae4546abbd8d73f3466a11084e562f099", null ],
    [ "OJPH_INFO", "ojph__message_8h.html#a83fc5ef7eace1ea8edd8bc89be67d407", null ],
    [ "OJPH_WARN", "ojph__message_8h.html#afa8368270d0003264e2f80353a7c4563", null ],
    [ "OJPH_MSG_LEVEL", "ojph__message_8h.html#a7d8d1706fd2535431e0c55e243ff80b0", [
      [ "NO_MSG", "ojph__message_8h.html#a7d8d1706fd2535431e0c55e243ff80b0ab6aa6d418185f69216e7171fbfdb1f32", null ],
      [ "INFO", "ojph__message_8h.html#a7d8d1706fd2535431e0c55e243ff80b0aac4a231e034f7a2f01825399453b5a10", null ],
      [ "WARN", "ojph__message_8h.html#a7d8d1706fd2535431e0c55e243ff80b0a1cf29c92ced6405e62ed71779131a511", null ],
      [ "ERROR", "ojph__message_8h.html#a7d8d1706fd2535431e0c55e243ff80b0a0dc9e7e3ca5beea50c43bc617a94569d", null ]
    ] ],
    [ "configure_error", "ojph__message_8h.html#a4051c29bb0bb05a6c60267639dfd709b", null ],
    [ "configure_info", "ojph__message_8h.html#ac2a52e5684abfeba4328cb2a99935b03", null ],
    [ "configure_warning", "ojph__message_8h.html#a8fa10116eb30216e1d098fe86a00666f", null ],
    [ "get_error", "ojph__message_8h.html#a1e82fbd7b1e96697aae76bc3cf708ba0", null ],
    [ "get_info", "ojph__message_8h.html#abf90019ada9bb14b361ffbcf22068b5f", null ],
    [ "get_warning", "ojph__message_8h.html#a6ae05eaf57529fc66f31c8dc1f9e0f6e", null ],
    [ "set_error_stream", "ojph__message_8h.html#a2517c7578fc47ea1e279ed62a9c647d4", null ],
    [ "set_info_stream", "ojph__message_8h.html#a816c1c0650fba79371b52cd681962096", null ],
    [ "set_warning_stream", "ojph__message_8h.html#a800c71aa3ad400e783249112900831b1", null ]
];