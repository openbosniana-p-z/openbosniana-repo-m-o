var dir_ff9752c3c2b312b535721929c9e19a75 =
[
    [ "ojph_colour.cpp", "ojph__colour_8cpp.html", "ojph__colour_8cpp" ],
    [ "ojph_colour.h", "ojph__colour_8h.html", "ojph__colour_8h" ],
    [ "ojph_colour_avx.cpp", "ojph__colour__avx_8cpp.html", "ojph__colour__avx_8cpp" ],
    [ "ojph_colour_avx2.cpp", "ojph__colour__avx2_8cpp.html", "ojph__colour__avx2_8cpp" ],
    [ "ojph_colour_local.h", "ojph__colour__local_8h.html", "ojph__colour__local_8h" ],
    [ "ojph_colour_sse.cpp", "ojph__colour__sse_8cpp.html", "ojph__colour__sse_8cpp" ],
    [ "ojph_colour_sse2.cpp", "ojph__colour__sse2_8cpp.html", "ojph__colour__sse2_8cpp" ],
    [ "ojph_colour_wasm.cpp", "ojph__colour__wasm_8cpp.html", "ojph__colour__wasm_8cpp" ],
    [ "ojph_transform.cpp", "ojph__transform_8cpp.html", "ojph__transform_8cpp" ],
    [ "ojph_transform.h", "ojph__transform_8h.html", "ojph__transform_8h" ],
    [ "ojph_transform_avx.cpp", "ojph__transform__avx_8cpp.html", "ojph__transform__avx_8cpp" ],
    [ "ojph_transform_avx2.cpp", "ojph__transform__avx2_8cpp.html", "ojph__transform__avx2_8cpp" ],
    [ "ojph_transform_local.h", "ojph__transform__local_8h.html", "ojph__transform__local_8h" ],
    [ "ojph_transform_sse.cpp", "ojph__transform__sse_8cpp.html", "ojph__transform__sse_8cpp" ],
    [ "ojph_transform_sse2.cpp", "ojph__transform__sse2_8cpp.html", "ojph__transform__sse2_8cpp" ],
    [ "ojph_transform_wasm.cpp", "ojph__transform__wasm_8cpp.html", "ojph__transform__wasm_8cpp" ]
];