var classojph_1_1param__cod =
[
    [ "param_cod", "classojph_1_1param__cod.html#aa244ffc61ff5b7e636a4ecce25e8c7de", null ],
    [ "get_block_dims", "classojph_1_1param__cod.html#a13748dcdd2bee074cf9ce00daf123cf5", null ],
    [ "get_block_vertical_causality", "classojph_1_1param__cod.html#accd01efa6f2c967df1902d8d7861d286", null ],
    [ "get_log_block_dims", "classojph_1_1param__cod.html#a7798d3316070dc877b3e89eebdc6c09c", null ],
    [ "get_log_precinct_size", "classojph_1_1param__cod.html#ade03f431f471433a707e896af631a2ee", null ],
    [ "get_num_decompositions", "classojph_1_1param__cod.html#a6bd57aa1bf609d2ded4bb5d7fc3cdbd8", null ],
    [ "get_num_layers", "classojph_1_1param__cod.html#ade90f85513852343eba9942fa9f7703d", null ],
    [ "get_precinct_size", "classojph_1_1param__cod.html#a810df4917f68a30a2534202ca9bea002", null ],
    [ "get_progression_order", "classojph_1_1param__cod.html#a1d8cde91682a1e85422c31d4efae453e", null ],
    [ "get_progression_order_as_string", "classojph_1_1param__cod.html#a8838656b09981daf72bc08288d65fb81", null ],
    [ "is_reversible", "classojph_1_1param__cod.html#ab6511c5bb08569d08197b987af7a556f", null ],
    [ "is_using_color_transform", "classojph_1_1param__cod.html#a2041b205847625a73e7c786596594a9f", null ],
    [ "packets_may_use_sop", "classojph_1_1param__cod.html#a7991ac5b15361d99f8c4cd3752eeb8ed", null ],
    [ "packets_use_eph", "classojph_1_1param__cod.html#a9577ca99a914a62683194e7c8a008a17", null ],
    [ "set_block_dims", "classojph_1_1param__cod.html#acd5a9f1ac1df062b9cb11a3bc7affab2", null ],
    [ "set_color_transform", "classojph_1_1param__cod.html#af69926e7b1ecfa2fcc861cb209dc5b1b", null ],
    [ "set_num_decomposition", "classojph_1_1param__cod.html#a42e3d73afd260e0d5fe118a34fa4c4a1", null ],
    [ "set_precinct_size", "classojph_1_1param__cod.html#a8a5aa60787290b083c87204865fa687a", null ],
    [ "set_progression_order", "classojph_1_1param__cod.html#acc63dececf30eec9744936885e222e02", null ],
    [ "set_reversible", "classojph_1_1param__cod.html#af87a46202d5268759ccf67caa0f43359", null ],
    [ "state", "classojph_1_1param__cod.html#ab500e37bdaec3e74ec6e5c43532a1030", null ]
];