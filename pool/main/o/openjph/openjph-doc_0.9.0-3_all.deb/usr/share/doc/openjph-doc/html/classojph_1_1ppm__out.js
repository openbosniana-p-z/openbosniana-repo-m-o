var classojph_1_1ppm__out =
[
    [ "ppm_out", "classojph_1_1ppm__out.html#a096f2d18899fa7b204084d5d28ba2b15", null ],
    [ "~ppm_out", "classojph_1_1ppm__out.html#ab62564bb5f1b6521e4c1c9c9c95f67f1", null ],
    [ "close", "classojph_1_1ppm__out.html#a2fe5c92e67edee355bfc190acd55a279", null ],
    [ "configure", "classojph_1_1ppm__out.html#ad415021edf2b07dddc36543e0376c4ef", null ],
    [ "open", "classojph_1_1ppm__out.html#a37f9dc23b1f36070ddf3bb8e3ca8d5fe", null ],
    [ "write", "classojph_1_1ppm__out.html#a3c6fd84eb97dd8dc960c75ec030a30dc", null ],
    [ "bit_depth", "classojph_1_1ppm__out.html#a62bc1be82ef64410fd5d4bfbc4120f31", null ],
    [ "buffer", "classojph_1_1ppm__out.html#af696a5cbce53769081e105780455e071", null ],
    [ "buffer_size", "classojph_1_1ppm__out.html#ad6b7f3c03f25378456d92d5cfad03ad7", null ],
    [ "bytes_per_line", "classojph_1_1ppm__out.html#a6a0509c9959c156b55636fe16951c6a0", null ],
    [ "bytes_per_sample", "classojph_1_1ppm__out.html#a6df94636e8648a26a68e8aa58a931caa", null ],
    [ "converter", "classojph_1_1ppm__out.html#ab7f4cd534fcd8604dccef2593c8dc186", null ],
    [ "cur_line", "classojph_1_1ppm__out.html#a3cd88183d01545bf4771e5ddc14009c1", null ],
    [ "fh", "classojph_1_1ppm__out.html#a3fa680fc345b680160539db4c524d554", null ],
    [ "fname", "classojph_1_1ppm__out.html#a276152189804d8d020984bd3bf186de0", null ],
    [ "height", "classojph_1_1ppm__out.html#a317a3b7fa398473a50a34f075b81db58", null ],
    [ "lptr", "classojph_1_1ppm__out.html#aa100f5c35698805da984824d470fed31", null ],
    [ "num_components", "classojph_1_1ppm__out.html#a143a9b535d7f7f14f9278d838f35d5fa", null ],
    [ "samples_per_line", "classojph_1_1ppm__out.html#ad96027dfb89891c4d44f3ce1a0a8dc3c", null ],
    [ "width", "classojph_1_1ppm__out.html#a3369f6675e2722983bdb3d21c41f0e65", null ]
];