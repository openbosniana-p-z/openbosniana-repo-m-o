var ojph__block__decoder_8cpp =
[
    [ "dec_mel_st", "structojph_1_1local_1_1dec__mel__st.html", "structojph_1_1local_1_1dec__mel__st" ],
    [ "rev_struct", "structojph_1_1local_1_1rev__struct.html", "structojph_1_1local_1_1rev__struct" ],
    [ "frwd_struct", "structojph_1_1local_1_1frwd__struct.html", "structojph_1_1local_1_1frwd__struct" ],
    [ "frwd_advance", "ojph__block__decoder_8cpp.html#a1b05f6ce183ff4ec3d14cf511a2aa0b6", null ],
    [ "frwd_fetch", "ojph__block__decoder_8cpp.html#aa5e97a9eaa4c463fd1dd137813104e0b", null ],
    [ "frwd_init", "ojph__block__decoder_8cpp.html#ab216fc9cc5c8c96626873bf2ea3a3bb0", null ],
    [ "frwd_read", "ojph__block__decoder_8cpp.html#a9d43f1c5a860e68c36a781b6fbb44bcb", null ],
    [ "mel_decode", "ojph__block__decoder_8cpp.html#afe8b9049b5852096a581214eb8cc535f", null ],
    [ "mel_get_run", "ojph__block__decoder_8cpp.html#a768fb0b78a145da9afc97fa14c196940", null ],
    [ "mel_init", "ojph__block__decoder_8cpp.html#a7ed2c2e0292f950d7d2814152def5987", null ],
    [ "mel_read", "ojph__block__decoder_8cpp.html#a15ecc3a48ca6e837178f1775d6d470b3", null ],
    [ "ojph_decode_codeblock", "ojph__block__decoder_8cpp.html#ac7fa5de1e5b3387aef20afe94607c059", null ],
    [ "rev_advance", "ojph__block__decoder_8cpp.html#a852d610244da597ee56617279d484e70", null ],
    [ "rev_advance_mrp", "ojph__block__decoder_8cpp.html#a642103fa4e727586485a0538e01327a2", null ],
    [ "rev_fetch", "ojph__block__decoder_8cpp.html#a0a10ad996c0a5f06b9bafcc2ac5c6809", null ],
    [ "rev_fetch_mrp", "ojph__block__decoder_8cpp.html#a5ef51a946a0a0a3addd12c52049467e1", null ],
    [ "rev_init", "ojph__block__decoder_8cpp.html#a7b034181ce396c0a3effca16c38ded99", null ],
    [ "rev_init_mrp", "ojph__block__decoder_8cpp.html#a15cc474f3763c485f23fe66458fb50b0", null ],
    [ "rev_read", "ojph__block__decoder_8cpp.html#a6ec7b6364a7c5d0cb7ace5ecdd3dceb1", null ],
    [ "rev_read_mrp", "ojph__block__decoder_8cpp.html#a4961e94b99a54b88fe6a36644fdcf7b0", null ]
];