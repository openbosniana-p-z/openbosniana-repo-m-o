var classojph_1_1local_1_1bibo__gains =
[
    [ "get_bibo_gain_h", "classojph_1_1local_1_1bibo__gains.html#a83de3f728fc2d0df80fc2ba0a04bfa63", null ],
    [ "get_bibo_gain_l", "classojph_1_1local_1_1bibo__gains.html#a47bb35d6080178d2869f1fb23f4666a5", null ],
    [ "gain_5x3_h", "classojph_1_1local_1_1bibo__gains.html#a7fa545d03573b6e4c9284b9845242a3b", null ],
    [ "gain_5x3_l", "classojph_1_1local_1_1bibo__gains.html#a05c5673233275312cc61971b8b140223", null ],
    [ "gain_9x7_h", "classojph_1_1local_1_1bibo__gains.html#ae64fbe57b4049b44d0f46df418e1bf9a", null ],
    [ "gain_9x7_l", "classojph_1_1local_1_1bibo__gains.html#af4bce541c520abab8ec8536a38c5f564", null ]
];