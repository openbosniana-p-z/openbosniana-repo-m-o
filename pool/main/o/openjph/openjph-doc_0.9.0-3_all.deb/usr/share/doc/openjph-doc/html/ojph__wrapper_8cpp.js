var ojph__wrapper_8cpp =
[
    [ "j2k_struct", "structj2k__struct.html", "structj2k__struct" ],
    [ "cpp_create_j2c_data", "ojph__wrapper_8cpp.html#a27a1759469e210e0133d6d83b8d61d74", null ],
    [ "cpp_init_j2c_data", "ojph__wrapper_8cpp.html#a7ca0f886199590c98d1c145135cb9cea", null ],
    [ "cpp_parse_j2c_data", "ojph__wrapper_8cpp.html#a7bd3f69da97b92738fbc9e8df816498a", null ],
    [ "cpp_pull_j2c_line", "ojph__wrapper_8cpp.html#a6b5d0c9b96a7746bc351db086563d253", null ],
    [ "cpp_release_j2c_data", "ojph__wrapper_8cpp.html#afae5539bfe3f9a92f9b16570b79056b0", null ],
    [ "cpp_restrict_input_resolution", "ojph__wrapper_8cpp.html#a84eff2f84fbbb71185301eb1532466ef", null ],
    [ "create_j2c_data", "ojph__wrapper_8cpp.html#a98a3f025d5d6e7598895394bd6d1d303", null ],
    [ "enable_resilience", "ojph__wrapper_8cpp.html#a4142b5a41f453e14969a18b01f4fb4b2", null ],
    [ "get_j2c_bit_depth", "ojph__wrapper_8cpp.html#aaa47ac3272f233d9d028311c79a87af4", null ],
    [ "get_j2c_downsampling_x", "ojph__wrapper_8cpp.html#aa8fae46b623d2a4223ba65458f519ea9", null ],
    [ "get_j2c_downsampling_y", "ojph__wrapper_8cpp.html#a30de9bb4379632ac96aac601285a59de", null ],
    [ "get_j2c_height", "ojph__wrapper_8cpp.html#a58adecebd9ea6ca9eb3dbb6a1694dcb1", null ],
    [ "get_j2c_is_signed", "ojph__wrapper_8cpp.html#a9911f096a2a7f94bb9f64b2bb3648967", null ],
    [ "get_j2c_num_components", "ojph__wrapper_8cpp.html#a286acf18dcb15c2d19b6473bc2933b5c", null ],
    [ "get_j2c_width", "ojph__wrapper_8cpp.html#ad46f3aa801790fbe71336bb25dd156d6", null ],
    [ "init_j2c_data", "ojph__wrapper_8cpp.html#a774fcfc8f2fd2a6b50ff499df2f12183", null ],
    [ "parse_j2c_data", "ojph__wrapper_8cpp.html#a346fb705a5c9f6ea9f8a3bd2b4b01f6e", null ],
    [ "pull_j2c_line", "ojph__wrapper_8cpp.html#a537ae1defff914ae3d8b43a3a3d48181", null ],
    [ "release_j2c_data", "ojph__wrapper_8cpp.html#a58a2a6ca58127eb8d52a2aa98e47b56f", null ],
    [ "restrict_input_resolution", "ojph__wrapper_8cpp.html#ae2e463f9236b894ab45a0bf9432c2145", null ]
];