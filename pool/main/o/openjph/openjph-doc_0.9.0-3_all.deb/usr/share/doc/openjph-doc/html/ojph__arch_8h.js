var ojph__arch_8h =
[
    [ "OJPH_EXPORT", "ojph__arch_8h.html#a4055a02605d6ecfa700885833628647d", null ],
    [ "align_ptr", "ojph__arch_8h.html#ac6c9509eb7db8ee95cea4299771d2971", null ],
    [ "calc_aligned_size", "ojph__arch_8h.html#a6f26595175bd2fd5339dd0cbec5d9cb9", null ],
    [ "count_leading_zeros", "ojph__arch_8h.html#ad0bd321a46a544da5e15fa0d8e2b3314", null ],
    [ "count_trailing_zeros", "ojph__arch_8h.html#acde01cd47ed8459823ecc1504d4f5a56", null ],
    [ "get_cpu_ext_level", "ojph__arch_8h.html#abdb0c49125bca6f38418a4b4cc89771e", null ],
    [ "ojph_round", "ojph__arch_8h.html#a62ea6b8dad0f8f24115fa370f7d2b005", null ],
    [ "ojph_trunc", "ojph__arch_8h.html#abe948ef7389321e2990f63f01a903b1b", null ],
    [ "population_count", "ojph__arch_8h.html#a900da15d3cf19078181523b65736c836", null ],
    [ "byte_alignment", "ojph__arch_8h.html#a194f0689c795987c1470d06a3a156f74", null ],
    [ "log_byte_alignment", "ojph__arch_8h.html#aea18379e814f1c0e1984a1355f289e4b", null ],
    [ "object_alignment", "ojph__arch_8h.html#a0851b64af14901b8a717bdb16df4f802", null ]
];