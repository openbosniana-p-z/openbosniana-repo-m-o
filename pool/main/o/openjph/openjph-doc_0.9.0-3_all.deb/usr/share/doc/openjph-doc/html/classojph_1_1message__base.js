var classojph_1_1message__base =
[
    [ "operator()", "classojph_1_1message__base.html#ae706e8ed09e46e1b928d379c97bc3465", null ]
];