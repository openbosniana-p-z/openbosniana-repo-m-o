var ojph__colour__avx2_8cpp =
[
    [ "avx2_cnvrt_si32_to_si32_shftd", "ojph__colour__avx2_8cpp.html#ae5cf6fa8f6324853dd35e82fb65f7ec2", null ],
    [ "avx2_rct_backward", "ojph__colour__avx2_8cpp.html#a5af8fa2b7c9f07d8c0bf981165918e20", null ],
    [ "avx2_rct_forward", "ojph__colour__avx2_8cpp.html#a16b83385f2029c380181c81f5b4e8b78", null ]
];