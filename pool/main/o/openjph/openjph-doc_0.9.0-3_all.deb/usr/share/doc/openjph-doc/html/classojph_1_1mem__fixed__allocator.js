var classojph_1_1mem__fixed__allocator =
[
    [ "mem_fixed_allocator", "classojph_1_1mem__fixed__allocator.html#ae9d39d7d9a6f71c6b3974e67cc865e9e", null ],
    [ "~mem_fixed_allocator", "classojph_1_1mem__fixed__allocator.html#ae83d1eb6ad0026582b6216fd4684f2d7", null ],
    [ "alloc", "classojph_1_1mem__fixed__allocator.html#a1c344f188d5f297867128c3ce00bbc26", null ],
    [ "post_alloc_data", "classojph_1_1mem__fixed__allocator.html#a98b8bd9042f851a0bd00ae16a3dfd770", null ],
    [ "post_alloc_local", "classojph_1_1mem__fixed__allocator.html#a8fbfe46fb08f61ff3ef326268a7d0415", null ],
    [ "post_alloc_obj", "classojph_1_1mem__fixed__allocator.html#a8219de7e4a18cf5eaa5a307844adb033", null ],
    [ "pre_alloc_data", "classojph_1_1mem__fixed__allocator.html#a002515c2bc2d86b4296199b881c712f0", null ],
    [ "pre_alloc_local", "classojph_1_1mem__fixed__allocator.html#a3da67d550ca52933093ed6d2ec2771e1", null ],
    [ "pre_alloc_obj", "classojph_1_1mem__fixed__allocator.html#a1f54e72013f441c887bd7b2a3afd9383", null ],
    [ "avail_data", "classojph_1_1mem__fixed__allocator.html#aa57078e63ea82f595e114b8bdf74c0a5", null ],
    [ "avail_obj", "classojph_1_1mem__fixed__allocator.html#a21a0eff26abb400c9961b36720c07464", null ],
    [ "avail_size_data", "classojph_1_1mem__fixed__allocator.html#aa8c44624147e0bf46434afc8ec1bc37c", null ],
    [ "avail_size_obj", "classojph_1_1mem__fixed__allocator.html#ab384749a0b8d7d55a13e63e06c559c63", null ],
    [ "size_data", "classojph_1_1mem__fixed__allocator.html#a75d83304ab64db208b21d10f52b4d5c9", null ],
    [ "size_obj", "classojph_1_1mem__fixed__allocator.html#aece4cd79ec0c937be25db2629e513f4c", null ],
    [ "store", "classojph_1_1mem__fixed__allocator.html#a26d0394ec3290aba5fefb7a76d135f3c", null ]
];