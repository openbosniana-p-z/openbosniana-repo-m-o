var dir_34b4cee2b5900b653deb3438fc906cf4 =
[
    [ "ojph_arch.h", "ojph__arch_8h.html", "ojph__arch_8h" ],
    [ "ojph_arg.h", "ojph__arg_8h.html", [
      [ "argument", "classojph_1_1argument.html", "classojph_1_1argument" ],
      [ "cli_interpreter", "classojph_1_1cli__interpreter.html", "classojph_1_1cli__interpreter" ],
      [ "arg_inter_base", "structojph_1_1cli__interpreter_1_1arg__inter__base.html", "structojph_1_1cli__interpreter_1_1arg__inter__base" ]
    ] ],
    [ "ojph_base.h", "ojph__base_8h.html", [
      [ "size", "structojph_1_1size.html", "structojph_1_1size" ],
      [ "point", "structojph_1_1point.html", "structojph_1_1point" ],
      [ "rect", "structojph_1_1rect.html", "structojph_1_1rect" ]
    ] ],
    [ "ojph_codestream.h", "ojph__codestream_8h.html", [
      [ "codestream", "classojph_1_1codestream.html", "classojph_1_1codestream" ]
    ] ],
    [ "ojph_defs.h", "ojph__defs_8h.html", "ojph__defs_8h" ],
    [ "ojph_file.h", "ojph__file_8h.html", "ojph__file_8h" ],
    [ "ojph_mem.h", "ojph__mem_8h.html", [
      [ "mem_fixed_allocator", "classojph_1_1mem__fixed__allocator.html", "classojph_1_1mem__fixed__allocator" ],
      [ "line_buf", "structojph_1_1line__buf.html", "structojph_1_1line__buf" ],
      [ "coded_lists", "structojph_1_1coded__lists.html", "structojph_1_1coded__lists" ],
      [ "mem_elastic_allocator", "classojph_1_1mem__elastic__allocator.html", "classojph_1_1mem__elastic__allocator" ],
      [ "stores_list", "structojph_1_1mem__elastic__allocator_1_1stores__list.html", "structojph_1_1mem__elastic__allocator_1_1stores__list" ]
    ] ],
    [ "ojph_message.h", "ojph__message_8h.html", "ojph__message_8h" ],
    [ "ojph_params.h", "ojph__params_8h.html", [
      [ "param_siz", "classojph_1_1param__siz.html", "classojph_1_1param__siz" ],
      [ "param_cod", "classojph_1_1param__cod.html", "classojph_1_1param__cod" ],
      [ "param_qcd", "classojph_1_1param__qcd.html", "classojph_1_1param__qcd" ]
    ] ],
    [ "ojph_version.h", "ojph__version_8h.html", "ojph__version_8h" ]
];