var ojph__params_8cpp =
[
    [ "sqrt_energy_gains", "classojph_1_1local_1_1sqrt__energy__gains.html", "classojph_1_1local_1_1sqrt__energy__gains" ],
    [ "bibo_gains", "classojph_1_1local_1_1bibo__gains.html", "classojph_1_1local_1_1bibo__gains" ],
    [ "_USE_MATH_DEFINES", "ojph__params_8cpp.html#a525335710b53cb064ca56b936120431e", null ],
    [ "swap_byte", "ojph__params_8cpp.html#ab7f61efd828f9c9ba18c717942ebb243", null ],
    [ "swap_byte", "ojph__params_8cpp.html#a2d5dfd4446b48acbcf0c8a4d5a2ebca7", null ]
];