var ojph__transform__sse_8cpp =
[
    [ "sse_irrev_horz_wvlt_bwd_tx", "ojph__transform__sse_8cpp.html#a074db733ee27f74b547d57f61da111b8", null ],
    [ "sse_irrev_horz_wvlt_fwd_tx", "ojph__transform__sse_8cpp.html#a73b180a35224c6f03ee2d1ae29ac6f86", null ],
    [ "sse_irrev_vert_wvlt_K", "ojph__transform__sse_8cpp.html#ad240615282dec70137e196a6185df384", null ],
    [ "sse_irrev_vert_wvlt_step", "ojph__transform__sse_8cpp.html#adad2212b2d6c3f82c4dbd2e342d17434", null ]
];