var ojph__colour_8h =
[
    [ "init_colour_transform_functions", "ojph__colour_8h.html#a5eb99c56675edbc7044ec7bc7513bf59", null ]
];