var ojph__defs_8h =
[
    [ "ojph_div_ceil", "ojph__defs_8h.html#a43333d02537e52329d7ea8e405420c67", null ],
    [ "OJPH_INT_STRINGIFY", "ojph__defs_8h.html#a34dff1a2ee4de923e7455ecd1cbe1748", null ],
    [ "OJPH_INT_TO_STRING", "ojph__defs_8h.html#a2c9176d8d2697bf0e930d654623447e5", null ],
    [ "ojph_max", "ojph__defs_8h.html#a0480926f2f10d84c1409ab9e7ac1fb1f", null ],
    [ "ojph_min", "ojph__defs_8h.html#a5b92cd2d30b869b1026ab6baeeb31d16", null ],
    [ "ojph_unused", "ojph__defs_8h.html#adf52fe9ad95bc92b1e16628516698c60", null ],
    [ "si16", "ojph__defs_8h.html#ad95344d8647d48943978f97874069018", null ],
    [ "si32", "ojph__defs_8h.html#ad2d9d914970dedad809cc49efaed33d5", null ],
    [ "si64", "ojph__defs_8h.html#a4ac4c0be41361083ed66dcfda17d32f2", null ],
    [ "si8", "ojph__defs_8h.html#a602707abdd3fcdb04d7b840a8722ad1f", null ],
    [ "ui16", "ojph__defs_8h.html#a833feb6951f040292369227c0c523a39", null ],
    [ "ui32", "ojph__defs_8h.html#aecb99bd81b3e138430e0bbb0f85edde4", null ],
    [ "ui64", "ojph__defs_8h.html#a61420cef650cde7cd26991a9f1bf5d36", null ],
    [ "ui8", "ojph__defs_8h.html#aeeb62f8ee0306cee97944c27b9effaee", null ],
    [ "NUM_FRAC_BITS", "ojph__defs_8h.html#a46249071eb7416828b072e1ef22494ed", null ]
];