var classojph_1_1image__out__base =
[
    [ "~image_out_base", "classojph_1_1image__out__base.html#ac4712b63a12b3646bb19787d7db1abdd", null ],
    [ "close", "classojph_1_1image__out__base.html#a667e37a9e9e1f29903771a9ca107ecf9", null ],
    [ "write", "classojph_1_1image__out__base.html#a6275f99226f41a94863398d274277d6b", null ]
];