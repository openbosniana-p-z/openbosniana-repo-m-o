var ojph__colour__sse_8cpp =
[
    [ "sse_cnvrt_float_to_si32", "ojph__colour__sse_8cpp.html#afc13334b9e96d3abcfa53bb3897479bd", null ],
    [ "sse_cnvrt_float_to_si32_shftd", "ojph__colour__sse_8cpp.html#a604692911515f52744d21ed13bc08e7c", null ],
    [ "sse_cnvrt_si32_to_float", "ojph__colour__sse_8cpp.html#addbfdddcead962e923bcc0ba7015d2f2", null ],
    [ "sse_cnvrt_si32_to_float_shftd", "ojph__colour__sse_8cpp.html#a90029a55a7937704cdddff5b0a6bb747", null ],
    [ "sse_ict_backward", "ojph__colour__sse_8cpp.html#aeb53375a46ac4decd5f7769c672b4dc4", null ],
    [ "sse_ict_forward", "ojph__colour__sse_8cpp.html#a86a336247e6843f50c6eea3592c523fb", null ]
];