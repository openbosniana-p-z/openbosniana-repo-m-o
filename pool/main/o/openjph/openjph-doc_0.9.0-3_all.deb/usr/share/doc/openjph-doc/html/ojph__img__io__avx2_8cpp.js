var ojph__img__io__avx2_8cpp =
[
    [ "avx2_cvrt_32b1c_to_16ub1c_be", "ojph__img__io__avx2_8cpp.html#adbf32cdbb8bc786a54e577a12172f255", null ],
    [ "avx2_cvrt_32b1c_to_16ub1c_le", "ojph__img__io__avx2_8cpp.html#af3ef115e84caffce4b814e060737bea6", null ],
    [ "avx2_cvrt_32b1c_to_8ub1c", "ojph__img__io__avx2_8cpp.html#a1720e2d65724271ffbdade77c19cdbee", null ],
    [ "avx2_cvrt_32b3c_to_8ub3c", "ojph__img__io__avx2_8cpp.html#a7e5b6b3109adbe03e3c62d49d5da84d1", null ],
    [ "be2le", "ojph__img__io__avx2_8cpp.html#aba0c80557fa35bb1aae1146c7174064c", null ]
];