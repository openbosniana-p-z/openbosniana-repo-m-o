var ojph__file_8h =
[
    [ "outfile_base", "classojph_1_1outfile__base.html", "classojph_1_1outfile__base" ],
    [ "j2c_outfile", "classojph_1_1j2c__outfile.html", "classojph_1_1j2c__outfile" ],
    [ "mem_outfile", "classojph_1_1mem__outfile.html", "classojph_1_1mem__outfile" ],
    [ "infile_base", "classojph_1_1infile__base.html", "classojph_1_1infile__base" ],
    [ "j2c_infile", "classojph_1_1j2c__infile.html", "classojph_1_1j2c__infile" ],
    [ "mem_infile", "classojph_1_1mem__infile.html", "classojph_1_1mem__infile" ],
    [ "ojph_fseek", "ojph__file_8h.html#a125cb7eaaa250e5483d0a457b37cd091", null ],
    [ "ojph_ftell", "ojph__file_8h.html#a319b1fa30347881cbba8429f213a238e", null ]
];