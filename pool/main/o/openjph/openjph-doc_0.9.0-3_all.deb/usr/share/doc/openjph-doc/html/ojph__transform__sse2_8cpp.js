var ojph__transform__sse2_8cpp =
[
    [ "sse2_rev_horz_wvlt_bwd_tx", "ojph__transform__sse2_8cpp.html#a37dda2088747166d88f8c3591d122475", null ],
    [ "sse2_rev_horz_wvlt_fwd_tx", "ojph__transform__sse2_8cpp.html#a0dea3fbacd73425ff9be48a8beddefc1", null ],
    [ "sse2_rev_vert_wvlt_bwd_predict", "ojph__transform__sse2_8cpp.html#a970e04b496a3933eb2e0b33b60641848", null ],
    [ "sse2_rev_vert_wvlt_bwd_update", "ojph__transform__sse2_8cpp.html#aff22fbaeff01777d496be97154b5b7b7", null ],
    [ "sse2_rev_vert_wvlt_fwd_predict", "ojph__transform__sse2_8cpp.html#ab3847a1ca98386fe1828af278c2df26f", null ],
    [ "sse2_rev_vert_wvlt_fwd_update", "ojph__transform__sse2_8cpp.html#a2b25a3d4e90fc1017a08b0f5f7273d40", null ]
];