var ojph__transform__avx_8cpp =
[
    [ "avx_irrev_horz_wvlt_bwd_tx", "ojph__transform__avx_8cpp.html#a17c52c56801d1e34ad14d5f9f1d47af5", null ],
    [ "avx_irrev_horz_wvlt_fwd_tx", "ojph__transform__avx_8cpp.html#a25b35ef00dfd835c8913171b4fbb6626", null ],
    [ "avx_irrev_vert_wvlt_K", "ojph__transform__avx_8cpp.html#a547d0e2a20827c6e01e03baf35eca3e2", null ],
    [ "avx_irrev_vert_wvlt_step", "ojph__transform__avx_8cpp.html#a69a434865835b5f6bca4d68ecef77d3a", null ]
];