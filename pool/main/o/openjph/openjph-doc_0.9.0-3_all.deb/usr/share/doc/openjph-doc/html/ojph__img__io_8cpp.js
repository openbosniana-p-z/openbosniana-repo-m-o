var ojph__img__io_8cpp =
[
    [ "be2le", "ojph__img__io_8cpp.html#aba0c80557fa35bb1aae1146c7174064c", null ],
    [ "eat_white_spaces", "ojph__img__io_8cpp.html#a263f76f643648bdcdad6d7ee6aa9882a", null ],
    [ "gen_cvrt_32b1c_to_16ub1c_be", "ojph__img__io_8cpp.html#af61feab3344a677b5d75d546b59a73f9", null ],
    [ "gen_cvrt_32b1c_to_16ub1c_le", "ojph__img__io_8cpp.html#a0c150feb037f5e9e7fb3b4e7dd965763", null ],
    [ "gen_cvrt_32b1c_to_8ub1c", "ojph__img__io_8cpp.html#a35b7dc3860aeab42f78ccd736d3dafc5", null ],
    [ "gen_cvrt_32b3c_to_16ub3c_be", "ojph__img__io_8cpp.html#ad0c75a64c1a65ad0cf7d4d3a8822acce", null ],
    [ "gen_cvrt_32b3c_to_16ub3c_le", "ojph__img__io_8cpp.html#a8f147a0beaf4d1ea103d264df8b73357", null ],
    [ "gen_cvrt_32b3c_to_8ub3c", "ojph__img__io_8cpp.html#a9ab8c6bfaf07480378db6cab61c8eb9c", null ]
];