# Technical Oversight Board ("TOB")

## Description: 
> The TOB is responsible for managing conflicts, violations of procedures or guidelines or other issues that cannot be resolved in the TSC for the OAS. For further details please consult the OpenAPI Project Charter.

## TSC Elected - terms through May 2021
Isabelle Mauny @isamauny

Uri Sarid @usarid

Marsh Gardiner @earth2marsh 

Ron Ratovsky @webron

## BGB Elected - terms through May 2022

Darrel Miller @darrelmiller

Jerome Louvel @jlouvel

Jeremy Whitlock @whitlockjc
