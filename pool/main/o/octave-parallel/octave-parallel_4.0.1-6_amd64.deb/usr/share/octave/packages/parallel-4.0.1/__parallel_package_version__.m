## This file is granted to the public domain.

## -*- texinfo -*-
## @deftypefn{Function File} {} __parallel_package_version__ ()
##
## Internal function, returns version of parallel package.
##
## @end deftypefn

function ver = __parallel_package_version__ ()

  ver = "4.0.0";

endfunction

