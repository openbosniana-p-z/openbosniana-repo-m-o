/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* Define if building universal (internal helper macro) */
/* #undef AC_APPLE_UNIVERSAL_BUILD */

/* Define to one of `_getb67', `GETB67', `getb67' for Cray-2 and Cray-YMP
   systems. This function is required for `alloca.c' support on those systems.
   */
/* #undef CRAY_STACKSEG_END */

/* Define to 1 if using `alloca.c'. */
/* #undef C_ALLOCA */

/* define this if memmove should be declared extern "C" */
/* #undef DECLARE_MEMMOVE */

/* define this if strerror should be declared extern "C" */
/* #undef DECLARE_STRERROR */

/* if this is not set it defaults to 200 */
/* #undef DEFAULT_ERROR_LIMIT */

/* Define to 1 if translation of program messages to the user's native
   language is requested. */
#define ENABLE_NLS 1

/* Define to 1 if you have `alloca', as a function or macro. */
#define HAVE_ALLOCA 1

/* Define to 1 if you have <alloca.h> and it should be used (not on Ultrix).
   */
#define HAVE_ALLOCA_H 1

/* Define to 1 if you have the <argz.h> header file. */
#define HAVE_ARGZ_H 1

/* Define to 1 if you have the `asprintf' function. */
#define HAVE_ASPRINTF 1

/* define if bool is a built-in type */
#define HAVE_BOOL /**/

/* Define to 1 if you have the <cassert> header file. */
#define HAVE_CASSERT 1

/* Define if you have the gettext() function */
/* #undef HAVE_CATGETS */

/* Define to 1 if you have the MacOS X function CFLocaleCopyCurrent in the
   CoreFoundation framework. */
/* #undef HAVE_CFLOCALECOPYCURRENT */

/* Define to 1 if you have the MacOS X function CFPreferencesCopyAppValue in
   the CoreFoundation framework. */
/* #undef HAVE_CFPREFERENCESCOPYAPPVALUE */

/* Define if the GNU dcgettext() function is already present or preinstalled.
   */
#define HAVE_DCGETTEXT 1

/* Define to 1 if you have the declaration of `feof_unlocked', and to 0 if you
   don't. */
#define HAVE_DECL_FEOF_UNLOCKED 1

/* Define to 1 if you have the declaration of `fgets_unlocked', and to 0 if
   you don't. */
#define HAVE_DECL_FGETS_UNLOCKED 1

/* Define to 1 if you have the declaration of `getc_unlocked', and to 0 if you
   don't. */
#define HAVE_DECL_GETC_UNLOCKED 1

/* Define to 1 if you have the declaration of `_snprintf', and to 0 if you
   don't. */
#define HAVE_DECL__SNPRINTF 0

/* Define to 1 if you have the declaration of `_snwprintf', and to 0 if you
   don't. */
#define HAVE_DECL__SNWPRINTF 0

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* define if the compiler supports dynamic_cast<> */
#define HAVE_DYNAMIC_CAST /**/

/* Define to 1 if you have the `fwprintf' function. */
#define HAVE_FWPRINTF 1

/* Define to 1 if you have the `getcwd' function. */
#define HAVE_GETCWD 1

/* Define to 1 if you have the `getegid' function. */
#define HAVE_GETEGID 1

/* Define to 1 if you have the `geteuid' function. */
#define HAVE_GETEUID 1

/* Define to 1 if you have the `getgid' function. */
#define HAVE_GETGID 1

/* Define to 1 if you have the `getpagesize' function. */
#define HAVE_GETPAGESIZE 1

/* Define if the GNU gettext() function is already present or preinstalled. */
#define HAVE_GETTEXT 1

/* Define to 1 if you have the `getuid' function. */
#define HAVE_GETUID 1

/* Define if you have the iconv() function. */
#define HAVE_ICONV 1

/* define if the compiler supports explicit instantiations */
#define HAVE_INSTANTIATIONS /**/

/* Define if you have the 'intmax_t' type in <stdint.h> or <inttypes.h>. */
#define HAVE_INTMAX_T 1

/* Define if <inttypes.h> exists and doesn't clash with <sys/types.h>. */
#define HAVE_INTTYPES_H 1

/* Define if <inttypes.h> exists, doesn't clash with <sys/types.h>, and
   declares uintmax_t. */
#define HAVE_INTTYPES_H_WITH_UINTMAX 1

/* Define to 1 if you have the <io.h> header file. */
/* #undef HAVE_IO_H */

/* Define if you have <langinfo.h> and nl_langinfo(CODESET). */
#define HAVE_LANGINFO_CODESET 1

/* Define if your <locale.h> file defines LC_MESSAGES. */
#define HAVE_LC_MESSAGES 1

/* Define to 1 if you have the `pthread' library (-lpthread). */
#define HAVE_LIBPTHREAD 1

/* Define to 1 if you have the `threads' library (-lthreads). */
/* #undef HAVE_LIBTHREADS */

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if you have the <locale.h> header file. */
#define HAVE_LOCALE_H 1

/* Define if you have the 'long double' type. */
#define HAVE_LONG_DOUBLE 1

/* Define if you have the 'long long' type. */
#define HAVE_LONG_LONG 1

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the `memcmp' function. */
#define HAVE_MEMCMP 1

/* Define to 1 if you have the `memmove' function. */
#define HAVE_MEMMOVE 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the `mempcpy' function. */
#define HAVE_MEMPCPY 1

/* Define to 1 if you have a working `mmap' system call. */
#define HAVE_MMAP 1

/* Define to 1 if you have the `munmap' function. */
#define HAVE_MUNMAP 1

/* define if the compiler supports the mutable keyword */
#define HAVE_MUTABLE /**/

/* define if the compiler implements namespaces */
#define HAVE_NAMESPACES /**/

/* define if the C++ compiler supports the std namespace */
#define HAVE_NAMESPACE_STD 1

/* Define to 1 if you have the <new> header file. */
#define HAVE_NEW 1

/* define if the compiler accepts the new for scoping rules */
#define HAVE_NEW_FOR_SCOPING /**/

/* Define to 1 if you have the <nl_types.h> header file. */
#define HAVE_NL_TYPES_H 1

/* Define to 1 if you have the <osfcn.h> header file. */
/* #undef HAVE_OSFCN_H */

/* define if the compiler supports placement operator delete */
/* #undef HAVE_PLACEMENT_OPERATOR_DELETE */

/* define if placement operator new is declared */
#define HAVE_PLACEMENT_OPERATOR_NEW 1

/* Define if your printf() function supports format strings with positions. */
#define HAVE_POSIX_PRINTF 1

/* Define to 1 if you have the `putenv' function. */
#define HAVE_PUTENV 1

/* Define to 1 if you have the `setenv' function. */
#define HAVE_SETENV 1

/* Define to 1 if you have the `setlocale' function. */
#define HAVE_SETLOCALE 1

/* Define to 1 if you have the `snprintf' function. */
#define HAVE_SNPRINTF 1

/* Define to 1 if you have the <stddef.h> header file. */
#define HAVE_STDDEF_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define if <stdint.h> exists, doesn't clash with <sys/types.h>, and declares
   uintmax_t. */
#define HAVE_STDINT_H_WITH_UINTMAX 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `stpcpy' function. */
#define HAVE_STPCPY 1

/* Define to 1 if you have the `strcasecmp' function. */
#define HAVE_STRCASECMP 1

/* Define to 1 if you have the `strdup' function. */
#define HAVE_STRDUP 1

/* Define to 1 if you have the `strerror' function. */
#define HAVE_STRERROR 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strtoul' function. */
#define HAVE_STRTOUL 1

/* Define to 1 if `st_blksize' is a member of `struct stat'. */
#define HAVE_STRUCT_STAT_ST_BLKSIZE 1

/* Define if your `struct stat' has `st_blksize'. Deprecated, use
   `HAVE_STRUCT_STAT_ST_BLKSIZE' instead. */
#define HAVE_ST_BLKSIZE 1

/* Define to 1 if you have the <sys/param.h> header file. */
#define HAVE_SYS_PARAM_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the `tsearch' function. */
#define HAVE_TSEARCH 1

/* define if the compiler recognizes typename */
#define HAVE_TYPENAME /**/

/* Define if you have the 'uintmax_t' type in <stdint.h> or <inttypes.h>. */
#define HAVE_UINTMAX_T 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define if you have the 'unsigned long long' type. */
#define HAVE_UNSIGNED_LONG_LONG 1

/* Define if you have the 'wchar_t' type. */
#define HAVE_WCHAR_T 1

/* Define to 1 if you have the `wcslen' function. */
#define HAVE_WCSLEN 1

/* Define if you have the 'wint_t' type. */
#define HAVE_WINT_T 1

/* Define to 1 if you have the `__argz_count' function. */
#define HAVE___ARGZ_COUNT 1

/* Define to 1 if you have the `__argz_next' function. */
#define HAVE___ARGZ_NEXT 1

/* Define to 1 if you have the `__argz_stringify' function. */
#define HAVE___ARGZ_STRINGIFY 1

/* Define to 1 if you have the `__fsetlocking' function. */
#define HAVE___FSETLOCKING 1

/* Define as const if the declaration of iconv() needs const. */
#define ICONV_CONST 

/* Define if integer division by zero raises signal SIGFPE. */
#define INTDIV0_RAISES_SIGFPE 1

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME ""

/* Define to the full name and version of this package. */
#define PACKAGE_STRING ""

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME ""

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION ""

/* set this to the path separator */
#define PATH_SEPARATOR ':'

/* Define if <inttypes.h> exists and defines unusable PRI* macros. */
/* #undef PRI_MACROS_BROKEN */

/* set this to the default catalog files list */
#define SGML_CATALOG_FILES_DEFAULT "/etc/sgml/catalog"

/* set this to the default SGML search path */
#define SGML_SEARCH_PATH_DEFAULT "/usr/local/share/sgml:/usr/share/sgml"

/* The size of `bool', as computed by sizeof. */
#define SIZEOF_BOOL 1

/* The size of `size_t', as computed by sizeof. */
#define SIZEOF_SIZE_T 8

/* The size of `unsigned int', as computed by sizeof. */
#define SIZEOF_UNSIGNED_INT 4

/* The size of `unsigned short', as computed by sizeof. */
#define SIZEOF_UNSIGNED_SHORT 2

/* The size of `wchar_t', as computed by sizeof. */
#define SIZEOF_WCHAR_T 4

/* Define as the maximum value of type 'size_t', if the system doesn't define
   it. */
/* #undef SIZE_MAX */

/* define this if h_errno should be declared extern int */
/* #undef SP_DECLARE_H_ERRNO */

/* define this to include template definitions in the headers */
#define SP_DEFINE_TEMPLATES 1

/* define this to build a dll */
/* #undef SP_DLLEXPORT */

/* define this tobuild a dll */
/* #undef SP_DLLIMPORT */

/* set this to enable DTDDECL support */
/* #undef SP_DTDDECL */

/* define this if the new handler takes size_t and returns int */
/* #undef SP_FANCY_NEW_HANDLER */

/* define this if _setmode is supported */
/* #undef SP_HAVE_SETMODE */

/* define this if sockets are available */
#define SP_HAVE_SOCKET 1

/* set this to the first line term character */
/* #undef SP_LINE_TERM1 */

/* set this to the second line term character */
/* #undef SP_LINE_TERM2 */

/* location of message catalogs */
#define SP_LOCALE_DIR "/usr/share/locale"

/* define this to compile explicit template instantiations */
/* #undef SP_MANUAL_INST */

/* message domain */
#define SP_MESSAGE_DOMAIN "sp5"

/* define this to build a multi-byte version */
#define SP_MULTI_BYTE 1

/* define this to use win32 mutex mechanisms */
/* #undef SP_MUTEX_WIN32 */

/* define this if your system misses new.h */
/* #undef SP_NEW_H_MISSING */

/* define this to not compile message texts in */
/* #undef SP_NO_MESSAGE_TEXT */

/* Package name */
#define SP_PACKAGE "OpenSP"

/* define this to enable precompiled header support */
/* #undef SP_PCH */

/* define this if set_new_handler() has to be declared extern "C" */
/* #undef SP_SET_NEW_HANDLER_EXTERN_C */

/* define this to build a dll */
/* #undef SP_USE_DLL */

/* define this if you can't or don't want to use the builtin assert() macro */
/* #undef SP_USE_OWN_ASSERT */

/* Package version */
#define SP_VERSION "1.5.2"

/* define this if the OS provides wide character interfaces */
/* #undef SP_WIDE_SYSTEM */

/* set this to enable XML Formatted Messages */
/* #undef SP_XML */

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at runtime.
	STACK_DIRECTION > 0 => grows toward higher addresses
	STACK_DIRECTION < 0 => grows toward lower addresses
	STACK_DIRECTION = 0 => direction of growth unknown */
/* #undef STACK_DIRECTION */

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Enable extensions on AIX 3, Interix.  */
#ifndef _ALL_SOURCE
# define _ALL_SOURCE 1
#endif
/* Enable GNU extensions on systems that have them.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE 1
#endif
/* Enable threading extensions on Solaris.  */
#ifndef _POSIX_PTHREAD_SEMANTICS
# define _POSIX_PTHREAD_SEMANTICS 1
#endif
/* Enable extensions on HP NonStop.  */
#ifndef _TANDEM_SOURCE
# define _TANDEM_SOURCE 1
#endif
/* Enable general extensions on Solaris.  */
#ifndef __EXTENSIONS__
# define __EXTENSIONS__ 1
#endif


/* Define WORDS_BIGENDIAN to 1 if your processor stores words with the most
   significant byte first (like Motorola and SPARC, unlike Intel). */
#if defined AC_APPLE_UNIVERSAL_BUILD
# if defined __BIG_ENDIAN__
#  define WORDS_BIGENDIAN 1
# endif
#else
# ifndef WORDS_BIGENDIAN
/* #  undef WORDS_BIGENDIAN */
# endif
#endif

/* Define to 1 if on MINIX. */
/* #undef _MINIX */

/* Define to 2 if the system does not provide POSIX.1 features except with
   this defined. */
/* #undef _POSIX_1_SOURCE */

/* Define to 1 if you need to in order for `stat' and other things to work. */
/* #undef _POSIX_SOURCE */

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* Define to `long int' if <sys/types.h> does not define. */
/* #undef off_t */

/* Define as the type of the result of subtracting two pointers, if the system
   doesn't define it. */
/* #undef ptrdiff_t */

/* Define to `int' if <sys/types.h> does not define. */
/* #undef sig_atomic_t */

/* Define to empty if the C compiler doesn't support this keyword. */
/* #undef signed */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */

/* Define to unsigned long or unsigned long long if <stdint.h> and
   <inttypes.h> don't define. */
/* #undef uintmax_t */


#ifdef HAVE_UNISTD_H
#define SP_INCLUDE_UNISTD_H
#endif

#ifdef HAVE_IO_H
/* #undef SP_INCLUDE_IO_H */
#endif

#ifdef HAVE_OSFCN_H
/* #undef SP_INCLUDE_OSFCN_H */
#endif

#ifndef SP_MSDOS_FILENAMES
#define SP_POSIX_FILENAMES
#endif

#ifdef HAVE_ST_BLKSIZE
#define SP_STAT_BLKSIZE
#endif

#ifdef HAVE_BOOL
#ifndef SP_HAVE_BOOL
#define SP_HAVE_BOOL
#endif
#endif /* HAVE_BOOL */

#ifdef HAVE_TYPENAME
#define SP_HAVE_TYPENAME
#endif /* HAVE_TYPENAME */

#if (SIZEOF_BOOL == 1)
#define SP_SIZEOF_BOOL_1
#endif

#if (SIZEOF_WCHAR_T == SIZEOF_UNSIGNED_SHORT)
#define SP_WCHAR_T_USHORT
#endif

#ifdef SP_HAVE_SETMODE
#ifndef SP_LINE_TERM1
#define SP_LINE_TERM1 '\r'
#define SP_LINE_TERM2 '\n'
#endif
#endif /* not SP_HAVE_SETMODE */

#ifndef SP_LINE_TERM1
#define SP_LINE_TERM1 '\n'
#endif

#ifndef HAVE_NEW_FOR_SCOPING
// This simulates the new ANSI "for" scope rules
#define for if (0); else for
#endif /* HAVE_NEW_FOR_SCOPING */

#ifndef SP_HAVE_TYPENAME
#define typename /* as nothing */
#endif

#ifndef SP_DLLEXPORT
#define SP_DLLEXPORT /* as nothing */
#endif

#ifndef SP_DLLIMPORT
#define SP_DLLIMPORT /* as nothing */
#endif

#ifdef SP_USE_DLL

#ifdef BUILD_LIBSP
#define SP_API SP_DLLEXPORT
#else
#define SP_API SP_DLLIMPORT
#endif

#else /* not SP_USE_DLL */

#define SP_API /* as nothing */

#endif /* not SP_USE_DLL */

#ifdef SP_WIDE_SYSTEM
#ifndef SP_MULTI_BYTE
#define SP_MULTI_BYTE 1
#endif
#endif

#ifdef HAVE_NAMESPACES
#define SP_NAMESPACE OpenSP
#endif /* HAVE_NAMESPACES */

#ifdef SP_NAMESPACE
#define SP_NAMESPACE_SCOPE SP_NAMESPACE::
#else
#define SP_NAMESPACE_SCOPE
#endif /* SP_NAMESPACE */

#ifdef HAVE_DYNAMIC_CAST
#define SP_HAVE_RTTI
#endif /* HAVE_DYNAMIC_CAST */

#ifdef HAVE_PATHNAME_STYLE_DOS
#define SP_MSDOS_FILENAMES
#else
#define SP_POSIX_FILENAMES
#endif /* HAVE_PATHNAME_STYLE_DOS */

#ifdef HAVE_INSTANTIATIONS
#ifndef SP_ANSI_CLASS_INST
#define SP_ANSI_CLASS_INST
#endif
#endif /* HAVE_INSTANTIATIONS */

#ifdef HAVE_SETLOCALE
#ifndef SP_HAVE_LOCALE
#define SP_HAVE_LOCALE
#endif
#endif /* HAVE_SETLOCALE */

#if defined(HAVE_GETTEXT) && defined(ENABLE_NLS)
#ifndef SP_HAVE_GETTEXT
#define SP_HAVE_GETTEXT
#endif
#endif /* HAVE_GETTEXT && ENABLE_NLS */

#ifdef WORDS_BIGENDIAN
#define SP_BIG_ENDIAN
#endif /* WORDS_BIGENDIAN */

#ifdef HAVE_LIBTHREADS
#define SP_MUTEX_MACH
#endif /* HAVE_LIBTHREADS */

#ifdef HAVE_LIBPTHREAD
#define SP_MUTEX_PTHREADS
#endif /* HAVE_LIBPTHREAD */

#ifdef HAVE_PLACEMENT_OPERATOR_DELETE
#define SP_HAVE_PLACEMENT_OPERATOR_DELETE
#endif /* HAVE_PLACEMENT_OPERATOR_DELETE */

#ifndef HAVE_PLACEMENT_OPERATOR_NEW
#define SP_DECLARE_PLACEMENT_OPERATOR_NEW
#endif /* HAVE_PLACEMENT_OPERATOR_NEW */

#ifndef HAVE_NAMESPACE_STD
#define SP_NO_STD_NAMESPACE
#endif /* HAVE_NAMESPACE_STD */

#if defined(HAVE_NEW) && defined(HAVE_CASSERT)
#define SP_ANSI_LIB 1
#endif /* HAVE_NEW && HAVE_CASSERT */

#ifndef HAVE_MUTABLE
#define mutable
#endif /* HAVE_MUTABLE */

