function FDTD = SetStepExcite(FDTD)

FDTD.Excitation.ATTRIBUTE.Type=3;
