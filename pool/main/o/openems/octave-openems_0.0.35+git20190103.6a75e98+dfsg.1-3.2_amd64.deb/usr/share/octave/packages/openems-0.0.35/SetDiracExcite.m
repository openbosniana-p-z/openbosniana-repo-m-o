function FDTD = SetDiracExcite(FDTD)

FDTD.Excitation.ATTRIBUTE.Type=2;
