/*
 * Copyright (c) 2014 Jeremy Yallop.
 *
 * This file is distributed under the terms of the MIT License.
 * See the file LICENSE for details.
 */

#ifndef CSTUBS_INTERNALS_H
#define CSTUBS_INTERNALS_H

/* This is just here for backwards compatibility and will eventually be
   removed. */

/* Include the real header. */
#include "ctypes_cstubs_internals.h"

#endif /* CSTUBS_INTERNALS_H */
