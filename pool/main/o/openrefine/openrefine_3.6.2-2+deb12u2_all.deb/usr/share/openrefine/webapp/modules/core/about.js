
$("#about-openrefine").text($.i18n('core-index/about') + " OpenRefine");
$("#contributors").text($.i18n('core-about/contributors'));
$("#definition").text($.i18n('core-about/definition'));
$("#history-openrefine").html($.i18n('core-about/history' ,'http://www.metaweb.com/' ,'Metaweb Technologies,Inc.', 'http://www.google.com/','Google' ));
$("#thanks").text($.i18n('core-about/thanks'));


 