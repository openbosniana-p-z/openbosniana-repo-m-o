var searchData=
[
  ['cmdlineoutput_0',['CmdLineOutput',['../class_cmd_line_output.html',1,'']]],
  ['config_1',['Config',['../classopencc_1_1_config.html',1,'opencc']]],
  ['configtestbase_2',['ConfigTestBase',['../classopencc_1_1_config_test_base.html',1,'opencc']]],
  ['conversion_3',['Conversion',['../classopencc_1_1_conversion.html',1,'opencc']]],
  ['conversionchain_4',['ConversionChain',['../classopencc_1_1_conversion_chain.html',1,'opencc']]],
  ['convert_5',['Convert',['../classopencc_1_1_simple_converter.html#a0042dba7fe92bee2cadb4d7a8cbec929',1,'opencc::SimpleConverter::Convert(const std::string &amp;input) const'],['../classopencc_1_1_simple_converter.html#a3bc95485e6b8c5bca6b728f557efd98a',1,'opencc::SimpleConverter::Convert(const char *input) const'],['../classopencc_1_1_simple_converter.html#a63baff1214203c8835105b5167daba43',1,'opencc::SimpleConverter::Convert(const char *input, size_t length) const'],['../classopencc_1_1_simple_converter.html#ac9eb53d7dbecf687e0d43eaaf9bf2bd1',1,'opencc::SimpleConverter::Convert(const char *input, char *output) const'],['../classopencc_1_1_simple_converter.html#a63f5dbba323443bd42772d4c5c77b313',1,'opencc::SimpleConverter::Convert(const char *input, size_t length, char *output) const']]],
  ['convertdictionary_6',['ConvertDictionary',['../group__opencc__cpp__api.html#ga84f945fa756d6f7f8bae6700586e5cba',1,'opencc']]],
  ['converter_7',['Converter',['../classopencc_1_1_converter.html',1,'opencc']]]
];
