var searchData=
[
  ['islineendingorfileending_0',['IsLineEndingOrFileEnding',['../classopencc_1_1_u_t_f8_util.html#a008b85311545f43a7a3c14e304004266',1,'opencc::UTF8Util']]],
  ['isnull_1',['IsNull',['../classopencc_1_1_optional.html#a1e0bf8b941446d82796cfa0e0aa413de',1,'opencc::Optional']]]
];
