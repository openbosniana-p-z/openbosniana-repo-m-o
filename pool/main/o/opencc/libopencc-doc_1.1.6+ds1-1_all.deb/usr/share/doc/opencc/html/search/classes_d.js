var searchData=
[
  ['textdict_0',['TextDict',['../classopencc_1_1_text_dict.html',1,'opencc']]],
  ['textdicttestbase_1',['TextDictTestBase',['../classopencc_1_1_text_dict_test_base.html',1,'opencc']]]
];
