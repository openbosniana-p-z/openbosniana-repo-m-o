var searchData=
[
  ['textdict_0',['TextDict',['../classopencc_1_1_text_dict.html#a853bbb425460e21199d934b6dc518b97',1,'opencc::TextDict']]],
  ['truncateutf8_1',['TruncateUTF8',['../classopencc_1_1_u_t_f8_util.html#ac0500d05548097452c9d5457449d648b',1,'opencc::UTF8Util']]]
];
