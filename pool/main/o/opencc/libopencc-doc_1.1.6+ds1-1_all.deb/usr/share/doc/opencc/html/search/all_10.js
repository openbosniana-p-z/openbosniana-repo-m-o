var searchData=
[
  ['segmentation_0',['Segmentation',['../classopencc_1_1_segmentation.html',1,'opencc']]],
  ['segments_1',['Segments',['../classopencc_1_1_segments.html',1,'opencc']]],
  ['serializabledict_2',['SerializableDict',['../classopencc_1_1_serializable_dict.html',1,'opencc']]],
  ['serializedvalues_3',['SerializedValues',['../classopencc_1_1_serialized_values.html',1,'opencc']]],
  ['serializetofile_4',['SerializeToFile',['../classopencc_1_1_binary_dict.html#a99e3982993ce0c2162c66559e054370e',1,'opencc::BinaryDict::SerializeToFile()'],['../classopencc_1_1_darts_dict.html#a835ab0c2b4ccaa7e586cecbcb2d417ae',1,'opencc::DartsDict::SerializeToFile()'],['../classopencc_1_1_marisa_dict.html#a4639fb40bd626c6c32bfa31e9c124891',1,'opencc::MarisaDict::SerializeToFile()'],['../classopencc_1_1_serializable_dict.html#acb184b20e1f9eaee02905809cf259e5f',1,'opencc::SerializableDict::SerializeToFile(FILE *fp) const =0'],['../classopencc_1_1_serializable_dict.html#a2e3a780d321cc79c5ba0d3cf7792bcd0',1,'opencc::SerializableDict::SerializeToFile(const std::string &amp;fileName) const'],['../classopencc_1_1_serialized_values.html#a363db1be5be544d3fb3856eec94c4225',1,'opencc::SerializedValues::SerializeToFile()'],['../classopencc_1_1_text_dict.html#a020f7973b33d4430c7a0e4ee474d44a8',1,'opencc::TextDict::SerializeToFile()']]],
  ['shouldnotbehere_5',['ShouldNotBeHere',['../classopencc_1_1_should_not_be_here.html',1,'opencc']]],
  ['signals_6',['Signals',['../structopencc_1_1_phrase_extract_1_1_signals.html',1,'opencc::PhraseExtract']]],
  ['simpleconverter_7',['SimpleConverter',['../classopencc_1_1_simple_converter.html',1,'opencc::SimpleConverter'],['../classopencc_1_1_simple_converter.html#a6e18e21f772ed986fb5ff89f6576dad4',1,'opencc::SimpleConverter::SimpleConverter()']]],
  ['singlevaluedictentry_8',['SingleValueDictEntry',['../classopencc_1_1_single_value_dict_entry.html',1,'opencc']]],
  ['skiputf8bom_9',['SkipUtf8Bom',['../classopencc_1_1_u_t_f8_util.html#a2c755b77ec792c825880b07c8ec2f788',1,'opencc::UTF8Util']]],
  ['strmultivaluedictentry_10',['StrMultiValueDictEntry',['../classopencc_1_1_str_multi_value_dict_entry.html',1,'opencc']]],
  ['strsinglevaluedictentry_11',['StrSingleValueDictEntry',['../classopencc_1_1_str_single_value_dict_entry.html',1,'opencc']]]
];
