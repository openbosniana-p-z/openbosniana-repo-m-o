var searchData=
[
  ['join_0',['Join',['../classopencc_1_1_u_t_f8_util.html#af97a85b5420283fab1e06b68a3d27fe5',1,'opencc::UTF8Util::Join(const std::vector&lt; std::string &gt; &amp;strings, const std::string &amp;separator)'],['../classopencc_1_1_u_t_f8_util.html#ab6041a2629499b1f61d99e4c2476d4dc',1,'opencc::UTF8Util::Join(const std::vector&lt; std::string &gt; &amp;strings)']]]
];
