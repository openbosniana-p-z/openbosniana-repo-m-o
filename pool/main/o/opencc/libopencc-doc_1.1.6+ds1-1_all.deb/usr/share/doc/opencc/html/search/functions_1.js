var searchData=
[
  ['findnextinline_0',['FindNextInline',['../classopencc_1_1_u_t_f8_util.html#ada1b68a720e3f667f1eb8dc4f17f00a4',1,'opencc::UTF8Util']]],
  ['fromsubstr_1',['FromSubstr',['../classopencc_1_1_u_t_f8_util.html#a15950b875c759489d657cd3e41717b79',1,'opencc::UTF8Util']]]
];
