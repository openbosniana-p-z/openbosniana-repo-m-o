var searchData=
[
  ['phraseextract_0',['PhraseExtract',['../classopencc_1_1_phrase_extract.html',1,'opencc']]]
];
