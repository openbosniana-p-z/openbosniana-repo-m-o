var searchData=
[
  ['prevchar_0',['PrevChar',['../classopencc_1_1_u_t_f8_util.html#afb0cbf03c32b544cc6b84406db18927c',1,'opencc::UTF8Util']]],
  ['prevcharlength_1',['PrevCharLength',['../classopencc_1_1_u_t_f8_util.html#a153a270ce21d855c07a7d5eba397da5e',1,'opencc::UTF8Util']]]
];
