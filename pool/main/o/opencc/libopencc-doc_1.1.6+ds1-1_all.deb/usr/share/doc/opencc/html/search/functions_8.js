var searchData=
[
  ['newfromdict_0',['NewFromDict',['../classopencc_1_1_darts_dict.html#a02dbb1e284cb99dfeb4c8cc5bd997d28',1,'opencc::DartsDict::NewFromDict()'],['../classopencc_1_1_marisa_dict.html#a3a1e3b76888ad6c5147de507a1436017',1,'opencc::MarisaDict::NewFromDict()'],['../classopencc_1_1_text_dict.html#af593a95f96c060a45eb6062d27ca27e9',1,'opencc::TextDict::NewFromDict()']]],
  ['nextchar_1',['NextChar',['../classopencc_1_1_u_t_f8_util.html#affde381db359726378f189d3e42d4d79',1,'opencc::UTF8Util']]],
  ['nextcharlength_2',['NextCharLength',['../classopencc_1_1_u_t_f8_util.html#ae71013ee7dfef2aba9e99dbae8f24bbd',1,'opencc::UTF8Util']]],
  ['nextcharlengthnoexception_3',['NextCharLengthNoException',['../classopencc_1_1_u_t_f8_util.html#a7741e8ca4c6ad9e4f68b9d4633b58def',1,'opencc::UTF8Util']]],
  ['notshorterthan_4',['NotShorterThan',['../classopencc_1_1_u_t_f8_util.html#a8ee1ac13118c59a357114782d18a3497',1,'opencc::UTF8Util']]],
  ['null_5',['Null',['../classopencc_1_1_optional.html#a5f7b2a5dc9178790635d9e6a4e1fe1fc',1,'opencc::Optional']]]
];
