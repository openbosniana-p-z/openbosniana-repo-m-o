var searchData=
[
  ['binarydict_0',['BinaryDict',['../classopencc_1_1_binary_dict.html',1,'opencc']]]
];
