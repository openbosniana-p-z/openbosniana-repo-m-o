var searchData=
[
  ['open_20chinese_20convert_20開放中文轉換_0',['Open Chinese Convert 開放中文轉換',['../index.html',1,'']]],
  ['opencc_20c_20api_1',['OpenCC C API',['../group__opencc__c__api.html',1,'']]],
  ['opencc_20c_2b_2b_20comprehensive_20api_2',['OpenCC C++ Comprehensive API',['../group__opencc__cpp__api.html',1,'']]],
  ['opencc_20c_2b_2b_20simple_20api_3',['OpenCC C++ Simple API',['../group__opencc__simple__api.html',1,'']]],
  ['opencc_5fclose_4',['opencc_close',['../group__opencc__c__api.html#gae4d995fd7bb65e2d4f386aa5cf0dbbb1',1,'opencc_close(opencc_t opencc):&#160;SimpleConverter.cpp'],['../group__opencc__c__api.html#gae4d995fd7bb65e2d4f386aa5cf0dbbb1',1,'opencc_close(opencc_t opencc):&#160;SimpleConverter.cpp']]],
  ['opencc_5fconvert_5futf8_5',['opencc_convert_utf8',['../group__opencc__c__api.html#ga1afb1062744ba0c032c11aa08a885354',1,'opencc_convert_utf8(opencc_t opencc, const char *input, size_t length):&#160;SimpleConverter.cpp'],['../group__opencc__c__api.html#ga1afb1062744ba0c032c11aa08a885354',1,'opencc_convert_utf8(opencc_t opencc, const char *input, size_t length):&#160;SimpleConverter.cpp']]],
  ['opencc_5fconvert_5futf8_5ffree_6',['opencc_convert_utf8_free',['../group__opencc__c__api.html#ga6c11f94e7bee16c080e6d8ab5c16ea84',1,'opencc_convert_utf8_free(char *str):&#160;SimpleConverter.cpp'],['../group__opencc__c__api.html#ga6c11f94e7bee16c080e6d8ab5c16ea84',1,'opencc_convert_utf8_free(char *str):&#160;SimpleConverter.cpp']]],
  ['opencc_5fconvert_5futf8_5fto_5fbuffer_7',['opencc_convert_utf8_to_buffer',['../group__opencc__c__api.html#ga9922ab17f25a2d93060292630eb46b81',1,'opencc_convert_utf8_to_buffer(opencc_t opencc, const char *input, size_t length, char *output):&#160;SimpleConverter.cpp'],['../group__opencc__c__api.html#ga9922ab17f25a2d93060292630eb46b81',1,'opencc_convert_utf8_to_buffer(opencc_t opencc, const char *input, size_t length, char *output):&#160;SimpleConverter.cpp']]],
  ['opencc_5fdefault_5fconfig_5fsimp_5fto_5ftrad_8',['OPENCC_DEFAULT_CONFIG_SIMP_TO_TRAD',['../group__opencc__c__api.html#ga05b32035094049395f8975f9d2ffa1a2',1,'opencc.h']]],
  ['opencc_5fdefault_5fconfig_5ftrad_5fto_5fsimp_9',['OPENCC_DEFAULT_CONFIG_TRAD_TO_SIMP',['../group__opencc__c__api.html#gaede2d75ff352d979e89dfc390aa855c8',1,'opencc.h']]],
  ['opencc_5ferror_10',['opencc_error',['../group__opencc__c__api.html#ga4b9411230b2c221ef310624633741eb7',1,'opencc_error(void):&#160;SimpleConverter.cpp'],['../group__opencc__c__api.html#ga4b9411230b2c221ef310624633741eb7',1,'opencc_error(void):&#160;SimpleConverter.cpp']]],
  ['opencc_5fopen_11',['opencc_open',['../group__opencc__c__api.html#ga3aa43bc27b880c05c14c15b2c8952336',1,'opencc_open(const char *configFileName):&#160;SimpleConverter.cpp'],['../group__opencc__c__api.html#ga3aa43bc27b880c05c14c15b2c8952336',1,'opencc_open(const char *configFileName):&#160;SimpleConverter.cpp']]],
  ['opencc_5ft_12',['opencc_t',['../group__opencc__c__api.html#gaa08a1436fedc071dc6fc352c98a6ade9',1,'opencc.h']]],
  ['optional_13',['Optional',['../classopencc_1_1_optional.html',1,'opencc::Optional&lt; T &gt;'],['../classopencc_1_1_optional.html#afc26cd1d9152426778b6aa532adb10d9',1,'opencc::Optional::Optional()']]],
  ['optional_3c_20t_20_2a_20_3e_14',['Optional&lt; T * &gt;',['../classopencc_1_1_optional_3_01_t_01_5_01_4.html',1,'opencc']]]
];
