var searchData=
[
  ['segmentation_0',['Segmentation',['../classopencc_1_1_segmentation.html',1,'opencc']]],
  ['segments_1',['Segments',['../classopencc_1_1_segments.html',1,'opencc']]],
  ['serializabledict_2',['SerializableDict',['../classopencc_1_1_serializable_dict.html',1,'opencc']]],
  ['serializedvalues_3',['SerializedValues',['../classopencc_1_1_serialized_values.html',1,'opencc']]],
  ['shouldnotbehere_4',['ShouldNotBeHere',['../classopencc_1_1_should_not_be_here.html',1,'opencc']]],
  ['signals_5',['Signals',['../structopencc_1_1_phrase_extract_1_1_signals.html',1,'opencc::PhraseExtract']]],
  ['simpleconverter_6',['SimpleConverter',['../classopencc_1_1_simple_converter.html',1,'opencc']]],
  ['singlevaluedictentry_7',['SingleValueDictEntry',['../classopencc_1_1_single_value_dict_entry.html',1,'opencc']]],
  ['strmultivaluedictentry_8',['StrMultiValueDictEntry',['../classopencc_1_1_str_multi_value_dict_entry.html',1,'opencc']]],
  ['strsinglevaluedictentry_9',['StrSingleValueDictEntry',['../classopencc_1_1_str_single_value_dict_entry.html',1,'opencc']]]
];
