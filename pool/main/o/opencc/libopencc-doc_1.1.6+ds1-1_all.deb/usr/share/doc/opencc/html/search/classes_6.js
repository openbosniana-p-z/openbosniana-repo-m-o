var searchData=
[
  ['invalidformat_0',['InvalidFormat',['../classopencc_1_1_invalid_format.html',1,'opencc']]],
  ['invalidtextdictionary_1',['InvalidTextDictionary',['../classopencc_1_1_invalid_text_dictionary.html',1,'opencc']]],
  ['invalidutf8_2',['InvalidUTF8',['../classopencc_1_1_invalid_u_t_f8.html',1,'opencc']]],
  ['iterator_3',['iterator',['../classopencc_1_1_segments_1_1iterator.html',1,'opencc::Segments']]]
];
