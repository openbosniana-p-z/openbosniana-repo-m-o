var searchData=
[
  ['optional_0',['Optional',['../classopencc_1_1_optional.html',1,'opencc']]],
  ['optional_3c_20t_20_2a_20_3e_1',['Optional&lt; T * &gt;',['../classopencc_1_1_optional_3_01_t_01_5_01_4.html',1,'opencc']]]
];
