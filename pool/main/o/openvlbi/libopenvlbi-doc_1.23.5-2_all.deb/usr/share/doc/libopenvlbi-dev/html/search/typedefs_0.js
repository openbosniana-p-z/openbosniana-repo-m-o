var searchData=
[
  ['dsp_5falign_5finfo_0',['dsp_align_info',['../group___d_s_p___types.html#ga8a50c6e2cc04b1fdc15cab83db4e888b',1,'dsp.h']]],
  ['dsp_5ffunc_5ft_1',['dsp_func_t',['../group___d_s_p___types.html#ga01ee07147aeafc2c4e900698040b77f8',1,'dsp.h']]],
  ['dsp_5flocation_2',['dsp_location',['../group___d_s_p___types.html#gaed2bb55a5ec25c68e1fbf547580651aa',1,'dsp.h']]],
  ['dsp_5foffset_3',['dsp_offset',['../group___d_s_p___types.html#ga1361847a33b2509e8db50bb058fd091f',1,'dsp.h']]],
  ['dsp_5fpoint_4',['dsp_point',['../group___d_s_p___types.html#ga169c280a64a5b5d7c28689851a3643a8',1,'dsp.h']]],
  ['dsp_5fregion_5',['dsp_region',['../group___d_s_p___types.html#ga0e8c1a3c205075785b9443d1c5166f74',1,'dsp.h']]],
  ['dsp_5fstar_6',['dsp_star',['../group___d_s_p___types.html#gaf93dd5cd3589db4649654b4976710670',1,'dsp.h']]],
  ['dsp_5fstream_7',['dsp_stream',['../group___d_s_p___types.html#gae48cfbf7c6f2fa3b617e939f311786b4',1,'dsp.h']]],
  ['dsp_5ftriangle_8',['dsp_triangle',['../group___d_s_p___types.html#ga5c35d8d85bdbf6df99e1abfd099457a1',1,'dsp.h']]]
];
