var searchData=
[
  ['very_20long_20baseline_20interferometry_20api_0',['Very Long Baseline Interferometry API',['../group___v_l_b_i.html',1,'']]],
  ['vlbi_20defines_1',['VLBI defines',['../group___v_l_b_i___defines.html',1,'']]],
  ['vlbi_20types_2',['VLBI types',['../group___v_l_b_i___types.html',1,'']]]
];
