var searchData=
[
  ['digital_20signal_20processing_20api_0',['Digital Signal Processing API',['../group___d_s_p.html',1,'']]],
  ['dsp_20api_20buffer_20editing_20functions_1',['DSP API Buffer editing functions',['../group__dsp___buffers.html',1,'']]],
  ['dsp_20api_20buffer_20statistics_20functions_2',['DSP API Buffer statistics functions',['../group__dsp___stats.html',1,'']]],
  ['dsp_20api_20convolution_20and_20cross_2dcorrelation_20functions_3',['DSP API Convolution and cross-correlation functions',['../group__dsp___convolution.html',1,'']]],
  ['dsp_20api_20defines_4',['DSP API defines',['../group___d_s_p___defines.html',1,'']]],
  ['dsp_20api_20file_20read_2fwrite_20functions_5',['DSP API File read/write functions',['../group__dsp___file_management.html',1,'']]],
  ['dsp_20api_20fits_20extensions_20functions_6',['DSP API FITS Extensions functions',['../group__dsp___fits_extensions.html',1,'']]],
  ['dsp_20api_20fitsidi_20extension_7',['DSP API FITSIDI Extension',['../group__dsp___fits_extension_f_i_t_s_i_d_i.html',1,'']]],
  ['dsp_20api_20fourier_20transform_20related_20functions_8',['DSP API Fourier transform related functions',['../group__dsp___fourier_transform.html',1,'']]],
  ['dsp_20api_20linear_20buffer_20filtering_20functions_9',['DSP API Linear buffer filtering functions',['../group__dsp___filters.html',1,'']]],
  ['dsp_20api_20sdfits_20extension_10',['DSP API SDFITS Extension',['../group__dsp___fits_extension_s_d_f_i_t_s.html',1,'']]],
  ['dsp_20api_20signal_20generation_20functions_11',['DSP API Signal generation functions',['../group__dsp___signal_gen.html',1,'']]],
  ['dsp_20api_20stream_20type_20management_20functions_12',['DSP API Stream type management functions',['../group__dsp___d_s_p_stream.html',1,'']]],
  ['dsp_20api_20types_13',['DSP API types',['../group___d_s_p___types.html',1,'']]]
];
