var searchData=
[
  ['baseline_0',['baseline',['../structvlbi__baseline.html#a23b83d569063d09974f530c433e8a4a3',1,'vlbi_baseline']]],
  ['buf_1',['buf',['../group___d_s_p.html#ga6d8d5300e9a18c8e3ef743cf6927b086',1,'dsp_complex::buf()'],['../group___d_s_p.html#gabbeea6eb682e65a8b07b7b03fff5314d',1,'dsp_stream_t::buf()']]]
];
