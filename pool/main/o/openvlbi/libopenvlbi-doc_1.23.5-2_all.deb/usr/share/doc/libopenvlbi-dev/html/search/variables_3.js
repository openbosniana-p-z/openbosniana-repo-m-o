var searchData=
[
  ['dec_0',['Dec',['../structvlbi__baseline.html#af1324e3897699e4b9c3c75b82a3c0b7b',1,'vlbi_baseline']]],
  ['decimals_1',['decimals',['../group___d_s_p.html#ga2da6135903e4a3fbfe7fa801d36a8278',1,'dsp_align_info_t']]],
  ['definition_2',['definition',['../structdsp__fits__axis.html#a96c9373f0f352ee0dac8d451526aee7d',1,'dsp_fits_axis']]],
  ['delay_3',['delay',['../structvlbi__baseline.html#a1ba498438b76ad4d50dc7f5ab0c3ba0d',1,'vlbi_baseline']]],
  ['dft_4',['dft',['../group___d_s_p.html#ga4ddbf170cb1599f5ad74b75c2c5fccc9',1,'dsp_stream_t']]],
  ['diameter_5',['diameter',['../group___d_s_p.html#ga7e1b4c29aaa45b43c134214f8c92ca92',1,'dsp_star_t::diameter()'],['../group___d_s_p.html#ga8d35ea08064f52fb1038502c8b24ab2f',1,'dsp_stream_t::diameter()']]],
  ['dims_6',['dims',['../group___d_s_p.html#gabeb3de4b1edf8a454ea5a3d8685bbdb5',1,'dsp_point_t::dims()'],['../group___d_s_p.html#ga991d438a2391c07059f1cc97b96cca0b',1,'dsp_offset_t::dims()'],['../group___d_s_p.html#ga7f9e40dd5103f5186ec1808f4ae625e4',1,'dsp_triangle_t::dims()'],['../group___d_s_p.html#ga2c4316f19e9265899a37fa5d4aa4f489',1,'dsp_align_info_t::dims()'],['../group___d_s_p.html#ga9be4e4bb4b6130bee801b2612238b1a9',1,'dsp_stream_t::dims()'],['../structdsp__fits__matrix.html#a53d00bdafd66042a34f790ee6986bf2f',1,'dsp_fits_matrix::dims()']]]
];
