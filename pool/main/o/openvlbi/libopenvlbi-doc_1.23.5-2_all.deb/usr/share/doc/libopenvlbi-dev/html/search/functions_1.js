var searchData=
[
  ['bandpass_0',['BandPass',['../class_v_l_b_i_1_1_server.html#adde1a3cdfcf6c4f64dfeb6481d810c53',1,'VLBI::Server']]],
  ['bandreject_1',['BandReject',['../class_v_l_b_i_1_1_server.html#a3b89328dd4f2cbf40e2da8ae52295052',1,'VLBI::Server']]]
];
