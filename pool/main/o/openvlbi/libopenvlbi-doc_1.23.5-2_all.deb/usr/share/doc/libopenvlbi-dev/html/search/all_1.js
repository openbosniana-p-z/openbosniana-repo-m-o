var searchData=
[
  ['bandpass_0',['BandPass',['../class_v_l_b_i_1_1_server.html#adde1a3cdfcf6c4f64dfeb6481d810c53',1,'VLBI::Server']]],
  ['bandreject_1',['BandReject',['../class_v_l_b_i_1_1_server.html#a3b89328dd4f2cbf40e2da8ae52295052',1,'VLBI::Server']]],
  ['baseline_2',['baseline',['../structvlbi__baseline.html#a23b83d569063d09974f530c433e8a4a3',1,'vlbi_baseline']]],
  ['baselines_20api_3',['Baselines API',['../group___v_l_b_i___baselines.html',1,'']]],
  ['boltsmann_4',['BOLTSMANN',['../group___v_l_b_i___defines.html#gacb142973c5cebc698968dbbe53041206',1,'vlbi.h']]],
  ['buf_5',['buf',['../group___d_s_p.html#ga6d8d5300e9a18c8e3ef743cf6927b086',1,'dsp_complex::buf()'],['../group___d_s_p.html#gabbeea6eb682e65a8b07b7b03fff5314d',1,'dsp_stream_t::buf()']]],
  ['build_20openvlbi_6',['Build OpenVLBI',['../page__build.html',1,'']]]
];
