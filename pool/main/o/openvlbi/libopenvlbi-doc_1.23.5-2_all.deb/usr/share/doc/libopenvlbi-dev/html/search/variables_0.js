var searchData=
[
  ['align_5finfo_0',['align_info',['../group___d_s_p.html#ga8e3dc381a797450dbd2710e55a44821a',1,'dsp_stream_t']]],
  ['arg_1',['arg',['../group___d_s_p.html#ga05451c3c028f37397421d1ff5f4cba0c',1,'dsp_stream_t']]],
  ['axes_5fdefinition_2',['axes_definition',['../structdsp__fits__matrix.html#a853337faa9b45fa0e4c7cfb72882e408',1,'dsp_fits_matrix']]]
];
