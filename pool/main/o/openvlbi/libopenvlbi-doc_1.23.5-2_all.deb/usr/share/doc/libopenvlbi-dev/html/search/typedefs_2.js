var searchData=
[
  ['vlbi_5fcontext_0',['vlbi_context',['../group___v_l_b_i___types.html#ga50f883f7e834b395856676739fe83e0e',1,'vlbi.h']]],
  ['vlbi_5ffunc2_5ft_1',['vlbi_func2_t',['../group___v_l_b_i___types.html#ga372e6573a910d3275046540c39f3dc39',1,'vlbi.h']]]
];
