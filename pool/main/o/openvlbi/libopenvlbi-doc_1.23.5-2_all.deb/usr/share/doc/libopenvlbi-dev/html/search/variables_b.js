var searchData=
[
  ['offset_0',['offset',['../group___d_s_p.html#gaa829075218a519d7905c1ff769ba92d8',1,'dsp_offset_t::offset()'],['../group___d_s_p.html#gafac188d2d5726bda04185c1cdfc8c246',1,'dsp_align_info_t::offset()']]]
];
