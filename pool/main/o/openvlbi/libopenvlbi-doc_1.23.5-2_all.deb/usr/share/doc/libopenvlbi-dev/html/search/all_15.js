var searchData=
[
  ['xy_5fcodeclination_5fin_5fdegrees_0',['XY_Codeclination_in_degrees',['../group__dsp___fits_extension_f_i_t_s_i_d_i.html#gaa71efadb2f45f6981d593598786b5f88',1,'fitsidi.h']]],
  ['xy_5fdeclination_5fin_5fdegrees_1',['XY_Declination_in_degrees',['../group__dsp___fits_extension_f_i_t_s_i_d_i.html#ga578fe3ab9f538293a4deb1e11b551b98',1,'fitsidi.h']]],
  ['xy_5felevation_5fin_5fdegrees_2',['XY_Elevation_in_degrees',['../group__dsp___fits_extension_f_i_t_s_i_d_i.html#ga2dc87197457f602147ade77dcb1369d8',1,'fitsidi.h']]],
  ['xy_5fhour_5fangle_5fin_5fdegrees_3',['XY_Hour_angle_in_degrees',['../group__dsp___fits_extension_f_i_t_s_i_d_i.html#ga339c6494909c59b7d4ad6a8f3f942ae1',1,'fitsidi.h']]],
  ['xy_5fnone_4',['XY_None',['../group__dsp___fits_extension_f_i_t_s_i_d_i.html#ga9b53475365f3ea6dbd57ef1c9e3aabae',1,'fitsidi.h']]],
  ['xy_5fzenith_5fangle_5fin_5fdegrees_5',['XY_Zenith_angle_in_degrees',['../group__dsp___fits_extension_f_i_t_s_i_d_i.html#ga61e94dfbd4100b97b7f619e1657a001d',1,'fitsidi.h']]],
  ['xyz_6',['xyz',['../group___d_s_p.html#ga101fc25bb71ab6b664b69e92dd2259ef',1,'dsp_location_t']]]
];
