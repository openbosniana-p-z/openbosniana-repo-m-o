var searchData=
[
  ['ra_0',['Ra',['../structvlbi__baseline.html#ad0fe725f861618e78817a43a36e7fcdb',1,'vlbi_baseline']]],
  ['radians_1',['radians',['../group___d_s_p.html#ga58deea46f6307c17241f13e3b869675a',1,'dsp_align_info_t']]],
  ['ratios_2',['ratios',['../group___d_s_p.html#gad7870c32610bc91930d03b63ec09b48e',1,'dsp_triangle_t']]],
  ['real_3',['real',['../group___d_s_p.html#gaeeffe41b9bb26cb61284740485107ef4',1,'dsp_complex::real()'],['../group___d_s_p.html#ga6cbf772ac7ceae80f931a539524d9193',1,'dsp_complex::@0::real()']]],
  ['red_4',['red',['../group___d_s_p.html#ga517949bf72f39b594e2db973861947b2',1,'dsp_stream_t']]],
  ['refpix_5',['refpix',['../structdsp__fits__axis.html#a07ef4319734ef0d2953aebc7a91bcf29',1,'dsp_fits_axis']]],
  ['relative_6',['relative',['../structvlbi__baseline.html#a083bcfe10e5a959e8c8f74f8a4c8626b',1,'vlbi_baseline']]],
  ['repeat_7',['repeat',['../structdsp__fits__format.html#a6495de1166ea374e4dd6a8b7a7b52208',1,'dsp_fits_format']]],
  ['roi_8',['ROI',['../group___d_s_p.html#gae4945adcbb1cc9fef407a62d6109a312',1,'dsp_stream_t']]]
];
