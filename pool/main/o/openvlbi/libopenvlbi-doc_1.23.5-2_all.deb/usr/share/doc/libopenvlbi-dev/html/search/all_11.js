var searchData=
[
  ['target_0',['target',['../group___d_s_p.html#ga6ed19c9f01e0485ece8c612cd18f529f',1,'dsp_stream_t']]],
  ['target_1',['Target',['../structvlbi__baseline.html#a4ca9b60bd6a28f67bd4ef290e4e1dde5',1,'vlbi_baseline']]],
  ['tempscal_5ftb_2',['TEMPSCAL_TB',['../group__dsp___fits_extension_s_d_f_i_t_s.html#ga0bf1fa6d63709f2bc5ee805118f77fdb',1,'sdfits.h']]],
  ['theta_3',['theta',['../group___d_s_p.html#ga8c248093882e6b5d96ca5e021daa7c0f',1,'dsp_triangle_t']]],
  ['thread_4',['thread',['../group___d_s_p.html#gae7a5ff8cbb6b9fe3d5cf1725617f9d0c',1,'dsp_stream_t']]],
  ['time_20conversions_5',['Time conversions',['../group___v_l_b_i___time.html',1,'']]],
  ['timespec_5ft_6',['timespec_t',['../group___v_l_b_i___types.html#gaa0b51754d79d4eac2b53e1c6ae364c43',1,'vlbi.h']]],
  ['trackrate_5flunar_7',['TRACKRATE_LUNAR',['../group___v_l_b_i___defines.html#gaf1344756892ba7d63cf2fdb927389f6e',1,'vlbi.h']]],
  ['trackrate_5fsidereal_8',['TRACKRATE_SIDEREAL',['../group___v_l_b_i___defines.html#gadec5cbb64e6214efa6422d3031113b90',1,'vlbi.h']]],
  ['trackrate_5fsolar_9',['TRACKRATE_SOLAR',['../group___v_l_b_i___defines.html#ga8039a7406532784e1804ef39260045a7',1,'vlbi.h']]],
  ['triangles_10',['triangles',['../group___d_s_p.html#gae34ce9d06f604b290bb67c14424fc4cd',1,'dsp_align_info_t::triangles()'],['../group___d_s_p.html#ga8e51e08def3c851c2f09e27b76180b70',1,'dsp_stream_t::triangles()']]],
  ['triangles_5fcount_11',['triangles_count',['../group___d_s_p.html#gabc77e9fa58160b64262dc9d7b12f286b',1,'dsp_align_info_t::triangles_count()'],['../group___d_s_p.html#ga2c345220a5e40e0a18f758243c9ee2a5',1,'dsp_stream_t::triangles_count()']]],
  ['typecode_12',['typecode',['../structdsp__fits__format.html#a451f9011c4c3ad98fbf82d3dc8280e21',1,'dsp_fits_format']]],
  ['typestr_13',['typestr',['../structdsp__fits__format.html#ae528b08f14e901cd55e5de0253a8c2f3',1,'dsp_fits_format']]]
];
