var searchData=
[
  ['center_0',['center',['../group___d_s_p.html#ga25582fb3facc1d5182e8a512744bfd38',1,'dsp_star_t::center()'],['../group___d_s_p.html#ga3eacff49b94608d8cac817ce28105f12',1,'dsp_align_info_t::center()']]],
  ['child_5fcount_1',['child_count',['../group___d_s_p.html#gac4f169d5e47e93bc982ea61fa5841d8f',1,'dsp_stream_t']]],
  ['children_2',['children',['../group___d_s_p.html#gaaea31f9e268c708cc8cabb3b8dcdbe99',1,'dsp_stream_t']]],
  ['columns_3',['columns',['../structdsp__fits__row.html#a8c972f3af02f2ecf9d8db00ccaabc489',1,'dsp_fits_row']]],
  ['comment_4',['comment',['../structdsp__fits__keyword.html#a91e2a06e9e858a6f7fb327c14d966ed6',1,'dsp_fits_keyword::comment()'],['../structdsp__fits__column.html#a8c235c5415da062daa3bf33c6f9b58af',1,'dsp_fits_column::comment()'],['../structdsp__fits__axis.html#a5b3e1f2aa89167dc2df5990efae6e782',1,'dsp_fits_axis::comment()'],['../structdsp__fits__matrix.html#a378b5f7c5cc2b59bcc0072998720f00c',1,'dsp_fits_matrix::comment()']]],
  ['complex_5',['complex',['../group___d_s_p.html#ga0e9317be51e2422d3213ab834d99005d',1,'dsp_complex']]],
  ['coordinates_6',['coordinates',['../group___d_s_p.html#ga8af8968a2c9a879a883fdd6498aa3c03',1,'dsp_location_t']]]
];
