var searchData=
[
  ['j2000_0',['J2000',['../group___v_l_b_i___defines.html#gafd09200b4253bfff7b9a890591e09292',1,'vlbi.h']]]
];
