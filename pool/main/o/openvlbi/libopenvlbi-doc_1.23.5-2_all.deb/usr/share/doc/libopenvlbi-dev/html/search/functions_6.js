var searchData=
[
  ['idft_0',['Idft',['../class_v_l_b_i_1_1_server.html#a4e49aa8fb407efbcc1a2f287b26c66ea',1,'VLBI::Server']]],
  ['init_1',['Init',['../class_v_l_b_i_1_1_server.html#a92cd5bfb6314ded325382b984dbefb62',1,'VLBI::Server']]]
];
