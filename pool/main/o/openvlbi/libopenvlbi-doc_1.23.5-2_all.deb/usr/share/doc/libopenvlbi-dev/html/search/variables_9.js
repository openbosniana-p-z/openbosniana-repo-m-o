var searchData=
[
  ['magnitude_0',['magnitude',['../group___d_s_p.html#ga7a2637533bdc7b363dcea9e3c2cc59b4',1,'dsp_stream_t']]]
];
