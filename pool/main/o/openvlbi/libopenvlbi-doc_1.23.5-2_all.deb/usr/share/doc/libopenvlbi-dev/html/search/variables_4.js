var searchData=
[
  ['err_0',['err',['../group___d_s_p.html#ga1b016e34ccff700572cda06e0f7abd0b',1,'dsp_align_info_t']]],
  ['expected_1',['expected',['../structdsp__fits__keyword.html#af267f69b6869a74d61455b56587d4395',1,'dsp_fits_keyword::expected()'],['../structdsp__fits__column.html#aca8e41e83171e7be33840e3c3d7a7c80',1,'dsp_fits_column::expected()']]]
];
