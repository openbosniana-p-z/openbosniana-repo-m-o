var searchData=
[
  ['pairs_0',['pairs',['../group___d_s_p.html#gafe53308b911daa147fcc8344d60c04e6',1,'dsp_complex']]],
  ['parent_1',['parent',['../group___d_s_p.html#ga40dc327cb0be8479a2d9af06a6996fe7',1,'dsp_stream_t']]],
  ['phase_2',['phase',['../group___d_s_p.html#ga00752458b299d33e40cd81c6e50d9115',1,'dsp_stream_t']]],
  ['pixel_5fsizes_3',['pixel_sizes',['../group___d_s_p.html#ga233ee0e0aac827d9acd06a0d0e91a16a',1,'dsp_stream_t']]]
];
