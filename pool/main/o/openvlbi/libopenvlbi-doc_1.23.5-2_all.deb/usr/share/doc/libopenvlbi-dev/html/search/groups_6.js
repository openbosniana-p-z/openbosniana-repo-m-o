var searchData=
[
  ['openvlbi_20server_20c_2b_2b_20api_0',['OpenVLBI Server C++ API',['../group___server.html',1,'']]]
];
