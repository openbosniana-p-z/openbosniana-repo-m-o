var searchData=
[
  ['u_0',['u',['../structvlbi__baseline.html#a3df508a186ef8126f2f3242f538c1cc2',1,'vlbi_baseline']]],
  ['unit_1',['unit',['../structdsp__fits__keyword.html#ac1b31b5271d6d7600366a412a8ea58d7',1,'dsp_fits_keyword::unit()'],['../structdsp__fits__column.html#aac3158b2325332ab0bc8d44a10a1e1dd',1,'dsp_fits_column::unit()'],['../structdsp__fits__axis.html#a21cf7ff0a3c2bae913223351e38de6ec',1,'dsp_fits_axis::unit()'],['../structdsp__fits__matrix.html#a4ac72c43f5377a768a0640f3bb6081bd',1,'dsp_fits_matrix::unit()']]],
  ['using_20openvlbi_2',['Using OpenVLBI',['../page__using.html',1,'']]]
];
