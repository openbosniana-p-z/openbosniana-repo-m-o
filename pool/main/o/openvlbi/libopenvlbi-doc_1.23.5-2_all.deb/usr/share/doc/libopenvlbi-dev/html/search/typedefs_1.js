var searchData=
[
  ['timespec_5ft_0',['timespec_t',['../group___v_l_b_i___types.html#gaa0b51754d79d4eac2b53e1c6ae364c43',1,'vlbi.h']]]
];
