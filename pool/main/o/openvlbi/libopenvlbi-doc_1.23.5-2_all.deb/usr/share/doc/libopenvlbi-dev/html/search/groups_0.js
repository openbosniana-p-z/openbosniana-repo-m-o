var searchData=
[
  ['astronomy_20specific_0',['Astronomy specific',['../group___v_l_b_i___astro.html',1,'']]]
];
