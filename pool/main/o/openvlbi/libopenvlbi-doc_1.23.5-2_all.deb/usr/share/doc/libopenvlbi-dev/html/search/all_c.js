var searchData=
[
  ['name_0',['name',['../group___d_s_p.html#ga9bd2faaa868d0420c3db136a734d4c3f',1,'dsp_star_t::name()'],['../group___d_s_p.html#ga0b5f7589eb4066ad7e8cb17800f8ac54',1,'dsp_stream_t::name()'],['../structdsp__fits__keyword.html#a0fc24ff390f501a5dcab107715ca4c80',1,'dsp_fits_keyword::name()'],['../structdsp__fits__column.html#a96750a1e5ea6bad2e2925794965fc744',1,'dsp_fits_column::name()'],['../structdsp__fits__axis.html#a2d003ad26036f756540be265c796aa64',1,'dsp_fits_axis::name()'],['../structdsp__fits__axis.html#a45c2b494b7a8e9b58b924f0e471845b9',1,'dsp_fits_axis::name()'],['../structdsp__fits__matrix.html#a026f1f00330beb345ea963ff40a043da',1,'dsp_fits_matrix::name()'],['../structdsp__fits__matrix.html#a9e64b9d135be3458c098917e879f45b4',1,'dsp_fits_matrix::name()']]],
  ['name_1',['Name',['../structvlbi__node.html#ae2609b20e785660dceb9397f69f274e6',1,'vlbi_node::Name()'],['../structvlbi__baseline.html#a1719db627b870126ccfaa2f926f2aa9d',1,'vlbi_baseline::Name()']]],
  ['node1_2',['Node1',['../structvlbi__baseline.html#ab9b1ac7e0f9d2dab00236b4abcbcf12b',1,'vlbi_baseline']]],
  ['node2_3',['Node2',['../structvlbi__baseline.html#a3f2cc666a17cb23587ec265577b48541',1,'vlbi_baseline']]],
  ['nodes_20api_4',['Nodes API',['../group___v_l_b_i___nodes.html',1,'']]],
  ['num_5fcolumns_5',['num_columns',['../structdsp__fits__row.html#a5efb187a7d5dc21c6371171b85bced21',1,'dsp_fits_row']]]
];
