var searchData=
[
  ['factor_0',['factor',['../group___d_s_p.html#ga2d5e397aad2739aa553cdacb4b45e980',1,'dsp_align_info_t']]],
  ['focal_5fratio_1',['focal_ratio',['../group___d_s_p.html#ga3b5d226ca9eabdff37caf0930232216b',1,'dsp_stream_t']]],
  ['format_2',['format',['../structdsp__fits__keyword.html#a10b19b76cc03eb158ae52c9e276c3561',1,'dsp_fits_keyword::format()'],['../structdsp__fits__column.html#a02f3fa69bb9b43d74d6ad20418e2bdd6',1,'dsp_fits_column::format()'],['../structdsp__fits__axis.html#a76a9c57caee5fc459c54cd2810169364',1,'dsp_fits_axis::format()'],['../structdsp__fits__matrix.html#ae9a2cb9124e2d2f58a6987d02dc5f0bb',1,'dsp_fits_matrix::format()'],['../structdsp__fits__matrix.html#af7abcc48d1d7325a9a20714471a523bc',1,'dsp_fits_matrix::format()']]],
  ['frame_5fnumber_3',['frame_number',['../group___d_s_p.html#ga28e720a294f2fa70766010198f88531c',1,'dsp_stream_t']]],
  ['func_4',['func',['../group___d_s_p.html#ga9396563830da1b28c966fec3f1378dbc',1,'dsp_stream_t']]]
];
