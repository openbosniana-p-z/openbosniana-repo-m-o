(** @canonical Cry.Cry_common *)
module Cry_common = Cry__Cry_common


(** @canonical Cry.Cry_https *)
module Cry_https = Cry__Cry_https
