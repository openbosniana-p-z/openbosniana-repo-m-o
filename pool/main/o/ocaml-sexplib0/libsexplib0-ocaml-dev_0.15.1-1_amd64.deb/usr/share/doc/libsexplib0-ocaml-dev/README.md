"Sexplib0 - a low-dep version of Sexplib"
=========================================

`sexplib0` is a lightweight portion of `sexplib`, for situations where a
dependency on `sexplib` is problematic.

It has the type definition and the printing functions, but not parsing.

See  [sexplib](https://github.com/janestreet/sexplib) for documentation.
