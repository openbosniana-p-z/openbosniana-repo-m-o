#!/bin/sh --

cd /usr/share/games/oneisenough/
python3 run_game.py "$@"

