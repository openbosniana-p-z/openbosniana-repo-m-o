#include <ost/geom/transform.hh>

namespace ost { namespace mol {
#warning mol::Transform is deprecated, use geom::Transform instead
    typedef geom::Transform Transform;
}}
