#ifdef _MSC_VER
  #if _MSC_VER >= 1600
    #include <stdint.h>
  #else
    #include <ost/stdint_msc.hh>
  #endif
#else
#include <stdint.h>
#endif

