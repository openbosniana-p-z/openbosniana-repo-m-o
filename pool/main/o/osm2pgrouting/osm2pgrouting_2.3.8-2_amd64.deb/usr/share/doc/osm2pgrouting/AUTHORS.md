# Project contributors:

## pgROuting Team:

* Daniel Kastl
* Ko Nagase
* Regina Obe
* Virginia Vergara

## Other contributors:

* Aakash Sharma
* Adrien Pavie
* Anton Patrushev
* Daniel Wendt (Initial author) 
* Jordan Anderson
* J Kishore Kumar
* Luís de Sousa
* Sarthak Agarwal
