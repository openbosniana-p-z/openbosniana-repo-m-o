"""
Folder Module of offlineimap
"""
from . import Base, Gmail, IMAP, Maildir, LocalStatus, UIDMaps
