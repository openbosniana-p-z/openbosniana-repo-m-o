# bigarray-compat

A library that exposes `Stdlib.Bigarray` when possible (>= 4.07) but can fallback to `Bigarray`.
The compability bigarray module is exposed under `Bigarray_compat`.