var group__Solvers =
[
    [ "Non-Linear Solver", "group__Newton.html", null ],
    [ "Linear Solvers", "group__Linear.html", null ]
];