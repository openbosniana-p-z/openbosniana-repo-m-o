var lens__richards__ecfv_8cc =
[
    [ "Opm::Properties::TTag::RichardsLensEcfvProblem", "structOpm_1_1Properties_1_1TTag_1_1RichardsLensEcfvProblem.html", null ],
    [ "Opm::Properties::SpatialDiscretizationSplice< TypeTag, TTag::RichardsLensEcfvProblem >", "structOpm_1_1Properties_1_1SpatialDiscretizationSplice_3_01TypeTag_00_01TTag_1_1RichardsLensEcfvProblem_01_4.html", null ],
    [ "Opm::Properties::LocalLinearizerSplice< TypeTag, TTag::RichardsLensEcfvProblem >", "structOpm_1_1Properties_1_1LocalLinearizerSplice_3_01TypeTag_00_01TTag_1_1RichardsLensEcfvProblem_01_4.html", null ]
];