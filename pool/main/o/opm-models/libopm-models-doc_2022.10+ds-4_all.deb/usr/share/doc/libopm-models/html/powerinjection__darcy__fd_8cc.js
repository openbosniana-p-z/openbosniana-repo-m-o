var powerinjection__darcy__fd_8cc =
[
    [ "Opm::Properties::TTag::PowerInjectionDarcyFdProblem", "structOpm_1_1Properties_1_1TTag_1_1PowerInjectionDarcyFdProblem.html", null ],
    [ "Opm::Properties::FluxModule< TypeTag, TTag::PowerInjectionDarcyFdProblem >", "structOpm_1_1Properties_1_1FluxModule_3_01TypeTag_00_01TTag_1_1PowerInjectionDarcyFdProblem_01_4.html", null ],
    [ "Opm::Properties::LocalLinearizerSplice< TypeTag, TTag::PowerInjectionDarcyFdProblem >", "structOpm_1_1Properties_1_1LocalLinearizerSplice_3_01TypeTag_00_01TTag_1_1PowerInjectionDarcyFdProblem_01_4.html", null ]
];