var lens__immiscible__vcfv__ad_8cc =
[
    [ "Opm::Properties::TTag::LensProblemVcfvAd", "structOpm_1_1Properties_1_1TTag_1_1LensProblemVcfvAd.html", null ],
    [ "Opm::Properties::LocalLinearizerSplice< TypeTag, TTag::LensProblemVcfvAd >", "structOpm_1_1Properties_1_1LocalLinearizerSplice_3_01TypeTag_00_01TTag_1_1LensProblemVcfvAd_01_4.html", null ]
];