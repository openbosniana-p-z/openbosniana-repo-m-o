var searchData=
[
  ['solvers_0',['Solvers',['../group__Solvers.html',1,'']]],
  ['spatial_20discretizations_1',['Spatial Discretizations',['../group__SpatialDiscretizations.html',1,'']]]
];
