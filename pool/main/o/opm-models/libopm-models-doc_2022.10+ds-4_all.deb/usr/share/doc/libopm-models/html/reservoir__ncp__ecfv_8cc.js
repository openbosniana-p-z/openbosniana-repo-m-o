var reservoir__ncp__ecfv_8cc =
[
    [ "Opm::Properties::TTag::ReservoirNcpEcfvProblem", "structOpm_1_1Properties_1_1TTag_1_1ReservoirNcpEcfvProblem.html", null ],
    [ "Opm::Properties::SpatialDiscretizationSplice< TypeTag, TTag::ReservoirNcpEcfvProblem >", "structOpm_1_1Properties_1_1SpatialDiscretizationSplice_3_01TypeTag_00_01TTag_1_1ReservoirNcpEcfvProblem_01_4.html", null ],
    [ "Opm::Properties::LocalLinearizerSplice< TypeTag, TTag::ReservoirNcpEcfvProblem >", "structOpm_1_1Properties_1_1LocalLinearizerSplice_3_01TypeTag_00_01TTag_1_1ReservoirNcpEcfvProblem_01_4.html", null ]
];