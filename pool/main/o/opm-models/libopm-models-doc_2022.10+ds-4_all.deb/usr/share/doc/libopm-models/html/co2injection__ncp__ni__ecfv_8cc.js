var co2injection__ncp__ni__ecfv_8cc =
[
    [ "Opm::Properties::TTag::Co2InjectionNcpNiEcfvProblem", "structOpm_1_1Properties_1_1TTag_1_1Co2InjectionNcpNiEcfvProblem.html", null ],
    [ "Opm::Properties::SpatialDiscretizationSplice< TypeTag, TTag::Co2InjectionNcpNiEcfvProblem >", "structOpm_1_1Properties_1_1SpatialDiscretizationSplice_3_01TypeTag_00_01TTag_1_1Co2InjectionNcpNiEcfvProblem_01_4.html", null ],
    [ "Opm::Properties::EnableEnergy< TypeTag, TTag::Co2InjectionNcpNiEcfvProblem >", "structOpm_1_1Properties_1_1EnableEnergy_3_01TypeTag_00_01TTag_1_1Co2InjectionNcpNiEcfvProblem_01_4.html", null ],
    [ "Opm::Properties::LocalLinearizerSplice< TypeTag, TTag::Co2InjectionNcpNiEcfvProblem >", "structOpm_1_1Properties_1_1LocalLinearizerSplice_3_01TypeTag_00_01TTag_1_1Co2InjectionNcpNiEcfvProblem_01_4.html", null ]
];