var group__ModelModules =
[
    [ "Flux", "group__FluxModules.html", null ],
    [ "Molecular Diffusion", "group__Diffusion.html", null ],
    [ "Energy", "group__Energy.html", null ],
    [ "VTK output", "group__Vtk.html", null ]
];