var co2injection__immiscible__ni__vcfv_8cc =
[
    [ "Opm::Properties::TTag::Co2InjectionImmiscibleNiVcfvProblem", "structOpm_1_1Properties_1_1TTag_1_1Co2InjectionImmiscibleNiVcfvProblem.html", null ],
    [ "Opm::Properties::SpatialDiscretizationSplice< TypeTag, TTag::Co2InjectionImmiscibleNiVcfvProblem >", "structOpm_1_1Properties_1_1SpatialDiscretizationSplice_3_01TypeTag_00_01TTag_1_1Co2InjectionImmiscibleNiVcfvProblem_01_4.html", null ],
    [ "Opm::Properties::EnableEnergy< TypeTag, TTag::Co2InjectionImmiscibleNiVcfvProblem >", "structOpm_1_1Properties_1_1EnableEnergy_3_01TypeTag_00_01TTag_1_1Co2InjectionImmiscibleNiVcfvProblem_01_4.html", null ]
];