var powerinjection__forchheimer__ad_8cc =
[
    [ "Opm::Properties::TTag::PowerInjectionForchheimerAdProblem", "structOpm_1_1Properties_1_1TTag_1_1PowerInjectionForchheimerAdProblem.html", null ],
    [ "Opm::Properties::FluxModule< TypeTag, TTag::PowerInjectionForchheimerAdProblem >", "structOpm_1_1Properties_1_1FluxModule_3_01TypeTag_00_01TTag_1_1PowerInjectionForchheimerAdProblem_01_4.html", null ],
    [ "Opm::Properties::LocalLinearizerSplice< TypeTag, TTag::PowerInjectionForchheimerAdProblem >", "structOpm_1_1Properties_1_1LocalLinearizerSplice_3_01TypeTag_00_01TTag_1_1PowerInjectionForchheimerAdProblem_01_4.html", null ]
];