var powerinjection__darcy__ad_8cc =
[
    [ "Opm::Properties::TTag::PowerInjectionDarcyAdProblem", "structOpm_1_1Properties_1_1TTag_1_1PowerInjectionDarcyAdProblem.html", null ],
    [ "Opm::Properties::FluxModule< TypeTag, TTag::PowerInjectionDarcyAdProblem >", "structOpm_1_1Properties_1_1FluxModule_3_01TypeTag_00_01TTag_1_1PowerInjectionDarcyAdProblem_01_4.html", null ],
    [ "Opm::Properties::LocalLinearizerSplice< TypeTag, TTag::PowerInjectionDarcyAdProblem >", "structOpm_1_1Properties_1_1LocalLinearizerSplice_3_01TypeTag_00_01TTag_1_1PowerInjectionDarcyAdProblem_01_4.html", null ]
];