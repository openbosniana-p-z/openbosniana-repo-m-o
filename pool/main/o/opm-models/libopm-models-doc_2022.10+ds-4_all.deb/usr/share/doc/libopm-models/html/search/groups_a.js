var searchData=
[
  ['richards_0',['Richards',['../group__RichardsModel.html',1,'']]]
];
