var powerinjection__forchheimer__fd_8cc =
[
    [ "Opm::Properties::TTag::PowerInjectionForchheimerFdProblem", "structOpm_1_1Properties_1_1TTag_1_1PowerInjectionForchheimerFdProblem.html", null ],
    [ "Opm::Properties::FluxModule< TypeTag, TTag::PowerInjectionForchheimerFdProblem >", "structOpm_1_1Properties_1_1FluxModule_3_01TypeTag_00_01TTag_1_1PowerInjectionForchheimerFdProblem_01_4.html", null ],
    [ "Opm::Properties::LocalLinearizerSplice< TypeTag, TTag::PowerInjectionForchheimerFdProblem >", "structOpm_1_1Properties_1_1LocalLinearizerSplice_3_01TypeTag_00_01TTag_1_1PowerInjectionForchheimerFdProblem_01_4.html", null ]
];