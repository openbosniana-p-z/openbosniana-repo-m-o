var files_dup =
[
    [ "tests", "dir_59425e443f801f1f2fd8bbe4959a3ccf.html", "dir_59425e443f801f1f2fd8bbe4959a3ccf" ],
    [ "tutorial", "dir_07c2df013bb20677b8e65a9f18968d2c.html", "dir_07c2df013bb20677b8e65a9f18968d2c" ]
];