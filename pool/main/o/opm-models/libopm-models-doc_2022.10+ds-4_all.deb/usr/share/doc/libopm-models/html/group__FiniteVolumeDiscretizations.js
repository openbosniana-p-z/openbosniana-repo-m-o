var group__FiniteVolumeDiscretizations =
[
    [ "Vertex-Centered-Finite-Volumes", "group__VcfvDiscretization.html", null ],
    [ "Element-Centered-Finite-Volumes", "group__EcfvDiscretization.html", null ]
];