var co2injection__immiscible__ecfv_8cc =
[
    [ "Opm::Properties::TTag::Co2InjectionImmiscibleEcfvProblem", "structOpm_1_1Properties_1_1TTag_1_1Co2InjectionImmiscibleEcfvProblem.html", null ],
    [ "Opm::Properties::SpatialDiscretizationSplice< TypeTag, TTag::Co2InjectionImmiscibleEcfvProblem >", "structOpm_1_1Properties_1_1SpatialDiscretizationSplice_3_01TypeTag_00_01TTag_1_1Co2InjectionImmiscibleEcfvProblem_01_4.html", null ]
];