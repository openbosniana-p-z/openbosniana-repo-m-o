var searchData=
[
  ['groundwaterproblem_0',['GroundWaterProblem',['../classOpm_1_1GroundWaterProblem.html#a240c805b52c1bf3530fd9b2416b80a13',1,'Opm::GroundWaterProblem']]],
  ['guessinitial_1',['guessInitial',['../classOpm_1_1Co2InjectionFlash.html#a176e12d339ebfa204a4f614c16e92509',1,'Opm::Co2InjectionFlash']]]
];
