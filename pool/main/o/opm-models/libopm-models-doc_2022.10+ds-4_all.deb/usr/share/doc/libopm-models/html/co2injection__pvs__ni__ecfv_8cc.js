var co2injection__pvs__ni__ecfv_8cc =
[
    [ "Opm::Properties::TTag::Co2InjectionPvsNiEcfvProblem", "structOpm_1_1Properties_1_1TTag_1_1Co2InjectionPvsNiEcfvProblem.html", null ],
    [ "Opm::Properties::SpatialDiscretizationSplice< TypeTag, TTag::Co2InjectionPvsNiEcfvProblem >", "structOpm_1_1Properties_1_1SpatialDiscretizationSplice_3_01TypeTag_00_01TTag_1_1Co2InjectionPvsNiEcfvProblem_01_4.html", null ],
    [ "Opm::Properties::EnableEnergy< TypeTag, TTag::Co2InjectionPvsNiEcfvProblem >", "structOpm_1_1Properties_1_1EnableEnergy_3_01TypeTag_00_01TTag_1_1Co2InjectionPvsNiEcfvProblem_01_4.html", null ],
    [ "Opm::Properties::LocalLinearizerSplice< TypeTag, TTag::Co2InjectionPvsNiEcfvProblem >", "structOpm_1_1Properties_1_1LocalLinearizerSplice_3_01TypeTag_00_01TTag_1_1Co2InjectionPvsNiEcfvProblem_01_4.html", null ]
];