var group__Models =
[
    [ "Immiscible", "group__ImmiscibleModel.html", null ],
    [ "PVS", "group__PvsModel.html", null ],
    [ "NCP", "group__NcpModel.html", null ],
    [ "Flash", "group__FlashModel.html", null ],
    [ "Black Oil", "group__BlackOilModel.html", null ],
    [ "Richards", "group__RichardsModel.html", null ],
    [ "(Navier-)Stokes", "group__StokesModel.html", null ],
    [ "Modules", "group__ModelModules.html", "group__ModelModules" ]
];