var modules =
[
    [ "Common", "group__Common.html", "group__Common" ],
    [ "Solvers", "group__Solvers.html", "group__Solvers" ],
    [ "Spatial Discretizations", "group__SpatialDiscretizations.html", "group__SpatialDiscretizations" ],
    [ "Flow Models", "group__Models.html", "group__Models" ],
    [ "ECL compatible black-oil simulator", "group__EclBlackOilSimulator.html", null ]
];