#pragma once

/* TODO: C++ math wrappers */
