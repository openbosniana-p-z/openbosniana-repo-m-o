from enum import IntEnum, auto

class CircleParam(IntEnum):
    CENTER_X = 0
    CENTER_Y = auto()
    RADIUS   = auto()
