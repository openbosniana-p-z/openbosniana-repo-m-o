from enum import IntEnum, auto

class NeedleParam(IntEnum):
    ROTATION = 0
    RHO      = auto()
    RADIUS   = auto()
