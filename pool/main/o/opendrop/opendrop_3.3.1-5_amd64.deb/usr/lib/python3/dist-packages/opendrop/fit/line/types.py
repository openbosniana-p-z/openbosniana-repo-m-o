from enum import IntEnum, auto

class LineParam(IntEnum):
    ANGLE = 0
    RHO   = auto()
